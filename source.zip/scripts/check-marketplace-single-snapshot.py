#!/usr/bin/env python3
"""Compile the ACTUAL marketplace composite JS in WishlistPriceWebViewProbe and run
positive/negative DOM snapshots. No Android SDK and no external service required."""
from pathlib import Path
import subprocess, tempfile, textwrap
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
java=(src/'WishlistPriceWebViewProbe.java').read_text()
start=java.index('actualJs = "(function(){try{var a=JSON.parse(')
end=java.index(';\n        }\n        else if (unknownGeneralDetail',start)+1
expression=java[start:end]
assert 'a.pageKind=b.pageKind;' in expression
assert 'WishlistGeneralMarketplaceImageDom.javascript(originalRetailUrl)' in expression
p=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
assert 'final boolean unifiedMarketSnapshot = serialGeneralPrice && guardedSavedMarketplace' in p
assert 'market.snapshot.complete' in p
assert 'if (unifiedMarketSnapshot) {' in p
assert 'repo.updateImageFromWebView(id, image, before.url' in p
assert 'finishUpdate(id);\n                            } else if (serialGeneralPrice)' in p
# This constructor shares one DOM; do not accidentally run the old three WebViews.
assert 'marketplaceImages.clear();' in java
assert 'marketplacePageKind="uninspected";' in java

with tempfile.TemporaryDirectory() as d:
    d=Path(d)
    (d/'SnapshotHarness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class SnapshotHarness {
 public static void main(String[] args)throws Exception{
 URL originalRetailUrl=new URL(args[0]);
 String actualJs="";
 '''+expression+'''
 System.out.print(actualJs);
 }
}
''')
    files=[src/(x+'.java') for x in ['WishlistGeneralMarketplaceIdentity','WishlistGeneralMarketplaceHydrationDom','WishlistGeneralMarketplaceVerifiedDom','WishlistGeneralMarketplaceImageDom']]
    subprocess.run(['javac','-encoding','UTF-8','-d',str(d),*[str(x) for x in files],str(d/'SnapshotHarness.java')],check=True, capture_output=True, text=True)
    urls=['https://m.shein.com/jp/Shirt-p-12345678.html','https://ja.aliexpress.com/item/1005008877665544.html']
    for i,u in enumerate(urls):
        result=subprocess.run(['java','-cp',str(d),'com.cmyk.bookmarkslauncher.wishlist.SnapshotHarness',u],check=True,capture_output=True,text=True)
        (d/('market'+str(i)+'.js')).write_text(result.stdout)
    node=r'''
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const shein=fs.readFileSync(process.argv[2],'utf8');
const ali=fs.readFileSync(process.argv[3],'utf8');
const savedS='https://m.shein.com/jp/Shirt-p-12345678.html', savedA='https://ja.aliexpress.com/item/1005008877665544.html';
function run(js,url,records=[],opts={}){
 const u=new URL(url),products=records.map(x=>({textContent:JSON.stringify(x)}));
 const img={alt:'',currentSrc:'https://img.shein.com/product/catalog-123.jpg',
  getAttribute:k=>k==='src'?'https://img.shein.com/product/catalog-123.jpg':null,closest:()=>null};
 const doc={readyState:'complete',body:{innerText:'Sample product detail with a current JPY price'},
 querySelector:q=>q.includes('canonical')?(opts.canonical?{href:opts.canonical}:null):null,
 querySelectorAll:q=>q==='script[type="application/ld+json"]'?products:(opts.gallery&&q==='[class*="product-gallery"] img'?[img]:[])};
 const ctx={document:doc,window:{},location:{href:url,hostname:u.hostname,pathname:u.pathname},URL,Set};
 const out=vm.runInNewContext(js,ctx,{timeout:3000});
 return JSON.parse(out);
}
let goodS={'@type':'Product',url:savedS,name:'Cotton SHEIN Shirt 1234',image:'https://img.shein.com/product/shirt1234.jpg',offers:{price:'2700',priceCurrency:'JPY'}};
let goodA={'@type':'Product',url:savedA,name:'AliExpress Blue Bottle 1234',image:'https://ae01.alicdn.com/kf/bottle1234.jpg',offers:{price:'1599',priceCurrency:'JPY'}};
let z=run(shein,savedS,[goodS]);
assert.equal(z.title,goodS.name);assert.equal(z.value,'¥2700');assert.equal(z.currency,'JPY');
assert.equal(z.pageKind,'item-bound-jsonld');assert.deepEqual(Array.from(z.imageCandidates),[goodS.image]);
assert.equal(z.itemEvidence,'verified-product');
z=run(ali,savedA,[goodA]);
assert.equal(z.title,goodA.name);assert.equal(z.value,'¥1599');assert.deepEqual(Array.from(z.imageCandidates),[goodA.image]);
z=run(shein,'https://m.shein.com/jp/landing',[]);
assert.equal(z.reason,'id-unverified');assert.equal(z.pageKind,'unbound-url');assert.equal(z.imageCandidates.length,0);
z=run(shein,'https://m.shein.com/jp/landing',[goodS]);
assert.equal(z.title,goodS.name);assert.equal(z.value,'¥2700');assert.equal(z.imageCandidates.length,1);
z=run(shein,'https://m.shein.com/jp/other-p-12345679.html',[goodS]);
assert.equal(z.title,'');assert.equal(z.value,'');assert.equal(z.imageCandidates.length,0);
z=run(shein,savedS,[{'@type':'Product',url:'https://m.shein.com/jp/other-p-12345679.html',name:'Wrong Item',image:'https://img.shein.com/product/wrong.jpg',offers:{price:5,priceCurrency:'JPY'}}]);
assert.equal(z.title,'');assert.equal(z.value,'');assert.equal(z.imageCandidates.length,0);
z=run(shein,savedS,[{...goodS,offers:{price:2700,priceCurrency:'USD'}}]);
assert.equal(z.value,'');assert.equal(z.imageCandidates.length,1);
z=run(shein,savedS,[goodS],{canonical:'https://m.shein.com/jp/other-p-12345679.html'});
assert.equal(z.title,'');assert.equal(z.value,'');assert.equal(z.imageCandidates.length,0);
z=run(shein,savedS,[goodS],{canonical:'https://m.shein.com/'});
assert.equal(z.title,goodS.name);assert.equal(z.value,'¥2700');
z=run(shein,savedS,[],{gallery:true});
assert.equal(z.title,'');assert.equal(z.value,'');assert.equal(z.imageCandidates.length,1);
assert.equal(z.imageCandidates[0],'https://img.shein.com/product/catalog-123.jpg');
z=run(shein,'https://m.shein.com/jp/landing',[],{gallery:true});
assert.equal(z.imageCandidates.length,0);
// Real SHEIN URLs may include -cat-ID after the *product* ID.
const catS='https://m.shein.com/jp/Shirt-p-12345678-cat-1738.html';
const wrongCat='https://m.shein.com/jp/Shirt-p-12345679-cat-1738.html';
const catProd={'@type':'Product',url:'https://jp.shein.com/Shirt-p-12345678-cat-1738.html',name:'Cat-bound SHEIN shirt',image:'https://img.shein.com/product/cat-123.jpg',offers:{price:'3780',priceCurrency:'JPY'}};
z=run(shein,catS,[catProd]);
assert.equal(z.title,catProd.name);assert.equal(z.value,'¥3780');assert.equal(z.pageKind,'item-bound-jsonld');
assert.equal(z.itemEvidence,'verified-product');assert.equal(z.imageCandidates.length,1);
z=run(shein,wrongCat,[catProd]);
assert.equal(z.title,'');assert.equal(z.value,'');assert.equal(z.imageCandidates.length,0);assert.equal(z.pageKind,'other-item-url');
z=run(shein,catS,[catProd],{canonical:wrongCat});
assert.equal(z.title,'');assert.equal(z.value,'');assert.equal(z.imageCandidates.length,0);
z=run(shein,'https://m.shein.com/jp/',[catProd]);
assert.equal(z.title,catProd.name);assert.equal(z.imageCandidates.length,1);
z=run(shein,'https://m.shein.com/jp/',[],{gallery:true});
assert.equal(z.imageCandidates.length,0);
console.log('Single-document snapshot DOM: PASS (16 field and denial scenarios, actual Java-built JS)');
'''
    (d/'snapshot-test.cjs').write_text(node)
    subprocess.run(['node',str(d/'snapshot-test.cjs'),str(d/'market0.js'),str(d/'market1.js')],check=True)
print('Single-WebView marketplace route and data preservation gates: PASS')
