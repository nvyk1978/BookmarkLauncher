#!/usr/bin/env python3
"""Compile the production numbered JS assembler against predictable stub sources,
then run the output in Node to catch Java->JS composition and duplicate stages."""
from pathlib import Path
import subprocess,tempfile, json
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
java_files={
 'org/json/JSONObject.java':r'''package org.json;public class JSONObject {public static String quote(String s){if(s==null)return "null";return "\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\"";} }''',
 'com/cmyk/bookmarkslauncher/wishlist/WishlistNumberedTechniqueRegistry.java':'''package com.cmyk.bookmarkslauncher.wishlist;public class WishlistNumberedTechniqueRegistry {public static int builtinCount(){return 40;}public static String number(int i){return String.format("%03d",i);}}''',
 'com/cmyk/bookmarkslauncher/wishlist/WishlistGeneralPurchaseDom.java':'''package com.cmyk.bookmarkslauncher.wishlist;public class WishlistGeneralPurchaseDom {public static String javascript(){return "'UNKNOWN'";}}''',
 'com/cmyk/bookmarkslauncher/wishlist/WishlistGeneralVariantStockDom.java':'''package com.cmyk.bookmarkslauncher.wishlist;import java.net.URL;public class WishlistGeneralVariantStockDom {public static String source(URL url){return "'UNKNOWN'";}}''',
 'com/cmyk/bookmarkslauncher/wishlist/WishlistMercariItemStockDom.java':'''package com.cmyk.bookmarkslauncher.wishlist;import java.net.URL;public class WishlistMercariItemStockDom {public static String javascript(URL url){return "'UNKNOWN'";}}''',
 'com/cmyk/bookmarkslauncher/wishlist/WishlistGeneralAlphabetDom.java':'''package com.cmyk.bookmarkslauncher.wishlist;import java.net.URL;public class WishlistGeneralAlphabetDom {public static String source(URL url,char label){return "'UNKNOWN'";}}''',
 'com/cmyk/bookmarkslauncher/wishlist/WishlistGeneralProductIdentity.java':'''package com.cmyk.bookmarkslauncher.wishlist;import java.net.URL;public class WishlistGeneralProductIdentity {public static String code(URL url){return "E123456-001";}}''',
 'com/cmyk/bookmarkslauncher/wishlist/WishlistCrawler.java':'''package com.cmyk.bookmarkslauncher.wishlist;import java.net.URL;public class WishlistCrawler {public static boolean isSingleProductPage(URL url){return true;}}''',
 'com/cmyk/bookmarkslauncher/wishlist/WishlistNumberedNativeAdapters.java':'''package com.cmyk.bookmarkslauncher.wishlist;import java.net.URL;public class WishlistNumberedNativeAdapters {public static String javascript(URL url,int stage){return stage==19?"JSON.stringify({status:'AVAILABLE',reason:'native-verified'})":null;}}''',
 'Run.java':'''import java.net.URL;import java.util.*;import com.cmyk.bookmarkslauncher.wishlist.*;public class Run {public static void main(String[] args) throws Exception {List<String> catalog=new ArrayList<>();for(int i=0;i<40;i++)catalog.add("MODE-"+i);catalog.add("PENDING-OLD");catalog.add("VERIFIED-EXTRA");System.out.println(WishlistNumberedSurveyDom.javascript(new URL("https://www.gu-global.com/jp/ja/products/E123456-001/01"),catalog));}}'''
}
with tempfile.TemporaryDirectory() as td:
 p=Path(td);files=[]
 for f,c in java_files.items():
  dst=p/f;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(c);files.append(str(dst))
 subprocess.run(['javac','-d',td,*files,str(src/'WishlistNumberedSurveyDom.java')],check=True)
 js=subprocess.check_output(['java','-cp',td,'Run'],text=True)
 assert "engine:'native-source'" in js and "no-portable-executor" in js
 script=p/'run.js'
 script.write_text('''const fs=require('fs');const vm=require('vm');const js=fs.readFileSync(process.argv[2],'utf8');const out=vm.runInNewContext(js,{location:{protocol:'https:',hostname:'www.gu-global.com',pathname:'/jp/ja/products/E123456-001/01'}});const rows=JSON.parse(out).results;if(rows.length!==42)throw new Error('Missing numbered stage: '+rows.length);if(new Set(rows.map(r=>r.id)).size!==42)throw new Error('Duplicated stage');if(rows[19].engine!=='native-source'||rows[19].status!=='AVAILABLE')throw new Error('Native engine not used');if(rows[40].status!=='UNKNOWN'||rows[40].reason!=='pending-three-field-proof')throw new Error('Pending auto profile ran');if(rows[41].status!=='UNKNOWN'||rows[41].reason!=='no-portable-executor')throw new Error('Unimplemented dynamic mode fabricated stock');console.log('PASS production numbered JS assembler, 42 unique IDs, native priority, unimplemented dynamic mode denied');''')
 jspath=p/'survey.js';jspath.write_text(js)
 subprocess.run(['node',str(script),str(jspath)],check=True)
