#!/usr/bin/env python3
"""v0.1.178 isolated official Temu/Ali routing + guard fixtures, no live claims."""
from pathlib import Path
import subprocess, tempfile, hashlib
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
page=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
probe=(src/'WishlistPriceWebViewProbe.java').read_text()
site=(src/'WishlistSiteBadge.java').read_text()
repo=(src/'WishlistRepository.java').read_text()
assert '"Temu"' in site and '"AliExpress"' in site
assert 'market.snapshot.commit' in page and 'singleWebView=true' in page
assert 'isAliResolvedShortItem(before.url, r.resolvedUrl, r.httpCode)' in page
assert 'marketplaceSavedItem = before.acquisitionMode == WishlistMode.GENERAL' in page
assert '|| aliShortlinkResolved' in page
assert 'stockModeName(before.url, before.acquisitionMode)' in page
assert 'actualJs=WishlistAliItemDom.javascript(originalRetailUrl);' in probe
assert 'actualJs=WishlistTemuItemDom.javascript(originalRetailUrl);' in probe
assert 'trace("temu.browser"' in probe
assert 'updateVerifiedOtherMarketplaceStock(id,before.url,sheinStock)' in page
assert 'updateVerifiedSheinStock(id,before.url,sheinStock)' in page
assert "acquisition_mode='GENERAL'" in repo
with tempfile.TemporaryDirectory() as d:
 p=Path(d)
 (p/'WishlistCrawler.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public final class WishlistCrawler {
 public static boolean isAllowedUrl(URL u){return u!=null && u.getHost()!=null;}
}
''')
 (p/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public final class Harness {
 static void check(boolean v,String label){if(!v)throw new AssertionError(label);}
 public static void main(String[] args)throws Exception{
  String temu="https://www.temu.com/jp/earbuds-g-607611151827013.html";
  String ali="https://a.aliexpress.com/_mA9Zx12";
  String resolved="https://ja.aliexpress.com/item/1005011682345346.html";
  check(WishlistMarketplaceDedicatedMode.fromSavedUrl(temu)==WishlistMarketplaceDedicatedMode.TEMU,"temu mode");
  check(WishlistMarketplaceDedicatedMode.fromSavedUrl(ali)==WishlistMarketplaceDedicatedMode.ALIEXPRESS,"ali short mode");
  check(WishlistMarketplaceDedicatedMode.fromSavedUrl(resolved)==WishlistMarketplaceDedicatedMode.ALIEXPRESS,"ali direct mode");
  check(WishlistMarketplaceDedicatedMode.fromSavedUrl("https://a.aliexpress.com/generic") == WishlistMarketplaceDedicatedMode.NONE,"no random short");
  check(WishlistMarketplaceDedicatedMode.fromSavedUrl("https://www.evil-temu.com/-g-607611151827013.html") == WishlistMarketplaceDedicatedMode.NONE,"no lookalike");
  check(WishlistMarketplaceDedicatedMode.fromSavedUrl("https://www.temu.com/jp/search") == WishlistMarketplaceDedicatedMode.NONE,"no category mode");
  check(WishlistMarketplaceDedicatedMode.isAliResolvedShortItem(ali,resolved,200),"trusted 200 ali alias");
  check(!WishlistMarketplaceDedicatedMode.isAliResolvedShortItem(ali,resolved,302),"not 200");
  check(!WishlistMarketplaceDedicatedMode.isAliResolvedShortItem(ali,"https://other.test/item/1005011682345346.html",200),"not foreign");
  check(!WishlistMarketplaceDedicatedMode.isAliResolvedShortItem(ali,"https://ja.aliexpress.com/item/1005011682345346.html@evil.test",200),"no lookalike");
  check(!WishlistMarketplaceDedicatedMode.isAliResolvedShortItem("http://a.aliexpress.com/_mA9Zx12",resolved,200),"no insecure short");
  check(!WishlistMarketplaceDedicatedMode.isAliResolvedShortItem(ali,"https://ja.aliexpress.com/",200),"no store front");
  check(!WishlistMarketplaceDedicatedMode.isAliResolvedShortItem(ali,"https://ja.aliexpress.com/item/1005011682345346.html?unsafe",404),"http must be 200");
  URL t=new URL(temu);URL fallback=WishlistGeneralMarketplaceIdentity.fallbackExactItemUrl(t);
  check(fallback!=null && fallback.getPath().equals("/-g-607611151827013.html"),"direct -g route");
  check(WishlistGeneralMarketplaceIdentity.sameItem(t,fallback),"same Temu item");
  check(WishlistGeneralMarketplaceIdentity.fallbackExactItemUrl(fallback)==null,"no looping retry");
  check(!WishlistGeneralMarketplaceIdentity.sameItem(t,new URL("https://www.temu.com/-g-607611151827014.html")),"reject other item");
  check(WishlistMarketplaceDedicatedMode.TEMU.liveLabel().equals("Temu専用モード"),"temu label");
  check(WishlistMarketplaceDedicatedMode.ALIEXPRESS.liveLabel().equals("AliExpress専用モード"),"ali label");
  System.out.println("Dedicated Temu/Ali URL identity: PASS (18 cases)");
 }
}
''')
 sources=[src/(n+'.java') for n in ('WishlistGeneralMarketplaceIdentity','WishlistMarketplaceDedicatedMode')]
 result=subprocess.run(['javac','-encoding','UTF-8','-d',d,str(p/'WishlistCrawler.java'),*map(str,sources),str(p/'Harness.java')],capture_output=True,text=True)
 assert result.returncode==0,result.stderr
 result=subprocess.run(['java','-cp',d,'com.cmyk.bookmarkslauncher.wishlist.Harness'],capture_output=True,text=True)
 assert result.returncode==0,result.stderr
 print(result.stdout.strip())
print('Dedicated pipeline static routing/writes: PASS')
