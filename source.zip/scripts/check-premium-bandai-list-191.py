#!/usr/bin/env python3
"""Test the actual standalone Java parser on synthetic shop-list fixtures.
No live-site/availability claims. Covers exact URL, card and status isolation.
"""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist/WishlistPremiumBandaiListingLookup.java'
price=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist/WishlistPriceWebViewProbe.java').read_text()
page=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
repo=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist/WishlistRepository.java').read_text()
assert 'WishlistPremiumBandaiListingLookup.lookup(bandaiTarget,nativeUserAgent)' in price
assert 'verifiedBandaiListing()' in price and 'savedBandaiItemUrl' in price
assert 'updateVerifiedBandaiListingTitle' in page and 'updateVerifiedBandaiListingStock' in page
assert 'user_title_edited=0' in repo and 'status=\'UNKNOWN\'' in repo
assert 'bandaiFromListing' in page and 'recoverMissingProductImage' in page
fixture=r'''
import java.net.URL;
import com.cmyk.bookmarkslauncher.wishlist.WishlistPremiumBandaiListingLookup;
class TestBandaiList191 {
 static final String ID="1000257064";
 static final URL URL_ITEM=url("https://p-bandai.jp/item/item-"+ID+"/");
 static URL url(String x){try{return new URL(x);}catch(Exception e){throw new RuntimeException(e);}}
 static void yes(boolean v,String m){if(!v)throw new AssertionError(m);}
 static void no(boolean v,String m){yes(!v,m);}
 static String card(String id,String title,String price,String icons){
  return "<div class=\"article_area\"><div class=\"article_photo_s\"><a href=\"/item/item-"+id+"/\"><img src=\"/images/"+id+".jpg\"></a></div>"+
  "<p class=\"article_title\"><a href=\"/item/item-"+id+"/\">"+title+"</a></p>"+
  "<p class=\"price\">"+price+"円</p>"+icons+"<!-- / article_area -->";
 }
 static String icon(String type){return "<img src=\"/bc/img/icon/"+type+".gif\">";}
 public static void main(String[] args){
  var p=WishlistPremiumBandaiListingLookup.parseListing(URL_ITEM,card(ID,"商品A&amp;B &#039;正規品&#039;","1,540",icon("ITEM_RESERVE")));
  yes(p!=null&&p.price==1540L&&p.itemId.equals(ID),"exact card price");
  yes(p.title.contains("A&B")&&p.title.contains("'正規品'"),"entities");
  yes(p.image.equals("https://p-bandai.jp/images/"+ID+".jpg"),"item card photo");
  yes("AVAILABLE".equals(p.status),"reserve icon");
  yes(WishlistPremiumBandaiListingLookup.parseListing(URL_ITEM,card("1000257065","other","999",icon("ITEM_RESERVE")))==null,"other ID");
  yes(WishlistPremiumBandaiListingLookup.parseListing(URL_ITEM,card(ID,"combined","999","<a href='/item/item-1000257065/'>other</a>"))==null,"mixed card IDs");
  var expired=WishlistPremiumBandaiListingLookup.parseListing(URL_ITEM,card(ID,"old","2,000",icon("ITEM_RESERVE_END")));
  yes("UNAVAILABLE".equals(expired.status),"reservation end");
  var sold=WishlistPremiumBandaiListingLookup.parseListing(URL_ITEM,card(ID,"old","2,000",icon("ITEM_OUT_OF_STOCK")));
  yes("UNAVAILABLE".equals(sold.status),"sold out");
  var uncertain=WishlistPremiumBandaiListingLookup.parseListing(URL_ITEM,card(ID,"lottery","2,000",icon("ITEM_LOT_SALES")));
  yes("UNKNOWN".equals(uncertain.status),"lottery not automatic purchase");
  var contrad=WishlistPremiumBandaiListingLookup.parseListing(URL_ITEM,card(ID,"mixed","2,000",icon("ITEM_RESERVE")+icon("ITEM_RESERVE_END")));
  yes("UNKNOWN".equals(contrad.status),"conflicting icons");
  var missing=WishlistPremiumBandaiListingLookup.parseListing(URL_ITEM,card(ID,"price missing","",icon("ITEM_RESERVE")));
  yes(missing.price==null,"no invented price");
  var duplicate=WishlistPremiumBandaiListingLookup.parseListing(URL_ITEM,
     card(ID,"same", "1,540",icon("ITEM_RESERVE"))+card(ID,"other", "2,000",icon("ITEM_RESERVE")));
  yes(duplicate==null,"duplicate conflict");
  yes(WishlistPremiumBandaiListingLookup.parseListing(URL_ITEM,"<html>access denied</html>")==null,"challenge unknown");
  yes(WishlistPremiumBandaiListingLookup.parseListing(url("https://p-bandai.jp/contents/abc/"),card(ID,"abc","1000",""))==null,"non-item URL");
  no(WishlistPremiumBandaiListingLookup.supports(url("http://p-bandai.jp/item/item-"+ID+"/")),"reject HTTP");
  no(WishlistPremiumBandaiListingLookup.supports(url("https://evil-p-bandai.jp/item/item-"+ID+"/")),"reject other host");
  System.out.println("Premium Bandai official list exact item fixtures: PASS (15 checks)");
 }
}'''
with tempfile.TemporaryDirectory() as temp:
 file=Path(temp)/'TestBandaiList191.java';file.write_text(fixture)
 subprocess.run(['javac','-d',temp,str(src),str(file)],check=True)
 subprocess.run(['java','-cp',temp,'TestBandaiList191'],check=True)
print('Premium Bandai official list wiring and identity preservation: PASS')
