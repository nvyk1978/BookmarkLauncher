#!/usr/bin/env python3
"""v0.1.192 regression: Threads metadata must not report screenshot-only success.

Runs real Java parser fixture, Java-generated script checks via v190 suite, and
captures the exact callback/fallback invariants without using a live account.
"""
from pathlib import Path
import subprocess
import tempfile
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'app/src/main/java/com/cmyk/bookmarkslauncher'
meta=(SRC/'ThreadsBookmarkMetadata.java').read_text()
capture=(SRC/'WebBookmarkCaptureManager.java').read_text()
price=(SRC/'wishlist/WishlistPriceWebViewProbe.java').read_text()
subprocess.run(['python',str(ROOT/'scripts/check-threads-bookmark-190.py')],check=True)
assert 'final String imageUrl;' in meta
assert 'safeImage(image, finalUrl)' in meta
assert 'postArticle' in meta and 'postText' in meta
assert 'if (isThreads) {' in capture and 'fetchThreadsPublicMetadataAsync(nodeId, originalUrl,' in capture
assert 'listener.onComplete(complete, repo.get(nodeId), complete ? null' in capture
assert 'verified = result != null && result.title != null' in capture
assert 'captureSession++' in capture and 'if (session != captureSession)' in capture
assert 'getContentLength()' in capture and '4_000_000' in capture
assert 'webView.setAlpha(1f)' in capture
assert 'showMarketplaceHumanVerification' in price and 'manualMerchantSite' in price
assert 'Merchant.ALIEXPRESS' in price and 'Merchant.TEMU' in price
with tempfile.TemporaryDirectory() as d:
 p=Path(d)
 (p/'android/text').mkdir(parents=True)
 (p/'org/json').mkdir(parents=True)
 (p/'android/text/Html.java').write_text('''package android.text;
public class Html {public static final int FROM_HTML_MODE_LEGACY=0;
public static CharSequence fromHtml(String s,int mode){return s.replace("&amp;","&");}}
''')
 (p/'org/json/JSONObject.java').write_text('''package org.json;
public class JSONObject {public JSONObject(String s){}public String optString(String k,String d){return d;}
public boolean optBoolean(String k,boolean d){return d;}}
''')
 (p/'org/json/JSONTokener.java').write_text('''package org.json;
public class JSONTokener{public JSONTokener(String s){}public Object nextValue(){return "{}";}}
''')
 (p/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher;
public class Harness{
 static void check(boolean ok,String s){if(!ok)throw new RuntimeException(s);}
 public static void main(String[] a){
  String post="https://www.threads.com/@tester/post/Abcd12345";
  String share="https://www.threads.com/share/AxvYmPab12";
  String good="<meta property='og:url' content='"+post+"'>"
    +"<meta property='og:description' content='A real public post about independent testing'>"
    +"<meta property='og:image' content='https://scontent-nrt1-1.cdninstagram.com/img.jpg'>";
  ThreadsBookmarkMetadata.Result r=ThreadsBookmarkMetadata.parseHtml(good,share);
  check(r!=null&&r.postUrl.equals(post),"canonical post required");
  check(r.imageUrl!=null&&r.imageUrl.contains("cdninstagram.com"),"official post preview");
  check(ThreadsBookmarkMetadata.parseHtml(good.replace("scontent-nrt1-1.cdninstagram.com","malicious.example"),share).imageUrl==null,"foreign preview must be rejected");
  check(ThreadsBookmarkMetadata.parseHtml("<meta property='og:url' content='"+post+"'><meta property='og:title' content='Log in to Threads • Instagram'>",share)==null,"login title must be rejected");
  check(ThreadsBookmarkMetadata.parseHtml("<meta property='og:title' content='A real post description'>",share)==null,"share without ID must be rejected");
  check(ThreadsBookmarkMetadata.parseHtml(good.replace("@tester/post/Abcd12345","@tester/post/Different"),post)==null,"redirected different post");
  System.out.println("PASS: Threads real metadata, no generic login, official image URL and exact permalink (6)");
 }
}
''')
 files=[p/'android/text/Html.java',p/'org/json/JSONObject.java',p/'org/json/JSONTokener.java',SRC/'ThreadsBookmarkMetadata.java',p/'Harness.java']
 subprocess.run(['javac','-encoding','UTF-8','-d',str(p),*map(str,files)],check=True)
 subprocess.run(['java','-cp',str(p),'com.cmyk.bookmarkslauncher.Harness'],check=True)
print('PASS: v192 bookmark capture lifecycle and Ali/Temu user-assisted retry wiring')
