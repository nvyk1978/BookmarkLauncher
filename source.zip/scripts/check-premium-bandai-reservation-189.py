#!/usr/bin/env python3
"""Offline Premium Bandai exact URL/stock predicate fixtures; no live stock claim."""
from pathlib import Path
import subprocess,tempfile,json
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
java=(src/'WishlistPremiumBandaiStockDom.java').read_text()
crawler=(src/'WishlistCrawler.java').read_text()
stock=(src/'WishlistAvailabilityWebViewProbe.java').read_text()
assert 'WishlistPremiumBandaiStockDom.supports(url)' in crawler
assert 'WishlistPremiumBandaiStockDom.supports(originalAlphabetUrl())' in stock
assert 'finishDedicated("AVAILABLE")' in stock
assert '予約する' in java
assert '予約する' in (src/'WishlistRawPurchaseDomAudit.java').read_text()
js=java.split('private static final String SCRIPT = """',1)[1].split('""";',1)[0]
js=js.replace('\\\\','\\').replace('__ITEM_PATH__',json.dumps('/item/item-1000250427'))
js_fixture=r'''
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const script=fs.readFileSync(process.argv[2],'utf8');
function run({path='/item/item-1000250427/',title='スーパー戦隊50周年記念 歴代ブルー ポーチ',price='販売価格：1,540円（税込）',
  action='予約する',disabled=false,negative='',pageExpired=false,nav=false,meta='' }={}) {
 const group={innerText:negative?('予約受付終了 '+action):action, textContent:negative?('予約受付終了 '+action):action};
 const heading={innerText:title,textContent:title,hidden:false,hasAttribute:()=>false,getAttribute:()=>null,
   closest:()=>null,parentElement:null};
 const button={tagName:'BUTTON',innerText:action,textContent:action,value:'',disabled,hidden:false,parentElement:group,
   hasAttribute:k=>k==='disabled'&&disabled,getAttribute:()=>null,
   closest:q=>q.includes('header,nav')?(nav?{}:null):group};
 group.parentElement=null;group.hidden=false;group.hasAttribute=()=>false;group.getAttribute=()=>null;
 const root={innerText:title+' '+price+' '+(pageExpired?'予約受付終了':'')+' '+action,textContent:title+' '+price+' '+(pageExpired?'予約受付終了':'')+' '+action,
   querySelectorAll:q=>q==='h1'?[heading]:q.includes('button,input')?[button]:[],contains:e=>e===group};
 const context={URL,location:{protocol:'https:',hostname:'p-bandai.jp',pathname:path},
   document:{querySelector:q=>q.startsWith('main,')?root:q==='meta[property="og:title"]'&&meta?{content:meta}:null},
   getComputedStyle:e=>({display:'block',visibility:'visible',opacity:'1'})};
 return JSON.parse(vm.runInNewContext(script,context,{timeout:2000}));
}
assert.equal(run().status,'AVAILABLE','working reserve is item-local proof');
assert.equal(run({path:'/item/item-1000250428/'}).status,'UNKNOWN','other product');
assert.equal(run({title:''}).status,'UNKNOWN','no product heading');
assert.equal(run({price:''}).status,'UNKNOWN','no product price');
assert.equal(run({disabled:true}).status,'UNKNOWN','disabled reserve');
assert.equal(run({negative:'予約受付終了'}).status,'UNKNOWN','expired item');
assert.equal(run({pageExpired:true}).status,'UNKNOWN','expired product label outside action panel');
assert.equal(run({nav:true}).status,'UNKNOWN','global reservation nav');
assert.equal(run({action:'カートを見る'}).status,'UNKNOWN','header cart is not reserve');
assert.equal(run({meta:'他の商品です'}).status,'UNKNOWN','contradicting metadata');
console.log('Premium Bandai exact-item reservation DOM: PASS (10 cases)');
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)
 (p/'test.cjs').write_text(js_fixture)
 (p/'script.js').write_text(js)
 subprocess.run(['node',str(p/'test.cjs'),str(p/'script.js')],check=True)
print('Premium Bandai URL, dedicated stock and diagnostics wiring: PASS')
