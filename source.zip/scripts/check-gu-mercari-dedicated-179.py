#!/usr/bin/env python3
"""Offline 0.1.179 staging guard for exact GU & Mercari; not a live website test."""
from pathlib import Path
import tempfile,subprocess,re
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
page=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
stock=(src/'WishlistAvailabilityWebViewProbe.java').read_text()
assert 'WishlistGeneralShopDedicatedMode.fromSavedUrl(url)' in page
assert 'WishlistGeneralShopDedicatedMode.forUrl(original)' in stock
assert 'WishlistGuVariantStockDom.javascript(original)' in stock
assert 'WishlistMercariItemStockDom.javascript(original)' in stock
assert stock.index('if (mode == WishlistMode.GENERAL && !pageInspectionStarted)') < stock.index('inspectGeneralShop(current);')
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp);pkg=d/'com/cmyk/bookmarkslauncher/wishlist';pkg.mkdir(parents=True)
 (pkg/'WishlistCrawler.java').write_text('package com.cmyk.bookmarkslauncher.wishlist; import java.net.URL; public final class WishlistCrawler {public static boolean isAllowedUrl(URL u){return u!=null&&u.getUserInfo()==null;}}')
 (pkg/'WishlistMode.java').write_text('package com.cmyk.bookmarkslauncher.wishlist; public enum WishlistMode {GENERAL;public String cardLabel(){return "";}}')
 j=d/'org/json/JSONObject.java';j.parent.mkdir(parents=True)
 j.write_text('package org.json; public final class JSONObject {public static String quote(String s){return "\\\""+s.replace("\\\\","\\\\\\\\").replace("\\\"","\\\\\\\"")+"\\\"";}}')
 (pkg/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL; public final class Harness {
static void test(boolean b){if(!b)throw new AssertionError("guard failed");}
public static void main(String[] a) throws Exception{
String gu="https://www.gu-global.com/jp/ja/products/E355777-000/00";
String me="https://jp.mercari.com/item/m25470772768";
test(WishlistGeneralShopDedicatedMode.fromSavedUrl(gu)==WishlistGeneralShopDedicatedMode.GU);
test(WishlistGeneralShopDedicatedMode.fromSavedUrl(me)==WishlistGeneralShopDedicatedMode.MERCARI);
test(WishlistGeneralShopDedicatedMode.fromSavedUrl("https://jp.mercari.com/search?keyword=foo")==WishlistGeneralShopDedicatedMode.NONE);
test(WishlistGeneralShopDedicatedMode.fromSavedUrl("https://www.gu-global.com/jp/ja/women")==WishlistGeneralShopDedicatedMode.NONE);
test(WishlistGeneralShopDedicatedMode.fromSavedUrl("https://gu-global.com.evil.com/jp/ja/products/E355777-000/00")==WishlistGeneralShopDedicatedMode.NONE);
test(WishlistGeneralShopDedicatedMode.fromSavedUrl("http://www.gu-global.com/jp/ja/products/E355777-000/00")==WishlistGeneralShopDedicatedMode.NONE);
test(WishlistGeneralShopDedicatedMode.GU.liveLabel().equals("GU専用モード"));
test(WishlistGeneralShopDedicatedMode.MERCARI.liveLabel().equals("メルカリ専用モード"));
test(WishlistSiteBadge.forSavedUrl(gu).equals("GU"));
test(WishlistSiteBadge.forSavedUrl(me).equals("メルカリ"));
test(WishlistSiteBadge.forSavedUrl("https://fakegu-global.com/x").isEmpty());
System.out.println("### GUJS");System.out.println(WishlistGuVariantStockDom.javascript(new URL(gu)));
System.out.println("### END");System.out.println("GU/Mercari route and badges: 11 fixtures PASS");
}}
''')
 args=['javac','-encoding','UTF-8','-d',str(d),str(pkg/'WishlistCrawler.java'),str(pkg/'WishlistMode.java'),str(j),*[str(src/x) for x in ('WishlistGeneralShopItem.java','WishlistGeneralShopDedicatedMode.java','WishlistSiteBadge.java','WishlistGuVariantStockDom.java')],str(pkg/'Harness.java')]
 c=subprocess.run(args,capture_output=True,text=True)
 assert c.returncode==0,c.stderr
 r=subprocess.run(['java','-cp',str(d),'com.cmyk.bookmarkslauncher.wishlist.Harness'],capture_output=True,text=True)
 assert r.returncode==0,r.stderr
 print(r.stdout.rsplit('### END',1)[-1].strip())
 script=r.stdout.split('### GUJS\n',1)[1].split('\n### END',1)[0]
 js=d/'gu.js';js.write_text(script)
 code=d/'gu-fixture.cjs'
 code.write_text(r'''const vm=require('vm'),assert=require('assert'),fs=require('fs');
const script=fs.readFileSync(process.argv[2],'utf8');new vm.Script(script);
const url='https://www.gu-global.com/jp/ja/products/E355777-000/00';
function el(text,attrs={}){return {tagName:'BUTTON',innerText:text,textContent:text,disabled:false,hidden:false,parentElement:null,
 getAttribute:k=>attrs[k]||null,closest:s=>null};}
function run(opts={}){
 const h1=el('Example product');const price=el('¥3,990');
 const color=el('01',{'data-testid':'select-color','aria-pressed':'true'});
 const size=el(opts.stock||'M 在庫あり',{'data-testid':'select-size','aria-pressed':'true'});
 size.closest=s=>s.includes('data-testid')?size:null;
 color.closest=s=>s.includes('data-testid')?color:null;
 const priceNodes=[price],buttons=[el('カートに入れる')];
 const root={querySelectorAll:s=>s==='h1'?[h1]:s.includes('data-testid*=price')?priceNodes:
 s==='button' ?buttons: s.includes('select,button')?(opts.selected===false?[]:[color,size]):[]};
 const doc={querySelector:s=>s==='link[rel=canonical]'?(opts.canonical?{href:opts.canonical}:null):root};
 const context={URL,document:doc,location:new URL(opts.url||url),getComputedStyle:()=>({display:'block',visibility:'visible'})};
 return JSON.parse(vm.runInNewContext(script,context,{timeout:1000}));
}
assert.strictEqual(run({selected:false}).status,'UNKNOWN');
assert.strictEqual(run({selected:false,stock:'在庫あり'}).status,'UNKNOWN');
assert.strictEqual(run({stock:'M 在庫あり'}).status,'AVAILABLE');
assert.strictEqual(run({stock:'M 在庫なし'}).status,'UNAVAILABLE');
assert.strictEqual(run({stock:'M あと少し'}).status,'UNKNOWN');
assert.strictEqual(run({url:'https://www.gu-global.com/jp/ja/sale'}).status,'UNKNOWN');
assert.strictEqual(run({canonical:'https://www.gu-global.com/jp/ja/products/E355778-000/00'}).status,'UNKNOWN');
console.log('GU selected-variant and wrong-item DOM: 7 fixtures PASS');
''')
 r=subprocess.run(['node',str(code),str(js)],capture_output=True,text=True)
 assert r.returncode==0,r.stderr
 print(r.stdout.strip())
print('Stock site-specific dispatch after isolated mode budget: PASS')
