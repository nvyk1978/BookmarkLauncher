#!/usr/bin/env python3
"""Run Java-exported isolated Temu/Ali DOM against public item metadata fixtures."""
from pathlib import Path
import subprocess,tempfile,base64
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
with tempfile.TemporaryDirectory() as td:
 d=Path(td)
 (d/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class Harness {
public static void main(String[] args)throws Exception{
 for(String arg:args) {
  URL url=new URL(arg);
  String script=WishlistGeneralMarketplaceIdentity.merchant(url)==WishlistGeneralMarketplaceIdentity.Merchant.TEMU
   ?WishlistTemuItemDom.javascript(url):WishlistAliItemDom.javascript(url);
  System.out.println(java.util.Base64.getEncoder().encodeToString(script.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
 }
}}
''')
 subprocess.run(['javac','-encoding','UTF-8','-d',str(d),*map(str,[src/'WishlistGeneralMarketplaceIdentity.java',src/'WishlistTemuItemDom.java',src/'WishlistAliItemDom.java',d/'Harness.java'])],check=True)
 urls=['https://www.temu.com/jp/product-g-603206260252304.html','https://ja.aliexpress.com/item/1005013255449296.html']
 texts=subprocess.run(['java','-cp',str(d),'com.cmyk.bookmarkslauncher.wishlist.Harness',*urls],text=True,capture_output=True,check=True).stdout.strip().splitlines()
 assert len(texts)==2
 for i,js in enumerate(texts):
  (d/(str(i)+'.js')).write_bytes(base64.b64decode(js))
  subprocess.run(['node','--check',str(d/(str(i)+'.js'))],check=True)
 (d/'test.cjs').write_text(r'''
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const urls=['https://www.temu.com/jp/product-g-603206260252304.html','https://ja.aliexpress.com/item/1005013255449296.html'];
const js=[0,1].map(i=>fs.readFileSync(process.argv[2+i],'utf8'));
const pic='https://cdn.example.com/real-product-image.jpg';
function run(i,{ogUrl=urls[i],name='Actual product title from public preview',image=pic,price='1600',currency='JPY',body='Genuine product',canonical=null}={}){
 const metas={'og:url':ogUrl,'og:title':name,'og:image':image,'product:price:amount':price,'product:price:currency':currency};
 const querySelector=q=>{
  if(q==='link[rel="canonical"]')return canonical?{href:canonical}:null;
  const match=q.match(/^meta\[property="([^"]+)"\]/);
  return match && metas[match[1]]?{getAttribute:()=>metas[match[1]]}:null;
 };
 const document={title:'Temu',readyState:'complete',URL:urls[i],
   body:{innerText:body,textContent:body,children:[]},querySelector,
   querySelectorAll:()=>[]};
 return JSON.parse(vm.runInNewContext(js[i],{location:{href:urls[i]},document,window:{},URL,Set},{timeout:3000}));
}
for(let i=0;i<2;i++){
 let r=run(i);
 assert.equal(r.title,'Actual product title from public preview',`name ${i}`);
 assert.equal(r.value,'¥1600',`JPY price ${i}`);
 assert.equal(r.stockStatus,'UNKNOWN',`no false stock ${i}`);
 assert.deepEqual(Array.from(r.imageCandidates),[pic],`image ${i}`);
 assert.equal(r.itemEvidence,'item-url-metadata',`metadata proof ${i}`);
 r=run(i,{ogUrl:urls[i].replace(i===0?'603206260252304':'1005013255449296',i===0?'603206260252305':'1005013255449297')});
 assert.equal(r.value,'',`foreign meta price ${i}`);assert.equal(r.title,'',`foreign meta title ${i}`);
 assert.equal(r.imageCandidates.length,0,`foreign meta image ${i}`);
 r=run(i,{ogUrl:''});assert.equal(r.value,'',`no item identity ${i}`);
 r=run(i,{currency:'USD'});assert.equal(r.value,'',`non JPY price ${i}`);
 r=run(i,{name:'Temu | Online Shopping'});assert.equal(r.title,'',`store banner ${i}`);
 r=run(i,{price:'1500.99'});assert.equal(r.value,'',`fraction yen ${i}`);
}
let challenge=run(0,{body:'Please verify you are human. Captcha required.'});
assert.equal(challenge.title,'');assert.equal(challenge.value,'');
console.log('PASS: Temu/Ali public OG proof, JPY-only price, field isolation, wrong-item and challenge rejection');
''')
 subprocess.run(['node',str(d/'test.cjs'),str(d/'0.js'),str(d/'1.js')],check=True)
print('PASS: Actual separated Java-exported Temu/Ali public metadata scripts')
