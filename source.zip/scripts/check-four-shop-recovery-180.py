#!/usr/bin/env python3
"""Four merchant-specific read-only recovery fixtures (no claim of live store access)."""
from pathlib import Path
import tempfile, subprocess, hashlib
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
p=(src/'WishlistPriceWebViewProbe.java').read_text()
a=(src/'WishlistAvailabilityWebViewProbe.java').read_text()
assert 'retryTemuNativeProfile(view,"unhydrated-item-document")' in p
assert 'retryTemuNativeProfile(view,"stable-unbound-or-challenge")' in p
assert 'view.getSettings().setUserAgentString(temuNativeUserAgent)' in p
assert 'WishlistGeneralMarketplaceIdentity.sameItem(originalRetailUrl,alternate)' in p
assert 'mountedMarketplace || mountedGu || mountedMercari' in p
assert 'parent.addView(web, 0' in a and '((ViewGroup) old.getParent()).removeView(old)' in a
assert 'WishlistGeneralShopDedicatedMode.forUrl(url)' in a
assert 'WishlistGuVariantStockDom.javascript(original)' in a
assert 'WishlistMercariItemStockDom.javascript(original)' in a
assert 'old.destroy();' in a
# 0.1.181 staging: Mercari's verified SOLD_OUT may not be discarded by
# the HIRAKI-only DB guard, and the probe must report persistence.
repo=(src/'WishlistRepository.java').read_text()
page=(src.parent/'WishlistPage.java').read_text()
assert 'HirakiStockEvidence.isHirakiProduct(original)' in repo
assert 'WishlistGeneralShopItem.Merchant.MERCARI' in repo
assert 'stock.mercari.commit' in page
assert 'reason=merchant-challenge-visible' in p
assert 'selectedColor=' in a and 'selectedSize=' in a
assert 'boundProducts=' in p
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp);j=d/'com/cmyk/bookmarkslauncher/wishlist';j.mkdir(parents=True)
 (j/'WishlistCrawler.java').write_text('package com.cmyk.bookmarkslauncher.wishlist; import java.net.URL; public final class WishlistCrawler {public static boolean isAllowedUrl(URL u){return u!=null&&u.getUserInfo()==null;}}')
 stub=d/'org/json/JSONObject.java';stub.parent.mkdir(parents=True)
 stub.write_text('package org.json; public final class JSONObject {public static String quote(String s){return "\\\""+s.replace("\\\\","\\\\\\\\").replace("\\\"","\\\\\\\"")+"\\\"";}}')
 (j/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public final class Harness {
 public static void main(String[] args)throws Exception {
  URL u=new URL(args[0]);switch(args[1]) {
   case "ali":System.out.print(WishlistAliItemDom.javascript(u));break;
   case "temu":System.out.print(WishlistTemuItemDom.javascript(u));break;
   case "mercari":System.out.print(WishlistMercariItemStockDom.javascript(u));break;
   case "gu":System.out.print(WishlistGuVariantStockDom.javascript(u));break;
  }
 }
}''')
 names=['WishlistGeneralMarketplaceIdentity','WishlistAliItemDom','WishlistTemuItemDom','WishlistGeneralShopItem','WishlistGuVariantStockDom','WishlistMercariItemStockDom']
 res=subprocess.run(['javac','-encoding','UTF-8','-d',str(d),str(j/'WishlistCrawler.java'),str(stub),*[str(src/(x+'.java')) for x in names],str(j/'Harness.java')],text=True,capture_output=True)
 assert res.returncode==0,res.stderr
 urls={'ali':'https://ja.aliexpress.com/item/1005008877665544.html',
       'temu':'https://www.temu.com/jp/goods-title-g-601099123456789.html',
       'gu':'https://www.gu-global.com/jp/ja/products/E355777-000/00',
       'mercari':'https://jp.mercari.com/item/m25470772768'}
 for site,url in urls.items():
  res=subprocess.run(['java','-cp',str(d),'com.cmyk.bookmarkslauncher.wishlist.Harness',url,site],text=True,capture_output=True)
  assert res.returncode==0,res.stderr
  (d/(site+'.js')).write_text(res.stdout)
 (d/'fixture.cjs').write_text(r'''const fs=require('fs'),vm=require('vm'),assert=require('assert');
const [ali,temu,gu,mercari]=process.argv.slice(2).map(p=>fs.readFileSync(p,'utf8'));
const aliUrl='https://ja.aliexpress.com/item/1005008877665544.html';
const meUrl='https://jp.mercari.com/item/m25470772768';
function basic(url,runParams){
 const doc={title:'Product detail',readyState:'complete',body:{innerText:'',textContent:''},
 querySelector:()=>null,querySelectorAll:()=>[]};
 const ctx={URL,location:{href:url},document:doc,window:{runParams}};
 return ctx;
}
function aliTest(params,url=aliUrl){return JSON.parse(vm.runInNewContext(ali,basic(url,params),{timeout:1000}));}
const data={actionModule:{productId:'1005008877665544'},titleModule:{subject:'Cordless Cleaning Tool'},
 priceModule:{formatedActivityPrice:'¥2,480'},currencyModule:{currencyCode:'JPY'},
 imageModule:{imagePathList:['https://cdn.example.com/listing.jpg']}};
let v=aliTest({data});
assert.equal(v.title,'Cordless Cleaning Tool');assert.equal(v.value,'¥2480');
assert.equal(v.imageCandidates.length,1);assert.equal(v.itemEvidence,'verified-product');
assert.equal(v.stockStatus,'UNKNOWN');assert.equal(v.aliAudit.runParamsItem,true);
v=aliTest({data:{...data,actionModule:{productId:'1005008877665545'}}});
assert.equal(v.value,'');assert.equal(v.title,'');assert.equal(v.aliAudit.runParamsItem,false);
v=aliTest({data:{...data,currencyModule:{currencyCode:'USD'},priceModule:{formatedActivityPrice:'2480'}}});
assert.equal(v.value,'');assert.equal(v.title,'Cordless Cleaning Tool');
v=aliTest({data:{...data,priceModule:{formatedActivityPrice:'¥2,480 - ¥3,580'}}});
assert.equal(v.value,'');
v=aliTest({data},'https://ja.aliexpress.com/category/0.html');assert.equal(v.value,'');
v=aliTest({});assert.equal(v.value,'');
function mercariTest(state,opts={}){
 const doc={querySelector:q=>q==='link[rel=canonical]'?(opts.canonical?{href:opts.canonical}:null):null,
 querySelectorAll:()=>[]};
 const ctx={URL,location:{href:opts.url||meUrl},document:doc,window:{__NEXT_DATA__:state}};
 return JSON.parse(vm.runInNewContext(mercari,ctx,{timeout:1000}));
}
const item={id:'m25470772768',name:'Vintage glass bottle',price:2380,status:'ON_SALE'};
v=mercariTest({props:{pageProps:{item}}});assert.equal(v.status,'AVAILABLE');
v=mercariTest({props:{pageProps:{item:{...item,status:'sold-out'}}}});assert.equal(v.status,'UNAVAILABLE');
v=mercariTest({props:{pageProps:{item:{...item,id:'m25470772769'}}}});assert.equal(v.status,'UNKNOWN');
v=mercariTest({props:{pageProps:{item}}},{canonical:'https://jp.mercari.com/item/m25470772769'});assert.equal(v.status,'UNKNOWN');
v=mercariTest({props:{pageProps:{item:{...item,price:null}}}});assert.equal(v.status,'UNKNOWN');
const guUrl='https://www.gu-global.com/jp/ja/products/E355777-000/00';
function el(txt,attr={}){return {tagName:'BUTTON',textContent:txt,innerText:txt,disabled:false,hidden:false,parentElement:null,
 className:attr.className||'',getAttribute:k=>attr[k]??null,closest:()=>null};}
function guTest(stock){const h=el('Cotton casual shirt'),pr=el('¥2,990');
 const color=el('01',{ 'data-testid':'select-color','data-state':'checked'}),
 size=el('M '+stock,{'data-testid':'select-size','data-state':'checked'});
 const main={querySelectorAll:q=>q==='h1'?[h]:q.includes('data-testid*=price')?[pr]:q==='button'?[el('カートに入れる')]:q.includes('select,button')?[color,size]:[]};
 const doc={querySelector:()=>main};
 return JSON.parse(vm.runInNewContext(gu,{URL,location:{href:guUrl},document:doc,
 getComputedStyle:()=>({display:'block',visibility:'visible'})},{timeout:1000}));}
v=guTest('在庫あり');assert.equal(v.status,'AVAILABLE');
v=guTest('在庫なし');assert.equal(v.status,'UNAVAILABLE');
v=guTest('選んでください');assert.equal(v.status,'UNKNOWN');
const td={title:'Temu product',body:{innerText:'',textContent:'',children:[]},readyState:'complete',URL:'https://www.temu.com/jp/goods-title-g-601099123456789.html',querySelector:()=>null,querySelectorAll:()=>[]};
const tc={URL,location:{href:td.URL},document:td,window:{},Set};
v=JSON.parse(vm.runInNewContext(temu,tc,{timeout:1000}));assert.equal(v.value,'');assert.equal(v.stockStatus,'UNKNOWN');
const challengedBody='Security check: Verify you are human before continuing';
const challenged={...td,body:{...td.body,innerText:challengedBody,textContent:challengedBody}};
const cv=JSON.parse(vm.runInNewContext(temu,{...tc,document:challenged},{timeout:1000}));
assert.equal(cv.reason,'challenge-visible');
assert.equal(cv.verifiedReason,'challenge-visible');
assert.equal(cv.value,'');
console.log('4-shop dedicated recovery: PASS (Ali 6, Mercari 5, GU 3, Temu 2; Java-exported JS)');''')
 paths=[str(d/(x+'.js')) for x in ['ali','temu','gu','mercari']]
 res=subprocess.run(['node',str(d/'fixture.cjs'),*paths],capture_output=True,text=True)
 assert res.returncode==0,res.stdout+'\n'+res.stderr
 print(res.stdout.strip())
print('4-shop WebView routing/teardown checks: PASS')
