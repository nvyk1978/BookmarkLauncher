#!/usr/bin/env bash
set -euo pipefail

JAVA_FILE="app/src/main/java/com/cmyk/bookmarkslauncher/MainActivity.java"
GRADLE_FILE="app/build.gradle"
PROPS_FILE="gradle.properties"
KEYSTORE_FILE="keystore/bookmarks-launcher.jks"
EXPECTED_KEYSTORE_SHA256="c15c0dcfdadba605edaab3f8ee4e732ad913a021d1100febb6894dd6e918f62a"
MIN_VERSION_CODE=63

# Google Code Scanner invariant:
# Maven coordinate: com.google.android.gms:play-services-code-scanner
# Java API package:  com.google.mlkit.vision.codescanner
# Repair the recurring wrong namespace before javac sees it.
sed -i 's/com\.google\.android\.gms\.mlkit\.vision\.codescanner/com.google.mlkit.vision.codescanner/g' "$JAVA_FILE"

# AndroidX is mandatory for this dependency set.
if grep -q '^android.useAndroidX=' "$PROPS_FILE"; then
  sed -i 's/^android.useAndroidX=.*/android.useAndroidX=true/' "$PROPS_FILE"
else
  printf '\nandroid.useAndroidX=true\n' >> "$PROPS_FILE"
fi

# Fixed app identity / signing invariants.
grep -Fq "namespace 'com.cmyk.bookmarkslauncher'" "$GRADLE_FILE"
grep -Fq "applicationId 'com.cmyk.bookmarkslauncher'" "$GRADLE_FILE"
grep -Fq "storeFile file('../keystore/bookmarks-launcher.jks')" "$GRADLE_FILE"
grep -Fq "keyAlias 'bookmarks'" "$GRADLE_FILE"
grep -Fq 'signingConfig signingConfigs.stable' "$GRADLE_FILE"
echo "${EXPECTED_KEYSTORE_SHA256}  ${KEYSTORE_FILE}" | sha256sum -c -

# Never allow this source line to roll back below the currently installed app.
VERSION_CODE=$(sed -nE 's/^[[:space:]]*versionCode[[:space:]]+([0-9]+).*/\1/p' "$GRADLE_FILE" | head -n1)
test -n "$VERSION_CODE"
if [ "$VERSION_CODE" -lt "$MIN_VERSION_CODE" ]; then
  echo "ERROR: versionCode ${VERSION_CODE} is below required minimum ${MIN_VERSION_CODE}." >&2
  exit 1
fi

# Dependency/import pair must stay exactly compatible.
grep -q '^android.useAndroidX=true$' "$PROPS_FILE"
grep -Fq "implementation 'com.google.android.gms:play-services-code-scanner:16.1.0'" "$GRADLE_FILE"

if grep -q 'com\.google\.android\.gms\.mlkit\.vision\.codescanner' "$JAVA_FILE"; then
  echo 'ERROR: invalid Google Code Scanner Java package remains.' >&2
  exit 1
fi

for cls in GmsBarcodeScanner GmsBarcodeScannerOptions GmsBarcodeScanning; do
  grep -Fqx "import com.google.mlkit.vision.codescanner.${cls};" "$JAVA_FILE" || {
    echo "ERROR: missing Code Scanner import: ${cls}" >&2
    exit 1
  }
done

echo "BookmarkLauncher build invariants: OK (versionCode=${VERSION_CODE})"
