#!/usr/bin/env python3
"""v0.1.186 targeted merchant recovery, identity and save guards.

Offline fixtures, not a live Temu/AliExpress access test or Android APK build.
"""
from pathlib import Path
import subprocess, tempfile

ROOT=Path(__file__).resolve().parent.parent
SRC=ROOT/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
identity=(SRC/'WishlistGeneralMarketplaceIdentity.java').read_text()
price=(SRC/'WishlistPriceWebViewProbe.java').read_text()
ali=(SRC/'WishlistAliItemDom.java').read_text()
repo=(SRC/'WishlistRepository.java').read_text()
page=(ROOT/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
assert 'https://www.temu.com/goods.html?goods_id=' in identity
assert 'https://www.temu.com/-g-' not in identity
assert 'guardedAliJapaneseLocale(url)' in price
assert 'CookieManager.getInstance().setCookie' in price
assert 'c_tp=JPY&region=JP&b_locale=ja_JP' in price
assert 'loadOnce.compareAndSet(false,true)' in price
assert 'offerCurrency=' in price
assert 'out.aliAudit.unlinkedCurrency' in ali
assert '&& generalProduct' in price[price.index('private boolean guardedAliJapaneseLocale'):price.index('private boolean allowedDestination')]
assert 'repo.recordMarketplaceChallenge(id,before.url)' in page
assert "acquisition_mode='GENERAL'" in repo[repo.index('public boolean recordMarketplaceChallenge'):repo.index('public void recordSiteReachableFromWebView')]
assert 'WishlistSiteState.ACCESS_RESTRICTED' in repo[repo.index('public boolean recordMarketplaceChallenge'):repo.index('public void recordSiteReachableFromWebView')]
crawler=(SRC/'WishlistCrawler.java').read_text()
assert 'if ("challenge-page".equals(verdict.reason))' in crawler
assert 'out.siteState = WishlistSiteState.ACCESS_RESTRICTED;' in crawler
assert 'Temuの確認画面で商品情報を取得できず' in page
assert 'AliExpressの確認画面で商品情報を取得できず' in page
with tempfile.TemporaryDirectory() as td:
    path=Path(td)
    (path/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public final class Harness {
 public static void main(String[] args)throws Exception{
  for (String raw:args){
    URL u=new URL(raw),v=WishlistGeneralMarketplaceIdentity.fallbackExactItemUrl(u);
    String id=WishlistGeneralMarketplaceIdentity.itemId(u);
    if(v!=null&&(!WishlistGeneralMarketplaceIdentity.sameItem(u,v)||!id.equals(WishlistGeneralMarketplaceIdentity.itemId(v))))
      throw new AssertionError("SKU changed on fallback: "+raw);
    if (raw.contains("temu.com/jp/") && (v==null||!v.getPath().equals("/goods.html")||!v.getQuery().equals("goods_id="+id)))
      throw new AssertionError("Missing official Temu goods route: "+raw);
    if (raw.contains("aliexpress.com/item/") && raw.contains("ja.") && (v==null||!v.getHost().equals("www.aliexpress.com")))
      throw new AssertionError("Missing global Ali fallback: "+raw);
  }
  System.out.println("Merchant official identity fallback: PASS (5)");
 }
}''')
    urls=[
      'https://www.temu.com/jp/goods.html?goods_id=603206260252304',
      'https://www.temu.com/jp/something-g-603206260252304.html',
      'https://www.temu.com/goods.html?goods_id=603206260252304',
      'https://ja.aliexpress.com/item/1005011682345346.html',
      'https://www.aliexpress.com/item/1005011682345346.html',
    ]
    subprocess.run(['javac','-encoding','UTF-8','-d',str(path),str(SRC/'WishlistGeneralMarketplaceIdentity.java'),str(path/'Harness.java')],check=True)
    subprocess.run(['java','-cp',str(path),'com.cmyk.bookmarkslauncher.wishlist.Harness',*urls],check=True)
print('JP currency-before-navigation, cookie-once, page-state/price protection: PASS (13)')
