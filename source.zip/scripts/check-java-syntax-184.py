#!/usr/bin/env python3
"""Use the real Java 17 compiler parser without Android SDK symbol resolution."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
src=list((root/'app/src/main/java').rglob('*.java'))
harness='''import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.util.*;
public class Parse184 {
 public static void main(String[] args) throws Exception {
  JavaCompiler c=ToolProvider.getSystemJavaCompiler();
  DiagnosticCollector<JavaFileObject> log=new DiagnosticCollector<>();
  StandardJavaFileManager fm=c.getStandardFileManager(log,null,null);
  JavacTask t=(JavacTask)c.getTask(null,fm,log,List.of("-proc:none"),null,
    fm.getJavaFileObjectsFromStrings(Arrays.asList(args)));
  t.parse();
  for(Diagnostic<? extends JavaFileObject> d:log.getDiagnostics())
   if(d.getKind()==Diagnostic.Kind.ERROR)throw new RuntimeException(d.toString());
  System.out.println("PASS Java syntax: "+args.length+" sources");
 }
}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'Parse184.java';p.write_text(harness)
 subprocess.run(['javac','-d',d,str(p)],check=True)
 subprocess.run(['java','-cp',d,'Parse184',*map(str,src)],check=True)
