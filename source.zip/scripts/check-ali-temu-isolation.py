#!/usr/bin/env python3
"""Actual Java-exported AliExpress / Temu DOM parsers: offline identity/proof fixtures.
No claim about a live marketplace response, Java/Android APK build or availability.
"""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
java=(src/'WishlistGeneralMarketplaceIdentity.java').read_text()
price=(src/'WishlistPriceWebViewProbe.java').read_text()
page=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
repo=(src/'WishlistRepository.java').read_text()
checks={
 'Temu explicit site route and ID verification': 'Merchant.TEMU' in price and 'WishlistTemuItemDom.javascript(originalRetailUrl)' in price,
 'Ali standalone merchant DOM': 'WishlistAliItemDom.javascript(originalRetailUrl)' in price,
 'SHEIN original adapter preserved': 'WishlistSheinItemDom.javascript(originalRetailUrl)' in price,
 'All three use saved item URL': 'final String pageUrl = marketplaceSavedItem' in page and '.preservedProbeUrl(before.url, r.resolvedUrl)' in page,
 'Ali/Temu strict stock commit': 'updateVerifiedOtherMarketplaceStock' in repo and 'repo.updateVerifiedOtherMarketplaceStock(id,before.url,sheinStock)' in page,
 'SHEIN original stock route': 'repo.updateVerifiedSheinStock(id,before.url,sheinStock)' in page,
 'No global cart positive': 'item-bound-jsonld' in (src/'WishlistTemuItemDom.java').read_text() and 'item-bound-jsonld' in (src/'WishlistAliItemDom.java').read_text(),
}
for what, ok in checks.items():
    assert ok,what
with tempfile.TemporaryDirectory() as d:
 t=Path(d)
 (t/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class Harness {
 public static void main(String[] args) throws Exception{
  URL u=new URL(args[0]);
  String js=WishlistGeneralMarketplaceIdentity.merchant(u)==WishlistGeneralMarketplaceIdentity.Merchant.TEMU
    ?WishlistTemuItemDom.javascript(u):WishlistAliItemDom.javascript(u);
  System.out.print(js);
 }
}
''')
 files=[src/(n+'.java') for n in ['WishlistGeneralMarketplaceIdentity','WishlistTemuItemDom','WishlistAliItemDom']]
 subprocess.run(['javac','-encoding','UTF-8','-d',str(t),*map(str,files),str(t/'Harness.java')],check=True)
 urls=['https://www.temu.com/jp/product-title-g-601099123456789.html','https://ja.aliexpress.com/item/1005008877665544.html',
       'https://www.temu.com/jp/goods.html?goods_id=601099123456789','https://www.aliexpress.com/p/item/1005008877665544.html']
 for i,url in enumerate(urls):
  result=subprocess.run(['java','-cp',str(t),'com.cmyk.bookmarkslauncher.wishlist.Harness',url],check=True,text=True,capture_output=True)
  (t/(str(i)+'.js')).write_text(result.stdout)
 test=r'''
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const urls=['https://www.temu.com/jp/product-title-g-601099123456789.html','https://ja.aliexpress.com/item/1005008877665544.html',
 'https://www.temu.com/jp/goods.html?goods_id=601099123456789','https://www.aliexpress.com/p/item/1005008877665544.html'];
const jss=[0,1,2,3].map(i=>fs.readFileSync(process.argv[2+i],'utf8'));
function run(i,{url=urls[i],canonical=null,products=[],heading=null,localPrice=null,extra=null}={}){
 let main;
 const price= {textContent:localPrice||'',innerText:localPrice||'',getAttribute:()=>null,closest:()=>null};
 main={contains:()=>true,querySelectorAll:q=>q.includes('price')||q.includes('Price')?[...(localPrice?[price]:[]),...(extra?[extra]:[])]:[]};
 const h=heading?{textContent:heading,closest:q=>q.includes('main')?main:null}:null;
 const d={title:'Sample Product',readyState:'complete',body:{innerText:'Sample document',textContent:'Sample document'},
   querySelector:q=>q==='link[rel="canonical"]'&&canonical?{href:canonical}:q==='main,[role="main"]'?main:null,
   querySelectorAll:q=>q==='script[type="application/ld+json"]'?products.map(p=>({textContent:JSON.stringify(p)})):
     q.includes('h1')?(h?[h]:[]):[]};
 const context={location:{href:url},document:d,URL,Set};
 return JSON.parse(vm.runInNewContext(jss[i],context,{timeout:2500}));
}
for(const i of [0,1,2,3]){
 const img='https://cdn.example.com/product/specific.jpg';
 const product={'@type':'Product',url:urls[i],name:'Verified Brand Headphones',image:[img],offers:{price:'1278',priceCurrency:'JPY',availability:'https://schema.org/InStock'}};
 let v=run(i,{products:[product]});
 assert.equal(v.title,product.name,`title ${i}`);
 assert.equal(v.value,'¥1278',`price ${i}`);
 assert.equal(v.stockStatus,'AVAILABLE',`stock ${i}`);
 assert.equal(v.imageCandidates.length,1,`image ${i}`);
 assert.equal(v.itemEvidence,'verified-product');
 v=run(i,{products:[{...product,offers:{price:1278,priceCurrency:'USD',availability:'https://schema.org/OutOfStock'}}]});
 assert.equal(v.value,'',`USD must not be JPY ${i}`);
 assert.equal(v.stockStatus,'UNAVAILABLE');
 v=run(i,{products:[{...product,url:urls[i].replace(i%2===0?'601099123456789':'1005008877665544',i%2===0?'601099123456788':'1005008877665543')}]});
 assert.equal(v.value,'',`other Product denied ${i}`);
 assert.equal(v.stockStatus,'UNKNOWN');
 v=run(i,{url:urls[i].replace(i%2===0?'601099123456789':'1005008877665544',i%2===0?'601099123456788':'1005008877665543'),products:[product]});
 assert.equal(v.value,'',`different navigation denied ${i}`);
 assert.equal(v.reason,'navigation-other-item');
 v=run(i,{canonical:urls[i].replace(i%2===0?'601099123456789':'1005008877665544',i%2===0?'601099123456788':'1005008877665543'),products:[product]});
 assert.equal(v.value,'',`different canonical denied ${i}`);
 assert.equal(v.reason,'canonical-other-item');
 v=run(i,{heading:'Verified Brand Headphones',localPrice:'¥699'});
 assert.equal(v.value,'¥699',`rendered item-local price ${i}`);
 assert.equal(v.stockStatus,'UNKNOWN',`DOM price NOT stock ${i}`);
 v=run(i,{heading:'Verified Brand Headphones',localPrice:'¥699',extra:{textContent:'¥701',getAttribute:()=>null,closest:()=>null}});
 assert.equal(v.value,'',`contradictory prices denied ${i}`);
 v=run(i,{url: i%2===0?'https://www.temu.com/jp/':'https://ja.aliexpress.com/',heading:'Verified Brand Headphones',localPrice:'¥699'});
 assert.equal(v.value,'',`home page not item ${i}`);
}
console.log('Temu/Ali product snapshots: PASS (32 identity/pricing/stock scenarios, actual Java-exported JS)');
'''
 (t/'test.cjs').write_text(test)
 subprocess.run(['node',str(t/'test.cjs'),*[str(t/(str(i)+'.js')) for i in range(4)]],check=True)
print('Temu/Ali code-path isolation: PASS (7)')
