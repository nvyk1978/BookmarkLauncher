#!/usr/bin/env python3
"""Execute Java-produced Temu page JS against privacy-safe DOM stubs.
Checks diagnostic classifications, not real Temu loading or merchant access.
"""
from pathlib import Path
import tempfile, subprocess
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
with tempfile.TemporaryDirectory() as d:
    t=Path(d)
    h=t/'TemuDiagnosticHarness.java'
    h.write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class TemuDiagnosticHarness {
 public static void main(String[] a) throws Exception {
  System.out.print(WishlistTemuItemDom.javascript(new URL("https://www.temu.com/jp/headphones-g-607611151827013.html")));
 }
}
''')
    subprocess.run(['javac','-encoding','UTF-8','-d',d,str(src/'WishlistGeneralMarketplaceIdentity.java'),
        str(src/'WishlistTemuItemDom.java'),str(h)],check=True)
    js=subprocess.check_output(['java','-cp',d,'com.cmyk.bookmarkslauncher.wishlist.TemuDiagnosticHarness'],text=True)
    (t/'temu.js').write_text(js)
    (t/'run.cjs').write_text(r'''
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const js=fs.readFileSync(process.argv[2],'utf8');
const item='https://www.temu.com/jp/headphones-g-607611151827013.html';
function inspect({href=item,docUrl=href,title='Temu Product',text='Add to cart',next=false}={}){
 const script={textContent:'',getAttribute:()=>null};
 const body={innerText:text,textContent:text,children:[1,2]};
 const doc={URL:docUrl,title,body,readyState:'complete',
  querySelector(q){if(q.includes('canonical'))return null;if(q.includes('#app')||q.includes('#root'))return {id:'root'};return null;},
  querySelectorAll(q){
   if(q==='script')return [script,script];
   if(q==='script[type="application/ld+json"]')return [];
   if(q==='button')return [1];
   if(q==='h1')return [];
   if(q==='iframe')return [];
   return [];
  }};
 const context={location:{href},document:doc,URL,Set,window:{__INITIAL_STATE__:next?{}:null}};
 return JSON.parse(vm.runInNewContext(js,context,{timeout:2000}));
}
let a=inspect();
assert.equal(a.temuAudit.href,'same');
assert.equal(a.temuAudit.docUrl,'same');
assert.equal(a.temuAudit.docUrlDiff,false);
assert.equal(a.temuAudit.bodyChars,11);
assert.equal(a.temuAudit.scripts,2);
assert.equal(a.temuAudit.buttons,1);
assert.equal(a.temuAudit.globalState,false);
assert.equal(a.temuAudit.bodyKind,'purchase');
assert.equal(a.temuAudit.appRoot,true);
assert.equal(a.temuAudit.stateRecords,0);
a=inspect({href:'https://www.temu.com/jp/',docUrl:'https://www.temu.com/jp/',text:'Download app'});
assert.equal(a.temuAudit.href,'unbound');
assert.equal(a.temuAudit.bodyKind,'app-gate');
assert.equal(a.value,'');
a=inspect({href:'https://www.temu.com/jp/',docUrl:item,text:'Sign in',next:true});
assert.equal(a.temuAudit.href,'unbound');
assert.equal(a.temuAudit.docUrl,'same');
assert.equal(a.temuAudit.docUrlDiff,true);
assert.equal(a.temuAudit.globalState,true);
assert.equal(a.temuAudit.bodyKind,'login-hint');
a=inspect({href:item,docUrl:item,title:'Security verification',text:'Verify you are human'});
assert.equal(a.temuAudit.titleKind,'challenge');
assert.equal(a.reason,'challenge-visible');
assert.equal(a.value,'');
assert.equal(a.temuAudit.inlineItemId,false);
const data=JSON.stringify(a);
assert(!data.includes('Security verification') && !data.includes('Verify you are human'));
console.log('Temu Java-exported audit JS: PASS (4 DOM states, privacy categories, identity)');
''')
    subprocess.run(['node',str(t/'run.cjs'),str(t/'temu.js')],check=True)
print('Temu Java wrapper: PASS')
