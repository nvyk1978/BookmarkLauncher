#!/usr/bin/env python3
"""Compile shipped exact-item Java methods, execute generated JS in isolated Node fixtures.
    Does not claim live merchant access, includes negative and cross-product cases."""
from pathlib import Path
import subprocess, tempfile, textwrap, re
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
with tempfile.TemporaryDirectory(prefix='bl-exact177-') as dirname:
    temp=Path(dirname)
    package=temp/'com/cmyk/bookmarkslauncher/wishlist'
    package.mkdir(parents=True)
    (package/'WishlistCrawler.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL; public final class WishlistCrawler {
 static boolean isAllowedUrl(URL u){return u!=null&&u.getHost()!=null;}}
''')
    j=temp/'org/json/JSONObject.java';j.parent.mkdir(parents=True)
    j.write_text('''package org.json; public final class JSONObject {
 public static String quote(String s){return "\\\""+s.replace("\\\\","\\\\\\\\").replace("\\\"","\\\\\\\"")+"\\\"";}}
''')
    (package/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public final class Harness {
 static void test(boolean condition){if(!condition)throw new AssertionError("identity assertion");}
 public static void main(String[] args)throws Exception {
   URL ali=new URL("https://ja.aliexpress.com/item/1005011682345346.html");
   URL aliFallback=WishlistGeneralMarketplaceIdentity.fallbackExactItemUrl(ali);
   test(aliFallback!=null && "www.aliexpress.com".equals(aliFallback.getHost())
      && WishlistGeneralMarketplaceIdentity.sameItem(ali,aliFallback));
   test(!WishlistGeneralMarketplaceIdentity.sameItem(ali,
     new URL("https://www.aliexpress.com/item/1005011682345347.html")));
   URL temu=new URL("https://www.temu.com/jp/ceramic-g-607611151827013.html");
   URL temuFallback=WishlistGeneralMarketplaceIdentity.fallbackExactItemUrl(temu);
   test(temuFallback!=null && "/-g-607611151827013.html".equals(temuFallback.getPath())
      && WishlistGeneralMarketplaceIdentity.sameItem(temu,temuFallback));
   test(WishlistGeneralMarketplaceIdentity.fallbackExactItemUrl(temuFallback)==null);
   URL shein=new URL("https://m.shein.com/jp/earbud-p-571445705.html");
   test(WishlistGeneralMarketplaceIdentity.fallbackExactItemUrl(shein)==null);
   URL listing=new URL("https://jp.mercari.com/item/m25470772768");
   test(WishlistGeneralShopItem.isDetail(listing));
   System.out.println("EXACT-JS-START");
   System.out.println(WishlistMercariItemStockDom.javascript(listing));
   System.out.println("EXACT-JS-END");
   System.out.println("EXACT-ID-PASS");
 }
}
''')
    subprocess.run(['javac','-encoding','UTF-8','-d',str(temp),
        str(package/'WishlistCrawler.java'),str(j),str(src/'WishlistGeneralMarketplaceIdentity.java'),
        str(src/'WishlistGeneralShopItem.java'),str(src/'WishlistMercariItemStockDom.java'),
        str(package/'Harness.java')],check=True)
    output=subprocess.run(['java','-cp',str(temp),
        'com.cmyk.bookmarkslauncher.wishlist.Harness'],check=True,capture_output=True,text=True).stdout
    assert 'EXACT-ID-PASS' in output
    match=re.search(r'EXACT-JS-START\n(.*?)\nEXACT-JS-END',output,flags=re.S)
    assert match, 'Java-generated Mercari script missing'
    js=temp/'proof.js';js.write_text(match.group(1))
    node=temp/'test.cjs'
    node.write_text(r'''const vm=require('vm'),fs=require('fs'),assert=require('assert');
const javaJs=fs.readFileSync(process.argv[2],'utf8');
new vm.Script(javaJs);
const id='m25470772768',url='https://jp.mercari.com/item/'+id;
function run(state,opts={}) {
 const data=JSON.stringify(state);
 const document={querySelector:q=>q==='link[rel=canonical]'?
  (opts.canon?{href:opts.canon}:null):q.startsWith('script#__NEXT_DATA__')?
   {textContent:data}:null,querySelectorAll:()=>opts.jsonLd?[{textContent:JSON.stringify(opts.jsonLd)}]:[]};
 const result=vm.runInNewContext(javaJs,{URL,document,window:{},location:new URL(opts.url||url)}, {timeout:1500});
 return JSON.parse(result);
}
function item(status='on_sale'){return {props:{pageProps:{item:{id,name:'Example reusable product',price:3000,status}}}};}
assert.strictEqual(run(item()).status,'AVAILABLE');
assert.strictEqual(run(item('sold_out')).status,'UNAVAILABLE');
assert.strictEqual(run(item('trading')).status,'UNKNOWN');
assert.strictEqual(run({props:{pageProps:{recommendations:[{id,name:'Wrong rec',price:999,status:'on_sale'}]}}}).status,'UNKNOWN');
assert.strictEqual(run({props:{pageProps:{item:{id:'m99999999999',name:'Unrelated',price:1200,status:'on_sale'}}}}).status,'UNKNOWN');
assert.strictEqual(run({props:{pageProps:{item:{id,name:'Missing price',status:'sold_out'}}}}).status,'UNKNOWN');
assert.strictEqual(run(item(),{url:'https://jp.mercari.com/search'}).status,'UNKNOWN');
assert.strictEqual(run(item(),{canon:'https://jp.mercari.com/item/m99999999999'}).status,'UNKNOWN');
assert.strictEqual(run({props:{pageProps:{item:{id,name:'Full Name',price:3000,status:'on_sale'},itemInfo:{id,name:'Full Name',price:3000,status:'sold_out'}}}}).status,'UNKNOWN');
const ld=(itemId=id,availability='https://schema.org/InStock')=>({
 '@type':'Product',url:'https://jp.mercari.com/item/'+itemId,name:'Exact Item',
 offers:{'@type':'Offer',price:3000,availability}
});
assert.strictEqual(run({}, {jsonLd:ld()}).status,'AVAILABLE');
assert.strictEqual(run({}, {jsonLd:ld(id,'https://schema.org/SoldOut')}).status,'UNAVAILABLE');
assert.strictEqual(run({}, {jsonLd:ld('m99999999999')}).status,'UNKNOWN');
assert.strictEqual(run({}, {jsonLd:{...ld(),offers:{availability:'https://schema.org/SoldOut'}}}).status,'UNKNOWN');
assert.strictEqual(run(item('on_sale'), {jsonLd:ld(id,'https://schema.org/SoldOut')}).status,'UNKNOWN');
console.log('Mercari embedded and JSON-LD exact-listing proof: 14 fixtures PASS');
''')
    subprocess.run(['node',str(node),str(js)],check=True)
    print('Official merchant alternative URL identity: PASS')
