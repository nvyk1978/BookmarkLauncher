#!/usr/bin/env python3
"""Compile deployed marketplace dispatch into Java and run its generated JS.
Excludes Android framework: confirms script selection + Ali fallback integration.
"""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parent.parent
s=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
full=(s/'WishlistPriceWebViewProbe.java').read_text()
a=full.index('actualJs = "(function(){try{var a=JSON.parse(')
b=full.index(';\n        }\n        else if (unknownGeneralDetail',a)+1
part=full[a:b]
# Reconstruct the opening guardedHydration block; its brace closes in part.
with tempfile.TemporaryDirectory() as td:
 t=Path(td)
 (t/'DispatchHarness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class DispatchHarness{
 public static void main(String[] args) throws Exception{
  URL originalRetailUrl=new URL(args[0]);
  String actualJs="";
  boolean guardedHydration=true;
  if(guardedHydration){
'''+part+'''
  }
  System.out.print(actualJs);
 }
}
''')
 java=[s/(n+'.java') for n in ['WishlistGeneralMarketplaceIdentity','WishlistGeneralMarketplaceHydrationDom','WishlistGeneralMarketplaceVerifiedDom','WishlistGeneralMarketplaceImageDom','WishlistSheinItemDom','WishlistTemuItemDom','WishlistAliItemDom']]
 c=subprocess.run(['javac','-encoding','UTF-8','-d',str(t),*map(str,java),str(t/'DispatchHarness.java')],capture_output=True,text=True)
 assert c.returncode==0,c.stderr
 urls=['https://www.temu.com/goods.html?goods_id=601099123456789','https://ja.aliexpress.com/item/1005008877665544.html','https://m.shein.com/jp/Shirt-p-12345678.html']
 for i,url in enumerate(urls):
  p=subprocess.run(['java','-cp',str(t),'com.cmyk.bookmarkslauncher.wishlist.DispatchHarness',url],capture_output=True,text=True)
  assert p.returncode==0,p.stderr
  (t/f'{i}.js').write_text(p.stdout)
  check=subprocess.run(['node','--check',str(t/f'{i}.js')],capture_output=True,text=True)
  assert check.returncode==0,(i,check.stderr)
 assert 'site=\'TEMU\'' in (t/'0.js').read_text()
 assert 'merchantAudit=\'ALI\'' in (t/'1.js').read_text()
 assert 'shein-bound-price' in (t/'2.js').read_text()
 node='''const fs=require('fs'),vm=require('vm'),assert=require('assert');
const url='https://ja.aliexpress.com/item/1005008877665544.html';
const js=fs.readFileSync(process.argv[2],'utf8');
const product={'@type':'Product',url,name:'AliExpress Cotton Shirt Special',image:'https://ae01.alicdn.com/kf/shirt-special.jpg',offers:{price:890,priceCurrency:'JPY',availability:'https://schema.org/InStock'}};
const doc={title:'Product detail',readyState:'complete',body:{innerText:'Sample item',textContent:'Sample item'},
 querySelector:()=>null,
 querySelectorAll:q=>q==='script[type="application/ld+json"]'?[{textContent:JSON.stringify(product)}]:[]};
const got=JSON.parse(vm.runInNewContext(js,{document:doc,window:{},location:{hostname:'ja.aliexpress.com',pathname:'/item/1005008877665544.html',href:url},URL,Set},{timeout:2500}));
assert.equal(got.title,product.name);assert.equal(got.value,'¥890');assert.equal(got.stockStatus,'AVAILABLE');
assert.equal(got.imageCandidates.length,1);console.log('Actual Ali composite integration: PASS');
'''
 (t/'integration.cjs').write_text(node)
 subprocess.run(['node',str(t/'integration.cjs'),str(t/'1.js')],check=True)
 print('Marketplace dispatch Java+JS syntax and site isolation: PASS (3 sites)')
