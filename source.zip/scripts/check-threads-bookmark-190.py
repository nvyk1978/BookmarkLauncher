#!/usr/bin/env python3
"""Offline Java/JS Threads bookmark checks. No live Threads availability claim."""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[1]
threads=root/'app/src/main/java/com/cmyk/bookmarkslauncher/ThreadsBookmarkMetadata.java'
capture=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WebBookmarkCaptureManager.java').read_text()
assert 'ThreadsBookmarkMetadata.fromJavascript' in capture
assert 'fetchThreadsPublicMetadataAsync' in capture
assert 'result.title, null, null' in capture
assert 'repo.updateWebMetadata(nodeId, finalSiteName, finalTitle' in capture
with tempfile.TemporaryDirectory() as d:
 p=Path(d)
 (p/'android/text').mkdir(parents=True)
 (p/'org/json').mkdir(parents=True)
 (p/'android/text/Html.java').write_text('''package android.text;
public class Html { public static final int FROM_HTML_MODE_LEGACY=0;
public static CharSequence fromHtml(String s,int mode){return s.replace("&amp;","&").replace("&quot;","\\\"");}}
''')
 (p/'org/json/JSONObject.java').write_text('''package org.json;
public class JSONObject {public JSONObject(String s){} public String optString(String s,String fallback){return fallback;}
public boolean optBoolean(String s,boolean fallback){return fallback;}}
''')
 (p/'org/json/JSONTokener.java').write_text('''package org.json;
public class JSONTokener {public JSONTokener(String s){} public Object nextValue(){return "{}";}}
''')
 (p/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher;
public class Harness {
 static void check(boolean b,String msg){if(!b)throw new RuntimeException(msg);}
 public static void main(String[] args){
  String share="https://www.threads.com/share/BAUmvyPnyb";
  String real="https://www.threads.com/@sample/post/AB12345";
  check(ThreadsBookmarkMetadata.share(share),"share URL not recognized");
  check(ThreadsBookmarkMetadata.post(real),"post URL not recognized");
  check(!ThreadsBookmarkMetadata.post(share),"share must not be treated as post");
  check(!ThreadsBookmarkMetadata.handles("https://threads.com.evil.org/share/BAUmvyPnyb"),"foreign host");
  String html="<meta content='A sample public post title' property='og:title'>"
    +"<meta content='A readable sample post about software' property='og:description'>"
    +"<meta content='"+real+"' property='og:url'>";
  ThreadsBookmarkMetadata.Result r=ThreadsBookmarkMetadata.parseHtml(html,share);
  check(r!=null&&r.postUrl.equals(real),"share post not resolved");
  check(r.title.contains("readable sample"),"post text not preferred");
  check(ThreadsBookmarkMetadata.parseHtml("<meta property='og:title' content='Threads'>",share)==null,"generic page accepted");
  check(ThreadsBookmarkMetadata.parseHtml("<meta property='og:title' content='Hello'>",share)==null,"unresolved share accepted");
  check(ThreadsBookmarkMetadata.parseHtml(html.replace(real,"https://evil.example/@sample/post/AB12345"),share)==null,"foreign canonical accepted");
  String bad=html+"<link rel='canonical' href='https://www.threads.com/@sample/post/XX98765'>";
  check(ThreadsBookmarkMetadata.parseHtml(bad,share)==null,"conflicting post accepted");
  String script=ThreadsBookmarkMetadata.javascript();
  check(script.contains("og:title")&&script.contains("og:url"),"JS metadata missing");
  System.out.print(script);
 }
}
''')
 files=[p/'android/text/Html.java',p/'org/json/JSONObject.java',p/'org/json/JSONTokener.java',threads,p/'Harness.java']
 subprocess.run(['javac','-encoding','UTF-8','-d',str(p),*map(str,files)],check=True)
 js=subprocess.run(['java','-cp',str(p),'com.cmyk.bookmarkslauncher.Harness'],text=True,capture_output=True,check=True).stdout
 (p/'threads.js').write_text(js)
 subprocess.run(['node','--check',str(p/'threads.js')],check=True)
 (p/'test.cjs').write_text(r'''
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const js=fs.readFileSync(process.argv[2],'utf8');
function run({href='https://www.threads.com/share/BAUmvyPnyb',url='https://www.threads.com/@user/post/AB12345',text='Post content from the author',body='Public post'}={}){
 const meta={ 'og:url':url,'og:title':'Post from @user','og:description':text};
 const doc={title:'Threads',body:{innerText:body},querySelector:s=>{
  if(s.startsWith('link['))return {href:url};
  const m=s.match(/meta\[property="([^"]+)"/);if(m&&meta[m[1]])return {getAttribute:()=>meta[m[1]]};
  return null;
 }};
 return JSON.parse(vm.runInNewContext(js,{location:{href},document:doc},{timeout:1000}));
}
assert.equal(run().canonical,'https://www.threads.com/@user/post/AB12345');
assert.equal(run().description,'Post content from the author');
assert.equal(run({body:'verify you are human with captcha'}).gate,true);
console.log('PASS: Threads official share/permalink metadata script');
''')
 subprocess.run(['node',str(p/'test.cjs'),str(p/'threads.js')],check=True)
print('PASS: Threads share URL validation, real-post metadata, title and fallback wiring')
