#!/usr/bin/env python3
"""Ensure serial manual/batch A-H and page item verification have TWO 15s windows.
Static code-path guard, not a simulated Android/WebView live site test.
"""
from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
s=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist/WishlistAvailabilityWebViewProbe.java').read_text()
assert 'refreshItem(id, false, null);' in p
assert 'refreshItem(id, true, () -> {' in p
assert 'new WishlistAvailabilityWebViewProbe(root)' in p
assert 'modeWindowTimeout' in s and 'pageWindowTimeout' in s
assert 'main.postDelayed(modeWindowTimeout, 15000L);' in s
assert 'main.postDelayed(pageWindowTimeout,15000L);' in s
assert 'pageInspectionStarted=true;' in s
assert 'beginPageInspection("mode-numbered-complete")' in s
assert 'beginPageInspection("mode-deadline")' in s
assert 'pageWindowExpired=true;' in s
assert 'if ("UNKNOWN".equals(status) && mode == WishlistMode.GENERAL\n                && pageInspectionStarted && !pageWindowExpired)' in s
assert '(firstPass && pageInspectionStarted)' in s
assert '(firstPass && pageInspectionStarted)' in s
assert 'main.removeCallbacks(modeWindowTimeout);' in s and 'main.removeCallbacks(pageWindowTimeout);' in s
assert 'if (expanded) updateModeCollapsed.setVisibility(View.GONE)' in p
assert 'if (expand) header.updateModeCollapsed.setVisibility(View.GONE)' in p
assert 'if (expanded) header.updateModeCollapsed.setVisibility(View.GONE)' in p
assert 'FrameLayout centeredModeSlot' in p
assert '!WishlistGeneralShopItem.isDetail(original)' in s
for name in ['WishlistGeneralShopDedicatedMode.java','WishlistGuVariantStockDom.java','WishlistMercariItemStockDom.java','WishlistMarketplaceDedicatedMode.java','WishlistTemuItemDom.java','WishlistAliItemDom.java','WishlistSheinItemDom.java']:
 assert (root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'/name).exists()
print('GENERAL mode <=15 s and page <=15 s independent, early proof, batch=manual, five shops, center: PASS')
