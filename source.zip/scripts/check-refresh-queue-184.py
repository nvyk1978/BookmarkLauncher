#!/usr/bin/env python3
"""Exercise the real Android-independent queue planner with javac/java."""
import pathlib, subprocess, tempfile
root=pathlib.Path(__file__).resolve().parents[1]
source=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist/WishlistManualRefreshQueue.java'
test='''import com.cmyk.bookmarkslauncher.wishlist.WishlistManualRefreshQueue;
import java.util.*;
public class Queue184Test {
 static void check(boolean c){if(!c)throw new AssertionError();}
 public static void main(String[] args){
  WishlistManualRefreshQueue q=new WishlistManualRefreshQueue();
  Map<String,String> hosts=new HashMap<>();hosts.put("a1","siteA");hosts.put("a2","siteA");hosts.put("b1","siteB");hosts.put("c1","siteC");
  check(q.enqueue("a1"));check(!q.enqueue("a1"));check(q.enqueue("a2"));check(q.enqueue("b1"));
  check("a1".equals(q.next(hosts::get)));
  q.setLastHost("siteA");q.remove("a1");
  check("b1".equals(q.next(hosts::get)));q.remove("b1");q.setLastHost("siteB");
  check("a2".equals(q.next(hosts::get)));q.remove("a2");q.setLastHost("siteA");
  check(q.enqueue("a1"));check(q.next(hosts::get)==null);
  check(q.enqueue("c1"));check("c1".equals(q.next(hosts::get)));
  check(q.pending().size()==2);q.prioritize("a1");check("a1".equals(q.pending().get(0)));
  System.out.println("PASS queue duplicate, cross-host, same-host wait, reordering");
 }
}
'''
with tempfile.TemporaryDirectory() as d:
 p=pathlib.Path(d)/'Queue184Test.java';p.write_text(test)
 subprocess.run(['javac','-d',d,str(source),str(p)],check=True)
 subprocess.run(['java','-cp',d,'Queue184Test'],check=True)
