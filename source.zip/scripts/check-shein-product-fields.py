#!/usr/bin/env python3
"""Compile shipped SHEIN DOM Java into JS then check current price / inventory evidence.
These offline fixtures do NOT assert SHEIN live-site availability or Android APK build.
"""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
page=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
price=(src/'WishlistPriceWebViewProbe.java').read_text()
repo=(src/'WishlistRepository.java').read_text()
for name,found in {
    'SHEIN dedicated field adapter':'WishlistSheinItemDom.javascript(originalRetailUrl)' in price,
    'snapshot stock getter':'public String marketplaceStockStatus()' in price,
    'SHEIN fields logged without raw price':'"shein.fields"' in price and '" yenTokens="' in price,
    'strict same URL + site inventory update':'repo.updateVerifiedSheinStock(id,before.url,sheinStock)' in page,
    'no stock on other marketplace':'WishlistGeneralMarketplaceIdentity.isDetail(url)' in repo[repo.index('public boolean updateVerifiedSheinStock'):repo.index('private java.net.URL urlForRetail')],
    'SHEIN stock uses row CAS':'AND acquisition_mode=\'GENERAL\' AND status=\'UNKNOWN\'' in repo[repo.index('public boolean updateVerifiedSheinStock'):repo.index('private java.net.URL urlForRetail')],
    'other site handlers unchanged':'case AMAZON: actualJs=AmazonDomSelectors.price();break;' in price,
}.items():
    assert found, name
with tempfile.TemporaryDirectory() as tmp:
    folder=Path(tmp)
    test=folder/'SheinHarness.java'
    test.write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class SheinHarness {
 public static void main(String[] args)throws Exception {
 System.out.print(WishlistSheinItemDom.javascript(new URL("https://m.shein.com/jp/Shirt-p-12345678.html")));
 }
}
''')
    subprocess.run(['javac','-encoding','UTF-8','-d',str(folder),
        str(src/'WishlistGeneralMarketplaceIdentity.java'),str(src/'WishlistSheinItemDom.java'),str(test)],
        check=True,capture_output=True,text=True)
    js=subprocess.check_output(['java','-cp',str(folder),
      'com.cmyk.bookmarkslauncher.wishlist.SheinHarness'],text=True)
    (folder/'script.js').write_text(js)
    runner=r'''
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const js=fs.readFileSync(process.argv[2],'utf8');
const saved='https://m.shein.com/jp/Shirt-p-12345678.html';
function element(text, extra={}){return {textContent:text,innerText:text,
   hidden:false,disabled:false,hasAttribute:()=>false,
   getAttribute:()=>null,closest:()=>null,querySelectorAll:()=>[],contains:()=>true,...extra};}
function run({url=saved,canonical=saved,title='Sample SHEIN Product Shirt',text='',priceNodes=[],
  buttons=[],products=[],badHeader=false,style,hasMain=true}={}){
 const canonicalLink=canonical?{href:canonical}:null;
 const priceEls=priceNodes.map(s=>element(s,{getAttribute:()=>null}));
 const h=element(title,{closest:q=>q.includes('main')||q.includes('product-intro')?main:null});
 const main=element(text||`${title}\nPrice and availability\n¥980\nSize\nADD TO CART`,{
   querySelectorAll:q=>q==='button,[role="button"],input[type="submit"]'?buttons:
     q.includes('price')||q.includes('Price')?priceEls:[],
   contains:()=>true});
 const doc={readyState:'complete',querySelector:q=>q.startsWith('link[')?canonicalLink:hasMain?main:null,
   querySelectorAll:q=>q.includes('application/ld+json')?products.map(p=>({textContent:JSON.stringify(p)})):
     q.includes('h1')?[h]:[]};
 const location=new URL(url);
 const ctx={URL,document:doc,location:{href:url,pathname:location.pathname,hostname:location.hostname},
   getComputedStyle:style||(()=>({display:'block',visibility:'visible'}))};
 return JSON.parse(vm.runInNewContext(js,ctx,{timeout:3000}));
}
let o=run();assert.equal(o.value,'¥980');assert.equal(o.priceSource,'labeled-current-price');
assert.equal(o.stock,'UNKNOWN');assert.equal(o.priceLabel,true);
// Product heading and current price are required; old price after current cannot replace it.
o=run({text:'Sample SHEIN Product Shirt\nPrice and availability\n¥431\nOriginal price ¥590\nSize\nADD TO CART'});
assert.equal(o.value,'¥431');
// A standalone price node also counts when in product region.
o=run({text:'Sample SHEIN Product Shirt\nSize\nADD TO CART',priceNodes:['¥459']});
assert.equal(o.value,'¥459');assert.equal(o.priceSource,'product-price-node');
// Conflicting independent price elements must not choose the first.
o=run({text:'Sample SHEIN Product Shirt\nSize',priceNodes:['¥459','¥522']});assert.equal(o.value,'');assert.equal(o.priceSource,'conflicting-prices');
// Body text of wrong product or generic landing is never used.
o=run({url:'https://m.shein.com/jp/other-p-12345679.html'});assert.equal(o.value,'');
o=run({url:'https://m.shein.com/jp/'});assert.equal(o.value,'');
o=run({canonical:'https://jp.shein.com/Other-p-12345679.html'});assert.equal(o.value,'');
o=run({title:'Home'});assert.equal(o.value,'');
o=run({text:'Sample SHEIN Product Shirt\nRelated items\n¥199\nADD TO CART'});assert.equal(o.value,'');
o=run({text:'Sample SHEIN Product Shirt\nPrice and availability\n$10.00\nSize'});assert.equal(o.value,'');
// No header cart; require a visible enabled product-local purchase button.
const buy=element('ADD TO CART',{closest:q=>q.includes('product-intro')?{}:null});
o=run({buttons:[buy]});assert.equal(o.stock,'AVAILABLE');assert.equal(o.stockReason,'item-local-enabled-cart');
const headCart=element('ADD TO CART');
o=run({buttons:[headCart]});assert.equal(o.stock,'UNKNOWN');
const disabled=element('ADD TO CART',{disabled:true,closest:q=>q.includes('product-intro')?{}:null});
o=run({buttons:[disabled]});assert.equal(o.stock,'UNKNOWN');
o=run({buttons:[buy,buy]});assert.equal(o.stock,'UNKNOWN');
// An exact Product offer can prove inventory, unrelated Product cannot.
let p={'@type':'Product',url:saved,offers:{availability:'https://schema.org/OutOfStock'}};
o=run({products:[p]});assert.equal(o.stock,'UNAVAILABLE');assert.equal(o.stockReason,'item-bound-jsonld-outofstock');
p={'@type':'Product',url:'https://m.shein.com/jp/Other-p-12345679.html',offers:{availability:'https://schema.org/InStock'}};
o=run({products:[p]});assert.equal(o.stock,'UNKNOWN');
console.log('SHEIN product-local price and stock evidence: PASS (16 scenarios, actual Java-exported JS)');
'''
    (folder/'runner.cjs').write_text(runner)
    subprocess.run(['node',str(folder/'runner.cjs'),str(folder/'script.js')],check=True)
print('SHEIN single-WebView stock commit and isolated routing: PASS')
