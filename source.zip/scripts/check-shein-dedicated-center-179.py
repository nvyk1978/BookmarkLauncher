#!/usr/bin/env python3
"""Offline SHEIN dedicated route, center-alignment static invariants, no live claims."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
page=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
mode=(src/'WishlistMarketplaceDedicatedMode.java').read_text()
badge=(src/'WishlistSiteBadge.java').read_text()
probe=(src/'WishlistPriceWebViewProbe.java').read_text()
assert 'FrameLayout centeredModeSlot = new FrameLayout(host);' in page
assert 'Gravity.CENTER_VERTICAL | Gravity.START' in page
assert 'centeredModeSlot.addView(updateModeExpanded, centeredChipLp)' in page
assert 'nameBox.addView(centeredModeSlot, new LinearLayout.LayoutParams(' in page
assert 'ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f' in page
assert 'showLiveModeChip(header.updateModeExpanded, label, expanded);' in page
assert 'NONE, TEMU, ALIEXPRESS, SHEIN' in mode
assert '"SHEIN専用モード"' in mode
assert 'if (onHost(host, "shein.com")) return "SHEIN"' in badge
assert 'if (stableMarketEvidence>=(sheinChallenge?2:3) && val.isEmpty())' in probe
assert 'trace("shein.challenge"' in probe
assert 'WishlistSheinItemDom.javascript(originalRetailUrl)' in probe
with tempfile.TemporaryDirectory() as d:
 p=Path(d)
 (p/'WishlistCrawler.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public final class WishlistCrawler { public static boolean isAllowedUrl(URL u){return u!=null&&u.getHost()!=null;} }\n''')
 (p/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class Harness {
 static void chk(boolean yes){if(!yes)throw new AssertionError();}
 public static void main(String[] args) throws Exception {
  String good="https://m.shein.com/jp/Shirt-p-571445705-cat-3239.html";
  String desktop="https://jp.shein.com/Shirt-p-571445705.html";
  chk(WishlistMarketplaceDedicatedMode.fromSavedUrl(good)==WishlistMarketplaceDedicatedMode.SHEIN);
  chk(WishlistMarketplaceDedicatedMode.fromSavedUrl(desktop)==WishlistMarketplaceDedicatedMode.SHEIN);
  chk(WishlistMarketplaceDedicatedMode.SHEIN.liveLabel().equals("SHEIN専用モード"));
  chk(WishlistGeneralMarketplaceIdentity.sameItem(new URL(good),new URL(desktop)));
  chk(WishlistMarketplaceDedicatedMode.fromSavedUrl("https://m.shein.com/jp/women/")==WishlistMarketplaceDedicatedMode.NONE);
  chk(WishlistMarketplaceDedicatedMode.fromSavedUrl("https://evil-shein.com/jp/Shirt-p-571445705.html")==WishlistMarketplaceDedicatedMode.NONE);
  chk(WishlistMarketplaceDedicatedMode.fromSavedUrl("http://m.shein.com/jp/Shirt-p-571445705.html")==WishlistMarketplaceDedicatedMode.NONE);
  chk(WishlistSiteBadge.forSavedUrl(good).equals("SHEIN"));
  chk(WishlistSiteBadge.forSavedUrl("https://fake-shein.com/").isEmpty());
  chk(WishlistMarketplaceDedicatedMode.fromSavedUrl("https://www.temu.com/-g-607611151827013.html")==WishlistMarketplaceDedicatedMode.TEMU);
  chk(WishlistMarketplaceDedicatedMode.fromSavedUrl("https://a.aliexpress.com/_mA9Zx12")==WishlistMarketplaceDedicatedMode.ALIEXPRESS);
  System.out.println("SHEIN item-only route, host, label, prior merchants: PASS (11 cases)");
 }
}''')
 sources=[src/(s+'.java') for s in ('WishlistGeneralMarketplaceIdentity','WishlistMarketplaceDedicatedMode','WishlistSiteBadge','WishlistMode')]
 # WishlistMode has an external symbol; provide a tiny stub for presentation-only code fixture.
 (p/'WishlistMode.java').write_text('package com.cmyk.bookmarkslauncher.wishlist; public enum WishlistMode { GENERAL; public String cardLabel(){return "";} }')
 sources=[s for s in sources if s.name!='WishlistMode.java']
 c=subprocess.run(['javac','-encoding','UTF-8','-d',d,str(p/'WishlistCrawler.java'),str(p/'WishlistMode.java'),*map(str,sources),str(p/'Harness.java')],capture_output=True,text=True)
 assert c.returncode==0,c.stderr
 r=subprocess.run(['java','-cp',d,'com.cmyk.bookmarkslauncher.wishlist.Harness'],capture_output=True,text=True)
 assert r.returncode==0,r.stderr
 print(r.stdout.strip())
print('Expanded live-mode geometric center / challenge-fast-fail wiring: PASS')
