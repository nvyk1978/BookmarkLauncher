#!/usr/bin/env python3
"""Regress observed Temu/Ali missing DOM proof, SHEIN price and progress overlay.
Tests Java-exported JS and source wiring. Does NOT claim live storefront reachability.
"""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
probe=(src/'WishlistPriceWebViewProbe.java').read_text()
page=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
checks={
 'mounted only exact GENERAL merchant page':'final boolean mountedMarketplace = mode == WishlistMode.GENERAL' in probe and '&& WishlistGeneralMarketplaceIdentity.isDetail(url)' in probe and 'parent.addView(web, 0, new FrameLayout.LayoutParams(' in probe,
 'mounted browser behind opaque Wish page': 'page.setBackgroundColor(BG)' in page and 'root.addView(page,' in page,
 'mount is never used for other stores': '&& expectedMarketplace == null && !retail' in probe,
 'temu exact item reached before denying redirect': 'if (temuReachedExactItem && originalRetailUrl!=null' in probe and 'reason=prevent-item-to-unbound-redirect' in probe,
 'stale callbacks invalidated': 'evaluatingMarketGeneration!=marketDocumentGeneration' in probe,
 'retain proven price on bounded timeout': 'Long retained = retainedPriceOnCurrentItem()' in probe and 'WishlistGeneralMarketplaceIdentity.sameItem(originalRetailUrl,current)' in probe,
 'progress overlay not list layout': 'gripScroll.addView(pullRefreshHeader, pullLp)' in page and 'animatePullOffset(trigger?dp(58):0)' not in page,
 'no list shift after triggering batch': 'setTranslationY(0f); // no push-down while progress floats' in page,
 'progress uses padded completed/total': 'String.format(java.util.Locale.ROOT, "%0"+width+"d/%0"+width+"d"' in page,
}
for title,result in checks.items():
    assert result,title
with tempfile.TemporaryDirectory() as d:
    tmp=Path(d)
    (tmp/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public final class Harness {
 public static void main(String[] a)throws Exception {
   URL u=new URL(a[0]);
   System.out.print(WishlistGeneralMarketplaceIdentity.merchant(u)==WishlistGeneralMarketplaceIdentity.Merchant.TEMU
      ?WishlistTemuItemDom.javascript(u):WishlistAliItemDom.javascript(u));
 }
}
''')
    files=[src/(name+'.java') for name in ['WishlistGeneralMarketplaceIdentity','WishlistTemuItemDom','WishlistAliItemDom']]
    subprocess.run(['javac','-encoding','UTF-8','-d',str(tmp),*[str(f) for f in files],str(tmp/'Harness.java')],check=True,capture_output=True,text=True)
    uris=['https://www.temu.com/g-607611151827013.html',
          'https://ja.aliexpress.com/item/1005011682345346.html']
    for i,uri in enumerate(uris):
        result=subprocess.run(['java','-cp',str(tmp),'com.cmyk.bookmarkslauncher.wishlist.Harness',uri],capture_output=True,text=True,check=True)
        (tmp/f'{i}.js').write_text(result.stdout)
        subprocess.run(['node','--check',str(tmp/f'{i}.js')],check=True,capture_output=True,text=True)
    (tmp/'test.cjs').write_text(r'''const assert=require('assert');const fs=require('fs'),vm=require('vm');
const ids=['607611151827013','1005011682345346'];
const urls=['https://www.temu.com/g-607611151827013.html','https://ja.aliexpress.com/item/1005011682345346.html'];
const js=[0,1].map(i=>fs.readFileSync(process.argv[2+i],'utf8'));
function run(i,{product=null,state=null,locationUrl=urls[i],canonical=null}={}){
 const scripts=product?[{textContent:JSON.stringify(product)}]:[];
 const document={readyState:'complete',title:'Valid shopping page',body:{innerText:'Item details',textContent:'Item details'},
 querySelector:q=>q==='link[rel="canonical"]'&&canonical?{href:canonical}:null,
 querySelectorAll:q=>q==='script[type="application/ld+json"]'?scripts:[]};
 const window={};if(state)window.__NEXT_DATA__=state;
 return JSON.parse(vm.runInNewContext(js[i],{location:{href:locationUrl},document,window,URL,Set},{timeout:3500}));
}
const temu={props:{pageProps:{goodsDetail:{goodsId:ids[0],goodsName:'Verified Temu Product Headphones',priceCurrency:'JPY',salePrice:'¥1280',mainImage:'https://img.example.org/items/temu-verified.webp'}}}};
let a=run(0,{state:temu});
assert.equal(a.value,'¥1280');assert.equal(a.title,'Verified Temu Product Headphones');
assert.equal(a.imageCandidates.length,1);assert.equal(a.pageKind,'item-url');
let x=JSON.parse(JSON.stringify(temu));x.props.pageProps.goodsDetail.goodsId='607611151827014';
a=run(0,{state:x});assert.equal(a.value,'');assert.equal(a.title,'');
a=run(0,{state:temu,locationUrl:'https://www.temu.com/jp/'});assert.equal(a.value,'');
x=JSON.parse(JSON.stringify(temu));x.props.pageProps.goodsDetail.priceCurrency='USD';x.props.pageProps.goodsDetail.salePrice='1280';
a=run(0,{state:x});assert.equal(a.value,'');
const ali={'@type':'Product',name:'AliExpress Verified Wired Headphones',offers:{price:'885',priceCurrency:'JPY',availability:'https://schema.org/InStock'},image:'https://ae01.alicdn.com/kf/ali-product.jpg'};
a=run(1,{product:ali});assert.equal(a.value,'¥885');assert.equal(a.title,ali.name);assert.equal(a.itemEvidence,'verified-product');
x={...ali,productId:'1005011682345347'};
a=run(1,{product:x});assert.equal(a.value,'');assert.equal(a.stockStatus,'UNKNOWN');
a=run(1,{product:ali,locationUrl:'https://ja.aliexpress.com/'});assert.equal(a.value,'');
x={...ali,offers:{price:885,priceCurrency:'USD'}};
a=run(1,{product:x});assert.equal(a.value,'');
a=run(1,{product:ali,canonical:'https://ja.aliexpress.com/item/1005011682345347.html'});
assert.equal(a.value,'');assert.equal(a.reason,'canonical-other-item');
console.log('Merchant live-diagnostic regression: PASS (9 concrete DOM positive/denial fixtures)');
''')
    subprocess.run(['node',str(tmp/'test.cjs'),str(tmp/'0.js'),str(tmp/'1.js')],check=True)
print('Marketplace mounted-engine/Temu redirect, exact-price deadline and floating-progress wiring: PASS (9)')
