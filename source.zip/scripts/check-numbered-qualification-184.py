#!/usr/bin/env python3
"""Compile real numbered registry against narrow Android storage fakes and test migration."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
reg=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist/WishlistNumberedTechniqueRegistry.java'
files={
'android/content/Context.java':'''package android.content; public abstract class Context { public static final int MODE_PRIVATE=0; public abstract Context getApplicationContext(); public abstract SharedPreferences getSharedPreferences(String name,int mode); }''',
'android/content/SharedPreferences.java':'''package android.content; public interface SharedPreferences { String getString(String key,String fallback); Editor edit(); interface Editor { Editor putString(String key,String value); boolean commit(); } }''',
'com/cmyk/bookmarkslauncher/wishlist/WishlistMode.java':'''package com.cmyk.bookmarkslauncher.wishlist; public enum WishlistMode {GENERAL,MUJI,UNIQLO,YODOBASHI,BICCAMERA,AMAZON,RAKUTEN,YAHOO;}''',
'CheckRegistry184.java':'''import android.content.*;import java.util.*;
import com.cmyk.bookmarkslauncher.wishlist.*;
public class CheckRegistry184 {
 static class Pref implements SharedPreferences {
  Map<String,String> map=new HashMap<>();public String getString(String k,String d){return map.getOrDefault(k,d);}
  public Editor edit(){return new Editor(){Map<String,String> set=new HashMap<>();public Editor putString(String k,String v){set.put(k,v);return this;}public boolean commit(){map.putAll(set);return true;}};}
 }
 static class Ctx extends Context {Pref p=new Pref();public Context getApplicationContext(){return this;}
   public SharedPreferences getSharedPreferences(String name,int mode){return p;}}
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  Ctx context=new Ctx();String pre="DEDICATED-OLD-SITE";
  try {
   ok("HONMA-GROSS-PRICE-CART".equals(WishlistNumberedTechniqueRegistry.dedicatedKey(new java.net.URL("https://www.honma-store.net/shop/products/view/55"),WishlistMode.GENERAL)));
   ok("ZOZO-EXACT-DID".equals(WishlistNumberedTechniqueRegistry.dedicatedKey(new java.net.URL("https://zozo.jp/shop/a/goods/1234567"),WishlistMode.GENERAL)));
   ok("YUIKAN-ITEM".equals(WishlistNumberedTechniqueRegistry.dedicatedKey(new java.net.URL("https://yuican-shop.com/?product_id=123"),WishlistMode.GENERAL)));
   ok("GU-COLOR-SIZE".equals(WishlistNumberedTechniqueRegistry.dedicatedKey(new java.net.URL("https://gu-global.com/jp/ja/products/E355777-000/00"),WishlistMode.GENERAL)));
  }catch(java.net.MalformedURLException ex){throw new AssertionError(ex);}
  context.p.map.put("extra_modes",pre+"\\n");
  List<String> catalog=WishlistNumberedTechniqueRegistry.catalog(context);
  ok(catalog.size()==41);ok(catalog.get(40).equals("PENDING-"+pre));
  ok(catalog.get(19).equals("TRIAL-GU-COLOR-SIZE"));
  ok("".equals(WishlistNumberedTechniqueRegistry.registerDedicatedSuccess(context,"GU-COLOR-SIZE","AVAILABLE",true,false,true)));
  ok(WishlistNumberedTechniqueRegistry.catalog(context).get(19).startsWith("TRIAL-"));
  ok("019".equals(WishlistNumberedTechniqueRegistry.registerDedicatedSuccess(context,"GU-COLOR-SIZE","AVAILABLE",true,true,true)));
  ok("GU-COLOR-SIZE".equals(WishlistNumberedTechniqueRegistry.catalog(context).get(19)));
  ok("".equals(WishlistNumberedTechniqueRegistry.registerDedicatedSuccess(context,pre,"AVAILABLE")));
  ok("".equals(WishlistNumberedTechniqueRegistry.registerDedicatedSuccess(context,pre,"AVAILABLE",true,true,false)));
  ok("".equals(WishlistNumberedTechniqueRegistry.registerDedicatedSuccess(context,"DEDICATED-NEW","UNKNOWN",true,true,true)));
  ok(WishlistNumberedTechniqueRegistry.catalog(context).size()==41);
  ok("040".equals(WishlistNumberedTechniqueRegistry.registerDedicatedSuccess(context,pre,"AVAILABLE",true,true,true)));
  ok(WishlistNumberedTechniqueRegistry.catalog(context).get(40).equals(pre));
  ok("041".equals(WishlistNumberedTechniqueRegistry.registerDedicatedSuccess(context,"DEDICATED-NEW","UNAVAILABLE",true,true,true)));
  ok("041".equals(WishlistNumberedTechniqueRegistry.registerDedicatedSuccess(context,"DEDICATED-NEW","UNAVAILABLE",true,true,true)));
  ok(WishlistNumberedTechniqueRegistry.catalog(context).size()==42);
  System.out.println("PASS registry legacy inactive, triple gate, stable IDs, dedup, durable storage");
 }
}'''
}
with tempfile.TemporaryDirectory() as d:
 base=Path(d);paths=[]
 for fn,content in files.items():
  p=base/fn;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content);paths.append(str(p))
 subprocess.run(['javac','-d',d,str(reg),*paths],check=True)
 subprocess.run(['java','-cp',d,'CheckRegistry184'],check=True)
