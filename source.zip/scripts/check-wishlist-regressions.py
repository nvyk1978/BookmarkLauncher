#!/usr/bin/env python3
"""Offline/CI no-regression guard including reviewed 0.1.162 GENERAL item recognition.

This does NOT claim that a live storefront is available: it ensures the
previously successful specialist stock, pricing and Joshin source bytes remain fixed
to the reviewed v0.1.162 baseline and that the fallback cannot replace
those codepaths. On a future intentional refactor, compare real-device logs
before updating the hashes rather than silently deleting this guard.
"""
from pathlib import Path
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
PROTECTED = {
    'WishlistJoshinProductIdentity.java': '751c6af4d5b2bac0c7b809e992335d213c7a122e9109f8f98b1b872c1e3bab78',
    'WishlistGeneralGalleryImageTechnique.java': '1e3378fe6a9af81bce15cb105828b1a2641f78d7fa21c4fc5c058ce098400e30',
    'WishlistZozoVariantDom.java': '34b5f2f6935ce259d2a794d5beee23e6dc55962ed447c96b85bbabff4d7249bb',
    'WishlistGeneralAlphabetDom.java': '5af0942e89dfd2ea5ce2137aa9dadc53575f3942905669a779a3de657adf9e28',
    'WishlistGeneralVariantStockDom.java': '0aafa1e557fcf7e336425e39639deca64bde72f9335f4efc2e5b9c6a9c7e136d',
    'WishlistPreviewStore.java': 'f3511d61abf2f560b926e44b8bf7ab37c42181795a6bee3cd84b627140e29b43',
    # 0.1.157: only ASKUL read-only product-name capture before the existing
    # early price+stock finish, plus MUJI transient parsing diagnostics/retry.
    # Reviewed against 0.1.156; the stock classifiers and price parsers remain untouched.
    # 0.1.164 reviewed: diagnostic-only additions for guarded market items,
    # no change to ASKUL/MUJI/ZOZO dispatch or generic price selectors.
    # 0.1.163 reviewed delta: unknown GENERAL strict JSON-LD and item-bound SHEIN/AliExpress
    # hydration is evaluated only for their own URL candidates; ASKUL/MUJI/ZOZO branches
    # retain the 0.1.162 logic. This digest records the intentional reviewed edit.
    # v0.1.172 reviewed: Temu/Ali strict independent read-only item snapshots only; SHEIN paths preserved.
    # v0.1.171 reviewed: add read-only SHEIN-only product price / stock evidence to guarded WebView.
    # Existing ASKUL/MUJI/ZOZO dispatch and price handlers remain unchanged.
    # v0.1.170 reviewed: guarded SHEIN cat-path parser, regional reroute + marketplace-only diagnostics.
    # v0.1.169 reviewed: EXACT guarded SHEIN/AliExpress item snapshot (price/name/gallery)
    # in the same WebView and repaired pageKind handoff; no ASKUL/MUJI/ZOZO changes.
    # v0.1.168 reviewed: price probe gives up after stable non-item DOM and once retries jp.shein.com same item ID. Other price paths untouched.
    # v0.1.167 reviewed: market identity tri-state and bound proof without blanket canonical veto.
    # v0.1.166 reviewed: exact-item hydrated/URL-bound market name + JPY price fallback.
    # v0.1.175 reviewed: exact merchant item navigation guard (four shops) only;
    # successful marketplace/ASKUL/MUJI/ZOZO field parsers untouched.
    # v0.1.174 reviewed: only three guarded marketplaces are window-mounted behind opaque page;
    # Temu item-to-unbound redirects blocked; exact-item price retained at deadline.
    # v0.1.173 reviewed: document-scoped SHEIN price retention and Temu redirect fail-fast;
    # no change to existing specialist price selection / scanner or any stock classifier.
    'WishlistPriceWebViewProbe.java': '89d52fa9aa3ddbaf20c5f80fa432d54ef1b486b8c08ec718e5a93a0a0bf39770',
    # 0.1.172 reviewed: conditional Ali/Temu item-bound stock CAS, original SHEIN-only CAS preserved.
    # 0.1.168 reviewed: add crawl.market.document sanitized classifier trace only; preserve title/photo edit protection.
    # 0.1.164 reviewed: add resolved URL identity flags to diagnostics only.
    # 0.1.163: GENERAL URL-bound JSON-LD recovery can replace an auto-saved wrong banner;
    # saved USER-edited photos are still excluded.
    # v0.1.166 reviewed: strictly guarded GENERAL market-title update only; existing methods intact.
    'WishlistRepository.java': 'e9fd834bc385fb79f383f94d6dc46443d793f2028d7eb348dd23b6f364df2378',
    # v0.1.175 reviewed: add exact four-shop product-URL recognition only.
    # 0.1.164 reviewed: prevent SHEIN/AliExpress redirects changing saved product identity.
    # 0.1.162: accept exact GENERAL item routes, reject page-wide image candidates on those hosts.
    'WishlistCrawler.java': '0484ba75b731e1b31d7710fbc72dac938836110ddeacad8efe8cfcaae5fc5cff',
    # 0.1.163: guarded marketplace rejects page-wide HTTP prices when exact JSON-LD missing.
    'WishlistPriceExtractor.java': '530978ba919a5c91e300c23224d9ca5e1ed6bb85412202992a1d69cdcdb3f05b',
}

def check(condition, message):
    if not condition:
        raise AssertionError(message)

for name, expected in PROTECTED.items():
    path = SRC / name
    check(path.is_file(), f'Protected source missing: {name}')
    check(hashlib.sha256(path.read_bytes()).hexdigest() == expected,
          f'Protected source changed, review against live regression fixtures: {name}')

android = (ROOT / 'app/build.gradle').read_text()
check("applicationId 'com.cmyk.bookmarkslauncher'" in android, 'applicationId changed')
check(re.search(r"versionCode\s+(\d+)", android) is not None, 'no versionCode')
check(int(re.search(r"versionCode\s+(\d+)", android).group(1)) >= 150, 'version rollback')
check('android.useAndroidX=true' in (ROOT / 'gradle.properties').read_text(), 'AndroidX disabled')
check((ROOT / 'keystore/bookmarks-launcher.jks').is_file(), 'signing key missing')

image = (SRC / 'WishlistRetailImageWebViewProbe.java').read_text()
feed = (SRC / 'WishlistVerifiedProductImageDom.java').read_text()
check('WishlistGeneralGalleryImageTechnique.javascript(originalRetailUrl' in image,
      'Joshin image parser was removed')
check('WishlistJoshinProductIdentity.isDetail(originalRetailUrl)' in image,
      'Joshin image routing guard was removed')
check('finish(urls.toArray(new String[0])); return;' in image,
      'Legacy image result is no longer preferred')
check('verifiedFeedFallback && !zozoFeedFirst' in image,
      'Image fallback is no longer gated')
check('!WishlistJoshinProductIdentity.isDetail(page)' in feed,
      'Verified feed must exclude Joshin')
check('WishlistCrawler.isSingleProductPage(page)' in feed, 'Listings must be excluded')
check('mode == WishlistMode.GENERAL' in feed, 'Dedicated modes must be excluded')
check('if(canonical&&canonical.href&&!samePage(canonical.href))return empty();' in feed,
      'Canonical item mismatch must be rejected')
check('if(edion&&new URLSearchParams(location.search).get(\'p_cd\')!==code)return empty();' in feed,
      'Edion query item ID mismatch must be rejected')
check('JSON.stringify([])' in feed, 'Unknown image feed must fail closed')
print('BookmarkLauncher source regression guard: PASS')
print(f'Protected source paths: {len(PROTECTED)}; build and image safeguards: PASS')

# 0.1.146: the verified feed is useless unless an exact ZOZO card actually
# starts it. These guards complement (not replace) the golden source hashes.
page = (ROOT / 'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
stock = (SRC / 'WishlistAvailabilityWebViewProbe.java').read_text()
audit = (SRC / 'WishlistRetailStockIdentityAuditDom.java').read_text()
check('isZozoSavedProductDetail(card.url)' in page, 'ZOZO saved product gate missing')
check('final String imagePageUrl = zozoSavedItem ? card.url : pageUrl;' in page,
      'ZOZO image must use saved product URL not HTTP error redirect')
check('thisImageProbe.start(imagePageUrl, zozoSavedItem ? card.acquisitionMode' in page,
      'Chosen ZOZO image URL not passed to image WebView')
check('repo.updateImageFromWebView(id, candidate, imagePageUrl, reason ->' in page,
      'Image save must verify the same source item')
check('"image.route.skip"' in page and '"image.webview.start"' in page,
      'Missing ZOZO entry/skip diagnostics')
check('else if (same && WishlistRetailDedicatedMode.forUrl(originalRetailUrl) == WishlistRetailDedicatedMode.ZOZO)' in image,
      'ZOZO gallery cannot depend only on onPageFinished')
check('if (!identityAuditDone && WishlistRetailStockIdentityAuditDom.supports(url))' in stock,
      'Purchase identity diagnostic is not bounded to one sample')
check('finish("UNKNOWN")' in stock and 'return done();' in audit,
      'Stock audit must be read-only and fail closed')
print('v0.1.146 ZOZO image entry and purchase identity diagnostics: PASS')

# v0.1.147 merchant-isolation regression gates. Saved mode stays GENERAL;
# actual site-specific parsing is routed only after strict product-url proof.
merchant = (SRC / 'WishlistRetailDedicatedMode.java').read_text()
merchant_stock = (SRC / 'WishlistRetailDedicatedStockDom.java').read_text()
merchant_image = (SRC / 'WishlistRetailDedicatedImageDom.java').read_text()
check('NONE, EDION, AU, ZOZO' in merchant, 'merchant submode routing missing')
check('MarketplaceIdentity.site(u) != MarketplaceIdentity.Site.OTHER' in merchant,
      'Merchant modes must not override marketplace identities')
check('WishlistRetailDedicatedMode.forUrl(originalAlphabetUrl())' in stock,
      'No dedicated stock dispatch before generic alphabet')
check('inspectDedicated(current)' in stock, 'Dedicated stock inspector missing')
check('return;' in stock[stock.index('inspectDedicated(current)'):stock.index('inspectDedicated(current)')+75],
      'Dedicated stock must never fall through into shared inspection')
check('mode == WishlistMode.GENERAL' in stock, 'Saved GENERAL mode guard missing')
check('!main' in merchant_stock or 'if(!main)' in merchant_stock,
      'Merchant stock must verify actual DOM')
check("merchant==='ZOZO'&&did" in merchant_stock,
      'Exact ZOZO requested detail ID must be verified')
check('return done();' in merchant_stock and "status:'UNKNOWN'" in merchant_stock,
      'Merchant stock must fail closed')
check('WishlistRetailDedicatedImageDom.javascript(originalRetailUrl)' in image,
      'ZOZO independent image extraction missing')
check('isZozoSavedProductDetail(card.url)' in page and
      'final String imagePageUrl = zozoSavedItem ? card.url : pageUrl;' in page,
      'ZOZO image must still use saved product URL')
check('WishlistRetailDedicatedMode.forUrl(parsed)' in page,
      'Unsupported saved ZOZO routes must not silently bypass the dedicated gate')
check('location.hostname.toLowerCase()!==host' in merchant_image,
      'Image evidence must never come from a redirected shop')
check('WishlistJoshinProductIdentity.isDetail(originalRetailUrl)' in image,
      'Joshin image source must remain independent')
print('v0.1.147 merchant-specific stock/image routing: PASS')

# v0.1.148: intentional, reviewed repository addition is name-only. The
# previously successful price, image and stock methods remain unchanged.
name = (SRC / 'WishlistRetailProductTitleDom.java').read_text()
repo = (SRC / 'WishlistRepository.java').read_text()
check('WishlistJoshinProductIdentity.isDetail(url)' in name and
      'WishlistMode.isMujiProduct(url)' in name and
      'askul.co.jp' in name, 'Retail title lookup must be only for three sites')
check('sku-not-present' in name and 'other-item-canonical' in name,
      'Retail title identity guard was removed')
check('WishlistRetailProductTitleDom.supports(original)' in stock and
      'verifiedProductTitle=name' in stock and
      'completeFinish(status)' in stock,
      'Name capture must run on the existing stock WebView and never override its result')
check('thisStockProbe.verifiedProductTitle()' in page and
      'repo.updateVerifiedRetailTitle(id,expectedUrl,verifiedName)' in page,
      'Verified name must be committed for the original card')
check('before.userTitleEdited' in repo[repo.index('boolean updateVerifiedRetailTitle'):],
      'Manual title must not be overwritten')
check('id=? AND url=? AND acquisition_mode=? AND user_title_edited=0' in repo,
      'Name update requires exact card, original URL, mode and unedited title')
check('r.idBound=!!(canonicalMatch||attrMatch||labelMatch)' in merchant_stock,
      'Edion exact item canonical identity must remain accepted')
print('v0.1.148 guarded retail-title recovery and Edion canonical proof: PASS')

# v0.1.149: visible, transient execution-mode label only. Regression routing
# and persistent acquisition modes must remain unchanged.
check('updateModeCollapsed = liveModeChip()' in page and
      'nameBox.addView(updateModeCollapsed, liveModeChipParams())' in page,
      'Collapsed progress badge must appear directly below product title')
check('nameBox.addView(url, urlLp);' in page and
      'nameBox.addView(updateModeExpanded, liveModeChipParams())' in page,
      'Expanded progress badge must appear directly below URL row')
check('switchRunningMode(id, "GENERAL A")' in page and
      'thisStockProbe.setModeProgress(label -> switchRunningMode(id,label))' in page and
      'switchRunningMode(id, stockModeName(imagePageUrl,' in page,
      'Real probe progress must update the visible card in sequence')
check('switchRunningMode(id, liveModeName(initial == null' in page and
      'switchRunningMode(id, liveModeName(repo.get(id).acquisitionMode))' in page,
      'A new update and generic price probe must publish current modes')
check('updatingItems.remove(id);\n        runningModes.remove(id);' in page and
      'applyLiveModeToVisibleCard(id);' in page,
      'Completed, failed or timed-out card tasks must remove the entire label')
check('chip.setVisibility(show ? View.VISIBLE : View.INVISIBLE)' in page and
      'liveModeColumnHeight(expanded)' in page,
      'Running-mode line must not change its height or disappear from layout')
check('View statusRow = header.footer;' in page,
      'New badge children must not shift the collapsed status row lookup')
print('v0.1.149 transient running-mode badge positions and lifecycle: PASS')

# v0.1.150: exact Edion/Isetan renderer recovery. Neither may touch the
# protected legacy price parsers or fabricate AVAILABLE from a generic cart.
merchant_meta = (SRC / 'WishlistRetailVerifiedMetadataDom.java').read_text()
isetan_stock = (SRC / 'WishlistIsetanStockDom.java').read_text()
name_probe = (SRC / 'WishlistRetailProductTitleDom.java').read_text()
check('ISETAN' in merchant and 'shopping|kyoto|sogogift' in merchant,
      'Isetan item-only merchant route removed')
check('WishlistIsetanStockDom.javascript(url)' in merchant_stock,
      'Isetan stock must use an isolated evidence engine')
check("r.reason='no-local-stock-proof'" in isetan_stock
      and 'canonical-different-product' in isetan_stock
      and "r.idBound=true" in isetan_stock,
      'Isetan cart must not be trusted without matching item and stock')
check('other-item-query' in merchant_meta
      and 'other-item-canonical' in merchant_meta
      and 'conflicting-gross-prices' in merchant_meta
      and 'single-product-heading-missing' in merchant_meta,
      'Retail metadata must reject other items and ambiguous prices')
check('WishlistRetailVerifiedMetadataDom.javascript(original)' in stock
      and 'verifiedProductPrice=recovered' in stock
      and 'verifiedProductTitle=name' in stock,
      'Existing stock renderer must capture independent name and gross price')
check('WishlistRetailVerifiedMetadataDom.supports(url)' in name_probe,
      'Title-only repository route must allow exact Edion/Isetan items')
check('single-rendered-item-first=true' in page
      and 'WishlistRetailDedicatedMode.ISETAN' in page
      and 'repo.updatePriceFromWebView(id,verifiedPrice,null)' in page
      and 'expectedUrl.equals(latest.url)' in page,
      'Merchant metadata must be committed to the saved card without a duplicate price WebView')
print('v0.1.150 Edion/Isetan metadata + item-bound stock safeguards: PASS')

# v0.1.151: first stock pass is serial GENERAL A..G, then exact-item native
# shop adapters. Progress is transient unframed N-white text, with no layout
# residue and no mutation of the stored acquisition mode.
check('if (!generalFirstDone)' in stock and 'inspectGeneralFirst(current);' in stock,
      'GENERAL-first routing not invoked before a site adapter')
check('publishMode("GENERAL A")' in stock and 'publishMode("GENERAL "+stage)' in stock,
      'Live labels must track the running GENERAL stage')
check('generalFirstDone=true;' in stock and 'inspect(current);' in stock,
      'Dedicated parser must be reached only after all GENERAL stages complete')
check('if (firstPass)' in stock and 'inspectAlphabet(current, index+1, true)' in stock,
      'First pass must run all six fallback stages without short circuit')
check('publishMode(merchant.name()+"固有モード")' in stock and
      'publishMode("JR東海固有モード")' not in stock and
      '"JR東海固有モード"' in stock,
      'Site-specific progress label missing')
check('generalFirstVerified="AVAILABLE"' in stock and
      '"AVAILABLE".equals(generalFirstVerified)' in stock,
      'A confirmed GENERAL result must survive a dedicated UNKNOWN')
check('"body-missing".equals(reason)' in stock and
      'nativeInspectionPending = true;' in stock,
      'JR stock probe must not exhaust attempts while the DOM is still absent')
check('TextView chip = text("", 11, WHITE, false)' in page and
      'chip.setBackground(null)' in page and
      'chip.setPadding(0, 0, 0, 0)' in page,
      'Mode indicator must be unframed, transparent and N-white')
check('runningModes.remove(id);' in page and 'View.GONE' in page,
      'Finished mode indicator must be removed')
print('v0.1.151 serial GENERAL to dedicated, JR retry and plain N-white mode label: PASS')

# v0.1.152: update-mode transitions must never resize either the card's
# collapsed right column or its progress-label row. Confirm that text-length,
# start/stop and repeated GENERAL->dedicated switches cannot change bounds.
check('return dp(expanded ? 140 : 80);' in page,
      'Progress text must never grow the card beyond its thumbnail height')
check('liveModeColumnHeight(expanded, label != null)' not in page and
      'liveModeColumnHeight(expand, runningMode != null)' not in page and
      'hasRunningLabel ? 98 : 80' not in page,
      'Progress lifecycle still alters the card column height')
check('ViewGroup.LayoutParams.MATCH_PARENT, dp(15)' in page and
      'chip.setSingleLine(true)' in page and
      'chip.setEllipsize(android.text.TextUtils.TruncateAt.END)' in page,
      'Longer mode labels must not change the measured row dimensions')
check('chip.setVisibility(show ? View.VISIBLE : View.INVISIBLE)' in page and
      'chip.setVisibility(View.GONE);' in page,
      'Idle active labels must retain their slot; the inactive slot remains GONE')
check('showLiveModeChip(updateModeCollapsed, runningMode, !expanded)' in page and
      'showLiveModeChip(updateModeExpanded, runningMode, expanded)' in page and
      'showLiveModeChip(header.updateModeCollapsed, label, !expanded)' in page and
      'showLiveModeChip(header.updateModeExpanded, label, expanded)' in page,
      'Expansion and update transitions must consistently share fixed mode rows')
print('v0.1.152 fixed-height running mode, no label relayout: PASS')

# v0.1.153: Isetan item routes, ZOZO equivalent canonical with strict goods ID,
# and Edion price tiers. Dedicated isolation prevents Joshin regressions.
check('shopping|kyoto|sogogift' in merchant and 'product/[0-9]{15,30}' in merchant,
      'Isetan storefront product routes must remain item-only')
check("saved[2]===item&&resolved[2]===item" in merchant_stock and
      "(!saved[1]||!resolved[1]||saved[1]===resolved[1])" in merchant_stock and
      "goods(?:-sale)?" in merchant_stock, 'ZOZO canonical must bind identical goods ID and shop')
check("r.idBound=canonicalMatch||attrMatch||labelMatch||zozoInquiry" in merchant_stock and
      "Number(item)+1000000" in merchant_stock,
      'ZOZO inquiry offset must only use explicitly ZOZO-labelled product ID')
check("main.querySelectorAll('tr,[role=row],dl,[class*=stock],[id*=stock]')" in isetan_stock and
      "filter(e=>visible(e)" in isetan_stock and
      "r.reason='no-local-stock-proof'" in isetan_stock,
      'Isetan in-stock must be verified from a visible local inventory row')
check('let primary=[];' in merchant_meta and
      'primary.every(v=>v===primary[0])' in merchant_meta and
      "o.reason='conflicting-gross-prices'" in merchant_meta,
      'Edion price must require agreement in high-confidence current-price field')
print('v0.1.153 isolated Isetan/Edion/ZOZO fixes: PASS')

check('edionDeliveryStock=false' in merchant_stock and
      '/配送受取/.test(before)' in merchant_stock and
      'matches.length===1' in merchant_stock and
      '!edionDeliveryStock' in merchant_stock,
      'Edion stock must require shipping availability tied to product purchase')
check('WishlistRetailDedicatedMode.zozoShopId(saved)' in stock and
      'expectedGoods.equals(loadedGoods)' in stock and
      'savedDid.equals(WishlistRetailDedicatedMode.query(url,"did"))' in stock,
      'ZOZO alias redirect must preserve original goods and variant identity')
print('v0.1.153 Edion local shipping and ZOZO URL alias verification: PASS')

# v0.1.154: never infer a price from Edion's tax-exclusive WEB price or coupon;
# ZOZO's selected ?did can only use a local, exact variant+stock+cart trio.
check("o.priceSource='edion-web-gross'" in merchant_meta and
      "WEB\\\\s*価格" in merchant_meta and
      "const priceText=stop?section.slice(0,stop.index):section" in merchant_meta and
      "o.reason='edion-main-price-conflict'" in merchant_meta,
      'Edion primary WEB gross and coupon/split-price protections missing')
check("didNodes:0,didLocalCarts:0,didLocalStock:0" in merchant_stock and
      "const exactDid=e=>" in merchant_stock and
      "matched===1" in merchant_stock and
      "other.length" in merchant_stock and
      "local.length!==1" in merchant_stock and
      "zozo-exact-did-local-cart" in merchant_stock,
      'ZOZO selected-DID-only inventory proof missing or too broad')
check('didLocalStock=' in stock and 'didNodes=' in stock,
      'ZOZO variant evidence diagnostic counters missing')
print('v0.1.154 EDION primary gross + ZOZO exact-did inventory safeguards: PASS')

# v0.1.155: ZOZO-only fallback for an exact did carried by product-scoped
# structured inventory. Do not accept the page-wide stock/cart or an ID from
# an unrelated item, do not weaken existing on-page attribute-bound evidence.
stock_dom=(SRC / 'WishlistRetailDedicatedStockDom.java').read_text()
check("merchant==='ZOZO'&&did&&r.idBound&&r.stockPairs===0&&adds.length" in stock_dom
      and 'const goodsKeys=' in stock_dom and 'const didKeys=' in stock_dom
      and 'goods===item' in stock_dom and 'const negKeys=' in stock_dom
      and 'owners>0&&proved>0&&contradictions===0' in stock_dom
      and 'didStateOwnerMatched=owners' in stock_dom
      and 'didStateNestedStock=nestedProof' in stock_dom
      and 'goodsKeys.some(k=>own(v,k)&&!sameId(v[k],item))' in stock_dom
      and 'didKeys.some(k=>own(v,k)&&!sameId(v[k],did))' in stock_dom
      and 'r.didStateRecords=matches' in stock_dom
      and "r.reason='zozo-structured-did-stock'" in stock_dom
      and "if(r.reason!=='zozo-structured-did-stock')" in stock_dom,
      'ZOZO exact goods/detail stock fallback was broadened or removed')
check('didStateRecords=o.optInt' in stock and 'didStateContradictions=o.optInt' in stock,
      'ZOZO state evidence counters absent from diagnostic')
print('v0.1.155 exact structured ZOZO selected detail and no false positives: PASS')

# v0.1.156: isolated title-only recovery on MUJI / ASKUL / ZOZO.
# Exact goods ID and variant guards remain independent of stock.
zozo_title=(SRC / 'WishlistZozoProductTitleDom.java').read_text()
retail_title=(SRC / 'WishlistRetailProductTitleDom.java').read_text()
check('WishlistZozoProductTitleDom.supports(url)' in retail_title
      and 'WishlistZozoProductTitleDom.javascript(url)' in retail_title
      and 'r.reason=\'canonical-different-product\'' in zozo_title
      and 'inquiryBound' in zozo_title and 'itemAttr' in zozo_title
      and 'r.reason=\'zozo-product-id-unverified\'' in zozo_title,
      'ZOZO title parser must verify the exact saved item')
check('お申込番号|お申し込み番号|申込番号|商品番号|商品コード' in retail_title
      and "if(!title&&type==='MUJI')" in retail_title
      and 'type===\'ASKUL\'' in retail_title,
      'MUJI/ASKUL item-bound product name paths missing')
check('didStateOwnerMatched=o.optInt' in stock
      and 'didStateNestedStock=o.optInt' in stock,
      'ZOZO stock nested-state diagnostics missing')
print('v0.1.156 MUJI/ASKUL/ZOZO titles and isolated variant guards: PASS')

# v0.1.157: item-name recovery must not compete with existing price/stock
# requests or relax ZOZO's exact-did availability proof.
price_probe = (SRC / 'WishlistPriceWebViewProbe.java').read_text()
page = (ROOT / 'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
title_dom = (SRC / 'WishlistRetailProductTitleDom.java').read_text()
zozo_stock = (SRC / 'WishlistRetailDedicatedStockDom.java').read_text()
check('finishAskulWithTitle(view, verifiedPrice)' in price_probe and
      'WishlistRetailProductTitleDom.javascript(originalRetailUrl)' in price_probe and
      'verifiedAskulTitle=title' in price_probe,
      'ASKUL successful price + stock must capture item-bound title before finish')
check('thisPriceProbe.verifiedAskulTitle()' in page and
      'repo.updateVerifiedRetailTitle(id,before.url,priceDomName)' in page,
      'ASKUL must save name independently of stock WebView early exit')
check('if(other&&other[1]!==jan)' in title_dom and
      'muji-canonical-sku-unverified' in title_dom and
      'muji-canonical-id-conflict' in title_dom,
      'MUJI product title must never accept a conflicting JAN or unverified alias')
check('didStateKeyHints' in zozo_stock and
      'if(matches>0&&owners>0&&proved>0&&contradictions===0)' in zozo_stock,
      'ZOZO diagnostics must not loosen exact detail stock proof')
check(int(re.search(r'versionCode\s+(\d+)', (ROOT / 'app/build.gradle').read_text()).group(1)) >= 158,
      'v0.1.157 versionCode must not roll back below 158')
print('v0.1.157 ASKUL same-WebView title + MUJI identity + ZOZO diagnostics: PASS')

# v0.1.158: ZOZO availabilityStatus only for the exact same-goods, same-did
# product record; preserve unknown and contrary evidence as fail-closed.
check("'availabilityStatus','status'" in merchant_stock,
      'ZOZO exact detail availabilityStatus classification missing')
check('IN_STOCK_NORMAL' in merchant_stock and 'negativeState.test(v)' in merchant_stock,
      'ZOZO explicit stock state or conflicting stock guard missing')
check('if(matches>0&&owners>0&&proved>0&&contradictions===0)' in merchant_stock,
      'ZOZO positive verdict must require same goods/detail and zero contradictions')
check('didStateAvailabilityValues' in merchant_stock and
      'didStateAvailabilityPositive=o.optInt' in stock and
      'didStateAvailabilityValues=values' in stock,
      'ZOZO exact-detail stock enum diagnostics absent')
print('v0.1.158 ZOZO exact-detail availabilityStatus enum and fail-closed guards: PASS')

# v0.1.160: Honma Store packaging site's *exact* product URL and gross-only
# adapter. Its GENERAL stored mode is unchanged. Confirm the cross-shop
# regressions above still pass, while no category/cart page can use this path.
honma = (SRC / 'WishlistHonmaProductDom.java').read_text()
crawler = (SRC / 'WishlistCrawler.java').read_text()
price_probe = (SRC / 'WishlistPriceWebViewProbe.java').read_text()
price = (SRC / 'WishlistPriceExtractor.java').read_text()
stock = (SRC / 'WishlistAvailabilityWebViewProbe.java').read_text()
image = (SRC / 'WishlistRetailImageWebViewProbe.java').read_text()
page = (ROOT / 'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
check('^/shop/products/view/' in honma and 'honma-store.net' in honma
      and 'sameItem(URL original, URL destination)' in honma,
      'Honma exact item route and identity check missing')
check('税込' in honma and '販売' in honma and 'Pattern GROSS' in honma
      and 'return null; // ambiguous product totals' in honma
      and 'honma-gross' in honma,
      'Honma must extract only item-bound tax-inclusive total')
check('if (WishlistHonmaProductDom.isDetail(url)) return true;' in crawler
      and 'WishlistHonmaProductDom.sameItem(url, conn.getURL())' in crawler
      and 'if (mode == WishlistMode.GENERAL && WishlistHonmaProductDom.isDetail(page))' in crawler
      and 'out.status = "UNKNOWN";' in crawler,
      'Honma HTTP scraper is not identity-bound and fail-closed')
check('WishlistHonmaProductDom.grossPrice(html, page)' in price
      and 'WishlistHonmaProductDom.priceJavascript(originalRetailUrl)' in price_probe
      and 'WishlistHonmaProductDom.sameItem(originalRetailUrl, dest)' in price_probe,
      'Honma gross-only price recovery missing')
check('WishlistHonmaProductDom.stockJavascript(originalAlphabetUrl())' in stock
      and 'if (WishlistHonmaProductDom.isDetail(original)) return true;' in stock
      and 'if (same && positive>0 && negative==0 && "AVAILABLE".equals(status))' in stock,
      'Honma positive stock must require saved item and product-bound purchase form')
check('WishlistHonmaProductDom.imageJavascript(originalRetailUrl)' in image
      and 'WishlistHonmaProductDom.sameItem(originalRetailUrl,u)' in image
      and 'recoverUnknownAvailability(id, before.url, pageUrl, () -> {' in page,
      'Honma image renderer must respect item identity and serial stock/price')
check(int(re.search(r'versionCode\s+(\d+)', (ROOT / 'app/build.gradle').read_text()).group(1)) >= 161,
      'v0.1.160 versionCode must not roll back')
print('v0.1.160 Honma identity, gross, image, stock isolation: PASS')

# v0.1.161: Honma's live DOM separates item code and prices into table cells;
# purchase inputs are named "purchase" and product pictures may be CSS/lazy assets.
assert '商品\\\\s*コード[^0-9]{0,65}' in honma, 'Honma multi-cell product code recognition missing'
assert '税込\\\\s*価格[^0-9]{0,65}' in honma, 'Honma multi-cell gross recognition missing'
assert 'item-purchase-control' in honma and 'purchase|cart|basket' in honma, 'Honma purchase control evidence missing'
assert 'codeHint=' in stock and 'grossHint=' in stock, 'Honma DOM proof diagnostics missing'
assert 'zozoSavedItem || honmaSavedItem' in page, 'Honma image gallery diagnostics missing'
check(int(re.search(r'versionCode\s+(\d+)', (ROOT / 'app/build.gradle').read_text()).group(1)) >= 162,
      'v0.1.161 versionCode must not roll back')
print('v0.1.161 Honma rendered-product parsing, purchase, image, regression: PASS')

# 0.1.164: Integration guard for saved item vs HTTP redirect (no live-site claim).
import subprocess
subprocess.run([sys.executable, str(ROOT / 'scripts/check-marketplace-route.py')], check=True)

# v0.1.166: the existing workflow invokes this gate before the Gradle build.
# Also run the new compiled marketplace JS/Java fixtures, not source-pattern checks alone.
import subprocess as _market_subprocess
_market_subprocess.run([sys.executable, str(ROOT / 'scripts/check-marketplace-metadata.py')], check=True)
# v0.1.170: CI must cover the regional-path + product-ID relationship and the
# actual Java-built unified snapshot, not just source-text expectations.
_market_subprocess.run([sys.executable, str(ROOT / 'scripts/check-marketplace-page-recovery.py')], check=True)
_market_subprocess.run([sys.executable, str(ROOT / 'scripts/check-marketplace-single-snapshot.py')], check=True)

# v0.1.171 CI gate: compile shipped SHEIN JS then exercise current price/stock proofs.
_market_subprocess.run([sys.executable, str(ROOT / 'scripts/check-shein-product-fields.py')], check=True)

# v0.1.172 CI: actual Java-generated standalone merchant scripts and composite dispatch.
_market_subprocess.run([sys.executable, str(ROOT / 'scripts/check-ali-temu-isolation.py')], check=True)
_market_subprocess.run([sys.executable, str(ROOT / 'scripts/check-merchant-dispatch.py')], check=True)

# v0.1.174: failures seen on device: Temu unbound page after item URL,
# AliExpress sole Product schema with missing URL, SHEIN earlier-price retention,
# and batch progress floating without moving the list view.
_market_subprocess.run([sys.executable, str(ROOT / 'scripts/check-marketplace-session-regression.py')], check=True)
_market_subprocess.run([sys.executable, str(ROOT / 'scripts/check-marketplace-rendered-recovery.py')], check=True)
