#!/usr/bin/env python3
"""Offline/CI no-regression guard for the 0.1.146 ZOZO image-gate repair.

This does NOT claim that a live storefront is available: it ensures the
previously successful stock, pricing and Joshin source bytes remain exactly
as in the verified v0.1.144 baseline and that the fallback cannot replace
those codepaths. On a future intentional refactor, compare real-device logs
before updating the hashes rather than silently deleting this guard.
"""
from pathlib import Path
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
PROTECTED = {
    'WishlistJoshinProductIdentity.java': '751c6af4d5b2bac0c7b809e992335d213c7a122e9109f8f98b1b872c1e3bab78',
    'WishlistGeneralGalleryImageTechnique.java': '1e3378fe6a9af81bce15cb105828b1a2641f78d7fa21c4fc5c058ce098400e30',
    'WishlistZozoVariantDom.java': '34b5f2f6935ce259d2a794d5beee23e6dc55962ed447c96b85bbabff4d7249bb',
    'WishlistGeneralAlphabetDom.java': '5af0942e89dfd2ea5ce2137aa9dadc53575f3942905669a779a3de657adf9e28',
    'WishlistGeneralVariantStockDom.java': '0aafa1e557fcf7e336425e39639deca64bde72f9335f4efc2e5b9c6a9c7e136d',
    'WishlistPreviewStore.java': 'f3511d61abf2f560b926e44b8bf7ab37c42181795a6bee3cd84b627140e29b43',
    'WishlistPriceWebViewProbe.java': '444750a604ce00aa22d5e3d8747281d445372aa0de06fa1f66280c6222c5d38e',
    'WishlistRepository.java': 'e146aa7c60a19bc6697504ecf902dbd70b8581b6bcb3b43fcd4c7dd601c95c88',
    'WishlistCrawler.java': '3c93ce9ca6fbf8c30da4b2e1083f5e412a707ca09ba309b80de781f3da636d22',
    'WishlistPriceExtractor.java': 'c4baeaf3602a696d9ab08ae0ee7307ac6743cf862dd322774bf1c2971762891b',
}

def check(condition, message):
    if not condition:
        raise AssertionError(message)

for name, expected in PROTECTED.items():
    path = SRC / name
    check(path.is_file(), f'Protected source missing: {name}')
    check(hashlib.sha256(path.read_bytes()).hexdigest() == expected,
          f'Protected source changed, review against live regression fixtures: {name}')

android = (ROOT / 'app/build.gradle').read_text()
check("applicationId 'com.cmyk.bookmarkslauncher'" in android, 'applicationId changed')
check(re.search(r"versionCode\s+(\d+)", android) is not None, 'no versionCode')
check(int(re.search(r"versionCode\s+(\d+)", android).group(1)) >= 147, 'version rollback')
check('android.useAndroidX=true' in (ROOT / 'gradle.properties').read_text(), 'AndroidX disabled')
check((ROOT / 'keystore/bookmarks-launcher.jks').is_file(), 'signing key missing')

image = (SRC / 'WishlistRetailImageWebViewProbe.java').read_text()
feed = (SRC / 'WishlistVerifiedProductImageDom.java').read_text()
check('WishlistGeneralGalleryImageTechnique.javascript(originalRetailUrl' in image,
      'Joshin image parser was removed')
check('WishlistJoshinProductIdentity.isDetail(originalRetailUrl)' in image,
      'Joshin image routing guard was removed')
check('finish(urls.toArray(new String[0])); return;' in image,
      'Legacy image result is no longer preferred')
check('verifiedFeedFallback && !zozoFeedFirst' in image,
      'Image fallback is no longer gated')
check('!WishlistJoshinProductIdentity.isDetail(page)' in feed,
      'Verified feed must exclude Joshin')
check('WishlistCrawler.isSingleProductPage(page)' in feed, 'Listings must be excluded')
check('mode == WishlistMode.GENERAL' in feed, 'Dedicated modes must be excluded')
check('if(canonical&&canonical.href&&!samePage(canonical.href))return empty();' in feed,
      'Canonical item mismatch must be rejected')
check('if(edion&&new URLSearchParams(location.search).get(\'p_cd\')!==code)return empty();' in feed,
      'Edion query item ID mismatch must be rejected')
check('JSON.stringify([])' in feed, 'Unknown image feed must fail closed')
print('BookmarkLauncher source regression guard: PASS')
print(f'Protected source paths: {len(PROTECTED)}; build and image safeguards: PASS')

# 0.1.146: the verified feed is useless unless an exact ZOZO card actually
# starts it. These guards complement (not replace) the golden source hashes.
page = (ROOT / 'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
stock = (SRC / 'WishlistAvailabilityWebViewProbe.java').read_text()
audit = (SRC / 'WishlistRetailStockIdentityAuditDom.java').read_text()
check('isZozoSavedProductDetail(card.url)' in page, 'ZOZO saved product gate missing')
check('final String imagePageUrl = zozoSavedItem ? card.url : pageUrl;' in page,
      'ZOZO image must use saved product URL not HTTP error redirect')
check('retailImageProbe.start(imagePageUrl, zozoSavedItem ? card.acquisitionMode' in page,
      'Chosen ZOZO image URL not passed to image WebView')
check('repo.updateImageFromWebView(id, candidate, imagePageUrl, reason ->' in page,
      'Image save must verify the same source item')
check('"image.route.skip"' in page and '"image.webview.start"' in page,
      'Missing ZOZO entry/skip diagnostics')
check('else if (same && WishlistRetailDedicatedMode.forUrl(originalRetailUrl) == WishlistRetailDedicatedMode.ZOZO)' in image,
      'ZOZO gallery cannot depend only on onPageFinished')
check('if (!identityAuditDone && WishlistRetailStockIdentityAuditDom.supports(url))' in stock,
      'Purchase identity diagnostic is not bounded to one sample')
check('finish("UNKNOWN")' in stock and 'return done();' in audit,
      'Stock audit must be read-only and fail closed')
print('v0.1.146 ZOZO image entry and purchase identity diagnostics: PASS')

# v0.1.147 merchant-isolation regression gates. Saved mode stays GENERAL;
# actual site-specific parsing is routed only after strict product-url proof.
merchant = (SRC / 'WishlistRetailDedicatedMode.java').read_text()
merchant_stock = (SRC / 'WishlistRetailDedicatedStockDom.java').read_text()
merchant_image = (SRC / 'WishlistRetailDedicatedImageDom.java').read_text()
check('NONE, EDION, AU, ZOZO' in merchant, 'merchant submode routing missing')
check('MarketplaceIdentity.site(u) != MarketplaceIdentity.Site.OTHER' in merchant,
      'Merchant modes must not override marketplace identities')
check('WishlistRetailDedicatedMode.forUrl(originalAlphabetUrl())' in stock,
      'No dedicated stock dispatch before generic alphabet')
check('inspectDedicated(current)' in stock, 'Dedicated stock inspector missing')
check('return;' in stock[stock.index('inspectDedicated(current)'):stock.index('inspectDedicated(current)')+75],
      'Dedicated stock must never fall through into shared inspection')
check('mode == WishlistMode.GENERAL' in stock, 'Saved GENERAL mode guard missing')
check('!main' in merchant_stock or 'if(!main)' in merchant_stock,
      'Merchant stock must verify actual DOM')
check("merchant==='ZOZO'&&did" in merchant_stock,
      'Exact ZOZO requested detail ID must be verified')
check('return done();' in merchant_stock and "status:'UNKNOWN'" in merchant_stock,
      'Merchant stock must fail closed')
check('WishlistRetailDedicatedImageDom.javascript(originalRetailUrl)' in image,
      'ZOZO independent image extraction missing')
check('isZozoSavedProductDetail(card.url)' in page and
      'final String imagePageUrl = zozoSavedItem ? card.url : pageUrl;' in page,
      'ZOZO image must still use saved product URL')
check('WishlistRetailDedicatedMode.forUrl(parsed)' in page,
      'Unsupported saved ZOZO routes must not silently bypass the dedicated gate')
check('location.hostname.toLowerCase()!==host' in merchant_image,
      'Image evidence must never come from a redirected shop')
check('WishlistJoshinProductIdentity.isDetail(originalRetailUrl)' in image,
      'Joshin image source must remain independent')
print('v0.1.147 merchant-specific stock/image routing: PASS')
