#!/usr/bin/env python3
"""Offline regression fixtures for safe GENERAL SHEIN/AliExpress product image recovery.
Requires Java 17 and Node 18+; neither network nor Android SDK is required.
Run from project root: python3 scripts/check-general-product-recovery.py
"""
from pathlib import Path
import subprocess
import tempfile
import textwrap

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
PARENT = ROOT / 'app/src/main/java/com/cmyk/bookmarkslauncher'

assert 'WishlistGeneralMarketplaceIdentity.isDetail(url)' in (SRC / 'WishlistCrawler.java').read_text()
assert '!WishlistGeneralMarketplaceIdentity.isGuarded(conn.getURL())' in (SRC / 'WishlistCrawler.java').read_text()
assert 'inspectPriorGeneralImage' in (PARENT / 'WishlistPage.java').read_text()
assert 'item-bound-general' in (SRC / 'WishlistRetailImageWebViewProbe.java').read_text()
assert 'WishlistGeneralMarketplaceIdentity.isDetail(parsed)' in (SRC / 'WishlistRepository.java').read_text()
assert '!WishlistGeneralMarketplaceIdentity.isGuarded(page)' in (SRC / 'WishlistGenericJsonLdProduct.java').read_text()

runner = r'''
package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class ProbeHarness {
 static void check(boolean b, String s) { if (!b) throw new AssertionError(s); }
 public static void main(String[] args) throws Exception {
  URL ali = new URL("https://ja.aliexpress.com/item/1005008877665544.html?spm=1");
  URL shein = new URL("https://m.shein.com/jp/Shirt-p-12345678.html");
  check(WishlistGeneralMarketplaceIdentity.isDetail(ali),"Ali item");
  check(WishlistGeneralMarketplaceIdentity.isDetail(shein),"SHEIN item");
  check(WishlistGeneralMarketplaceIdentity.sameItem(ali,new URL("https://www.aliexpress.com/item/1005008877665544.html")),"same item alias");
  check(!WishlistGeneralMarketplaceIdentity.sameItem(ali,new URL("https://www.aliexpress.com/item/1005008877665545.html")),"wrong Ali item");
  check(!WishlistGeneralMarketplaceIdentity.isDetail(new URL("https://ja.aliexpress.com/category/123.html")),"Ali listing");
  check(!WishlistGeneralMarketplaceIdentity.isDetail(new URL("https://m.shein.com/jp/Dresses-c-123.html")),"SHEIN listing");
  check(!WishlistGeneralMarketplaceIdentity.isDetail(new URL("https://badaliexpress.com/item/1005008877665544.html")),"fake Ali host");
  check(!WishlistGeneralMarketplaceIdentity.isItemBoundImage("https://www.example.com/banner.png",ali),"banner is not proof");
  System.out.println("---ALI---");
  System.out.println(WishlistGeneralMarketplaceImageDom.javascript(ali));
  System.out.println("---SHEIN---");
  System.out.println(WishlistGeneralMarketplaceImageDom.javascript(shein));
  System.out.println("---ALI-HYDRATION---");
  System.out.println(WishlistGeneralMarketplaceHydrationDom.javascript(ali));
  System.out.println("---SHEIN-HYDRATION---");
  System.out.println(WishlistGeneralMarketplaceHydrationDom.javascript(shein));
  URL general = new URL("https://shop.example.jp/products/1234567");
  URL wrong = new URL("https://shop.example.jp/products/1234568");
  check(WishlistGeneralVerifiedUnknownDom.candidate(general),"unknown candidate");
  check(WishlistGeneralVerifiedUnknownDom.samePage(general,general),"exact saved URL");
  check(!WishlistGeneralVerifiedUnknownDom.samePage(general,wrong),"different product URL");
  check(!WishlistGeneralVerifiedUnknownDom.candidate(new URL("https://shop.example.jp/category/list")),"exclude category");
  System.out.println("---UNKNOWN-JSONLD---");
  System.out.println(WishlistGeneralVerifiedUnknownDom.javascript(general));
 }
}
'''
node_test = r'''
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const ali=fs.readFileSync(process.argv[2],'utf8');
const shein=fs.readFileSync(process.argv[3],'utf8');
const a='https://ja.aliexpress.com/item/1005008877665544.html';
const s='https://m.shein.com/jp/Shirt-p-12345678.html';
const img=(src,alt='')=>({alt,currentSrc:src,getAttribute:k=>k==='src'?src:null,closest:()=>null});
const run=(code,url,images={},product=[],title='')=>{
 const u=new URL(url);
 const document={
  querySelector:q=>q.startsWith('h1')&&title?{textContent:title}:null,
  querySelectorAll:q=>q==='script[type="application/ld+json"]'?product.map(p=>({textContent:JSON.stringify(p)})):(images[q]||[])
 };
 const result=vm.runInNewContext(code,{document,URL,location:{hostname:u.hostname,pathname:u.pathname,href:url}}, {timeout:1000});
 return JSON.parse(result);
};
assert.equal(run(ali,a).length,0); // site-wide banner has no gallery evidence
assert.deepEqual([...run(ali,a,{'#magnifier img':[img('https://ae01.alicdn.com/promo-banner.webp'),img('https://ae01.alicdn.com/kf/item.jpg')]})],['https://ae01.alicdn.com/kf/item.jpg']);
assert.equal(run(ali,'https://ja.aliexpress.com/item/1005008877665545.html',{'#magnifier img':[img('https://ae01.alicdn.com/kf/item.jpg')]}).length,0);
assert.equal(run(ali,a,{},[{'@type':'Product',url:'https://ja.aliexpress.com/item/1005008877665545.html',image:'https://ae01.alicdn.com/kf/wrong.jpg'}]).length,0);
assert.deepEqual([...run(ali,a,{},[{'@type':'Product',url:a,image:'https://ae01.alicdn.com/kf/matched.jpg'}])],['https://ae01.alicdn.com/kf/matched.jpg']);
assert.deepEqual([...run(shein,s,{'[class*="product-gallery"] img':[img('https://img.shein.com/product/photo.webp')]})],['https://img.shein.com/product/photo.webp']);
assert.equal(run(shein,'https://m.shein.com/jp/category-c-112233.html',{'[class*="product-gallery"] img':[img('https://img.shein.com/product/photo.webp')]}).length,0);
console.log('GENERAL product-image DOM fixtures: PASS (7)');
const runHyd=(script,url,state={},body='')=>{
 const u=new URL(url);
 const doc={readyState:'complete',body:{innerText:body},querySelectorAll:()=>[]};
 const context={location:{hostname:u.hostname,pathname:u.pathname,href:url},document:doc,window:state,URL};
 return JSON.parse(vm.runInNewContext(script,context,{timeout:1500}));
};
const ah=fs.readFileSync(process.argv[4],'utf8'),sh=fs.readFileSync(process.argv[5],'utf8');
const alData={actionModule:{productId:'1005008877665544'},
 priceModule:{formatedActivityPrice:'¥1,280',minAmount:{value:'1280'},maxAmount:{value:'1280'}},
 currencyModule:{currencyCode:'JPY'},imageModule:{imagePathList:['https://ae01.alicdn.com/kf/opaque.webp']}};
let r=runHyd(ah,a,{runParams:{data:alData}});
assert.equal(r.value,'¥1280'); assert.equal(r.reason,'bound-price');
assert.deepEqual([...r.images],['https://ae01.alicdn.com/kf/opaque.webp']);
assert.equal(runHyd(ah,a,{runParams:{data:{...alData,actionModule:{productId:'1005008877665545'}}}}).value,'');
assert.equal(runHyd(ah,a,{runParams:{data:{...alData,currencyModule:{currencyCode:'USD'},priceModule:{formatedPrice:'US $19.99'}}}}).value,'');
assert.equal(runHyd(ah,a,{runParams:{data:{...alData,priceModule:{formatedPrice:'¥100～¥200'}}}}).value,'¥100～¥200');
assert.equal(runHyd(ah,a,{runParams:{data:alData}},'Robot check verify you are human').value,'');
const shi={goods_id:'12345678',salePrice:{amountWithSymbol:'¥990'},goods_img:'https://img.ltwebstatic.com/images/something-opaque.webp'};
r=runHyd(sh,s,{productIntroData:shi});
assert.equal(r.value,'¥990');assert.deepEqual([...r.images],['https://img.ltwebstatic.com/images/something-opaque.webp']);
assert.equal(runHyd(sh,s,{productIntroData:{...shi,goods_id:'12345679'}}).value,'');
assert.equal(runHyd(sh,s,{productIntroData:{...shi,salePrice:{amountWithSymbol:'$9.90'}}}).value,'');
assert.equal(runHyd(sh,s,{productIntroData:{...shi,goods_img:'https://www.shein.com/banner.jpg'}}).images.length,0);
assert.equal(runHyd(sh,'https://m.shein.com/jp/Foo-p-12345679.html',{productIntroData:shi}).value,'');
// Site-wide unbound promotions do not masquerade as a merchandise price.
assert.equal(runHyd(ah,a,{runParams:{data:{priceModule:alData.priceModule,currencyModule:alData.currencyModule}}}).reason,'id-unverified');
console.log('GENERAL item-bound hydration DOM fixtures: PASS (12)');
const runGallery=(script,url,state)=>{
 const u=new URL(url);
 const document={readyState:'complete',body:{innerText:''},querySelector:()=>null,querySelectorAll:()=>[]};
 return JSON.parse(vm.runInNewContext(script,{window:state,document,URL,location:{hostname:u.hostname,pathname:u.pathname,href:url}}, {timeout:1500}));
};
assert.deepEqual([...runGallery(ali,a,{runParams:{data:alData}})],['https://ae01.alicdn.com/kf/opaque.webp']);
assert.deepEqual([...runGallery(shein,s,{productIntroData:shi})],['https://img.ltwebstatic.com/images/something-opaque.webp']);
assert.equal(runGallery(ali,a,{runParams:{data:{...alData,actionModule:{productId:'1005008877665545'}}}}).length,0);
console.log('Marketplace image/WebView hydration integration: PASS (3)');

const unknown=fs.readFileSync(process.argv[6],'utf8');
const unknownUrl='https://shop.example.jp/products/1234567';
const runUnknown=(url,products)=>{
 const u=new URL(url);
 const scripts=products.map(p=>({textContent:JSON.stringify(p)}));
 const context={URL,location:{href:url},document:{querySelectorAll:()=>scripts}};
 return JSON.parse(vm.runInNewContext(unknown,context,{timeout:1500}));
};
const product={'@type':'Product',name:'Widget',url:unknownUrl,
  offers:{'@type':'Offer',priceCurrency:'JPY',price:'2190'},
  image:'https://cdn.example.jp/images/main-opaque.webp'};
let u=runUnknown(unknownUrl,[product]);
assert.equal(u.value,'¥2190');assert.deepEqual([...u.images],['https://cdn.example.jp/images/main-opaque.webp']);
assert.equal(runUnknown(unknownUrl,[{...product,url:'https://shop.example.jp/products/1234568'}]).value,'');
assert.equal(runUnknown(unknownUrl,[product,product]).value,'');
assert.equal(runUnknown(unknownUrl,[{...product,offers:{priceCurrency:'USD',price:'21.90'}}]).value,'');
assert.equal(runUnknown(unknownUrl,[{...product,image:'https://cdn.example.jp/banner.jpg'}]).images.length,0);
assert.equal(runUnknown('https://shop.example.jp/products/1234568',[product]).value,'');
console.log('GENERAL unknown-URL strict JSON-LD fixtures: PASS (6)');

'''
with tempfile.TemporaryDirectory() as d:
    d = Path(d)
    harness = d / 'ProbeHarness.java'
    harness.write_text(textwrap.dedent(runner))
    subprocess.run(['javac','-encoding','UTF-8','-d',str(d),
                    str(SRC/'WishlistGeneralMarketplaceIdentity.java'),
                    str(SRC/'WishlistGeneralMarketplaceImageDom.java'),
                    str(SRC/'WishlistGeneralMarketplaceHydrationDom.java'),
                    str(SRC/'WishlistGeneralVerifiedUnknownDom.java'),str(harness)],check=True)
    r = subprocess.run(['java','-cp',str(d),'com.cmyk.bookmarkslauncher.wishlist.ProbeHarness'],
                       check=True,capture_output=True,text=True)
    chunks = r.stdout.split('---ALI---\n',1)[1].split('---SHEIN---\n',1)
    ali_js, shein_js = (c.strip() for c in chunks)
    shein_js = shein_js.split('---ALI-HYDRATION---',1)[0].strip()
    ah = r.stdout.split('---ALI-HYDRATION---\n',1)[1].split('---SHEIN-HYDRATION---\n',1)
    ali_hydrated, shein_hydrated = (c.strip() for c in ah)
    shein_hydrated = shein_hydrated.split('---UNKNOWN-JSONLD---',1)[0].strip()
    unknown_js = r.stdout.split('---UNKNOWN-JSONLD---\n',1)[1].strip()
    js1,js2 = d/'ali.js',d/'shein.js'
    js1.write_text(ali_js)
    js2.write_text(shein_js)
    hs1,hs2=d/'ali-hydration.js',d/'shein-hydration.js'
    hs1.write_text(ali_hydrated)
    hs2.write_text(shein_hydrated)
    subprocess.run(['node','--check',str(hs1)],check=True)
    subprocess.run(['node','--check',str(hs2)],check=True)
    unknownfile=d/'general-unknown.js'
    unknownfile.write_text(unknown_js)
    subprocess.run(['node','--check',str(unknownfile)],check=True)
    subprocess.run(['node','--check',str(js1)],check=True)
    subprocess.run(['node','--check',str(js2)],check=True)
    test = d/'fixtures.cjs'
    test.write_text(textwrap.dedent(node_test))
    subprocess.run(['node',str(test),str(js1),str(js2),str(hs1),str(hs2),str(unknownfile)],check=True)
print('GENERAL URL identity Java unit tests: PASS')
print('General image Java/JavaScript syntax and negative proof tests: PASS')
