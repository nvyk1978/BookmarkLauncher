#!/usr/bin/env python3
"""Offline regression fixtures for safe GENERAL SHEIN/AliExpress product image recovery.
Requires Java 17 and Node 18+; neither network nor Android SDK is required.
Run from project root: python3 scripts/check-general-product-recovery.py
"""
from pathlib import Path
import subprocess
import tempfile
import textwrap

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
PARENT = ROOT / 'app/src/main/java/com/cmyk/bookmarkslauncher'

assert 'WishlistGeneralMarketplaceIdentity.isDetail(url)' in (SRC / 'WishlistCrawler.java').read_text()
assert '!WishlistGeneralMarketplaceIdentity.isGuarded(conn.getURL())' in (SRC / 'WishlistCrawler.java').read_text()
assert 'inspectPriorGeneralImage' in (PARENT / 'WishlistPage.java').read_text()
assert 'item-bound-general' in (SRC / 'WishlistRetailImageWebViewProbe.java').read_text()
assert 'WishlistGeneralMarketplaceIdentity.isDetail(parsed)' in (SRC / 'WishlistRepository.java').read_text()
assert '!WishlistGeneralMarketplaceIdentity.isGuarded(page)' in (SRC / 'WishlistGenericJsonLdProduct.java').read_text()

runner = r'''
package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class ProbeHarness {
 static void check(boolean b, String s) { if (!b) throw new AssertionError(s); }
 public static void main(String[] args) throws Exception {
  URL ali = new URL("https://ja.aliexpress.com/item/1005008877665544.html?spm=1");
  URL shein = new URL("https://m.shein.com/jp/Shirt-p-12345678.html");
  check(WishlistGeneralMarketplaceIdentity.isDetail(ali),"Ali item");
  check(WishlistGeneralMarketplaceIdentity.isDetail(shein),"SHEIN item");
  check(WishlistGeneralMarketplaceIdentity.sameItem(ali,new URL("https://www.aliexpress.com/item/1005008877665544.html")),"same item alias");
  check(!WishlistGeneralMarketplaceIdentity.sameItem(ali,new URL("https://www.aliexpress.com/item/1005008877665545.html")),"wrong Ali item");
  check(!WishlistGeneralMarketplaceIdentity.isDetail(new URL("https://ja.aliexpress.com/category/123.html")),"Ali listing");
  check(!WishlistGeneralMarketplaceIdentity.isDetail(new URL("https://m.shein.com/jp/Dresses-c-123.html")),"SHEIN listing");
  check(!WishlistGeneralMarketplaceIdentity.isDetail(new URL("https://badaliexpress.com/item/1005008877665544.html")),"fake Ali host");
  check(!WishlistGeneralMarketplaceIdentity.isItemBoundImage("https://www.example.com/banner.png",ali),"banner is not proof");
  System.out.println("---ALI---");
  System.out.println(WishlistGeneralMarketplaceImageDom.javascript(ali));
  System.out.println("---SHEIN---");
  System.out.println(WishlistGeneralMarketplaceImageDom.javascript(shein));
 }
}
'''
node_test = r'''
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const ali=fs.readFileSync(process.argv[2],'utf8');
const shein=fs.readFileSync(process.argv[3],'utf8');
const a='https://ja.aliexpress.com/item/1005008877665544.html';
const s='https://m.shein.com/jp/Shirt-p-12345678.html';
const img=(src,alt='')=>({alt,currentSrc:src,getAttribute:k=>k==='src'?src:null,closest:()=>null});
const run=(code,url,images={},product=[],title='')=>{
 const u=new URL(url);
 const document={
  querySelector:q=>q.startsWith('h1')&&title?{textContent:title}:null,
  querySelectorAll:q=>q==='script[type="application/ld+json"]'?product.map(p=>({textContent:JSON.stringify(p)})):(images[q]||[])
 };
 const result=vm.runInNewContext(code,{document,URL,location:{hostname:u.hostname,pathname:u.pathname,href:url}}, {timeout:1000});
 return JSON.parse(result);
};
assert.equal(run(ali,a).length,0); // site-wide banner has no gallery evidence
assert.deepEqual([...run(ali,a,{'#magnifier img':[img('https://ae01.alicdn.com/promo-banner.webp'),img('https://ae01.alicdn.com/kf/item.jpg')]})],['https://ae01.alicdn.com/kf/item.jpg']);
assert.equal(run(ali,'https://ja.aliexpress.com/item/1005008877665545.html',{'#magnifier img':[img('https://ae01.alicdn.com/kf/item.jpg')]}).length,0);
assert.equal(run(ali,a,{},[{'@type':'Product',url:'https://ja.aliexpress.com/item/1005008877665545.html',image:'https://ae01.alicdn.com/kf/wrong.jpg'}]).length,0);
assert.deepEqual([...run(ali,a,{},[{'@type':'Product',url:a,image:'https://ae01.alicdn.com/kf/matched.jpg'}])],['https://ae01.alicdn.com/kf/matched.jpg']);
assert.deepEqual([...run(shein,s,{'[class*="product-gallery"] img':[img('https://img.shein.com/product/photo.webp')]})],['https://img.shein.com/product/photo.webp']);
assert.equal(run(shein,'https://m.shein.com/jp/category-c-112233.html',{'[class*="product-gallery"] img':[img('https://img.shein.com/product/photo.webp')]}).length,0);
console.log('GENERAL product-image DOM fixtures: PASS (7)');
'''
with tempfile.TemporaryDirectory() as d:
    d = Path(d)
    harness = d / 'ProbeHarness.java'
    harness.write_text(textwrap.dedent(runner))
    subprocess.run(['javac','-encoding','UTF-8','-d',str(d),
                    str(SRC/'WishlistGeneralMarketplaceIdentity.java'),
                    str(SRC/'WishlistGeneralMarketplaceImageDom.java'),str(harness)],check=True)
    r = subprocess.run(['java','-cp',str(d),'com.cmyk.bookmarkslauncher.wishlist.ProbeHarness'],
                       check=True,capture_output=True,text=True)
    chunks = r.stdout.split('---ALI---\n',1)[1].split('---SHEIN---\n',1)
    ali_js, shein_js = (c.strip() for c in chunks)
    js1,js2 = d/'ali.js',d/'shein.js'
    js1.write_text(ali_js)
    js2.write_text(shein_js)
    subprocess.run(['node','--check',str(js1)],check=True)
    subprocess.run(['node','--check',str(js2)],check=True)
    test = d/'fixtures.cjs'
    test.write_text(textwrap.dedent(node_test))
    subprocess.run(['node',str(test),str(js1),str(js2)],check=True)
print('GENERAL URL identity Java unit tests: PASS')
print('General image Java/JavaScript syntax and negative proof tests: PASS')
