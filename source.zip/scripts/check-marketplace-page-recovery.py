#!/usr/bin/env python3
"""v0.1.168 HTTP + WebView identity recovery regression; does not assert live access."""
from pathlib import Path
import tempfile, subprocess, textwrap
ROOT=Path(__file__).resolve().parent.parent
SRC=ROOT/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
CRAWLER=(SRC/'WishlistCrawler.java').read_text()
PRICE=(SRC/'WishlistPriceWebViewProbe.java').read_text()
IMAGE=(SRC/'WishlistRetailImageWebViewProbe.java').read_text()
METADATA=(SRC/'WishlistGeneralMarketplaceImageDom.java').read_text()
REPO=(SRC/'WishlistRepository.java').read_text()
for label, passed in {
 'HTTP body inspected before UNKNOWN marketplace rejection':
     CRAWLER.index('WishlistGeneralMarketplacePageEvidence.inspect')>CRAWLER.index('byte[] bytes;')
     and 'relation != WishlistGeneralMarketplaceIdentity.ItemRelation.SAME' not in CRAWLER,
 'HTTP UNKNOWN accepted only after URL-bound Product':
     'if (!verdict.verified)' in CRAWLER and 'productParseUrl = url;' in CRAWLER,
 'Card diagnosis records inspected-page kind': 'crawl.market.document' in REPO,
 'WebView stops stable unbound product before eleven retries':
     'stableMarketEvidence>=3' in PRICE and 'inspection.stop' in PRICE,
 'Regional retry preserves identical item ID':
     'WishlistGeneralMarketplaceIdentity.japanDesktopUrl(originalRetailUrl)' in PRICE and 'alternate != null' in PRICE,
 'Image rejects explicit different item':
     'WishlistGeneralMarketplaceIdentity.ItemRelation.DIFFERENT' in IMAGE,
 'Unknown-path images require item-bound hydrated data':
     'if(!urlBound){' in METADATA and 'hydrated.idBound === true' in METADATA and 'const found=products.filter(bound)' in METADATA,
}.items():
 if not passed: raise AssertionError(label)
print('HTTP/WebView wiring: PASS (7)')
# Test tri-state page classification independently of Android runtime.
with tempfile.TemporaryDirectory() as td:
 tmp=Path(td); stub=tmp/'WishlistGenericJsonLdProduct.java';stub.write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
final class WishlistGenericJsonLdProduct {
 static Object find(String html, URL saved) {
  // Stand-in for the already independently tested JSON-LD exact URL parser.
  return html.contains("exact-item-product") ? new Object() : null;
 }
}
''')
 harness=tmp/'PageEvidenceHarness.java'
 harness.write_text(textwrap.dedent('''
 package com.cmyk.bookmarkslauncher.wishlist;
 import java.net.URL;
 public class PageEvidenceHarness {
  static void expect(boolean ok,String message) { if(!ok)throw new AssertionError(message); }
  public static void main(String[] args)throws Exception {
   URL saved=new URL("https://m.shein.com/jp/Dress-p-12345678.html");
   URL same=new URL("https://jp.shein.com/jp/Dress-p-12345678.html");
   URL landing=new URL("https://m.shein.com/jp/");
   URL other=new URL("https://jp.shein.com/jp/Skirt-p-12345679.html");
   expect(WishlistGeneralMarketplacePageEvidence.inspect("<html>page</html>", saved, same).verified,"same-id URL");
   expect(!WishlistGeneralMarketplacePageEvidence.inspect("<html>recommend products</html>",saved,landing).verified,"unknown landing has no proof");
   expect(WishlistGeneralMarketplacePageEvidence.inspect("exact-item-product",saved,landing).verified,"URL-bound Product on rewrite");
   expect(!WishlistGeneralMarketplacePageEvidence.inspect("exact-item-product",saved,other).verified,"other item URL conflict");
   URL catSame=new URL("https://jp.shein.com/Dress-p-12345678-cat-1738.html");
   URL catWrong=new URL("https://jp.shein.com/Dress-p-12345679-cat-1738.html");
   expect(WishlistGeneralMarketplacePageEvidence.inspect("<html>cat product</html>",saved,catSame).verified,"cat path same-id accepted");
   expect(!WishlistGeneralMarketplacePageEvidence.inspect("<html>wrong cat product</html>",saved,catWrong).verified,"cat path different-id refused");
   expect(!WishlistGeneralMarketplacePageEvidence.inspect("<h1>Verify you are human</h1>",saved,same).verified,"challenge page blocked");
   expect(!WishlistGeneralMarketplacePageEvidence.inspect("  ",saved,same).verified,"empty body blocked");
   System.out.println("Marketplace HTTP document classification: PASS (8)");
  }
 }
 '''))
 subprocess.run(['javac','-encoding','UTF-8','-d',str(tmp),str(SRC/'WishlistGeneralMarketplaceIdentity.java'),str(SRC/'WishlistGeneralMarketplacePageEvidence.java'),str(stub),str(harness)],check=True)
 subprocess.run(['java','-cp',str(tmp),'com.cmyk.bookmarkslauncher.wishlist.PageEvidenceHarness'],check=True)
