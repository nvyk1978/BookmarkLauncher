#!/usr/bin/env python3
"""Protect v0.1.184 UI queue and three-field numbering contract."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
p=(r/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
repo=(r/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist/WishlistRepository.java').read_text()
reg=(r/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist/WishlistNumberedTechniqueRegistry.java').read_text()
stock=(r/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist/WishlistAvailabilityWebViewProbe.java').read_text()
numbered=(r/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist/WishlistNumberedSurveyDom.java').read_text()
assert '情報更新が完了してから操作してください' not in p
assert 'manualQueue.enqueue(id)' in p and 'manualQueue.next(id -> refreshSite(repo.get(id)))' in p
assert 'manualRunningId=next;' in p and 'refreshItem(next,false,() -> {' in p
assert 'manualRunningId=null;' in p and 'drainManualQueue();' in p
assert '.putString(REFRESH_RUNNING,manualRunningId==null?"":manualRunningId)' in p
assert 'String previousRunning=prefs.getString(REFRESH_RUNNING,"")' in p
assert 'button.setEnabled(!disabled);' in p and 'batchRefreshing || running || pending || updatingItems.contains(id)' in p
assert 'batchRefreshing = true;\n        updateVisibleButtons();\n        refreshList();' in p
assert 'repo.beginDedicatedQualification(id);' in p and 'repo.finishDedicatedQualification(id);' in p
assert 'if (!q.name || !q.image || !q.stock) return;' in repo
assert 'item.userTitleEdited || item.userImageEdited' in repo
assert 'result.availabilityExplicit' in repo
assert 'if (!imageVerified || !titleVerified || !stateVerified) return "";' in reg
assert 'return "";\n    }\n    /** Only three verified' in reg
assert 'pending-three-field-proof' in numbered
assert 'persistProvenDedicated(status)' not in stock
assert 'public boolean dedicatedStockProof()' in stock
print('PASS UI queue state, persistence, disabled controls, same-site scheduling, triple proof, legacy suppression')
