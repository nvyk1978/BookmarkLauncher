#!/usr/bin/env python3
"""Offline 0.1.188 exact-item/metadata and challenge retry guards.
Java-exported merchant JS is executed in a bounded Node mock DOM. Does NOT
assert production site access, captcha bypass or Android APK compilation.
"""
from pathlib import Path
import subprocess, tempfile, hashlib
root=Path(__file__).resolve().parent.parent
source=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
probe=(source/'WishlistPriceWebViewProbe.java').read_text()
assert 'retryExactMarketAlternate(view,"merchant-challenge-exact-route")' in probe
assert '== WishlistGeneralMarketplaceIdentity.Merchant.TEMU' in probe
assert probe.count('"merchant-challenge-exact-route"') == 1
assert 'marketplaceAlternateRetry=true' in probe
assert '"Temuの確認画面で商品情報を取得できず"' in probe
assert '"AliExpressの確認画面で商品情報を取得できず"' in probe
assert 'updateVerifiedOtherMarketplaceStock' in (root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
with tempfile.TemporaryDirectory() as td:
    p=Path(td)
    (p/'JsHarness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class JsHarness {public static void main(String[] x)throws Exception {
System.out.print(WishlistAliItemDom.javascript(new URL("https://ja.aliexpress.com/item/1005013255449296.html")));
}}''')
    subprocess.run(['javac','-encoding','UTF-8','-d',str(p),str(source/'WishlistAliItemDom.java'),str(source/'WishlistGeneralMarketplaceIdentity.java'),str(p/'JsHarness.java')],check=True)
    js=subprocess.run(['java','-cp',str(p),'com.cmyk.bookmarkslauncher.wishlist.JsHarness'],text=True,capture_output=True,check=True).stdout
    (p/'ali.js').write_text(js)
    subprocess.run(['node','--check',str(p/'ali.js')],check=True)
    (p/'test.cjs').write_text(r'''
const assert=require('assert'),fs=require('fs'),vm=require('vm');
const js=fs.readFileSync(process.argv[2],'utf8');
const url='https://ja.aliexpress.com/item/1005013255449296.html';
const name='Outdoor Tactical Backpack Strap Phone Holder',photo='https://examplecdn.com/goods/genuine-item.jpg';
const safe={ '@type':'Product',name,image:[photo],offers:{'priceCurrency':'JPY',availability:'https://schema.org/InStock'}};
function run({href=url,canonical=null,products=[safe],body='Product page',title='AliExpress',headings=[],app=false}={}){
  const q=(s)=>s==='link[rel="canonical"]'&&canonical?{href:canonical}:null;
  const qa=(s)=>s==='script[type="application/ld+json"]'? products.map(v=>({textContent:JSON.stringify(v)})):
    s==='h1'||s.includes('h1')?headings.map(x=>({textContent:x,closest:()=>null})):[];
  const doc={readyState:'complete',URL:href,title,body:{innerText:app?'Open in app '+body:body,textContent:app?'Open in app '+body:body},querySelector:q,querySelectorAll:qa};
  return JSON.parse(vm.runInNewContext(js,{location:{href},document:doc,URL,Set},{timeout:2500}));
}
let r=run();
assert.equal(r.title,name,'metadata-only exact URL must preserve item title');
assert.deepEqual(Array.from(r.imageCandidates),[photo],'only Product image');
assert.equal(r.value,'','no fabricated current price from JPY currency');
assert.equal(r.stockStatus,'UNKNOWN','no stock from unpriced URL-less Product');
assert.equal(r.aliAudit.metadataOnly,true);
assert.equal(r.itemEvidence,'item-url-metadata');
assert.equal(r.verifiedReason,'single-item-jsonld-metadata');
r=run({products:[safe,{...safe,name:'Other Item Model Q',image:'https://examplecdn.com/other.jpg'}]});
assert.equal(r.title,'');assert.equal(r.imageCandidates.length,0,'multiple products must be rejected');
r=run({products:[{...safe,url:'https://ja.aliexpress.com/item/1005013255449297.html'}]});
assert.equal(r.title,'');assert.equal(r.imageCandidates.length,0,'foreign URL must be rejected');
r=run({canonical:'https://ja.aliexpress.com/item/1005013255449297.html'});
assert.equal(r.title,'');assert.equal(r.reason,'canonical-other-item');
r=run({href:'https://ja.aliexpress.com/item/1005013255449297.html'});
assert.equal(r.title,'');assert.equal(r.reason,'navigation-other-item');
r=run({body:'Security check captcha verify you are human'});
assert.equal(r.title,'');assert.equal(r.imageCandidates.length,0,'verification gate refused');
r=run({app:true});assert.equal(r.title,'','app-gate metadata refused');
r=run({products:[{...safe,offers:{priceCurrency:'USD',price:'18.95',availability:'https://schema.org/OutOfStock'}}]});
assert.equal(r.value,'');assert.equal(r.stockStatus,'UNKNOWN');
r=run({products:[{...safe,offers:{priceCurrency:'JPY',lowPrice:'1000',highPrice:'1900',availability:'https://schema.org/InStock'}}]});
assert.equal(r.title,name);assert.equal(r.value,'');assert.equal(r.stockStatus,'UNKNOWN');
r=run({products:[{...safe,offers:{priceCurrency:'JPY',price:'1680',availability:'https://schema.org/InStock'}}]});
assert.equal(r.value,'¥1680');assert.equal(r.stockStatus,'AVAILABLE');
console.log('PASS: metadata-only exact Ali Product, no fabricated price/stock, multi/foreign/canonical/gate deny, JPY positive (10)');
''')
    subprocess.run(['node',str(p/'test.cjs'),str(p/'ali.js')],check=True)
print('PASS: Temu single official same-ID challenge retry, separated Ali parser (static assertions)')
