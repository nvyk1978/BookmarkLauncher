#!/usr/bin/env python3
"""SHEIN/AliExpress exact-item route regression test; Java + source control-flow.

This is NOT a live-storefront or APK build test. It verifies that all three
independent WebViews preserve the saved item URL after an HTTP redirect, and
that redirects to a different item / landing page cannot commit metadata.
"""
from pathlib import Path
import subprocess
import tempfile
import textwrap

root = Path(__file__).resolve().parent.parent
src = root / 'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
page = (root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
crawler = (src/'WishlistCrawler.java').read_text()
repo = (src/'WishlistRepository.java').read_text()
price = (src/'WishlistPriceWebViewProbe.java').read_text()
image = (src/'WishlistRetailImageWebViewProbe.java').read_text()

checks = {
 'probe uses saved marketplace item before HTTP-resolved URL':
  'final String pageUrl = marketplaceSavedItem' in page and '.preservedProbeUrl(before.url, r.resolvedUrl)' in page,
 'price/stock receive selected probe URL':
  'thisPriceProbe.start(pageUrl,' in page and 'recoverUnknownAvailability(id, before.url, pageUrl' in page,
 'image receives selected probe URL':
  'recoverMissingProductImage(id, pageUrl' in page and 'thisImageProbe.start(imagePageUrl,' in page,
 'HTTP distinguishes UNKNOWN from a proven different item':
  'WishlistGeneralMarketplaceIdentity.relation(url, conn.getURL())' in crawler and 'WishlistGeneralMarketplacePageEvidence.inspect' in crawler and '転送先に別の商品IDを検出' in crawler,
 'repository logs resolved item identity':
  'resolvedSameMarketItem=' in repo and 'resolvedDetail=' in repo,
 'price records script dispatch / navigation / DOM evidence':
  all(x in price for x in ['"script.select"','"hydration"','"navigation.reject"','"dom.skip"','"hydration.error"']),
 'image records exact-item route and navigation':
  all(x in image for x in ['"savedMarketItem=true source=saved-item','"navigation"','"deadline"']),
}
for title, good in checks.items():
    if not good: raise AssertionError('Missing regression guard: '+title)

harness = '''
package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class SavedRouteHarness {
 static void ok(boolean b, String message) { if (!b) throw new AssertionError(message); }
 public static void main(String[] args) throws Exception {
  String shein="https://m.shein.com/jp/Dress-p-12345678.html?some=1";
  String ali="https://ja.aliexpress.com/item/1005008877665544.html";
  String landing="https://m.shein.com/jp/";
  String wrong="https://m.shein.com/jp/Dress-p-12345679.html";
  ok(shein.equals(WishlistGeneralMarketplaceIdentity.preservedProbeUrl(shein,landing)), "SHEIN landing preserved original");
  ok(shein.equals(WishlistGeneralMarketplaceIdentity.preservedProbeUrl(shein,wrong)), "SHEIN foreign SKU preserved original");
  ok(ali.equals(WishlistGeneralMarketplaceIdentity.preservedProbeUrl(ali,"https://www.aliexpress.com/")), "Ali landing preserved original");
  ok(!WishlistGeneralMarketplaceIdentity.sameItem(new URL(shein),new URL(landing)), "SHEIN generic landing must not match");
  ok(WishlistGeneralMarketplaceIdentity.relation(new URL(shein),new URL(landing))==WishlistGeneralMarketplaceIdentity.ItemRelation.UNKNOWN,"missing item ID is unknown, NOT different");
  ok(WishlistGeneralMarketplaceIdentity.relation(new URL(shein),new URL(wrong))==WishlistGeneralMarketplaceIdentity.ItemRelation.DIFFERENT,"wrong ID is definite conflict");
  ok(WishlistGeneralMarketplaceIdentity.relation(new URL(shein),new URL("https://evil.example.com/jp/Dress-p-12345678.html"))==WishlistGeneralMarketplaceIdentity.ItemRelation.DIFFERENT,"offsite unsafe");
  ok(WishlistGeneralMarketplaceIdentity.relation(new URL(ali),new URL("https://ja.aliexpress.com/"))==WishlistGeneralMarketplaceIdentity.ItemRelation.UNKNOWN,"Ali rewritten URL not automatically different");
  ok(!WishlistGeneralMarketplaceIdentity.sameItem(new URL(shein),new URL(wrong)), "SHEIN different product must not match");
  ok(WishlistGeneralMarketplaceIdentity.sameItem(new URL(shein),new URL("https://www.shein.com/jp/Dress-p-12345678.html")), "SHEIN same ID cross-subdomain");
  ok(WishlistGeneralMarketplaceIdentity.sameItem(new URL(ali),new URL("https://www.aliexpress.com/item/1005008877665544.html")), "Ali same ID cross-subdomain");
  ok(!WishlistGeneralMarketplaceIdentity.sameItem(new URL(ali),new URL("https://www.aliexpress.com/item/1005008877665545.html")), "Ali wrong ID rejected");
  ok("https://ordinary.example.net/item.html".equals(WishlistGeneralMarketplaceIdentity.preservedProbeUrl(
    "https://ordinary.example.net/category", "https://ordinary.example.net/item.html")), "Non-marketplace behavior unchanged");
  ok(ali.equals(WishlistGeneralMarketplaceIdentity.preservedProbeUrl(ali,null)), "HTTP failure keeps Ali saved item");
  URL sheinPlain = new URL("https://m.shein.com/jp/Shirt-p-12345678.html");
  URL sheinCat = new URL("https://m.shein.com/jp/Shirt-p-12345678-cat-1738.html?language=en");
  URL sheinWrongCat = new URL("https://m.shein.com/jp/Shirt-p-12345679-cat-1738.html");
  URL sheinDesktop = new URL("https://jp.shein.com/Shirt-p-12345678-cat-1738.html?language=en");
  ok(WishlistGeneralMarketplaceIdentity.isDetail(sheinCat), "SHEIN cat URL is detail");
  ok(WishlistGeneralMarketplaceIdentity.itemId(sheinCat).equals("12345678"), "cat ID must NOT replace product ID");
  ok(WishlistGeneralMarketplaceIdentity.relation(sheinPlain,sheinCat)==WishlistGeneralMarketplaceIdentity.ItemRelation.SAME, "cat suffix same item");
  ok(WishlistGeneralMarketplaceIdentity.relation(sheinCat,sheinWrongCat)==WishlistGeneralMarketplaceIdentity.ItemRelation.DIFFERENT, "cat suffix wrong product rejected");
  ok(WishlistGeneralMarketplaceIdentity.relation(sheinCat,sheinDesktop)==WishlistGeneralMarketplaceIdentity.ItemRelation.SAME, "desktop same product cat suffix");
  ok(WishlistGeneralMarketplaceIdentity.isDetail(new URL("https://jp.shein.com/Shirt-p-12345678.html")), "desktop SHEIN plain path");
  ok(!WishlistGeneralMarketplaceIdentity.isDetail(new URL("https://m.shein.com/jp/Shirt-p-12345678-cat-other.html")), "unknown suffix refused");
  ok(!WishlistGeneralMarketplaceIdentity.isDetail(new URL("https://m.shein.com/jp/Shirt-p-12345678-cat-1738.html.extra")), "non-product suffix refused");
  ok(!WishlistGeneralMarketplaceIdentity.isDetail(new URL("https://bad-shein.com/jp/Shirt-p-12345678-cat-1738.html")), "spoof host refused");
  ok(WishlistGeneralMarketplaceIdentity.japanDesktopUrl(sheinCat).toExternalForm().equals(sheinDesktop.toExternalForm()), "strip /jp/ on desktop country host");
  ok(WishlistGeneralMarketplaceIdentity.japanDesktopUrl(new URL("https://m.shein.com/jp/Shirt-p-12345678.html")).toExternalForm().equals("https://jp.shein.com/Shirt-p-12345678.html"), "plain regional mapping");
  ok(WishlistGeneralMarketplaceIdentity.japanDesktopUrl(new URL("https://m.shein.com/ar-en/Shirt-p-12345678.html"))==null, "never apply JP mapping to another country");
  ok(WishlistGeneralMarketplaceIdentity.japanDesktopUrl(new URL("https://jp.shein.com/Shirt-p-12345678.html"))==null, "no duplicate regional retry");
  ok(WishlistGeneralMarketplaceIdentity.japanDesktopUrl(new URL("https://m.shein.com/jp/"))==null, "no regional retry for home");
  ok(WishlistGeneralMarketplaceIdentity.diagnosticRoute(sheinCat.toString()).contains("cat=yes"),"diagnostic records suffix");
  ok(!WishlistGeneralMarketplaceIdentity.diagnosticRoute("https://m.shein.com/jp/Shirt-p-12345678.html?token=private-secret").contains("private-secret"), "diagnostic excludes query values");
  System.out.println("Marketplace exact-item URL routing tests: PASS (30)");
 }
}
'''
with tempfile.TemporaryDirectory() as tmp:
    root_tmp = Path(tmp)
    f = root_tmp/'SavedRouteHarness.java'
    f.write_text(textwrap.dedent(harness))
    subprocess.run(['javac','-encoding','UTF-8','-d',str(root_tmp),str(src/'WishlistGeneralMarketplaceIdentity.java'),str(f)],check=True)
    subprocess.run(['java','-cp',str(root_tmp),'com.cmyk.bookmarkslauncher.wishlist.SavedRouteHarness'],check=True)
    # Match the actual WishlistPage package. Package-local route tests alone
    # cannot catch a missing public modifier on this Java API.
    external = root_tmp/'ExternalMarketplaceAccessHarness.java'
    external.write_text(textwrap.dedent("""\
        package com.cmyk.bookmarkslauncher;
        import java.net.URL;
        import com.cmyk.bookmarkslauncher.wishlist.WishlistGeneralMarketplaceIdentity;
        public class ExternalMarketplaceAccessHarness {
            public static void main(String[] args) throws Exception {
                URL expected = new URL("https://m.shein.com/jp/Dress-p-12345678.html");
                URL actual = new URL("https://www.shein.com/jp/Dress-p-12345678.html");
                if (!WishlistGeneralMarketplaceIdentity.sameItem(expected, actual))
                    throw new AssertionError("Public cross-package product identity failed");
                System.out.println("Cross-package marketplace access: PASS");
            }
        }
    """))
    subprocess.run(['javac','-encoding','UTF-8','-cp',str(root_tmp),'-d',str(root_tmp),str(external)],check=True)
    subprocess.run(['java','-cp',str(root_tmp),'com.cmyk.bookmarkslauncher.ExternalMarketplaceAccessHarness'],check=True)
print('Marketplace runtime wiring guards: PASS (7)')
