#!/usr/bin/env python3
"""v0.1.187 offline tests: shared URLs, Ali JPY offer forms, Temu challenge.
Does not assert live merchant access or a compiled Android APK.
"""
from pathlib import Path
import tempfile, subprocess
r=Path(__file__).resolve().parent.parent
base=r/'app/src/main/java/com/cmyk/bookmarkslauncher'
src=base/'wishlist'
page=(base/'WishlistPage.java').read_text()
dialog=(base/'ui/NDialog.java').read_text()
probe=(src/'WishlistPriceWebViewProbe.java').read_text()
assert 'SharedUrlPaste.attach(url)' in page and 'SharedUrlExtractor.extractOrOriginal' in page
assert 'SharedUrlPaste.attach(input)' in dialog and 'SharedUrlExtractor.extractOrOriginal' in dialog
assert 'profile=system-default first=true' in probe
assert 'profile=desktop reason=' in probe
assert 'offerShape=' in probe
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp)
    (d/'ShareHarness.java').write_text('''import com.cmyk.bookmarkslauncher.ui.SharedUrlExtractor;
public class ShareHarness { public static void main(String[] a) {
for (String s:a) System.out.println(SharedUrlExtractor.extractOrOriginal(s)); }
}''')
    subprocess.run(['javac','-encoding','UTF-8','-d',str(d),str(base/'ui/SharedUrlExtractor.java'),str(d/'ShareHarness.java')],check=True)
    samples=[
       'AliExpressでこんな商品見つけたよ： \nモールバックパックストラップバッグ電話ホルダーアウトドアスポーツランニングキャンプハイキングハンティングアクセサリーオーガナイザーEDCツールウエストポーチ\nhttps://a.aliexpress.com/_c4CsD1uR',
       'https://a.aliexpress.com/_c4CsD1uR',
       'Temuで見つけた https://www.temu.com/goods.html?goods_id=603206260252304。',
       '通常の https://shop.example.jp/item/123?variant=001 ですよ',
    ]
    want=['https://a.aliexpress.com/_c4CsD1uR','https://a.aliexpress.com/_c4CsD1uR',
          'https://www.temu.com/goods.html?goods_id=603206260252304','https://shop.example.jp/item/123?variant=001']
    out=subprocess.run(['java','-cp',str(d),'ShareHarness',*samples],text=True,capture_output=True,check=True).stdout.splitlines()
    assert out==want,(out,want)
    (d/'DomHarness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class DomHarness { public static void main(String[] a)throws Exception {
URL u=new URL(a[0]);System.out.print(WishlistGeneralMarketplaceIdentity.merchant(u)==WishlistGeneralMarketplaceIdentity.Merchant.TEMU?
WishlistTemuItemDom.javascript(u):WishlistAliItemDom.javascript(u));}}
''')
    subprocess.run(['javac','-encoding','UTF-8','-d',str(d),*[str(src/(n+'.java')) for n in ['WishlistGeneralMarketplaceIdentity','WishlistTemuItemDom','WishlistAliItemDom']],str(d/'DomHarness.java')],check=True)
    for i,u in enumerate(['https://www.temu.com/jp/goods.html?goods_id=603206260252304','https://ja.aliexpress.com/item/1005013255449296.html']):
        js=subprocess.run(['java','-cp',str(d),'com.cmyk.bookmarkslauncher.wishlist.DomHarness',u],text=True,capture_output=True,check=True).stdout
        (d/f'{i}.js').write_text(js)
        subprocess.run(['node','--check',str(d/f'{i}.js')],check=True)
    (d/'test.cjs').write_text(r'''const vm=require('vm'),fs=require('fs'),assert=require('assert');
const scripts=[0,1].map(i=>fs.readFileSync(process.argv[i+2],'utf8'));
const URLs=['https://www.temu.com/jp/goods.html?goods_id=603206260252304','https://ja.aliexpress.com/item/1005013255449296.html'];
function run(i,{body='A product page',heading='',title='Example store',products=[]}={}){
 const headings=heading?[{textContent:heading,closest:()=>null}]:[];
 const d={title,readyState:'complete',body:{innerText:body,textContent:body,children:[]},URL:URLs[i],
  querySelector:(s)=>null,
  querySelectorAll:(s)=>s==='script[type="application/ld+json"]'?products.map(x=>({textContent:JSON.stringify(x)}))
    :s==='h1,h2,[role="heading"]'||s.includes('h1')?headings:[]};
 const window={};return JSON.parse(vm.runInNewContext(scripts[i],{location:{href:URLs[i]},document:d,window,URL,Set},{timeout:3500}));
}
// Live Temu regression: a verification page includes a long H1 and plenty of DOM but NO product.
let v=run(0,{body:'Security verification: please confirm you are human before continuing. '.repeat(50),
 heading:'Please complete security verification'});
assert.equal(v.reason,'challenge-visible');assert.equal(v.title,'');assert.equal(v.value,'');
v=run(0,{body:'正常な商品詳細。防犯 security についての説明があります。',heading:'Quality Jacket for Hiking'});
assert.notEqual(v.reason,'challenge-visible','product review not a verification page');
const item={'@type':'Product',name:'Ali Hiking Strap Phone Holder',offers:{priceCurrency:'JPY',priceSpecification:{price:'1680',priceCurrency:'JPY'}}};
v=run(1,{products:[item]});assert.equal(v.value,'¥1680');assert.equal(v.title,item.name);
assert.equal(v.aliAudit.unlinkedPriceShape,'specification');
const range={...item,offers:{priceCurrency:'JPY',lowPrice:'1280',highPrice:'1980'}};
v=run(1,{products:[range]});assert.equal(v.value,'');assert.equal(v.title,'');
const equal={...item,offers:{priceCurrency:'JPY',lowPrice:'1280',highPrice:'1280'}};
v=run(1,{products:[equal]});assert.equal(v.value,'¥1280');
const us={...item,offers:{priceCurrency:'USD',priceSpecification:{price:'1680',priceCurrency:'JPY'}}};
v=run(1,{products:[us]});assert.equal(v.value,'');
const foreign={...item,url:'https://ja.aliexpress.com/item/1005013255449297.html',offers:{price:'1680',priceCurrency:'JPY'}};
v=run(1,{products:[foreign]});assert.equal(v.value,'');
console.log('Temu challenge H1, Ali JPY specification/price range, unrelated SKU: PASS (7)');
''')
    subprocess.run(['node',str(d/'test.cjs'),str(d/'0.js'),str(d/'1.js')],check=True)
print('Ali shared text -> URL, ordinary URL, Temu/Ali JS regression: PASS (4 + 7)')
