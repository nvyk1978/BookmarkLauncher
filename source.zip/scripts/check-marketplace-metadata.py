#!/usr/bin/env python3
"""Offline exact-item marketplace title and price evidence tests, Java and JS (no live network)."""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
probe=(src/'WishlistPriceWebViewProbe.java').read_text()
block=probe.split('actualJs = "(function(){try{var a=JSON.parse("',1)[1].split('\n        }',1)[0]
block='actualJs = "(function(){try{var a=JSON.parse("'+block
java='''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public class MarketplaceMetadataHarness {
 public static void main(String[] args) throws Exception {
  URL marketUrl = new URL("https://m.shein.com/jp/Shirt-p-12345678.html");
  String actualJs;
__MARKET_BLOCK__
  System.out.println("-----COMBINED-----");
  System.out.println(actualJs);
  System.out.println("-----ALI-----");
  System.out.println(WishlistGeneralMarketplaceVerifiedDom.javascript(new URL("https://ja.aliexpress.com/item/1005008877665544.html")));
  System.out.println("-----SHEIN-----");
  System.out.println(WishlistGeneralMarketplaceVerifiedDom.javascript(new URL("https://m.shein.com/jp/Shirt-p-12345678.html")));
  System.out.println("-----HYDRATION-----");
  System.out.println(WishlistGeneralMarketplaceHydrationDom.javascript(new URL("https://m.shein.com/jp/Shirt-p-12345678.html")));
 }
}
'''
java=java.replace('__MARKET_BLOCK__',block.replace('originalRetailUrl','marketUrl'))
js=r'''
const assert=require('assert');const fs=require('fs'),vm=require('vm');
const [ali,shein,hyd,combined]=process.argv.slice(2).map(s=>fs.readFileSync(s,'utf8'));
const a='https://ja.aliexpress.com/item/1005008877665544.html',s='https://m.shein.com/jp/Shirt-p-12345678.html';
function run(script,url,{canonical='',product=[],h1='',detail=true,price='',body='',win={}}={}) {
 const u=new URL(url);
 const heading=h1?{textContent:h1}:null;
 const target={querySelectorAll(sel){if(sel.includes('sale')||sel.includes('price'))return price?[{textContent:price,closest:()=>null}]:[];return [];}};
 const doc={readyState:'complete',body:{innerText:body},querySelector(sel){
  if(sel.startsWith('link['))return canonical?{href:canonical}:null;
  if(sel.includes(' h1')||sel.startsWith('h1'))return heading;
  return detail?target:null;
 },querySelectorAll(sel){if(sel.includes('application/ld+json'))return product.map(p=>({textContent:JSON.stringify(p)}));return [];}};
 const result=vm.runInNewContext(script,{document:doc,window:win,URL,location:{href:url,hostname:u.hostname,pathname:u.pathname}}, {timeout:2000});return JSON.parse(result);
}
let x=run(ali,a,{product:[{'@type':'Product',url:a,name:'Electric Widget ALI',offers:{price:'1280',priceCurrency:'JPY'}}]});
assert.equal(x.title,'Electric Widget ALI');assert.equal(x.value,'¥1280');assert.equal(x.source,'url-bound-jsonld');
x=run(ali,a,{product:[{'@type':'Product',url:a.replace('544','545'),name:'Wrong',offers:{price:'1280',priceCurrency:'JPY'}}]});assert.equal(x.title,'');assert.equal(x.value,'');
x=run(ali,a,{canonical:'https://ja.aliexpress.com/',product:[{'@type':'Product',url:a,name:'URL-Bound Product',offers:{price:'1280',priceCurrency:'JPY'}}]});assert.equal(x.title,'URL-Bound Product');assert.equal(x.value,'¥1280');assert.equal(x.canonical,'non-item');
x=run(ali,a,{canonical:'https://ja.aliexpress.com/item/1005008877665545.html',product:[{'@type':'Product',url:a,name:'Conflicting canonical',offers:{price:'1280',priceCurrency:'JPY'}}]});assert.equal(x.reason,'canonical-other-item');assert.equal(x.value,'');
x=run(shein,s,{canonical:s,h1:'Printed Linen Summer Shirt',detail:true,price:'¥1,290'});assert.equal(x.title,'Printed Linen Summer Shirt');assert.equal(x.value,'¥1290');
x=run(shein,s,{canonical:s,h1:'Printed Linen Summer Shirt',detail:true,price:'US $10.99'});assert.equal(x.title,'Printed Linen Summer Shirt');assert.equal(x.value,'');
x=run(shein,s,{canonical:'https://m.shein.com/jp/',h1:'Unbound site heading',price:'¥990'});assert.equal(x.title,'');assert.equal(x.value,'');
x=run(shein,s,{h1:'Bound product shirt',price:'¥990'});assert.equal(x.title,'Bound product shirt');assert.equal(x.value,'¥990');
x=run(shein,'https://m.shein.com/jp/',{canonical:s,h1:'Printed Shirt',price:'¥1290'});assert.equal(x.title,'');assert.equal(x.value,'');
x=run(shein,'https://m.shein.com/jp/',{canonical:'https://m.shein.com/jp/',product:[{'@type':'Product',url:s,name:'URL Bound Shirt',offers:{price:'1390',priceCurrency:'JPY'}}]});assert.equal(x.title,'URL Bound Shirt');assert.equal(x.value,'¥1390');
x=run(shein,'https://m.shein.com/jp/Another-p-12345679.html',{product:[{'@type':'Product',url:s,name:'Wrong Nav Shirt'}]});assert.equal(x.reason,'navigation-other-item');
x=run(shein,s,{product:[{'@type':'Product',url:s,name:'Linen Summer Shirt',offers:{price:'990',priceCurrency:'JPY'}},{'@type':'Product',url:s,name:'Conflicting Other Shirt'}]});assert.equal(x.title,'');assert.equal(x.value,'¥990');
x=run(shein,s,{product:[{'@type':'Product',url:s,name:'Sign in',offers:{price:'990',priceCurrency:'USD'}}]});assert.equal(x.title,'');assert.equal(x.value,'');
x=run(shein,s,{canonical:s,h1:'Summer Shirt',detail:false,price:'¥990'});assert.equal(x.title,'');assert.equal(x.value,'');
x=run(shein,s,{product:[{'@type':'Product',url:s,name:'Summer Shirt',offers:{price:'990',priceCurrency:'JPY'}}],body:'Robot check verify you are human'});assert.equal(x.reason,'challenge-visible');
let z=run(hyd,s,{win:{productIntroData:{goods_id:'12345678',goods_name:'Verified shirt title',salePrice:{amountWithSymbol:'¥990'}}}});assert.equal(z.title,'Verified shirt title');assert.equal(z.value,'¥990');
z=run(hyd,s,{win:{productIntroData:{goods_id:'12345679',goods_name:'Wrong item',salePrice:{amountWithSymbol:'¥990'}}}});assert.equal(z.title,'');
let combo=run(combined,s,{canonical:s,h1:'Summer Shirt',price:'¥990'});assert.equal(combo.title,'Summer Shirt');assert.equal(combo.value,'¥990');
combo=run(combined,s,{canonical:'https://m.shein.com/jp/',win:{productIntroData:{goods_id:'12345678',goods_name:'Bound shirt data',salePrice:{amountWithSymbol:'¥990'}}}});assert.equal(combo.title,'Bound shirt data');assert.equal(combo.value,'¥990');
combo=run(combined,s,{canonical:'https://m.shein.com/jp/Other-p-12345679.html',win:{productIntroData:{goods_id:'12345678',goods_name:'Contradicted Item',salePrice:{amountWithSymbol:'¥990'}}}});assert.equal(combo.title,'');assert.equal(combo.value,'');
combo=run(combined,'https://m.shein.com/jp/',{win:{productIntroData:{goods_id:'12345678',goods_name:'Verified Hydration',salePrice:{amountWithSymbol:'¥990'}}}});assert.equal(combo.title,'Verified Hydration');assert.equal(combo.value,'¥990');
console.log('Verified marketplace name/price fixtures: PASS (20)');
'''
with tempfile.TemporaryDirectory() as tmp:
 t=Path(tmp);f=t/'MarketplaceMetadataHarness.java';f.write_text(java)
 subprocess.run(['javac','-encoding','UTF-8','-d',str(t),str(src/'WishlistGeneralMarketplaceIdentity.java'),str(src/'WishlistGeneralMarketplaceVerifiedDom.java'),str(src/'WishlistGeneralMarketplaceHydrationDom.java'),str(src/'WishlistGeneralMarketplaceImageDom.java'),str(f)],check=True)
 result=subprocess.run(['java','-cp',str(t),'com.cmyk.bookmarkslauncher.wishlist.MarketplaceMetadataHarness'],capture_output=True,text=True,check=True).stdout
 ali=result.split('-----ALI-----\n')[1].split('-----SHEIN-----\n')[0].strip()
 sh=result.split('-----SHEIN-----\n')[1].split('-----HYDRATION-----\n')[0].strip()
 hy=result.split('-----HYDRATION-----\n')[1].strip()
 co=result.split('-----COMBINED-----\n')[1].split('-----ALI-----\n')[0].strip()
 for name,data in [('ali.js',ali),('shein.js',sh),('hyd.js',hy),('combined.js',co)]: (t/name).write_text(data)
 n=t/'test.js';n.write_text(js)
 subprocess.run(['node',str(n),str(t/'ali.js'),str(t/'shein.js'),str(t/'hyd.js'),str(t/'combined.js')],check=True)
price=(src/'WishlistPriceWebViewProbe.java').read_text()
image=(src/'WishlistRetailImageWebViewProbe.java').read_text()
repo=(src/'WishlistRepository.java').read_text()
page=(root/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
for label,good in {
 'price dispatches verified DOM': 'WishlistGeneralMarketplaceVerifiedDom.javascript(originalRetailUrl)' in price,
 'name captured from strict price DOM':'verifiedMarketplaceTitle=title' in price,
 'price name saved to card':'repo.updateVerifiedMarketplaceTitle(id,before.url,marketName)' in page,
 'image name recovered from same DOM':'WishlistGeneralMarketplaceVerifiedDom.javascript(originalRetailUrl)' in image,
 'image name saved to original card':'repo.updateVerifiedMarketplaceTitle(id,card.url,imageDomName)' in page,
 'repo refuses edited titles':'item.userTitleEdited' in repo[repo.index('public boolean updateVerifiedMarketplaceTitle'):],
 'repo verifies original URL and GENERAL mode':'WishlistGeneralMarketplaceIdentity.isDetail(new java.net.URL(expectedUrl))' in repo,
 'existing image gallery retained':'WishlistGeneralMarketplaceImageDom.javascript(originalRetailUrl)' in image,
}.items():
 if not good:raise AssertionError(label)
print('Metadata source wiring tests: PASS (8)')
