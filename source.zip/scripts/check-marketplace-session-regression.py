#!/usr/bin/env python3
"""v0.1.173: test real Java evidence accumulator and merchant routing gates.
This tests offline logic, NOT live service reachability or an Android APK build.
"""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parent.parent
s=r/'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
p=(s/'WishlistPriceWebViewProbe.java').read_text()
page=(r/'app/src/main/java/com/cmyk/bookmarkslauncher/WishlistPage.java').read_text()
assert 'retainedMarketPrice.offer(price)' in p
assert 'marketDocumentGeneration++' in p and 'evaluatingMarketGeneration!=marketDocumentGeneration' in p
assert 'retainedMarketPrice.get()' in p
assert 'retainedMarketPrice.clear();' in p[p.index('@Override public void onPageStarted'):p.index('@Override public void onPageFinished')]
assert 'retainedMarketPrice.clear();' in p[p.index('if (guardedHydration) {',p.index('view.evaluateJavascript(actualJs, returned')):p.index('JSONArray snapshotImages=')]
assert 'reason=item-left-to-unbound-page' in p
assert 'WishlistGeneralMarketplaceIdentity.ItemRelation.UNKNOWN' in p
assert '&& (guardedSavedMarketplace\n                            || isVerifiedSingleProductUrl(pageUrl)' in page
assert 'final boolean unifiedMarketSnapshot = serialGeneralPrice && guardedSavedMarketplace;' in page
assert 'repo.updateVerifiedOtherMarketplaceStock(id,before.url,sheinStock)' in page
assert 'repo.updateImageFromWebView(id, image, before.url' in page
with tempfile.TemporaryDirectory() as tmp:
    t=Path(tmp)
    (t/'SessionEvidenceHarness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
public class SessionEvidenceHarness {
 static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
 public static void main(String[] args){
   WishlistMarketplacePriceEvidence x=new WishlistMarketplacePriceEvidence();
   check(x.get()==null,"initial");
   x.offer(242L);check(x.get()==242L,"first price");
   x.offer(null);check(x.get()==242L,"keep across no-price title poll");
   x.offer(null);check(x.get()==242L,"keep across no-price image poll");
   x.offer(242L);check(x.get()==242L,"repeat same price");
   x.clear();check(x.get()==null,"new navigation clears price");
   x.offer(242L);x.offer(243L);
   check(x.get()==null&&x.conflicted(),"conflict must fail closed");
   x.offer(242L);check(x.get()==null,"conflict never repairs without navigation");
   x.clear();x.offer(999L);check(x.get()==999L&&!x.conflicted(),"new same-item session");
   System.out.println("Marketplace session price accumulation: PASS (9)");
 }
}''')
    subprocess.run(['javac','-encoding','UTF-8','-d',str(t),str(s/'WishlistMarketplacePriceEvidence.java'),str(t/'SessionEvidenceHarness.java')],check=True)
    subprocess.run(['java','-cp',str(t),'com.cmyk.bookmarkslauncher.wishlist.SessionEvidenceHarness'],check=True)
print('v0.1.173 marketplace entry, item-bound stock/image and Temu navigation guards: PASS (8)')
