#!/usr/bin/env python3
"""v0.1.182 Mercari H regression: actual Java-generated JS + Node synthetic DOM.
No live Mercari pages or Android WebView are claimed by this test.
"""
import hashlib
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parent.parent
src = root / 'app/src/main/java/com/cmyk/bookmarkslauncher/wishlist'
stock = (src/'WishlistAvailabilityWebViewProbe.java').read_text()
alph = (src/'WishlistGeneralAlphabetDom.java').read_text()
mercari = (src/'WishlistMercariItemStockDom.java').read_text()
assert "FALLBACK_ORDER = {'B','C','D','E','F','G','H'}" in alph
assert "if (stage == 'H') return WishlistMercariItemStockDom.javascript(url);" in alph
assert "case 'H' -> \"exact-listing-state\"" in (src/'WishlistGeneralEvidenceTechniques.java').read_text()
assert 'publishMode("GENERAL 000")' in stock
assert 'beginPageInspection("mode-numbered-complete")' in stock
assert 'WishlistGeneralShopItem.merchant(original)==WishlistGeneralShopItem.Merchant.MERCARI' in stock
assert 'details.optBoolean("bound",false)' in stock
assert 'details.optInt("heading",0)==1' in stock
assert 'details.optBoolean("heroPrice",false)' in stock
assert 'if(mercariVerified){finish(generalFirstVerified);return;}' in stock
assert 'WishlistMercariItemStockDom.javascript(original)' in stock, 'Dedicated Mercari fallback must remain'
assert 'main.postDelayed(modeWindowTimeout, 15000L)' in stock
assert 'main.postDelayed(pageWindowTimeout,15000L)' in stock

with tempfile.TemporaryDirectory(prefix='mercari-h-') as d:
    td=Path(d); pkg=td/'com/cmyk/bookmarkslauncher/wishlist'; pkg.mkdir(parents=True)
    (pkg/'WishlistCrawler.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL; public final class WishlistCrawler {
  public static boolean isAllowedUrl(URL url){return url!=null && url.getUserInfo()==null;}
  public static boolean isSingleProductPage(URL url){return WishlistGeneralShopItem.isDetail(url);}
}''')
    (pkg/'WishlistGeneralVariantStockDom.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL; public final class WishlistGeneralVariantStockDom {
  public static String source(URL url){return "JSON.stringify({status:'UNKNOWN',reason:'not-zozo'})";}
}''')
    (pkg/'WishlistGeneralProductIdentity.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL; public final class WishlistGeneralProductIdentity {
  public static String code(URL url){return "";}
}''')
    (pkg/'MarketplaceIdentity.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL; public final class MarketplaceIdentity {
  public enum Site {OTHER} public static Site site(URL url){return Site.OTHER;}
}''')
    jp=td/'org/json/JSONObject.java';jp.parent.mkdir(parents=True)
    jp.write_text('''package org.json; public final class JSONObject {
  public static String quote(String s){return "\\\""+s.replace("\\\\","\\\\\\\\").replace("\\\"","\\\\\\\"")+"\\\"";}
}''')
    (pkg/'Harness.java').write_text('''package com.cmyk.bookmarkslauncher.wishlist;
import java.net.URL;
public final class Harness {
 public static void main(String[] args) throws Exception {
  if (!new String(WishlistGeneralAlphabetDom.FALLBACK_ORDER).equals("BCDEFGH")) throw new AssertionError("order");
  if (!WishlistGeneralEvidenceTechniques.label('H').equals("exact-listing-state")) throw new AssertionError("label");
  System.out.println("###MERCARI###");
  System.out.println(WishlistGeneralAlphabetDom.source(new URL("https://jp.mercari.com/item/m25470772768"),'H'));
  System.out.println("###OTHER###");
  System.out.println(WishlistGeneralAlphabetDom.source(new URL("https://www.gu-global.com/jp/ja/products/E344712-000/00"),'H'));
  System.out.println("###BAD###");
  System.out.println(WishlistGeneralAlphabetDom.source(new URL("https://jp.mercari.com/search?keyword=bag"),'H'));
  System.out.println("###END###");
 }
}''')
    files=[*(pkg/x for x in ('WishlistCrawler.java','WishlistGeneralVariantStockDom.java','WishlistGeneralProductIdentity.java','MarketplaceIdentity.java','Harness.java')),jp,*(src/x for x in ('WishlistGeneralAlphabetDom.java','WishlistGeneralEvidenceTechniques.java','WishlistMercariItemStockDom.java','WishlistGeneralShopItem.java'))]
    cp=subprocess.run(['javac','-encoding','UTF-8','-d',str(td),*(str(f) for f in files)],capture_output=True,text=True)
    assert cp.returncode==0, cp.stderr
    rp=subprocess.run(['java','-cp',str(td),'com.cmyk.bookmarkslauncher.wishlist.Harness'],capture_output=True,text=True)
    assert rp.returncode==0,rp.stderr
    a=rp.stdout.split('###MERCARI###\n')[1].split('\n###OTHER###')[0]
    b=rp.stdout.split('###OTHER###\n')[1].split('\n###BAD###')[0]
    c=rp.stdout.split('###BAD###\n')[1].split('\n###END###')[0]
    (td/'h.js').write_text(a)
    (td/'other.js').write_text(b)
    (td/'bad.js').write_text(c)
    (td/'tests.cjs').write_text(r'''const vm=require('vm'),fs=require('fs'),assert=require('assert');
const mainScript=fs.readFileSync(process.argv[2],'utf8');
const otherScript=fs.readFileSync(process.argv[3],'utf8');
const badScript=fs.readFileSync(process.argv[4],'utf8');
new vm.Script(mainScript);
const good='https://jp.mercari.com/item/m25470772768';
const id='m25470772768';
let count=0;
function run(opts={}) {
 const {url=good,canonical=null,globals=true,states=['on_sale'],ld=null}=opts;
 const rows=states.map(s=>typeof s==='string'?{id,name:'Exact same listing name',price:{amount:3000},status:s}:s);
 const data={props:{pageProps:{item:rows[0],entries:rows.slice(1)}}};
 const doc={
 querySelector:selector=>selector==='link[rel=canonical]'&&canonical?{href:canonical}:null,
 querySelectorAll:selector=>selector==='script[type="application/ld+json"]'&&ld?[{textContent:JSON.stringify(ld)}]:[]
 };
 const context={URL,location:new URL(url),document:doc,window:globals?{__NEXT_DATA__:data}:{}};
 return JSON.parse(vm.runInNewContext(mainScript,context,{timeout:1000}));
}
function check(value,expected,label){assert.strictEqual(value.status,expected,label+JSON.stringify(value));count++;}
check(run(), 'AVAILABLE','live listing');
check(run({states:['sold_out']}),'UNAVAILABLE','sold listing');
check(run({states:['sold-out']}),'UNAVAILABLE','hyphen sold');
check(run({states:['available']}),'AVAILABLE','available listing');
check(run({states:['on_sale','sold_out']}),'UNKNOWN','contradictory states');
check(run({states:[{id:'m25470772769',name:'Other listing',price:3000,status:'on_sale'}]}),'UNKNOWN','other item');
check(run({states:[{id,name:'Exact listing',price:0,status:'on_sale'}]}),'UNKNOWN','no valid price');
check(run({states:[{id,name:'',price:3000,status:'on_sale'}]}),'UNKNOWN','no name');
check(run({states:[{id,itemId:'m25470772769',name:'Conflict',price:3000,status:'on_sale'}]}),'UNKNOWN','contradictory ID');
check(run({url:'https://jp.mercari.com/item/m25470772769'}),'UNKNOWN','wrong URL');
check(run({canonical:'https://jp.mercari.com/item/m25470772769'}),'UNKNOWN','wrong canonical');
check(run({url:'https://jp.mercari.com/search?keyword=bag'}),'UNKNOWN','listing');
check(run({globals:false}),'UNKNOWN','no state');
check(run({globals:false,ld:{'@type':'Product',url:good,name:'Correct listing item',offers:{price:3000,availability:'https://schema.org/InStock'}}}),'AVAILABLE','bound JSON-LD');
check(run({globals:false,ld:{'@type':'Product',url:'https://jp.mercari.com/item/m25470772769',name:'Other listing',offers:{price:3000,availability:'https://schema.org/InStock'}}}),'UNKNOWN','unbound JSON-LD');
check(JSON.parse(vm.runInNewContext(otherScript,{URL,location:new URL('https://www.gu-global.com/jp/ja/products/E344712-000/00')},{timeout:1000})),'UNKNOWN','GU is not Mercari');
check(JSON.parse(vm.runInNewContext(badScript,{URL,location:new URL('https://jp.mercari.com/search?keyword=bag')},{timeout:1000})),'UNKNOWN','search not Mercari item');
console.log('Mercari alphabet H Java-generated JS fixtures:',count,'PASS');
''')
    np=subprocess.run(['node',str(td/'tests.cjs'),str(td/'h.js'),str(td/'other.js'),str(td/'bad.js')],capture_output=True,text=True)
    assert np.returncode==0,np.stderr
    print(np.stdout.strip())
print('H ordering, exact item guards, early positive/negative proof, dedicated fallback, and 15s windows: PASS')
