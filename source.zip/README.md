# BookmarkLauncher 0.1.94 (versionCode 95) — 三大通販サイトの商品照合改善
- 唯一のベース：`BookmarkLauncher_0.1.93_source.zip`（versionCode 94）。`applicationId`、固定keystore、GitHub Actionsの2つのYMLは維持。
- Amazon.co.jp（ASIN）、楽天市場の商品URL（店舗ID＋商品ID）、Yahoo!ショッピングの商品URL（店舗ID＋商品ID）を商品詳細URLとして認識する専用 `MarketplaceIdentity` を追加。canonical が別商品なら、そのページから商品データを更新しない。商品詳細以外のページは関連商品の解析にフォールバックしない。
- 対象商品の JSON-LD はURL/ASIN照合を優先し、最初の無関係な `Product` を採用しない。商品名・画像・価格・購入可否はそれぞれ独立した解析クラスとし、既存の一般通販サイト向け実装を維持。
- Amazon画像：HTML全体の `hiRes / large / mainUrl` 先頭一致を廃止。メイン商品 `landingImage` 等からのみ候補を抽出し、関連商品を採用しない。手動「情報更新」では以前の自動取得画像が保存済みでも、メイン商品WebView画像を再検証して差し替え可能。手動画像は変更しない。
- 楽天・Yahoo画像：対象商品JSON-LDの `image`、canonical一致商品ページのOGP、専用主画像領域だけを候補として利用。非表示WebView補完も別商品への遷移を拒否、商品メイン画像領域に限定。
- 価格：対象商品JSON-LDのJPY Offerのみ、複数異なる価格は確定値としない。Amazon Buy Box、商品固有の価格メタや専用DOMを補完。AggregateOfferは下限/範囲として区別し、確定価格履歴へ入れない。送料や関連商品価格を使わない。
- 購入可否：対象ProductのOffers（競合バリエーションはUNKNOWN）と対象商品の有効なカート操作だけを利用。商品外の売切れ・カートは無視。手動更新のWebView補完も各サイトの商品IDを確認し、専用購入領域を調べる。推測で販売可能/終了とはしない。
- 既存の商品データ、価格履歴、画像、サイト状態、購入履歴を初期化せず、ユーザーが設定した名前・画像を保護。取得失敗で成功済みデータを削除しない。
- 検証：Java構文検査、独立パーサーのJDK型検査、HTML擬似テスト23件、WebView内JS4件構文検査、GitBuild前提チェック、keystore SHA256/証明書、ZIP整合性。**Gradle実ビルド、GitHub Actions、実機検証、現行の3サイトHTMLでの成功確認は未実施。** サイトの認証/アクセス制限時は取得できない場合がある。

# BookmarkLauncher 0.1.93 (versionCode 94) — Stock evidence and search polish
- Only base: BookmarkLauncher_0.1.92_source.zip (versionCode 93). Stable applicationId/signing/workflows preserved.
- Wish card action label: `今すぐ更新` -> `情報更新`, no behavior change.
- Pinned search-condition card: `閉じる / クリア / 再検索` in equal positions. Close exits search and restores the original list; Clear empties only draft keyword/prices/tags without closing; Re-search applies the draft.
- Android 11+ IME animation callback makes the pinned search card track the keyboard's insets while opening/closing; the existing one-tap outside-to-dismiss and Home behavior remain.
- Independent availability parser: selects URL-matching product JSON-LD rather than first related-product offer, treats conflicting variants as UNKNOWN, avoids page-wide sold-out signals, recognizes product detail paths and scoped active cart controls. This is conservative: unknown items without trustworthy item-specific evidence stay UNKNOWN.
- Manual-refresh-only, bounded hidden WebView checks for a visible enabled cart in a cart-specific form (only upgrades an UNKNOWN result to AVAILABLE). Notes-selected product sections are also inspected for a strictly scoped cart form. No modification to existing image/price/title extractors, site-state logic, GitBuild YAML, or historical data. Availability improvements are static source changes and are NOT yet verified against live retailer HTML or on-device.

# BookmarkLauncher 0.1.92 (versionCode 93) — Wishlist UI and horizontal swipe improvements
- Unique base: `BookmarkLauncher_0.1.91_source.zip` (versionCode 92), preserving applicationId, stable signing keystore and both GitHub Actions workflows.
- Search dialog **Clear** empties only the editable keyword, price and selected tag chips without closing the dialog or altering applied search state. The pinned search-filter panel retains its distinct Clear-to-exit behavior.
- Wish-card tag selection: buttons are **Cancel (left) / Apply (right)**. Only Apply saves tag membership; cancel/back/outside dismisses without saving a draft.
- Wishlist floating tag icon outer diameter is 58dp, matching the floating Add icon; tag symbol remains centered with its prior glyph size/colors.
- Horizontal Home/Wishlist swipe: warm up page before drag, never reconstruct all card Views at gesture start, refresh only when SQLite external data_version changes, adjust horizontal gesture threshold to 12dp, use release velocity plus distance for commit and responsive landing animation. Grips on cards and visible fast-scroll thumb are excluded from page-swiping.
- Fast-scroll thumb finishes its 260ms opacity fade around 1 second after scrolling stops (740ms idle + 260ms fade), including search results.
- Product extraction, price, images, stock/site diagnostics, stored card/purchase data, GitBuild workflows and app signing unchanged.
- Verified: JDK 17 Java parser on all 53 Java sources, prepare-build invariants, ZIP test, keystore hash/certificate. Not verified: full Gradle Android APK build, GitHub Actions, or physical device behaviors.

# BookmarkLauncher 0.1.88 (versionCode 90) — 在庫誤判定の修正
- 正本: BookmarkLauncher_0.1.87_source.zip (versionCode 88)。applicationId・固定署名を維持。
- 購入可否を `WishlistAvailabilityExtractor` に独立分離。ページ全体の「売り切れ」「完売」「在庫切れ」を商品自身の購入不可判定に使わない。
- 商品詳細URL上で一意に紐づく構造化商品データを優先。購入ボタンと構造化情報が矛盾すれば UNKNOWN（状態未確認）、状態不明時にも誤って購入不可を出さない。
- 旧DB v7 → v8 は非破壊。古い購入不可フラグのみ解除し、商品・価格・履歴・画像・タグ・サイト状態を維持。次回更新時に購入可否を再判定する。
- 不室屋 `product/detail/300840` と由比缶詰所 `dispatch=products.view&product_id=17` の在庫誤判定を対象とする。現物のDOMおよび実機での成功は未確認。
- 商品名／価格／画像抽出コード、WebView画像補完、サイト状態解析、YML、署名は変更しない。
- Gradle実ビルドと実機動作は未検証。

# BookmarkLauncher 0.1.87 (versionCode 88) — Wishlistサイト状態と操作改善
- 唯一のベース: `BookmarkLauncher_0.1.86_source.zip`。`com.cmyk.bookmarkslauncher`、固定署名と既存Workflow維持。
- 最低価格 (`¥500～`) はそれだけで購入不可判定しない。商品名・価格・画像の解析とサイト状態診断を分離。
- サイト状態 (メンテナンス/404・410/403・429/タイムアウト/接続障害/5xx) を独立DB列で管理。旧商品データと価格履歴を保持。
- カードの現在欄に異常注釈と「前回取得」を表示。正常復旧時は注釈解除。
- 削除ダイアログをNカプセル型に。並べ替えグリップはヒット領域を維持して左へ移動・中央寄せ。
- 商品名が未取得またはURL形式なら共有本文はURL1件のみ。
- 本ZIPはGradle実ビルドと実機取得は未検証。

# BookmarkLauncher 0.1.86 (versionCode 87) — 一般通販商品画像の取得改善
- 唯一の正本: `BookmarkLauncher_0.1.85_source.zip` (0.1.85 / versionCode 86)。固定署名と `com.cmyk.bookmarkslauncher` を維持。
- 対象: 中嶋屋本店 `item-detail/1000086`（同一商品の画像ギャラリー2枚）、松浦漬本舗 `item_detail_0000016.html`（URLの商品番号と一致するJPG）。
- 商品詳細のHTMLから高確度の画像候補を抽出する独立した `WishlistRetailImageCandidates` を追加。商品番号／ギャラリー／専用画像CDNを根拠として絞り込み、ロゴ・バナー・関連商品は除外する。
- 通常取得で画像が保存できなければ、商品詳細ページの候補画像を順番に試す。画像の個別ダウンロードが失敗しても次の候補を試し、商品ページのRefererを渡す。
- 非表示WebView画像補完を複数候補対応に改修。商品番号に一致するURL、商品ギャラリー、大きな商品画像を優先。発見した候補を順次保存し、失敗した1枚で処理を打ち切らない。
- 商品名・価格・価格履歴・Amazon専用取得・八百三備考欄解析・既存DB・ホーム/Wishlist UI・YMLは変更しない。手動設定画像も上書きしない。
- 検証: JVM画像候補テスト5例、DOM JS 3例、WebViewクラスのAndroid代替APIコンパイル、JS構文、固定署名とGitBuild事前チェック、ZIP整合性。実際のAndroid Gradleビルド・実機取得は未確認。

# BookmarkLauncher 0.1.85 (versionCode 86) — 一般通販価格/画像補完
- 唯一のベース: BookmarkLauncher 0.1.84 (85) の source.zip。
- 商品詳細判定: /product/170, /item-detail/1000086, /item_detail_0000016.html, CS-Cart `index.php?dispatch=products.view&product_id=17` を追加。商品一覧は対象外。
- 最低価格/価格範囲の表示: `500円～` は `¥500～` として別カラム保存、確定価格履歴には書き込まない。既存の登録価格・履歴は維持。
- 日本向け商品の販売価格を詳細ページ近傍から抽出。本文全体の最初の金額、送料、追加オプションを推測採用しない。
- 商品名・画像・価格の解析は分離したまま、既存のAmazon/八百三/不室屋向けコードを保護。
- 固定署名・applicationIdを維持。実機・実サイトの成功は未検証。

# BookmarkLauncher 0.1.84 (85) — Wishカード整列・一般通販の商品画像／価格補完
- 正本は `BookmarkLauncher_0.1.83_source.zip` (versionCode 84) のみ。applicationIdと固定署名を維持。
- Wishカード下部の操作順：左「削除」／中央「今すぐ更新」／右「商品ページ」。均等幅、間隔8dp。
- 展開時の上部：商品名・URLを上詰め、可変スペース、商品名編集・画像編集、備考欄を下詰めにし、画像140dpと右側の高さを合わせる。編集ボタン間6dp、備考欄まで6dp、画像との間隔12dp。
- 「現在購入不可」は独立したヘッダ注釈ではなく、展開時の「現在」価格欄へ移動。格納状態は従来の状態表示を維持。
- タグ選択ダイアログ：左「適用」、右「閉じる」に入れ替え、ボタン間8dp。既存の処理は維持。
- Wishカード追加：URLと備考欄を同一44dp高さ・同じ幅・上下8dp間隔に統一、下部操作は8dp間隔。
- 商品詳細URL（例：`/product/detail/300840`）では備考欄を商品一覧解析の絞り込みに使わず、そのURLの商品を優先。備考欄による八百三型の一覧商品選択は従来通り。
- 手動更新時、一般通販の商品詳細ページの画像が未保存の場合に限り、別クラス `WishlistRetailImageWebViewProbe` が非表示WebViewで商品画像URLを補完。Amazon専用画像取得と完全分離。画像のみ保存し、価格・商品名は変更しない。
- 価格WebViewは商品詳細URLに限り一般通販の価格セレクタと近傍の単一円価格を追加、空結果は限定回数再確認。Amazon専用抽出・価格保存先は維持。関連商品・送料・複数候補は誤採用防止。
- 済：WebView解析JavaScript文法検査、ローカル価格5件・画像3件、WebView新規／改修クラスの代替Android APIコンパイル、署名・ZIP・ビルド前検査。
- 未実施：実Android SDK Gradleビルド、実サイト通信、実機UIの表示・取得検証。商品ページからの取得はサイトの配信・制限次第で失敗する可能性がある。

# BookmarkLauncher 0.1.83 (84) — Wishlist備考欄・余白・ダイアログ配置
- 正本は 0.1.82 (versionCode 83) の source.zip のみ。固定署名と applicationId を維持。
- Wishカード展開：140dp画像と右側全体（商品名・URL・編集ボタン・備考欄）を同じ縦幅に配置。備考欄は編集ボタンと同じ30dp高、未入力表示は「備考欄」。カード毎にテキストを即時保存。
- Wishカード追加ダイアログの題字を「Wishカード追加」にし、URL（未入力時「URL」）直下に備考欄を設置。
- DB v4→v5 非破壊移行で note 列追加。既存の商品、画像、価格、タグ、履歴を保持。
- 備考欄を商品キーワードとして使う場合、同じページの一致する商品見出しの範囲のみ画像と価格を抽出。画像／価格解析は別クラス。候補価格が複数ある場合は取得しない。通常のAmazon専用抽出ロジック・WebView補完は改変しない。
- タグ選択ダイアログ：左「閉じる」、右「適用」。既存の保存動作は維持。
- Wishカードのスクロール末尾に112dpのスペースを置き、フロートボタンと操作ボタンが重ならないようにする。検索中は16dp。
- Android Gradle実コンパイル・実機検証は未実施。

# BookmarkLauncher 0.1.81 (versionCode 82) — Wishlist監視ボタン移設と共有アイコン

- 正本は `BookmarkLauncher_0.1.80_source.zip` (0.1.80 / versionCode 81)。
- Wishlist展開カードの再開監視ボタンを、価格ステータスの右側へ移動。横に共有丸アイコンを追加。
- 共有時はAndroid共有シートを開き、商品の名称・URLをテキストで共有。
- N規格色・円形の共有ベクターを使用。NS本体ソースが未確認のためアイコン完全一致は未確認。
- 商品名・価格・Amazon画像の取得経路、DB、タグ、履歴、署名、YMLは変更なし。
- Java構文、ビルド前設定、ZIPの整合性を確認。Gradle実ビルド・実機動作は未検証。

# BookmarkLauncher 0.1.80 (versionCode 81) — PriceRecタグ管理移植・Wishlist丸ボタン修正

- **唯一の正本**： `BookmarkLauncher_0.1.79_source.zip` (versionCode 80)。applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。
- 通常時は従来の＋丸（URL追加）・虫眼鏡（検索）を右下に復活。左下のPriceRec丸タグアイコンも表示。テキスト操作ボタンは廃止。
- 検索条件カード表示中は、＋丸・虫眼鏡・タグ丸をすべて非表示。条件カードは画面最下部に固定し、リストのスクロールとは独立。
- PriceRec v0.1.81を参照し、タグ管理を改修：行タップで選択・解除、複数選択時の「削除」（確認あり）、選択中「キャンセル」／通常「OK」、タグ追加は管理ダイアログ内、行長押しで名前編集、左端☰グリップ長押しで指に追従するアニメーション並べ替え。並び順はドロップ時だけ保存。
- タグ追加・改名・削除後も管理ダイアログを維持し、一覧をその場で更新。商品別タグ選択もグリップ・選択強調・長押し編集に統一し、改名後も選択ダイアログを保持。
- Amazonの商品名・価格・画像取得モジュール、WebView補完・DB、MainActivity、YML、署名は変更なし。変更範囲はWishlistPage.java、バージョンと事前検査、READMEに限定。
- ビルド事前検査・ZIP整合性・Java構文静的検査を実施。Android SDK/Gradleによる実ビルドと実機動作は未確認。

# BookmarkLauncher 0.1.79 (versionCode 80) — Wishlist検索UI・Android Back・PriceRecタグアイコン

- 正本は **`BookmarkLauncher_0.1.78_source.zip` のみ**。アプリID `com.cmyk.bookmarkslauncher` と固定署名を維持。
- 検索ダイアログ：不要な「価格更新」ボタンを撤去し、左から **「閉じる／クリア／検索」**。旧「適用」を「検索」に変更。
- 検索条件カードは **画面最下部に固定**。Wishカード一覧の縦スクロールから分離。検索語句・価格・タグの編集と「再検索」「クリア」は維持。
- Wishリストの旧「＋丸」「虫眼鏡」フローティングアイコンを撤去。商品登録・検索の入口を保つため、検索していないときは下部に **「URL追加」「検索」** の文字ボタンを表示する。検索中は検索条件カードに切り替わる。
- 画面左下には PriceRec v0.1.81 の `TagManageIconView` と同一のベクター描画による **48dpのNグレー丸型タグ管理アイコン**を移植。クリックするとWishリストのタグ作成・名称変更・削除を行える。タグの紐付け処理は変更しない。
- Android 13以降の端末バック／ジェスチャーバックを `OnBackInvokedDispatcher` でWishリスト表示中に受ける。検索条件表示中は「クリア」と同じ復帰処理（展開状態・スクロール位置を復元）。非検索中はホームへ戻る。ホーム側の端末バック挙動は維持。
- Amazonの商品名・価格・画像の解析と WebView 補完、データベース、ホーム/Wishlist横スワイプ、カード開閉・並べ替えアニメーション、画像手動設定の処理は変更しない。
- Java全44ファイル構文検査とビルド前検査は実施。ただし Gradle/Android SDK の実コンパイルと実機動作は未実施。

# BookmarkLauncher 0.1.78 (versionCode 79) — Wishlist検索条件パネル・手動画像編集

- 正本は `BookmarkLauncher_0.1.77_source.zip`（0.1.77 / versionCode 78）のみ。
- Wishlist検索・絞り込みを実行すると、結果リスト上部に **検索語句・最低価格・最高価格・タグ** の編集パネルを表示する。編集するだけでは検索結果は変わらず「再検索」で適用、クリアまたは Android 端末バックで条件をすべて解除し、検索前のカード展開状態・スクロール位置を復元。
- タグは選択済みのものをチップ表示し、チップの×で候補から外し、「＋ タグ」からタグ一覧を編集。適用は再検索ボタンで確定。
- カード展開時の旧「商品名を編集」は「商品名編集」に短縮。隣に「画像編集」を新設し、Androidのシステム画像選択画面から任意の画像を選択、端末内に縮小JPEGを保存する。
- 手動設定画像は自動取得画像とは別ファイルに保存。`user_image_edited` フラグで自動取得が手動画像を上書きしないよう保護（DB v3→v4、非破壊マイグレーション）。画像データ以外の既存商品情報・価格履歴・タグに影響させない。
- 成功済み商品名・価格・Amazon画像の抽出器、ネット取得処理、WebView補完、署名、applicationId、YMLは変更しない。
- 検証：全Javaソースの構文診断（Androidライブラリ未解決を除く）、コード/DB更新経路の静的チェック、build invariants、ZIP整合性。Android SDK が無いため Gradle実ビルド・実機は未確認。

# BookmarkLauncher 0.1.77 (versionCode 78) — Amazon画像取得・WebView表示不具合修正

- 正本は直前の `BookmarkLauncher_0.1.76_source.zip`（0.1.76 / versionCode 77）のみ。
- Wishリスト内部で描画されていた画像・価格補完用WebViewを非表示（alpha=0、フォーカス不可）とし、ページの背面も不透明化。WebViewはレイアウトに接続したままDOMを検査する。
- Amazonの画像解析を価格・商品名のロジックから独立した `AmazonProductImageExtractor` で補完。高解像度URL、遅延読み込み属性を解析し、商品画像CDNの `/images/I/` のみ採用。
- 画像WebViewは1回で画像が見つからなくても限定回数だけ再試行し、タイムアウトで終了。サイトの制限やCAPTCHAの回避は行わない。
- 1pxのダミーや小さすぎる画像は保存成功と見なさず、過去に保存した無効なサムネイルも再取得対象にする。
- 商品名・価格の解析器、DB価格履歴、タグ、カードアニメーション、ホーム連動スワイプは変更なし。価格補完WebViewは**非表示設定のみ**変更。
- `applicationId=com.cmyk.bookmarkslauncher`、固定署名、既存データ、YMLは維持。Android Gradle実ビルド・Amazon実サイト・実機での確認は未実施。

# BookmarkLauncher 0.1.76 (versionCode 77) — Amazon画像取得不具合修正

- 0.1.75 (76) source.zip を唯一の正本として使用。
- Amazonの画像が通常HTML取得で保存されなかった場合、手動「今すぐ更新」で商品画像専用のWebView補完を起動。
- Amazonのメイン商品画像のみDOMから取得し、HTTPSのAmazon画像CDN URLに限定して保存する。
- 画像ダウンロードに商品ページのRefererなど一般的なHTTPヘッダーを付与。
- 価格解析器、価格WebView、商品名解析器、DB価格履歴のロジックは変更しない。
- アプリID、固定署名、データスキーマ、YMLは変更なし。
- Android Gradleの本番コンパイルと実際のAmazon商品ページでの取得は未確認。

# BookmarkLauncher 0.1.75 (76)

## 0.1.75 — Wishlist price/metadata pipeline isolation + free foreground WebView price fallback
- Base **only** on 0.1.74 (75). Keep applicationId and stable signing keystore unchanged; code increment to 76.
- `WishlistMetadataExtractor`: name, hero-image and availability parsing only; does not import/use price logic.
- `WishlistPriceExtractor`: JPY prices from Product JSON-LD, OGP/meta, itemprop, and product-heading-localized yen text; does not consume a title from the metadata extractor. Price values must be scoped to product data.
- `AmazonPriceExtractor`: separate Amazon.co.jp current-price HTML detection (no product-name logic).
- `WishlistCrawler`: HTTP transport and two independent parser invocations only. A failure in one parser cannot suppress the other.
- `WishlistRepository`: independent metadata and price database write paths. A price lookup never changes the product name/image; image fetching errors do not invalidate stored price. Existing records, titles, pictures, tags and historical prices are preserved.
- Manual **今すぐ更新**: if direct HTML lookup has no price, try `WishlistPriceWebViewProbe` once for the same product. The probe reads current-price DOM selectors, explicit JPY meta and Product JSON-LD, and writes **price only** to local history. It has a 14-second timeout and refuses non-HTTPS/unsafe URLs; browser restrictions/CAPTCHA are not bypassed. No paid API, tracking server, automatic WebView background crawling, or unlimited retry loops.
- Scheduled/background jobs continue using direct HTML only; WebView runs only on an explicit foreground update.
- This source has static checks, stub Java compilation and 11 sample cases; a full Android Gradle build and real site/device integration test are not available in this environment.

# BookmarkLauncher 0.1.74 (75)

## 0.1.74 (75) — Wishlist price detection reliability fix
- Preserve existing 0.1.73 UI/gesture behavior. Improve only price parsing for Japanese merchant pages lacking metadata by extracting explicit yen prices from the vicinity of a matching product heading.
- Support itemprop price values written in an element body. Do not infer arbitrary page prices or prices from shipping/recommendations.
- Show useful failure reasons (HTTP code, timeout, price not found) and persist them with a non-destructive Wishlist DB v2→v3 migration.
- Existing Wishlist records, manual titles, images, tags, sorting, price history and signing identity are retained.

Androidホームランチャーの操作感を正本にしたブックマーク管理アプリ。

## 0.1.73 (74) — Wishlist card layout and independent expansion
- Collapsed thumbnail 80dp; expanded thumbnail 140dp. Keep the same thumbnail view and animate its size along with card height (ChangeBounds + Fade).
- Expanded header: image on the left; up to two lines of product name, URL and name-edit button on the right. Prices, tags, monitoring and three action buttons below the header.
- Multiple Wishlist cards may remain expanded at once; opening or closing one does not change the others. Tapping the Wishlist title collapses all cards with a shared animation.
- Remove all purchase-recording interface: purchase counter, history listing, button, and return-from-product purchase prompt. Existing purchase data is retained in the database for backward compatibility, without UI exposure.
- Keep existing card reordering animation, tag dialogs, price crawling, home/Wishlist swipe navigation and app identity/signature unchanged.

## 現行仕様
- applicationId: `com.cmyk.bookmarkslauncher`
- version: `0.1.77 (78)`
- minSdk 29 / targetSdk 36 / compileSdk 36
- ホームは5列×8行のCellLayout型グリッド
- ホーム初期値は4×1検索窓＋右隣1×1のNライトブルー丸＋。どちらも独立して長押しドラッグ移動でき、上部×へドロップして削除可能
- 検索窓／＋を削除した場合、ホーム空欄長押しからそれぞれ再追加可能
- 検索は表示名・サイト名・ページタイトル・URLを対象
- フォルダ内は4列×5行。アイコンとテキストエリアはホームと同じ物理サイズ
- 長押しドラッグで空きセルへ自由配置、外周は650msでreorder。周囲アイコンは約180msで滑らかにスライドして空きセルを作る
- 既存フォルダ上で約650msホバーするとドロップ前に展開し、親→子→孫へ同一ドラッグを継続可能
- ドラッグ開始後に生成されたフォルダパネルも、root側ドラッグコーディネータでホバー・ドロップを追跡
- フォルダへ入ってから外へ出るとその階層だけ格納。子を出た後は親を残し、親へ再入場→再退出で親を格納
- フォルダは元アイコン位置から拡大展開し、閉じる時は逆方向へ格納
- フォルダダイアログ自体は常に不透明。子・孫が重なっている間だけ背面フォルダの不透明背景色を段階的に暗くし、擬似alpha風に黒へ近づける。アイコン／文字は常に不透明
- フォルダ欄内タップでは閉じず、欄外タップで最前面フォルダのみ格納
- フォルダ名タップでリネーム、名前欄長押しでダイアログを一時移動（位置は保存しない）
- フォルダが1件以下になった場合は自動解体し、残存1件を親階層へ繰り上げ
- フォルダ詳細の「中身を保護」はデフォルトON。ONでフォルダだけ削除、OFFで配下を再帰削除
- ブックマーク長押しで詳細ダイアログ。サイト名・1:1サムネイル・URL・ブックマーク日時・最終アクセス・オフライン状態を表示（Google Maps / YouTubeではオフライン項目を非表示）
- サムネイルタップでページトップスクショ・favicon・site name・page titleを同時再取得
- 撮影用WebViewは画面外で描画し、取得中はNライトグレーのシークサークルのみ表示
- ブックマークアイコンはNダークグレー円＋縮小favicon。faviconは元形状・縦横比を維持し、未取得時のみ汎用ブックマーク記号
- フォルダアイコンはNブルーの処理描画ベクター形状＋最大4件プレビュー。子フォルダもフォルダ絵で表示
- アイコン長押し中は画面上部中央（初期基準から合計40dp下）に黒丸＋Nレッドの×削除ターゲット
- Android共有（text/plain）からURLを受け取りブックマーク化し、メタデータ／サムネイル取得を開始

## Chrome同期を後付けするためのDB設計
`nodes` はアプリ内UUID `id` と別に `external_source` / `external_id` を保持。
Chrome等の外部ブックマーク同期を後付けしても、セル位置・表示情報・スクリーンショット・オフライン情報を独立維持できる。
削除は `deleted_at` を使うsoft delete。

## オフラインWeb
- 通常Webブックマークのみ対応。Google Maps / YouTubeは対象外。
- WebViewのMHTMLをSAFで選んだ外部フォルダへ保存。アプリ内部は一時キャッシュのみ。
- 1ブックマーク内で複数ページを追加保存し、保存済みURLはローカルMHTMLを優先表示。
- 未保存ページはフロート＋、保存済みページはフロート更新アイコン。
- フロート操作はFinderlessCamera v0.1.92準拠：300ms長押し、ポヨン＋40msバイブ、自由ドラッグ、中央削除ターゲット、スナップ／リリース閾値、位置保存。

## 今後
- Chrome/Google同期ブリッジ

## ビルド
GitHub Actions `.github/workflows/build.yml` を使用。
AGP 9.4.0 / Gradle 9.6.0 / JDK 17。
固定keystore同梱のため継続ビルドは上書きインストール可能。



## 0.1.53 (54)
- オフライン保存済みバッジ内の白い▼を、3辺が等しい下向き正三角形へ変更。正三角形の重心を緑丸の幾何学的中心へ一致させ、丸のサイズ・位置・色は維持。


## 0.1.52 (53)
- オフライン保存済みのブックマークアイコン右上に、Nグリーン `#227733` の丸＋白い下向き三角ベクターの状態バッジを追加。三角形の重心を丸の中心へ一致させて幾何学的に中央配置。
- オフラインビューアから戻った際にホーム／開いているフォルダを再読込し、保存直後はバッジを表示、オフライン保存削除後はバッジを消去。


## 0.1.51 (52)
- 保存済みMHTMLを開くときはJavaScriptを停止し、WebViewのネットワーク読み込みを遮断して外部保存ファイルだけで描画するオフラインモードへ変更。
- オフライン表示中に保存済みリンクをタップした場合はローカルMHTMLを優先。未保存リンクはネット接続が無ければ遷移せず「このページは保存されていません」と表示。
- 保存／更新のオンライン再読込時のみネットワークとJavaScriptを有効化。機内モード中の更新操作は実行しない。

## 0.1.49 (50)
- 通常Web詳細のオフライン保存済み表示を「表示」に変更し、詳細側の「更新」ボタンを削除。保存済み時は「表示／削除」。
- URL本文は最大2行まで表示し、それ以降は末尾省略。コピーカプセルはURL行の上詰めに変更。
- オフライン保存／表示から戻った際にDBを再読込し、開いたままのブックマーク詳細ダイアログの保存状態をその場で更新。
- オフライン削除確認はブックマーク詳細ダイアログを閉じず、その上に表示。削除完了後は同じ詳細ダイアログ内を未保存状態へ更新。


## 0.1.48 (49)
- 通常Web詳細の「オフラインビューイング」題字は維持し、タップ可能な状態テキストをNオレンジの細カプセルボタンへ変更。
- URL列右端にNダークグレーの細カプセル「コピー」ボタンを追加。URL本文タップの既存コピー動作も維持。
- オフラインビューアの保存／更新フロート初期位置を右下寄せへ変更。ユーザーが移動済みの場合は保存位置を優先。
- ステータスバーを半透明黒へ変更。
- オフラインビューアは初期表示を横幅フィットにし、横スクロールバーを非表示。ピンチズームは維持。

## 0.1.46 (47)
- Google Maps / YouTube詳細から「オフラインビューイング」を削除。通常Webのみ表示。
- Google Maps電話番号取得・詳細表示を停止。既存DBカラムは互換維持のため残す。
- 通常Web向け外部MHTMLオフラインビューアを追加。SAF選択フォルダを正本とし、アプリ内は一時キャッシュのみ。
- 閲覧中に未保存URLへ移動すると＋、保存済みURLでは更新アイコンへ切替。ページ単位で保存／更新。
- フロートボタンの長押し移動をFinderlessCamera v0.1.92から移植。


## 0.1.10 (11)
- Central drag coordinator at the root ViewGroup for reliable folder IN/OUT detection.
- Only the topmost folder can exit-close; after a child closes the parent must be re-entered before it can close.
- Folder panel surfaces stay opaque; only geometrically overlapped background regions are progressively darkened.
- Search bar visual height reduced to 50% of its 5x1 row; outside taps clear focus and hide the IME immediately.
- Delete target moved to top-center.
- More vertical room for two-line icon labels; home/folder tiles share the same metrics.
- Favicons keep their original silhouette/aspect ratio instead of circular clipping.


## 0.1.11 (12)
- Child-folder drag-out now quarantines the parent IN/OUT detector for 1 second.
- Parent close requires a real outside -> re-enter -> outside sequence after a child closes.
- Bookmark favicon reduced inside its dark-gray circle while preserving original aspect ratio.
- Folder circle uses N Light Gray (#656060).
- Folder dialog background uses N Gray (#454040).
- Search field uses N Light Gray (#656060).


## 0.1.12 (13)
- Bookmark/folder circle diameters stay unchanged; bookmark favicon now uses up to 80% of the circle diameter while preserving its original aspect ratio and silhouette.
- Delete target moved 25dp downward from its 0.1.11 top-center position.
- Activity uses IME adjustNothing so the home grid never shifts when the keyboard opens.
- If the search field would be covered by the IME, only the search field receives a temporary upward translation; closing the IME restores its exact grid position.
- Tapping outside the focused search field immediately clears focus, hides the keyboard, and restores any temporary IME translation.


## 0.1.14 (15)
- 検索窓を4×1へ変更し、さらに細身化・左右余白を追加。
- 検索窓右側に1×1のNライトブルー丸＋を追加。URL直接入力からブックマーク追加でき、取得処理でtitle / site name / favicon / screenshotを更新。
- 検索窓と＋は独立して長押しドラッグ移動・上部×へドロップ削除可能。空欄長押しから再追加可能。
- 検索窓は長押し移動時はドラッグ、移動しない長押しでは標準のコピー／切り取り／貼り付け／全選択／範囲選択を利用可能。不要なSearch項目のみ抑制。
- faviconを0.1.13からさらに80%へ縮小。サークルサイズは維持し、元の縦横比・形状を維持。
- フォルダアイコンをNブルーの処理描画ベクター形状へ変更。子フォルダもフォルダ絵で表示。
- BookmarkLauncher題字をNホワイト＋GitBuild/PriceRec系のlight sans題字へ統一。
- 削除×をさらに15dp下げ、初期位置から合計40dp下へ。
- フォルダダイアログ重なり暗化を双方のroundRectでクリップし、重なり部分でも角丸を維持。

## 0.1.13 (14)
- Favicon visual size is reduced to 80% of the 0.1.12 rendered size; bookmark/folder circle diameters are unchanged.
- Folder-preview favicons follow the same 80%-of-previous-size rule while preserving original aspect ratio and silhouette.
- Search field is slimmer (50% of row height, 30dp minimum) and visually inset 12dp on both sides while still occupying the full 5x1 grid row.
- Drag-source translucency is keyed by item ID at Activity level and survives folder exit/re-entry, panel refresh, and tile recreation until the drag session ends.


## 0.1.15
- Home folders restored to the launcher-style N-light-gray circle with up to four child previews.
- Folder tiles shown inside folders use the N-blue vector folder silhouette.
- Home-folder circular drop hit area restored; nested-folder vector hit area retained.
- applicationId and stable signing key unchanged.


## 0.1.17
- Home folder remains the N-light-gray circular preview folder.
- Nested folder tiles use a dark-gray circle with the shared N-blue vector folder silhouette.
- Mini nested-folder previews now reuse the exact same vector path instead of the legacy mini glyph.
- Up to four home-folder preview items are enlarged and clipped by the outer folder circle when necessary.


## 0.1.17 changes
- Child-folder vector glyphs use N Light Blue (#445577).
- When a parent folder is expanded, child folders use the same full Home folder tile (circle + up to four previews) instead of the compact nested-folder glyph.
- The four preview positions inside a Home folder circle are spread farther outward while retaining circular clipping.


## 0.1.18 (19)
- Search field hint changed to `ブックマーク検索`; a vector clear button appears at the right while text exists.
- Search 4x1 and URL-add 1x1 widgets are visually raised to align with normal icon height while retaining their original grid occupancy.
- Drag occupancy previews for search and URL-add are rounded rectangles matching 4x1 / 1x1 cells.
- Dropping onto a folder only stores the item; folder expansion occurs only after the existing 650 ms drag hover.
- Bookmark creation from Share or direct URL continues to auto-fetch favicon, top-page screenshot, site name, and page title.

## 0.1.19 (20)
- 検索結果をフォルダと同じNグレー角丸パネル＋4列アイコングリッドで表示。
- ブックマーク詳細の左下に「削除」「コピー」を並べ、コピーはNライトブルーでホームへ別UUID複製。
- 画面回転を禁止し、Activityをportrait固定。
- ホーム空欄長押しメニューを大きな角丸Nグレー面＋背景なし白文字の縦メニューへ変更し、「エクスプローラ」を追加。
- エクスプローラはBookmarkLauncher内の論理的なホーム／フォルダ構成だけを辿る入口として実装。
- NDialog背景をNグレー (#454040) に統一し、通常ボタンはNライトブルー (#445577) のカプセル型へ統一。
- ホーム／展開フォルダのフォルダ円をNライトブルー (#445577) に統一。


## 0.1.20 (21)
- ドラッグ中、アイコン外周を掠めた時に並び替え候補へ入りやすいよう、ドラッグ専用の外周ヒット領域を少し拡大。
- 中央のフォルダ作成／フォルダ格納判定も一段だけ拡大し、重なる場合は中央フォルダ判定を優先。
- ブックマーク表示名は custom name → page title → site name → legacy title/URL の順で決定。
- Android共有時は EXTRA_SUBJECT を初期タイトル候補として使い、WebView取得後は実ページタイトルを優先表示。


## 0.1.21 (22)
- 題字「BookmarkLauncher」のTypefaceをN Standardと同じデフォルトsansへ統一。
- 名前変更はNダイアログを使用し、既存名を開いた時点で全文選択。
- 空欄長押しの「エクスプローラ」をN Standard由来のNエクスプローラUIへ置換。対象はホームをルートにしたBookmarkLauncher内フォルダ階層のみ。
- 空欄長押しメニューの表記を `(＋URL追加)を追加` に訂正し、その下に「アプリを追加」を追加。
- 端末の起動可能アプリ一覧から、アプリアイコン＋アプリ名のショートカットをホームへ追加可能。タップで対象アプリを起動。
- BookmarkLauncherがバックグラウンドへ移ると、展開中のフォルダパネルを全て閉じ、復帰時は通常ホームから再開。


## 0.1.22 (23)
- App picker: search field under title, ListView recycling + scaled lazy icon loading for crash/memory mitigation.
- App picker: long-press multi-select, green check, selection count, batch add.
- Home empty-cell long-press menu: NS-style diagnostic log at bottom.
- Diagnostic log records app-picker query/icon/errors and uncaught exceptions.
- N Explorer buttons aligned to current NS visual component.

## 0.1.23 (24)
- BookmarkLauncher title uses the same 25sp bold default sans treatment as GitBuild.
- Version name is displayed directly under the title in the same 12sp N-white style as GitBuild.
- Search field keeps its existing grid position/order but is always rendered above bookmark/folder tiles when IME translation causes overlap.
- Drag graze hit halo expanded from 6dp to 10dp.
- Folder-create / move-into-folder merge hit region expanded outward by 4dp without changing icon visuals.

## 0.1.29 (30)
- Google Maps URL (`maps.app.goo.gl`, `goo.gl/maps`, `google.* /maps`) を専用判定。
- Google Mapsブックマークは通常faviconの代わりに、Nレッド `#441100` のピン型VectorDrawableを表示。フォルダ内プレビューも同じピン表示。
- Google Mapsの短縮URLはWebViewで展開後、`/place/<店名>/` → 画面のh1/og:title → page title → 共有テキストの順で店舗・施設名を取得。
- Google Mapsのfavicon取得は行わず、専用ベクター表示を固定。

## 0.1.30 (31)
- Google Mapsのページタイトル／OGタイトルから郵便番号・都道府県以下など住所部分を除外し、屋号・施設名を優先して表示。
- Google Mapsの画面h1を最優先候補にし、URLの `/place/<name>/`、通常タイトル、共有タイトルへフォールバック。
- 撮影用WebViewでmain-frameエラー、`chrome-error://`、アクセス不可系タイトルを検出した場合はエラーページをスクリーンショットとして保存しない。既存サムネイルがある場合は維持。
- `intent://` 等へ遷移した場合はブラウザ用HTTPSフォールバックを使い、WebViewのアクセス不可画面化を抑制。
- Google Maps専用ピンをNライトレッド `#662211` に変更。

## 0.1.31 (32)
- Google Maps短縮URLはWebViewより先にHTTPリダイレクトを追跡し、`intent://` を含む場合はブラウザ用HTTPS URLへ復帰して最終Maps URLを確定。
- 最終URLから `/place/<name>/`、`@lat,lng`、`!3dlat!4dlng`、座標クエリを解析し、屋号と緯度経度を取得。
- 緯度経度が取れた場合はOpenStreetMapの地図タイルを端末側で合成し、Nライトレッドの中心ピン＋帰属表示付き512px正方形の静的地図サムネイルを生成。WebViewスクショ失敗時もこの静的地図を使用。
- 座標または地図タイルを取得できない場合のみ、従来のWebViewスクリーンショット取得へフォールバック。
- Google Maps用ピンアイコンはNライトレッド `#662211` を維持し、表示サイズを0.1.30比80%へ縮小。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.32 (33)
- Google Maps静的地図の座標抽出順を修正。`!8m2!3dlat!4dlng` のPOI座標を最優先、その他の `!3dlat!4dlng` は最後の有効ペアを採用。
- `@lat,lng` と `center` / `ll` は地図の表示中心になり得るため、短縮URL展開直後には使わず、WebViewで最終URLまで到達してもPOI座標が取れない場合だけ最終フォールバックとして使用。
- WebView到達後は `rel=canonical` / `og:url` も一度確認し、そこにPOI座標があれば表示中心より優先。
- Google Mapsタイトルが `〒住所 … 階 屋号` の並びでも、住所・階数部分を除いて後半の屋号／施設名を抽出。全角数字にも対応。
- Mapsページのタイトル取得はh1だけで確定せず、専用h1・main h1・OG title・Twitter title・document.titleを順に候補化し、住所だけの候補を除外。
- 診断ログへ静的地図生成に使った座標と precise / viewport fallback の別を記録。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.33 (34)
- Google Maps静的地図の座標決定を見直し、`@lat,lng` と一般の `!3d..!4d..` は使用しない。
- Maps画面から住所を取得し、Android Geocoderで座標化する経路を最優先。明確なPOI `!8m2!3d..!4d..` のみフォールバックとして使用。
- Mapsの共有タイトルはEXTRA_SUBJECTを無加工で採用せず、屋号抽出を必ず通す。住所＋屋号形式や階数直後の屋号にも対応。
- Google Maps取得成功時は屋号をtitle/page_titleへ反映し、詳細ダイアログの題字・ページタイトル・サムネイルを再取得直後に更新。


## 0.1.34 (35)
- Google Maps対応を `com.cmyk.bookmarkslauncher.googlemaps` パッケージへ完全分離。通常ブックマークのキャプチャ処理は `WebBookmarkCaptureManager` として独立。
- Maps URL判定、短縮URL展開、共有タイトル解析、屋号／住所抽出、Geocoder座標化、静的地図生成、Nライトレッドのピン描画を `GoogleMapsModule` 配下へ集約。
- `BookmarkCaptureManager` は通常Web／Google Mapsの振り分けだけを担当し、Maps固有処理を保持しない。
- MainActivityの共有受信とBookmarkTileViewのMaps表示も公開ファサード `GoogleMapsModule` 経由に統一。Maps内部クラスを通常UIから直接参照しない。
- Repositoryの `updateGoogleMapsMetadata` を廃止し、汎用 `updateCapturedMetadata` へ置換。データ層からMaps固有ロジックを除去。
- 今後、Google Maps以外の通常開発では `googlemaps` パッケージを変更しないことをソース内 `package-info.java` に明記。
- Google Maps共有、屋号取得、住所Geocoder、静的地図、Nライトレッド80%ピンの0.1.33動作を維持。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。

## 0.1.36 (36)
- Google Maps静的地図はzoom 16を維持したまま、中央450px範囲を512pxへ拡大して表示。0.1.34比で約13.8%だけ寄った縮尺に調整。
- 静的地図内の地点マーカーサイズは維持し、ホーム／フォルダ内のGoogle Mapsピンアイコンのみ、未反映だった指定どおり0.1.34表示サイズの20%へ縮小（80%小さく）。
- favicon未取得時に表示する通常ブックマークのデフォルト記号を少し小型化。取得済みWebサイトfaviconのサイズは変更しない。
- Google Maps専用ロジックの `googlemaps` パッケージ分離を維持。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.36 (37)
- Google Maps static thumbnail: pinch-in/out changes real map coverage (70%..160%) and redraws tiles on release.
- Per-bookmark Google Maps scale + resolved coordinates stay isolated in googlemaps SharedPreferences.
- Google Maps home/folder pin restored from the accidental tiny size to 70% of the original pin size.
- Existing Maps bookmarks without stored coordinates resolve them once on first pinch refresh.


## 0.1.37 (38)
- Google Maps detail thumbnails now track pinch scale continuously using the current bitmap, then replace it with a freshly rendered sharp static map after release.
- Bookmark detail and folder detail dialogs dismiss with a deliberate vertical swipe up or down; multi-touch is excluded so Maps pinch does not dismiss them.
- Google Maps bookmark pin remains isolated in the googlemaps package and uses 70% of the original pin size.

## 0.1.38 (39)
- ブックマーク／フォルダ／アプリなどのユーザー操作による削除は、実削除前にNダイアログで確認する。ドラッグで削除先へ落とした場合も同じ確認を通す。
- フォルダで「中身を保護」をOFFにしている場合は「フォルダと中身を削除しますか？」と明示する。
- ブックマーク詳細ダイアログの「コピー」表記を「複製」へ変更。複製動作自体は従来どおりホームへ同一ブックマークを作成する。
- ブックマーク詳細ダイアログのURL表示をタップすると、そのURLをクリップボードへコピーし「URLをコピーしました」と表示する。
- Google Maps専用ロジックには変更を加えない。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。

## 0.1.39 (40)
- 削除確認を汎用選択メニューから専用Nダイアログへ変更。本文の下部右側に「キャンセル」「削除」を横並びし、「削除」はNライトレッド `#662211`。
- フォルダで中身も削除する場合は「フォルダと中身を削除しますか？」を表示。ドラッグ削除も同じ確認ダイアログを通す。
- フォルダ内は4列・既存アイコンサイズを維持したまま、5行を超えると下方向へ行を追加。題字は固定し、内容エリアだけ縦スクロールする。
- フォルダが満杯になった時点で次の空行を確保し、追加アイテムを下へ配置できるようにする。
- Google Maps専用ロジックには変更を加えない。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.40 (41)
- 削除確認ダイアログのボタンを中央配置し、キャンセル/削除を1行表示に固定。
- フォルダは5行以内ではスクロールを無効化。6行目以降でスクロールを有効化。
- フォルダの表示高を約5.5行へ拡張し、6行目が半分見切れて見えるように調整。

## 0.1.41 (42)
- フォルダ内は1〜20個（5行）まで予備6行目を作らず、縦スクロールを完全に無効化。旧版で6行目に残った位置も5行内へ再配置する。
- 21個目で実際に6行目が発生した時だけフォルダダイアログを少し縦に延長し、6行目の上半分だけが見切れて見える高さにする。
- 6行目以降は内容エリアだけを縦スクロールし、7行目以降でもダイアログ自体はそれ以上拡大しない。
- Google Maps専用ロジックには変更を加えない。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.42 (43)
- YouTube対応を `com.cmyk.bookmarkslauncher.youtube` パッケージへ完全分離。通常Web／Google Mapsの取得処理からYouTube固有ロジックを分離。
- `youtube.com/watch?v=...`、`youtu.be/...`、`youtube.com/shorts/...`（embed/live含む）から動画IDを抽出。
- YouTube公式サムネイルを maxres → sd → hq の順で直接取得し、ページUI・文字・再生コントロールを含めず1:1中央トリミングしてブックマーク画像として保存。
- oEmbedから動画タイトルを取得できた場合はサイト名 `YouTube` とページタイトルへ反映。
- 専用サムネイル取得に失敗した場合だけ従来のWebView取得へフォールバック。
- Google Maps専用パッケージは変更せず、applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。

## 0.1.63 (64) Wishlist initial build
- 0.1.62 (63) を唯一の正本として Wishlist を統合。versionCode は 64 へ更新し、applicationId／固定署名を維持。
- ホームから右スワイプで Wishlist を開く。ブックマーク詳細から Wishlist へ追加し、元ブックマーク／favicon／URL は変更しない。
- Wishlist は細めのグリップ付き縦リスト。タップで展開し、現在価格・登録時価格・価格変動・タグ・購入済み回数／履歴・再開監視を表示。
- 右下は虫眼鏡丸ボタン。検索ダイアログ内に検索欄・価格範囲・タグチェックリストをまとめ、価格条件検索時は全件の最新価格を再取得してから絞り込む。
- タグ追加／選択／編集は PriceRec. の操作系を参照。商品展開内からタグを追加し、タグ一覧はグリップ並べ替え・長押し編集／削除に対応。
- 商品ページから戻った際、一定時間閲覧していた商品だけ画面下に「購入しましたか？」確認バーを表示。購入日時とその時点の価格を履歴保存。
- JobScheduler で約1日1回クロール。再開監視ONの商品が未開始／購入不可から購入可能へ変化した場合に通知。
- 0.1.61で指定済みの「＋ → ブックマーク / アプリを追加 / QR作成」、QR作成のURL入力、ブックマーク詳細の「削除 / QR生成 / 複製 / 閉じる」を維持。

## 0.1.64 (65) Wishlist return navigation
- Wishlist から左スワイプで BookmarkLauncher ホームへ戻れる復路を追加。
- Wishlist 上部の戻るボタンと Android 戻る操作も同じ復帰処理へ統一。
- 通知から Wishlist 単独で開いた場合でも MainActivity を前面へ復帰して終了できるようにした。
- 横スワイプは 110dp 以上かつ縦移動より十分大きい場合のみ成立し、縦スクロール／グリップ操作との誤爆を抑制。
- build-apk.yml は versionName/versionCode の固定値を持たない BookmarkLauncher 共用 workflow に変更。APK 名は source.zip 内の versionName から自動生成。

## 0.1.65 (66) Wishlist tag persistence fix
- Wishlistの商品展開内タグ編集を即時保存方式へ変更。
- 既存タグのチェックON/OFFを操作時点で item_tags に保存し、閉じる操作でも変更が消えないよう修正。
- 新規タグ作成時はタグ作成（既存同名タグなら再利用）と同時に対象商品へ即時紐付け。
- item_tags への追加は CONFLICT_IGNORE を使用し、重複紐付けで失敗しないようにした。
- versionCode 66 / versionName 0.1.65。

## 0.1.66 (67) Wishlist Java compile correction
- WishlistActivity.Flow の generateLayoutParams(AttributeSet) を public override に修正。
- 署名と applicationId の固定を維持。

## 0.1.67 (68) Wishlist gesture, tag dialog and price placeholder
- Wishlist画面の右スワイプ（横移動110dp以上）でホームに戻るよう、従来の左スワイプ判定を反転。ホーム→Wishlistの右スワイプは変更なし。
- タグ選択／編集ダイアログを開いた際に入力欄が自動フォーカスされてキーボードが表示され、初期配置が動くことを抑制。開いた時は中央表示、編集欄をタップすると入力できる。
- 商品名の右に価格が未取得の場合表示されていた「—」を削除。価格取得済みの場合は価格を表示。
- versionCode 68 / versionName 0.1.67。applicationId・固定署名・その他の機能は維持。


## 0.1.68 (69) 連動スワイプ・ページ統合
- v0.1.67 (68) のsource.zipを唯一のベースとして作成。
- ホームとWishlistをひとつのウィンドウ上に並ぶ実ページとして統合。Wishlistの描画・DB操作・タグダイアログ等を `WishlistPage` に集約し、通知用の `WishlistActivity` からも再利用。
- ホーム右スワイプでWishlist、Wishlist右スワイプでホームへ戻る。Wishlist左スワイプでも逆方向で戻れる。
- 指の移動量に応じて両ページを同時に水平移動し、一定距離を超えるとスナップ。短いスワイプは元の位置へアニメーション復帰。
- 縦スクロールの開始時はページ切替ジェスチャーを破棄。長押しドラッグ中、フォルダ展開中、検索中は切り替え禁止。
- Wishlist再開通知からはMainActivity内の同じWishlistPageへ直接遷移。旧通知用WishlistActivityはMainActivityへの転送専用として保持。
- applicationId、固定署名、依存、ワークフローを維持。versionCode 69。

## 0.1.69 (70) Wishlist header alignment

- Wishlistの題字をホームのBookmarkLauncher題字に合わせ、上端64dp、左余白18dp、25sp太字、44dp高さで縦中央揃えに統一。
- 左端の戻る矢印カプセルを削除。スワイプ操作による画面移動はそのまま維持。
- applicationIdと固定署名を維持、versionCode 70。

## 0.1.70 (71) Wishlist URLプレビュー
- Wishリストの左下に「＋」を追加し、商品URLの直接登録と初回の自動解析を実装。
- ブックマーク詳細からWishリストへ追加した場合も、既存の非同期初回解析を使って商品名・画像・価格を取得。
- OGP（og:title/og:image）、Twitter Card、JSON-LD Product（name/image/JPY price/availability）、ページタイトルを優先順で解析。商品画像の一部HTML属性も補完。
- 取得画像は最大5MBをダウンロードして縮小・JPEG化し、`filesDir/wishlist_previews/`にオフライン保存。Wishカードでは商品画像を優先し、未取得時は既存のブックマークサムネイル／faviconを表示。
- SQLiteDB v1→v2非破壊移行：商品画像のURLとローカルパス、手動で商品名を編集したフラグを追加。登録済みWish・タグ・価格履歴・並び順は保持。
- 商品名はURL元のブックマーク表示名より取得した商品名を優先。商品詳細内「商品名を編集」またはタイトル長押しで手動変更した後は、以降の再解析で上書きしない。
- 価格は通貨がJPYと確認できた構造化データまたは日本向けサイトの価格メタ情報のみを円として扱う。アクセス制限・動的サイト・情報欠落時は取得できた範囲のみ適用し、取得済み画像は消さない。
- 画面の連動スワイプ、applicationId、固定署名、既存workflowのビルド構成は維持。versionCode=71。


## 0.1.71 (72)
- Wishlistカード開閉にChangeBounds + Fadeのアニメーションを追加。リストを再生成せず隣接カードの位置も滑らかに追従。
- カードの並べ替えをグリップ長押しドラッグ方式に変更。掴んだカードは指に追従、周囲カードは220msで滑らかに移動し、確定時のみ並び順を保存。
- 商品名はカード右端まで1行表示し、超過分は末尾省略。価格は二段目へ移動。
- タグダイアログのwindow属性を表示前に適用し、初期右寄り・位置飛びを軽減。
- 商品価格はJSON-LD Offer / priceSpecificationのJPY受け渡し、OGP、itemprop、AmazonのpriceToPayと明示的な商品価格要素から補完。ページ内の無関係な価格や外貨を誤表示しない。
- ネットワーク拒否／サイト側非公開の価格は取得不可のままとし、過去に保存した価格は維持。

## 0.1.82 (83) N Standard共有アイコン正本移植
- Wishlist展開カードの共有丸アイコンを N Standard 0.1.28 の `NShareIconView` 正本へ変更。元の描画構造を維持し、パッケージと N.DGRAY 色参照だけをローカル化。
- 正本どおり42dp、ダークグレー `#252020` 背景、白 `#FFFFFF` の細い線と3つの円を幾何学的にセンター配置。旧代替 `NStyleShareIconView` を削除。
- 共有操作（商品名とURLをAndroid共有シートへ渡す）、再開監視ボタン位置、成功済み取得ロジックは変更しない。
- versionCode 83 / versionName 0.1.82。applicationIdと固定署名を維持。


## 0.1.89 (90)
- Wishlist + / search floating buttons: N light blue (#445577) circle with N white (#A9A999) glyphs. Search-mode visibility remains unchanged.
- Wishlist card grip: do not detach/reparent any card while the finger is pressed. Use PriceRec-like animated sibling preview; commit reorder and persist only on ACTION_UP. CANCEL restores the original order without saving. Auto-scroll near list edges is active while pressed.
- Wishlist price search inputs: numeric keyboard, Android Autofill disabled for price fields, saved input state disabled, and personalized IME learning suppressed. This does not guarantee every third-party keyboard hides its proprietary suggestions.
- Keep successful product title, price, image, availability and site-status crawlers unchanged.
- Signing/applicationId unchanged; Gradle build and device test remain unverified in this environment.
