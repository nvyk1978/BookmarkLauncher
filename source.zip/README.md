# BookmarkLauncher 0.1.184 (versionCode 185) — 個別情報更新キュー・3項目限定採番

- 唯一のベース: `BookmarkLauncher_0.1.183_source.zip`、SHA256 `6e20651e85553e1cfe02f1dbc1ec0286ef92fdf8dbc8b3108193411050adf77d`。
- 個別の「情報更新」は1件ずつ共通取得パイプラインで順次実行。更新中のカード・キュー待ちカードのみボタンをNグレーで無効化。他サイトは予約可能。
- 一括更新中は全カードの「情報更新」をグレーアウトして操作不可。処理後に再有効化。
- キューはSharedPreferencesへ同期保存、二重登録を拒否、画面再生成・正常終了・強制終了後の再開に備え実行中IDも記録。
- 同一サイトの連続実行は禁止。別サイトの完了が間にない限り次の同サイトカードは「キュー待機中」に置く。サイトのサブドメイン違いも同一グループとして扱う。
- 旧「在庫AVAILABLE/UNAVAILABLEだけで番号を自動登録」を禁止。更新中に同一商品から再取得/保存した商品名・画像と、確定した在庫状態の3条件が揃った場合にのみ登録。
- 0.1.183で在庫情報のみで作られた旧自動登録番号 (例: 040〜042) は番号を詰めず`PENDING`として非活性化。3条件の再実証により元番号で有効化。
- GU最初のJSON解析例外に限定した最大2回の再試行、AliExpressの構造化商品監査（前ターンで次版用として保留した検証済み4ファイルパッチ）も取り込み。SHEINの成功取得処理は不変。
- 現時点の制約: 008以降の番号が専用サイトJava/JSを完全再利用するわけではなく、TEMU等の単一WebView専用経路の全番号実行や価格・名前・画像の番号横断統合は未完成。本版は登録資格とキューの修正であり、全面的な取得技術移植ではない。
- Android SDK/APK実ビルドや実機テストはこの作業環境では未実施。Java構文/限定コンパイル/生成JavaScriptテスト、旧回帰検証は実施。
- 署名/DB/applicationId/workflow/AndroidX/`scripts/prepare-build.sh` は維持。

---

# BookmarkLauncher 0.1.183 (versionCode 184) — 全専用技術を000+に番号登録

- v0.1.182 (183) SHA256 051e71ed13a7117bf0e897e9df456abd87fb1a9469230d9eaff00af7598ada8f を唯一の正本として構築。
- 000–007 は従来GENERAL A–Hの対応を維持。008以降に未登録だった専用技術をサイト制限のない保守的なDOM証拠ポリシーとして収録。
- 000+ の全技術は1つのWebViewにて順次評価（実装上は1回のJavaScriptスナップショット）。各処理は元サイトではなく対象商品のURL・SKU/JSON-LD Productと一致するデータのみ見る。成功があっても全件評価後に統合。
- 専用で確定成功した新サイト名はSharedPreferencesへ番号を永続登録。再利用は検証済みの保守的共通stockポリシーのみで、サイト固有のHTMLにしか適用できない選択子は自動移植しない。
- 従来の独立したサイト専用モードは改変せず、在庫UNKNOWN時の追跡として保持。
- 署名/DB/applicationId/workflow/AndroidXは維持。
- 重要な制約: 自動登録は専用モードの成功識別・汎用stock判定プロファイルの追加を意味し、動作未知の専用JavaScript/Javaプログラムを実行時に自動生成するものではない。価格/画像/名前の既存巡回は非破壊で保持。

# BookmarkLauncher 0.1.182 (versionCode 183) — GENERAL alphabet H: Mercari

- Exclusive source: `BookmarkLauncher_0.1.181_source.zip` (versionCode 182), SHA256 `20fafc9306a0b7e9c5c78c4f249d9185cf9eb3bcb01c207598aa6cabfa5b7171`.
- Extend first GENERAL read-only alphabetical pass from A–G to A–H. **H = Mercari exact-listing state**, delegated directly to the already-working `WishlistMercariItemStockDom` JavaScript; no duplicate parser, changes to Mercari selector, or changes to the dedicated Mercari follow-up.
- H only certifies `AVAILABLE` / `UNAVAILABLE` if saved URL is an exact `jp.mercari.com/item/m…` route and the JSON inspector confirms the same listing ID, bounded name, price and one unambiguous on-sale/sold-out status. Unknown/mismatched/other merchants remain UNKNOWN. An exact proven H result may finish the stock probe early; if H cannot prove the listing, the existing independent 15-second dedicated Mercari inspector still runs.
- The existing 15-second GENERAL pass and independent 15-second item-specific page pass remain separate. No changes to prices, previews, card DB, acquisition mode, app identity, signing keystore, AndroidX, workflow or `prepare-build.sh`.
- Offline Java/Node regression fixtures cover exact Mercari listing state, wrong ID, canonical mismatch, contradictory status, no price/name, and other hosts. Existing site tests and archive validation still required. **No live Android/WebView or production merchant availability is claimed from offline tests.**

---

# BookmarkLauncher 0.1.181 (versionCode 182) — 実機診断に基づく保存・認証判定修正

**唯一の正本ベース:** `BookmarkLauncher_0.1.180_source.zip` (SHA256 `cd9eb0765fa7d6aecebbd738a03d96b9d1467055c73e52941db93670112abc39`)。`BookmarkLauncher_0.1.180_diagnostic_fix_staging.patch` (SHA256 `bbd9c0fd4b679411230ac9af1134f3be6124159b5c0d46abbaacbb7e681ddab3`) の8ファイル差分を適用。

- **メルカリ:** 実機で `listing-id-sold-state` により `UNAVAILABLE` と判定できた商品について、従来のHIRAKI専用DB保存制限をメルカリにも限定拡張。対象URL一致・既存モード・ステータス前提条件は維持し、保存結果の診断ログを追加。
- **Temu:** 商品ページで短い確認画面が表示された際に `challenge-visible` を検出し、単なる価格タイムアウトとしての無益なリトライを抑制。認証やchallengeの突破機能ではない。
- **AliExpress:** 商品IDと結びつく構造化 Product レコード、結びつかないレコードの数を診断に出力。**実機で価格/在庫の新規取得成功は未確認**。
- **GU:** 選択済みカラー・サイズの診断フラグを追加。曖昧な在庫を勝手に `AVAILABLE` にしない。
- 署名キー・applicationId・既存DBスキーマ・AndroidX・`scripts/prepare-build.sh`・CI workflows は変更しない。元の `0.1.180` のほかの解析コードを維持。
- 回帰テストは実行するが、Android SDK/GradleによるAPKビルドと実機検証は実施できていない。サイト側の確認/アクセス制限を超えた取得は保証できない。

---

# BookmarkLauncher 0.1.180 (versionCode 181) — Temu・AliExpress・GU・メルカリ取得修正

**唯一のベース:** `BookmarkLauncher_0.1.179_source.zip` (SHA256 `afa3229a9189f29b7bb7c41ea291af215b6860d61373481b21e91fa79ef25b98`) に検証済み `BookmarkLauncher_0.1.179_fourshops_staging.patch` (SHA256 `0cb2392219686126f1391b7f891f72ffea8ef186f1628d685c2b888cd7eb979e`) を適用。

- Temu: 専用WebViewでデスクトップUAが商品データを返さない場合、元の端末WebView UAで同じ商品に限定した再取得を行う。
- AliExpress: 厳密に商品ID一致した `runParams` からタイトル・JPY価格・商品画像を取得する。異なる商品、異なる通貨、価格範囲は無視。
- GU: 選択済みカラー・サイズ近傍の在庫検出を補強。専用取得WebViewをWish画面背面にマウントし、読み込み後は親Viewから取り外して破棄。
- メルカリ: 独立した在庫状態判定の表記揺れ対応と、在庫用WebView描画改善。異なる商品IDは採用しない。
- 既存専用サイト処理・署名キー・applicationId・DBスキーマ・AndroidX設定・workflow・`scripts/prepare-build.sh`は保持。
- `scripts/check-four-shop-recovery-180.py` にJava生成JSの肯定/否定ケースを追加。
- **注意:** 静的・オフラインテストは実行するが、Android APKの実ビルドと4サイトの実機取得成功は未検証。サイト側の認証・Bot制限は回避しない。

---

# BookmarkLauncher 0.1.179 (versionCode 180) — 専用モード5サイトと独立15秒×2、モード表示中央寄せ

**唯一のベース:** `BookmarkLauncher_0.1.178_source.zip`、SHA256 `b15f08e65829852693da4fc697e27d1af01392a0f9574a2f8a2f8610ac0998f3`。署名・applicationId・既存カードDB・保存済みモードGENERAL・正常取得サイトの専用解析は維持。

- **専用モードラベル・厳格なサイト別経路:** Temu / AliExpress / SHEIN は各自の保存済み商品URLに限って市場専用モードを表示し、既存の別々のアイテムID検査付きWebView DOM処理へ振り分け。GU / メルカリは新設 `WishlistGeneralShopDedicatedMode` から特化した在庫JSへ振り分け。各サイトの固定ラベルはGU/メルカリ/SHEINも追加。Green Beansと成功済みLOHACOの商品判定処理を変更しない。
- **SHEIN:** SHEINの確認・challengeページで商品内容が取得できないとき、品番未確認の価格・画像・商品名を推測せず、同じ取得不能画面を延々と巡回しない。実際に商品データが公開されない場合は取得保証なし。
- **GU:** GU固有の正規商品URL、主商品名、選択済みカラー・サイズ、該当バリエーション近傍の在庫を別々に検証。ページ共通のボタンや関連商品で購入可能にしない。既に実機で取得できた価格・画像の方式は維持。
- **メルカリ:** H1がないページでも保存済み`m...`商品IDに厳密一致するNext/初期state/JSON-LD商品レコードから、名前・数値価格・販売状態を検査。商品ID未確認/他商品/不一致ならUNKNOWN。既に成功している価格・画像パイプラインは維持。
- **単体とまとめの完全同一カード更新処理:** `refreshItem` を両方から呼び出し、モードのGENERAL A→G探索に最大**15秒**、完了または時間切れ後の**サイト固有ページ確認に独立した15秒**を設定。いずれのフェーズでも信頼できる購入可否を検知したら即終了。取得根拠のないUNKNOWNは専用ページの15秒を使い切るまで再調査。既存の非GENERAL専用モードの制御はそのまま。
- **展開UI:** URL行と商品名変更ボタン行の余白を可変の`FrameLayout`にし、その幾何学的中央にモード表示を配置。展開中は不要な格納用モード行を`GONE`にして下端への密着を解消。
- **取得不能の正直な扱い:** TemuやAliExpressがWebViewに商品内容を渡さない、SHEINが確認ページを表示する場合、アプリ側だけで商品名/値段/画像の取得を保証することはできない。異なる商品のデータを誤記録せずUNKNOWN/価格未取得を維持。
- ローカル: 既存回帰テスト、Java17製DOM JavaScriptのNode fixtures、専門サイトの肯定/否定条件、A-Gと固有ページの独立タイムウィンドウ、署名・CIアーカイブ構造を検証。**Android APKビルドと実機での新規サイト取得成功は未確認**。

---

# BookmarkLauncher 0.1.178 (versionCode 179) — Temu・AliExpress 専用サブモード

**唯一の正本ベース:** `BookmarkLauncher_0.1.177_source.zip` (SHA256 `80b5d22a0d583bd57308d012577387c162570351196dc7649d94b2f6c72c52ef`)。既存カードの保存モードは GENERAL のままにし、その内側で独立した `WishlistMarketplaceDedicatedMode` を使う。DBスキーマ更新・保存URL変更・署名変更はなし。

- Wishラベルに **Temu / AliExpress** を追加。購入ページの実行中表示は **Temu専用モード / AliExpress専用モード**。正式ドメインの保存先から判定し、他店のGENERAL分岐を変更しない。
- Temu：独立した商品ID照合付き `WishlistTemuItemDom` のみ実行。Temu専用のウィンドウ付きWebViewで端末WebViewのChromeバージョンに沿ったデスクトップ相当のUA・広いビューポートを試し、空の別ページになった場合に同じgoods IDの公式 `/-g-ID.html` 形式を**一度だけ**再試行。無関係な価格・商品名・画像を取り込まない。
- AliExpress：`a.aliexpress.com/_...` のHTTPS短縮リンクが今回のHTTPアクセスで200の公式商品ID付きページに転送されたときに限り、保存URLは変更せず、その正確な遷移先を**単一WebView**の専用解析へ渡す。以前のGENERAL/SHEIN合成JSは実行せず、Ali専用のID束縛されたJSON-LD／商品DOM解析のみ実行。bannerやトップだけのシェルは引き続き拒否し、ローカルの個人情報を記録しないカテゴリ別診断を追加。
- 在庫・価格・画像・商品名とも、**実際に保存商品の識別子と結びつくデータが確認できた場合のみ保存**。HTMLにデータがない、別ページに転送された、認証ページが出た場合は取得不能のままにする。サイトの制限を突破する実装ではない。
- ログ追加：`market.dedicated.route`, `aliexpress.dedicated.shortlink`, `price.webview.temu.browser`, `price.webview.aliexpress.document.audit`。ログは生HTML、商品名、個人情報、Cookie、トークンを出さない。
- 実Javaコードから生成したJavaScriptと商品ID拒否パターン、新たなAli短縮リンクテスト18ケース、既存の全回帰テストを実行。**Android SDKでのAPKビルドおよび実機でのTemu/Ali商品データ取得成功は未検証**。

---

# BookmarkLauncher 0.1.176 (versionCode 177) — Temu live DOM/navigation diagnostic

**Sole base:** `BookmarkLauncher_0.1.175_source.zip`, SHA256 `ab1e855b46fce1aa4185385b1516b783434c3674dfd47f697b8ca69ea50148bc`.

- Temu-only in existing SAME-item price WebView: capture redacted client URL-vs-document URL item relation, DOM status/counters, framework/root/JSON script evidence, generic access-gate categories, and whether blocked main-frame redirects occurred. No raw page body, cookies, titles, JSON, saved full URL or user input is logged.
- Record Temu main-frame request/commit separately so WebView redirect vs client-side DOM/SPA change can be distinguished by the next device diagnostic. The existing same-item redirect guard and strict SKU/pricing/stock rules are untouched.
- All existing successful merchant pipelines, Wish UI, persistence, signature, workflows, preparation and AndroidX remain byte-identical; no added permission or network request.
- These diagnostics do **not** claim to bypass Temu access controls or make non-rendered product data magically available. No price or availability is inferred from URL, 200 HTTP, redirect prevention, or a non-product page.
- Tested with exported Java Temu parser and Node page fixtures, Java 17 syntax parser, full regression scripts and prepared archive. Android Gradle APK build and live Temu success are not verified in this environment.

---

# BookmarkLauncher 0.1.175 (versionCode 176) — GENERAL retail item identity and site-bound stock evidence

**Sole base:** `BookmarkLauncher_0.1.174_source.zip` (SHA256 `c6de56278fba31110f17bf7c9e2f331c3a08d0f7f48dd53b2e8e7557183324cc`). No modification to signing key, application ID, workflow, AndroidX settings, persistent data model, or specialist merchant parsers.

- GENERAL product-route recognition for confirmed URL shapes: Green Beans `/products/<numeric>/details`, LOHACO `/store/<store>/item/<code>/`, GU `/jp/ja/products/E######-###/##`, Mercari `/item/m########...`. No category/search/shop-home routes admitted.
- Read-only, original-item-url-scoped DOM stock evidence after the existing serial A-G diagnostic pass: discard related/advertised products, require one visible primary H1, the primary item's purchase controls and a local price; distinguish Mercari explicit `売り切れました`, Green Beans hero cart, LOHACO delivery-dependent explicit inventory, and GU selected-variant inventory. Missing or contradictory proof remains UNKNOWN. No buttons clicked.
- GU's newly recognized product URLs now enter the previously existing bounded product-price WebView inspection path instead of a generic 14-second deadline-only path. This may recover rendered prices; if the site does not expose them, it still fails safely rather than inventing a price.
- Same-item navigation guard for those four shops' GENERAL price and stock WebViews; prevent generic landing/recommendation data from being adopted after redirects. Existing SHEIN/Temu/Ali, Joshin, ASKUL, MUJI and ZOZO parsers are unchanged.
- Offline Java product-URL tests, Java-generated merchant JavaScript runtime fixtures (9 checks), and legacy regression/preflight checks included. **Live device extraction and Android APK compilation are not verified here**; the source archive is for existing GitHub Actions build.

---

# BookmarkLauncher 0.1.174 (versionCode 175) — Marketplace rendered WebView and floating batch progress

**Sole base:** `BookmarkLauncher_0.1.173_source.zip` (SHA256 `0fc400fc7cf79a3084020907069f73f3bf21d382fb83ae00d416d6954787ce61`). No database schema, application ID, signing key, workflow or other-site scraper changes.

- **3 guarded GENERAL marketplaces only:** run the actual price WebView *mounted at index 0 behind the existing opaque Wish page*, instead of detached. It has a real viewport for JavaScript-powered product pages but cannot be seen or interacted with; on finishing the existing cleanup removes/destroys it. Other sites retain their old detached path.
- **SHEIN:** keep the v0.1.173 intra-document exact-item price retention; a bounded timer preserves that verified price on an unchanged product URL even if later fields remain missing. Never accept prices after other-item navigation.
- **Temu:** once an exact item page has been reached, prevent a browser-followed main-frame redirect into an unbound storefront; on-page read-only JSON app state may supply price/title/image ONLY if the nested goods record explicitly matches the saved goods ID and the amount has JPY evidence. Do not click purchase controls or use private endpoints.
- **AliExpress:** recognize the *only* JSON-LD Product record on the actual verified same-item URL when the record has no URL/own product ID, a meaningful product name and exactly one JPY offer price. Reject any explicit conflicting item ID, wrong currency, conflicting canonical, other items and list/category pages. Still use existing strict hydration and specialist guards.
- **UI:** batch label is the existing floating overlay (`検索結果の更新中 01/07`) while the card ScrollView returns immediately to translationY=0 on trigger; no 58dp push-down, no list spacer. Works for filtered and all-item batches, two-digit progress counters.
- Regression gate exercises shipped Java-generated DOM JavaScript on positive/negative Temu and AliExpress records, preserved SHEIN proof, attachment route, and overlay offset. Legacy regression suite still runs; **not** a claim that storefronts permit live extraction or that an APK was compiled locally. Challenge/captcha and missing item-specific evidence stay UNKNOWN. If a web storefront immediately diverts the app even with the mounted engine, do not guess data.

---

# BookmarkLauncher 0.1.173 (versionCode 174) — Three guarded marketplaces recovery

Only base: `BookmarkLauncher_0.1.172_source.zip` (SHA256 `84072d10e6b7a8fd0125692613d88ebadfa34bac610b3695934807c9652b6dd4`). The app ID, fixed keystore, workflows, MainActivity, database schema, independent specialist parsers and existing product data compatibility are preserved.

- SHEIN: retain an exact-item JPY price observed in the current WebView document while later polls obtain a verified title and gallery. A new main-frame document, conflicting prices, other-item redirect or challenge invalidates the price; no synthetic stock status.
- AliExpress: saved product-ID marketplace URLs, including mobile/short aliases that existing strict marketplace identity recognizes, always enter serial, one-WebView marketplace field processing. The page no longer launches redundant generic stock/image probes in this scenario. Product JSON-LD without URL can qualify only when an explicit productId/itemId/SKU equals the requested item ID on the same page.
- Temu: the same explicit-ID JSON-LD restriction applies. After a verified item page redirects to an unbound storefront, fail promptly with diagnostic evidence rather than waiting through the full marketplace timeout. Reject stale evaluateJavascript callbacks from a previous main-frame navigation.
- Failure to receive item-specific data still leaves unavailable/price/stock unknown; no site-wide cart or recommendation price is accepted. No bypass of site challenges or authentication is attempted.
- Offline Java/JavaScript negative and positive fixtures, existing full regression harness, and independent new session-price/market routing checks pass. This environment does not include the Android SDK/Gradle, so an Android APK build and live marketplace success cannot be claimed from these tests.

---

BookmarkLauncher 0.1.170 (171): SHEIN -cat- product URLs and Japan regional URL mapping; marketplace navigation evidence logs.
# BookmarkLauncher 0.1.169 (versionCode 170) — Consolidated guarded marketplace snapshot

Source of truth: `BookmarkLauncher_0.1.168_source.zip`, SHA256 `2969e6a2447a597a129dcd8c42552ade51ca0738eced47b8ef084d28034353a3`. This is a focused fix for GENERAL SHEIN/AliExpress exact-item URLs. During a manual or user-triggered batch refresh, the *same* price WebView document evaluates exact item-bound title, JPY price and image-gallery candidates; the later independent general stock and image WebViews are skipped for those guarded marketplace items. Without verified stock evidence, status remains UNKNOWN. HTTP 200 never proves the product. The `pageKind` field is now passed into stability/exit checks; a stable unbound landing may trigger the one bounded SHEIN host retry. A main-frame navigation resets accumulated item evidence and title. Other sites' specialized extractors and signature settings remain unchanged.

Validation: actual Java-generated composite JavaScript fixtures for matched item, unrelated item, canonical mismatch, currency mismatch, bare gallery and landing; GENERAL/marketplace regression tests; `prepare-build.sh` checks. No claim of APK build or live storefront availability.

---

# BookmarkLauncher 0.1.167 (versionCode 168) — Strict marketplace title/price recovery

**唯一の正本ベース:** `BookmarkLauncher_0.1.165_source.zip` (SHA256 `e2dd389cc779e6c0b12a3c37215992381b4a494a80a17128bde20660d0067c71`)。以前の正本を混ぜず、`applicationId`、固定署名、DB、workflow、AndroidXを保持。

- SHEIN・AliExpressの保存商品IDを維持する既存HTTP→WebView経路をそのまま利用。価格WebViewで、商品ID付き水和データに加え、商品URLと一致するProduct JSON-LD、同一商品のcanonical＋商品固有H1からタイトル／円価格を限定抽出する。商品名と価格を別々に返せる。
- 通常の「画像だけ取得できた」パスでも、同じ画像WebViewに商品ID検証済みタイトルの追加照会を行い、価格取得の失敗に左右されず名前を保存できる場合を増やした。JSON-LDが無ければcanonical一致＋商品領域H1を要求し、他商品・サイトバナー・単なるOGタイトルは名前として採用しない。
- 商品名保存は元URL・GENERALモード・未編集カード・商品ページ形式を再検証し、ユーザー編集済みタイトルを上書きしない。価格／画像／在庫の保存値とは独立。再照会は1250ms上限、画像保存はタイムアウトでも継続。
- 価格は明示的なJPYまたは円記号のある、同一商品に束縛された構造化価格／限定DOM価格だけを認める。USD・誤canonical・異なる商品ID・サイトトップへの遷移では価格／タイトルを採用しない。在庫GENERAL A～Gは変更なしで、証拠がない場合UNKNOWNを維持。
- 診断`price.webview.metadata`および`image.webview.metadata`でタイトル検証、canonical一致、Product構造化データの件数、失敗理由を記録。商品本文・名前のログ出力はしない。
- 検証：新Java17実コンパイルとJSフィクスチャ14件＋接続テスト8件、以前の商品ID／URL・画像テスト、既存のWish回帰検査、署名・ビルド設定の維持を確認。**Android APKの実ビルドと実機のSHEIN/AliExpress取得は、この環境で未確認**。取得対象サイトが商品データを提供していない、CAPTCHA/トップへ切り替わる場合はUNKNOWN／未取得のまま保護。

---

# BookmarkLauncher 0.1.165 (versionCode 166) — Marketplace URL access fix

**Only base:** supplied BookmarkLauncher 0.1.164 (versionCode 165) `source.zip`, SHA256 `beb24ea0fdfd5074dc2190700dd42e593143dffe9c793c1d512d048442f97751`.

- Fix `WishlistPage.java` compile error at the `WishlistGeneralMarketplaceIdentity.sameItem(URL,URL)` call by changing only its access modifier to `public static`. Its item-ID comparison logic is unchanged.
- Add a separate-package Java compilation check in `scripts/check-marketplace-route.py` to catch this access error in future CI checks; previous runtime route assertions retained.
- Preserve the app ID, fixed signing key, existing app data layout, AndroidX, GitHub workflows and build preparation script; increase versionCode monotonically from 165 to 166.
- Offline source/regression tests verify the change. Full Android Gradle/APK build and on-device behavior are not verified locally.

---

# BookmarkLauncher 0.1.162 (versionCode 163) — Safe GENERAL product recovery

**Only base:** `BookmarkLauncher_0.1.161_source.zip` (SHA256 `397686745c4c3f08f24340773558b9bf8bd30f61a97a95d6bdb1c66192f4683b`). `applicationId`, signing keystore, database schema, acquisition modes, AndroidX, build workflows and `scripts/prepare-build.sh` unchanged.

- GENERAL URL identity: exact HTTPS SHEIN `-p-<itemId>.html` and AliExpress `/item/<itemId>.html` routes; category/listing pages and forged domains rejected. Original shared `WishlistGeneralProductIdentity.code()` preserved exactly; new adapter is isolated.
- Item-bound navigation: WebView price/image redirect to a different item ID rejected, including across same-marketplace mobile/desktop aliases. Never infer stock from the existence of a cart button; existing GENERAL A-G inventory checks unchanged.
- Image: no page-wide `og:image`, `twitter:image`, unbound JSON-LD or generic broad image scan on these two guarded marketplaces. Prefer exact-page primary gallery, matching heading-alt, or unique URL-bound Product JSON-LD; reject banners, logos, recommendations and wrong item IDs. Image DOM investigation starts on recognized exact product pages even when the HTML crawler had no image.
- Earlier non-user-edited auto-saved AliExpress/SHEIN images may be replaced only after a new item-bound image is downloaded. User-edited images stay untouched; an unsuccessful recovery does not erase the existing image. Image-specific trace includes DOM reject reason and attempt count.
- Price: existing price extraction is preserved; exact URL allows the existing guarded WebView price probe to inspect instead of prematurely treating the document as non-product. Currency ambiguity and unverified prices remain null. Image/name/stock data remain independent.
- Regression: `python3 scripts/check-wishlist-regressions.py` plus `python3 scripts/check-general-product-recovery.py`. Java 17 helper compile, JavaScript syntax, wrong-item/category/fake-host and primary-gallery/banner/JSON-LD negative fixtures. Actual Gradle APK build, site live DOM and device outcomes **not verified** here.

---

# BookmarkLauncher 0.1.161 (versionCode 162) — Honma Store follow-up

- Base: verified 0.1.160 source.zip only. No acquisitionMode migration.
- Fixed strict Honma table parsing: separate code/net/gross table cells, layout separators and visible DOM spacing. Gross (tax-inclusive) price exclusively; a listing or conflicted price fails closed.
- Repaired Honma buy-box stock inspection: exact product route and bounded product code/gross evidence, item-local enabled `purchase` controls and negative stock evidence; no site-wide cart links.
- Repaired Honma gallery lookup near the item heading (IMG, lazy, linked and inline style sources), excluding navigation icons.
- Added identity and DOM-evidence diagnostics on unknown stock, Honma image trace; price recovery remains unchanged outside the isolated Honma parser.
- Protected site-specific ZOZO/ASKUL/Joshin behavior, signing files, workflow and AndroidX.
- Regression checks and isolated Java/JS tests run; actual Android APK build and live device not performed here.

# BookmarkLauncher 0.1.160 (versionCode 161) — Honma Store packaging-shop isolation

唯一の修正ベース: `BookmarkLauncher_0.1.159_source.zip`（SHA256 `73e2c6866d4bf052d691c5356ff4633edd28401c657e47e36183a6fac979a77e`）。保存済みGENERALモード、データベース、アプリID、固定署名、AndroidX、GitHub Actionsを変更しない。

- 本間商店 **包装店** `https://www.honma-store.net/shop/products/view/<商品ID>(/category:<カテゴリID>)` に限定して、商品詳細URLを認識。商品IDが異なるリダイレクト、一覧・カテゴリー、偽ドメイン、HTTPを拒否。別サイトの `honma-store.com`（原料店）は対象外。
- 専用HTTPパーサーは商品コードのある単一商品ブロックから **税込価格** のみを取得する。税抜「販売価格」、単価、送料・別商品を値段として採用しない。名前も同じ商品ブロックの近接見出しを優先。商品写真は商品見出し付近に限り、アイコン・バナーを除外。汎用の画像スキャンによる上書きを禁止。
- WebViewも本間商店に限って税込価格・商品画像・在庫を独立したスクリプトで調べる。GENERAL A〜G を変更せず、成功済みZOZO/ASKUL/ジョーシン等の専用判定には不干渉。本間商店ではアイテム検証・商品購入フォーム・数量入力・有効な購入ボタンが揃う場合のみAVAILABLEとし、根拠が弱い場合はUNKNOWNを維持する。値段がHTTPで取れた場合には在庫WebView→画像WebViewを直列実行。
- 公式ページを参照したオフライン検証例: BF-384（サイト商品ID2298、商品コード61357、税込1,430円）、VK-22（サイト商品ID640、商品コード5130、税込561円）。これらのカードIDが診断中の2件と一致するかは端末未確認。
- テスト: Java17隔離コンパイル＋HTTP価格/URL/不一致・一覧フィクスチャ、JavaScript3本のNode構文検査、価格・在庫DOMフィクスチャ、既存回帰テスト、ZIP CRC/署名ワークフロー維持確認。**Android APKビルド・実機取得成功は未検証**。通信環境がないためサイト生HTMLへのJavaパーサーの統合実行も未検証。

---

# BookmarkLauncher 0.1.159 (versionCode 160) — Wish site labels, presentation-only

Only base: BookmarkLauncher_0.1.158_source.zip (versionCode 159). Four Wish store chips are now derived solely from the saved URL host: ZOZO (zozo.jp), ニトリ (nitori-net.jp / nitori.co.jp), ASKUL (askul.co.jp), モノタロウ (monotaro.com). Exact host or dot-boundary subdomain match is required; fake domain suffixes do not qualify. Persisted GENERAL and other acquisition modes remain untouched. Existing Amazon/楽天/Yahoo!/MUJI/etc. mode chips are retained for all other URLs. Both collapsed right-edge chip and expanded URL-row chip reuse the previous N-white/N-BG low-profile design. No DB or URL updates.

Confirmed v0.1.158 on-device ZOZO selected-DID stock AVAILABLE, ZOZO title and ASKUL title success: their price, stock, image, title, WebView and routing source files are byte-for-byte unchanged. Existing source regression guard retained. An earlier unlabelled card reported inability to establish a product detail; without its saved URL no inference about MonotaRO or any site is supported, so this patch does NOT change product identification or claim to fix that failure.

Offline validation: Java parser, site-badge unit cases, source regression guard, signing/workflow integrity and ZIP CRC. GitHub Actions APK build and device UI are not verified here.

---

# BookmarkLauncher 0.1.156 (versionCode 157)

- Based exclusively on 0.1.155 (156) source.zip. Preserve the applicationId, AndroidX, fixed signing keystore, workflows, existing wishlist database, successful price/image/stock adapters and the GENERAL A-G -> dedicated sequence.
- ZOZO: rendered title retrieval is now a separate item-ID-checked, title-only path from the already-running stock WebView. Works even if size-specific inventory remains UNKNOWN. Rejects a different canonical goods ID or conflicting shop. Never overwrites a manually edited title.
- ASKUL: repair the order-number match in the generated JavaScript regular expression. Continue requiring exact code and exact detail URL before reading product headings (including h6).
- MUJI: accept one verified visible product-name heading from item detail elements if the primary h1 is missing/ambiguous, checking the exact saved JAN URL and canonical. Do not infer titles from unrelated items.
- ZOZO inventory: within exact-goods/exact-DID hydration, inspect bounded nested stock objects; reject different goods/DID and any contradictory out-of-stock evidence. Uninformative duplicate records do not negate an explicit item-bound positive stock record. Record product-bound, nested, and unproven state counts. No page-wide purchase-button shortcuts.
- Offline checks: Java 119-file syntax parse, generated JS parse, 14 exact-DID stock fixtures, 9 strict title fixtures, existing regression guard, signing artifact comparison. Android APK build and live ZOZO/MUJI/ASKUL results are NOT verified.

# BookmarkLauncher 0.1.155 (versionCode 156) — ZOZO商品固有のdid/在庫構造化状態検証

**唯一のベース:** `BookmarkLauncher_0.1.154_source.zip`（SHA256 `2c94c56bd1deb57a394a8fe9c32e070f89f598709d2b7e53f26ae780e4d813da`）。

- 0.1.154の実機ログで `id=true`、`didNodes=0`、`didLocalStock=0`、表示カートは一時的に1個という事実から、既存のDOM属性内 `did` 検索のみでは照合できないことを確認。
- 商品URL、商品固有ID、厳密な`did`、同一商品の構造化商品在庫レコードを確認するZOZOのみの読み取り専用フォールバック。HTML側に`did`属性が無くても、埋め込みJSON/購入ボタン近傍のReact propsが、正確な商品ID＋正確なdid＋正の在庫を一意に持つ場合のみ「購入可能」を返す。
- `did`なし、別商品、ID不一致、在庫無し、矛盾や複数候補、JSON未公開時は肯定しない。ページの単なるカートボタンや他サイズの在庫では「購入可能」にしない。通信やクリック・フォーム値変更なし。
- EDION/伊勢丹/ジョーシンを含む他ドメインの判定、GENERAL A〜G、価格・画像、表示、アプリID・署名・DB・CI維持。実機に構造化データが無ければ依然UNKNOWNとなり得る。Android実機未検証。

---

# BookmarkLauncher 0.1.154 (versionCode 155) — EDION gross price + ZOZO exact did evidence

**唯一のベース:** `BookmarkLauncher_0.1.153_source.zip` (SHA-256 `754f207416cb818792596e77647a53401a7dcdb6f177a6279b287f4563f5d74a`).

- **EDION商品価格:** 同一商品と購入操作を検証した描画済みDOMのタイトル直後から、`WEB価格` に対応する明示的 `税込` 金額を限定抽出。税別の第一金額、クーポン/ポイント/配送・関連品の別金額を競合とせず、複数の異なるWEB税込候補は引き続き拒否。取得成功時は同一WebViewから保存するため、独立WebViewの追加通信は不要。既存の伊勢丹・他サイト価格は維持。
- **ZOZO選択商品:** `?did=` の一致を商品ボタンの祖先属性だけでなく正確な `data-goods-detail-id` / `data-stock-id` / 同一オリジンリンクの `did` にも拡張。さらに正確なdidの選択肢がボタンの隣にある場合、商品内の短く一意な選択肢エリアで「did/在庫あり/カート」の3点が一致した時のみ確認。グローバル購入ボタンや他のサイズ・色からは推定しない。専用ログ didNodes/didLocalCarts/didLocalStock を追加。
- **保護:** 既存EDION/ISETAN在庫成功ロジック、GENERAL A〜G、Joshin等他店、購入サイト画像/価格取得、モード表示の固定寸法、署名・アプリID・データ形式・CIを維持。

**検証:** Java17構文、生成JavaScript構文と商品単位の肯定/否定フィクスチャ、回帰スクリプト、prepare-build.sh、JKS/CI/source.zipファイル一致。Android Gradle APKビルドと実機の結果は未検証。

---

# BookmarkLauncher 0.1.153 (versionCode 154) — ISETAN / EDION / ZOZO identity and stock recovery

**唯一のベース:** `BookmarkLauncher_0.1.152_source.zip`（SHA-256 `5ab562ec794dc9a4c97f4ea5fc18efe6caf12561180ebd6307edfee176e37399`）。

- **伊勢丹:** `isetan.mistore.jp/kyoto/product/<商品ID>.html` および `/sogogift/product/<商品ID>.html` を、従来の正規商品URLに追加。検索/一覧は対象外。実在する京都伊勢丹の27桁商品IDのURL構造と在庫表「◎在庫あり」を踏まえ、同一商品の可視の在庫行＋購入ボタンの両方を確認。非表示の「在庫切れ」テンプレート文言を誤認しない。
- **エディオン:** 税込の現行価格が主価格フィールドで一致する場合はそれを採用し、周辺にある別価格を無条件に競合とみなさない。主価格が曖昧/異なる場合は従来どおりUNKNOWNに留める。在庫は同じ商品ページの「配送受取のかた／在庫状況 ○在庫あり・△在庫わずか」と有効な購入操作が揃った場合だけ確認し、他商品の在庫や汎用カートのみでは成功としない。
- **ZOZO:** 保存URLが `goods`、正規URLが `goods-sale`（またはその逆）、あるいは公式ホストの www あり／なしで異なる場合でも、正確に同じgoods IDかつショップ一致なら正規商品として照合。明示的な `(ZOZO)` 問い合わせ番号の公式オフセットも補助識別に使う。`?did` バリエーションの照合は変更しない。異なるgoods IDは引き続き拒否。
- **隔離:** GENERAL A→G → 固有モードの順序、リトライ、UI固定寸法、保存DB、署名、ジョーシンなど成功済み処理は現行から不変。固有モードでも根拠が弱い在庫はUNKNOWNのまま。

**検証:** ソース回帰検査、Java 17構文・生成JS構文、商品URL認識とZOZO別形式URL照合、既存保護ファイルSHA、ZIP/署名の同一性。実機での対象商品の取得成功は未確認。

---

# BookmarkLauncher 0.1.152 (versionCode 153) — 情報更新モード表示のガタつき防止

**唯一のベース:** `BookmarkLauncher_0.1.151_source.zip` (SHA-256 `1960dce59e7c2d5e5436f57270663e9bd864b3b5fb7b21234d600dd4127f38fb`).

- 折りたたみ時のカード右列は常に80dp、展開時は140dp。更新開始・終了や `GENERAL A`〜`G` → 各サイト固有モードの遷移でサイズを変更しない。
- 有効な位置の更新モード行は非更新時も `INVISIBLE` で15dp + 上3dpの表示枠を確保。もう一方の（折りたたみ/展開で未使用の）行だけ `GONE`。商品名、URL、価格・在庫表示および隣接カードの位置をモード表示に依存させない。
- モード文字は折り返さない固定幅・固定高さの1行。長い文字列は省略表示。Nホワイト `#A9A999`、背景/枠なし、表示位置は従来どおり。
- 取得パーサ・在庫検証・WebView・DB・固定署名・アプリID・GitHub Actionsを変更せず、見た目のみ修正。

**検証:** ソース差分、既存の回帰テスト、更新モード固有の固定寸法検査、Java構文検査、ビルド準備スクリプトと署名ハッシュ/ZIP整合性。Android実機でのUI動作は未確認。

---

# BookmarkLauncher 0.1.151 (versionCode 152) — serial GENERAL → site-specific stock inspection

**Sole base:** `BookmarkLauncher_0.1.150_source.zip` (SHA256 `06d0a1fd1a138624f097dea0fc1eadd93deb48f2c45349e8bc3c09eaf9f5d43d`). Fixed Android signing, package ID and retained marketplace/retailer implementations are unchanged.

- On starting an eligible product-stock WebView probe, evaluate the same-item `GENERAL A`, then B through G in series (read-only), and only then invoke the appropriate site/merchant-specific parser. This applies even when a dedicated mode is available, with no parallel inspection and no early cancellation after an A-G positive. For generic-only sites the original guarded GENERAL retries remain available after the initial sweep.
- Dedicated ISETAN/EDION/AU/ZOZO routing stays limited to the original, identity-verified product URLs; legacy ASKUL, JR Central/Tep​pan Kōbō, HIRAKI, MUJI and marketplace stock adapters remain independently guarded. A dedicated `UNKNOWN` does not erase a *verified* positive GENERAL result for the same GENERAL-mode item, and a positive specialist result can still establish the item. Merely seeing a cart link never proves stock.
- The collapsed/expanded update progress line retains its position (under title / under URL) but now uses N-white `#A9A999` **plain text without a badge background or rounded border**. Label follows the actual A-G stages and site-specific step. At the end of an update it is GONE, with no residual height.
- JR Central's existing item/SKU/variant/image-cart verified stock script is unchanged. Serialized its native WebView inspection and made an absent HTML body a delayed retry rather than consuming the five item-check attempts; the pre-existing absolute timeout still bounds the operation. This targets the reported intermittent `body-missing` diagnostic without overriding real out-of-stock results.
- Explicitly **not a guarantee** of Edion 403 reachability or ISETAN site-routing outside known exact product URL forms; those require new device evidence.

**Local checks:** JDK Java-17 syntax parsing of all 118 Java sources, regression script, `prepare-build.sh`, protected ten-source byte hashes, stable keystore, versionCode 152, ZIP CRC/SHA256 and source diff. Android SDK/Gradle APK build and device tests were not executed locally.

---

# BookmarkLauncher 0.1.149 (versionCode 150) — transient current-mode label (2026-10-21)

**Sole base:** `BookmarkLauncher_0.1.148_source.zip`, SHA-256 `ee088e6c9de498daaf13eeaf18aec94ec9d18715c655affcdd02d63a90b66a70`.

When a Wish card's manual or pull-to-refresh update is executing, a separate small N-white rounded label shows the actual current processing mode. **Collapsed:** directly below the product name. **Expanded:** directly below the URL/site line. Standard modes are named explicitly (GENERAL, Amazon, Rakuten, Yahoo!, MUJI, etc). When the existing GENERAL pipeline dispatches dedicated EDION/AU/ZOZO stock or image logic, its displayed label follows the actual dedicated submode. A generic price probe switches the label back to the actual saved route if that probe begins. The label remains while nested tasks are still running, and is cleared after the final `finishUpdate` for that card (including failures and timeouts); both label view and its temporary extra collapsed-column height disappear. Stored card modes, name, price, stock, image, signing key, database and merchant parsers remain untouched.

**Verification:** original ZIP identity, Java 17 parser for 116 Java files, protected 10-source parser checksum checks, CI preparation script, explicit UI placement and lifecycle source invariants, ZIP CRC/keystore identity. Android Gradle APK compilation and device UI behavior require GitHub Actions/real-device checks; they were not executed locally.

---

## 0.1.146 (147) — ZOZO image entry recovery, bounded purchase-identity audit (2026-10-21)

**Only base:** `BookmarkLauncher_0.1.145_source.zip` (SHA-256 `1a6ab625eb4e98372d132ebe57020e92208c7d35d19047aecf3fa31e89fb3016`, 136 ZIP entries). Fixed applicationId, signing key and installed data schema retained. This is a new source ZIP, not a prebuilt APK.

**Root failure fixed at the caller:** v0.1.145 introduced a Product JSON-LD/image-gallery extractor, but `WishlistPage.recoverMissingProductImage()` could still return before invoking that extractor, with no diagnostic reason. On exact saved ZOZO GENERAL goods URLs, the image recovery now uses the original saved product URL (not a possibly redirected HTTP 403 access page) and checks its verified product path, current saved mode and preview state before launching the existing image WebView. Any failure to enter is reported as `image.route.skip`; an eligible ZOZO card reports `image.route` and `image.webview.start`. The image WebView begins bounded sampling after the ZOZO main-frame **start** in addition to page-finished, so a stuck tracker cannot suppress image inspection. It records loading, HTTP/error, inspect and candidate stages. Existing price, image download/save guards, stock and all Joshin product routines remain unchanged in result semantics.

**Stock diagnostics only:** For unresolved GENERAL ZOZO, EDION and au domains, emit one bounded `stock.webview.identity.audit` observation after the first A–G pass: same document, canonical route match, unique heading count, item claim, Product schema, live/hidden add-to-cart and selected variant hints. This only makes the product-binding failure observable; it **does not** infer availability, click buttons, or change A–G/price/stock outcome. HTTP 403/503, unverified item IDs and ambiguous carts still remain UNKNOWN.

**Local verification:** protected source SHA-256 guard (10 files), prepare-build.sh, all Java 17 AST syntax, isolated real Java generator compilation and three generated JS syntax checks, six positive/negative DOM simulation cases, ZIP CRC and manifest/signing identity diff. The Android Gradle/GitHub Actions APK build and real-device end-to-end success are NOT verified in this environment. ZOZO image availability and EDION/au stock remain subject to device evidence.

# BookmarkLauncher 0.1.144 (versionCode 145) — Joshin image recovery + reusable G gallery technique

**Sole base:** `BookmarkLauncher_0.1.143_source.zip` (versionCode 144), unchanged stable JKS, applicationId, AndroidX and GitHub Actions workflows.

- **Joshin detail-route adapter (stored mode stays GENERAL):** recognize only HTTPS `joshinweb.jp/<category>/<categoryNumber>/<8–15 digit item>.html`, not category/index URLs or unrelated hosts. Joshin category redirects are allowed only when the terminal product code is unchanged. No database migration or new persistent acquisition mode.
- **Image recovery now runs for verified Joshin item URLs:** before this patch, stock G accepted Joshin but the image probe's stricter `isSingleProductPage()` denied the route; no `image.webview.start` event was written. The crawler now recognizes the exact Joshin item path, enabling the existing independent rendered-image probe.
- **Technique extracted for G:** `WishlistGeneralGalleryImageTechnique` inspects the same product's visible H1 and main gallery, image attributes including lazy/srcset, product-labelled image ALT, and product Open Graph image only for an exact item route. It rejects non-HTTPS, non-image, recommendation/header images and unrelated canonical product identifiers. Joshin is the first strictly scoped adapter; code is reusable for other verified product pages later, without assigning their site to Joshin.
- **Bounded image transport:** On Android 14+, attempt HttpEngine first for Joshin images, then the existing HttpURLConnection fallback, with 4s/5.5s connect/read timeouts and a three-candidate Joshin limit. Existing independent image-only storage rules and user edited-image protection are preserved.
- **Regression isolation:** Existing G **stock** verdict, A–F, dedicated ASKUL, MUJI and Teppan Kobo purchase parsers, d-shopping HTTP success, prices, cards, image files and UI are unchanged; only the image entry gate and Joshin-specific image handling are added.
- **Per-card logging:** `image.joshin.route`, `image.webview.start technique=G-gallery adapter=Joshin`, candidate count, transport failure reason, and final image save outcome.

**Local preflight:** JVM compilation of both new Java classes with minimal stubs, generated G image Javascript syntax validated via Node.js, seven synthetic gallery identity/image cases, ZIP CRC, retained signing JKS byte-for-byte, version settings and diff checks. No actual Android APK build or Joshin device image-save success has been verified yet.

---

# BookmarkLauncher 0.1.143 (versionCode 144) — GENERAL evidence-technique refactor (experimental)

**Sole base:** `BookmarkLauncher_0.1.142_source.zip` (versionCode 143). Signing JKS, applicationId, GitHub workflows, existing dedicated store handlers, data schema and UI remain unchanged. This is an internal design experiment, not a claim of device success.

- **B–F: extract techniques, not site modes.** Existing `WishlistGeneralAlphabetDom` remains the single read-only document/heading/SKU/cart/JSON-LD evidence collector. Distinct B SKU+quantity, C local buybox, D linked structured Product offer, E selected variant, and F MUJI-inspired dynamic stock rules are now separate, injected `WishlistGeneralEvidenceTechniques` policies. No copy of ASKUL/Yodobashi/Bic/UNIQLO/MUJI page lifecycle, site routing or private APIs. Old technical conditions remain byte-equivalent in meaning; originals remain intact.
- **G: reuse variant-local evidence method beyond ZOZO.** `WishlistGeneralVariantStockDom` retains the exact existing `WishlistZozoVariantDom` adapter and ?did match for ZOZO; for other GENERAL product URLs it accepts only a local in-stock text, one active purchase operation in the SAME small row, matching on-page product ID, and query variant ID when supplied. Negative/unknown/other-product/hidden/disabled/ambiguous results stay UNKNOWN. No automatic page clicks.
- **Shared item-code resolution.** `WishlistGeneralProductIdentity` centralizes the previously existing path/query SKU and Edion `p_cd` resolver for all techniques; it does not assume unrelated query params define the item.
- **Card diagnostics:** alphabet entries now show `technique=<identifier>` and generic G item/variant evidence rather than a ZOZO-only evidence label. Old A and site-specific success pathways remain untouched.

**Preflight performed:** extracted 0.1.142 source ZIP integrity; compiled all modified/new GENERAL technique Java classes on Java 17 with minimal dependency stubs; generated B–G JavaScript and checked with Node 22; 35 old/new B–F synthetic DOM comparisons (same status/reason/evidence) passed; 10 G synthetic DOM cases for product binding, stock, disabled cart, host and variant ID passed. These tests DO NOT constitute Android Gradle compilation or real device verification.

---

# BookmarkLauncher 0.1.142 (versionCode 143) — five-card follow-up and ZOZO G

**Only base:** exactly BookmarkLauncher_0.1.141_source.zip (versionCode 142), SHA256 `3a73f66c5f4c8272a3c1d46ba2378af19d707891e7869f1b05bea070887cc056`. Do not treat local checks as an actual GitHub Actions APK build or on-device verification.

Changes limited to the GENERAL fallback/diagnostics code, ZOZO-specific conservative G engine, ZOZO single-product route recognition, build version, and this README:

- **G: ZOZO variant stock.** HTTPS exact `/shop/<shop>/goods[-sale]/<id>/` recognition. The official ZOZO inquiry number may be goods ID plus 1,000,000; this numerical equivalence applies ONLY to a page's explicitly `（ZOZO）`-labelled inquiry number, never other merchants' SKU. The G stage requires a matching inquiry number, a *local* positive stock indication, and exactly one live add-to-cart for that variant. If `?did=<detail id>` is present, the SAME detail ID must bind to that variant's DOM. No click or add-to-cart is performed. Other merchants skip G entirely. For ZOZO only, generic B–F defer to G to prevent a different colour/size's stock from falsely verifying the selected variant; A's product-wide cart alone remains UNVERIFIED.
- **Cart candidate classification.** When a page has one live add-to-cart button plus informational purchase links, the single real button is inspected preferentially. Multiple buttons remain ambiguous, and presence of any button alone never verifies stock. Per-card audit records action type, number of dismissed links, out-of-scope cart links, item proof and number of claimed identifiers, but not raw identifiers or page text.
- **HTTP 5xx main frame.** Skip repeated general alphabet probes when the actual *main* WebView document responds 500+, e.g. a 503 error page with no product content. Failed images, frames or other subresources never trigger the fast fail. 403 continues via the already working verified-product WebView recovery path.
- **Successes protected.** No changes to dedicated MUJI, ASKUL, Hiraki, JR/Tep-pan Kobo, marketplace-specific stock/price, GENERAL HTTP stock parser, database/repository/tags, swipe UI, image pipeline, signing config or workflows.

**Local tests:** 105 Java files parsed with JDK 21 compiler in Java 17 source mode (zero syntax errors); actual B–G JS generators compiled using minimal test stubs; 6 generated stage scripts parsed by Node; 8 simulated G DOM cases (positive, negative stock, wrong SKU, disabled button, invalid heading, wrong host, exact did bound / unbound), and all B–F ZOZO-defer checks passed. Keystore and certificate fingerprint verified. No Android SDK build or device test occurred.

---

# BookmarkLauncher 0.1.141 (versionCode 142) — five-site GENERAL field trials

**Sole canonical base:** BookmarkLauncher_0.1.140_source.zip (versionCode 141). Keystore, app ID, Gradle workflow, original successful specialized engines and per-card data/history remain unchanged. Do not equate these local tests with a GitHub Actions Android build or device success.

Five observed card reports on Nothing A001 v0.1.140 informed this update:
1. ZOZOTOWN ¥990: HTTP 403, rendered price succeeded, SKU not bound; live purchase candidate disappeared as page hydrated. New strictly scoped `/shop/<store>/goods/<id>/` recognition, labelled `問い合わせ番号` matching, with ZOZO added to the **needs-stock-proof** exception so bare cart visibility never asserts AVAILABLE.
2. General item ¥4,500: HTTP/price/image succeeded but multiple live purchase candidates and absent SKU prevented stock confirmation. Exact SAME-SITE SAME-HREF duplicate add-to-cart links are now collapsed into one logical operation; different actions remain ambiguous. Labelled contradicting product codes are rejected.
3. d-shopping `/products/0054901411157702?sku=...` ¥5,380: GENERAL HTTP stock=AVAILABLE verified=true, price/image successful. Existing working HTTP parser unchanged; diagnostic `stockReason` now reveals which product-specific evidence generated the HTTP status on future reports.
4. General item ¥9,980: HTTP 403, price recovered, all B–F rejected `multiple-products`. Removed an inconsistent SECOND count of hidden/related `h1` elements after the initial correct visible-heading filtering; genuine multiple visible product headings still rejected.
5. General item with HTTP 403 + WebView price timeout, no stock probe started: stock inspection now continues independently for an individual-product URL if HTTP returned either TIMEOUT or ACCESS_RESTRICTED, regardless of the price WebView outcome. Unknown/list pages remain excluded. Added an Edion `/detail.html?p_cd=<8–14-digit-item>` recognition rule and query-ID redirect guard based on documented examples; no attribution to a specific unlabelled diagnostic card is claimed.

Additional carry-forward request: F now uses the successful MUJI-style positive-stock method, via strict same-URL/SKU matching of Product JSON-LD (including gtin13/gtin and labelled eight-digit merchandise codes), exactly one live product purchase operation and confirmed InStock. A numeric quantity field is not required when the exact structured Product offer proves stock. MUJI's proven dedicated mode and handler remain unchanged; F generalizes **the evidence method** for GENERAL candidates only. Unknown stock, conflicting stock, alternate SKU, other actions or listing pages remain UNKNOWN.

Single-item updates no longer erase an earlier batch diagnostic log; successive card runs are delineated by timestamps and refresh.start, with the existing 192 KB per-card cap retained. Added query SKU + `p_cd` checks to the existing WebView redirect verification.

**Local preflight:** extracted B–F script syntax verified with Node; simulated correct/negative/other-SKU/hidden-h1/deduplicated-href/variant-unknown cases; recompiled actual URL recognition and alphabet Java source with minimal stubs; check signing/workflow/applicationId/versionCode and ZIP CRC. No Android SDK or production GitHub Actions build is present, and five live sites have NOT yet been retested on v0.1.141.

---

# BookmarkLauncher 0.1.140 (versionCode 141) — MUJI isolated DOM mode

**Sole base:** BookmarkLauncher_0.1.139_source.zip (versionCode 140). All changes confined to MUJI-specific acquisition and safe mode routing, with original GENERAL A-F engines and ASKUL/JR/Hiraki/etc. intact.

- New `MUJI` Wishlist mode only for HTTPS `muji.com` / `www.muji.com` individual `/jp/ja/store/cmdty/detail/<13-digit-JAN>` product URLs. Existing GENERAL/UNRESOLVED cards for those URLs migrate on database v11 → v12 by changing only `acquisition_mode`; saved title, prices, images, history, tags and user edits remain untouched. Other sites remain in their original modes.
- User-triggered single or batch refresh uses the exact same MUJI path: skip the repeatedly timed-out HTTP transport; price-first identity-checked WebView, then independently render and verify stock regardless of price success, then try image if missing.
- Dedicated `MujiProductDom` read-only evidence probe: single matching page URL, product heading, visible enabled `products_cart`, hidden responsive replicas excluded, exact product JSON-LD URL/13-digit JAN or verified eight-digit printed 商品番号, and positive SKU-linked availability are needed for AVAILABLE. If stock or item identity is unproven, return UNKNOWN. Never add to cart, navigate checkout or infer purchase ability from a live button alone.
- Rendered price/image probes may inspect before pageFinished; reject redirect to a different product. Image fetch tries Android HttpEngine first on API 34+ then the old connection; with shorter timeouts and a two-candidate budget on MUJI to avoid six ~12-second sequential timeouts. An alternate engine is only a recovery attempt; success is not claimed without actual media bytes.
- Per-card MUJI price/stock evidence traces include bounded counters and diagnostic reason codes. Both manual and batch use the same MUJI acquisition path. No changes to GENERAL A-F engines.

**Local checks:** Java 17 syntax parsing for all Java sources; compiled mode and MUJI DOM script generator with JDK17 stubs; actual generated JS syntax checked by Node.js; mock-DOM available/unknown/soldout/hidden/other SKU/other URL checks; product URL routing, ZIP integrity, keystore/hash, build prepare script. GitHub Actions APK build and Nothing A001 on-device availability/image status remain unverified and must be tested.

---

# BookmarkLauncher 0.1.138 (versionCode 139) — GENERAL alphabetical retrieval engines

Base: exactly BookmarkLauncher_0.1.137_source.zip (versionCode 138). User clarification supersedes the earlier concept of generic A/B/C extraction *levels*.

Alphabet stage mapping for NEW/GENERAL product sites:
- A: existing GENERAL rendered purchase evidence (untouched selector), attempted FIRST for every GENERAL candidate. On an unrecognized URL, its result cannot alone certify availability.
- B: ASKUL-derived SKU + stock + quantity + cart binding, generalized to other sites without modifying the official ASKUL parser.
- C: Yodobashi-derived live single buybox, local positive-stock and cart evidence.
- D: Bic Camera-derived matching Product JSON-LD offers, own-stock and live product cart.
- E: UNIQLO-derived selected variant + positive-stock + bound cart checks.
- F: MUJI-derived dynamic product stock + quantity + own enabled add-to-cart, never view-cart alone.

All stages operate sequentially on one bounded, read-only WebView with validated host and path; any stage can return UNKNOWN, but only verified AVAILABLE may stop the sequence. The persistent Wishlist mode remains GENERAL. Unknown future product URL patterns are inspected only on a product-looking HTTPS path and require additional on-page identity; category/cart/search paths are excluded. It is NOT assumed that retailer-specific selectors can simply be run unchanged against a foreign storefront: each stage ports a specific evidence strategy with fail-closed identity/stock checks. New cross-site compatibility must be demonstrated on-device before declaring a site successful.

Changes: `WishlistGeneralAlphabetDom.java` (new stage source), stock WebView A->F serial fallback + bounded hydration repeats and structured stage diagnostics, earlier partial page DOM sampling, GENERAL price DOM repeated early while the page is loading, defer GENERAL stock probing until any pending price probe finishes, and resume stock verification after a price timeout for a safe single-product URL. Recognize CAINZ `/g/<item>.html` and NITORI `/ec/product/<item>` as GENERAL single-product paths only when HTTPS/host/shape match.

Protected byte-identical: ASKUL 0.1.137 successful SKU parser, HIRAKI, JR/鉄板工房, existing retailer and marketplace special parsers, saved Wishlist database/repository and tags, swipe UI, Android manifest, keystore, both Actions workflows, scripts/prepare-build.sh, scanner imports. No new stored `WishlistMode` values. Available with positive evidence is not inferred from "View cart"; absence does not imply sold out.

Verification: Java 17 parsing, extracted JS Node syntax, mocked positive/negative/cart-view/duplicate/redirect tests, original ZIP invariant hashes, `prepare-build.sh` and ZIP CRC. GitHub Actions and Nothing A001 end-to-end behavior are NOT verified.

---

BookmarkLauncher 0.1.136 (137)

Base: 0.1.135 (136). Changes: Home (finger left-to-right)->Wish, Wish (finger right-to-left)->Home; product-purchase vocabulary from 30+ domestic/international storefronts (separate ADD from VIEW/CHECKOUT); ASKUL SKU-bound product text stock evidence and "カゴへ" with fail-closed SKU/quantity/cart checks; HTTP TIMEOUT site-state recovered after successful WebView price, independently probe GENERAL single-product stock if eligible. No guessed availability; HIRAKI/JR/MonotaRO/UNIQLO dedicated scripts unchanged. Local tests, no actual GitHub Actions/Android verification.

---

BookmarkLauncher 0.1.135 (136)

Wish: left swipe disabled, right swipe returns Home. ASKUL: only product-bound, explicitly named and target-confirmed cart insertion modal can prove availability. Unconfirmed modal remains UNKNOWN.

# BookmarkLauncher 0.1.134 (versionCode 135) — ASKUL product-bound visible stock/quantity/cart evidence

Base: `BookmarkLauncher_0.1.133_source.zip` (SHA256 `10a8cbf1761e7df128ce6ff745b9771e8384d8d542f8f3d5ab117ace4143c84d`).

- ASKUL WNE6579: retain SKU-matched URL, on-page order-code, negative/disabled rejection and existing purchase classifiers. Add an independent read-only inspection of a **visible short stock-status label in the same SKU product main area** because existing generic recommendation-boundary cropping stops at ~701 chars before the relevant stock/quantity/cart panel. Only a specific positive stock label without conflict + quantity field + nearby explicit cart caption + exactly one live SKU-bound modal opener can verify AVAILABLE; generic body-wide stock hints or modal button alone still cannot.
- Fix a genuine product-modal rejection: `c.closest('[class*=modal]')` matched the `js-modal1803` button itself and incorrectly discarded it. Check excluded *ancestors*, not the button. Classify modal targets without clicking, and report SKU-bound stock panel evidence in per-card diagnosis; never record modal contents or personal data.
- No changes to HIRAKI 0.1.133 success, JR Central 0.1.132 success, MonotaRO, UNIQLO, Fumuroya, Gojochoubei, WebView lifecycle, workflows, app ID, signature and saved data.
- Local syntax/mock and ZIP integrity verification only. GitHub Actions and Nothing A001 device not executed; verify outcome via live card diagnostics.

---

# BookmarkLauncher 0.1.133 (versionCode 134) — ASKUL / HIRAKI on-device cart bindings

**Sole base:** `BookmarkLauncher_0.1.132_source.zip` SHA256 `bfa2288fd51224f14f09ea82fe7e5ceb8c9f3a60970c491da2c24cef3ce8dfcd`.

- ASKUL WNE6579: the raw real-device DOM audit on Nothing A001 found a live `button#modal_01.js-modal1803` with cart-related text in the product region, beside quantity controls; older classifier rejected it when a sibling modal duplicate existed elsewhere and when the label did not spell out `カゴに入れる`. Examine *each* actual modal separately and require verified URL + printed SKU, a sufficiently populated product area, cart-related accessible text excluding simple cart-view/help links, enabled status, an opener with an actual event/handler and a quantity control nearby. Exactly one qualifying **product-linked** opener can indicate AVAILABLE; hidden, disabled, unrelated/duplicated product openers, or absent product proof remain UNKNOWN. No click or order is made. The role of the site modal may still require user-device confirmation.
- HIRAKI 53896 color 99: the raw on-device audit found `a#tagCartInSmt` enabled *outside* the title's root while the row-level selector searched only inside the root and distance <=3. Locate a **single** page-level `#tagCartInSmt` with explicit add-to-cart text, reject navigation/recommendation and disabled controls, and bind it to the **sole** enabled color-99 quantity row in the SKU-verified item's stock table even across separate DOM parents. The disabled `#cartInsertButton` and hidden `.btn-cart` never qualify. Negative row evidence blocks AVAILABLE.
- Keep all existing read-only DOM audit and per-card/global diagnostics; the new reason codes and counters for modal-product linkage and page-level cart linkage appear in the same stock evidence JSON. No new WebView types, special rendering or UI changes.
- Byte-identical protection of all previous successes, including JR Central SG100130006 image-cart, MonotaRO, UNIQLO, Fumuroya and Katsuo-gobou, all price/image extractors, repository/history, search-filtered shared refresh, signing keystore, app identity and GitHub Actions workflows.
- Verification: Java syntax 102 files, modified classes compile, extracted JS syntax and safety mock tests 14 cases, build preflight and ZIP CRC + unchanged-file byte comparison. NOT an Android/GitHub Actions build or live-site confirmation.

---

# BookmarkLauncher 0.1.132 (versionCode 133) — generalized DOM/cart audit + device-proven cart identifiers

**Canonical base:** BookmarkLauncher 0.1.131 (versionCode 132), SHA256 `16b7f47ee9df7f48a86bd8c6f8ac73bbd2e07b381e8a62d375e5bd898f82823a`.

- For every saved GENERAL product refreshed through the shared stock WebView, collect bounded read-only pre-classifier DOM fingerprints and compare the presence of product-local enabled cart candidates with the site-specific verdict. Card diagnostics store summary, structured candidate samples and final verdict. The app-wide `DiagLog` stores bounded summary/verdict only, not document HTML/URLs, input values, cookies, credentials or user data. Non-WebView updates do not launch a new WebView for diagnostics. Successful dedicated modes / marketplace crawlers unchanged.
- JR Central SG100130006: actual user-device `input#cart_in[type=image]` is a valid product-cart candidate after exact SKU URL and selected large+lid variant verification; require one enabled control, no negative evidence. No click is performed.
- ASKUL: separately recognize `button#modal_01.js-modal1803` observed in user-device DOM. Since this may only open a modal, require exact add-to-cart accessible text and exactly one enabled verified product-local control to recognize it as an active purchase operation. Ambiguous multiple/disabled/generic modals remain UNKNOWN. Preserve price 103 WebView recovery and HTTP403 fallback.
- HIRAKI: distinguish actual `a.btn-cart` (hidden), `input#cartInsertButton` (disabled), `a#tagCartInSmt` (enabled). Only treat the latter as cart evidence if it is directly DOM-bound (short ancestor distance <=3) to the verified color-99 quantity row. No inference from unrelated/global controls. Keep item price/image and false-positive checks.
- Preserve canonical fixed keystore/app ID, both GitHub Actions workflows, prepare-build.sh, search-filtered Pull-to-Refresh, shared card/batch refresh, MonotaRO and Uniqlo successful paths, Fumuroya and Gojochoubei successful availability.
- Verification: Java syntax, extracted JavaScript syntax and mock DOM positive/negative tests, preflight scripts, ZIP integrity, file hash changes limited to targeted sources and version/README. Not a real Android device or GitHub Actions build; live outcome must be verified by user.

---

# BookmarkLauncher 0.1.131 (versionCode 132) — on-device pre-classifier DOM audit

**Single canonical base:** `BookmarkLauncher_0.1.130_source.zip` SHA256 `b4bb88b6767bf5aede63d751d7f9365ddd1ad31dd95a6e34f8c515eb4ec0ab8d`.

- Diagnose ASKUL, HIRAKI and JR Central's persistent missing add-to-cart evidence **on Nothing A001 without a PC** by inspecting the actual DOM in the existing detached stock WebView, *independently of the existing cart classifier*. No special attached/rendered WebView and no debugging bridge or new network endpoint.
- At two bounded checkpoints, card-only `stock.webview.dom.audit.summary` reports DOM readiness/size, raw purchase-text presence, control/button/quantity and prefiltered cart label counts, frame access/open-shadow counts; `stock.webview.dom.audit.element` reports only sanitized element tag, id, first CSS class and **attribute names** (not values), presence of onclick, enabled/hidden state, product/quantity proximity and frame/shadow scope. This exposes both recognized and unnamed structural candidates without treating them as verified availability. Console/network errors are classified without raw messages or URLs.
- No document dump, user input values, credentials, cookies, headers, request/response payloads or arbitrary page text are persisted. Recording is capped by count and existing per-card diagnostic storage; no click/cart action. Only these three verified stock probes have the new diagnostic. A blank/non-instrumented document or cross-origin frame is reported as incomplete, not as proof that purchase cannot occur.
- Keep all original purchase availability classifiers, price/image retrieval, search-filtered pull refresh, shared per-card/batch update flow, app database/history, MonotaRO/UNIQLO/Fumuroya/Katsuo-gobou successful behavior, AndroidX, workflows, app ID and signing keystore byte-identical to the canonical ZIP.
- Local Java syntax / diagnostic JS Node syntax and bounded DOM-mock tests / prepare-build / ZIP CRC checks are **not** GitHub Actions or real-device verification. Success of purchase detection is NOT claimed in this diagnostic release.

# BookmarkLauncher 0.1.130 (versionCode 131) — live cart evidence, common WebView restored

**Sole source base:** `BookmarkLauncher_0.1.129_source.zip` SHA256 `ecbfedcd27f3a95b6f26383b9450c554118e76c81dff5faf075f14b0a2e427a2`.

- Remove the entire 0.1.129 attached/rendered stock-only WebView, background page insertion, viewport layout waiting and warm-up scroll. All sites again use the existing shared detached `BackgroundDomWebView` stock probe. Only the old shared WebView probe gained HIRAKI's pageStarted + bounded fallback inspection, so a hanging pageFinished doesn't result in `attempts=0`.
- For verified products, a uniquely identifiable active `カートに入れる` / `カゴに入れる` purchase control is sufficient purchase-availability evidence; no second `在庫あり` label is required. The scanner checks actual actionable controls and their accessible names/attributes including open shadow roots; mere instructional text or sitewide cart links are not an action. No click, cart insertion or purchase is executed.
- ASKUL only uses exact `/p/WNE6579/` with on-page `お申込番号`, no restriction or conflicting negative; HIRAKI requires matching product number, color 99 and enabled quantity row; JR Central requires exact SKU, product title and selected large plate + lid. Disabled, missing, unrelated, contradictory or ambiguous cart controls remain UNKNOWN. The successful site-specific modes (MonotaRO, UNIQLO, Fumuroya, Katsuo-gobou) and existing price/image parsers are untouched.
- Preserves shared card/pull-refresh path, filtered updates, saved data, stable signing keystore, app identity, AndroidX and workflows. Local Java/JS parse, store-mock safety tests and preflight executed; Android GitHub Actions build and Nothing A001 live-site behavior are not verified here.

# BookmarkLauncher 0.1.129 (versionCode 130) — rendered, attached stock-only WebView

**Sole base:** `BookmarkLauncher_0.1.128_source.zip` SHA256 `938687682563398f8721a51fdd65e3a7dd9b6ecb728420de35295c177b717de4`.

- **Actual acquisition-mode change, not a diagnostics-only release.** For stock checks on ASKUL, HIRAKI and JR Central only, use a properly attached and laid-out WebView with drawing enabled. It is placed at child index 0 behind the existing fully opaque Wishlist page, rather than using a detached, `setWillNotDraw(true)` DOM-only view. Do not expose the page or intercept user interactions.
- Wait for a true `onLayoutChange` event and attached, positive viewport dimensions before calling `loadUrl`. This avoids assuming a posted Runnable means layout has completed. A bounded read-only `scrollIntoView` warms the product panel for lazy/intersection-observer rendering; it never clicks, changes quantities, or submits forms.
- On every completion, timeout and cancellation path, detach and destroy the WebView and its pending layout listener. The existing item URL, variant, enabled-cart, negative-stock and UNKNOWN safety gates are unchanged.
- The successful stock pathways for Monotaro, UNIQLO, Fumuroya and Katsuo-gobou remain unchanged. Existing price/image WebViews, shared per-card/batch update pipeline, filtered Pull-to-Refresh, database and signing/config files untouched.
- **No Android/device success claim** until verified on Nothing A001. Syntax and isolated lifecycle/invariant tests are local only; the full GitHub Actions Gradle build is not run in this environment.

# BookmarkLauncher 0.1.128 (versionCode 129) — shared product-bound stock evidence

**Sole base:** `BookmarkLauncher_0.1.127_source.zip` SHA256 `31faed758c95a5da6862848a387436f3317b0b367aa78c70a3400b76923e0f68`.

- Introduce reusable, **read-only** `wishlist/ProductEvidenceScopeDom`: locate each item using a verified product label, retain the exact marker when recommendation headings appear before it, stop at unrelated-product sections after it, and scan enabled purchase controls in relation to the item's quantity field. Reject navigation/recommendation controls, hidden/disabled elements and unbound cart buttons. The shared helper **never independently changes stock status**, clicks a control, or assumes a generic stock hint proves a sale.
- **ASKUL WNE6579:** replace the fragile string split that could remove the product number and actual stock text whenever `関連商品` appeared before the SKU. Add directional scope and shared-control diagnostics; preserve exact-SKU/price and dedicated frame/JSON-LD conditions. Do not classify AVAILABLE without verified product-specific stock and purchase evidence.
- **HIRAKI 53896, color 99:** inspect the same shared purchase/quantity anchors. A single cart candidate may supplement the dedicated probe only if unique, enabled, bound to the actual item quantity row, and not a sitewide/related-product cart. Color, row, quantity and stock-negative checks remain mandatory.
- **JR Central SG100130006:** reuse the same control diagnostics and conservative bound-cart fallback only after exact SKU URL, correct product heading and correct selected *large plate + lid* variant. Preserve product-specific refusal for wrong options, negative stock and invalid carts.
- No changes to existing successful MonotaRO, UNIQLO, Fumuroya or Katsuo-gobou stock extractors, prices/images, repository/history, background jobs, user data, UI, filtered Pull-to-Refresh, shared update pipeline, AndroidX, signing keystore, applicationId or workflows.
- Local verification: Java sources syntactically parsed, affected stock Java compiled, exported scripts checked with Node, mock positive/negative conditions and shared scope/control tests, release archive integrity and unchanged protected-file bytes. **GitHub Actions Android build and Nothing A001 live-site behavior not executed**.

# BookmarkLauncher 0.1.127 (versionCode 128) — independent store stock evidence

Sole base: `BookmarkLauncher_0.1.126_source.zip` SHA256 `e58956e5b932d3baf4c8354277983a1efae123ec2d42148c4b192d1b58875ca4`.

- JR Central (`SG100130006`): match a product-specific heading among actual headings (not only the first h1), or matched product title metadata after exact SKU URL verification; retain exact selected large-plate-and-lid variant check, purchase action readiness, and negative checks. Per-card traces distinguish title source, selected-variant source, control and action candidate counts.
- ASKUL (`WNE6579`): investigate only same-origin iframe documents that themselves carry the exact registered SKU; unknown or cross-origin frame evidence never becomes availability. Per-card trace records independent scope, stock-positive/negative, frame, purchase evidence. Original ¥103 WebView price probe preserved.
- HIRAKI (`53896`, color `99`): improve purchase candidate diagnostics near the item-specific quantity row without assuming unlabelled quantity +/- buttons are purchase actions. Product SKU, selected color and stock-row proof are still mandatory.
- Protect successful Monotaro, Uniqlo, Fumuroya and Katsuo-gobou stock routes, saved data, existing prices/images, filtered Pull-to-Refresh shared pipeline, stable keystore, app ID, workflows and AndroidX/ML Kit setup.
- Local checks: 100 Java parse units, isolated Java class compilation, generated JS syntax, mocked JR/ASKUL negative/positive cases, pre-build invariants, archive CRC and byte-identical protected resources. GitHub Actions/Android real device stock success **not tested**.

# BookmarkLauncher 0.1.121 (versionCode 122) — ASKUL + HIRAKI purchase-state probes

**Sole base:** BookmarkLauncher 0.1.120 (versionCode 121), source SHA-256 `e4e430f8db9decc4e79f8af0419dcfabd0001e4f36e8c1163cb083cd5c2cb519`.

- ASKUL GENERAL `/p/WNE6579/`: continue requiring the exact HTTPS item URL and on-page `お申込番号` match. Inspect item-specific purchase controls in the rendered DOM, including icon buttons / accessible labels / non-hidden cart actions. In addition, accept explicit schema.org `Product` `offers.availability=InStock` only when the structured Product SKU equals the requested SKU and the offer has a positive JPY price. A catalog item, unrelated Product structured data, shipping price, a stock disclaimer, or an HTTP 403 page alone cannot prove that the specific SKU is currently purchasable. No click or cart mutation.
- HIRAKI GENERAL `/ec/pro/disp/1/53896`: inspect the exact item number + actual color `(99)` stock/quantity table, stock icon attributes, active quantity input and enabled product cart. Stock symbol LEGENDS elsewhere on the page are never used as a stock result. A confirmed negative row can produce UNAVAILABLE; missing/ambiguous product evidence remains UNKNOWN. Add card-scoped `stock.webview.hiraki.evidence` showing SKU/color/table/row/quantity/cart/icon/stock reason to identify why availability is UNKNOWN. Bounded recheck while the rendered color table hydrates.
- Keep all successful image and tax-inclusive price capture, preserved card history, earlier registration value, app design, main diagnostics and screenshot/preview behavior. Dedicated UNIQLO (fully working), MonotaRO (fully working), Yodobashi and BicCamera including its HttpEngine image path, and Amazon/Rakuten/Yahoo extractors are not modified. Only ASKUL/HIRAKI purchase evidence and associated diagnostic plumbing change.
- Keep applicationId `com.cmyk.bookmarkslauncher`, original fixed signing keystore SHA256 `c15c0dcfdadba605edaab3f8ee4e732ad913a021d1100febb6894dd6e918f62a`, Gradle workflows both YMLs, `scripts/prepare-build.sh`, Java scanner imports, AndroidX and all existing cards/data unchanged.
- Local verification: Java source syntax parse (99 files), generated JavaScript syntax, 14 synthetic same-SKU/wrong-SKU/disabled/sold-out and product-offer tests, ZIP CRC and unchanged-file comparisons, prepare-build preflight. **NOT TESTED:** Android Gradle or GitHub Actions build; actual ASKUL/HIRAKI mobile WebView behavior may still return UNKNOWN when authoritative sale-state evidence is absent.

# BookmarkLauncher 0.1.120 (versionCode 121) — card price row and verified product purchase signals

**Only source of truth:** BookmarkLauncher 0.1.119 (versionCode 120), SHA256 `9ad65c04a531550a6152f0fab3cfc79bccc4e9e1e42100728a6e33fad5770ff2`.

- Expanded Wish card registered/current price row minimum height 44dp → **48dp**, retaining 12sp text and WRAP_CONTENT; previous collapsed price/store row unchanged.
- UNIQLO variant-bound purchase status: when all three selected variant controls (color, size, length) and original URL identity are unambiguous, a **single active, enabled and product-local add-to-cart control** with no sold-out/negative evidence may establish `AVAILABLE` even if the detached WebView has no separately rendered stock label. Require all three selection proofs, never infer from product-level price or unselected/default cart controls. Disabled/multiple/related-product cart actions, variant conflict and explicit sold-out remain `UNKNOWN`; retain all existing price/image extraction code.
- ASKUL `WNE6579` purchase check: after successful exact-SKU price detection, inspect stock+cart evidence within **the same successful detached WebView** before discarding it; 5 bounded polls max with a 7.2s hard deadline. Only the existing strict ASKUL SKU-specific stock DOM can approve `AVAILABLE`; if unverified, continue the old independent stock WebView, keep `UNKNOWN` rather than synthesizing status, and keep already confirmed price 103. Write `price.webview.askul.stock` trace fields into the card-only diagnostic; never click cart or use another SKU.
- Do not change the MonotaRO image+price+availability success pipeline, BicCamera HttpEngine, Yodobashi, other GENERAL sites, marketplace extractors, all existing user records, price history or images. Keep both GitHub Actions workflows and `scripts/prepare-build.sh` byte-for-byte, `applicationId`, AndroidX, scanner imports and fixed JKS signature.
- Local verification: Java parser on all 99 sources, Node syntax on actual exported Java-to-WebView scripts, simulated positive/negative same-product evidence tests, preflight script, ZIP CRC and unchanged-byte protection. Android SDK/Gradle real build, GitHub Actions, or Nothing A001 live-site outcomes are **not** tested locally.

# BookmarkLauncher 0.1.119 (versionCode 120) — expanded price row, scoped stock probes, diagnostic copy dismiss

**Sole base:** BookmarkLauncher 0.1.118 (versionCode 119), SHA256 `d0a98e219f0ef471032be696cf51040385cb65b299251feee6013a3c76e5814f`.

- Expanded Wish card registered/current price row increases from 36dp to 44dp minimum, retaining 12sp and wrap_content for two-line/longer values. Collapsed 13sp price/label layout unchanged.
- Both app-wide and card-scoped diagnostic dialogs now dismiss after tapping Copy; original clipboard operation is retained.
- ASKUL-only stock read-only WebView: broader semantic purchase label and nearby product stock detection while retaining the requested SKU label, canonical HTTPS path, explicit stock positive evidence, enabled product cart, and exclusion of unrelated items. Bounded additional hydration wait; if evidence is missing, return UNKNOWN, never fabricate availability or change price.
- UNIQLO-only exact color/size/length stock: allow CSS-visible controls/availability metadata in detached DOM (rather than requiring `getClientRects()`); still require proof of selected variant AND item-specific valid cart AND stock evidence, reject ambiguous controls and negative stock. Existing price and images unchanged.
- YODOBASHI-only purchase operation: equivalent semantically visible cart fallback with primary-product and stock guards. Existing price/image retrieval unchanged.
- Ignore a non-existent retail probe when cancel() is called on a fresh object, avoiding bogus elapsedMs since system boot.
- MonotaRO full-success source and BicCamera HttpEngine, marketplace and GENERAL non-ASKUL modes untouched. `applicationId` and keystore remain fixed; both workflows and prepare-build.sh retained.
- Local ZIP/Java parser/JS syntax and synthetic guard testing are **not** a substitute for GitHub Actions or Android real-device checks.

# BookmarkLauncher 0.1.118 (versionCode 119) — Wishlist layout, per-refresh diagnostics, scoped stock checks

**Only source of truth:** BookmarkLauncher 0.1.117 (versionCode 118), SHA256 `2e113c5ceb670c20aa8c877e3d4cb186033bc81aaf4a49b28941878c2b25a953`.

- Collapsed Wish card summary: price (13sp) at left, purchase state in a flexible middle column and the original [store] pill pinned to the right on the same horizontal row. Avoid clipping with ellipsis in price and purchase state; expansion UI unchanged.
- Card-only diagnostic history automatically clears when a single-card manual information refresh is accepted, immediately before `refresh.manual.start`, and when a card's user-initiated full-list refresh begins processing it. Never clear on diagnostic-open, background scheduled refresh, or failed-to-start refresh. Other cards, application log, registered/current price, price history and preview images unaffected.
- ASKUL GENERAL stock probe: preserve exact same on-page `お申込番号` and HTTPS product path requirement. Observe semantic enabled cart operations without relying on `getClientRects()` in a detached WebView; require in-item `在庫：あり` evidence, exclude related sections and unavailable buttons, return UNKNOWN on insufficient/conflicting proof. Emit safe `skuMatch/stockFound/cartFound/cartEnabled/cartDisabled/reason` to that card's diagnostic log; no product purchase action.
- YODOBASHI-only DOM enhancement: separate fallback for a single enabled cart operation and stock evidence scoped to the main product section, excluding recommendations. DOM stock stays UNKNOWN for ambiguous/disabled buttons. Per-card diagnostic records bounded price/stock/purchase observer evidence during manual/batch probes. Earlier verified price and image saved intact when probes fail.
- UNIQLO-only rendered variant selector: in addition to existing URL and code-marked options, recognize explicitly checked product color/size/length input values when names match the variant axis. Do not trust incompatible selections, another color/size, or page-wide price/stock. Require exact variant proof for stock; add limited variant/purchase evidence to the per-card log. Existing stored price and preview preserved on failed fetch.
- In particular, validated MonotaRO image/price/availability processing, BicCamera HttpEngine image retrieval, Amazon/Rakuten/Yahoo and all other site modes are byte-identical. Unmodified fixed `com.cmyk.bookmarkslauncher` ID, stable keystore SHA256 `c15c0dcfdadba605edaab3f8ee4e732ad913a021d1100febb6894dd6e918f62a`, both GitHub Actions workflows and scripts/prepare-build.sh.
- Java AST syntax checks, extracted retailer JavaScript syntax, mock positive/negative same-product purchase tests, prepare-build script, zip integrity and protected-byte comparisons performed locally. Android SDK/Gradle full build, GitHub Actions and Nothing A001 live-site tests are **not** performed here; a successful real-device purchase-state check cannot be promised.

# BookmarkLauncher 0.1.117 (versionCode 118) — ASKUL product evidence without h1 dependency

- Only source of truth: BookmarkLauncher 0.1.116 (versionCode 117), SHA256 9f2a009a728fc5257e6931ee4f0369a722f64cda44c3f516b9a046fa7ac9a8f8.
- ASKUL-only DOM refinement in GENERAL: exact HTTPS product path + on-page お申込番号:<SKU> required; price from same product's explicitly labeled **税込** item-price table, or single gross price in bounded product-offer section **before** 配送オプション. Reject shipping 385yen, tax-exclusive 94yen, other SKUs, related products and ambiguous values. Product h1 no longer mandatory for ASKUL; MonotaRO code unchanged, preserves all-real-device-successful image/price/stock.
- ASKUL purchase/stock probe likewise no longer depends on h1, but still requires matching on-page item ID, the stock-available label and a unique enabled, visible purchase control. Does not tap controls or fabricate availability.
- New ASKUL card-scoped non-sensitive WebView price diagnostics: body character count, presence of heading, SKU label, restriction hint, exact gross price evidence, and original request HTTP response. Stock probe logs HTTP main frame and attempt states. Never logs raw page text, credentials or tracking URLs. Distinguishes restricted HTML from missing product structure. Only verified exact item-price/stock evidence can update the state to OK; never clear ACCESS_RESTRICTED because an image loaded.
- Preserve existing product identity, previous verified price history, user images, card diagnostic UX, GENERAL other retailers, dedicated marketplaces/large retailers, BicCamera's HttpEngine, MonotaRO, AndroidX, Code Scanner, both workflow YMLs, build scripts, keystore, and applicationId.
- Android Gradle/GitHub Actions/device tests are not run here; a site sending genuine 403 blocked HTML to both HTTP and WebView may still be inaccessible and remain ACCESS_RESTRICTED.

# BookmarkLauncher 0.1.116 (versionCode 117) — SKU-verified retail price recovery and 12sp price fields

**Only base:** BookmarkLauncher 0.1.115 (versionCode 116) SHA256 `b7ea6d89dece186195cf09a06b4e0e6211c9c0e17b80ca9582c6a052f4280a9c`.

- Expanded Wish card "登録時" and "現在" price fields return from 14sp to the original **12sp** to avoid clipping. Existing 36dp minimum row and image-edge alignment stay as configured, and collapsed 13sp price + product title remain unchanged.
- In a **user-initiated manual refresh** for the EXACT ASKUL/MonotaRO GENERAL product pages, when HTTP does not return a price, run price WebView **before** stock WebView, rather than simultaneously. Stock remains independent and is attempted afterward even if price cannot be acquired; once stock finishes the already-working image recovery can run when needed. No background WebView loops. Other stores/modes retain existing flow.
- On these two exact retail pages, price DOM observes after page-start (not just page-finished), with a bounded 23s time budget and up to 13 inspections, instead of 14s/5 inspections. Unrelated shopping websites keep their original 14s limit and 5 tries. The probe validates the original HTTPS host, canonical product SKU/path, a matching product title and code label, and tax-inclusive price evidence. It never clicks buy controls, and does not accept price from an ad, a related product, shipping, or a tax-exclusive display. No hardcoded amount is saved; the visible page must prove its current price.
- ASKUL SKU WNE6579 matches gross value `￥103（税込）` only from the product section, not delivery-option `￥385（税込）`. MonotaRO SKU 70130576 matches `販売価格(税込)￥252`, not `販売価格(税別)￥229`. For different SKU URLs or missing evidence, leave price UNKNOWN. DOM selector can fall back from <main> to document body only if the expected SKU is absent in <main>, while retaining strict SKU/path checks.
- Card-only diagnostic (`price.webview.page.start`, `page.finished`, `http`, `dom` with bounded reason and attempt, `timeout`, `network.error`) now distinguishes blocked main-frame HTTP response, absent SKU/title, unavailable tax-inclusive price and load timeout, with no credentials or raw URLs. Existing image/stock/card logs remain untouched.
- Do not infer that HTTP 403 has been bypassed. A page refusing HTML/DOM inspection can still return ACCESS_RESTRICTED and no price. No fabricated price or forced site-state success.
- Fixed applicationId `com.cmyk.bookmarkslauncher`, fixed keystore SHA256 `c15c0dcfdadba605edaab3f8ee4e732ad913a021d1100febb6894dd6e918f62a`, YAML workflows, scripts, AndroidX scanner imports, other scrapers, image HttpEngine, stored cards/price history, manual images and tag/sort UI remain identical.
- Local Java AST parse, item-bound SKU JavaScript syntax/synthetic DOM tests (correct tax-inclusive / reject shipping and tax-exclusive / reject other SKU), prepare-build script, ZIP CRC and byte diff validation. No actual Android Gradle / GitHub Actions / Nothing A001 runtime build or network access test has been performed.

# BookmarkLauncher 0.1.115 (versionCode 116) — Wishlist expanded layout and card diagnostics

Canonical sole base: BookmarkLauncher 0.1.114 (versionCode 115), SHA256 `a5ecb464caf85f29dc1259bb4ce478aa9b685896014bc6f13a8a02e7ee5787a6`.

- Wish expanded content inset: prices, comparison/status text, tags and bottom actions now all start at the thumbnail's actual left edge (2dp card header inset + 32dp grip = 34dp). The red alignment guide was reference-only and has NOT been drawn.
- Registered/current price row: remove its excessive 72dp fixed cell heights, use 36dp minimum and wrap_content for longer availability details. Field text size 14sp to match product name. No overflow/clipping for longer status lines.
- Add a 36dp circular card diagnostic button immediately to the LEFT of the existing Delete capsule: `[diagnostic] [削除] [情報更新] [商品ページ]`. N Gray #454040 circular fill; N White #A9A999 icon. Vector proportions (16.4 x 20dp document body, 2.3dp radius, 3 knockout text strokes) copied from ImgStalker v0.1.151 `MainActivity.HeaderIconView` DIAGNOSTIC branch. The knockout lines take the circle's new N Gray color, while the white document matches the source glyph. No placeholder icon or extraneous border. Existing capsules and short-click behavior unchanged; no long-press action.
- The card-only diagnostic uses exactly the existing `NDiagnosticLog` dialog implementation: title, typography, background, scrollbar/grip, "ログ消去", "コピー", "閉じる" controls all shared, no new dialog design. Source is switched from app-wide `DiagLog` to separately stored `WishlistCardDiagnostics` keyed by the immutable Wish item ID. Clearing a card deletes its own log only, not the app-wide log nor another card's. Device/SDK/version report header generated by the same `DiagLog.formatReport` function.
- Begin isolated per-card records of manual/batch crawl HTTP state, price success/failure, saved preview outcome, metadata/stock, and WebView recovery stages; display latest persisted card state (mode, stock, price, saved image, last check) even before older unscoped logs exist. No attempt to attribute previous app-wide log lines to a card. Privacy filtering strips URLs/auth tokens from records and item IDs are hashed in log filenames; bounded file storage.
- Preserve existing saved user cards/DB schema, background scheduling, large retailer and marketplace extractors, BicCamera HttpEngine image flow, sort/tag dialog, GENERAL ASKUL/MonotaRO logic, both YML workflows, prepare-build.sh, AndroidX and Code Scanner imports. applicationId `com.cmyk.bookmarkslauncher` and keystore SHA256 `c15c0dcfdadba605edaab3f8ee4e732ad913a021d1100febb6894dd6e918f62a` stay unchanged.
- Local validation: Java syntax parser, scoped log JDK stub isolation/copy/clear/privacy tests, archive identity/diff/CRC, and workflow prepare-build preflight. Android Gradle compile/GitHub Actions/Android device operation NOT run.

# BookmarkLauncher 0.1.114 (versionCode 115) — collapsed row + retail price correction

Base: ONLY BookmarkLauncher 0.1.113 (versionCode 114), SHA-256 `ecb79cde9192dc9df536e2171e14d267ad7edd9a23ddd4efeacaf672bd311519`.

- FIX: Collapsed Wish cards present one line `[店舗]  購入可能  ¥価格` (or current status), with the price right-aligned in 13sp and the status truncated as necessary; expanded layout unaffected.
- FIX: GENERAL MonotaRO `/p/7013/0576/` SKU 70130576: recognize the verified product's exact `販売価格(税込)￥252` rather than failing to identify it or accidentally using tax-exclusive `販売価格(税別)￥229`; do not substitute related listings.
- FIX: GENERAL ASKUL `/p/WNE6579/` SKU WNE6579: support its explicitly tax-inclusive `￥103（税込）` product price, preserving the guard against shipping fees, tax-exclusive prices and unrelated products. An actual HTTP 403/access restriction is respected; it cannot be guaranteed removable by parsing code.
- GENERAL-only SKU-linked, read-only WebView price fallback; diagnostics include gross recognition and main-frame WebView HTTP failure code (`RETAIL [ASKUL]` / `[MONOTARO]`). Missing product-specific evidence remains UNKNOWN. Image retrieval remains independent, with added WebView main-frame HTTP failure diagnostic for these two shops.
- Protect existing MonotaRO image+purchase success, BicCamera's HttpEngine image path, dedicated UNIQLO/YODOBASHI modes, marketplace-specific extractors, manual images, saved cards, user data and fixed keystore.
- Invariants: `com.cmyk.bookmarkslauncher`, versionCode 115, SHA256 keystore c15c0dcfdadba605edaab3f8ee4e732ad913a021d1100febb6894dd6e918f62a; both GitHub Actions workflows and scripts/prepare-build.sh preserved.
- Local tests: SKU-bound Java HTML gross positive/negative tests (MonotaRO 252 yen, ASKUL 103 yen; mismatched SKU rejected; exclusive price never gross), JS syntax and mock DOM positive/mismatch tests, GitBuild prepare-build invariants, archive CRC/contents and signing hash comparisons. Android Gradle compilation/GitHub Actions and Nothing A001 tests have NOT been run. If ASKUL's website refuses both HTTP and WebView, the app cannot fetch metadata and must not fabricate it.

# BookmarkLauncher 0.1.112 (versionCode 113) — Tag visibility, radio dots and stock-history labels

Only base: BookmarkLauncher 0.1.111 (versionCode 112) source.zip, SHA-256 `cee5458efb59d44f5793e251a45f3109941b94929b931a7f8f497767506fba32`.

- Wishlist search radio buttons: the same fixed 2-row/2-column four-choice layout and persisted exclusivity, but each control now uses an N-gray outer circle (#454040) with a centered N-white dot (#A9A999) only when selected.
- Tag manager: adding a tag automatically scrolls its list to fully reveal the new row without moving the dialog controls. The existing Wishlist draggable grip indicator follows the list. Card-side tag selection/creation also auto-scrolls to the created row; opening global tag management next also reveals that newly created tag. A post-layout visibility check prevents measuring an unlaid-out row and avoids unwanted scrolls if the row is already visible. 11.5-row maximum remains unchanged.
- Stock labels: replace ambiguous current/previous combinations with a single truthfully qualified status. Verified `AVAILABLE`/`UNAVAILABLE` with no site error displays `現在購入可能`/`現在購入不可`; otherwise show `現在未確認`, appending the last independently verified state and its original stored timestamp if both exist (`前回購入可能`/`前回完売`). Never fabricate prior history. Page connectivity remains independent. Expanded price keeps `(前回取得)` when a site issue prevents a fresh fetch.
- Successfully matched LargeRetail DOM results whose product-specific stock is **not** verified now record `UNKNOWN` as the *current* stock status, leaving `last_confirmed_status` and `last_confirmed_at` intact. Previously successful names, prices and images remain independently retained; result/product identity checks, trusted stock evidence, and actual retailer image fetching are unchanged.
- No schema migration. No unrelated Wishlist crawler/DOM/network modifications. Both GitBuild YMLs, prepare-build.sh, AndroidX/ML Kit settings, package name, fixed keystore and protected files are unchanged.
- Local tests: JDK Java compiler AST parse of all 92 Java sources; prepare-build.sh; comparison against original archive; keystore SHA-256, archive CRC and versioning. Android Gradle/GitHub Actions and Nothing A001 behavior NOT verified here.

# BookmarkLauncher 0.1.111 (versionCode 112) — Wishlist sorting and tag dialog UI

Base source: exactly BookmarkLauncher 0.1.110 (111) source.zip, SHA-256 b9796c964402e3c640d3dc7e338dfced85c04d62fc286d91b88ffc8c0a063687.

- Wishlist cards: on first use show existing cards by persisted registration timestamp descending. New registrations lead the list; editing and price refresh never rewrite that timestamp. Search results use the same current selected sort.
- Search dialog: a fixed two-row, two-choice-column, single-selection radio area after tags: date (new/old), confirmed current price (high/low). Unknown or stale prices go last. Default new first; the choice persists across app relaunches via private preferences. Clear resets draft selection to newest until Search is pressed.
- Existing card drag reorder continues to work without falsifying registration dates: explicit drag order remains until a radio sort is explicitly applied, then the selected date/price order is restored. Later new cards appear above the manually reordered group.
- Tag manager: cap tag list at 11.5 rows (42dp per item including gap) while respecting physically smaller displays; list region alone scrolls. Reuse the Wishlist card list's GripScrollFrame, allowing draggable indicator with identical color, dimensions and fading. Header/entry/actions stay fixed.
- Tag bulk delete confirmation uses the same custom dialog surface, spacing, message typography and Cancel/Delete capsules as Wish card deletion; deleting tags never deletes products.
- No wishlist DB schema changes, no retail crawler/parser/network modifications, no mutation of purchase history or user-edited data. Both GitBuild YML, AndroidX/scanner imports, prepare-build script and fixed keystore preserved.
- Validated: local Java parse of 92 source files (zero syntax errors), prepare-build invariants, keystore/certificate, archive integrity. Android Gradle build / GitHub Actions / Nothing A001 behavior are NOT verified in this environment.

# BookmarkLauncher 0.1.110 (versionCode 111) — HIRAKI商品固有在庫判定

唯一のベース：0.1.109（versionCode110）source.zip。user-requested ロム焼き。

- HIRAKI SHOPPING `https://www.hiraki.co.jp/ec/pro/disp/1/53896` 綿100％白タオル(4枚組)、品番53896、カラー(99)が在庫UNKNOWNとなる問題に限定。
- `hiraki.co.jp` / `www.hiraki.co.jp` の `/ec/pro/disp/1/<数字>` のみを一般モードの商品詳細として認定し、関連ドメインの同形URLは対象外。独立ショップのGENERALモードのまま、専用モードラベルとDB変更は追加しない。
- `HirakiStockEvidence`：HTMLの対象商品品番/H1とカラー99のサイズ・在庫・数量テーブルの実際の行を照合。ページ全体の在庫あり／在庫わずか／入荷後発送／後日発送／完売の凡例は在庫根拠にしない。対象行の数量入力と有効なカート操作がある場合のみ購入可能、対象行の明確な完売表示のみ購入不可、根拠がなければUNKNOWN。
- `HirakiStockDom` と既存の`WishlistAvailabilityWebViewProbe`：ユーザー手動・引っ張り全件更新の一般在庫補完で、対象品番・対象色・テーブル行のみをDOMで確認。UNKNOWNの場合は最長3回の限定再確認で停止。ユーザー画面に描画しない既存BackgroundDomWebViewを維持し、カート投入・購入操作なし。
- 在庫DOM結果を文字列(AVAILABLE / UNAVAILABLE / UNKNOWN)として伝達し、ヒラキだけ商品行根拠付きのUNAVAILABLEもDBへ保存可能に。既存モードのAVAILABLE補完動作と、画像/商品名/現在価格取得は変更しない。
- N診断ログに個人情報を含まない`RETAIL [HIRAKI]`のHTML根拠・DOM判定結果を記録。
- ビックカメラ画像の実機成功経路：Android標準HttpEngine→image.biccamera.com HTTP200→480x480 JPG→DB保存、ならびにUNIQLO/YODOBASHI価格と画像、Amazon/楽天/Yahooの取得ロジックは変更なし。両GitHub workflow、固定keystore、applicationId、DBスキーマ、Manifest、AndroidX/MLKitも変更なし。
- 事前検査：Java構文解析・HIRAKI HTML/DOM模擬テスト・Node JavaScript構文・GitBuild prepare-build・keystoreとZIP整合。実ページのHTML構造とNothing A001端末での在庫結果は未検証。証拠が足りなければUNKNOWNを維持し、実機診断ログで対応する。

# BookmarkLauncher 0.1.109 (110)

2026-10-16 - Wishlist background DOM pipeline update.

- Wishlist WebView DOM probes run as detached, no-pixel, single-use background workers. They do not attach a transparent View to the app interface or capture a screenshot. No guarantee of fully headless browser behavior on all Android builds; device verification needed.
- Keep existing JavaScript/DOM selectors, product ID verification, price and availability evidence rules.
- Remove WebView canvas/draw/bitmap crop capture for BicCamera. Product image data is obtained through platform HTTP fetch and decoded/validated before saving; see diagnostics for the transport outcome.
- Other app features that intentionally generate website/map screenshot thumbnails remain unchanged because those functions inherently require rendered pixels.
- Fixed package/signature, AndroidX, scanner imports and GitHub Actions unchanged.
- Java syntax/ZIP checks are not an Android Gradle or real-site test.

BookmarkLauncher 0.1.108 (versionCode 109)

0.1.107 (versionCode 108) source.zip を唯一のベースにした「観察→証拠照合→判定→保存」の初回実装。

- LargeRetailWebViewProbeの既存サイト別抽出を壊さず、RetailEvidenceObserverの独立段階を追加。実商品ページのH1と登録URLパス、UNIQLOの指定色・サイズ・丈の選択状態、ヨドバシの主購入領域と可視有効なカート・在庫表示を照合して、AVAILABLE/UNAVAILABLEの確定根拠がある場合のみ保存。
- 対象商品の在庫が矛盾する場合はUNKNOWNを維持。商品画像・価格・商品名は独立保存を継続。Amazon/楽天/Yahoo!/GENERALおよび既存サイト専用抽出器は変更しない。
- UNIQLOはカラー/サイズ/レングスの登録値と一致するUI選択肢に限って安全にクリックして、商品ページの遅延在庫表示を促す（最大3操作）。購入・カート投入は一切しない。異なる/曖昧な選択肢は操作しない。
- 同じDOMの無限再検査を避け、観察証拠が変化した時のみ待機を正当化。ページ読み込み完了後に変化が一定時間なく、購入可否未確認なら合理的に早期終了し、その理由をアプリ内診断ログへ残す。
- ビックカメラは非表示WebViewの透明度を極小の非ゼロにして画像読み込みの遅延を抑える試行、商品コード一致CDN画像のみの判定、画像lazy-loadを促してWebView内のピクセル取得を試す。image.biccamera.comのJava直接DLが失敗しても他商品画像で代替しない。
- 商品URLクエリ・備考・商品名・画面テキストを診断ログへ追加で保存しない。AI APIやGoogle Shopping非公開データには接続しない。この実装はLLMではなく根拠ベースの推論フローを端末内で模倣するもので、サイト/実機での成功は未検証。
- applicationId、keystore署名、GitHub Actions workflow 2本、DBスキーマ、AndroidX/MLKit設定、ユーザーデータを維持。Android Gradle/GitHub Actions/実機テストは未実施。

BookmarkLauncher 0.1.107 (versionCode 108)

0.1.106正本ベース。実機ログに基づくヨドバシのWebView解析早期終了対策、ビックカメラの商品画像WebView描画ピクセル保存経路と画像CDNタイムアウト短縮。その他既存取得モードは維持。

## 0.1.106 (versionCode 107): Large-retailer diagnostic trace

- Added copyable in-app N diagnostic events (`RETAIL [YODOBASHI]`, `[BICCAMERA]`, `[UNIQLO]`) for the existing HTTP -> rendered WebView -> database/image pipeline.
- Log milestones for connection/headers/body, HTTP status and timeout stage, WebView document HTTP/network errors and DOM evidence, image candidate/download/decode/save outcomes, and final DB/site state. Do not log complete product URLs, query strings, titles, or notes.
- Does not change retailer extraction algorithms, stock or price logic, network deadlines, database schema, applicationId, keystore, or GitBuild workflows. Inspect the exported diagnostic report after manually refreshing the failing Wish cards.
- Static checks are not a substitute for GitHub Actions APK build or on-device tests.

# BookmarkLauncher 0.1.105 (versionCode 106) — 大手通販の早すぎるタイムアウトと公開商品情報補完
- **唯一のベース**：0.1.104（versionCode105）source.zip。applicationId、固定keystore／署名、GitBuild両YML、DBスキーマ、成功済UNIQLO・Amazon・楽天・Yahoo!・GENERAL解析は変更なし。
- **通信タイムアウト**：ヨドバシとビックカメラの通常HTTP待機を接続5.5秒／読み取り7.5秒から接続11秒／読み取り14秒へ調整。UNIQLO・その他モードの接続設定は変更しない。非表示WebViewの上限はヨドバシ23秒・ビック25秒。HTTP応答ヘッダー前／本文読込中のタイムアウト段階をログで区別し、WebViewのメインフレームHTTP 403/401/429、404、その他HTTP・ネットワークエラーを診断して、証拠のあるアクセス制限を単なるタイムアウトと誤表示しない。
- **結果確定のタイミング**：ユーザー操作の手動更新・引っ張り全件更新では最初のHTTP失敗をカードの最終判定にせず、独立WebView終了まで「商品情報を確認中」とする。最終段階で正しい接続状態に更新。リジューム／周期HTTP更新の既存仕様は維持。途中で取得できた画像や価格は失敗処理で破棄しない。誤商品URLや別モードの解析結果なら成功として確定しない。
- **公開商品メタデータ補完**：Google Merchant Center等が掲載に利用する種類の、ショップがページに公開したOG/Twitter/HTML商品情報を直接読む。ヨドバシは商品見出し後の明示的な「価格：￥…」から現在の売価を抽出するルートを追加。希望小売価格・ポイント・関連商品価格を除外。ビックカメラは公式OG/Twitter画像と商品IDが一致する画像URLを先に試し、検証できない場合だけ公式商品コードCDN候補へ進む。画像取得・デコードが成功した場合のみ保存し、別の商品番号の画像は拒否。**Googleの検索結果・Merchant Centerの非公開商品フィードを直接取得する機能は追加していない**（無認証で利用できる安定した公式APIがないため）。
- **保護対象**：UNIQLO画像・価格、ヨドバシ画像・購入可能判定、ビック価格・購入可能判定、既存の購入履歴・タグ・手動編集値、Amazon・楽天・Yahoo!とノーマルモードの取得処理。
- **検証**：Java全86ファイル構文解析、JDK17でヨドバシ販売価格・ビック商品画像9項目型検査／実行、DOM模擬9項目、JS構文3本、prepare-build.sh、ZIP109エントリ整合性、keystore・YML不変を検査。
- **未実施**：Android SDK Gradle実ビルド、GitHub Actions、Nothing A001実機、および両通販サイトの実通信・画像／価格取得成功。サイトによる403などアクセス制限は引き続き取得を妨げる可能性がある。

# BookmarkLauncher 0.1.104 (versionCode 105) — ヨドバシ価格・ビックカメラ主画像だけの独立補強
- **唯一のベース**：0.1.103（versionCode104）source.zip。applicationId、固定keystore／署名、GitBuild両YML、DB、既存UNIQLO・Amazon・楽天・Yahoo!・GENERAL解析を保護。
- **ヨドバシ専用の価格補完**：商品見出し付近の「￥販売価格 ＋ ゴールドポイント」を主商品領域と本文の限定区間から照合し、希望小売価格／ポイント額／関連商品価格は除外。販売価格候補が複数に分かれ不一致なら価格は未確認。購入可否と画像取得のルールは変更しない。
- **ビックカメラ専用の主画像補完**：商品コードと一致するビックカメラ公式CDNの`<商品コード14桁>_A01.jpg`を検証候補に追加（例：14027620→`00000014027620_A01.jpg`）。DOMでは主商品ギャラリーの複数画像候補を優先、別商品コードの画像は排除、保存失敗時は同商品候補を順次試す。**画像HTTP取得・デコード・サイズ検証が成功した候補だけ保存**し、失敗時は既存画像を保持。既存保存画像の不要な再ダウンロードは行わない。商品価格と購入可否は変更しない。
- **検証**：Java全86ファイル構文解析、サイト専用のJava型検査／商品の公式画像パスを対象としたJDKモック実行、DOM模擬テスト9件、JS構文・Javaへの組込一致、GitBuild prepare-build事前検査、ZIP整合性、keystore／YML維持。
- **未実施**：Android SDK Gradle実ビルド、GitHub Actions、Nothing A001実機での取得成功。サイトのアクセス制限やDOM差により取得できない可能性は残る。

# BookmarkLauncher 0.1.103 (versionCode 104) — 大型EC3モードの未取得フィールド補強
- 正本は0.1.102（versionCode 103）。`applicationId`、固定署名・keystore、GitBuild YML、DB構造を変更しない。
- UNIQLO：**商品価格と在庫の確定条件を分離**。対象商品ID/色の一致と、登録URLに残った選択値（またはDOMの選択状態）を照合し、商品本体の明確な価格を取得。別バリエーションの価格や複数レンジは採用しない。在庫は対応バリエーションと表示中・有効な購入操作が確認できた場合だけ採用。
- ヨドバシ：商品見出し直後にある、価格ラベルを持たない「￥販売価格＋ゴールドポイント」の表示を主商品領域内で補完。希望小売価格、ポイント額、関連商品価格を排除。既存の画像と購入可否判定は変更しない。
- ビックカメラ：主商品の画像ギャラリー内の`src`/遅延属性/`srcset`/`picture source`を取得候補とし、商品固有のOG/Twitter画像に安全にフォールバック。画像CDNに対しては元の商品ページのReferer付き取得を追加。商品価格・購入可否判定は変更しない。
- 保護対象：Amazon/楽天/Yahoo!とGENERALの既存取得、その他大型ECの成功済みフィールド、DBデータ、手動編集値。
- **Gradle実コンパイル・GitHub Actions・Nothing A001実機取得は今回未実施**。成功を保証しない。

# BookmarkLauncher 0.1.102 (versionCode 103) — 大型EC3モード取得改善
- **唯一のベース**：0.1.101（versionCode102）の `source.zip`。applicationId、固定署名、両GitBuild YML、AndroidX/Code Scanner 設定を維持。DBスキーマ変更なし。
- **ヨドバシ専用モード**：商品本体の「価格：」表示を優先して税込販売価格を取得。希望小売価格・ポイント額・関連商品を価格から除外。「在庫残少」などの商品固有表示と可視・有効なカート操作を照合し、在庫判定を強化。対象商品のIDは URL で照合。
- **ビックカメラ専用モード**：通常商品用「販売価格／税込価格」表示や商品固有価格要素、対象商品購入エリアの有効カートと在庫表示に対応。関連商品・中古・販売休止中の表示からは購入可能と推定しない。専用非表示WebViewの待機上限を21秒に延長し、読み込み途中の独立解析と途中成功データ保持を維持。通信失敗の根拠をログに出す。
- **UNIQLO専用モード**：登録時のカラー・サイズ・レングスを取得DOMに安全に渡し、サイト側がURLクエリを削除しても異なるパラメータへ変わった場合は拒否。色・サイズ・丈の同一性を確認できた場合にのみ、その選択に関わる価格・在庫を確定。主商品画像の異色混入を抑制。
- **3サイト専用共通WebViewライフサイクル**：メインフレーム通信エラーでも一度DOM部分結果を確認。タイムアウト時の途中成功情報保持、結果/理由/HTTP応答の診断を維持。対象商品でないページ、アクセス制限画面、複数価格の不一致を成功扱いにしない。解析セレクター自体はサイト別に完全分離。
- **保護対象**：Amazon・楽天・Yahoo! の成功済み専用解析クラス、GENERAL全取得、保存済みの商品名・画像・価格・購入履歴・タグ、DBデータ。意図しない解析モード切替なし。
- **検証**：全86 Javaファイルの JDK21 構文パース、3サイトDOMのNode構文検査、販売価格／希望小売／関連商品／在庫矛盾の模擬ケース、UNIQLO URL・バリエーション照合テスト、GitBuild prepare-buildの事前検査、keystore/YML/ZIP照合。
- **未実施**：Android SDKを使うGradle実ビルド、GitHub Actions、Nothing A001実機、現行実商品ページでの取得成功。サイトのアクセス制限によっては取得不可のままの場合がある。

# BookmarkLauncher 0.1.100 (versionCode 101) — 大型EC専用モードとモードラベル中心合わせ
- **唯一のベース**：0.1.99（versionCode100）の source.zip。applicationId `com.cmyk.bookmarkslauncher`、固定keystoreと署名、GitBuildワークフローは変更なし。
- **大型EC3サイトを独立モード化**：`UNIQLO`、`YODOBASHI`、`BICCAMERA` を `WishlistMode` に追加。特定のHTTPSホストと商品ID形式が一致する時だけモードを確定し、登録カードの `acquisition_mode` に永続保存。DB v10→v11非破壊移行で既存の該当GENERALカードも自動移行し、商品名・画像・価格・タグ・購入記録・履歴・並び順を維持する。別商品URLへ移動した場合は補完拒否。
- **専用解析器を完全分離**：UNIQLOの色/サイズ/レングス、ヨドバシの商品番号、ビックカメラの商品番号を対象に、専用HTML/JS抽出器で主商品名・画像・税込JPYの明示価格・購入可否を解析。バリエーション価格や中古／関連商品の価格、無効なカートボタンを採用しない。商品名・画像・価格・購入可否・サイト状態の保存経路は既存の独立処理を利用し、サイトごとの解析ルールは混ぜない。
- **表示ラベル**：「UNIQLO」「ヨドバシ」「ビックカメラ」をNホワイトベタ塗り15dp低背チップで表示。既存Amazon/楽天/Yahooラベルも文字の描画範囲を使って中央補正。表示は保存モードにのみ連動。
- **通信失敗時の補完**：3サイトのHTTP失敗または情報不足時、手動「情報更新」および引っ張り全件更新（最大9件まで順次）で、非表示WebViewから**同一商品ID**のDOMを検査する。WebViewが403等でアクセス拒否された場合は無理に補完せず、既存の成功データを保持する。通常の定期更新は従来の軽量HTTPのまま。
- **GENERAL購入可否の限定補強**：由比缶詰所のCS-Cart型とJR東海の対象SKUを確認するWebView専用判定を追加し、不室屋だけは動的購入操作の確認を少し遅らせて再試行。無関係な商品や必須バリエーション未選択ではAVAILABLEと判定しない。取得成功は実機検証前のため保証しない。八百三は修正対象外のまま。
- **保護対象**：Amazon/楽天/Yahooの既存成功済み各専用解析クラス、ノーマルモードの商品名・画像・価格解析、購入履歴・タグなどのデータ、署名と両YML。汎用モードへの無断フォールバックなし。
- **検証**：Java全86ファイルJDK21構文解析成功、専用URL/モード判定と静的画像/価格のローカル型検査とテスト成功、5本のWebView JavaScript構文チェック成功、GitBuild prepare-build、ZIP整合/keystore SHA-256一致/Workflow差分なし確認。
- **未実施**：Android SDKを使用するGradle実ビルド、GitHub Actions、Nothing A001実機検証、UNIQLO/ヨドバシ/ビックカメラの実商品ページへの取得成功。外部アクセス制限には依然左右される。

# BookmarkLauncher 0.1.98 (versionCode 99) — ノーマルモード取得ロジックの安全な強化
- **唯一のベース**：0.1.97（versionCode 98）のsource.zip。アプリID・固定keystore・署名・GitBuild両YMLは維持。既存DB／商品情報は消去しない。
- Amazon・楽天・Yahoo!の取得モード・個別パーサーを変更せず保護。ノーマルモードに安全に組み込めるURL形式を拡張し、ECプラットフォームごとの新モードは**今回は追加していない**。
- 一般の商品詳細URLとして `/shop/g/gSKU/`、`/SHOP/数字を含む商品コード.html`、`/?pid=数字`、`/i/商品コード`、`/view/item/ID`、`/?page_id=...&eci_product=商品コード` を追加。EC-CUBE、らくうるカート、CS-Cart、松浦漬等の既対応形式は維持。八百三 `/shouhin` のような複数商品紹介ページは単独商品と誤認せず、備考欄キーワード方式を維持。
- ノーマル用JSON-LDは登録URLと一致するProductを優先し、関連商品の先頭Productを無条件に採用しない。URL照合不能ならOGPなどに戻す。名前・画像・価格・購入可否は別処理のまま。商品画像候補では商品タイトルに一致するaltを高評価、関連商品・装飾画像を抑制。非表示WebView画像候補でも `pid`／`eci_product`／`product_id` を識別可能に。
- 商品の近傍にある明確な「在庫あり」表示だけを一般モードの補完根拠にする。ページ全体の「売切れ」は引き続き根拠にせず、関連商品の表示や曖昧なバリエーションはUNKNOWNのまま。購入可否の判定理由を内部ログへ伝達。
- 表示ラベルは `WishlistMode.cardLabel()` に集約。Amazon／楽天／Yahoo!は従来のベタ塗り低背ラベル、GENERALはラベルなし。将来小規模な独立モードを追加した場合は表示名を「専用モード」とする設計。**大型店（ヨドバシ等）の個別ラベルは今後該当サイト対応時に追加**。
- 第1〜3グループの12商品を回帰対象として整理。11件の単一商品URLを認識し、八百三のみ複数商品ページとして除外することを検査。商品画像選択・明示的な在庫表示の模擬テストを含め24件のローカルテスト合格。Java17全77ソースの構文解析とGitBuild事前検査合格。
- **未検証**：Android SDKを使うGradle実ビルド、GitHub Actions、Nothing A001実機、実サイトで12商品の取得成功。現実のサイトのアクセス制限、ページ構造・バリエーションによっては一部取得できない。

# BookmarkLauncher 0.1.97 (versionCode 98) — 取得モードの永続化とWishカード識別ラベル
- 唯一のベース：`BookmarkLauncher_0.1.96_source.zip`（versionCode 97）。`applicationId`・固定keystore・両GitBuild YMLを維持。
- DB 9→10 を非破壊で移行し、各Wishカードに取得モード（AMAZON／RAKUTEN／YAHOO／GENERAL／UNRESOLVED）を永続保存。既存の直接商品URLは移行時に識別し、短縮URLはHTTP転送先の商品確認後に確定。既存の商品名、画像、価格履歴、タグ、カード順を維持。
- 名前・画像・価格・在庫のHTTP解析は保存モードに基づき、Amazon／楽天／Yahooの各専用パーサーのみを使用。保存済みモードと転送先が異なる場合は解析を拒否してログに記録、一般モードへ無断フォールバックしない。手動・全件・定期・監視更新も同じ保存モード付きfetchを利用。
- WebViewの在庫・価格・楽天/Yahoo画像補完には保存モードとの整合検査を追加。Amazon画像・商品名補完はAmazonモードだけで起動し、独立通販サイトの抽出は従来のまま。
- Wishカード表示は保存済みモードだけを読み取り、Amazon／楽天／Yahoo!の低背Nホワイトベタ塗りラウンドスクエアを同寸高で表示。展開時はURLの位置にラベル（3モード以外では従来URLを表示）、格納時は購入状態の下に配置。
- Amazonの購入可能判定は専用のbuybox/メイン商品領域探索を拡張し、WebViewで対象ASIN一致・可視・有効な購入ボタンを検証。これは静的/DOM補完の改善であり、実サイトの全商品判定成功を保証しない。
- 事前検査：Java 17ソース75本の構文解析、マーケットプレイス隔離テスト18件、モード判定テスト12件、Amazon DOMテスト4件、GitBuild prepare-build、ZIP整合・固定keystore・workflow一致を確認。Android Gradle実ビルド／GitHub Actions／実機の動作は未検証。

# BookmarkLauncher 0.1.96 (versionCode 97) — 3大ECサイト取得ロジック分離 / Amazon商品名・在庫履歴 / Pull-to-Refresh
- **唯一のベース**：`BookmarkLauncher_0.1.95_source.zip`（versionCode 96）。`applicationId=com.cmyk.bookmarkslauncher`、固定keystore、2つのGitBuild workflowを維持。
- **Amazon・楽天市場・Yahoo!ショッピングの取得解析をサイトごとに独立**：各サイトのJSON-LD／名前／画像／価格／購入可否解析をサイト別の専用Javaクラスに分割。従来の5つの混合 `Marketplace*Extractor` / `MarketplaceProductJsonLd` は削除し、crawlerはURLの商品IDを確認して該当サイトの専用処理だけを呼ぶ。別サイトや一般通販の解析へフォールバックしない。URLのホスト・商品ID認識、HTTP通信、DB保存は共通インフラとして維持するが、商品情報抽出ロジックのサイト跨ぎはない。
- **非表示WebViewのDOM取得ルールもサイト別**：`AmazonDomSelectors`、`RakutenDomSelectors`、`YahooDomSelectors` に分け、価格・画像・購入操作の各DOMセレクタは専用ルールで解決。WebViewのロード・タイムアウト・結果反映というライフサイクルのみ共通。Amazon画像の既存専用WebViewは維持。
- **Amazon商品名を改善**：`#productTitle`を最優先して解析し、ASIN照合済みJSON-LD、OGP、HTML titleの順に補完。手動「情報更新」時は名前だけを読む専用非表示WebView `AmazonNameWebViewProbe` を最終手段に追加。関連商品、CAPTCHA/サインインページタイトルを除外。手動設定した商品名は上書き禁止。成功例 ASIN B075CJ81PL と失敗例 B0DT9RGZCG を回帰検証対象として継続。
- **在庫状態の逆戻り対策**：DBをv8→v9へ非破壊更新し `last_confirmed_status` / `last_confirmed_at` を独立保存。新取得がUNKNOWNでも最終確定履歴は維持し、現在の状態はあくまでも「状態未確認」、前回の購入可否と確認日時は分けて表示。古い購入可能を現在購入可能と偽装しない。手動Amazon商品名WebViewも価格・画像・在庫から独立。
- **引っ張り更新の操作感**：Wish通常一覧が最上段で下に引かれた時、カード一覧自体が指の縦移動に追従し最大約150dp下降。表示移動量約125dpで放すと一括更新、未達なら弾性復帰。処理中は約58dpに戻して進捗を維持し、終了後元位置にアニメーション復帰。通常の縦スクロール、横スワイプやグリップ操作と競合しないようタッチを消費する。検索中は対象外。
- **検査**：Java 17構文解析全74ソース、専用パーサーのJDK型検査、サイト間隔離18例、Amazon DOM模擬4例、サイト専用DOM JS8本のNode構文解析、GitBuild事前検査、YML・keystore・署名証明書の保全とZIP整合性を確認。
- **未実施**：Android SDK/Gradle実ビルド、GitHub Actions、実機動作、実サイトHTMLの取得成功。これらは静的テストで保証できない。大手ECのアクセス制限や表示差は引き続き実機確認が必要。

# BookmarkLauncher 0.1.95 (versionCode 96) — Wish全件更新・画像と販売状態補完
- 正本：`BookmarkLauncher_0.1.94_source.zip`（versionCode 95）のみ。`applicationId`、固定署名keystore、GitBuild YMLは変更なし。
- Wish一覧の最上段で一定距離（約94dp）下へ引いて離すと、登録済み商品全件を順番に再解析する。検索中では動かず、再実行中の重複起動を防ぐ。上部に進捗件数を表示。
- 各Wishカードの画像の幾何学的中央に更新中の不定進捗サークルを重ねる。単件手動更新は価格・画像・購入可否のWebView補完も完了してからサークルを消す。全件更新は既存定期更新と同じHTTP取得パイプライン（WebView補完は自動実行しない）で逐次実行する。
- EC-CUBE標準URL `/shop/products/detail/40` を商品詳細ページと認識し、鳥寛の商品メインギャラリー（slide-item、item_visual、save_image）の画像候補・遅延読み込み補完を有効化。手動画像は上書きしない。
- 中嶋屋本店（らくうるカート）固有の数量欄＋有効な購入リンク、EC-CUBE商品固有フォームを独立した購入可否判定に追加。中嶋屋・鳥寛・不室屋は、手動更新時に非表示WebViewで可視・有効な購入操作を確認する専用補完を追加。単なるページ内の売切れ文字・関連商品からは判定しない。
- Amazonの購入エリア抽出上限を6,000字→22,000字に拡張し、関連商品の領域を除外。`B0DMVCXD39` は確認対象とするが、実ページでの取得成功は未確認。
- 商品別の購入可否の理由をログに記録（サイト／商品パス／HTTP／判定／理由）。既存の名前・価格・画像取得の独立処理とデータ／履歴は保持。
- ローカルのJava構文・独立ショップ画像／購入判定の疑似HTMLテスト・WebView JS構文・GitBuild事前検査・ZIP整合性は合格。Gradle実ビルド、GitHub Actions、Nothing A001実機、Amazon／不室屋の現行ページでの判定成功は未実施。取得を保証するものではない。

# BookmarkLauncher 0.1.94 (versionCode 95) — 三大通販サイトの商品照合改善
- 唯一のベース：`BookmarkLauncher_0.1.93_source.zip`（versionCode 94）。`applicationId`、固定keystore、GitHub Actionsの2つのYMLは維持。
- Amazon.co.jp（ASIN）、楽天市場の商品URL（店舗ID＋商品ID）、Yahoo!ショッピングの商品URL（店舗ID＋商品ID）を商品詳細URLとして認識する専用 `MarketplaceIdentity` を追加。canonical が別商品なら、そのページから商品データを更新しない。商品詳細以外のページは関連商品の解析にフォールバックしない。
- 対象商品の JSON-LD はURL/ASIN照合を優先し、最初の無関係な `Product` を採用しない。商品名・画像・価格・購入可否はそれぞれ独立した解析クラスとし、既存の一般通販サイト向け実装を維持。
- Amazon画像：HTML全体の `hiRes / large / mainUrl` 先頭一致を廃止。メイン商品 `landingImage` 等からのみ候補を抽出し、関連商品を採用しない。手動「情報更新」では以前の自動取得画像が保存済みでも、メイン商品WebView画像を再検証して差し替え可能。手動画像は変更しない。
- 楽天・Yahoo画像：対象商品JSON-LDの `image`、canonical一致商品ページのOGP、専用主画像領域だけを候補として利用。非表示WebView補完も別商品への遷移を拒否、商品メイン画像領域に限定。
- 価格：対象商品JSON-LDのJPY Offerのみ、複数異なる価格は確定値としない。Amazon Buy Box、商品固有の価格メタや専用DOMを補完。AggregateOfferは下限/範囲として区別し、確定価格履歴へ入れない。送料や関連商品価格を使わない。
- 購入可否：対象ProductのOffers（競合バリエーションはUNKNOWN）と対象商品の有効なカート操作だけを利用。商品外の売切れ・カートは無視。手動更新のWebView補完も各サイトの商品IDを確認し、専用購入領域を調べる。推測で販売可能/終了とはしない。
- 既存の商品データ、価格履歴、画像、サイト状態、購入履歴を初期化せず、ユーザーが設定した名前・画像を保護。取得失敗で成功済みデータを削除しない。
- 検証：Java構文検査、独立パーサーのJDK型検査、HTML擬似テスト23件、WebView内JS4件構文検査、GitBuild前提チェック、keystore SHA256/証明書、ZIP整合性。**Gradle実ビルド、GitHub Actions、実機検証、現行の3サイトHTMLでの成功確認は未実施。** サイトの認証/アクセス制限時は取得できない場合がある。

# BookmarkLauncher 0.1.93 (versionCode 94) — Stock evidence and search polish
- Only base: BookmarkLauncher_0.1.92_source.zip (versionCode 93). Stable applicationId/signing/workflows preserved.
- Wish card action label: `今すぐ更新` -> `情報更新`, no behavior change.
- Pinned search-condition card: `閉じる / クリア / 再検索` in equal positions. Close exits search and restores the original list; Clear empties only draft keyword/prices/tags without closing; Re-search applies the draft.
- Android 11+ IME animation callback makes the pinned search card track the keyboard's insets while opening/closing; the existing one-tap outside-to-dismiss and Home behavior remain.
- Independent availability parser: selects URL-matching product JSON-LD rather than first related-product offer, treats conflicting variants as UNKNOWN, avoids page-wide sold-out signals, recognizes product detail paths and scoped active cart controls. This is conservative: unknown items without trustworthy item-specific evidence stay UNKNOWN.
- Manual-refresh-only, bounded hidden WebView checks for a visible enabled cart in a cart-specific form (only upgrades an UNKNOWN result to AVAILABLE). Notes-selected product sections are also inspected for a strictly scoped cart form. No modification to existing image/price/title extractors, site-state logic, GitBuild YAML, or historical data. Availability improvements are static source changes and are NOT yet verified against live retailer HTML or on-device.

# BookmarkLauncher 0.1.92 (versionCode 93) — Wishlist UI and horizontal swipe improvements
- Unique base: `BookmarkLauncher_0.1.91_source.zip` (versionCode 92), preserving applicationId, stable signing keystore and both GitHub Actions workflows.
- Search dialog **Clear** empties only the editable keyword, price and selected tag chips without closing the dialog or altering applied search state. The pinned search-filter panel retains its distinct Clear-to-exit behavior.
- Wish-card tag selection: buttons are **Cancel (left) / Apply (right)**. Only Apply saves tag membership; cancel/back/outside dismisses without saving a draft.
- Wishlist floating tag icon outer diameter is 58dp, matching the floating Add icon; tag symbol remains centered with its prior glyph size/colors.
- Horizontal Home/Wishlist swipe: warm up page before drag, never reconstruct all card Views at gesture start, refresh only when SQLite external data_version changes, adjust horizontal gesture threshold to 12dp, use release velocity plus distance for commit and responsive landing animation. Grips on cards and visible fast-scroll thumb are excluded from page-swiping.
- Fast-scroll thumb finishes its 260ms opacity fade around 1 second after scrolling stops (740ms idle + 260ms fade), including search results.
- Product extraction, price, images, stock/site diagnostics, stored card/purchase data, GitBuild workflows and app signing unchanged.
- Verified: JDK 17 Java parser on all 53 Java sources, prepare-build invariants, ZIP test, keystore hash/certificate. Not verified: full Gradle Android APK build, GitHub Actions, or physical device behaviors.

# BookmarkLauncher 0.1.88 (versionCode 90) — 在庫誤判定の修正
- 正本: BookmarkLauncher_0.1.87_source.zip (versionCode 88)。applicationId・固定署名を維持。
- 購入可否を `WishlistAvailabilityExtractor` に独立分離。ページ全体の「売り切れ」「完売」「在庫切れ」を商品自身の購入不可判定に使わない。
- 商品詳細URL上で一意に紐づく構造化商品データを優先。購入ボタンと構造化情報が矛盾すれば UNKNOWN（状態未確認）、状態不明時にも誤って購入不可を出さない。
- 旧DB v7 → v8 は非破壊。古い購入不可フラグのみ解除し、商品・価格・履歴・画像・タグ・サイト状態を維持。次回更新時に購入可否を再判定する。
- 不室屋 `product/detail/300840` と由比缶詰所 `dispatch=products.view&product_id=17` の在庫誤判定を対象とする。現物のDOMおよび実機での成功は未確認。
- 商品名／価格／画像抽出コード、WebView画像補完、サイト状態解析、YML、署名は変更しない。
- Gradle実ビルドと実機動作は未検証。

# BookmarkLauncher 0.1.87 (versionCode 88) — Wishlistサイト状態と操作改善
- 唯一のベース: `BookmarkLauncher_0.1.86_source.zip`。`com.cmyk.bookmarkslauncher`、固定署名と既存Workflow維持。
- 最低価格 (`¥500～`) はそれだけで購入不可判定しない。商品名・価格・画像の解析とサイト状態診断を分離。
- サイト状態 (メンテナンス/404・410/403・429/タイムアウト/接続障害/5xx) を独立DB列で管理。旧商品データと価格履歴を保持。
- カードの現在欄に異常注釈と「前回取得」を表示。正常復旧時は注釈解除。
- 削除ダイアログをNカプセル型に。並べ替えグリップはヒット領域を維持して左へ移動・中央寄せ。
- 商品名が未取得またはURL形式なら共有本文はURL1件のみ。
- 本ZIPはGradle実ビルドと実機取得は未検証。

# BookmarkLauncher 0.1.86 (versionCode 87) — 一般通販商品画像の取得改善
- 唯一の正本: `BookmarkLauncher_0.1.85_source.zip` (0.1.85 / versionCode 86)。固定署名と `com.cmyk.bookmarkslauncher` を維持。
- 対象: 中嶋屋本店 `item-detail/1000086`（同一商品の画像ギャラリー2枚）、松浦漬本舗 `item_detail_0000016.html`（URLの商品番号と一致するJPG）。
- 商品詳細のHTMLから高確度の画像候補を抽出する独立した `WishlistRetailImageCandidates` を追加。商品番号／ギャラリー／専用画像CDNを根拠として絞り込み、ロゴ・バナー・関連商品は除外する。
- 通常取得で画像が保存できなければ、商品詳細ページの候補画像を順番に試す。画像の個別ダウンロードが失敗しても次の候補を試し、商品ページのRefererを渡す。
- 非表示WebView画像補完を複数候補対応に改修。商品番号に一致するURL、商品ギャラリー、大きな商品画像を優先。発見した候補を順次保存し、失敗した1枚で処理を打ち切らない。
- 商品名・価格・価格履歴・Amazon専用取得・八百三備考欄解析・既存DB・ホーム/Wishlist UI・YMLは変更しない。手動設定画像も上書きしない。
- 検証: JVM画像候補テスト5例、DOM JS 3例、WebViewクラスのAndroid代替APIコンパイル、JS構文、固定署名とGitBuild事前チェック、ZIP整合性。実際のAndroid Gradleビルド・実機取得は未確認。

# BookmarkLauncher 0.1.85 (versionCode 86) — 一般通販価格/画像補完
- 唯一のベース: BookmarkLauncher 0.1.84 (85) の source.zip。
- 商品詳細判定: /product/170, /item-detail/1000086, /item_detail_0000016.html, CS-Cart `index.php?dispatch=products.view&product_id=17` を追加。商品一覧は対象外。
- 最低価格/価格範囲の表示: `500円～` は `¥500～` として別カラム保存、確定価格履歴には書き込まない。既存の登録価格・履歴は維持。
- 日本向け商品の販売価格を詳細ページ近傍から抽出。本文全体の最初の金額、送料、追加オプションを推測採用しない。
- 商品名・画像・価格の解析は分離したまま、既存のAmazon/八百三/不室屋向けコードを保護。
- 固定署名・applicationIdを維持。実機・実サイトの成功は未検証。

# BookmarkLauncher 0.1.84 (85) — Wishカード整列・一般通販の商品画像／価格補完
- 正本は `BookmarkLauncher_0.1.83_source.zip` (versionCode 84) のみ。applicationIdと固定署名を維持。
- Wishカード下部の操作順：左「削除」／中央「今すぐ更新」／右「商品ページ」。均等幅、間隔8dp。
- 展開時の上部：商品名・URLを上詰め、可変スペース、商品名編集・画像編集、備考欄を下詰めにし、画像140dpと右側の高さを合わせる。編集ボタン間6dp、備考欄まで6dp、画像との間隔12dp。
- 「現在購入不可」は独立したヘッダ注釈ではなく、展開時の「現在」価格欄へ移動。格納状態は従来の状態表示を維持。
- タグ選択ダイアログ：左「適用」、右「閉じる」に入れ替え、ボタン間8dp。既存の処理は維持。
- Wishカード追加：URLと備考欄を同一44dp高さ・同じ幅・上下8dp間隔に統一、下部操作は8dp間隔。
- 商品詳細URL（例：`/product/detail/300840`）では備考欄を商品一覧解析の絞り込みに使わず、そのURLの商品を優先。備考欄による八百三型の一覧商品選択は従来通り。
- 手動更新時、一般通販の商品詳細ページの画像が未保存の場合に限り、別クラス `WishlistRetailImageWebViewProbe` が非表示WebViewで商品画像URLを補完。Amazon専用画像取得と完全分離。画像のみ保存し、価格・商品名は変更しない。
- 価格WebViewは商品詳細URLに限り一般通販の価格セレクタと近傍の単一円価格を追加、空結果は限定回数再確認。Amazon専用抽出・価格保存先は維持。関連商品・送料・複数候補は誤採用防止。
- 済：WebView解析JavaScript文法検査、ローカル価格5件・画像3件、WebView新規／改修クラスの代替Android APIコンパイル、署名・ZIP・ビルド前検査。
- 未実施：実Android SDK Gradleビルド、実サイト通信、実機UIの表示・取得検証。商品ページからの取得はサイトの配信・制限次第で失敗する可能性がある。

# BookmarkLauncher 0.1.83 (84) — Wishlist備考欄・余白・ダイアログ配置
- 正本は 0.1.82 (versionCode 83) の source.zip のみ。固定署名と applicationId を維持。
- Wishカード展開：140dp画像と右側全体（商品名・URL・編集ボタン・備考欄）を同じ縦幅に配置。備考欄は編集ボタンと同じ30dp高、未入力表示は「備考欄」。カード毎にテキストを即時保存。
- Wishカード追加ダイアログの題字を「Wishカード追加」にし、URL（未入力時「URL」）直下に備考欄を設置。
- DB v4→v5 非破壊移行で note 列追加。既存の商品、画像、価格、タグ、履歴を保持。
- 備考欄を商品キーワードとして使う場合、同じページの一致する商品見出しの範囲のみ画像と価格を抽出。画像／価格解析は別クラス。候補価格が複数ある場合は取得しない。通常のAmazon専用抽出ロジック・WebView補完は改変しない。
- タグ選択ダイアログ：左「閉じる」、右「適用」。既存の保存動作は維持。
- Wishカードのスクロール末尾に112dpのスペースを置き、フロートボタンと操作ボタンが重ならないようにする。検索中は16dp。
- Android Gradle実コンパイル・実機検証は未実施。

# BookmarkLauncher 0.1.81 (versionCode 82) — Wishlist監視ボタン移設と共有アイコン

- 正本は `BookmarkLauncher_0.1.80_source.zip` (0.1.80 / versionCode 81)。
- Wishlist展開カードの再開監視ボタンを、価格ステータスの右側へ移動。横に共有丸アイコンを追加。
- 共有時はAndroid共有シートを開き、商品の名称・URLをテキストで共有。
- N規格色・円形の共有ベクターを使用。NS本体ソースが未確認のためアイコン完全一致は未確認。
- 商品名・価格・Amazon画像の取得経路、DB、タグ、履歴、署名、YMLは変更なし。
- Java構文、ビルド前設定、ZIPの整合性を確認。Gradle実ビルド・実機動作は未検証。

# BookmarkLauncher 0.1.80 (versionCode 81) — PriceRecタグ管理移植・Wishlist丸ボタン修正

- **唯一の正本**： `BookmarkLauncher_0.1.79_source.zip` (versionCode 80)。applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。
- 通常時は従来の＋丸（URL追加）・虫眼鏡（検索）を右下に復活。左下のPriceRec丸タグアイコンも表示。テキスト操作ボタンは廃止。
- 検索条件カード表示中は、＋丸・虫眼鏡・タグ丸をすべて非表示。条件カードは画面最下部に固定し、リストのスクロールとは独立。
- PriceRec v0.1.81を参照し、タグ管理を改修：行タップで選択・解除、複数選択時の「削除」（確認あり）、選択中「キャンセル」／通常「OK」、タグ追加は管理ダイアログ内、行長押しで名前編集、左端☰グリップ長押しで指に追従するアニメーション並べ替え。並び順はドロップ時だけ保存。
- タグ追加・改名・削除後も管理ダイアログを維持し、一覧をその場で更新。商品別タグ選択もグリップ・選択強調・長押し編集に統一し、改名後も選択ダイアログを保持。
- Amazonの商品名・価格・画像取得モジュール、WebView補完・DB、MainActivity、YML、署名は変更なし。変更範囲はWishlistPage.java、バージョンと事前検査、READMEに限定。
- ビルド事前検査・ZIP整合性・Java構文静的検査を実施。Android SDK/Gradleによる実ビルドと実機動作は未確認。

# BookmarkLauncher 0.1.79 (versionCode 80) — Wishlist検索UI・Android Back・PriceRecタグアイコン

- 正本は **`BookmarkLauncher_0.1.78_source.zip` のみ**。アプリID `com.cmyk.bookmarkslauncher` と固定署名を維持。
- 検索ダイアログ：不要な「価格更新」ボタンを撤去し、左から **「閉じる／クリア／検索」**。旧「適用」を「検索」に変更。
- 検索条件カードは **画面最下部に固定**。Wishカード一覧の縦スクロールから分離。検索語句・価格・タグの編集と「再検索」「クリア」は維持。
- Wishリストの旧「＋丸」「虫眼鏡」フローティングアイコンを撤去。商品登録・検索の入口を保つため、検索していないときは下部に **「URL追加」「検索」** の文字ボタンを表示する。検索中は検索条件カードに切り替わる。
- 画面左下には PriceRec v0.1.81 の `TagManageIconView` と同一のベクター描画による **48dpのNグレー丸型タグ管理アイコン**を移植。クリックするとWishリストのタグ作成・名称変更・削除を行える。タグの紐付け処理は変更しない。
- Android 13以降の端末バック／ジェスチャーバックを `OnBackInvokedDispatcher` でWishリスト表示中に受ける。検索条件表示中は「クリア」と同じ復帰処理（展開状態・スクロール位置を復元）。非検索中はホームへ戻る。ホーム側の端末バック挙動は維持。
- Amazonの商品名・価格・画像の解析と WebView 補完、データベース、ホーム/Wishlist横スワイプ、カード開閉・並べ替えアニメーション、画像手動設定の処理は変更しない。
- Java全44ファイル構文検査とビルド前検査は実施。ただし Gradle/Android SDK の実コンパイルと実機動作は未実施。

# BookmarkLauncher 0.1.78 (versionCode 79) — Wishlist検索条件パネル・手動画像編集

- 正本は `BookmarkLauncher_0.1.77_source.zip`（0.1.77 / versionCode 78）のみ。
- Wishlist検索・絞り込みを実行すると、結果リスト上部に **検索語句・最低価格・最高価格・タグ** の編集パネルを表示する。編集するだけでは検索結果は変わらず「再検索」で適用、クリアまたは Android 端末バックで条件をすべて解除し、検索前のカード展開状態・スクロール位置を復元。
- タグは選択済みのものをチップ表示し、チップの×で候補から外し、「＋ タグ」からタグ一覧を編集。適用は再検索ボタンで確定。
- カード展開時の旧「商品名を編集」は「商品名編集」に短縮。隣に「画像編集」を新設し、Androidのシステム画像選択画面から任意の画像を選択、端末内に縮小JPEGを保存する。
- 手動設定画像は自動取得画像とは別ファイルに保存。`user_image_edited` フラグで自動取得が手動画像を上書きしないよう保護（DB v3→v4、非破壊マイグレーション）。画像データ以外の既存商品情報・価格履歴・タグに影響させない。
- 成功済み商品名・価格・Amazon画像の抽出器、ネット取得処理、WebView補完、署名、applicationId、YMLは変更しない。
- 検証：全Javaソースの構文診断（Androidライブラリ未解決を除く）、コード/DB更新経路の静的チェック、build invariants、ZIP整合性。Android SDK が無いため Gradle実ビルド・実機は未確認。

# BookmarkLauncher 0.1.77 (versionCode 78) — Amazon画像取得・WebView表示不具合修正

- 正本は直前の `BookmarkLauncher_0.1.76_source.zip`（0.1.76 / versionCode 77）のみ。
- Wishリスト内部で描画されていた画像・価格補完用WebViewを非表示（alpha=0、フォーカス不可）とし、ページの背面も不透明化。WebViewはレイアウトに接続したままDOMを検査する。
- Amazonの画像解析を価格・商品名のロジックから独立した `AmazonProductImageExtractor` で補完。高解像度URL、遅延読み込み属性を解析し、商品画像CDNの `/images/I/` のみ採用。
- 画像WebViewは1回で画像が見つからなくても限定回数だけ再試行し、タイムアウトで終了。サイトの制限やCAPTCHAの回避は行わない。
- 1pxのダミーや小さすぎる画像は保存成功と見なさず、過去に保存した無効なサムネイルも再取得対象にする。
- 商品名・価格の解析器、DB価格履歴、タグ、カードアニメーション、ホーム連動スワイプは変更なし。価格補完WebViewは**非表示設定のみ**変更。
- `applicationId=com.cmyk.bookmarkslauncher`、固定署名、既存データ、YMLは維持。Android Gradle実ビルド・Amazon実サイト・実機での確認は未実施。

# BookmarkLauncher 0.1.76 (versionCode 77) — Amazon画像取得不具合修正

- 0.1.75 (76) source.zip を唯一の正本として使用。
- Amazonの画像が通常HTML取得で保存されなかった場合、手動「今すぐ更新」で商品画像専用のWebView補完を起動。
- Amazonのメイン商品画像のみDOMから取得し、HTTPSのAmazon画像CDN URLに限定して保存する。
- 画像ダウンロードに商品ページのRefererなど一般的なHTTPヘッダーを付与。
- 価格解析器、価格WebView、商品名解析器、DB価格履歴のロジックは変更しない。
- アプリID、固定署名、データスキーマ、YMLは変更なし。
- Android Gradleの本番コンパイルと実際のAmazon商品ページでの取得は未確認。

# BookmarkLauncher 0.1.75 (76)

## 0.1.75 — Wishlist price/metadata pipeline isolation + free foreground WebView price fallback
- Base **only** on 0.1.74 (75). Keep applicationId and stable signing keystore unchanged; code increment to 76.
- `WishlistMetadataExtractor`: name, hero-image and availability parsing only; does not import/use price logic.
- `WishlistPriceExtractor`: JPY prices from Product JSON-LD, OGP/meta, itemprop, and product-heading-localized yen text; does not consume a title from the metadata extractor. Price values must be scoped to product data.
- `AmazonPriceExtractor`: separate Amazon.co.jp current-price HTML detection (no product-name logic).
- `WishlistCrawler`: HTTP transport and two independent parser invocations only. A failure in one parser cannot suppress the other.
- `WishlistRepository`: independent metadata and price database write paths. A price lookup never changes the product name/image; image fetching errors do not invalidate stored price. Existing records, titles, pictures, tags and historical prices are preserved.
- Manual **今すぐ更新**: if direct HTML lookup has no price, try `WishlistPriceWebViewProbe` once for the same product. The probe reads current-price DOM selectors, explicit JPY meta and Product JSON-LD, and writes **price only** to local history. It has a 14-second timeout and refuses non-HTTPS/unsafe URLs; browser restrictions/CAPTCHA are not bypassed. No paid API, tracking server, automatic WebView background crawling, or unlimited retry loops.
- Scheduled/background jobs continue using direct HTML only; WebView runs only on an explicit foreground update.
- This source has static checks, stub Java compilation and 11 sample cases; a full Android Gradle build and real site/device integration test are not available in this environment.

# BookmarkLauncher 0.1.74 (75)

## 0.1.74 (75) — Wishlist price detection reliability fix
- Preserve existing 0.1.73 UI/gesture behavior. Improve only price parsing for Japanese merchant pages lacking metadata by extracting explicit yen prices from the vicinity of a matching product heading.
- Support itemprop price values written in an element body. Do not infer arbitrary page prices or prices from shipping/recommendations.
- Show useful failure reasons (HTTP code, timeout, price not found) and persist them with a non-destructive Wishlist DB v2→v3 migration.
- Existing Wishlist records, manual titles, images, tags, sorting, price history and signing identity are retained.

Androidホームランチャーの操作感を正本にしたブックマーク管理アプリ。

## 0.1.73 (74) — Wishlist card layout and independent expansion
- Collapsed thumbnail 80dp; expanded thumbnail 140dp. Keep the same thumbnail view and animate its size along with card height (ChangeBounds + Fade).
- Expanded header: image on the left; up to two lines of product name, URL and name-edit button on the right. Prices, tags, monitoring and three action buttons below the header.
- Multiple Wishlist cards may remain expanded at once; opening or closing one does not change the others. Tapping the Wishlist title collapses all cards with a shared animation.
- Remove all purchase-recording interface: purchase counter, history listing, button, and return-from-product purchase prompt. Existing purchase data is retained in the database for backward compatibility, without UI exposure.
- Keep existing card reordering animation, tag dialogs, price crawling, home/Wishlist swipe navigation and app identity/signature unchanged.

## 現行仕様
- applicationId: `com.cmyk.bookmarkslauncher`
- version: `0.1.77 (78)`
- minSdk 29 / targetSdk 36 / compileSdk 36
- ホームは5列×8行のCellLayout型グリッド
- ホーム初期値は4×1検索窓＋右隣1×1のNライトブルー丸＋。どちらも独立して長押しドラッグ移動でき、上部×へドロップして削除可能
- 検索窓／＋を削除した場合、ホーム空欄長押しからそれぞれ再追加可能
- 検索は表示名・サイト名・ページタイトル・URLを対象
- フォルダ内は4列×5行。アイコンとテキストエリアはホームと同じ物理サイズ
- 長押しドラッグで空きセルへ自由配置、外周は650msでreorder。周囲アイコンは約180msで滑らかにスライドして空きセルを作る
- 既存フォルダ上で約650msホバーするとドロップ前に展開し、親→子→孫へ同一ドラッグを継続可能
- ドラッグ開始後に生成されたフォルダパネルも、root側ドラッグコーディネータでホバー・ドロップを追跡
- フォルダへ入ってから外へ出るとその階層だけ格納。子を出た後は親を残し、親へ再入場→再退出で親を格納
- フォルダは元アイコン位置から拡大展開し、閉じる時は逆方向へ格納
- フォルダダイアログ自体は常に不透明。子・孫が重なっている間だけ背面フォルダの不透明背景色を段階的に暗くし、擬似alpha風に黒へ近づける。アイコン／文字は常に不透明
- フォルダ欄内タップでは閉じず、欄外タップで最前面フォルダのみ格納
- フォルダ名タップでリネーム、名前欄長押しでダイアログを一時移動（位置は保存しない）
- フォルダが1件以下になった場合は自動解体し、残存1件を親階層へ繰り上げ
- フォルダ詳細の「中身を保護」はデフォルトON。ONでフォルダだけ削除、OFFで配下を再帰削除
- ブックマーク長押しで詳細ダイアログ。サイト名・1:1サムネイル・URL・ブックマーク日時・最終アクセス・オフライン状態を表示（Google Maps / YouTubeではオフライン項目を非表示）
- サムネイルタップでページトップスクショ・favicon・site name・page titleを同時再取得
- 撮影用WebViewは画面外で描画し、取得中はNライトグレーのシークサークルのみ表示
- ブックマークアイコンはNダークグレー円＋縮小favicon。faviconは元形状・縦横比を維持し、未取得時のみ汎用ブックマーク記号
- フォルダアイコンはNブルーの処理描画ベクター形状＋最大4件プレビュー。子フォルダもフォルダ絵で表示
- アイコン長押し中は画面上部中央（初期基準から合計40dp下）に黒丸＋Nレッドの×削除ターゲット
- Android共有（text/plain）からURLを受け取りブックマーク化し、メタデータ／サムネイル取得を開始

## Chrome同期を後付けするためのDB設計
`nodes` はアプリ内UUID `id` と別に `external_source` / `external_id` を保持。
Chrome等の外部ブックマーク同期を後付けしても、セル位置・表示情報・スクリーンショット・オフライン情報を独立維持できる。
削除は `deleted_at` を使うsoft delete。

## オフラインWeb
- 通常Webブックマークのみ対応。Google Maps / YouTubeは対象外。
- WebViewのMHTMLをSAFで選んだ外部フォルダへ保存。アプリ内部は一時キャッシュのみ。
- 1ブックマーク内で複数ページを追加保存し、保存済みURLはローカルMHTMLを優先表示。
- 未保存ページはフロート＋、保存済みページはフロート更新アイコン。
- フロート操作はFinderlessCamera v0.1.92準拠：300ms長押し、ポヨン＋40msバイブ、自由ドラッグ、中央削除ターゲット、スナップ／リリース閾値、位置保存。

## 今後
- Chrome/Google同期ブリッジ

## ビルド
GitHub Actions `.github/workflows/build.yml` を使用。
AGP 9.4.0 / Gradle 9.6.0 / JDK 17。
固定keystore同梱のため継続ビルドは上書きインストール可能。



## 0.1.53 (54)
- オフライン保存済みバッジ内の白い▼を、3辺が等しい下向き正三角形へ変更。正三角形の重心を緑丸の幾何学的中心へ一致させ、丸のサイズ・位置・色は維持。


## 0.1.52 (53)
- オフライン保存済みのブックマークアイコン右上に、Nグリーン `#227733` の丸＋白い下向き三角ベクターの状態バッジを追加。三角形の重心を丸の中心へ一致させて幾何学的に中央配置。
- オフラインビューアから戻った際にホーム／開いているフォルダを再読込し、保存直後はバッジを表示、オフライン保存削除後はバッジを消去。


## 0.1.51 (52)
- 保存済みMHTMLを開くときはJavaScriptを停止し、WebViewのネットワーク読み込みを遮断して外部保存ファイルだけで描画するオフラインモードへ変更。
- オフライン表示中に保存済みリンクをタップした場合はローカルMHTMLを優先。未保存リンクはネット接続が無ければ遷移せず「このページは保存されていません」と表示。
- 保存／更新のオンライン再読込時のみネットワークとJavaScriptを有効化。機内モード中の更新操作は実行しない。

## 0.1.49 (50)
- 通常Web詳細のオフライン保存済み表示を「表示」に変更し、詳細側の「更新」ボタンを削除。保存済み時は「表示／削除」。
- URL本文は最大2行まで表示し、それ以降は末尾省略。コピーカプセルはURL行の上詰めに変更。
- オフライン保存／表示から戻った際にDBを再読込し、開いたままのブックマーク詳細ダイアログの保存状態をその場で更新。
- オフライン削除確認はブックマーク詳細ダイアログを閉じず、その上に表示。削除完了後は同じ詳細ダイアログ内を未保存状態へ更新。


## 0.1.48 (49)
- 通常Web詳細の「オフラインビューイング」題字は維持し、タップ可能な状態テキストをNオレンジの細カプセルボタンへ変更。
- URL列右端にNダークグレーの細カプセル「コピー」ボタンを追加。URL本文タップの既存コピー動作も維持。
- オフラインビューアの保存／更新フロート初期位置を右下寄せへ変更。ユーザーが移動済みの場合は保存位置を優先。
- ステータスバーを半透明黒へ変更。
- オフラインビューアは初期表示を横幅フィットにし、横スクロールバーを非表示。ピンチズームは維持。

## 0.1.46 (47)
- Google Maps / YouTube詳細から「オフラインビューイング」を削除。通常Webのみ表示。
- Google Maps電話番号取得・詳細表示を停止。既存DBカラムは互換維持のため残す。
- 通常Web向け外部MHTMLオフラインビューアを追加。SAF選択フォルダを正本とし、アプリ内は一時キャッシュのみ。
- 閲覧中に未保存URLへ移動すると＋、保存済みURLでは更新アイコンへ切替。ページ単位で保存／更新。
- フロートボタンの長押し移動をFinderlessCamera v0.1.92から移植。


## 0.1.10 (11)
- Central drag coordinator at the root ViewGroup for reliable folder IN/OUT detection.
- Only the topmost folder can exit-close; after a child closes the parent must be re-entered before it can close.
- Folder panel surfaces stay opaque; only geometrically overlapped background regions are progressively darkened.
- Search bar visual height reduced to 50% of its 5x1 row; outside taps clear focus and hide the IME immediately.
- Delete target moved to top-center.
- More vertical room for two-line icon labels; home/folder tiles share the same metrics.
- Favicons keep their original silhouette/aspect ratio instead of circular clipping.


## 0.1.11 (12)
- Child-folder drag-out now quarantines the parent IN/OUT detector for 1 second.
- Parent close requires a real outside -> re-enter -> outside sequence after a child closes.
- Bookmark favicon reduced inside its dark-gray circle while preserving original aspect ratio.
- Folder circle uses N Light Gray (#656060).
- Folder dialog background uses N Gray (#454040).
- Search field uses N Light Gray (#656060).


## 0.1.12 (13)
- Bookmark/folder circle diameters stay unchanged; bookmark favicon now uses up to 80% of the circle diameter while preserving its original aspect ratio and silhouette.
- Delete target moved 25dp downward from its 0.1.11 top-center position.
- Activity uses IME adjustNothing so the home grid never shifts when the keyboard opens.
- If the search field would be covered by the IME, only the search field receives a temporary upward translation; closing the IME restores its exact grid position.
- Tapping outside the focused search field immediately clears focus, hides the keyboard, and restores any temporary IME translation.


## 0.1.14 (15)
- 検索窓を4×1へ変更し、さらに細身化・左右余白を追加。
- 検索窓右側に1×1のNライトブルー丸＋を追加。URL直接入力からブックマーク追加でき、取得処理でtitle / site name / favicon / screenshotを更新。
- 検索窓と＋は独立して長押しドラッグ移動・上部×へドロップ削除可能。空欄長押しから再追加可能。
- 検索窓は長押し移動時はドラッグ、移動しない長押しでは標準のコピー／切り取り／貼り付け／全選択／範囲選択を利用可能。不要なSearch項目のみ抑制。
- faviconを0.1.13からさらに80%へ縮小。サークルサイズは維持し、元の縦横比・形状を維持。
- フォルダアイコンをNブルーの処理描画ベクター形状へ変更。子フォルダもフォルダ絵で表示。
- BookmarkLauncher題字をNホワイト＋GitBuild/PriceRec系のlight sans題字へ統一。
- 削除×をさらに15dp下げ、初期位置から合計40dp下へ。
- フォルダダイアログ重なり暗化を双方のroundRectでクリップし、重なり部分でも角丸を維持。

## 0.1.13 (14)
- Favicon visual size is reduced to 80% of the 0.1.12 rendered size; bookmark/folder circle diameters are unchanged.
- Folder-preview favicons follow the same 80%-of-previous-size rule while preserving original aspect ratio and silhouette.
- Search field is slimmer (50% of row height, 30dp minimum) and visually inset 12dp on both sides while still occupying the full 5x1 grid row.
- Drag-source translucency is keyed by item ID at Activity level and survives folder exit/re-entry, panel refresh, and tile recreation until the drag session ends.


## 0.1.15
- Home folders restored to the launcher-style N-light-gray circle with up to four child previews.
- Folder tiles shown inside folders use the N-blue vector folder silhouette.
- Home-folder circular drop hit area restored; nested-folder vector hit area retained.
- applicationId and stable signing key unchanged.


## 0.1.17
- Home folder remains the N-light-gray circular preview folder.
- Nested folder tiles use a dark-gray circle with the shared N-blue vector folder silhouette.
- Mini nested-folder previews now reuse the exact same vector path instead of the legacy mini glyph.
- Up to four home-folder preview items are enlarged and clipped by the outer folder circle when necessary.


## 0.1.17 changes
- Child-folder vector glyphs use N Light Blue (#445577).
- When a parent folder is expanded, child folders use the same full Home folder tile (circle + up to four previews) instead of the compact nested-folder glyph.
- The four preview positions inside a Home folder circle are spread farther outward while retaining circular clipping.


## 0.1.18 (19)
- Search field hint changed to `ブックマーク検索`; a vector clear button appears at the right while text exists.
- Search 4x1 and URL-add 1x1 widgets are visually raised to align with normal icon height while retaining their original grid occupancy.
- Drag occupancy previews for search and URL-add are rounded rectangles matching 4x1 / 1x1 cells.
- Dropping onto a folder only stores the item; folder expansion occurs only after the existing 650 ms drag hover.
- Bookmark creation from Share or direct URL continues to auto-fetch favicon, top-page screenshot, site name, and page title.

## 0.1.19 (20)
- 検索結果をフォルダと同じNグレー角丸パネル＋4列アイコングリッドで表示。
- ブックマーク詳細の左下に「削除」「コピー」を並べ、コピーはNライトブルーでホームへ別UUID複製。
- 画面回転を禁止し、Activityをportrait固定。
- ホーム空欄長押しメニューを大きな角丸Nグレー面＋背景なし白文字の縦メニューへ変更し、「エクスプローラ」を追加。
- エクスプローラはBookmarkLauncher内の論理的なホーム／フォルダ構成だけを辿る入口として実装。
- NDialog背景をNグレー (#454040) に統一し、通常ボタンはNライトブルー (#445577) のカプセル型へ統一。
- ホーム／展開フォルダのフォルダ円をNライトブルー (#445577) に統一。


## 0.1.20 (21)
- ドラッグ中、アイコン外周を掠めた時に並び替え候補へ入りやすいよう、ドラッグ専用の外周ヒット領域を少し拡大。
- 中央のフォルダ作成／フォルダ格納判定も一段だけ拡大し、重なる場合は中央フォルダ判定を優先。
- ブックマーク表示名は custom name → page title → site name → legacy title/URL の順で決定。
- Android共有時は EXTRA_SUBJECT を初期タイトル候補として使い、WebView取得後は実ページタイトルを優先表示。


## 0.1.21 (22)
- 題字「BookmarkLauncher」のTypefaceをN Standardと同じデフォルトsansへ統一。
- 名前変更はNダイアログを使用し、既存名を開いた時点で全文選択。
- 空欄長押しの「エクスプローラ」をN Standard由来のNエクスプローラUIへ置換。対象はホームをルートにしたBookmarkLauncher内フォルダ階層のみ。
- 空欄長押しメニューの表記を `(＋URL追加)を追加` に訂正し、その下に「アプリを追加」を追加。
- 端末の起動可能アプリ一覧から、アプリアイコン＋アプリ名のショートカットをホームへ追加可能。タップで対象アプリを起動。
- BookmarkLauncherがバックグラウンドへ移ると、展開中のフォルダパネルを全て閉じ、復帰時は通常ホームから再開。


## 0.1.22 (23)
- App picker: search field under title, ListView recycling + scaled lazy icon loading for crash/memory mitigation.
- App picker: long-press multi-select, green check, selection count, batch add.
- Home empty-cell long-press menu: NS-style diagnostic log at bottom.
- Diagnostic log records app-picker query/icon/errors and uncaught exceptions.
- N Explorer buttons aligned to current NS visual component.

## 0.1.23 (24)
- BookmarkLauncher title uses the same 25sp bold default sans treatment as GitBuild.
- Version name is displayed directly under the title in the same 12sp N-white style as GitBuild.
- Search field keeps its existing grid position/order but is always rendered above bookmark/folder tiles when IME translation causes overlap.
- Drag graze hit halo expanded from 6dp to 10dp.
- Folder-create / move-into-folder merge hit region expanded outward by 4dp without changing icon visuals.

## 0.1.29 (30)
- Google Maps URL (`maps.app.goo.gl`, `goo.gl/maps`, `google.* /maps`) を専用判定。
- Google Mapsブックマークは通常faviconの代わりに、Nレッド `#441100` のピン型VectorDrawableを表示。フォルダ内プレビューも同じピン表示。
- Google Mapsの短縮URLはWebViewで展開後、`/place/<店名>/` → 画面のh1/og:title → page title → 共有テキストの順で店舗・施設名を取得。
- Google Mapsのfavicon取得は行わず、専用ベクター表示を固定。

## 0.1.30 (31)
- Google Mapsのページタイトル／OGタイトルから郵便番号・都道府県以下など住所部分を除外し、屋号・施設名を優先して表示。
- Google Mapsの画面h1を最優先候補にし、URLの `/place/<name>/`、通常タイトル、共有タイトルへフォールバック。
- 撮影用WebViewでmain-frameエラー、`chrome-error://`、アクセス不可系タイトルを検出した場合はエラーページをスクリーンショットとして保存しない。既存サムネイルがある場合は維持。
- `intent://` 等へ遷移した場合はブラウザ用HTTPSフォールバックを使い、WebViewのアクセス不可画面化を抑制。
- Google Maps専用ピンをNライトレッド `#662211` に変更。

## 0.1.31 (32)
- Google Maps短縮URLはWebViewより先にHTTPリダイレクトを追跡し、`intent://` を含む場合はブラウザ用HTTPS URLへ復帰して最終Maps URLを確定。
- 最終URLから `/place/<name>/`、`@lat,lng`、`!3dlat!4dlng`、座標クエリを解析し、屋号と緯度経度を取得。
- 緯度経度が取れた場合はOpenStreetMapの地図タイルを端末側で合成し、Nライトレッドの中心ピン＋帰属表示付き512px正方形の静的地図サムネイルを生成。WebViewスクショ失敗時もこの静的地図を使用。
- 座標または地図タイルを取得できない場合のみ、従来のWebViewスクリーンショット取得へフォールバック。
- Google Maps用ピンアイコンはNライトレッド `#662211` を維持し、表示サイズを0.1.30比80%へ縮小。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.32 (33)
- Google Maps静的地図の座標抽出順を修正。`!8m2!3dlat!4dlng` のPOI座標を最優先、その他の `!3dlat!4dlng` は最後の有効ペアを採用。
- `@lat,lng` と `center` / `ll` は地図の表示中心になり得るため、短縮URL展開直後には使わず、WebViewで最終URLまで到達してもPOI座標が取れない場合だけ最終フォールバックとして使用。
- WebView到達後は `rel=canonical` / `og:url` も一度確認し、そこにPOI座標があれば表示中心より優先。
- Google Mapsタイトルが `〒住所 … 階 屋号` の並びでも、住所・階数部分を除いて後半の屋号／施設名を抽出。全角数字にも対応。
- Mapsページのタイトル取得はh1だけで確定せず、専用h1・main h1・OG title・Twitter title・document.titleを順に候補化し、住所だけの候補を除外。
- 診断ログへ静的地図生成に使った座標と precise / viewport fallback の別を記録。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.33 (34)
- Google Maps静的地図の座標決定を見直し、`@lat,lng` と一般の `!3d..!4d..` は使用しない。
- Maps画面から住所を取得し、Android Geocoderで座標化する経路を最優先。明確なPOI `!8m2!3d..!4d..` のみフォールバックとして使用。
- Mapsの共有タイトルはEXTRA_SUBJECTを無加工で採用せず、屋号抽出を必ず通す。住所＋屋号形式や階数直後の屋号にも対応。
- Google Maps取得成功時は屋号をtitle/page_titleへ反映し、詳細ダイアログの題字・ページタイトル・サムネイルを再取得直後に更新。


## 0.1.34 (35)
- Google Maps対応を `com.cmyk.bookmarkslauncher.googlemaps` パッケージへ完全分離。通常ブックマークのキャプチャ処理は `WebBookmarkCaptureManager` として独立。
- Maps URL判定、短縮URL展開、共有タイトル解析、屋号／住所抽出、Geocoder座標化、静的地図生成、Nライトレッドのピン描画を `GoogleMapsModule` 配下へ集約。
- `BookmarkCaptureManager` は通常Web／Google Mapsの振り分けだけを担当し、Maps固有処理を保持しない。
- MainActivityの共有受信とBookmarkTileViewのMaps表示も公開ファサード `GoogleMapsModule` 経由に統一。Maps内部クラスを通常UIから直接参照しない。
- Repositoryの `updateGoogleMapsMetadata` を廃止し、汎用 `updateCapturedMetadata` へ置換。データ層からMaps固有ロジックを除去。
- 今後、Google Maps以外の通常開発では `googlemaps` パッケージを変更しないことをソース内 `package-info.java` に明記。
- Google Maps共有、屋号取得、住所Geocoder、静的地図、Nライトレッド80%ピンの0.1.33動作を維持。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。

## 0.1.36 (36)
- Google Maps静的地図はzoom 16を維持したまま、中央450px範囲を512pxへ拡大して表示。0.1.34比で約13.8%だけ寄った縮尺に調整。
- 静的地図内の地点マーカーサイズは維持し、ホーム／フォルダ内のGoogle Mapsピンアイコンのみ、未反映だった指定どおり0.1.34表示サイズの20%へ縮小（80%小さく）。
- favicon未取得時に表示する通常ブックマークのデフォルト記号を少し小型化。取得済みWebサイトfaviconのサイズは変更しない。
- Google Maps専用ロジックの `googlemaps` パッケージ分離を維持。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.36 (37)
- Google Maps static thumbnail: pinch-in/out changes real map coverage (70%..160%) and redraws tiles on release.
- Per-bookmark Google Maps scale + resolved coordinates stay isolated in googlemaps SharedPreferences.
- Google Maps home/folder pin restored from the accidental tiny size to 70% of the original pin size.
- Existing Maps bookmarks without stored coordinates resolve them once on first pinch refresh.


## 0.1.37 (38)
- Google Maps detail thumbnails now track pinch scale continuously using the current bitmap, then replace it with a freshly rendered sharp static map after release.
- Bookmark detail and folder detail dialogs dismiss with a deliberate vertical swipe up or down; multi-touch is excluded so Maps pinch does not dismiss them.
- Google Maps bookmark pin remains isolated in the googlemaps package and uses 70% of the original pin size.

## 0.1.38 (39)
- ブックマーク／フォルダ／アプリなどのユーザー操作による削除は、実削除前にNダイアログで確認する。ドラッグで削除先へ落とした場合も同じ確認を通す。
- フォルダで「中身を保護」をOFFにしている場合は「フォルダと中身を削除しますか？」と明示する。
- ブックマーク詳細ダイアログの「コピー」表記を「複製」へ変更。複製動作自体は従来どおりホームへ同一ブックマークを作成する。
- ブックマーク詳細ダイアログのURL表示をタップすると、そのURLをクリップボードへコピーし「URLをコピーしました」と表示する。
- Google Maps専用ロジックには変更を加えない。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。

## 0.1.39 (40)
- 削除確認を汎用選択メニューから専用Nダイアログへ変更。本文の下部右側に「キャンセル」「削除」を横並びし、「削除」はNライトレッド `#662211`。
- フォルダで中身も削除する場合は「フォルダと中身を削除しますか？」を表示。ドラッグ削除も同じ確認ダイアログを通す。
- フォルダ内は4列・既存アイコンサイズを維持したまま、5行を超えると下方向へ行を追加。題字は固定し、内容エリアだけ縦スクロールする。
- フォルダが満杯になった時点で次の空行を確保し、追加アイテムを下へ配置できるようにする。
- Google Maps専用ロジックには変更を加えない。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.40 (41)
- 削除確認ダイアログのボタンを中央配置し、キャンセル/削除を1行表示に固定。
- フォルダは5行以内ではスクロールを無効化。6行目以降でスクロールを有効化。
- フォルダの表示高を約5.5行へ拡張し、6行目が半分見切れて見えるように調整。

## 0.1.41 (42)
- フォルダ内は1〜20個（5行）まで予備6行目を作らず、縦スクロールを完全に無効化。旧版で6行目に残った位置も5行内へ再配置する。
- 21個目で実際に6行目が発生した時だけフォルダダイアログを少し縦に延長し、6行目の上半分だけが見切れて見える高さにする。
- 6行目以降は内容エリアだけを縦スクロールし、7行目以降でもダイアログ自体はそれ以上拡大しない。
- Google Maps専用ロジックには変更を加えない。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.42 (43)
- YouTube対応を `com.cmyk.bookmarkslauncher.youtube` パッケージへ完全分離。通常Web／Google Mapsの取得処理からYouTube固有ロジックを分離。
- `youtube.com/watch?v=...`、`youtu.be/...`、`youtube.com/shorts/...`（embed/live含む）から動画IDを抽出。
- YouTube公式サムネイルを maxres → sd → hq の順で直接取得し、ページUI・文字・再生コントロールを含めず1:1中央トリミングしてブックマーク画像として保存。
- oEmbedから動画タイトルを取得できた場合はサイト名 `YouTube` とページタイトルへ反映。
- 専用サムネイル取得に失敗した場合だけ従来のWebView取得へフォールバック。
- Google Maps専用パッケージは変更せず、applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。

## 0.1.63 (64) Wishlist initial build
- 0.1.62 (63) を唯一の正本として Wishlist を統合。versionCode は 64 へ更新し、applicationId／固定署名を維持。
- ホームから右スワイプで Wishlist を開く。ブックマーク詳細から Wishlist へ追加し、元ブックマーク／favicon／URL は変更しない。
- Wishlist は細めのグリップ付き縦リスト。タップで展開し、現在価格・登録時価格・価格変動・タグ・購入済み回数／履歴・再開監視を表示。
- 右下は虫眼鏡丸ボタン。検索ダイアログ内に検索欄・価格範囲・タグチェックリストをまとめ、価格条件検索時は全件の最新価格を再取得してから絞り込む。
- タグ追加／選択／編集は PriceRec. の操作系を参照。商品展開内からタグを追加し、タグ一覧はグリップ並べ替え・長押し編集／削除に対応。
- 商品ページから戻った際、一定時間閲覧していた商品だけ画面下に「購入しましたか？」確認バーを表示。購入日時とその時点の価格を履歴保存。
- JobScheduler で約1日1回クロール。再開監視ONの商品が未開始／購入不可から購入可能へ変化した場合に通知。
- 0.1.61で指定済みの「＋ → ブックマーク / アプリを追加 / QR作成」、QR作成のURL入力、ブックマーク詳細の「削除 / QR生成 / 複製 / 閉じる」を維持。

## 0.1.64 (65) Wishlist return navigation
- Wishlist から左スワイプで BookmarkLauncher ホームへ戻れる復路を追加。
- Wishlist 上部の戻るボタンと Android 戻る操作も同じ復帰処理へ統一。
- 通知から Wishlist 単独で開いた場合でも MainActivity を前面へ復帰して終了できるようにした。
- 横スワイプは 110dp 以上かつ縦移動より十分大きい場合のみ成立し、縦スクロール／グリップ操作との誤爆を抑制。
- build-apk.yml は versionName/versionCode の固定値を持たない BookmarkLauncher 共用 workflow に変更。APK 名は source.zip 内の versionName から自動生成。

## 0.1.65 (66) Wishlist tag persistence fix
- Wishlistの商品展開内タグ編集を即時保存方式へ変更。
- 既存タグのチェックON/OFFを操作時点で item_tags に保存し、閉じる操作でも変更が消えないよう修正。
- 新規タグ作成時はタグ作成（既存同名タグなら再利用）と同時に対象商品へ即時紐付け。
- item_tags への追加は CONFLICT_IGNORE を使用し、重複紐付けで失敗しないようにした。
- versionCode 66 / versionName 0.1.65。

## 0.1.66 (67) Wishlist Java compile correction
- WishlistActivity.Flow の generateLayoutParams(AttributeSet) を public override に修正。
- 署名と applicationId の固定を維持。

## 0.1.67 (68) Wishlist gesture, tag dialog and price placeholder
- Wishlist画面の右スワイプ（横移動110dp以上）でホームに戻るよう、従来の左スワイプ判定を反転。ホーム→Wishlistの右スワイプは変更なし。
- タグ選択／編集ダイアログを開いた際に入力欄が自動フォーカスされてキーボードが表示され、初期配置が動くことを抑制。開いた時は中央表示、編集欄をタップすると入力できる。
- 商品名の右に価格が未取得の場合表示されていた「—」を削除。価格取得済みの場合は価格を表示。
- versionCode 68 / versionName 0.1.67。applicationId・固定署名・その他の機能は維持。


## 0.1.68 (69) 連動スワイプ・ページ統合
- v0.1.67 (68) のsource.zipを唯一のベースとして作成。
- ホームとWishlistをひとつのウィンドウ上に並ぶ実ページとして統合。Wishlistの描画・DB操作・タグダイアログ等を `WishlistPage` に集約し、通知用の `WishlistActivity` からも再利用。
- ホーム右スワイプでWishlist、Wishlist右スワイプでホームへ戻る。Wishlist左スワイプでも逆方向で戻れる。
- 指の移動量に応じて両ページを同時に水平移動し、一定距離を超えるとスナップ。短いスワイプは元の位置へアニメーション復帰。
- 縦スクロールの開始時はページ切替ジェスチャーを破棄。長押しドラッグ中、フォルダ展開中、検索中は切り替え禁止。
- Wishlist再開通知からはMainActivity内の同じWishlistPageへ直接遷移。旧通知用WishlistActivityはMainActivityへの転送専用として保持。
- applicationId、固定署名、依存、ワークフローを維持。versionCode 69。

## 0.1.69 (70) Wishlist header alignment

- Wishlistの題字をホームのBookmarkLauncher題字に合わせ、上端64dp、左余白18dp、25sp太字、44dp高さで縦中央揃えに統一。
- 左端の戻る矢印カプセルを削除。スワイプ操作による画面移動はそのまま維持。
- applicationIdと固定署名を維持、versionCode 70。

## 0.1.70 (71) Wishlist URLプレビュー
- Wishリストの左下に「＋」を追加し、商品URLの直接登録と初回の自動解析を実装。
- ブックマーク詳細からWishリストへ追加した場合も、既存の非同期初回解析を使って商品名・画像・価格を取得。
- OGP（og:title/og:image）、Twitter Card、JSON-LD Product（name/image/JPY price/availability）、ページタイトルを優先順で解析。商品画像の一部HTML属性も補完。
- 取得画像は最大5MBをダウンロードして縮小・JPEG化し、`filesDir/wishlist_previews/`にオフライン保存。Wishカードでは商品画像を優先し、未取得時は既存のブックマークサムネイル／faviconを表示。
- SQLiteDB v1→v2非破壊移行：商品画像のURLとローカルパス、手動で商品名を編集したフラグを追加。登録済みWish・タグ・価格履歴・並び順は保持。
- 商品名はURL元のブックマーク表示名より取得した商品名を優先。商品詳細内「商品名を編集」またはタイトル長押しで手動変更した後は、以降の再解析で上書きしない。
- 価格は通貨がJPYと確認できた構造化データまたは日本向けサイトの価格メタ情報のみを円として扱う。アクセス制限・動的サイト・情報欠落時は取得できた範囲のみ適用し、取得済み画像は消さない。
- 画面の連動スワイプ、applicationId、固定署名、既存workflowのビルド構成は維持。versionCode=71。


## 0.1.71 (72)
- Wishlistカード開閉にChangeBounds + Fadeのアニメーションを追加。リストを再生成せず隣接カードの位置も滑らかに追従。
- カードの並べ替えをグリップ長押しドラッグ方式に変更。掴んだカードは指に追従、周囲カードは220msで滑らかに移動し、確定時のみ並び順を保存。
- 商品名はカード右端まで1行表示し、超過分は末尾省略。価格は二段目へ移動。
- タグダイアログのwindow属性を表示前に適用し、初期右寄り・位置飛びを軽減。
- 商品価格はJSON-LD Offer / priceSpecificationのJPY受け渡し、OGP、itemprop、AmazonのpriceToPayと明示的な商品価格要素から補完。ページ内の無関係な価格や外貨を誤表示しない。
- ネットワーク拒否／サイト側非公開の価格は取得不可のままとし、過去に保存した価格は維持。

## 0.1.82 (83) N Standard共有アイコン正本移植
- Wishlist展開カードの共有丸アイコンを N Standard 0.1.28 の `NShareIconView` 正本へ変更。元の描画構造を維持し、パッケージと N.DGRAY 色参照だけをローカル化。
- 正本どおり42dp、ダークグレー `#252020` 背景、白 `#FFFFFF` の細い線と3つの円を幾何学的にセンター配置。旧代替 `NStyleShareIconView` を削除。
- 共有操作（商品名とURLをAndroid共有シートへ渡す）、再開監視ボタン位置、成功済み取得ロジックは変更しない。
- versionCode 83 / versionName 0.1.82。applicationIdと固定署名を維持。


## 0.1.89 (90)
- Wishlist + / search floating buttons: N light blue (#445577) circle with N white (#A9A999) glyphs. Search-mode visibility remains unchanged.
- Wishlist card grip: do not detach/reparent any card while the finger is pressed. Use PriceRec-like animated sibling preview; commit reorder and persist only on ACTION_UP. CANCEL restores the original order without saving. Auto-scroll near list edges is active while pressed.
- Wishlist price search inputs: numeric keyboard, Android Autofill disabled for price fields, saved input state disabled, and personalized IME learning suppressed. This does not guarantee every third-party keyboard hides its proprietary suggestions.
- Keep successful product title, price, image, availability and site-status crawlers unchanged.
- Signing/applicationId unchanged; Gradle build and device test remain unverified in this environment.


## 0.1.99 (100) GENERAL購入可否の補強
- 0.1.98 (99) を唯一のベースに、ノーマルモードの購入可否判断のみを強化。
- 対象は7店舗の未確認状態。商品固有のフォーム／画像ボタン／リンク型購入操作を厳密に評価し、関連商品・ナビゲーションは採用しない。
- 単一商品専用の非表示WebViewで、表示・有効状態と数量欄・フォームの関連を確認。カートクリックや注文操作は実行しない。
- 八百三の複数商品紹介ページは無理に「購入可能」としない。既存のAmazon／楽天／Yahoo解析には変更なし。
- 静的・模擬テストに合格しても実サイトの在庫確認は未検証。


## 0.1.101 (102) - large retail recovery and partial-result safety

- Three large retailers keep independent DOM selectors and routing; marketplace/GENERAL parsers are unchanged.
- Dedicated hidden WebView begins inspecting during page loading, not only after onPageFinished.
- Timeout / main-frame errors preserve independently verified product fields instead of discarding them.
- Only verified fields update storage. Missing DOM price no longer marks a previously successful price as failed.
- Dedicated retail HTTP connection/read timeout is shorter before rendered fallback; diagnosis logs distinguish HTTP from WebView stages.
- UNIQLO variant-specific stock remains UNKNOWN without confirmation of selected color, size and length.
- No claim of site-specific end-to-end success until Android Gradle and device tests pass.


## 0.1.113 (versionCode 114)
- Wish collapsed card: price aligned below purchase status, 13sp; sort radio/text 10dp gap.
- Availability captions shortened to 購入可能/未確認. Price change signed formats -¥/+¥/¥0.
- GENERAL still handles ASKUL product /p/WNE6579/ and MonotaRO /p/7013/0576/ by strict host/product ID.
- Strip advertising queries only for those two exact product URLs for new Wish cards; preserve other stores.
- Add host-limited safe diagnostics and conservative same-item DOM stock checks.
- No change to application ID, signing, GitBuild workflows or large retailer extraction.


## 0.1.122 (versionCode 123) - independent-shop price and purchase evidence
- Canonical base: 0.1.121 source.zip only. No changes to keystore, applicationId or workflows.
- Fumuroya product detail and Gojo Chobei Katsuo Gobou: strict H1-bounded tax-included JPY price HTML and rendered DOM recovery; do not accept recommendations or shipping.
- Fumuroya: price WebView runs before its stock WebView to avoid concurrent detached renderers; new site-only quantity/cart diagnostics and read-only purchase evaluation.
- JR Central M.M.Factory size-specific product: independent strict SKU, product title, selected size and enabled purchase-control probe with per-card diagnostics.
- Hiraki color 99: broaden real clickable cart-action recognition (including JavaScript-backed controls); preserve the item stock-row and enabled quantity prerequisites.
- ASKUL: additional body/DOM purchase hints and counts for card-specific diagnostics; missing evidence remains UNKNOWN.
- Gojo Chobei stock parser untouched; MonotaRO and UNIQLO working sources unchanged.
- Tests: Java syntax 100/100, four generated JS programs parse, 22 mocked stock cases, two price DOM cases, build preparation verification. Android Gradle and device runtime NOT verified.

## 0.1.158 (versionCode 159)
- ZOZO only: the selected, product-scoped goodsDetailId state now checks `availabilityStatus` alongside existing stock fields. Only explicit, recognized positive enum strings (including `IN_STOCK_NORMAL`) count as in stock; unrecognized/numeric values remain UNKNOWN; explicit negative records veto purchase availability. Same-product and exact-`did` matching remain mandatory.
- ZOZO only: bounded diagnostics `didStateAvailabilityPositive`, `didStateAvailabilityNegative`, `didStateAvailabilityUnknown`, `didStateAvailabilityValues` (short enum strings only) help identify remaining missing mappings.
- ASKUL and ZOZO product-name success, MUJI/ASKUL stock and prices, other dedicated merchants, signature, existing data and workflow unchanged.

## 0.1.163 (versionCode 164) - GENERAL read-only, item-bound extraction
- Only 0.1.162 (163) is the source baseline; fixed signing certificate, package ID, Gradle AndroidX and GitHub Actions kept.
- SHEIN and AliExpress GENERAL item URLs: rendered WebView now reads bounded exact-ID state (`runParams.data` / product-intro/detail), JPY price and product-bound image URLs; it refuses mismatched IDs, conflicting prices, non-JPY values and obvious banners. No inventory inference or cart clicks.
- New/general stores with strong product-looking paths: a separate, read-only WebView can save only Product JSON-LD with an exact matching saved item URL and JPY offer; unrelated products and generic social banners are not trusted as proof.
- UNKNOWN stock remains UNKNOWN. Names, pricing and image failures are independent. Previous user-selected photos are immutable. Host-only diagnostics show why DOM evidence was refused without recording query parameters/tokens.
- Offline Java + Node fixtures cover positive/negative currency, product-ID and gallery cases. Passing does NOT assert real-storefront or Android APK build success.


## v0.1.164 (versionCode 165) -- GENERAL marketplace exact-item recovery

Base: BookmarkLauncher_0.1.163_source.zip (SHA256 1dbd2642feca5f5ab3688ca230de58d814379b125779f8a2c315111bbfbc2a38).

- When a GENERAL SHEIN or AliExpress card contains a verified item ID, always retry
  the SAVED item's URL for sequential price, stock and image WebViews instead of
  silently substituting the preliminary HTTP redirect destination.
- Guard HTTP metadata commits: a redirect to the storefront homepage, challenge
  path or different item ID cannot write a foreign title, price, image or stock
  to the saved card. Same-item redirects across verified subdomains remain valid.
- Add non-sensitive diagnostic reason flags: saved/resolved item matching,
  pricing WebView route, same-item navigation rejection, hydration selection,
  script result, body readiness and timeout. No raw product query or page text.
- Keep existing protected ZOZO, ASKUL, Joshin, Honma, Amazon, Rakuten, Yahoo!
  acquisition parsers unchanged; no saved acquisition modes are modified.
- Add scripts/check-marketplace-route.py (10 Java behavior cases + 7 wiring
  assertions) to existing CI regression entrypoint. Other existing tests remain.

Verification: source-only Java tests, DOM fixture tests, regression harness,
script invariants and archive checksum checks. No Android APK build or actual
SHEIN/AliExpress device results were executed in this environment; successful
real-site retrieval remains unverified.


## 0.1.168 (versionCode 169) - GENERAL marketplace landing-page recovery
- Sole base is BookmarkLauncher_0.1.167_source.zip, SHA256 cccb533802bec654155594543c6c18e86a72cc46becbc5a3406803254f5149d9.
- SHEIN and AliExpress product HTTP redirects: after confirming same marketplace family, inspect the returned HTML before rejecting ID-less URLs. A rewritten/landing URL is never trusted unless it contains exactly one Product JSON-LD explicitly bound to the saved item. Different item IDs remain blocked.
- Guarded marketplace HTTP stock status stays UNKNOWN (do not promote store-wide cart controls); item-bound price, name, image remain separate.
- On a fully loaded unbound marketplace WebView, skip repeated identical inspections. SHEIN m.shein.com gets at most one jp.shein.com retry with identical saved product path/ID; data on alternate page must still match the saved item.
- GENERAL image WebView can investigate same-family UNKNOWN navigations, but accepts images only from an ID-bound hydrated record. User-chosen images and previous correctly saved images are preserved.
- Diagnostics include sanitized HTTP document evidence, stable DOM page kind and regional retry state; no raw HTML, URL query or image data in logs.
- Dedicated ZOZO/ASKUL/Joshin/Honma/MUJI/UNIQLO/Edion parsers, signing key, applicationId, workflow and data schema remain unchanged.
- Tests include a new page-evidence harness and unchanged existing Java/Node regression fixtures. Real storefront and APK build not verified in this environment.


v0.1.169: GENERAL SHEIN/AliExpress read-only single-WebView item snapshot for title, JPY price and item-scoped product images. Carries pageKind through combined JS and stops repeat analysis on stable landing. Unproven stock remains UNKNOWN. Specialist handlers unchanged.


## v0.1.171 (versionCode 172) — SHEIN exact-item price and inventory recovery
- Sole baseline: BookmarkLauncher_0.1.170_source.zip, SHA256 4ebf58cb247851c6f0d650dc730351e8a36ba848eb166cd6cf4e12e67df95dfd.
- SHEIN-only read-only single-WebView extraction of a labeled current yen price or a nonambiguous item-region active price; requires exact saved item ID and local product heading. Different items, unrelated prices, promotion widgets and conflicting values remain rejected.
- Same-document stock uses exact-item-bound JSON-LD offer availability or ONE enabled item-local Add-to-Cart control. Header cart, unrelated recommended product controls and missing evidence cannot prove availability. No cart clicks.
- New database stock method checks original URL, GENERAL mode, current UNKNOWN and site OK with atomic SQL condition; edits and confirmed stock are preserved.
- Diagnostic event `price.webview.shein.fields` reports identity, price evidence / yen token counts, scoped purchase evidence and reasons without raw page content or item prices.
- Java-exported real JS fixture tests added to existing GitHub Actions source regression suite; dedicated merchants and fixed signing unchanged.
- Does not establish real-device success, live SHEIN response or full Android APK build (SDK not available here).


## 0.1.172 (versionCode 173) — isolated GENERAL marketplaces
- Keep the verified SHEIN product price path and wait up to four same-document
  inspections when its title/gallery/stock is still pending (never use header cart).
- Add exact Temu item-ID routing for `-g-ID.html` and `goods.html?goods_id=ID`,
  with an independent rendered DOM / item-bound Product JSON-LD snapshot.
- Add AliExpress item-bound rendered DOM fallback while keeping existing
  AliExpress hydrated/JSON-LD recovery; extend exact item URL recognition.
- Commit AliExpress/Temu availability only from exact Product JSON-LD offers;
  unknown or conflicting pages remain UNKNOWN. No unrelated store parsers changed.
- Offline Java/JavaScript identity, price, image, stock and dispatch regressions
  are run before the GitHub Actions Gradle build. No live-store success claimed.


## 0.1.177 (versionCode 178) — URL-bound storefront retries and separate item proof
- Sole base 0.1.176. GU price WebView mounted behind opaque Wishlist UI because detached GU price DOM callbacks timed out on device. All successful dedicated stores left unchanged.
- LOHACO: recognize a single item-main product action across H2 layout boundaries, retaining exact URL/H1 and displayed JPY price requirements. Availability reflects the rendered default delivery region; no automatic checkout.
- Mercari: dedicated, read-only current listing status from an exactly matching ID-bearing embedded item state (name+price+explicit status required) instead of trusting unbound article/body text when H1 is absent. Recommendation trees excluded.
- AliExpress and Temu: bounded one-time retry on a second official URL carrying exactly the SAME numeric item ID only after an empty stable document; no generic storefront price adoption and no repeated retries.
- Identity/route and mocked JavaScript fixture tests are source-only. These changes are not claimed to fix authentication/challenge blocks or prove live store success until device diagnostics confirm.

### 0.1.185 — numbered verification / source-adapter safeguards
- Numbered 008–039 methods are labelled `TRIAL-` until a single fresh card update verifies its unedited product name, saved/verified image and dedicated positive/negative stock state. The verified number is persisted without changing existing IDs. The crawler's general availability flag can no longer qualify a dedicated stock technique.
- The numbered one-document WebView scan now invokes the genuine existing read-only native stock script on its own supported URL for Hiraki, Fumuroya, JR Central, Honma, ASKUL, Yuican, GU, EDION, AU, Isetan, ZOZO and Mercari (where supported). Other merchant sites continue to use portable guarded templates, separately identified as `portable-pattern`; this is **not** a claim that every original site-specific scraper can be transplanted verbatim.
- Automatically appended slots 040+ can reserve numbers, but are not interpreted as stock-confirming until a concrete runtime engine is implemented. `PENDING-*` and `no-portable-executor` fail closed; proof-only labels must never fabricate a stock outcome.
- Correct existing source-key aliases for root-domain ZOZO and GU, Honma Store, Yuican and Green Beans, avoiding further duplicate `DEDICATED-*` registrations.
- GU logs `colorCandidates`, `sizeCandidates`, `selectedControls`, `variantEvidence` to identify missing SKU-selection binding. No CTA-only false in-stock promotion.
- v0.1.184 serialized/persisted manual refresh queue, same-site consecutive lock, and disabled refresh buttons during single/batch refresh remain unchanged.
- SHEIN/Temu/AliExpress server-side challenges or missing item-bound evidence still yield UNKNOWN; no speculative price/stock changes.


## 0.1.186 (187) - Temu / AliExpress on-device diagnostics repair

- After the Oct 25 00:46 Nothing A001 logs: retry Temu with official `https://www.temu.com/goods.html?goods_id=<saved numeric ID>` rather than a fabricated `/-g-<ID>.html` URL. Same-item URL verification and field identity checks remain mandatory.
- AliExpress only: request Japan/JPY via the standard storefront locale cookie **before the WebView loads**, continuing once even if cookie setup is unavailable. Never convert USD or accept unbound offers. Log an offer currency category for diagnosis.
- Mark a confirmed Temu/AliExpress merchant verification challenge (HTML or rendered WebView) as `ACCESS_RESTRICTED` instead of retaining the HTTP-200 site-reachable state; leave price/title/image/stock untouched.
- Dedicated guarded marketplace code only. Existing successful shop engines, stored mode, signing and database remain unchanged.
- These are attempted recovery measures. A merchant challenge or a response without item-specific data may still yield unknown fields. No live-marketplace success claim until device validation.
