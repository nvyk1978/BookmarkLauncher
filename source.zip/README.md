# BookmarkLauncher 0.1.2

Androidのホームランチャーに近い操作感でブックマークを管理するための初期プロジェクト。

## 初期仕様
- アプリ名: BookmarkLauncher
- applicationId: `com.cmyk.bookmarkslauncher`
- version: `0.1.2 (3)`
- minSdk 29 / targetSdk 36 / compileSdk 36
- ホーム: 5列 × 8行のCellLayout型グリッド
- フォルダ展開内: 4列 × 5行グリッド
- フォルダは別画面へ遷移せずPopupWindow内で展開
- フォルダ内フォルダ対応の土台あり
- ブックマーク/フォルダ: 1x1 / 2x1 / 1x2 / 2x2
- Pixel Launcher / AOSP Launcher3を正本にした長押しドラッグ
- 空きセルへ自由配置、中心重ねでフォルダ化、外周ホバー650msでreorder
- Android共有（text/plain）からURLを受け取りブックマーク化
- 登録日時 / 最終アクセス日時 / スクリーンショットパス / オフライン保存パスをDB保持

## Chrome同期を後付けするためのDB設計
`nodes` はアプリ内UUID `id` と別に `external_source` / `external_id` を持つ。
Chromeなど外部ブックマークと紐付けても、アプリ固有の表示サイズ・スクリーンショット・オフライン情報を独立維持できる。
削除は `deleted_at` を使うsoft delete設計。

## 未実装（次段階）
- WebViewでページタイトル/favicon取得
- ページトップの自動スクリーンショット生成
- MHTML等によるオフライン保存
- スクリーンショットを2x2タイル背景として表示
- フォルダアイコンの中身プレビュー
- Chrome/Google同期ブリッジ

## ビルド
GitHub Actions `.github/workflows/build.yml` を使用。
AGP 9.4.0 / Gradle 9.6.0 / JDK 17。
固定keystoreを同梱しているため、このプロジェクトからの継続ビルドは上書きインストール可能。
