# BookmarkLauncher 0.1.13

Androidホームランチャーの操作感を正本にしたブックマーク管理アプリ。

## 現行仕様
- applicationId: `com.cmyk.bookmarkslauncher`
- version: `0.1.13 (14)`
- minSdk 29 / targetSdk 36 / compileSdk 36
- ホームは5列×8行のCellLayout型グリッド
- ホーム最上段の初期値として5×1検索窓を配置。検索窓も長押しドラッグで移動でき、下中央の×へドロップして削除可能
- 検索窓を削除した場合、ホーム空欄長押しの「検索窓を追加」から再追加可能
- 検索は表示名・サイト名・ページタイトル・URLを対象
- フォルダ内は4列×5行。アイコンとテキストエリアはホームと同じ物理サイズ
- 長押しドラッグで空きセルへ自由配置、外周は650msでreorder。周囲アイコンは約180msで滑らかにスライドして空きセルを作る
- 既存フォルダ上で約650msホバーするとドロップ前に展開し、親→子→孫へ同一ドラッグを継続可能
- ドラッグ開始後に生成されたフォルダパネルも、root側ドラッグコーディネータでホバー・ドロップを追跡
- フォルダへ入ってから外へ出るとその階層だけ格納。子を出た後は親を残し、親へ再入場→再退出で親を格納
- フォルダは元アイコン位置から拡大展開し、閉じる時は逆方向へ格納
- フォルダダイアログ自体は常に不透明。子・孫が重なっている間だけ背面フォルダの不透明背景色を段階的に暗くし、擬似alpha風に黒へ近づける。アイコン／文字は常に不透明
- フォルダ欄内タップでは閉じず、欄外タップで最前面フォルダのみ格納
- フォルダ名タップでリネーム、名前欄長押しでダイアログを一時移動（位置は保存しない）
- フォルダが1件以下になった場合は自動解体し、残存1件を親階層へ繰り上げ
- フォルダ詳細の「中身を保護」はデフォルトON。ONでフォルダだけ削除、OFFで配下を再帰削除
- ブックマーク長押しで詳細ダイアログ。サイト名・1:1サムネイル・URL・ブックマーク日時・最終アクセス・オフライン状態を表示
- サムネイルタップでページトップスクショ・favicon・site name・page titleを同時再取得
- 撮影用WebViewは画面外で描画し、取得中はNライトグレーのシークサークルのみ表示
- ブックマークアイコンはNダークグレーの大きな円＋大きなfavicon。favicon未取得時のみ汎用ブックマーク記号
- フォルダアイコンは大型円＋最大4件プレビュー。子フォルダはfavicon風表示ではなくフォルダ絵
- アイコン長押し中は画面上部中央（従来位置から25dp下）に黒丸＋Nレッドの×削除ターゲット
- Android共有（text/plain）からURLを受け取りブックマーク化し、メタデータ／サムネイル取得を開始

## Chrome同期を後付けするためのDB設計
`nodes` はアプリ内UUID `id` と別に `external_source` / `external_id` を保持。
Chrome等の外部ブックマーク同期を後付けしても、セル位置・表示情報・スクリーンショット・オフライン情報を独立維持できる。
削除は `deleted_at` を使うsoft delete。

## 今後
- MHTML等によるオフライン保存／更新／削除
- Chrome/Google同期ブリッジ

## ビルド
GitHub Actions `.github/workflows/build.yml` を使用。
AGP 9.4.0 / Gradle 9.6.0 / JDK 17。
固定keystore同梱のため継続ビルドは上書きインストール可能。


## 0.1.10 (11)
- Central drag coordinator at the root ViewGroup for reliable folder IN/OUT detection.
- Only the topmost folder can exit-close; after a child closes the parent must be re-entered before it can close.
- Folder panel surfaces stay opaque; only geometrically overlapped background regions are progressively darkened.
- Search bar visual height reduced to 50% of its 5x1 row; outside taps clear focus and hide the IME immediately.
- Delete target moved to top-center.
- More vertical room for two-line icon labels; home/folder tiles share the same metrics.
- Favicons keep their original silhouette/aspect ratio instead of circular clipping.


## 0.1.11 (12)
- Child-folder drag-out now quarantines the parent IN/OUT detector for 1 second.
- Parent close requires a real outside -> re-enter -> outside sequence after a child closes.
- Bookmark favicon reduced inside its dark-gray circle while preserving original aspect ratio.
- Folder circle uses N Light Gray (#656060).
- Folder dialog background uses N Gray (#454040).
- Search field uses N Light Gray (#656060).


## 0.1.12 (13)
- Bookmark/folder circle diameters stay unchanged; bookmark favicon now uses up to 80% of the circle diameter while preserving its original aspect ratio and silhouette.
- Delete target moved 25dp downward from its 0.1.11 top-center position.
- Activity uses IME adjustNothing so the home grid never shifts when the keyboard opens.
- If the search field would be covered by the IME, only the search field receives a temporary upward translation; closing the IME restores its exact grid position.
- Tapping outside the focused search field immediately clears focus, hides the keyboard, and restores any temporary IME translation.


## 0.1.13 (14)
- Favicon visual size is reduced to 80% of the 0.1.12 rendered size; bookmark/folder circle diameters are unchanged.
- Folder-preview favicons follow the same 80%-of-previous-size rule while preserving original aspect ratio and silhouette.
- Search field is slimmer (50% of row height, 30dp minimum) and visually inset 12dp on both sides while still occupying the full 5x1 grid row.
- Drag-source translucency is keyed by item ID at Activity level and survives folder exit/re-entry, panel refresh, and tile recreation until the drag session ends.
