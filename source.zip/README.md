# BookmarkLauncher 0.1.33

Androidホームランチャーの操作感を正本にしたブックマーク管理アプリ。

## 現行仕様
- applicationId: `com.cmyk.bookmarkslauncher`
- version: `0.1.33 (34)`
- minSdk 29 / targetSdk 36 / compileSdk 36
- ホームは5列×8行のCellLayout型グリッド
- ホーム初期値は4×1検索窓＋右隣1×1のNライトブルー丸＋。どちらも独立して長押しドラッグ移動でき、上部×へドロップして削除可能
- 検索窓／＋を削除した場合、ホーム空欄長押しからそれぞれ再追加可能
- 検索は表示名・サイト名・ページタイトル・URLを対象
- フォルダ内は4列×5行。アイコンとテキストエリアはホームと同じ物理サイズ
- 長押しドラッグで空きセルへ自由配置、外周は650msでreorder。周囲アイコンは約180msで滑らかにスライドして空きセルを作る
- 既存フォルダ上で約650msホバーするとドロップ前に展開し、親→子→孫へ同一ドラッグを継続可能
- ドラッグ開始後に生成されたフォルダパネルも、root側ドラッグコーディネータでホバー・ドロップを追跡
- フォルダへ入ってから外へ出るとその階層だけ格納。子を出た後は親を残し、親へ再入場→再退出で親を格納
- フォルダは元アイコン位置から拡大展開し、閉じる時は逆方向へ格納
- フォルダダイアログ自体は常に不透明。子・孫が重なっている間だけ背面フォルダの不透明背景色を段階的に暗くし、擬似alpha風に黒へ近づける。アイコン／文字は常に不透明
- フォルダ欄内タップでは閉じず、欄外タップで最前面フォルダのみ格納
- フォルダ名タップでリネーム、名前欄長押しでダイアログを一時移動（位置は保存しない）
- フォルダが1件以下になった場合は自動解体し、残存1件を親階層へ繰り上げ
- フォルダ詳細の「中身を保護」はデフォルトON。ONでフォルダだけ削除、OFFで配下を再帰削除
- ブックマーク長押しで詳細ダイアログ。サイト名・1:1サムネイル・URL・ブックマーク日時・最終アクセス・オフライン状態を表示
- サムネイルタップでページトップスクショ・favicon・site name・page titleを同時再取得
- 撮影用WebViewは画面外で描画し、取得中はNライトグレーのシークサークルのみ表示
- ブックマークアイコンはNダークグレー円＋縮小favicon。faviconは元形状・縦横比を維持し、未取得時のみ汎用ブックマーク記号
- フォルダアイコンはNブルーの処理描画ベクター形状＋最大4件プレビュー。子フォルダもフォルダ絵で表示
- アイコン長押し中は画面上部中央（初期基準から合計40dp下）に黒丸＋Nレッドの×削除ターゲット
- Android共有（text/plain）からURLを受け取りブックマーク化し、メタデータ／サムネイル取得を開始

## Chrome同期を後付けするためのDB設計
`nodes` はアプリ内UUID `id` と別に `external_source` / `external_id` を保持。
Chrome等の外部ブックマーク同期を後付けしても、セル位置・表示情報・スクリーンショット・オフライン情報を独立維持できる。
削除は `deleted_at` を使うsoft delete。

## 今後
- MHTML等によるオフライン保存／更新／削除
- Chrome/Google同期ブリッジ

## ビルド
GitHub Actions `.github/workflows/build.yml` を使用。
AGP 9.4.0 / Gradle 9.6.0 / JDK 17。
固定keystore同梱のため継続ビルドは上書きインストール可能。


## 0.1.10 (11)
- Central drag coordinator at the root ViewGroup for reliable folder IN/OUT detection.
- Only the topmost folder can exit-close; after a child closes the parent must be re-entered before it can close.
- Folder panel surfaces stay opaque; only geometrically overlapped background regions are progressively darkened.
- Search bar visual height reduced to 50% of its 5x1 row; outside taps clear focus and hide the IME immediately.
- Delete target moved to top-center.
- More vertical room for two-line icon labels; home/folder tiles share the same metrics.
- Favicons keep their original silhouette/aspect ratio instead of circular clipping.


## 0.1.11 (12)
- Child-folder drag-out now quarantines the parent IN/OUT detector for 1 second.
- Parent close requires a real outside -> re-enter -> outside sequence after a child closes.
- Bookmark favicon reduced inside its dark-gray circle while preserving original aspect ratio.
- Folder circle uses N Light Gray (#656060).
- Folder dialog background uses N Gray (#454040).
- Search field uses N Light Gray (#656060).


## 0.1.12 (13)
- Bookmark/folder circle diameters stay unchanged; bookmark favicon now uses up to 80% of the circle diameter while preserving its original aspect ratio and silhouette.
- Delete target moved 25dp downward from its 0.1.11 top-center position.
- Activity uses IME adjustNothing so the home grid never shifts when the keyboard opens.
- If the search field would be covered by the IME, only the search field receives a temporary upward translation; closing the IME restores its exact grid position.
- Tapping outside the focused search field immediately clears focus, hides the keyboard, and restores any temporary IME translation.


## 0.1.14 (15)
- 検索窓を4×1へ変更し、さらに細身化・左右余白を追加。
- 検索窓右側に1×1のNライトブルー丸＋を追加。URL直接入力からブックマーク追加でき、取得処理でtitle / site name / favicon / screenshotを更新。
- 検索窓と＋は独立して長押しドラッグ移動・上部×へドロップ削除可能。空欄長押しから再追加可能。
- 検索窓は長押し移動時はドラッグ、移動しない長押しでは標準のコピー／切り取り／貼り付け／全選択／範囲選択を利用可能。不要なSearch項目のみ抑制。
- faviconを0.1.13からさらに80%へ縮小。サークルサイズは維持し、元の縦横比・形状を維持。
- フォルダアイコンをNブルーの処理描画ベクター形状へ変更。子フォルダもフォルダ絵で表示。
- BookmarkLauncher題字をNホワイト＋GitBuild/PriceRec系のlight sans題字へ統一。
- 削除×をさらに15dp下げ、初期位置から合計40dp下へ。
- フォルダダイアログ重なり暗化を双方のroundRectでクリップし、重なり部分でも角丸を維持。

## 0.1.13 (14)
- Favicon visual size is reduced to 80% of the 0.1.12 rendered size; bookmark/folder circle diameters are unchanged.
- Folder-preview favicons follow the same 80%-of-previous-size rule while preserving original aspect ratio and silhouette.
- Search field is slimmer (50% of row height, 30dp minimum) and visually inset 12dp on both sides while still occupying the full 5x1 grid row.
- Drag-source translucency is keyed by item ID at Activity level and survives folder exit/re-entry, panel refresh, and tile recreation until the drag session ends.


## 0.1.15
- Home folders restored to the launcher-style N-light-gray circle with up to four child previews.
- Folder tiles shown inside folders use the N-blue vector folder silhouette.
- Home-folder circular drop hit area restored; nested-folder vector hit area retained.
- applicationId and stable signing key unchanged.


## 0.1.17
- Home folder remains the N-light-gray circular preview folder.
- Nested folder tiles use a dark-gray circle with the shared N-blue vector folder silhouette.
- Mini nested-folder previews now reuse the exact same vector path instead of the legacy mini glyph.
- Up to four home-folder preview items are enlarged and clipped by the outer folder circle when necessary.


## 0.1.17 changes
- Child-folder vector glyphs use N Light Blue (#445577).
- When a parent folder is expanded, child folders use the same full Home folder tile (circle + up to four previews) instead of the compact nested-folder glyph.
- The four preview positions inside a Home folder circle are spread farther outward while retaining circular clipping.


## 0.1.18 (19)
- Search field hint changed to `ブックマーク検索`; a vector clear button appears at the right while text exists.
- Search 4x1 and URL-add 1x1 widgets are visually raised to align with normal icon height while retaining their original grid occupancy.
- Drag occupancy previews for search and URL-add are rounded rectangles matching 4x1 / 1x1 cells.
- Dropping onto a folder only stores the item; folder expansion occurs only after the existing 650 ms drag hover.
- Bookmark creation from Share or direct URL continues to auto-fetch favicon, top-page screenshot, site name, and page title.

## 0.1.19 (20)
- 検索結果をフォルダと同じNグレー角丸パネル＋4列アイコングリッドで表示。
- ブックマーク詳細の左下に「削除」「コピー」を並べ、コピーはNライトブルーでホームへ別UUID複製。
- 画面回転を禁止し、Activityをportrait固定。
- ホーム空欄長押しメニューを大きな角丸Nグレー面＋背景なし白文字の縦メニューへ変更し、「エクスプローラ」を追加。
- エクスプローラはBookmarkLauncher内の論理的なホーム／フォルダ構成だけを辿る入口として実装。
- NDialog背景をNグレー (#454040) に統一し、通常ボタンはNライトブルー (#445577) のカプセル型へ統一。
- ホーム／展開フォルダのフォルダ円をNライトブルー (#445577) に統一。


## 0.1.20 (21)
- ドラッグ中、アイコン外周を掠めた時に並び替え候補へ入りやすいよう、ドラッグ専用の外周ヒット領域を少し拡大。
- 中央のフォルダ作成／フォルダ格納判定も一段だけ拡大し、重なる場合は中央フォルダ判定を優先。
- ブックマーク表示名は custom name → page title → site name → legacy title/URL の順で決定。
- Android共有時は EXTRA_SUBJECT を初期タイトル候補として使い、WebView取得後は実ページタイトルを優先表示。


## 0.1.21 (22)
- 題字「BookmarkLauncher」のTypefaceをN Standardと同じデフォルトsansへ統一。
- 名前変更はNダイアログを使用し、既存名を開いた時点で全文選択。
- 空欄長押しの「エクスプローラ」をN Standard由来のNエクスプローラUIへ置換。対象はホームをルートにしたBookmarkLauncher内フォルダ階層のみ。
- 空欄長押しメニューの表記を `(＋URL追加)を追加` に訂正し、その下に「アプリを追加」を追加。
- 端末の起動可能アプリ一覧から、アプリアイコン＋アプリ名のショートカットをホームへ追加可能。タップで対象アプリを起動。
- BookmarkLauncherがバックグラウンドへ移ると、展開中のフォルダパネルを全て閉じ、復帰時は通常ホームから再開。


## 0.1.22 (23)
- App picker: search field under title, ListView recycling + scaled lazy icon loading for crash/memory mitigation.
- App picker: long-press multi-select, green check, selection count, batch add.
- Home empty-cell long-press menu: NS-style diagnostic log at bottom.
- Diagnostic log records app-picker query/icon/errors and uncaught exceptions.
- N Explorer buttons aligned to current NS visual component.

## 0.1.23 (24)
- BookmarkLauncher title uses the same 25sp bold default sans treatment as GitBuild.
- Version name is displayed directly under the title in the same 12sp N-white style as GitBuild.
- Search field keeps its existing grid position/order but is always rendered above bookmark/folder tiles when IME translation causes overlap.
- Drag graze hit halo expanded from 6dp to 10dp.
- Folder-create / move-into-folder merge hit region expanded outward by 4dp without changing icon visuals.

## 0.1.29 (30)
- Google Maps URL (`maps.app.goo.gl`, `goo.gl/maps`, `google.* /maps`) を専用判定。
- Google Mapsブックマークは通常faviconの代わりに、Nレッド `#441100` のピン型VectorDrawableを表示。フォルダ内プレビューも同じピン表示。
- Google Mapsの短縮URLはWebViewで展開後、`/place/<店名>/` → 画面のh1/og:title → page title → 共有テキストの順で店舗・施設名を取得。
- Google Mapsのfavicon取得は行わず、専用ベクター表示を固定。

## 0.1.30 (31)
- Google Mapsのページタイトル／OGタイトルから郵便番号・都道府県以下など住所部分を除外し、屋号・施設名を優先して表示。
- Google Mapsの画面h1を最優先候補にし、URLの `/place/<name>/`、通常タイトル、共有タイトルへフォールバック。
- 撮影用WebViewでmain-frameエラー、`chrome-error://`、アクセス不可系タイトルを検出した場合はエラーページをスクリーンショットとして保存しない。既存サムネイルがある場合は維持。
- `intent://` 等へ遷移した場合はブラウザ用HTTPSフォールバックを使い、WebViewのアクセス不可画面化を抑制。
- Google Maps専用ピンをNライトレッド `#662211` に変更。

## 0.1.31 (32)
- Google Maps短縮URLはWebViewより先にHTTPリダイレクトを追跡し、`intent://` を含む場合はブラウザ用HTTPS URLへ復帰して最終Maps URLを確定。
- 最終URLから `/place/<name>/`、`@lat,lng`、`!3dlat!4dlng`、座標クエリを解析し、屋号と緯度経度を取得。
- 緯度経度が取れた場合はOpenStreetMapの地図タイルを端末側で合成し、Nライトレッドの中心ピン＋帰属表示付き512px正方形の静的地図サムネイルを生成。WebViewスクショ失敗時もこの静的地図を使用。
- 座標または地図タイルを取得できない場合のみ、従来のWebViewスクリーンショット取得へフォールバック。
- Google Maps用ピンアイコンはNライトレッド `#662211` を維持し、表示サイズを0.1.30比80%へ縮小。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.32 (33)
- Google Maps静的地図の座標抽出順を修正。`!8m2!3dlat!4dlng` のPOI座標を最優先、その他の `!3dlat!4dlng` は最後の有効ペアを採用。
- `@lat,lng` と `center` / `ll` は地図の表示中心になり得るため、短縮URL展開直後には使わず、WebViewで最終URLまで到達してもPOI座標が取れない場合だけ最終フォールバックとして使用。
- WebView到達後は `rel=canonical` / `og:url` も一度確認し、そこにPOI座標があれば表示中心より優先。
- Google Mapsタイトルが `〒住所 … 階 屋号` の並びでも、住所・階数部分を除いて後半の屋号／施設名を抽出。全角数字にも対応。
- Mapsページのタイトル取得はh1だけで確定せず、専用h1・main h1・OG title・Twitter title・document.titleを順に候補化し、住所だけの候補を除外。
- 診断ログへ静的地図生成に使った座標と precise / viewport fallback の別を記録。
- applicationId `com.cmyk.bookmarkslauncher` と固定署名を維持。


## 0.1.33 (34)
- Google Maps静的地図の座標決定を見直し、`@lat,lng` と一般の `!3d..!4d..` は使用しない。
- Maps画面から住所を取得し、Android Geocoderで座標化する経路を最優先。明確なPOI `!8m2!3d..!4d..` のみフォールバックとして使用。
- Mapsの共有タイトルはEXTRA_SUBJECTを無加工で採用せず、屋号抽出を必ず通す。住所＋屋号形式や階数直後の屋号にも対応。
- Google Maps取得成功時は屋号をtitle/page_titleへ反映し、詳細ダイアログの題字・ページタイトル・サムネイルを再取得直後に更新。
