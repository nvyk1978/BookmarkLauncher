# ECサイトの購入・カート導線調査（2026-10-20）

**公式40 URLにアクセスし、34ページの公開本文を閲覧**（6ページは本文取得不可：モノタロウ、ハンズ、Target、Walmart、Etsy、Home Depot）。国内外の公式商品ページまたは購入案内を対象とした。下表の文言は公式公開表示、公式ガイド、または検索結果で見られた表記例を含み、全40サイトの画面・ログイン後の動作や実際の購入操作まで検証した意味ではない。ショップによって購入ボタンは商品・在庫・ログイン・地域・サイズ選択で変わる。

判定語句は「追加・購入（ADD）」と「閲覧・決済へ進む（VIEW/CHECKOUT）」に分離。カート閲覧しか購入導線がないサイトもあるが、ビュー導線のみでは**そのSKUが現在購入可能という証拠にはならない**。商品と紐づく在庫・商品選択・数量・操作の有効状態が確認できた場合だけ購入可否の根拠とする。語句一覧は無条件にAVAILABLEへ格上げするルールではない。

| No. | 地域 | ECサイト | 確認した文言 | 分類 | 公式ページ |
|---:|---|---|---|---|---|
| 1 | 日本 | アスクル | カゴへ／カゴに入れる | ADD | [出典](https://www.askul.co.jp/p/WNE6579/) |
| 2 | 日本 | 無印良品 | カートに入れる／カートを見る | ADD + VIEW | [出典](https://www.muji.com/jp/ja/store/cmdty/detail/4550512865773) |
| 3 | 日本 | ユニクロ | カートに入れる | ADD | [出典](https://www.uniqlo.com/jp/ja/products/E463386-000/00?colorDisplayCode=09&sizeDisplayCode=002) |
| 4 | 日本 | ビックカメラ | カートに入れる | ADD | [出典](https://www.biccamera.com/bc/item/15234485/) |
| 5 | 日本 | LOHACO | カートに入れる／カートを見る | ADD + VIEW | [出典](https://lohaco.yahoo.co.jp/help/order/) |
| 6 | 日本 | モノタロウ | バスケットに入れる | 検索上の表記例（この回は本文取得不可） | [出典](https://www.monotaro.com/p/7410/5597/) |
| 7 | 日本 | ヨドバシ.com | ショッピングカートに入れる | ADD | [出典](https://www.yodobashi.com/product/100000001006092311/) |
| 8 | 日本 | 楽天市場（出店店） | 買い物かごに入れる／ご注文手続きへ | ADD + VIEW | [出典](https://www.rakuten.ne.jp/gold/whatnot/guide/first-shopping.html) |
| 9 | 日本 | IKEA Japan | カートに追加／ショッピングカートを開く | ADD + VIEW | [出典](https://www.ikea.com/jp/ja/customer-service/shopping-at-ikea/online-store-pub8679c890/) |
| 10 | 日本 | ハンズ | カートに入れる | 検索上の表記例（この回は本文取得不可） | [出典](https://hands.net/goods/4901681104512/) |
| 11 | 日本 | コーナンeショップ | カートに入れる／購入手続きへ | ADD + VIEW | [出典](https://www.kohnan-eshop.com/shop/pages/uketori_s.aspx) |
| 12 | 日本 | ニトリ | カートに入れる | ADD | [出典](https://www.nitori-net.jp/ec/product/2118100010046s/) |
| 13 | 米国 | Sephora | Add to Basket | ADD | [出典](https://www.sephora.com/product/next-big-thing-perfume-sampler-set-w-redeemable-voucher-P517221?skuId=2893550) |
| 14 | 米国 | Best Buy | Add to cart | ADD | [出典](https://www.bestbuy.com/site/searchpage.jsp?browsedCategory=cat00000&id=pcat17071&st=categoryid%24cat00000) |
| 15 | 米国 | Lowe’s | Add to Cart | ADD | [出典](https://www.lowes.com/pd/Pd-Home-Bohemian-Style-Wooden-Bead-and-Jute-Rope-Tassel-Hanging-Garland-Boho/7859037) |
| 16 | 米国 | H&M | Add to bag | ADD | [出典](https://www2.hm.com/en_us/productpage.1328350001.html) |
| 17 | 米国 | adidas | Add to bag | ADD | [出典](https://www.adidas.com/us/black-adidas_by_stella_mccartney-zipper-travel) |
| 18 | 英国 | Decathlon UK | Add to basket | ADD | [出典](https://www.decathlon.co.uk/p/k500-kids-portable-basketball-hoop-with-adjustable-stand-1-30m-to-1-60m/176071/c344m8734294) |
| 19 | 英国 | Argos | Add to Trolley／view items in trolley | ADD + VIEW | [出典](https://www.argos.co.uk/static/StaticDisplay/includeName/HowToUseTheSite.htm%235) |
| 20 | 米国 | LEGO | Add to Bag | ADD | [出典](https://www.lego.com/en-us/product/21179) |
| 21 | 米国 | Newegg | Add to cart／Buy now | ADD | [出典](https://www.newegg.com/p/1VK-02DD-00001) |
| 22 | 米国 | Chewy | Add to Cart | ADD | [出典](https://www.chewy.com/b/food-332) |
| 23 | 米国 | B&H Photo | Add to Cart | ADD | [出典](https://www.bhphotovideo.com/c/product/1333872-REG/case_logic_ibir115_black_ibira_backpack_black.html) |
| 24 | 米国 | Nordstrom | Add to Bag | ADD | [出典](https://www.nordstrom.com/s/le-roudoudou-patent-leather-shoulder-bag/8894166) |
| 25 | 米国 | Macy’s | Add To Bag | ADD | [出典](https://www.macys.com/shop/product/livabliss-brunswick-bwk-2323-rug-collection?ID=22328717) |
| 26 | 米国 | Crate & Barrel | Add to Cart／Checkout Now | ADD + VIEW | [出典](https://www.crateandbarrel.com/customer-service/faqs) |
| 27 | 米国 | Anthropologie | Add to Basket | ADD | [出典](https://www.anthropologie.com/shop/kaxi-cherry-gingham-hair-bow) |
| 28 | 英国 | The Body Shop | Add to bag／Checkout | ADD + VIEW | [出典](https://www.thebodyshop.com/products/oval-bamboo-pin-hairbrush) |
| 29 | 英国 | Marks & Spencer | Add to bag | ADD | [出典](https://www.marksandspencer.com/je/ida-lace-non-wired-bralette-set-a-e/p/DS2bb82a513b150f7896892d79019d5e7d.html) |
| 30 | 英国 | Tesco | Add（商品カードの短縮表記） | SITE-ONLY | [出典](https://www.tesco.com/groceries/en-GB/products/321044872) |
| 31 | 米国 | Wayfair | Add to Cart／Adding...／Added to Cart! | ADD + STATE | [出典](https://www.wayfair.com/furniture/pdp/astoria-grand-traditional-queen-bed-with-ornate-carved-details-and-bun-feet-w119207374.html) |
| 32 | 米国 | Target | Add to cart | 検索上の表記例（この回は本文取得不可） | [出典](https://www.target.com/p/unique-bargains-oxford-cloth-double-drawstrings-storage-bag-black/-/A-92958907) |
| 33 | 米国 | Walmart | Add to cart | 検索上の表記例（この回は本文取得不可） | [出典](https://www.walmart.com/ip/Finest-Alloy-Bridge-Pickup-Covers-Protectors-Set-For-Replacement-Parts-Golden/1855034916) |
| 34 | 米国 | Etsy | Add to cart | 検索上の表記例（この回は本文取得不可） | [出典](https://www.etsy.com/listing/1903049337/handmade-tulip-friendship-bracelet) |
| 35 | 米国 | Apple Store | Buy（単独語・対象機種の選択へ進むため汎用判定不可） | REVIEW | [出典](https://www.apple.com/shop/buy-iphone) |
| 36 | 米国 | Google Store | 対象商品を選択する導線（汎用購入語句を確認できず） | REVIEW | [出典](https://store.google.com/us/category/phones) |
| 37 | 米国 | IKEA US | カテゴリ商品の追加導線（商品ごとの確定語句は未検証） | REVIEW | [出典](https://www.ikea.com/us/en/cat/sofas-fu003/) |
| 38 | 米国 | Samsung US | Buy（商品・色・容量の選択が必要） | REVIEW | [出典](https://www.samsung.com/us/smartphones/galaxy-s26-ultra/buy/) |
| 39 | 米国 | Home Depot | Add to Cart（本文取得不可、参考） | REVIEW | [出典](https://www.homedepot.com/p/DEWALT-20V-MAX-Cordless-Drill-Driver-Kit-DCD771C2/204279858) |
| 40 | 米国 | Zara US | 商品一覧（個々の購入操作の確認は未完了） | REVIEW | [出典](https://www.zara.com/us/en/woman-dresses-l1066.html) |
## 今回追加・拡張した主な購入表記

- 日本語：`カゴへ`、`かごへ`、`カゴに入れる`、`買い物かごに入れる`、`お買い物かごに追加`、`カートに入れる`、`ショッピングカートに入れる`、`カートに追加`、`バスケットに入れる`、`バッグに入れる`、`今すぐ購入`、`購入する`、`注文する`。
- 英語：`Add to Cart`、`Add to Bag`、`Add to Basket`、`Add to Trolley`、`Buy Now`、`Buy it now`。
- 購入手続き導線として別扱い：`カートを見る`、`カゴを見る`、`買い物かごを確認`、`購入手続きへ`、`レジへ`、`View Cart`、`View Basket`、`View Trolley`、`Checkout`、`Proceed to Checkout`。
- **除外・保留**：単独 `Add` / `Buy`、`Added to Cart!`（過去の状態メッセージ）、ヘッダーのカートアイコン、関連商品・おすすめ商品の購入ボタン、在庫なし・無効ボタン。商品固有の操作と証明できないため。

アスクルWNE6579については `在庫：あり`・商品番号・数量と `カゴへ`/`カゴに入れる` の結び付けを改善。ただし実機0.1.135では UNKNOWN、0.1.136の実機検証は未実施。

調査結果を一般サイト向けの保守的な購入語句に反映し、成功済みのヒラキ・鉄板工房を使う共通補助関数は前版と同一に保った。
