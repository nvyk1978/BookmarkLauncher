package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Exact, host-bound GENERAL product identity for ASKUL and MonotaRO only. */
public final class GeneralRetailIdentity {
    private GeneralRetailIdentity() { }
    private static final Pattern ASKUL = Pattern.compile("^/p/([a-z0-9_-]{5,20})/?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONOTARO = Pattern.compile("^/p/([0-9]{4})/([0-9]{4})/?$");

    public static String store(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())) return null;
        String h = url.getHost().toLowerCase(Locale.ROOT);
        if (h.equals("askul.co.jp") || h.equals("www.askul.co.jp"))
            return ASKUL.matcher(url.getPath()).matches() ? "ASKUL" : null;
        if (h.equals("monotaro.com") || h.equals("www.monotaro.com"))
            return MONOTARO.matcher(url.getPath()).matches() ? "MONOTARO" : null;
        return null;
    }

    public static String itemId(URL url) {
        String s = store(url);
        if ("ASKUL".equals(s)) {
            Matcher m = ASKUL.matcher(url.getPath());
            return m.matches() ? m.group(1).toUpperCase(Locale.ROOT) : null;
        }
        if ("MONOTARO".equals(s)) {
            Matcher m = MONOTARO.matcher(url.getPath());
            return m.matches() ? m.group(1) + m.group(2) : null;
        }
        return null;
    }

    /** Strip ads only for a proven product-detail URL. All other URLs are untouched. */
    public static String canonical(String raw) {
        if (raw == null) return null;
        try {
            URL url = new URL(raw.trim());
            String store = store(url);
            if (store == null) return raw.trim();
            String code = itemId(url);
            if ("ASKUL".equals(store)) return "https://www.askul.co.jp/p/" + code + "/";
            return "https://www.monotaro.com/p/" + code.substring(0,4) + "/" + code.substring(4) + "/";
        } catch (Exception ignored) { return raw.trim(); }
    }

    public static boolean storeFromText(String raw) {
        try { return store(new URL(raw)) != null; }
        catch (Exception ignored) { return false; }
    }

    public static boolean sameProduct(URL a, URL b) {
        String storeA = store(a);
        return storeA != null && storeA.equals(store(b))
                && itemId(a).equals(itemId(b));
    }
}
