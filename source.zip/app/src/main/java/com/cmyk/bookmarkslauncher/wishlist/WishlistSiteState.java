package com.cmyk.bookmarkslauncher.wishlist;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Independent, conservative site/page-reachability annotation. Never touches product availability. */
public final class WishlistSiteState {
    public static final String OK = "OK";
    public static final String CHECKING = "CHECKING";
    public static final String MAINTENANCE = "MAINTENANCE";
    public static final String PAGE_MISSING = "PAGE_MISSING";
    public static final String ACCESS_RESTRICTED = "ACCESS_RESTRICTED";
    public static final String CONNECT_FAILED = "CONNECT_FAILED";
    public static final String TIMEOUT = "TIMEOUT";
    public static final String TEMPORARY_ERROR = "TEMPORARY_ERROR";
    private static final Pattern MAINTENANCE_MESSAGE = Pattern.compile(
            "(?:メンテナンス(?:中|を実施中|のため)|ただいま準備中|一時休業中|under maintenance|maintenance mode|scheduled maintenance|temporarily down for maintenance)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern HEADING = Pattern.compile(
            "(?is)<(?:title|h1|h2)\\b[^>]*>(.*?)</(?:title|h1|h2)\\s*>");
    private WishlistSiteState() { }

    public static String classify(int httpCode, String html) {
        if (httpCode == 404 || httpCode == 410) return PAGE_MISSING;
        if (httpCode == 401 || httpCode == 403 || httpCode == 429) return ACCESS_RESTRICTED;
        if (explicitMaintenance(html, httpCode)) return MAINTENANCE;
        if (httpCode >= 500 || httpCode >= 400) return TEMPORARY_ERROR;
        return OK;
    }

    private static boolean explicitMaintenance(String html, int httpCode) {
        if (html == null || html.isEmpty()) return false;
        Matcher m = MAINTENANCE_MESSAGE.matcher(html);
        if (!m.find()) return false;
        // A sale page's "maintenance information" in its footer is not a maintenance page.
        if (httpCode == 503) return true;
        Matcher heading = HEADING.matcher(html);
        while (heading.find()) {
            String plain = heading.group(1).replaceAll("(?s)<[^>]+>", " ").toLowerCase(Locale.ROOT);
            if (MAINTENANCE_MESSAGE.matcher(plain).find()) return true;
        }
        String text = html.replaceAll("(?is)<script\\b[^>]*>.*?</script>", " ")
                .replaceAll("(?is)<style\\b[^>]*>.*?</style>", " ")
                .replaceAll("(?s)<[^>]*>", " ").replaceAll("\\s+", " ").trim();
        return text.length() < 550
                && (text.matches("(?is)^\\s*(?:現在|ただいま|只今)?\\s*(?:サイト)?メンテナンス中.*")
                    || (MAINTENANCE_MESSAGE.matcher(text).find()
                        && text.matches("(?is).*(?:ご利用いただけません|ご利用できません|service unavailable|temporarily unavailable).*")));
    }

    public static String label(String state) {
        if (CHECKING.equals(state)) return "商品情報を確認中";
        if (MAINTENANCE.equals(state)) return "メンテナンス中";
        if (PAGE_MISSING.equals(state)) return "商品ページ削除の可能性";
        if (ACCESS_RESTRICTED.equals(state)) return "アクセス制限中";
        if (CONNECT_FAILED.equals(state)) return "サイトに接続できません";
        if (TIMEOUT.equals(state)) return "接続タイムアウト";
        if (TEMPORARY_ERROR.equals(state)) return "一時的な接続障害";
        return null;
    }
}
