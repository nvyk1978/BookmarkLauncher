package com.cmyk.bookmarkslauncher.wishlist;

/** Tight GENERAL-only DOM purchase checks for the three still-unresolved stores.
 * Never reads product image/name/price, never clicks or submits a form. */
final class WishlistRemainingStockDom {
    private WishlistRemainingStockDom() { }
    static String javascript(String host) {
        if (host.equals("yuican-shop.com")) return yuican();
        if (host.equals("e-mono.jr-central.co.jp")) return jr();
        return "(function(){return 'UNKNOWN';})()";
    }
    private static String yuican() {
        return "(function(){try{"+
            "var id=new URLSearchParams(location.search).get('product_id');if(!/^\\d+$/.test(id||''))return 'UNKNOWN';"+
            "var form=document.getElementById('product_form_'+id)||document.querySelector('form[name=product_form_'+id+']');"+
            "if(!form)return 'UNKNOWN';"+
            "var own=form.querySelector('[name=\\\"product_data['+id+'][amount]\\\"],[name=\\\"product_data['+id+'][product_id]\\\"]');"+
            "if(!own)return 'UNKNOWN';"+
            "var buy=form.querySelector('button[name*=checkout],button[type=submit],input[type=submit]');"+
            "if(!buy||buy.disabled||buy.getAttribute('aria-disabled')==='true'||!buy.getClientRects().length)return 'UNKNOWN';"+
            "var action=(buy.getAttribute('name')||'')+' '+(buy.value||'')+' '+(buy.innerText||'');"+
            "if(!/(?:checkout.add|カートに入れる|add.to.cart|購入する)/i.test(action))return 'UNKNOWN';"+
            "var sold=form.querySelector('.ty-control-group__item .ty-error-text,.ty-product-block__out-of-stock');"+
            "if(sold&&sold.getClientRects().length)return 'UNKNOWN';"+
            "return 'AVAILABLE';}catch(e){return 'UNKNOWN';}})()";
    }
    private static String jr() {
        return "(function(){try{"+
            "var sku=location.pathname.match(/\\/shop\\/g\\/g([a-z0-9_-]+)\\/?$/i);if(!sku)return 'UNKNOWN';"+
            "var forms=document.querySelectorAll('main form,#main form,.item-detail form');"+
            "var good=0;for(var i=0;i<forms.length&&i<35;i++){var form=forms[i];"+
            "if(!new RegExp(sku[1],'i').test(form.outerHTML.slice(0,20000)))continue;"+
            "var selects=form.querySelectorAll('select[required]');var valid=true;"+
            "for(var j=0;j<selects.length;j++)if(!selects[j].value||selects[j].selectedIndex<0)valid=false;"+
            "if(!valid)continue;var buy=form.querySelector('button[type=submit],input[type=submit],button[name*=cart]');"+
            "if(!buy||buy.disabled||buy.getAttribute('aria-disabled')==='true'||!buy.getClientRects().length)continue;"+
            "var label=(buy.innerText||'')+' '+(buy.value||'')+' '+(buy.name||'');"+
            "if(!/(?:カートに入れる|購入する|add.to.cart)/i.test(label))continue;good++;}"+
            "return good===1?'AVAILABLE':'UNKNOWN';}catch(e){return 'UNKNOWN';}})()";
    }
}
