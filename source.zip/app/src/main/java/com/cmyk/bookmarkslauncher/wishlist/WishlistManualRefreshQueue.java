package com.cmyk.bookmarkslauncher.wishlist;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/** UI-thread queue of user-requested single-card refreshes. A successful refresh
 * must finish its complete nested fetch pipeline before another card can start.
 * Do not schedule the same host immediately after itself, even after relaunch. */
public final class WishlistManualRefreshQueue {
    private final ArrayList<String> pending = new ArrayList<>();
    private String lastHost = "";

    public boolean enqueue(String id) {
        if (id == null || id.isEmpty() || pending.contains(id)) return false;
        pending.add(id);
        return true;
    }
    public boolean contains(String id) { return pending.contains(id); }
    public boolean remove(String id) { return pending.remove(id); }
    public List<String> pending() { return new ArrayList<>(pending); }
    public String lastHost() { return lastHost; }
    public void setLastHost(String host) { lastHost = host == null ? "" : host; }
    public String next(Function<String,String> hostForId) {
        for (String id : pending) {
            String host = hostForId.apply(id);
            if (host != null && !host.isEmpty() && !host.equals(lastHost)) return id;
        }
        return null;
    }
    public void prioritize(String id) {
        if (pending.remove(id)) pending.add(0, id);
    }
}
