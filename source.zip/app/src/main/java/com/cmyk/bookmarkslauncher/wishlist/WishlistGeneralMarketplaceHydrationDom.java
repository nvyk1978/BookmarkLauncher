package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;

/** Read-only, exact-item hydrated data for GENERAL AliExpress/SHEIN products.
 * Never clicks, requests private APIs, or promotes inventory from generic UI.
 * Results are untrusted unless the saved item ID is present in the data object. */
final class WishlistGeneralMarketplaceHydrationDom {
    private WishlistGeneralMarketplaceHydrationDom() { }

    static String javascript(URL saved) {
        final String id = WishlistGeneralMarketplaceIdentity.itemId(saved);
        if (id == null) return "'{}'";
        String host = saved.getHost().toLowerCase(Locale.ROOT);
        return SCRIPT.replace("__ITEM_ID__", id)
                .replace("__SHEIN__", String.valueOf(host.equals("shein.com") || host.endsWith(".shein.com")));
    }

    private static final String SCRIPT = """
(function(){'use strict';
const expected='__ITEM_ID__',shein=__SHEIN__;
const result={value:'',currency:'',images:[],source:'none',reason:'data-missing',ready:document.readyState||'unknown',blocked:false,bodyChars:0};
try{
 const h=location.hostname.toLowerCase();
 const family=shein?(h==='shein.com'||h.endsWith('.shein.com')):(h==='aliexpress.com'||h.endsWith('.aliexpress.com'));
 const m=shein?location.pathname.match(/(?:^|[-/])p-([0-9]{5,15})\\.html$/i):location.pathname.match(/^\\/(?:item|i)\\/([0-9]{9,19})\\.html$/i);
 if(!family||!m||m[1]!==expected){result.reason='item-url-mismatch';return JSON.stringify(result);}
 const text=String(document.body&&(document.body.innerText||document.body.textContent)||'');
 result.bodyChars=text.length;
 result.blocked=/(?:captcha|robot check|access denied|verify you are human|unusual traffic|安全検証|アクセスが制限)/i.test(text.slice(0,3500));
 if(result.blocked){result.reason='challenge-visible';return JSON.stringify(result);}
 const idMatches=v=>v!=null&&String(v).trim()===expected;
 const ownId=o=>{if(!o||typeof o!=='object')return false;
   return [o.goods_id,o.goodsId,o.productId,o.product_id,o.itemId,o.item_id,
           o.actionModule&&o.actionModule.productId].some(idMatches);
 };
 const images=[],seen=new Set();
 const addImage=v=>{if(images.length>=8||!v)return;
   if(typeof v==='object') {addImage(v.url||v.src||v.imageUrl||v.imagePath||v.contentUrl||v.originUrl||v.goods_img);return;}
   if(typeof v!=='string')return;
   try{const u=new URL(v,location.href);
    if(u.protocol!=='https:'||/(?:logo|banner|sprite|avatar|icon|promo|campaign|tracking|placeholder|spacer|payment|favicon|noimage)/i.test(u.pathname))return;
    if(/\\.(?:svg|gif)(?:$|[?#])/i.test(u.pathname)||!/(?:\\.(?:jpe?g|png|webp|avif)(?:$|[?#])|\\/kf\\/|\\/images?\\/|ltwebstatic\\.com)/i.test(u.href))return;
    if(!seen.has(u.href)){seen.add(u.href);images.push(u.href);}
   }catch(_){} 
 };
 const addImages=v=>{if(Array.isArray(v)){for(const x of v.slice(0,10))addImage(x);} else addImage(v);};
 const validMoney=v=>{if(v==null)return '';
   if(typeof v==='object')return validMoney(v.amountWithSymbol||v.formattedAmount||v.formatedPrice||v.value||v.amount||'');
   const s=String(v).trim();
   if(s.length>80||!s||/(?:USD|EUR|GBP|\\$|€|£)/i.test(s))return '';
   return s;
 };
 const numeric=v=>{const s=validMoney(v);if(!s)return null;
   const v1=s.replace(/[¥￥,\\s円]/g,'');return /^\\d+(?:\\.0+)?$/.test(v1)?Number(v1):null;};
 const yen=s=>/¥|￥|円/.test(String(s||''));
 const currencyOf=o=>String(o&&typeof o==='object'?(o.currencyCode||o.currency||o.currency_code||o.currencyType||''):'').toUpperCase();
 const money=(v,c)=>{let s=validMoney(v);if(!s)return '';
   if(c!=='JPY'&&!yen(s))return '';
   if(/\\d+\\.\\d*[1-9]/.test(s))return ''; // no rounded FX guesses
   // Price ranges: only return if both bounds have yen/JPY evidence.
   const matches=s.match(/\\d[\\d,]*(?:\\.0+)?/g)||[];
   if(matches.length===1){const n=numeric(matches[0]);return n!=null&&n>=1&&n<=100000000?'¥'+Math.trunc(n):'';}
   if(matches.length===2&&/(?:~|～|〜|\\s-\\s|から)/.test(s)){
     const a=numeric(matches[0]),b=numeric(matches[1]);
     return a!=null&&b!=null&&a>=1&&a<=b&&b<=100000000?'¥'+a+'～¥'+b:'';
   }
   return '';
 };
 const chooseAli=o=>{const pm=o.priceModule||{},cm=o.currencyModule||{};
   const currency=currencyOf(cm)||currencyOf(pm)||currencyOf(o);
   const m=pm.formatedActivityPrice||pm.formatedPrice||pm.formattedActivityPrice||pm.formattedPrice;
   let price=money(m,currency);
   if(!price&&currency==='JPY'){
     const low=numeric(pm.minAmount&&pm.minAmount.value),high=numeric(pm.maxAmount&&pm.maxAmount.value);
     if(low!=null&&low>=1&&low<=100000000&&high!=null&&high>=low&&high<=100000000)
       price=low===high?'¥'+low:'¥'+low+'～¥'+high;
   }
   result.value=price;result.currency=price?'JPY':'';
   const im=o.imageModule||{};
   addImages(im.imagePathList||im.imageUrlList||im.imageList);
 };
 const chooseShein=o=>{
   let currency=currencyOf(o)||currencyOf(o.salePrice)||currencyOf(o.retailPrice);
   let price=money(o.salePrice&& (o.salePrice.amountWithSymbol||o.salePrice.amount),currency);
   if(!price)price=money(o.salePrice||o.sale_price||o.shopPrice,currency);
   result.value=price;result.currency=price?'JPY':'';
   addImages(o.goods_img);addImages(o.goodsImg);addImages(o.goods_imgs);addImages(o.imageList);
   addImages(o.productImages);addImages(o.mainImage);addImages(o.images);
 };
 const picks=[];
 function walk(root,source){
   if(!root||typeof root!=='object')return;
   const stack=[[root,0]],visited=new Set();let count=0;
   while(stack.length&&count++<650){const [o,depth]=stack.pop();
    if(!o||typeof o!=='object'||visited.has(o)||depth>7)continue;visited.add(o);
    if(ownId(o)){picks.push({o,source});if(picks.length>=8)return;}
    if(Array.isArray(o)){for(const x of o.slice(0,16))if(x&&typeof x==='object')stack.push([x,depth+1]);continue;}
    // Never infer the product from recommendation collections or unrelated widgets.
    for(const [k,v] of Object.entries(o).slice(0,70)){
     if(/(?:recommend|related|search|similar|suggest|category|tracking|adverts|popular|review)/i.test(k))continue;
     if(v&&typeof v==='object')stack.push([v,depth+1]);
    }
   }
 }
 if(!shein){const rp=window.runParams;
  if(rp&&typeof rp==='object')walk(rp.data||rp,'runParams');
 }else{
  for(const [key,obj] of [['productIntroData',window.productIntroData],['gbProductDetail',window.gbProductDetail],['INITIAL_STATE',window.__INITIAL_STATE__]])
   if(obj&&typeof obj==='object')walk(obj,key);
 }
 // JSON-only script states. Never eval script source, interpret arbitrary JS, or fetch an API.
 if(!picks.length){for(const tag of [...document.querySelectorAll('script[type="application/json"],script#__NEXT_DATA__')].slice(0,12)){
   try{const raw=tag.textContent||'';if(raw.length>3000000)continue;walk(JSON.parse(raw),'json-script');}catch(_){}}
 }
 if(!picks.length){result.reason='id-unverified';return JSON.stringify(result);}
 // Multiple state snapshots of the SAME ID are common (intro + detail).
 // Merge only matching-ID records, refuse contradictory exact prices.
 const prices=new Set();let found=0;
 for(const p of picks){
  const o=p.o;
  if(shein&&!(o.salePrice||o.sale_price||o.shopPrice||o.goods_img||o.goods_imgs||o.imageList))continue;
  if(!shein&&!(o.priceModule||o.imageModule))continue;
  if(!found)result.source=p.source;
  found++;
  if(shein)chooseShein(o);else chooseAli(o);
  if(result.value)prices.add(result.value);
 }
 if(!found){result.reason='product-pending';return JSON.stringify(result);}
 result.value=prices.size===1?[...prices][0]:'';
 result.currency=result.value?'JPY':'';
 result.images=images;
 result.reason=prices.size>1?'contradictory-prices':result.value?'bound-price':images.length?'bound-images':'bound-item-empty';
 return JSON.stringify(result);
}catch(_){result.reason='script-error';return JSON.stringify(result);}
})()
""";
}
