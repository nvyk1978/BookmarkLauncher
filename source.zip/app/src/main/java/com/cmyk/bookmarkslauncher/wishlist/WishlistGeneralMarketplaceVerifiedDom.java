package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;

/** Evidence-only title and JPY price fallback for exactly one saved marketplace item.
 * No network calls, no clicks, no unrelated product listings or unbound meta tags. */
final class WishlistGeneralMarketplaceVerifiedDom {
    private WishlistGeneralMarketplaceVerifiedDom() { }

    static String javascript(URL saved) {
        String id = WishlistGeneralMarketplaceIdentity.itemId(saved);
        if (id == null) return "'{}'";
        boolean shein = saved.getHost().toLowerCase(java.util.Locale.ROOT).endsWith("shein.com");
        return SCRIPT.replace("__ID__", id).replace("__SHEIN__", String.valueOf(shein));
    }

    private static final String SCRIPT = """
(function(){'use strict';
const expected='__ID__',shein=__SHEIN__;
const out={title:'',value:'',currency:'',reason:'item-unverified',source:'none',
  canonical:'missing',heading:false,productNodes:0,pageKind:'uninspected',ready:document.readyState||'unknown',bodyChars:0};
try {
 const family=h=>shein?(h==='shein.com'||h.endsWith('.shein.com')):(h==='aliexpress.com'||h.endsWith('.aliexpress.com'));
 const idOf=u=>{try{const v=new URL(u,location.href);
   if(v.protocol!=='https:'||!family(v.hostname.toLowerCase()))return '';
   const m=shein?v.pathname.match(/(?:^|[-/])p-([0-9]{5,15})\\.html$/i):v.pathname.match(/^\\/(?:item|i)\\/([0-9]{9,19})\\.html$/i);
   return m?m[1]:'';
 }catch(_){return '';}};
 const locationId=idOf(location.href);
 out.pageKind=locationId===expected?'item-url':locationId?'other-item-url':'unbound-url';
 if(locationId&&locationId!==expected){out.reason='navigation-other-item';return JSON.stringify(out);}
 // Missing item ID in the URL is not a mismatch. It still forbids
 // selector-only guesses; require an explicitly item-bound JSON-LD record.
 const text=String(document.body&&(document.body.innerText||document.body.textContent)||'');out.bodyChars=text.length;
 if(/(?:captcha|robot check|access denied|verify you are human|unusual traffic|安全検証)/i.test(text.slice(0,3500))){
   out.reason='challenge-visible';return JSON.stringify(out);}
 const canon=document.querySelector('link[rel="canonical"]');
 const canonical=canon&&(canon.href||canon.getAttribute('href'));
 if(canonical){const ci=idOf(canonical);out.canonical=ci===expected?'same-item':ci?'other-item':'non-item';
   if(ci&&ci!==expected){out.reason='canonical-other-item';return JSON.stringify(out);}}
 // A canonical without a product ID is not evidence of a different product.
 const goodTitle=s=>{s=String(s||'').replace(/\\s+/g,' ').trim();
   return s.length>=4&&s.length<=240&&!/(?:^(?:home|homepage|shein|aliexpress|sign in|login|shopping cart)$|cookie policy|privacy policy|robot check|404|ページが見つかりません)/i.test(s)?s:'';};
 // Only consume product JSON-LD explicitly bound by its URL or @id to this item.
 let products=[];
 function walk(o,depth){if(!o||typeof o!=='object'||depth>5||products.length>=24)return;
   if(Array.isArray(o)){for(const x of o.slice(0,35))walk(x,depth+1);return;}
   const ty=String(o['@type']||'').toLowerCase();
   if(ty==='product'||ty.endsWith('/product'))products.push(o);
   for(const k of ['@graph','mainEntity','item'])if(o[k])walk(o[k],depth+1);
 }
 for(const el of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,25)){
   try{const s=el.textContent||'';if(s.length<1500000)walk(JSON.parse(s),0);}catch(_){}
 }
 out.productNodes=products.length;
 const names=new Set(),prices=new Set();
 const money=(raw,cur)=>{
  if(raw==null||typeof raw==='object')return '';
  const s=String(raw).trim();if(s.length>55||/(?:USD|EUR|GBP|\\$|€|£)/i.test(s))return '';
  if(cur!=='JPY'&&!/[¥￥円]/.test(s))return '';
  if(!/^(?:[¥￥]\\s*)?\\d[\\d,]*(?:\\.0+)?\\s*円?$/.test(s))return '';
  const n=Number(s.replace(/[¥￥,円\\s]/g,''));return Number.isInteger(n)&&n>=1&&n<=100000000?'¥'+n:'';
 };
 for(const p of products){
  const urls=[p.url,p['@id'],p.mainEntityOfPage].map(v=>typeof v==='object'&&v?(v['@id']||v.url):v);
  if(!urls.some(u=>u&&idOf(u)===expected))continue;
  const n=goodTitle(p.name);if(n)names.add(n);
  const offer=Array.isArray(p.offers)?p.offers:p.offers?[p.offers]:[];
  for(const v of offer){if(!v||typeof v!=='object')continue;
    const cur=String(v.priceCurrency||'').toUpperCase();
    const result=money(v.price,cur);
    if(result)prices.add(result);
  }
 }
 if(names.size===1){out.title=[...names][0];out.source='url-bound-jsonld';}
 if(prices.size===1){out.value=[...prices][0];out.currency='JPY';}
 if(out.title||out.value)out.pageKind='item-bound-jsonld';
 // Saved product URL plus a product-specific H1 and an
 // actual detail container is required for a rendered DOM title/price.
 // An explicit other-item canonical is already rejected; a generic/non-item
 // canonical does NOT invalidate separately item-bound JSON-LD evidence.
 // Never promote a generic site heading or site-wide OG title.
 const detail=document.querySelector(shein?
   '[class*="product-intro"],[class*="product-detail"],[class*="goods-detail"],[class*="productIntro"]':
   '#root [class*="product-detail"],#root [class*="product-title"],#product-detail,[class*="productDetail"]');
 const heading=document.querySelector(shein?
   '[class*="product-intro"] h1,[class*="product-detail"] h1,[class*="productIntro"] h1,h1[class*="product"]':
   '[class*="product-title"] h1,h1[class*="product"],#product-detail h1');
 out.heading=!!heading;
 if(!out.title&&locationId===expected&&out.canonical!=='non-item'
   &&detail&&heading&&(!detail.contains||detail.contains(heading))){
   const n=goodTitle(heading.textContent);if(n){out.title=n;out.source='canonical-bound-dom';}
 }
 if(!out.value&&out.title&&locationId===expected&&out.canonical!=='non-item'&&detail){
  // A priced text node must be inside the same verified product detail region.
  const sels=shein?['[class*="sale-price"]','[class*="salePrice"]','[class*="product-price"]','[class*="price-current"]']:
    ['[class*="product-price"]','[class*="uniform-banner-box-price"]','[class*="price--current"]'];
  for(const sel of sels){for(const el of [...detail.querySelectorAll(sel)].slice(0,5)){
    if(el.closest('[class*="recommend"],[class*="related"],[class*="original"],[class*="old-price"]'))continue;
    const v=money(el.textContent||'', '');
    if(v){out.value=v;out.currency='JPY';break;}
  }if(out.value)break;}
 }
 out.reason=out.title||out.value?'verified-product-metadata':
   locationId!==expected?'unbound-navigation':'product-data-unverified';
 return JSON.stringify(out);
}catch(_){out.reason='script-error';return JSON.stringify(out);}
})()
""";
}
