package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Locates the requested product in general-shop JSON-LD. Identity resolution
 * is shared infrastructure, not a new shop mode or a name/price parser.
 * It never selects the first related Product solely due to document order.
 */
final class WishlistGenericJsonLdProduct {
    private static final Pattern SCRIPT = Pattern.compile("(?is)<script\\b([^>]*)>(.*?)</script\\s*>");
    private WishlistGenericJsonLdProduct() { }

    static JSONObject find(String html, URL page) {
        // Unknown storefront URLs can still identify a single Product through an
        // EXACT Product.url/@id match. The URL-only shortcut remains forbidden for
        // unknown routes; unrelated Product blocks cannot qualify.
        if (html == null || page == null || !WishlistCrawler.isAllowedUrl(page)) return null;
        List<JSONObject> products = new ArrayList<>();
        Matcher m = SCRIPT.matcher(html);
        while (m.find() && products.size() < 60) {
            if (!m.group(1).toLowerCase(Locale.ROOT).contains("application/ld+json")) continue;
            try {
                String json = m.group(2).trim().replaceAll("(?s)^<!--|-->$", "");
                Object node = json.startsWith("[") ? new JSONArray(json) : new JSONObject(json);
                collect(node, products, 0);
            } catch (Exception ignored) { }
        }
        JSONObject selected = null;
        int hits = 0;
        for (JSONObject product : products) {
            if (matches(product.opt("url"), page) || matches(product.opt("@id"), page)
                    || matches(product.opt("mainEntityOfPage"), page)) {
                selected = product;
                hits++;
            }
        }
        if (hits == 1) return selected;
        // One unlabelled product on an identified detail page is useful;
        // an explicitly different URL or multiple unverified products is not.
        if (WishlistCrawler.isSingleProductPage(page)
                && !WishlistGeneralMarketplaceIdentity.isGuarded(page)
                && hits == 0 && products.size() == 1) {
            JSONObject only = products.get(0);
            if (!only.has("url") && !only.has("@id") && !only.has("mainEntityOfPage"))
                return only;
        }
        return null;
    }

    private static void collect(Object node, List<JSONObject> dest, int depth) {
        if (depth > 10 || node == null || dest.size() >= 60) return;
        if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < Math.min(a.length(), 60); i++) collect(a.opt(i), dest, depth + 1);
        } else if (node instanceof JSONObject) {
            JSONObject j = (JSONObject) node;
            if (isProduct(j.opt("@type"))) dest.add(j);
            for (String k : new String[]{"@graph", "mainEntity", "itemListElement", "item", "about", "hasPart"})
                collect(j.opt(k), dest, depth + 1);
        }
    }

    private static boolean isProduct(Object value) {
        if (value instanceof JSONArray) {
            JSONArray a = (JSONArray) value;
            for (int i = 0; i < a.length(); i++) if (isProduct(a.opt(i))) return true;
        }
        if (value instanceof String) {
            String t = ((String) value).toLowerCase(Locale.ROOT);
            return t.equals("product") || t.endsWith("/product") || t.endsWith(":product");
        }
        return false;
    }

    private static boolean matches(Object value, URL page) {
        if (value instanceof JSONArray) {
            JSONArray a = (JSONArray) value;
            for (int i = 0; i < Math.min(a.length(), 12); i++) if (matches(a.opt(i), page)) return true;
        } else if (value instanceof JSONObject) {
            JSONObject j = (JSONObject) value;
            return matches(j.opt("url"), page) || matches(j.opt("@id"), page);
        } else if (value instanceof String) {
            try {
                URL other = new URL(page, (String) value);
                if (WishlistGeneralMarketplaceIdentity.isDetail(page))
                    return WishlistGeneralMarketplaceIdentity.sameItem(page, other);
                if (!host(other).equals(host(page))) return false;
                String a = other.getPath().replaceAll("/+$", "").toLowerCase(Locale.ROOT);
                String b = page.getPath().replaceAll("/+$", "").toLowerCase(Locale.ROOT);
                if (!a.equals(b)) return false;
                String key = null;
                for (String k : new String[]{"pid", "eci_product", "product_id"})
                    if (query(page, k) != null) { key = k; break; }
                if (key != null) {
                    String expected = query(page, key);
                    return expected.equalsIgnoreCase(query(other, key) == null ? "" : query(other, key));
                }
                return !a.isEmpty() && !a.equals("/index.php") && !a.equals("/");
            } catch (Exception ignored) { }
        }
        return false;
    }
    private static String host(URL url) {
        return url.getHost().toLowerCase(Locale.ROOT).replaceFirst("^www\\.", "");
    }
    private static String query(URL url, String key) {
        String q = url.getQuery();
        if (q == null) return null;
        Matcher m = Pattern.compile("(?i)(?:^|&)" + Pattern.quote(key)
                + "=([a-z0-9_-]+)(?:&|$)").matcher(q);
        return m.find() ? m.group(1) : null;
    }
}
