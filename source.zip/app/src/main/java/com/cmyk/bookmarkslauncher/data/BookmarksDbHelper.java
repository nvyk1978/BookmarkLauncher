package com.cmyk.bookmarkslauncher.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public final class BookmarksDbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "bookmarks_launcher.db";
    public static final int DB_VERSION = 4;

    public BookmarksDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE nodes (" +
                "id TEXT PRIMARY KEY," +
                "external_source TEXT," +
                "external_id TEXT," +
                "type INTEGER NOT NULL," +
                "parent_id TEXT," +
                "title TEXT NOT NULL," +
                "site_name TEXT," +
                "page_title TEXT," +
                "custom_name TEXT," +
                "url TEXT," +
                "phone_number TEXT," +
                "sort_index INTEGER NOT NULL DEFAULT 0," +
                "cell_x INTEGER NOT NULL DEFAULT -1," +
                "cell_y INTEGER NOT NULL DEFAULT -1," +
                "span_x INTEGER NOT NULL DEFAULT 1," +
                "span_y INTEGER NOT NULL DEFAULT 1," +
                "created_at INTEGER NOT NULL," +
                "updated_at INTEGER NOT NULL," +
                "last_accessed_at INTEGER," +
                "deleted_at INTEGER," +
                "favicon_path TEXT," +
                "screenshot_path TEXT," +
                "offline_path TEXT," +
                "offline_saved_at INTEGER" +
                ")");

        db.execSQL("CREATE INDEX idx_nodes_parent_sort ON nodes(parent_id, sort_index)");
        db.execSQL("CREATE UNIQUE INDEX idx_nodes_external ON nodes(external_source, external_id) " +
                "WHERE external_source IS NOT NULL AND external_id IS NOT NULL");

        db.execSQL("CREATE TABLE sync_state (" +
                "provider TEXT PRIMARY KEY," +
                "remote_cursor TEXT," +
                "last_sync_at INTEGER," +
                "metadata TEXT" +
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE nodes ADD COLUMN cell_x INTEGER NOT NULL DEFAULT -1");
            db.execSQL("ALTER TABLE nodes ADD COLUMN cell_y INTEGER NOT NULL DEFAULT -1");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE nodes ADD COLUMN site_name TEXT");
            db.execSQL("ALTER TABLE nodes ADD COLUMN page_title TEXT");
            db.execSQL("ALTER TABLE nodes ADD COLUMN custom_name TEXT");
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE nodes ADD COLUMN phone_number TEXT");
        }
    }
}
