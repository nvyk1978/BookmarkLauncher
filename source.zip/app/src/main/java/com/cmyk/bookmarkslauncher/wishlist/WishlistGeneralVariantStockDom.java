package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/**
 * Reusable G technique: match stock+cart inside the SAME visible variant row.
 * Existing ZOZO identity rules remain in the original proven adapter; the
 * row-scoped signal itself can now run on other verified GENERAL products.
 * No site mode is cloned, no UI is clicked and no network request is made.
 */
public final class WishlistGeneralVariantStockDom {
    private WishlistGeneralVariantStockDom() { }

    public static String source(URL url) {
        if (WishlistZozoVariantDom.supports(url)) {
            // Keep the established, site-verified enquiry-number and ?did
            // identity checks exactly as they were before this refactor.
            return WishlistZozoVariantDom.javascript(url);
        }
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())
                || !WishlistCrawler.isAllowedUrl(url)
                || MarketplaceIdentity.site(url) != MarketplaceIdentity.Site.OTHER
                || !(WishlistCrawler.isSingleProductPage(url)
                     || WishlistGeneralAlphabetDom.candidateUrl(url))) {
            return "JSON.stringify({status:'UNKNOWN',reason:'not-product'})";
        }
        String path = url.getPath().replaceAll("/+$", "");
        String item = WishlistGeneralProductIdentity.code(url);
        // A generic slug alone never establishes a product identity. If a
        // query contains an explicit variant identifier, match that exact row.
        String variant = "";
        String query = url.getQuery() == null ? "" : url.getQuery();
        java.util.regex.Matcher vm = java.util.regex.Pattern.compile(
                "(?i)(?:^|&)(?:did|variant_id|variant|sku_id)=([a-z0-9_-]{5,30})(?:&|$)")
                .matcher(query);
        if (vm.find()) variant = vm.group(1);
        return SCRIPT.replace("__HOST__", JSONObject.quote(url.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(path))
                .replace("__ITEM__", JSONObject.quote(item))
                .replace("__VARIANT__", JSONObject.quote(variant));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const r={status:'UNKNOWN',reason:'pending',product:false,idBound:false,
   variantBound:false,variants:0,liveCarts:0,stockPairs:0,didRequired:false};
 const done=()=>JSON.stringify(r);
 try {
  const host=__HOST__,path=__PATH__,item=__ITEM__,variant=__VARIANT__;
  r.didRequired=!!variant;
  if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host||
     location.pathname.replace(/\\/+$/,'').toLowerCase()!==path.toLowerCase()){
    r.reason='document-mismatch';return done();
  }
  if(!item){r.reason='unbound-product-slug';return done();}
  const main=document.querySelector('main,[role=main],#main,#contents,#content')||document.body;
  if(!main){r.reason='main-pending';return done();}
  const words=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ').trim();
  const visible=e=>{if(!e||e.disabled||e.hasAttribute('disabled')||e.getAttribute('aria-disabled')==='true')return false;
    for(let p=e;p;p=p.parentElement){if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return false;
      const s=getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||Number(s.opacity)===0)return false;}return true;};
  const excluded='header,nav,footer,aside,[class*=recommend],[class*=related],[class*=ranking],'+
    '[class*=carousel],[class*=pickup],[id*=recommend],[id*=related]';
  const titles=[...main.querySelectorAll('h1')].filter(x=>visible(x)&&!x.closest(excluded));
  if(titles.length!==1||words(titles[0]).length<3){r.reason='heading-unverified';return done();}
  r.product=true;
  const root=titles[0].closest('[itemtype*=Product],#productDetail,#product-detail,'+
    '.product-detail,.product_detail,.productDetail,.product-page,.item-detail')||main;
  if(!root.contains(titles[0])){r.reason='heading-unbound';return done();}
  // Unlike a site adapter, generic G accepts ONLY an on-page item label or a
  // strongly scoped data-product-id. It never assumes URL==page identity.
  const text=words(root).slice(0,15000),title=words(titles[0]);
  const at=text.indexOf(title);
  if(at<0){r.reason='heading-unbound';return done();}
  let local=text.slice(at,at+3500);
  const end=/(?:関連商品|おすすめ商品|この商品を見た|人気商品|他の商品|ランキング)/.exec(local);
  if(end&&end.index>100)local=local.slice(0,end.index);
  const claims=[...local.matchAll(/(?:商品番号|商品コード|品番|製品番号|お申込番号|注文番号|問い合わせ番号|SKU|JAN|型番)\\s*[:：#№]?\\s*([a-z0-9_-]{5,30})/ig)].slice(0,20);
  r.idBound=claims.some(c=>c[1].toLowerCase()===item.toLowerCase())||
    [...root.querySelectorAll('[data-product-id],[data-sku],[data-item-id]')].some(e=>
      visible(e)&&!e.closest(excluded)&&
      ['data-product-id','data-sku','data-item-id'].some(k=>String(e.getAttribute(k)||'').toLowerCase()===item.toLowerCase()));
  if(!r.idBound){r.reason='product-id-unverified';return done();}
  const add=/(?:カート|カゴ|かご|バッグ)\\s*(?:に|へ)?\\s*(?:入れる|追加)|add\\s*to\\s*(?:cart|bag|basket)/i;
  const positive=/(?:在庫\\s*[:：]?\\s*(?:あり|有り|残少|僅少)|残り\\s*[0-9]+\\s*(?:点|個)|残りわずか|in\\s*stock)/i;
  const negative=/(?:在庫\\s*[:：]?\\s*(?:なし|無し|切れ)|売り切れ|売切れ|完売|予約商品|予約受付|out\\s*of\\s*stock|sold\\s*out)/i;
  const cart=[...root.querySelectorAll('button,[role=button],a[href],input[type=submit]')]
    .filter(c=>visible(c)&&!c.closest(excluded)&&add.test([words(c),c.value,c.getAttribute('aria-label')].filter(Boolean).join(' ').slice(0,130)));
  r.liveCarts=cart.length;
  if(!cart.length){r.reason='no-variant-cart';return done();}
  for(const c of cart.slice(0,60)){
    let row=null;
    // Only a SMALL local variant row is admissible, never whole product text.
    for(let p=c.parentElement,k=0;p&&k<5&&root.contains(p);p=p.parentElement,k++){
      if(!visible(p))continue;
      const rowText=words(p);
      if(rowText.length>450)break;
      if(!positive.test(rowText)||negative.test(rowText))continue;
      const localCarts=[...p.querySelectorAll('button,[role=button],a[href],input[type=submit]')]
        .filter(x=>visible(x)&&add.test([words(x),x.value,x.getAttribute('aria-label')].filter(Boolean).join(' ').slice(0,130)));
      if(localCarts.length!==1||localCarts[0]!==c)continue;
      row=p;break;
    }
    if(!row)continue;
    r.variants++;
    if(variant){
      let bound=false;
      for(let x=c,k=0;x&&k<5&&root.contains(x);x=x.parentElement,k++){
        const ids=['data-did','data-detail-id','data-variant-id','data-sku','data-sku-id','href'];
        const attrs=ids.map(key=>x.getAttribute(key)||'').join(' ');
        if(new RegExp('(?:^|[^a-zA-Z0-9])'+variant+'(?:$|[^a-zA-Z0-9])','i').test(attrs)){bound=true;break;}
      }
      if(!bound)continue;
    }
    r.variantBound=true;
    r.stockPairs++;
  }
  if(r.stockPairs>0&&r.idBound&&r.variantBound){
    r.status='AVAILABLE';r.reason='bound-local-variant-stock-cart';
  }else r.reason=variant?'selected-variant-unverified':'variant-stock-unverified';
  return done();
 }catch(_){r.reason='dom-error';return done();}
})()
""";
}
