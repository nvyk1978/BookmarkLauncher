package com.cmyk.bookmarkslauncher.wishlist;

import android.content.Context;
import android.util.Log;
import com.cmyk.bookmarkslauncher.DiagLog;
import java.net.URL;
import java.util.Locale;

/** App-visible transport/DOM/image trace for the three isolated large retailers.
 * No full URLs, URL queries, notes, cookies, HTML, or user-defined titles are logged. */
public final class RetailDiagnostics {
    private static volatile Context app;
    private RetailDiagnostics() { }

    public static void install(Context context) {
        if (context != null) app = context.getApplicationContext();
    }

    public static boolean enabled(WishlistMode mode) {
        return mode == WishlistMode.UNIQLO || mode == WishlistMode.YODOBASHI
                || mode == WishlistMode.BICCAMERA;
    }

    public static void event(WishlistMode mode, String phase, String detail) {
        if (!enabled(mode)) return;
        String line = "RETAIL [" + mode.name() + "] " + safe(phase, 36)
                + " " + safe(detail, 300);
        Log.i("RetailDiag", line);
        Context context = app;
        if (context != null) DiagLog.write(context, line);
    }

    public static String host(String url) {
        if (url == null) return "none";
        try { return new URL(url).getHost().toLowerCase(Locale.ROOT); }
        catch (Exception ignored) { return "invalid"; }
    }

    public static String error(Throwable error) {
        return error == null ? "none" : error.getClass().getSimpleName();
    }

    private static String safe(String text, int max) {
        if (text == null) return "-";
        // Drop control characters and dangerous URLs rather than store secrets in the report.
        String s = text.replaceAll("https?://\\S+", "[URL]")
                .replace('\n', ' ').replace('\r', ' ');
        if (s.length() > max) s = s.substring(0, max);
        return s;
    }
}
