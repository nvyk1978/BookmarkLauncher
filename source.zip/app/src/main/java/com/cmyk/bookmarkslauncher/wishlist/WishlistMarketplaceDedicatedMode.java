package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;

/** Two isolated merchant engines within persisted GENERAL acquisition mode.
 * Routing from the ORIGINAL saved host; metadata still needs independently
 * proven same-item evidence before any database write. */
public enum WishlistMarketplaceDedicatedMode {
    NONE, TEMU, ALIEXPRESS;

    public static WishlistMarketplaceDedicatedMode fromSavedUrl(String raw) {
        try {
            URL url = new URL(raw);
            if (!"https".equalsIgnoreCase(url.getProtocol()) || url.getUserInfo() != null
                    || !WishlistCrawler.isAllowedUrl(url)) return NONE;
            WishlistGeneralMarketplaceIdentity.Merchant merchant =
                    WishlistGeneralMarketplaceIdentity.merchant(url);
            if (merchant == WishlistGeneralMarketplaceIdentity.Merchant.TEMU
                    && WishlistGeneralMarketplaceIdentity.isDetail(url)) return TEMU;
            if (merchant == WishlistGeneralMarketplaceIdentity.Merchant.ALIEXPRESS
                    && (WishlistGeneralMarketplaceIdentity.isDetail(url)
                        || isAliShortlink(url))) return ALIEXPRESS;
        } catch (Exception ignored) { }
        return NONE;
    }

    public String liveLabel() {
        return this == TEMU ? "Temu専用モード" : this == ALIEXPRESS
                ? "AliExpress専用モード" : "GENERALモード";
    }

    private static boolean isAliShortlink(URL u) {
        return "a.aliexpress.com".equalsIgnoreCase(u.getHost())
                && u.getPath().matches("^/_[a-zA-Z0-9_-]{3,90}/?$");
    }

    /** Trust the HTTPS shortener's one successful redirect as an item probe
     * target, never as proof of price, title, image or stock. Never use this
     * for a generic Ali URL or a redirect outside Ali's official host family. */
    public static boolean isAliResolvedShortItem(String saved, String resolved, int httpCode) {
        if (httpCode != 200 || saved == null || resolved == null) return false;
        try {
            URL shortUrl=new URL(saved), target=new URL(resolved);
            return isAliShortlink(shortUrl)
                    && "https".equalsIgnoreCase(shortUrl.getProtocol())
                    && "https".equalsIgnoreCase(target.getProtocol())
                    && shortUrl.getUserInfo()==null && target.getUserInfo()==null
                    && WishlistCrawler.isAllowedUrl(target)
                    && WishlistGeneralMarketplaceIdentity.merchant(target)
                        ==WishlistGeneralMarketplaceIdentity.Merchant.ALIEXPRESS
                    && WishlistGeneralMarketplaceIdentity.isDetail(target);
        } catch(Exception ignored) { return false; }
    }
}
