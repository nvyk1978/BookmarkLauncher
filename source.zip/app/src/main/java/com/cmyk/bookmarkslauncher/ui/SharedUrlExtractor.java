package com.cmyk.bookmarkslauncher.ui;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Extracts the first URL from ordinary store sharing text without changing plain URL input. */
public final class SharedUrlExtractor {
    private static final Pattern URL_PATTERN = Pattern.compile(
            "https?://[^\\s<>\\\"\'\\u300c\\u300d\\u300e\\u300f\\u3010\\u3011]+",
            Pattern.CASE_INSENSITIVE);

    private SharedUrlExtractor() {}

    public static String extractOrOriginal(String text) {
        if (text == null) return "";
        String original = text.trim();
        Matcher match = URL_PATTERN.matcher(original);
        while (match.find()) {
            String candidate = trimSentencePunctuation(match.group());
            if (candidate.isEmpty()) continue;
            // Do not turn a half-entered "https://" into a saved URL.
            int authorityStart = candidate.indexOf("://") + 3;
            if (authorityStart < 3 || authorityStart >= candidate.length()) continue;
            int authorityEnd = candidate.length();
            for (char separator : new char[]{'/', '?', '#'}) {
                int next = candidate.indexOf(separator, authorityStart);
                if (next >= 0 && next < authorityEnd) authorityEnd = next;
            }
            String authority = candidate.substring(authorityStart, authorityEnd);
            if (authority.isEmpty() || authority.indexOf('.') < 0 || authority.contains("@")) continue;
            return candidate;
        }
        return original;
    }

    private static String trimSentencePunctuation(String value) {
        int end = value.length();
        while (end > 0) {
            char c = value.charAt(end - 1);
            if (c == '.' || c == ',' || c == ';' || c == ':' || c == '!' || c == '?' ||
                    c == ')' || c == ']' || c == '}' || c == '\u3002' || c == '\u3001' ||
                    c == '\uff01' || c == '\uff1f' || c == '\uff0c' || c == '\uff09') {
                end--;
            } else {
                break;
            }
        }
        return value.substring(0, end);
    }
}
