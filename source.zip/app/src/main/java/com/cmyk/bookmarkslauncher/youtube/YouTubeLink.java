package com.cmyk.bookmarkslauncher.youtube;

import android.net.Uri;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** URL-only helpers for the isolated YouTube capture module. */
final class YouTubeLink {
    private static final Pattern VIDEO_ID = Pattern.compile("^[A-Za-z0-9_-]{6,32}$");

    private YouTubeLink() {}

    static boolean isYouTubeUrl(String url) {
        return extractVideoId(url) != null;
    }

    static String extractVideoId(String url) {
        if (url == null || url.isBlank()) return null;
        try {
            Uri uri = Uri.parse(url.trim());
            String host = uri.getHost();
            if (host == null) return null;
            host = host.toLowerCase(Locale.ROOT);
            if (host.startsWith("www.")) host = host.substring(4);

            String candidate = null;
            if ("youtu.be".equals(host)) {
                candidate = firstPathSegment(uri);
            } else if ("youtube.com".equals(host) || "m.youtube.com".equals(host)
                    || "music.youtube.com".equals(host) || "youtube-nocookie.com".equals(host)) {
                String path = uri.getPath() == null ? "" : uri.getPath();
                if ("/watch".equals(path) || "/watch/".equals(path)) {
                    candidate = uri.getQueryParameter("v");
                } else {
                    String[] parts = path.split("/");
                    for (int i = 0; i + 1 < parts.length; i++) {
                        if ("shorts".equals(parts[i]) || "embed".equals(parts[i]) || "live".equals(parts[i])) {
                            candidate = parts[i + 1];
                            break;
                        }
                    }
                }
            }
            return valid(candidate) ? candidate : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    static String canonicalWatchUrl(String videoId) {
        return "https://www.youtube.com/watch?v=" + videoId;
    }

    private static String firstPathSegment(Uri uri) {
        for (String segment : uri.getPathSegments()) {
            if (segment != null && !segment.isBlank()) return segment;
        }
        return null;
    }

    private static boolean valid(String value) {
        if (value == null) return false;
        Matcher matcher = VIDEO_ID.matcher(value.trim());
        return matcher.matches();
    }
}
