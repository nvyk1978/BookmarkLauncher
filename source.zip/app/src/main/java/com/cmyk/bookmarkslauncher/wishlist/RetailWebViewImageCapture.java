package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.View;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/** BICCAMERA only. Reads pixels already rendered by WebView, no separate CDN connection.
 * Never screenshots the whole page into the wishlist; only an exact product image
 * whose src belongs to the already identity-verified product DOM result. */
final class RetailWebViewImageCapture {
    interface Callback { void complete(byte[] jpeg); }
    private final WebView web;
    private final URL expected;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Callback callback;
    private final String sourceList;
    private boolean completed;
    private int attempts;

    private RetailWebViewImageCapture(WebView web, URL expected, List<String> sources, Callback callback) {
        this.web=web;this.expected=expected;this.callback=callback;
        JSONArray list=new JSONArray();
        for(String source:sources) if(source!=null && source.startsWith("https://"))list.put(source);
        this.sourceList=list.toString();
    }
    static void start(WebView web, URL expected, WishlistCrawler.Result result, Callback cb) {
        if(web==null||expected==null||result==null||result.imageUrl==null
                ||WishlistMode.forLargeRetailUrl(expected)!=WishlistMode.BICCAMERA){cb.complete(null);return;}
        List<String> candidates=new ArrayList<>();candidates.add(result.imageUrl);
        if(result.retailImageCandidates!=null)candidates.addAll(result.retailImageCandidates);
        RetailWebViewImageCapture capture=new RetailWebViewImageCapture(web,expected,candidates,cb);
        // A stalled JavaScript callback cannot keep an in-progress update alive.
        capture.main.postDelayed(()->capture.finish(null),4600);
        capture.tryImage();
    }
    private void trace(String phase,String detail){ RetailDiagnostics.event(WishlistMode.BICCAMERA,"webview.image."+phase,detail); }
    private boolean sameItem(){
        try { return WishlistMode.sameLargeRetailVariant(expected,new URL(web.getUrl())); }
        catch(Exception e){ return false; }
    }
    private void finish(byte[] bytes){
        if(completed)return;completed=true;
        trace("done", "bytes="+(bytes==null?0:bytes.length)+" attempts="+attempts);
        callback.complete(bytes);
    }
    private void again(String reason){
        trace("retry", "attempt="+attempts+" reason="+reason);
        if(attempts>=4)finish(null);
        else main.postDelayed(this::tryImage,540);
    }
    private void tryImage(){
        if(completed)return;
        if(!sameItem()){finish(null);return;}
        attempts++;
        // Only an already loaded IMG tied to one of the verified product image URLs
        // is eligible. DOM canvas works for CORS-enabled sources; if tainted, crop
        // the actual WebView rendering after bringing that exact IMG into view.
        String js="(function(){try{"
            +"const urls="+sourceList+";"
            +"const id="+JSONObject.quote(expected.getPath().replaceAll("^/bc/item/([0-9]{5,15})/?$","$1"))+";"
            +"const allowed=new Set(urls.map(x=>{try{return new URL(x).href;}catch(e){return '';}}));"
            +"const eligible=e=>{let src=e.currentSrc||e.src||'';try{src=new URL(src,location.href).href;}catch(_){return false;}"
            +"if(!allowed.has(src))return false;"
            +"if(!e.complete||e.naturalWidth<96||e.naturalHeight<96)return false;"
            +"const a=e.closest('main,#productMain,#detailMain,#mainArea,#itemDetail,[class*=gallery],[class*=Gallery],[id*=image],[id*=Image]');"
            +"return !!a;};"
            +"const image=Array.from(document.images).find(eligible);"
            +"if(!image)return JSON.stringify({type:'pending'});"
            +"image.scrollIntoView({block:'center',inline:'center'});"
            +"try{const scale=Math.min(1,480/image.naturalWidth,480/image.naturalHeight);"
            +"const c=document.createElement('canvas');c.width=Math.round(image.naturalWidth*scale);c.height=Math.round(image.naturalHeight*scale);"
            +"c.getContext('2d').drawImage(image,0,0,c.width,c.height);"
            +"const data=c.toDataURL('image/jpeg',0.83);"
            +"if(data.length>2000&&data.length<2600000)return JSON.stringify({type:'data',data:data});}catch(_){/* CORS-tainted image */}"
            +"return JSON.stringify({type:'rect'});"
            +"}catch(e){return JSON.stringify({type:'error'});}})()";
        try {
            web.evaluateJavascript(js, raw->{
                if(completed)return;
                try{
                    Object v=new JSONTokener(raw==null?"null":raw).nextValue();
                    JSONObject o=new JSONObject(v instanceof String?(String)v:"{}");
                    String type=o.optString("type");
                    if("data".equals(type)){
                        String data=o.optString("data","");int comma=data.indexOf(',');
                        if(comma>0&&data.startsWith("data:image/jpeg;base64,")){
                            byte[] bytes=Base64.decode(data.substring(comma+1),Base64.DEFAULT);
                            if(looksUsable(bytes)){trace("canvas","success");finish(bytes);return;}
                        }
                    }
                    if("rect".equals(type)){
                        // Allow scrollIntoView to update the compositor before a crop.
                        main.postDelayed(this::screenCrop,280);
                        return;
                    }
                    again(type);
                }catch(Exception e){again("callback-"+e.getClass().getSimpleName());}
            });
        }catch(Exception e){again("eval-"+e.getClass().getSimpleName());}
    }
    private void screenCrop(){
        if(completed)return;
        if(!sameItem()){finish(null);return;}
        String js="(function(){try{const urls="+sourceList+";"
           +"const imgs=Array.from(document.images);"
           +"const e=imgs.find(x=>x.complete&&x.naturalWidth>=96&&x.naturalHeight>=96&&urls.indexOf(x.currentSrc||x.src)>=0);"
           +"if(!e)return '{}';const r=e.getBoundingClientRect();"
           +"return JSON.stringify({x:r.left,y:r.top,w:r.width,h:r.height,vw:innerWidth,vh:innerHeight});"
           +"}catch(_){return '{}';}})()";
        try{
            web.evaluateJavascript(js, raw->{
                if(completed)return;
                try{
                    Object v=new JSONTokener(raw==null?"null":raw).nextValue();
                    JSONObject r=new JSONObject(v instanceof String?(String)v:"{}");
                    int ww=web.getWidth(),hh=web.getHeight();
                    double vw=r.optDouble("vw",0),vh=r.optDouble("vh",0);
                    if(ww<160||hh<160||ww>3000||hh>4000||vw<100||vh<100){again("invalid-viewport");return;}
                    double sx=ww/vw,sy=hh/vh;
                    int x=(int)Math.round(r.optDouble("x",-999)*sx);
                    int y=(int)Math.round(r.optDouble("y",-999)*sy);
                    int width=(int)Math.round(r.optDouble("w",0)*sx);
                    int height=(int)Math.round(r.optDouble("h",0)*sy);
                    Rect crop=new Rect(Math.max(0,x),Math.max(0,y),Math.min(ww,x+width),Math.min(hh,y+height));
                    if(crop.width()<80||crop.height()<80||crop.width()>2000||crop.height()>2000){again("image-offscreen");return;}
                    Bitmap full=null,sub=null;
                    float originalAlpha=web.getAlpha();
                    try{
                        full=Bitmap.createBitmap(ww,hh,Bitmap.Config.ARGB_8888);
                        Canvas c=new Canvas(full);
                        c.drawColor(android.graphics.Color.WHITE);
                        // alpha was zero for privacy; restore within the same UI turn.
                        web.setAlpha(1f);
                        try{web.draw(c);}finally{web.setAlpha(originalAlpha);}
                        sub=Bitmap.createBitmap(full,crop.left,crop.top,crop.width(),crop.height());
                        if(!nonBlank(sub)){again("blank-render");return;}
                        int max=Math.max(sub.getWidth(),sub.getHeight());
                        float scale=Math.min(1f,480f/max);
                        Bitmap output=Bitmap.createScaledBitmap(sub,Math.max(1,Math.round(sub.getWidth()*scale)),
                            Math.max(1,Math.round(sub.getHeight()*scale)),true);
                        ByteArrayOutputStream buffer=new ByteArrayOutputStream();
                        try{output.compress(Bitmap.CompressFormat.JPEG,84,buffer);}
                        finally{if(output!=sub)output.recycle();}
                        byte[] bytes=buffer.toByteArray();
                        if(looksUsable(bytes)){trace("painted","success");finish(bytes);}
                        else again("bad-render-bytes");
                    }finally{if(sub!=null)sub.recycle();if(full!=null)full.recycle();}
                }catch(Exception e){again("crop-"+e.getClass().getSimpleName());}
            });
        }catch(Exception e){again("geometry-"+e.getClass().getSimpleName());}
    }
    private static boolean nonBlank(Bitmap bmp){
        java.util.HashSet<Integer> colors=new java.util.HashSet<>();
        for(int y=0;y<8;y++)for(int x=0;x<8;x++){
            int c=bmp.getPixel((x*7+3)*bmp.getWidth()/56, (y*7+3)*bmp.getHeight()/56);
            colors.add(c&0x00F0F0F0);
        }
        return colors.size()>=5;
    }
    private static boolean looksUsable(byte[] bytes){
        if(bytes==null||bytes.length<1500||bytes.length>2200000)return false;
        android.graphics.BitmapFactory.Options o=new android.graphics.BitmapFactory.Options();
        o.inJustDecodeBounds=true;android.graphics.BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);
        return o.outWidth>=80&&o.outHeight>=80&&o.outWidth<=1200&&o.outHeight<=1200;
    }
}
