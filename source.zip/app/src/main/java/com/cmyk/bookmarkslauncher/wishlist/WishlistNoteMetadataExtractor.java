package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Keyword-scoped metadata only. It never reads a price. */
final class WishlistNoteMetadataExtractor {
    private static final Pattern IMG=Pattern.compile("<img\\b[^>]*>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL);
    private static final Pattern ATTR=Pattern.compile("(?:src|data-src|data-original|data-image-src)\\s*=\\s*[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);
    static String image(String before, URL page) {
        Matcher images=IMG.matcher(before);
        String found=null;
        while(images.find()) {
            Matcher attr=ATTR.matcher(images.group());
            while(attr.find()) {
                try {
                    URL u=new URL(page, attr.group(1).replace("&amp;","&"));
                    if ("https".equalsIgnoreCase(u.getProtocol()) && WishlistCrawler.isAllowedUrl(u)
                            && !u.getPath().endsWith(".svg") && !u.getPath().endsWith(".gif")) found=u.toString();
                } catch(Exception ignored) {}
                break;
            }
        }
        return found;
    }
}
