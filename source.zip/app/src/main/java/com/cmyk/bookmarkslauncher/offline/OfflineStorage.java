package com.cmyk.bookmarkslauncher.offline;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** External-file backing store for normal web bookmark offline sets. */
public final class OfflineStorage {
    private static final String PREFS = "offline_web";
    private static final String KEY_TREE_URI = "tree_uri";
    private static final String ROOT_DIR = "BookmarkLauncher Offline";
    private static final String INDEX_NAME = "index.json";

    private OfflineStorage() {}

    public static Uri getTreeUri(Context context) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TREE_URI, null);
        return raw == null || raw.isBlank() ? null : Uri.parse(raw);
    }

    public static void setTreeUri(Context context, Uri treeUri) {
        SharedPreferences.Editor e = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        if (treeUri == null) e.remove(KEY_TREE_URI); else e.putString(KEY_TREE_URI, treeUri.toString());
        e.apply();
    }

    public static Uri ensureBookmarkFolder(Context context, BookmarkNode node) throws Exception {
        if (node.offlinePath != null && !node.offlinePath.isBlank()) {
            Uri existing = Uri.parse(node.offlinePath);
            if (canQuery(context, existing)) return existing;
        }
        Uri tree = getTreeUri(context);
        if (tree == null) return null;
        Uri rootDoc = treeDocumentUri(tree);
        Uri appDir = ensureDirectory(context, rootDoc, ROOT_DIR);
        String shortId = node.id == null ? "bookmark" : node.id.replace("-", "").substring(0, Math.min(8, node.id.replace("-", "").length()));
        String folderName = safeName(node.displayName(), 42) + "_" + shortId;
        return ensureDirectory(context, appDir, folderName);
    }

    public static Index loadIndex(Context context, Uri folder) {
        Index index = new Index();
        if (folder == null) return index;
        try {
            Uri file = findChild(context, folder, INDEX_NAME);
            if (file == null) return index;
            String json = readText(context, file);
            if (json == null || json.isBlank()) return index;
            JSONObject root = new JSONObject(json);
            JSONArray pages = root.optJSONArray("pages");
            if (pages == null) return index;
            for (int i = 0; i < pages.length(); i++) {
                JSONObject p = pages.optJSONObject(i);
                if (p == null) continue;
                Page page = new Page();
                page.url = canonicalize(p.optString("url", null));
                page.title = p.optString("title", "");
                page.fileName = p.optString("file", "");
                page.savedAt = p.optLong("savedAt", 0L);
                page.size = p.optLong("size", 0L);
                if (page.url != null && !page.fileName.isBlank()) index.pages.put(page.url, page);
            }
        } catch (Throwable ignored) { }
        return index;
    }

    public static void saveIndex(Context context, Uri folder, BookmarkNode node, Index index) throws Exception {
        JSONObject root = new JSONObject();
        root.put("version", 1);
        root.put("bookmarkId", node.id == null ? "" : node.id);
        root.put("rootUrl", canonicalize(node.url));
        JSONArray pages = new JSONArray();
        for (Page page : index.pages.values()) {
            JSONObject p = new JSONObject();
            p.put("url", page.url);
            p.put("title", page.title == null ? "" : page.title);
            p.put("file", page.fileName);
            p.put("savedAt", page.savedAt);
            p.put("size", page.size);
            pages.put(p);
        }
        root.put("pages", pages);
        Uri file = ensureFile(context, folder, "application/json", INDEX_NAME);
        writeText(context, file, root.toString(2));
    }

    public static Page find(Index index, String url) {
        if (index == null) return null;
        String key = canonicalize(url);
        return key == null ? null : index.pages.get(key);
    }

    public static Page putArchive(Context context, Uri folder, Index index, String url,
                                  String title, File tempArchive) throws Exception {
        String canonical = canonicalize(url);
        if (canonical == null || tempArchive == null || !tempArchive.isFile()) return null;
        Page old = index.pages.get(canonical);
        String fileName = old != null && old.fileName != null && !old.fileName.isBlank()
                ? old.fileName : archiveFileNameForUrl(canonical);
        Uri target = ensureFile(context, folder, "multipart/related", fileName);
        copyFileToUri(context, tempArchive, target);
        Page page = old == null ? new Page() : old;
        page.url = canonical;
        page.title = title == null ? "" : title;
        page.fileName = fileName;
        page.fileUri = target.toString();
        page.savedAt = System.currentTimeMillis();
        page.size = tempArchive.length();
        index.pages.put(canonical, page);
        return page;
    }

    public static File materializePage(Context context, Uri folder, Page page) throws Exception {
        if (folder == null || page == null || page.fileName == null) return null;
        Uri source = findChild(context, folder, page.fileName);
        if (source == null) return null;
        File out = new File(context.getCacheDir(), "offline_view_" + sha256Short(page.url) + ".mhtml");
        try (InputStream in = context.getContentResolver().openInputStream(source);
             OutputStream os = new FileOutputStream(out, false)) {
            if (in == null) return null;
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) >= 0) os.write(buf, 0, n);
        }
        return out;
    }

    /** Materializes an exact SAF document URI without consulting index.json. */
    public static File materializeDocument(Context context, Uri source, String url) throws Exception {
        if (source == null) return null;
        String canonical = canonicalize(url);
        if (canonical == null) return null;
        File out = new File(context.getCacheDir(), "offline_view_" + sha256Short(canonical) + ".mhtml");
        try (InputStream in = context.getContentResolver().openInputStream(source);
             OutputStream os = new FileOutputStream(out, false)) {
            if (in == null) return null;
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) >= 0) os.write(buf, 0, n);
        }
        return out.isFile() && out.length() > 0L ? out : null;
    }

    /** Finds the deterministic page archive directly in the external folder. */
    public static Uri findPageDocument(Context context, Uri folder, String url) {
        if (folder == null) return null;
        try {
            return findChild(context, folder, archiveFileNameForUrl(url));
        } catch (Throwable ignored) {
            return null;
        }
    }

    /** Legacy recovery: if a set contains exactly one MHTML archive, that file is its root. */
    public static Uri findSingleArchiveDocument(Context context, Uri folder) {
        if (folder == null) return null;
        try {
            String parentId = DocumentsContract.getDocumentId(folder);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(folder, parentId);
            String[] projection = {
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME
            };
            Uri match = null;
            int count = 0;
            try (Cursor c = context.getContentResolver().query(children, projection, null, null, null)) {
                if (c == null) return null;
                while (c.moveToNext()) {
                    String name = c.getString(1);
                    if (name == null) continue;
                    String lower = name.toLowerCase(Locale.ROOT);
                    if (!lower.endsWith(".mhtml") && !lower.endsWith(".mht")) continue;
                    count++;
                    if (count > 1) return null;
                    match = DocumentsContract.buildDocumentUriUsingTree(folder, c.getString(0));
                }
            }
            return count == 1 ? match : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    public static String archiveFileNameForUrl(String url) throws Exception {
        String canonical = canonicalize(url);
        if (canonical == null) throw new IllegalArgumentException("url required");
        return "page_" + sha256Short(canonical) + ".mhtml";
    }


    /** Deletes the complete external offline set for one bookmark. */
    public static boolean deleteBookmarkSet(Context context, BookmarkNode node) {
        if (node == null || node.offlinePath == null || node.offlinePath.isBlank()) return true;
        try {
            Uri folder = Uri.parse(node.offlinePath);
            deleteTree(context, folder);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static String canonicalize(String raw) {
        if (raw == null || raw.isBlank()) return null;
        try {
            URI u = new URI(raw.trim());
            String scheme = u.getScheme();
            if (scheme == null) return raw.trim();
            if (!scheme.equalsIgnoreCase("http") && !scheme.equalsIgnoreCase("https")) return raw.trim();
            URI clean = new URI(scheme.toLowerCase(Locale.ROOT), u.getUserInfo(),
                    u.getHost() == null ? null : u.getHost().toLowerCase(Locale.ROOT), u.getPort(),
                    u.getPath(), u.getQuery(), null);
            return clean.toString();
        } catch (Exception e) {
            int hash = raw.indexOf('#');
            return (hash >= 0 ? raw.substring(0, hash) : raw).trim();
        }
    }

    public static final class Index {
        public final LinkedHashMap<String, Page> pages = new LinkedHashMap<>();
    }

    public static final class Page {
        public String url;
        public String title;
        public String fileName;
        public String fileUri;
        public long savedAt;
        public long size;
    }

    private static Uri treeDocumentUri(Uri tree) {
        String id = DocumentsContract.getTreeDocumentId(tree);
        return DocumentsContract.buildDocumentUriUsingTree(tree, id);
    }

    private static boolean canQuery(Context context, Uri folder) {
        try {
            String id = DocumentsContract.getDocumentId(folder);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(folder, id);
            try (Cursor c = context.getContentResolver().query(children,
                    new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID}, null, null, null)) {
                return c != null;
            }
        } catch (Throwable t) {
            return false;
        }
    }

    private static Uri ensureDirectory(Context context, Uri parent, String name) throws Exception {
        Uri found = findChild(context, parent, name);
        if (found != null) return found;
        Uri created = DocumentsContract.createDocument(context.getContentResolver(), parent,
                DocumentsContract.Document.MIME_TYPE_DIR, name);
        if (created == null) throw new IllegalStateException("directory create failed");
        return created;
    }

    private static Uri ensureFile(Context context, Uri parent, String mime, String name) throws Exception {
        Uri found = findChild(context, parent, name);
        if (found != null) return found;
        Uri created = DocumentsContract.createDocument(context.getContentResolver(), parent, mime, name);
        if (created == null) throw new IllegalStateException("file create failed");
        return created;
    }

    private static Uri findChild(Context context, Uri parent, String name) {
        try {
            String parentId = DocumentsContract.getDocumentId(parent);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(parent, parentId);
            String[] projection = {
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME
            };
            try (Cursor c = context.getContentResolver().query(children, projection, null, null, null)) {
                if (c == null) return null;
                while (c.moveToNext()) {
                    String childName = c.getString(1);
                    if (name.equals(childName)) {
                        return DocumentsContract.buildDocumentUriUsingTree(parent, c.getString(0));
                    }
                }
            }
        } catch (Throwable ignored) { }
        return null;
    }


    private static void deleteTree(Context context, Uri document) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        List<Uri> childUris = new ArrayList<>();
        try {
            String id = DocumentsContract.getDocumentId(document);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(document, id);
            try (Cursor c = resolver.query(children,
                    new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID}, null, null, null)) {
                if (c != null) {
                    while (c.moveToNext()) {
                        childUris.add(DocumentsContract.buildDocumentUriUsingTree(document, c.getString(0)));
                    }
                }
            }
        } catch (Throwable ignored) {
            // Plain files are not child containers. They are deleted below.
        }
        for (Uri child : childUris) deleteTree(context, child);
        if (!DocumentsContract.deleteDocument(resolver, document)) {
            throw new IllegalStateException("document delete failed");
        }
    }

    private static String readText(Context context, Uri uri) throws Exception {
        try (InputStream in = context.getContentResolver().openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) return null;
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private static void writeText(Context context, Uri uri, String text) throws Exception {
        try (OutputStream out = context.getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new IllegalStateException("openOutputStream failed");
            out.write(text.getBytes(StandardCharsets.UTF_8));
        }
    }

    private static void copyFileToUri(Context context, File source, Uri target) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        try (InputStream in = new FileInputStream(source);
             OutputStream out = resolver.openOutputStream(target, "wt")) {
            if (out == null) throw new IllegalStateException("openOutputStream failed");
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
        }
    }

    private static String safeName(String raw, int max) {
        String s = raw == null ? "bookmark" : raw.trim();
        s = s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").replaceAll("\\s+", " ").trim();
        if (s.isBlank()) s = "bookmark";
        return s.length() <= max ? s : s.substring(0, max).trim();
    }

    private static String sha256Short(String text) throws Exception {
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 10; i++) b.append(String.format(Locale.ROOT, "%02x", hash[i]));
        return b.toString();
    }
}
