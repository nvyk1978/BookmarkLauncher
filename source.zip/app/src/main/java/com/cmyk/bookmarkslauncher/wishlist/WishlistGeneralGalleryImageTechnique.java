package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import org.json.JSONObject;

/**
 * G gallery technique: choose photos from the verified product page, not from
 * sidebar recommendations. Joshin uses it via a strict site/route adapter;
 * another merchant may reuse it only after supplying a proven item identity.
 * No stock or price inference, and no navigation or clicks.
 */
public final class WishlistGeneralGalleryImageTechnique {
    private WishlistGeneralGalleryImageTechnique() { }

    public static String javascript(URL page, String productCode) {
        if (page == null || productCode == null || productCode.isBlank()
                || !WishlistCrawler.isAllowedUrl(page)) return "JSON.stringify([])";
        return SCRIPT.replace("__HOST__", JSONObject.quote(page.getHost().toLowerCase(java.util.Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(page.getPath()))
                .replace("__ITEM__", JSONObject.quote(productCode));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 try {
  const host=__HOST__, path=__PATH__, item=__ITEM__;
  if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host||
     !(location.pathname.replace(/\\/+$/,'').toLowerCase()===path.replace(/\\/+$/,'').toLowerCase()||
     location.pathname.toLowerCase().endsWith('/'+item.toLowerCase()+'.html'))) return JSON.stringify([]);
  const main=document.querySelector('main,[role=main],#main,#contents,#content')||document.body;
  const heading=[...main.querySelectorAll('h1')].find(e=>{
    const s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&(e.innerText||e.textContent||'').trim().length>3;
  });
  if(!heading) return JSON.stringify([]);
  const canonical=document.querySelector('link[rel=canonical]');
  if(canonical&&canonical.href){
    try {const u=new URL(canonical.href,location.href);
      if(u.hostname.toLowerCase()!==host||!u.pathname.endsWith('/'+item+'.html'))return JSON.stringify([]);
    }catch(_){return JSON.stringify([]);}
  }
  const title=(heading.innerText||heading.textContent||'').replace(/\\s+/g,'').toLowerCase();
  const excluded='header,footer,nav,aside,[class*=recommend],[class*=related],[class*=ranking],'+
     '[class*=pickup],[class*=carousel],[id*=recommend],[id*=related]';
  const seen=new Map();
  function add(raw,score){
   if(!raw||typeof raw!=='string'||raw.length>2048)return;
   try {const u=new URL(raw.replace(/&amp;/g,'&'),location.href);
     if(u.protocol!=='https:'||u.username||u.password)return;
     if(!(/\\.(?:jpg|jpeg|png|webp|avif)(?:$|[?#])/i.test(u.href)||/\\/(?:image|images|img|photo|picture|thumb)[\\/_-]/i.test(u.pathname)))return;
     if(/(?:logo|banner|icon|sprite|payment|recommend|related|tracking|spacer|placeholder|noimage|header|footer)/i.test(u.pathname))return;
     if(u.href.includes(item))score+=70;
     const key=u.href; if(!seen.has(key)||seen.get(key)<score)seen.set(key,score);
   }catch(_){}
  }
  function image(el,score){
   if(!el||el.closest(excluded))return;
   const hint=[el.id,el.className,el.getAttribute('alt')].join(' ').toLowerCase();
   if(/logo|banner|icon|recommend|related|tracking|spacer|placeholder/i.test(hint))return;
   const alt=String(el.getAttribute('alt')||'').replace(/\\s+/g,'').toLowerCase();
   const labels=(title.match(/[a-z0-9][a-z0-9_-]{4,}/g)||[]).slice(0,8);
   if(alt&&((title.length>=8&&alt.includes(title.slice(0,8)))||
      labels.some(t=>alt.includes(t))))score+=45;
   if(el.naturalWidth>=200&&el.naturalHeight>=180)score+=10;
   for(const k of ['data-zoom-image','data-large-image','data-original','data-src','data-lazy-src','src'])add(el.getAttribute(k),score);
   add(el.currentSrc,score+5);
   const set=el.getAttribute('data-srcset')||el.getAttribute('srcset')||'';
   for(const part of set.split(',').slice(0,5))add(part.trim().split(/\\s+/)[0],score+4);
   const a=el.closest('a[href]');if(a)add(a.getAttribute('href'),score+10);
  }
  // Strong sources only: marked gallery, explicitly product-bound image, or
  // an image whose alt matches the product heading. Never a page-wide first image.
  const selectors=['img[itemprop=image]','[itemprop=image] img',
    '[class*=productImage] img','[class*=product-image] img',
    '[class*=itemImage] img','[class*=item-image] img',
    '[class*=productPhoto] img','[class*=product-photo] img',
    '[class*=productGallery] img','[class*=product-gallery] img',
    '[class*=gallery] img','#mainImage img','#mainImage','#main_image img',
    '[data-fancybox] img','[data-lightbox] img'];
  for(const selector of selectors){
    for(const el of main.querySelectorAll(selector))image(el,180);
  }
  for(const el of main.querySelectorAll('img[alt]')){
    const alt=String(el.getAttribute('alt')||'').replace(/\\s+/g,'').toLowerCase();
    const words=(title.match(/[a-z0-9][a-z0-9_-]{4,}/g)||[]).slice(0,8);
    if(alt.length>=8&&((title.length>=8&&alt.includes(title.slice(0,8)))||
       words.some(t=>alt.includes(t))))image(el,140);
  }
  // Metadata is usable only when the canonical product identity matches.
  // It is lower priority than images anchored within the product gallery.
  if(location.pathname.toLowerCase().endsWith('/'+item.toLowerCase()+'.html')){
   for(const meta of document.querySelectorAll('meta[property="og:image"],meta[property="og:image:secure_url"],meta[name="twitter:image"]'))
      add(meta.content,65);
  }
  return JSON.stringify([...seen.entries()].filter(x=>x[1]>=65)
    .sort((a,b)=>b[1]-a[1]).slice(0,6).map(x=>x[0]));
 }catch(_){return JSON.stringify([]);}
})()
""";
}
