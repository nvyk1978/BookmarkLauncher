package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import org.json.JSONTokener;
import java.net.URL;

/** Amazon title ONLY. No marketplace/generic parsing, price, image or stock writes. */
public final class AmazonNameWebViewProbe {
    public interface Callback { void completed(String title); }
    private final FrameLayout parent;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private Callback callback;
    private MarketplaceIdentity expected;
    private boolean finished;
    private int inspected;
    private final Runnable timeout=()->finish(null);

    public AmazonNameWebViewProbe(FrameLayout parent){this.parent=parent;}
    public void start(String url, Callback done){
        cancel();
        callback=done;finished=false;inspected=0;
        if(Looper.myLooper()!=Looper.getMainLooper()){finish(null);return;}
        try{
            URL parsed=new URL(url);
            expected=MarketplaceIdentity.from(parsed);
            if(expected==null||expected.site!=MarketplaceIdentity.Site.AMAZON){finish(null);return;}
            web=new WebView(parent.getContext());
            web.setAlpha(0f);
            web.setBackgroundColor(Color.TRANSPARENT);
            web.setFocusable(false);web.setFocusableInTouchMode(false);
            web.setClickable(false);web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            parent.addView(web,0,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
            web.setWebViewClient(new WebViewClient(){
                @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
                    return r.isForMainFrame()&&!allowed(r.getUrl().toString());
                }
                @Override public void onPageFinished(WebView v,String u){if(!finished&&allowed(u))inspect(v);}
                @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){
                    if(r.isForMainFrame())finish(null);
                }
            });
            main.postDelayed(timeout,15000);
            web.loadUrl(url);
        }catch(Exception ignored){finish(null);}
    }
    private boolean allowed(String text){
        try {URL u=new URL(text);return expected!=null&&"https".equalsIgnoreCase(u.getProtocol())
                &&WishlistCrawler.isAllowedUrl(u)&&expected.matches(u);}
        catch(Exception ignored){return false;}
    }
    private void inspect(WebView v){
        if(finished||v!=web||!allowed(v.getUrl()))return;
        inspected++;
        String js="(function(){try{var e=document.querySelector('#productTitle')||document.querySelector('#title #productTitle');"
                +"if(!e)return '';var text=(e.innerText||e.textContent||'').replace(/\\s+/g,' ').trim();"
                +"if(text.length<5||/captcha|robot check|sign.in|アクセスできません/i.test(text))return '';"
                +"return text.slice(0,500);}catch(err){return '';}})()";
        v.evaluateJavascript(js,value->{
            if(finished||v!=web)return;
            String title=null;
            try{Object decoded=new JSONTokener(value==null?"null":value).nextValue();
                if(decoded instanceof String)title=((String)decoded).trim();}catch(Exception ignored){}
            if(title!=null&&title.length()>=5){finish(title);return;}
            if(inspected<7)main.postDelayed(()->inspect(v),1050);
            else finish(null);
        });
    }
    private void finish(String title){
        if(finished)return;
        finished=true;main.removeCallbacks(timeout);
        WebView old=web;web=null;
        if(old!=null){old.stopLoading();old.setWebViewClient(new WebViewClient());parent.removeView(old);old.destroy();}
        Callback done=callback;callback=null;
        if(done!=null)done.completed(title);
    }
    public void cancel(){
        if(Looper.myLooper()!=Looper.getMainLooper())return;
        callback=null;finish(null);
    }
}
