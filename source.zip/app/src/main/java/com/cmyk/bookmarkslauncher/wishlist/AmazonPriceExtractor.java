package com.cmyk.bookmarkslauncher.wishlist;

import android.text.Html;
import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Amazon-only price extractor. No name/image extraction and no shared product state. */
final class AmazonPriceExtractor {
    private AmazonPriceExtractor() {}
    static boolean isAmazon(URL url) {
        String host=url.getHost().toLowerCase(Locale.ROOT);
        return host.equals("amazon.co.jp") || host.endsWith(".amazon.co.jp");
    }
    private static final Pattern TAG = Pattern.compile("<[^>]+>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern OFFSCREEN = Pattern.compile("<span\\b[^>]*class\\s*=\\s*['\"][^'\"]*\\ba-offscreen\\b[^'\"]*['\"][^>]*>(.*?)</span\\s*>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL);
    private static final Pattern YEN = Pattern.compile("[¥￥]\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)");
    static Long fromHtml(String html) {
        Matcher tags=TAG.matcher(html);
        while(tags.find()) {
            String tag=tags.group();
            String lower=tag.toLowerCase(Locale.ROOT);
            boolean current=lower.matches("(?s).*\\bid\\s*=\\s*['\"](?:priceblock_ourprice|priceblock_dealprice|priceblock_saleprice|price_inside_buybox|newbuyboxprice|pricetopay)['\"].*")
                    || lower.matches("(?s).*\\bclass\\s*=\\s*['\"][^'\"]*\\bpricetopay\\b[^'\"]*['\"].*");
            if(!current)continue;
            String region=html.substring(tags.end(),Math.min(html.length(),tags.end()+1400));
            Matcher hidden=OFFSCREEN.matcher(region);
            if(hidden.find()) { Long p=parseYen(Html.fromHtml(hidden.group(1),Html.FROM_HTML_MODE_LEGACY).toString()); if(p!=null)return p; }
            // For current-price containers only; do not accept struck-through regular prices.
            if(!region.substring(0,Math.min(350,region.length())).contains("a-text-price")) {
                Long p=parseYen(Html.fromHtml(region.substring(0,Math.min(450,region.length())),Html.FROM_HTML_MODE_LEGACY).toString());
                if(p!=null)return p;
            }
        }
        return null;
    }
    static Long parseYen(String s) {
        if(s==null)return null;
        Matcher m=YEN.matcher(s);
        if(!m.find())return null;
        try {long p=Math.round(Double.parseDouble(m.group(1).replace(",","")));return p>=1&&p<=100000000?p:null;}
        catch(Exception ignored){return null;}
    }
}
