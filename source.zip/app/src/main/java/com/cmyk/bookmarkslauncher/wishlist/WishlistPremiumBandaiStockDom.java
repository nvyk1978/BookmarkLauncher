package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/** Premium Bandai exact-item reservation availability; never clicks a control. */
public final class WishlistPremiumBandaiStockDom {
    private WishlistPremiumBandaiStockDom() { }

    public static boolean supports(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())) return false;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        return (host.equals("p-bandai.jp") || host.equals("www.p-bandai.jp"))
                && url.getPath().matches("(?i)^/item/item-[0-9]{7,13}/?$");
    }

    public static String javascript(URL original) {
        if (!supports(original)) return "JSON.stringify({status:'UNKNOWN',reason:'unsupported-item'})";
        return SCRIPT.replace("__ITEM_PATH__", JSONObject.quote(original.getPath().replaceAll("/+$", "").toLowerCase(Locale.ROOT)));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const o={status:'UNKNOWN',reason:'unverified',bound:false,title:false,price:false,
          candidates:0,enabled:0,disabled:0,negative:false,variant:false},done=()=>JSON.stringify(o);
 try{
   const path=String(location.pathname||'').replace(/\\/+$/,'').toLowerCase();
   if(!/^https:$/.test(location.protocol)||!/(?:^|\\.)p-bandai\\.jp$/i.test(location.hostname)
       ||path!==__ITEM_PATH__){o.reason='item-url-mismatch';return done();}
   const bad='header,nav,footer,aside,[class*=recommend],[class*=related],'+
       '[class*=ranking],[class*=breadcrumb],[class*=history]';
   const txt=e=>String(e&&(e.innerText||e.textContent)||'').replace(/\\s+/g,' ').trim();
   const visible=e=>{if(!e||e.closest(bad))return false;
     for(let n=e;n;n=n.parentElement){
       if(n.hidden||n.hasAttribute('inert')||n.getAttribute('aria-hidden')==='true')return false;
       const s=getComputedStyle(n);
       if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||Number(s.opacity)===0)return false;
     }return true;};
   const root=document.querySelector('main,[role=main],#main,#contents,#itemDetail,.item-detail')||document.body;
   if(!root){o.reason='body-missing';return done();}
   const names=[...root.querySelectorAll('h1')].filter(e=>visible(e)&&txt(e).length>=4&&txt(e).length<=300);
   if(names.length!==1){o.reason='unique-product-title-missing';return done();}
   o.title=true;
   const itemTitle=txt(names[0]);
   const meta=document.querySelector('meta[property="og:title"]');
   if(meta&&meta.content&&meta.content.length>5&&!meta.content.includes(itemTitle)&&!itemTitle.includes(meta.content)){
     o.reason='title-contradiction';return done();}
   // Official route AND the product's rendered H1 are both mandatory.
   o.bound=true;
   const bodyText=txt(root).slice(0,18000);
   // An ended reservation anywhere in the primary product information
   // contradicts a leftover enabled button template. Prefer UNKNOWN.
   if(/(?:予約受付終了|予約終了|予約期間終了|販売終了|完売)/.test(bodyText.slice(0,4500))){
     o.negative=true;o.reason='reservation-ended-or-conflicting';return done();
   }
   o.price=/(?:販売価格|価格)\\s*[:：]?\\s*[¥￥]?\\s*[0-9][0-9,]{2,}\\s*円|[¥￥]\\s*[0-9][0-9,]{2,}\\s*\\(?税込/.test(bodyText);
   // Reservation is a buy action only on this exact item. Never use a header
   // cart, an expired reservation badge, or a linked recommendation.
   const actions=[...root.querySelectorAll('button,input[type=submit],input[type=button],a[href],[role=button]')]
     .filter(e=>!e.closest(bad));
   const reserve=/(?:^|\\s)予約する(?:$|\\s)/;
   const blockedText=/(?:予約受付終了|予約終了|予約期間終了|受付終了|販売終了|在庫切れ|売り切れ|売切れ|完売)/;
   for(const e of actions){
     const label=[txt(e),e.value,e.getAttribute('aria-label'),e.getAttribute('title')]
         .filter(Boolean).join(' ').replace(/\\s+/g,' ').trim();
     if(!reserve.test(label)||label.length>100)continue;
     o.candidates++;
     const group=e.closest('form,[class*=order],[class*=purchase],[class*=buy],'+
       '[class*=cart],[class*=reserve],[class*=variation],[class*=variant]')||e.parentElement;
     if(!visible(e)||e.disabled||e.hasAttribute('disabled')||
        e.getAttribute('aria-disabled')==='true') {o.disabled++;continue;}
     if(!group||!root.contains(group))continue;
     const panel=txt(group).slice(0,600);
     // When the product itself advertises an expired reservation, a remaining
     // template button is NOT availability evidence.
     if(blockedText.test(panel)) {o.negative=true;continue;}
     // Reject generic/header links. An actual form or product-local purchase
     // area is required, together with a rendered product price.
     if(e.tagName==='A' && !e.closest('form,[class*=purchase],[class*=order],'+
           '[class*=buy],[class*=reserve],[class*=variation],[class*=variant]'))continue;
     const variant=e.closest('[class*=variation],[class*=variant]');
     if(variant)o.variant=true;
     o.enabled++;
   }
   if(!o.price){o.reason='item-price-missing';return done();}
   if(o.negative){o.reason='reservation-ended-or-conflicting';return done();}
   if(o.enabled>=1){o.status='AVAILABLE';o.reason='item-local-enabled-reservation';return done();}
   o.reason=o.candidates===0?'reservation-control-missing':'reservation-disabled';
   return done();
 }catch(_){o.reason='dom-error';return done();}
})()
""";
}
