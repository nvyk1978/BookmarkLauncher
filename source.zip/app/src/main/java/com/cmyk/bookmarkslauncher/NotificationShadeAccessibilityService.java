package com.cmyk.bookmarkslauncher;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

public final class NotificationShadeAccessibilityService extends AccessibilityService {
    private static volatile NotificationShadeAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        DiagLog.write(this, "ACCESSIBILITY_SERVICE_CONNECTED");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // No event inspection is required. This service exists only to perform the
        // user-requested global notification-shade action from the launcher gesture.
    }

    @Override
    public void onInterrupt() {
        // Nothing to interrupt.
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        DiagLog.write(this, "ACCESSIBILITY_SERVICE_DISCONNECTED");
        super.onDestroy();
    }

    public static boolean openNotifications() {
        NotificationShadeAccessibilityService service = instance;
        return service != null && service.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
    }
}
