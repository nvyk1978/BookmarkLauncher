package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;

/** Draws BookmarkLauncher's semi-transparent black status-bar surface on edge-to-edge Android. */
public final class SystemBarScrim {
    private static final int STATUS_SCRIM = 0x80000000;

    private SystemBarScrim() {}

    public static void apply(Activity activity, FrameLayout root) {
        if (activity == null) return;
        Window window = activity.getWindow();
        if (window == null) return;

        if (Build.VERSION.SDK_INT < 35 || root == null) {
            window.setStatusBarColor(STATUS_SCRIM);
            return;
        }

        // Android 15+ enforces edge-to-edge for modern targets, so statusBarColor alone can
        // be ignored. Keep the system bar transparent and draw the requested 50% black scrim
        // inside the status-bar inset instead.
        window.setStatusBarColor(Color.TRANSPARENT);
        int height = statusBarHeight(activity);
        if (height <= 0) return;

        View scrim = new View(activity);
        scrim.setBackgroundColor(STATUS_SCRIM);
        scrim.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height, Gravity.TOP);
        root.addView(scrim, lp);
    }

    private static int statusBarHeight(Activity activity) {
        int id = activity.getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id == 0 ? 0 : activity.getResources().getDimensionPixelSize(id);
    }
}
