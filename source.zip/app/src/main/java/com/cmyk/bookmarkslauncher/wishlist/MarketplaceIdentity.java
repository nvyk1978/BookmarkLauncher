package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** URL/primary-product identity only. Never guesses from related product links. */
final class MarketplaceIdentity {
    enum Site { AMAZON, RAKUTEN, YAHOO, OTHER }
    private static final Pattern ASIN = Pattern.compile("(?i)/(?:dp|gp/product|gp/aw/d)/([a-z0-9]{10})(?:[/?]|$)");
    private static final Pattern CANONICAL = Pattern.compile("(?is)<link\\b(?=[^>]*\\brel\\s*=\\s*['\"]?canonical\\b)[^>]*>");
    private static final Pattern HREF = Pattern.compile("(?i)\\bhref\\s*=\\s*(?:\"([^\"]+)\"|'([^']+)')");
    final Site site;
    final String id;
    final String host;
    private MarketplaceIdentity(Site site, String id, String host) { this.site=site;this.id=id;this.host=host; }
    static Site site(URL url) {
        if(url==null)return Site.OTHER;
        String h=url.getHost().toLowerCase(Locale.ROOT);
        if(h.equals("amazon.co.jp")||h.endsWith(".amazon.co.jp"))return Site.AMAZON;
        if(h.equals("item.rakuten.co.jp"))return Site.RAKUTEN;
        if(h.equals("store.shopping.yahoo.co.jp"))return Site.YAHOO;
        return Site.OTHER;
    }
    static MarketplaceIdentity from(URL page) {
        if(page==null)return null;
        Site s=site(page);
        String path=page.getPath();
        String id=null;
        if(s==Site.AMAZON){
            Matcher m=ASIN.matcher(path); if(m.find()) id=m.group(1).toUpperCase(Locale.ROOT);
        }else if(s==Site.RAKUTEN){
            // item.rakuten.co.jp/{shop}/{item}/; never accept a shop front or search page.
            Matcher m=Pattern.compile("^/([^/]+)/([^/]+)/?$",Pattern.CASE_INSENSITIVE).matcher(path);
            if(m.matches()&&!m.group(1).equalsIgnoreCase("search")&&!m.group(2).equalsIgnoreCase("search"))
                id=(m.group(1)+"/"+m.group(2)).toLowerCase(Locale.ROOT);
        }else if(s==Site.YAHOO){
            Matcher m=Pattern.compile("^/([^/]+)/([^/]+)\\.html$",Pattern.CASE_INSENSITIVE).matcher(path);
            if(m.matches()&&!m.group(2).equalsIgnoreCase("index"))
                id=(m.group(1)+"/"+m.group(2)).toLowerCase(Locale.ROOT);
        }
        return id==null?null:new MarketplaceIdentity(s,id,page.getHost().toLowerCase(Locale.ROOT));
    }
    boolean matches(URL other) {
        MarketplaceIdentity i=from(other);
        return i!=null&&i.site==site&&id.equalsIgnoreCase(i.id);
    }
    /** Explicit canonical for a different product means the requested URL is not verified. */
    boolean verified(String html,URL page) {
        if(html==null||page==null||!matches(page))return false;
        Matcher links=CANONICAL.matcher(html);
        while(links.find()){
            Matcher href=HREF.matcher(links.group());
            if(href.find()){
                try {
                    String url=href.group(1)!=null?href.group(1):href.group(2);
                    URL canonical=new URL(page,url.replace("&amp;","&"));
                    if(matches(canonical))return true;
                    // Variant canonical links may point at a parent ASIN. Accept
                    // only if THIS rendered product explicitly states the requested ASIN.
                    if(site==Site.AMAZON) {
                        Pattern asin=Pattern.compile("(?is)<input\\b[^>]*\\b(?:id|name)\\s*=\\s*['\"](?:ASIN|asin)['\"][^>]*\\bvalue\\s*=\\s*['\"]"+Pattern.quote(id)+"['\"]");
                        if(asin.matcher(html).find())return true;
                    }
                    return false;
                }catch(Exception ignored){return false;}
            }
        }
        // Some marketplaces omit canonical links in bot responses. The URL
        // itself still identifies a product, but individual evidence must be scoped.
        return true;
    }
}
