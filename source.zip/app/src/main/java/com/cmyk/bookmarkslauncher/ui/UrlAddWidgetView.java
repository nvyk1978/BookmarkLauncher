package com.cmyk.bookmarkslauncher.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

public final class UrlAddWidgetView extends View {
    public interface Listener {
        void onClickAdd();
        boolean onDragRequest(UrlAddWidgetView view);
    }

    private static final int N_LBLUE = 0xFF445577;
    private static final int N_ICON = 0xFFA9A999;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int touchSlop;
    private Listener listener;
    private int cellX;
    private int cellY;
    private float downX;
    private float downY;
    private boolean longPressArmed;
    private boolean dragStarted;
    private final Runnable armLongPress = () -> {
        longPressArmed = true;
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
    };

    public UrlAddWidgetView(Context context, int cellX, int cellY) {
        super(context);
        this.cellX = Math.max(0, cellX);
        this.cellY = Math.max(0, cellY);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setClickable(true);
        setFocusable(true);
        setElevation(0f);
    }

    public void setListener(Listener listener) { this.listener = listener; }
    public int getCellX() { return cellX; }
    public int getCellY() { return cellY; }
    public void setCell(int x, int y) { cellX = Math.max(0, x); cellY = Math.max(0, y); }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getX();
                downY = event.getY();
                longPressArmed = false;
                dragStarted = false;
                postDelayed(armLongPress, ViewConfiguration.getLongPressTimeout());
                return true;
            case MotionEvent.ACTION_MOVE:
                if (longPressArmed && !dragStarted) {
                    float dx = event.getX() - downX;
                    float dy = event.getY() - downY;
                    if (dx * dx + dy * dy > touchSlop * touchSlop) {
                        dragStarted = listener != null && listener.onDragRequest(this);
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
                removeCallbacks(armLongPress);
                if (!longPressArmed && !dragStarted && listener != null) listener.onClickAdd();
                longPressArmed = false;
                return true;
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(armLongPress);
                longPressArmed = false;
                dragStarted = false;
                return true;
            default:
                return true;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float diameter = Math.min(getWidth(), getHeight()) * 0.78f;
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float radius = diameter / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_LBLUE);
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setColor(N_ICON);
        paint.setStrokeWidth(Math.max(dp(2), diameter * 0.055f));
        paint.setStrokeCap(Paint.Cap.SQUARE);
        float arm = diameter * 0.22f;
        canvas.drawLine(cx - arm, cy, cx + arm, cy, paint);
        canvas.drawLine(cx, cy - arm, cx, cy + arm, paint);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
