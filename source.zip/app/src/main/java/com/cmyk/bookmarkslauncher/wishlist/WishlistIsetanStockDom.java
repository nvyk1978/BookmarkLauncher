package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/** Isolated ISETAN same-product stock evidence; never used by A-G or other stores. */
public final class WishlistIsetanStockDom {
    private WishlistIsetanStockDom() { }
    public static String javascript(URL url) {
        if (WishlistRetailDedicatedMode.forUrl(url) != WishlistRetailDedicatedMode.ISETAN)
            return "JSON.stringify({status:'UNKNOWN',reason:'unsupported'})";
        return SCRIPT.replace("__HOST__", JSONObject.quote(url.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(url.getPath().replaceAll("/+$", "").toLowerCase(Locale.ROOT)));
    }
    private static final String SCRIPT = """
(function(){'use strict';
 const r={status:'UNKNOWN',reason:'pending',product:false,idBound:false,
   variantBound:false,liveCarts:0,stockPairs:0};
 const done=()=>JSON.stringify(r);
 try {
   const host=__HOST__,path=__PATH__,clean=s=>String(s||'').replace(/\\/+$/,'').toLowerCase();
   if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host||
     clean(location.pathname)!==path){r.reason='document-mismatch';return done();}
   const main=document.querySelector('main,[role=main],#main,#contents,#content')||document.body;
   if(!main){r.reason='body-pending';return done();}
   const bad='header,footer,nav,aside,[class*=recommend],[class*=related],'+
     '[class*=ranking],[class*=pickup]';
   const txt=e=>String(e&&(e.innerText||e.textContent)||'').replace(/\\u00a0|　/g,' ').trim();
   const visible=e=>{if(!e||e.closest(bad)||e.disabled||e.getAttribute('aria-disabled')==='true')return false;
     for(let p=e;p;p=p.parentElement){if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return false;
       const s=getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0)return false;}
     return true;};
   const hs=[...main.querySelectorAll('h1')].filter(visible).map(txt).filter(t=>t.length>=4&&t.length<=240);
   if([...new Set(hs)].length!==1){r.reason='heading-unverified';return done();}
   r.product=true;
   const c=document.querySelector('link[rel=canonical]');
   if(c&&c.href){
     let u;try{u=new URL(c.href,location.href);}catch(_){r.reason='bad-canonical';return done();}
     if(u.hostname.toLowerCase()!==host||clean(u.pathname)!==path){r.reason='canonical-different-product';return done();}
   }
   // Only the exact product URL, a unique detail H1, and its own purchase
   // form may bind the action. A site-header cart never satisfies this.
   const buttons=[...main.querySelectorAll('#purBtn,button[name*=cart],button[name*=purchase]')]
     .filter(visible).filter(e=>e.id==='purBtn'||/カートに追加|カートに入れる/.test(txt(e)));
   r.liveCarts=buttons.length;
   if(buttons.length!==1){r.reason='product-purchase-not-unique';return done();}
   const buy=buttons[0];
   r.idBound=true;
   // A mandatory size/colour picker must be selected before its stock could
   // apply to this requested item. No cross-variant inherited positives.
   for(const sel of main.querySelectorAll('select[required],select[name*=size],select[name*=color]')){
     if(!visible(sel))continue;
     const op=sel.options&&sel.options[sel.selectedIndex];
     if(!op||!op.value||/^選択|お選び/.test(txt(op))){r.reason='variant-unselected';return done();}
   }
   // ISETAN puts stock in a table row (e.g. "在庫 | ◎在庫あり") separate
   // from #purBtn. Page-wide stock banners can include hidden templates for
   // "在庫切れ": never read their text or another product's stock.
   const yes=/(?:[◎◯○]\\s*在庫あり|在庫\\s*[:：]?\\s*[◎◯○]?\\s*(?:在庫)?(?:あり|有り)|在庫数\\s*[1-9][0-9]*|残り\\s*[1-9][0-9]*\\s*(?:個|点))/;
   const no=/(?:在庫\\s*[:：]?\\s*(?:なし|切れ|0)|売り切れ|完売|販売終了|入荷待ち)/;
   const rows=[...main.querySelectorAll('tr,[role=row],dl,[class*=stock],[id*=stock]')]
     .filter(e=>visible(e)&&!e.closest(bad)).slice(0,180);
   const evidence=[];
   for(const row of rows){
     const t=txt(row);
     if(t.length>230||!/(?:在庫|残り)/.test(t))continue;
     // Prefer the exact same inventory row to a global message elsewhere.
     if(yes.test(t)||no.test(t))evidence.push(t);
   }
   const unique=[...new Set(evidence)];
   if(unique.length){
     if(unique.some(t=>no.test(t))){r.reason='conflicting-or-negative-stock-row';return done();}
     if(!unique.some(t=>yes.test(t))){r.reason='no-local-stock-proof';return done();}
   }else{
     // Fallback: a short, visible product purchase form, not all body text.
     let near='';for(let p=buy,i=0;p&&i<6;i++,p=p.parentElement){
       const t=txt(p);if(t.length>1400)break;
       if(/在庫/.test(t)){near=t;break;}
     }
     if(!near||no.test(near)||!yes.test(near)){
       r.reason='no-local-stock-proof';return done();
     }
   }
   r.variantBound=true;r.stockPairs=1;
   r.status='AVAILABLE';r.reason='isetan-visible-stock-row-cart';return done();
 }catch(_){r.reason='isetan-dom-error';return done();}
})()
""";
}
