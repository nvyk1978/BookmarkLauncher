package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Resolves one requested marketplace product; never returns the first Product blindly. */
final class AmazonProductJsonLd {
    private static final Pattern SCRIPT=Pattern.compile("(?is)<script\\b([^>]*)>(.*?)</script\\s*>");
    private AmazonProductJsonLd(){}
    static JSONObject find(String html, URL page) {
        MarketplaceIdentity identity=MarketplaceIdentity.from(page);
        if(identity==null||identity.site!=MarketplaceIdentity.Site.AMAZON||!identity.verified(html,page))return null;
        List<JSONObject> products=new ArrayList<>();
        Matcher scripts=SCRIPT.matcher(html);
        while(scripts.find()){
            if(!scripts.group(1).toLowerCase(Locale.ROOT).contains("application/ld+json"))continue;
            try{
                String raw=scripts.group(2).trim().replaceAll("(?s)^<!--|-->$","");
                Object json=raw.startsWith("[")?new JSONArray(raw):new JSONObject(raw);
                collect(json,products,0);
            }catch(Exception ignored){}
        }
        if(products.isEmpty())return null;
        JSONObject matched=null;
        int count=0;
        for(JSONObject product:products){
            if(matches(product,identity,page)) {matched=product;count++;}
        }
        if(count==1)return matched;
        if(count>1)return null;
        if(products.size()!=1)return null;
        // A sole JSON-LD Product may be the principal item, but only if it has
        // no contradictory URL/ASIN/sku pointing to another item.
        JSONObject sole=products.get(0);
        if(hasExplicitIdentity(sole))return null;
        return sole;
    }
    private static boolean hasExplicitIdentity(JSONObject p){
        for(String k:new String[]{"url","@id","mainEntityOfPage","asin","productID"})
            if(p.has(k)&&!p.isNull(k)&&!p.optString(k,"").isBlank())return true;
        return false;
    }
    private static boolean matches(JSONObject p,MarketplaceIdentity identity,URL page){
        for(String k:new String[]{"url","@id","mainEntityOfPage"})
            if(matchUrl(p.opt(k),identity,page,0))return true;
        if(identity.site==MarketplaceIdentity.Site.AMAZON){
            for(String k:new String[]{"asin","productID","sku","mpn"})
                if(identity.id.equalsIgnoreCase(p.optString(k,"")))return true;
        }
        // SKU is only a weak hint for Rakuten/Yahoo: store code is required for
        // uniqueness, so never match an unrelated merchant's identical SKU.
        return false;
    }
    private static boolean matchUrl(Object val,MarketplaceIdentity identity,URL page,int depth){
        if(val==null||depth>4)return false;
        if(val instanceof JSONArray){
            JSONArray a=(JSONArray)val;
            for(int n=0;n<Math.min(20,a.length());n++)if(matchUrl(a.opt(n),identity,page,depth+1))return true;
        }else if(val instanceof JSONObject){
            JSONObject j=(JSONObject)val;
            return matchUrl(j.opt("url"),identity,page,depth+1)||matchUrl(j.opt("@id"),identity,page,depth+1);
        }else if(val instanceof String){
            try{return identity.matches(new URL(page,(String)val));}catch(Exception ignored){}
        }
        return false;
    }
    private static void collect(Object val,List<JSONObject> list,int depth){
        if(val==null||depth>11||list.size()>70)return;
        if(val instanceof JSONArray){
            JSONArray a=(JSONArray)val;
            for(int i=0;i<Math.min(80,a.length());i++)collect(a.opt(i),list,depth+1);
        }else if(val instanceof JSONObject){
            JSONObject o=(JSONObject)val;
            if(isProduct(o.opt("@type")))list.add(o);
            for(String k:new String[]{"@graph","mainEntity","itemListElement","item","about","hasPart"})collect(o.opt(k),list,depth+1);
        }
    }
    private static boolean isProduct(Object t){
        if(t instanceof JSONArray){JSONArray a=(JSONArray)t;for(int i=0;i<a.length();i++)if(isProduct(a.opt(i)))return true;}
        if(t instanceof String){String x=((String)t).toLowerCase(Locale.ROOT);return x.equals("product")||x.endsWith("/product")||x.endsWith(":product");}
        return false;
    }
}
