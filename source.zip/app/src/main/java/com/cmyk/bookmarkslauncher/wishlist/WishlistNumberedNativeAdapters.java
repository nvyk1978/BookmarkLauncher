package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;

/** Actually executes the original site-specific inspector on its own product.
 * For foreign merchants, the numbered survey executes portable evidence
 * templates without borrowing the original site's identity or SKU. */
final class WishlistNumberedNativeAdapters {
    private WishlistNumberedNativeAdapters() { }
    static String javascript(URL url, int id) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())) return null;
        final String host=url.getHost().toLowerCase(java.util.Locale.ROOT);
        switch (id) {
            case 8:
                if (host.equals("hiraki.co.jp") || host.equals("www.hiraki.co.jp"))
                    return HirakiStockDom.stockEvidence(url.getPath().replaceAll("/+$", "").replaceAll(".*/", ""));
                break;
            case 9:
                if (host.equals("eshop.fumuroya.com"))return WishlistIndependentStockDom.javascript(host);
                break;
            case 10:
                if (host.equals("e-mono.jr-central.co.jp"))return WishlistIndependentStockDom.javascript(host);
                break;
            case 11:
                if (WishlistHonmaProductDom.isDetail(url))return WishlistHonmaProductDom.stockJavascript(url);
                break;
            case 12:
                if ("ASKUL".equals(GeneralRetailIdentity.store(url))) {
                    String sku=GeneralRetailIdentity.itemId(url);
                    if(sku!=null)return AskulProductDom.stockEvidence(sku);
                }
                break;
            case 14:
                if (host.equals("yuican-shop.com"))return WishlistRemainingStockDom.javascript(host);
                break;
            case 19:
                if (WishlistGeneralShopItem.merchant(url)==WishlistGeneralShopItem.Merchant.GU)
                    return WishlistGuVariantStockDom.javascript(url);
                break;
            case 20: case 21: case 22:
                WishlistRetailDedicatedMode m=WishlistRetailDedicatedMode.forUrl(url);
                if ((id==20&&m==WishlistRetailDedicatedMode.EDION)
                        ||(id==21&&m==WishlistRetailDedicatedMode.AU)
                        ||(id==22&&m==WishlistRetailDedicatedMode.ISETAN))
                    return WishlistRetailDedicatedStockDom.javascript(url);
                break;
            case 36:
                if (WishlistRetailDedicatedMode.forUrl(url)==WishlistRetailDedicatedMode.ZOZO)
                    return WishlistRetailDedicatedStockDom.javascript(url);
                break;
            case 37:
                if (WishlistGeneralShopItem.merchant(url)==WishlistGeneralShopItem.Merchant.MERCARI)
                    return WishlistMercariItemStockDom.javascript(url);
                break;
            default: break;
        }
        return null;
    }
}
