package com.cmyk.bookmarkslauncher.offline;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.PathInterpolator;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.SystemBarScrim;
import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;
import com.cmyk.bookmarkslauncher.googlemaps.GoogleMapsModule;
import com.cmyk.bookmarkslauncher.youtube.YouTubeModule;

import java.io.File;

/**
 * Normal-web-only MHTML viewer/saver. The archive is external SAF data; app storage is
 * used only as a short-lived WebView staging cache.
 */
public final class OfflineWebActivity extends Activity {
    public static final String EXTRA_NODE_ID = "node_id";
    public static final String EXTRA_AUTO_SAVE_ROOT = "auto_save_root";
    private static final int REQ_TREE = 7031;
    private static final String FLOAT_PREFS = "offline_float_button";
    private static final String KEY_FLOAT_X = "float_x";
    private static final String KEY_FLOAT_Y = "float_y";
    private static final int FLOAT_SIZE_PX = 200;
    private static final int DELETE_TARGET_SIZE_PX = 200;
    private static final long LONG_PRESS_MS = 300L;
    private static final float SNAP_DISTANCE_PX = 300f;
    private static final float RELEASE_DISTANCE_PX = 420f;
    private static final int ICON = 0xFFA9A999;
    private static final int DARK_RED = 0xFF882211;

    private final Handler main = new Handler();
    private FrameLayout root;
    private WebView webView;
    private OfflineFloatingButton floating;
    private TextView deleteTarget;
    private BookmarkRepository repo;
    private BookmarkNode node;
    private Uri folderUri;
    private OfflineStorage.Index index;
    private String currentOriginalUrl;
    private boolean currentSaved;
    private boolean currentIsLocal;
    private boolean saving;
    private boolean pendingUpdateAfterOnlineLoad;
    private boolean autoSaveRoot;

    // FinderlessCamera v0.1.92 floating-shutter gesture state, transplanted 1:1.
    private boolean draggingFloat;
    private boolean snappedToDelete;
    private float downRawX, downRawY, grabOffsetX, grabOffsetY;
    private int downWindowX, downWindowY;
    private long downTimeMs;
    private Runnable longPressRunnable;

    public static void open(Activity activity, String nodeId) {
        Intent i = new Intent(activity, OfflineWebActivity.class);
        i.putExtra(EXTRA_NODE_ID, nodeId);
        activity.startActivity(i);
    }

    /** Opens the root page online and saves it immediately after the page settles. */
    public static void openAndSave(Activity activity, String nodeId) {
        Intent i = new Intent(activity, OfflineWebActivity.class);
        i.putExtra(EXTRA_NODE_ID, nodeId);
        i.putExtra(EXTRA_AUTO_SAVE_ROOT, true);
        activity.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0x80000000);
        getWindow().setNavigationBarColor(0xFF303030);
        String nodeId = getIntent().getStringExtra(EXTRA_NODE_ID);
        autoSaveRoot = getIntent().getBooleanExtra(EXTRA_AUTO_SAVE_ROOT, false);
        repo = new BookmarkRepository(this);
        node = repo.get(nodeId);
        if (node == null || node.url == null || node.url.isBlank()
                || GoogleMapsModule.handles(node.url) || YouTubeModule.handles(node.url)) {
            finish();
            return;
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF303030);
        setContentView(root);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        // Offline viewer always starts width-fitted. Keep pinch zoom available afterwards.
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setBlockNetworkLoads(false);
        webView.setInitialScale(0);
        webView.setHorizontalScrollBarEnabled(false);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        SystemBarScrim.apply(this, root);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(request == null ? null : request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    currentOriginalUrl = OfflineStorage.canonicalize(url);
                    currentIsLocal = false;
                    refreshSavedState();
                    if (pendingUpdateAfterOnlineLoad) {
                        pendingUpdateAfterOnlineLoad = false;
                        main.postDelayed(OfflineWebActivity.this::saveLoadedOnlinePage, 900L);
                    }
                }
            }
        });

        addFloatingButton();
        restoreStorage();
        openInitial();
    }

    private void restoreStorage() {
        if (node.offlinePath != null && !node.offlinePath.isBlank()) {
            try { folderUri = Uri.parse(node.offlinePath); } catch (Exception ignored) { }
        }
        index = OfflineStorage.loadIndex(this, folderUri);
    }

    private void openInitial() {
        String rootUrl = OfflineStorage.canonicalize(node.url);
        OfflineStorage.Page page = OfflineStorage.find(index, rootUrl);

        if (autoSaveRoot) {
            currentOriginalUrl = rootUrl;
            currentIsLocal = false;
            currentSaved = page != null;
            pendingUpdateAfterOnlineLoad = true;
            saving = true;
            updateFloatingIcon();
            Toast.makeText(this,
                    currentSaved ? "更新ページを読み込んでいます" : "保存ページを読み込んでいます",
                    Toast.LENGTH_SHORT).show();
            if (!isNetworkAvailable()) {
                saving = false;
                pendingUpdateAfterOnlineLoad = false;
                if (page != null && openSaved(page.url)) return;
                Toast.makeText(this, "ネットワークに接続してください", Toast.LENGTH_SHORT).show();
                return;
            }
            applyOnlineMode();
            webView.loadUrl(node.url);
            return;
        }

        if (page == null && node.offlineSavedAt != null && index != null && !index.pages.isEmpty()) {
            page = index.pages.values().iterator().next();
        }
        if (page != null && openSaved(page.url)) return;
        currentOriginalUrl = rootUrl;
        currentIsLocal = false;
        currentSaved = false;
        updateFloatingIcon();
        if (!isNetworkAvailable()) {
            Toast.makeText(this, "このページは保存されていません", Toast.LENGTH_SHORT).show();
            return;
        }
        applyOnlineMode();
        webView.loadUrl(node.url);
    }

    private boolean routeUrl(String url) {
        if (url == null) return false;
        if (!url.startsWith("http://") && !url.startsWith("https://")) return false;
        String canonical = OfflineStorage.canonicalize(url);
        if (pendingUpdateAfterOnlineLoad && currentOriginalUrl != null
                && currentOriginalUrl.equals(canonical)) {
            return false;
        }
        OfflineStorage.Page saved = OfflineStorage.find(index, canonical);
        if (saved != null && openSaved(canonical)) return true;
        if (!isNetworkAvailable()) {
            Toast.makeText(this, "このページは保存されていません", Toast.LENGTH_SHORT).show();
            return true;
        }
        applyOnlineMode();
        currentOriginalUrl = canonical;
        currentIsLocal = false;
        currentSaved = false;
        updateFloatingIcon();
        return false;
    }

    private boolean openSaved(String url) {
        try {
            OfflineStorage.Page page = OfflineStorage.find(index, url);
            if (page == null || folderUri == null) return false;
            File local = OfflineStorage.materializePage(this, folderUri, page);
            if (local == null || !local.isFile()) return false;
            currentOriginalUrl = page.url;
            currentSaved = true;
            currentIsLocal = true;
            updateFloatingIcon();
            applyOfflineMode();
            webView.loadUrl(Uri.fromFile(local).toString());
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private void applyOfflineMode() {
        if (webView == null) return;
        WebSettings s = webView.getSettings();
        // A saved page must stand on the MHTML alone. Do not let JavaScript or network
        // requests quietly fill in missing content while the device is online.
        s.setJavaScriptEnabled(false);
        s.setDomStorageEnabled(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        try { s.setBlockNetworkLoads(true); } catch (Throwable ignored) { }
        try { webView.setNetworkAvailable(false); } catch (Throwable ignored) { }
    }

    private void applyOnlineMode() {
        if (webView == null) return;
        WebSettings s = webView.getSettings();
        try { s.setBlockNetworkLoads(false); } catch (Throwable ignored) { }
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        try { webView.setNetworkAvailable(isNetworkAvailable()); } catch (Throwable ignored) { }
    }

    private boolean isNetworkAvailable() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void refreshSavedState() {
        currentSaved = OfflineStorage.find(index, currentOriginalUrl) != null;
        updateFloatingIcon();
    }

    private void updateFloatingIcon() {
        if (floating != null) floating.setSaved(currentSaved);
    }

    private void onFloatingTap() {
        if (saving) return;
        if (currentOriginalUrl == null || currentOriginalUrl.isBlank()) return;
        if (currentSaved && currentIsLocal) {
            // Updating a saved MHTML must reload the original network URL first.
            if (!isNetworkAvailable()) {
                Toast.makeText(this, "ネットワークに接続してください", Toast.LENGTH_SHORT).show();
                return;
            }
            pendingUpdateAfterOnlineLoad = true;
            saving = true;
            Toast.makeText(this, "更新ページを読み込んでいます", Toast.LENGTH_SHORT).show();
            applyOnlineMode();
            webView.loadUrl(currentOriginalUrl);
            return;
        }
        beginSaveCurrent();
    }

    private void beginSaveCurrent() {
        if (!isNetworkAvailable()) {
            saving = false;
            Toast.makeText(this, "ネットワークに接続してください", Toast.LENGTH_SHORT).show();
            return;
        }
        applyOnlineMode();
        if (OfflineStorage.getTreeUri(this) == null) {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, REQ_TREE);
            return;
        }
        saveLoadedOnlinePage();
    }

    private void saveLoadedOnlinePage() {
        if (webView == null || currentOriginalUrl == null) { saving = false; return; }
        String shown = webView.getUrl();
        if (shown == null || (!shown.startsWith("http://") && !shown.startsWith("https://"))) {
            saving = false;
            return;
        }
        saving = true;
        floating.setAlpha(0.55f);
        try {
            if (folderUri == null) folderUri = OfflineStorage.ensureBookmarkFolder(this, node);
            if (folderUri == null) {
                saving = false;
                floating.setAlpha(1f);
                beginSaveCurrent();
                return;
            }
            final String sourceUrl = OfflineStorage.canonicalize(currentOriginalUrl);
            final String title = webView.getTitle();
            File temp = new File(getCacheDir(), "offline_capture_" + System.currentTimeMillis() + ".mhtml");
            webView.saveWebArchive(temp.getAbsolutePath(), false, path -> main.post(() -> {
                try {
                    File archive = path == null ? temp : new File(path);
                    if (!archive.isFile() || archive.length() == 0L) throw new IllegalStateException("archive empty");
                    boolean wasSaved = OfflineStorage.find(index, sourceUrl) != null;
                    OfflineStorage.Page page = OfflineStorage.putArchive(
                            OfflineWebActivity.this, folderUri, index, sourceUrl, title, archive);
                    if (page == null) throw new IllegalStateException("archive write failed");
                    OfflineStorage.saveIndex(OfflineWebActivity.this, folderUri, node, index);
                    repo.updateOfflineState(node.id, folderUri.toString(), page.savedAt);
                    node = repo.get(node.id);
                    currentSaved = true;
                    Toast.makeText(OfflineWebActivity.this,
                            wasSaved ? "このページを更新しました" : "このページを保存しました",
                            Toast.LENGTH_SHORT).show();
                    updateFloatingIcon();
                    openSaved(sourceUrl);
                } catch (Throwable t) {
                    Toast.makeText(OfflineWebActivity.this, "オフライン保存に失敗しました", Toast.LENGTH_SHORT).show();
                } finally {
                    saving = false;
                    floating.setAlpha(1f);
                    try { temp.delete(); } catch (Throwable ignored) { }
                }
            }));
        } catch (Throwable t) {
            saving = false;
            floating.setAlpha(1f);
            Toast.makeText(this, "保存先を利用できません", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_TREE) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            saving = false;
            return;
        }
        Uri tree = data.getData();
        int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(tree, takeFlags); } catch (Throwable ignored) { }
        OfflineStorage.setTreeUri(this, tree);
        folderUri = null;
        beginSaveCurrent();
    }

    private void addFloatingButton() {
        floating = new OfflineFloatingButton(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FLOAT_SIZE_PX, FLOAT_SIZE_PX, Gravity.TOP | Gravity.START);
        root.addView(floating, lp);
        root.post(() -> {
            int maxX = Math.max(0, root.getWidth() - FLOAT_SIZE_PX);
            int maxY = Math.max(0, root.getHeight() - FLOAT_SIZE_PX);
            // New default: sit close to the lower-right edge. A user-moved saved position still wins.
            int defaultX = Math.max(0, root.getWidth() - FLOAT_SIZE_PX - dp(16));
            int defaultY = Math.max(0, root.getHeight() - FLOAT_SIZE_PX - dp(20));
            android.content.SharedPreferences p = getSharedPreferences(FLOAT_PREFS, MODE_PRIVATE);
            lp.leftMargin = clamp(p.getInt(KEY_FLOAT_X, defaultX), 0, maxX);
            lp.topMargin = clamp(p.getInt(KEY_FLOAT_Y, defaultY), 0, maxY);
            floating.setLayoutParams(lp);
        });
        floating.setOnTouchListener(this::handleFloatingTouch);
    }

    /** Exact FinderlessCamera v0.1.92 floating-shutter gesture thresholds and timing. */
    private boolean handleFloatingTouch(View view, MotionEvent event) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) floating.getLayoutParams();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                draggingFloat = false;
                snappedToDelete = false;
                setDeleteSnapVisual(false);
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                downWindowX = lp.leftMargin;
                downWindowY = lp.topMargin;
                int[] rootLoc = new int[2];
                root.getLocationOnScreen(rootLoc);
                grabOffsetX = event.getRawX() - (rootLoc[0] + lp.leftMargin);
                grabOffsetY = event.getRawY() - (rootLoc[1] + lp.topMargin);
                downTimeMs = System.currentTimeMillis();
                longPressRunnable = () -> {
                    draggingFloat = true;
                    vibrateLongPress();
                    animatePoyon(floating);
                    showDeleteTarget();
                };
                main.postDelayed(longPressRunnable, LONG_PRESS_MS);
                return true;

            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downRawX;
                float dy = event.getRawY() - downRawY;
                if (!draggingFloat && (Math.abs(dx) > 24 || Math.abs(dy) > 24)) {
                    if (longPressRunnable != null) {
                        main.removeCallbacks(longPressRunnable);
                        longPressRunnable = null;
                    }
                }
                if (!draggingFloat) return true;

                int maxX = Math.max(0, root.getWidth() - FLOAT_SIZE_PX);
                int maxY = Math.max(0, root.getHeight() - FLOAT_SIZE_PX);
                int[] loc = new int[2];
                root.getLocationOnScreen(loc);
                float targetCenterX = loc[0] + root.getWidth() / 2f;
                float targetCenterY = loc[1] + root.getHeight() / 2f;
                float fingerDistance = distance(event.getRawX(), event.getRawY(), targetCenterX, targetCenterY);

                if (!snappedToDelete && fingerDistance <= SNAP_DISTANCE_PX) {
                    snappedToDelete = true;
                    setDeleteSnapVisual(true);
                    animateDeleteTargetScale(true);
                    lp.leftMargin = clamp(Math.round(root.getWidth() / 2f - FLOAT_SIZE_PX / 2f), 0, maxX);
                    lp.topMargin = clamp(Math.round(root.getHeight() / 2f - FLOAT_SIZE_PX / 2f), 0, maxY);
                    floating.setLayoutParams(lp);
                    return true;
                }

                if (snappedToDelete) {
                    if (fingerDistance >= RELEASE_DISTANCE_PX) {
                        snappedToDelete = false;
                        setDeleteSnapVisual(false);
                        animateDeleteTargetScale(false);
                        lp.leftMargin = clamp(Math.round(event.getRawX() - loc[0] - grabOffsetX), 0, maxX);
                        lp.topMargin = clamp(Math.round(event.getRawY() - loc[1] - grabOffsetY), 0, maxY);
                        floating.setLayoutParams(lp);
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        downWindowX = lp.leftMargin;
                        downWindowY = lp.topMargin;
                        return true;
                    }
                    return true;
                }

                lp.leftMargin = clamp(downWindowX + Math.round(dx), 0, maxX);
                lp.topMargin = clamp(downWindowY + Math.round(dy), 0, maxY);
                floating.setLayoutParams(lp);
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (longPressRunnable != null) {
                    main.removeCallbacks(longPressRunnable);
                    longPressRunnable = null;
                }
                if (draggingFloat) {
                    draggingFloat = false;
                    if (snappedToDelete) {
                        snappedToDelete = false;
                        animateFloatingDelete();
                    } else {
                        animateDeleteTargetScale(false);
                        setDeleteSnapVisual(false);
                        hideDeleteTarget();
                        saveFloatingPosition();
                    }
                    return true;
                }
                float upDx = Math.abs(event.getRawX() - downRawX);
                float upDy = Math.abs(event.getRawY() - downRawY);
                long heldMs = System.currentTimeMillis() - downTimeMs;
                if (heldMs < LONG_PRESS_MS && upDx < 24 && upDy < 24) onFloatingTap();
                return true;
            default:
                return false;
        }
    }

    private void vibrateLongPress() {
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(40L, 200));
        else v.vibrate(40L);
    }

    private void animatePoyon(View v) {
        if (v == null) return;
        v.animate().cancel();
        v.animate().scaleX(1.18f).scaleY(1.18f)
                .setDuration(45L).setInterpolator(new AccelerateInterpolator())
                .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f)
                        .setDuration(155L).setInterpolator(new DecelerateInterpolator()).start())
                .start();
    }

    private void showDeleteTarget() {
        if (deleteTarget != null) return;
        deleteTarget = new TextView(this);
        deleteTarget.setText("×");
        deleteTarget.setTextSize(54f);
        deleteTarget.setTextColor(Color.WHITE);
        deleteTarget.setGravity(Gravity.CENTER);
        deleteTarget.setAlpha(0f);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(DELETE_TARGET_SIZE_PX, DELETE_TARGET_SIZE_PX, Gravity.TOP | Gravity.START);
        p.leftMargin = Math.round(root.getWidth() / 2f - DELETE_TARGET_SIZE_PX / 2f);
        p.topMargin = Math.round(root.getHeight() / 2f - DELETE_TARGET_SIZE_PX / 2f - 16f);
        root.addView(deleteTarget, p);
        deleteTarget.animate().alpha(1f).setDuration(120L).start();
    }

    private void hideDeleteTarget() {
        if (deleteTarget == null) return;
        TextView target = deleteTarget;
        deleteTarget = null;
        target.animate().alpha(0f).setDuration(100L).withEndAction(() -> root.removeView(target)).start();
    }

    private void setDeleteSnapVisual(boolean snapped) {
        int color = snapped ? DARK_RED : ICON;
        if (floating != null) floating.setIconColor(color);
        if (deleteTarget != null) deleteTarget.setTextColor(color);
    }

    private void animateDeleteTargetScale(boolean expand) {
        if (deleteTarget == null) return;
        float targetScale = expand ? 2f : 1f;
        deleteTarget.animate().scaleX(targetScale).scaleY(targetScale)
                .setDuration(expand ? 1000L : 500L)
                .setInterpolator(expand
                        ? new PathInterpolator(0.01f, 0.98f, 0.04f, 1.00f)
                        : new PathInterpolator(0.85f, 0.00f, 1.00f, 0.20f))
                .start();
    }

    private void animateFloatingDelete() {
        getSharedPreferences(FLOAT_PREFS, MODE_PRIVATE).edit().remove(KEY_FLOAT_X).remove(KEY_FLOAT_Y).apply();
        if (deleteTarget != null) {
            deleteTarget.animate().scaleX(0f).scaleY(0f).alpha(0f)
                    .setDuration(1000L)
                    .setInterpolator(new PathInterpolator(0.97f, 0.00f, 1.00f, 0.02f)).start();
        }
        if (floating == null) return;
        OfflineFloatingButton target = floating;
        target.animate().scaleX(0f).scaleY(0f).setDuration(500L)
                .setInterpolator(new PathInterpolator(0.97f, 0.00f, 1.00f, 0.02f))
                .withEndAction(() -> {
                    target.setVisibility(View.INVISIBLE);
                    hideDeleteTarget();
                }).start();
    }

    private void saveFloatingPosition() {
        if (floating == null) return;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) floating.getLayoutParams();
        int maxX = Math.max(0, root.getWidth() - FLOAT_SIZE_PX);
        int maxY = Math.max(0, root.getHeight() - FLOAT_SIZE_PX);
        lp.leftMargin = clamp(lp.leftMargin, 0, maxX);
        lp.topMargin = clamp(lp.topMargin, 0, maxY);
        floating.setLayoutParams(lp);
        getSharedPreferences(FLOAT_PREFS, MODE_PRIVATE).edit()
                .putInt(KEY_FLOAT_X, lp.leftMargin).putInt(KEY_FLOAT_Y, lp.topMargin).apply();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(v, max)); }
    private static float distance(float x1, float y1, float x2, float y2) {
        float dx = x1 - x2, dy = y1 - y2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (longPressRunnable != null) main.removeCallbacks(longPressRunnable);
        if (webView != null) {
            try { webView.stopLoading(); webView.destroy(); } catch (Throwable ignored) { }
            webView = null;
        }
        super.onDestroy();
    }
}
