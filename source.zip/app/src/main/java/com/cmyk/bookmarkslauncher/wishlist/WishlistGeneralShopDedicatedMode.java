package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;

/** GU and Mercari are exact-item, independently inspected GENERAL submodes.
 * Persisted acquisition mode and the existing verified price/image pathways
 * remain unchanged; this class only gates site-specific routes and UI labels. */
public enum WishlistGeneralShopDedicatedMode {
    NONE, GU, MERCARI;

    public static WishlistGeneralShopDedicatedMode forUrl(URL original) {
        WishlistGeneralShopItem.Merchant merchant = WishlistGeneralShopItem.merchant(original);
        if (merchant == WishlistGeneralShopItem.Merchant.GU) return GU;
        if (merchant == WishlistGeneralShopItem.Merchant.MERCARI) return MERCARI;
        return NONE;
    }

    public static WishlistGeneralShopDedicatedMode fromSavedUrl(String raw) {
        if (raw == null) return NONE;
        try { return forUrl(new URL(raw)); }
        catch (Exception ignored) { return NONE; }
    }

    public String liveLabel() {
        if (this == GU) return "GU専用モード";
        if (this == MERCARI) return "メルカリ専用モード";
        return "GENERALモード";
    }
}
