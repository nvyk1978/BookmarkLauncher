package com.cmyk.bookmarkslauncher;

import android.content.Context;
import com.cmyk.bookmarkslauncher.wishlist.WishlistItem;
import com.cmyk.bookmarkslauncher.wishlist.WishlistRepository;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** One physical event file per immutable Wish item ID.  Never parses or clears
 * the application's full diagnostic log, or another card's log. */
public final class WishlistCardDiagnostics {
    private static final String DIRECTORY = "wishlist-card-diagnostics";
    private static final long MAX_BYTES = 192_000;
    private static final SimpleDateFormat FORMAT =
            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.JAPAN);
    private WishlistCardDiagnostics() { }

    private static File file(Context ctx, String itemId) {
        if (ctx == null || itemId == null || !itemId.matches("[a-zA-Z0-9_-]{1,90}")) return null;
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(itemId.getBytes(StandardCharsets.UTF_8));
            StringBuilder name = new StringBuilder();
            for (byte b : digest) name.append(String.format(Locale.ROOT, "%02x", b & 255));
            File dir = new File(ctx.getApplicationContext().getFilesDir(), DIRECTORY);
            return new File(dir, name.toString() + ".log");
        } catch (Exception ignored) { return null; }
    }

    /** No product titles, URLs, cookies, or credentials are written. */
    public static synchronized void event(Context ctx, String itemId, String phase, String detail) {
        File f = file(ctx, itemId);
        if (f == null) return;
        try {
            File dir = f.getParentFile();
            if (dir == null || (!dir.exists() && !dir.mkdirs())) return;
            if (f.exists() && f.length() > MAX_BYTES) {
                // Capped storage: retain only new per-card records after rollover.
                try (FileOutputStream ignored = new FileOutputStream(f, false)) { }
            }
            String cleanPhase = scrub(phase, 48);
            String cleanDetail = scrub(detail, 360);
            String line = FORMAT.format(new Date()) + " " + cleanPhase + " " + cleanDetail + "\n";
            try (FileOutputStream out = new FileOutputStream(f, true)) {
                out.write(line.getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) { }
    }

    private static String scrub(String input, int maximum) {
        String s = input == null ? "-" : input.replaceAll("(?i)https?://\\S+", "[URL]")
                .replaceAll("(?i)(cookie|authorization|token|password|secret)\\s*[:=]\\s*[^\\s,]+", "[private]")
                .replace('\n', ' ').replace('\r', ' ');
        return s.length() > maximum ? s.substring(0, maximum) : s;
    }

    private static synchronized String read(Context ctx, String itemId) {
        File f = file(ctx, itemId);
        if (f == null || !f.isFile()) return "ログはまだありません。\n";
        StringBuilder content = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) content.append(line).append('\n');
        } catch (Exception ex) { return "ログ読込エラー\n"; }
        return content.length() == 0 ? "ログはまだありません。\n" : content.toString();
    }

    public static synchronized void clear(Context ctx, String itemId) {
        File f = file(ctx, itemId);
        if (f != null && f.exists()) f.delete();
    }

    public static synchronized String report(Context ctx, String itemId) {
        StringBuilder result = new StringBuilder();
        result.append("Wish card ID: ").append(itemId == null ? "unknown" : itemId).append('\n');
        try {
            WishlistRepository repo = new WishlistRepository(ctx);
            WishlistItem i = repo.get(itemId);
            if (i != null) {
                result.append("Mode: ").append(i.acquisitionMode).append('\n');
                result.append("Site state: ").append(i.siteState).append('\n');
                result.append("Availability: ").append(i.status).append('\n');
                result.append("Last confirmed: ").append(i.lastConfirmedStatus).append('\n');
                result.append("Registered price: ").append(i.registeredPrice).append('\n');
                result.append("Current price: ").append(i.currentPrice).append('\n');
                result.append("Price quote: ").append(i.priceQuoteKind).append('\n');
                result.append("Minimum price: ").append(i.priceMinimum).append('\n');
                result.append("Last price checked: ").append(i.lastPriceCheckedAt).append('\n');
                result.append("Price fetch OK: ").append(i.priceFetchOk).append('\n');
                result.append("Price error: ").append(scrub(i.lastPriceError, 180)).append('\n');
                result.append("Saved preview usable: ")
                        .append(repo.hasUsablePreview(itemId)).append('\n');
                result.append("User edited image: ").append(i.userImageEdited).append('\n');
            } else result.append("Card not found\n");
        } catch (Exception ignored) { result.append("Card state unavailable\n"); }
        result.append("\n").append(read(ctx, itemId));
        return DiagLog.formatReport(ctx, result.toString());
    }
}
