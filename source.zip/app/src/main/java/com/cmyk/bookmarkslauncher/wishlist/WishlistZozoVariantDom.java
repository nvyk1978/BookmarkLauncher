package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/**
 * G: read-only variant-local stock engine derived from ZOZOTOWN's product UI.
 * Only item-matched explicit stock and an enabled variant cart can return
 * AVAILABLE. A goods link without ?did reports product-level availability when
 * any one locally verifiable variant is purchasable. A URL specifying ?did must
 * verify the SAME detail id on the matched variant; no implicit default sizes.
 * No clicks, navigation, cookies, tokens, or form values are collected.
 */
public final class WishlistZozoVariantDom {
    private WishlistZozoVariantDom() { }

    public static boolean supports(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())) return false;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        return (host.equals("zozo.jp") || host.equals("www.zozo.jp"))
                && url.getPath().toLowerCase(Locale.ROOT)
                .matches("^/shop/[a-z0-9_-]+/goods(?:-sale)?/[0-9]{5,15}/?$");
    }

    public static String javascript(URL url) {
        if (!supports(url)) return "JSON.stringify({status:'UNKNOWN',reason:'not-zozo-item'})";
        String path = url.getPath().replaceAll("/+$", "");
        String goodsId = path.substring(path.lastIndexOf('/') + 1);
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?i)(?:^|&)did=([0-9]{5,18})(?:&|$)")
                .matcher(url.getQuery() == null ? "" : url.getQuery());
        String did = m.find() ? m.group(1) : "";
        // If did is present but malformed, refuse variant matching.
        if (url.getQuery() != null && url.getQuery().matches("(?i)(?:^|.*&)did=.*") && did.isEmpty())
            return "JSON.stringify({status:'UNKNOWN',reason:'invalid-variant-id'})";
        return SCRIPT.replace("__HOST__", JSONObject.quote(url.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(path))
                .replace("__GOODS__", JSONObject.quote(goodsId))
                .replace("__DID__", JSONObject.quote(did));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const r={status:'UNKNOWN',reason:'pending',product:false,idBound:false,
   variantBound:false,variants:0,liveCarts:0,stockPairs:0,didRequired:false};
 const done=()=>JSON.stringify(r);
 try{
  const host=__HOST__,path=__PATH__,goods=__GOODS__,did=__DID__;
  r.didRequired=!!did;
  if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host||
     location.pathname.replace(/\\/+$/,'').toLowerCase()!==path.toLowerCase()){
    r.reason='document-mismatch';return done();
  }
  const main=document.querySelector('main,[role=main],#main,#contents')||document.body;
  if(!main){r.reason='main-pending';return done();}
  const text=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ').trim();
  const live=e=>{if(!e||e.disabled||e.getAttribute('aria-disabled')==='true')return false;
    for(let x=e;x;x=x.parentElement){if(x.hidden||x.getAttribute('aria-hidden')==='true'||x.hasAttribute('inert'))return false;
      const s=getComputedStyle(x);if(s.display==='none'||s.visibility!=='visible'||Number(s.opacity)===0)return false;}return true;};
  const title=[...main.querySelectorAll('h1')].filter(live);
  if(title.length!==1||text(title[0]).length<3){r.reason='heading-unverified';return done();}
  r.product=true;
  // ZOZO labels a distinct inquiry number, commonly goods + 1,000,000.
  // Require its explicit '（ZOZO）' suffix; a second (店舗) code is unrelated.
  const expected=String(Number(goods)+1000000);
  const labels=[...text(main).slice(0,100000)
    .matchAll(/問い合わせ番号\\s*[:：]?\\s*([0-9]{5,15})\\s*[（(]ZOZO[）)]/g)];
  r.idBound=labels.some(x=>x[1]===goods||x[1]===expected);
  if(!r.idBound){r.reason='zozo-inquiry-id-unverified';return done();}
  const bad='header,nav,footer,aside,[class*=recommend],[class*=related],[class*=ranking],'+
    '[class*=carousel],[class*=pickup],[id*=recommend],[id*=related]';
  const controls=[...main.querySelectorAll('button,[role=button],a[href],input[type=submit]')]
    .filter(c=>live(c)&&!c.closest(bad)&&/カート\\s*に\\s*入れる|かご\\s*に\\s*入れる|add\\s*to\\s*cart/i
       .test([text(c),c.value,c.getAttribute('aria-label')].filter(Boolean).join(' ').slice(0,120)));
  r.liveCarts=controls.length;
  if(!controls.length){r.reason='no-variant-cart';return done();}
  for(const c of controls.slice(0,70)){
    let row=null;
    // Pick the smallest visible local row containing ONE cart control and
    // its own positive variant stock, not all colours/sizes on the page.
    for(let x=c.parentElement,k=0;x&&k<6&&main.contains(x);x=x.parentElement,k++){
      if(!live(x))continue;
      const t=text(x);
      if(t.length>500)break;
      if(!/在庫あり|残り\\s*[0-9]+\\s*点|在庫残少|残りわずか/i.test(t))continue;
      if(/在庫なし|在庫切れ|完売|売り切れ|予約商品|予約受付/i.test(t))continue;
      const inRow=[...x.querySelectorAll('button,[role=button],a[href],input[type=submit]')]
        .filter(v=>live(v)&&/カート\\s*に\\s*入れる|かご\\s*に\\s*入れる/i.test(text(v)));
      if(inRow.length!==1||inRow[0]!==c)continue;
      row=x;break;
    }
    if(!row)continue;
    r.variants++;
    if(did){
      // A URL with ?did=<detailID> is variant-specific: DOM binding is
      // mandatory, never assume the first/default available size is it.
      let bound=false;
      for(let a=c,k=0;a&&k<6&&main.contains(a);a=a.parentElement,k++){
        const attr=[a.getAttribute('data-did'),a.getAttribute('data-detail-id'),
          a.getAttribute('data-variant-id'),a.getAttribute('href')].filter(Boolean).join(' ');
        if(new RegExp('(?:^|[^0-9])'+did+'(?:$|[^0-9])').test(attr)){bound=true;break;}
      }
      if(!bound)continue;
      r.variantBound=true;
    } else r.variantBound=true; // Product URL without a selected SKU.
    r.stockPairs++;
  }
  if(r.stockPairs>0&&r.idBound&&r.variantBound){
    r.status='AVAILABLE';r.reason='same-zozo-product-variant-stock-cart';
  }else r.reason=did?'selected-variant-unverified':'variant-stock-unverified';
  return done();
 }catch(_){r.reason='dom-error';return done();}
})()
""";
}
