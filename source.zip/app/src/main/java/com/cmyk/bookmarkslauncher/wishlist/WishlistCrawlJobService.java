package com.cmyk.bookmarkslauncher.wishlist;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import android.os.Build;

import com.cmyk.bookmarkslauncher.MainActivity;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class WishlistCrawlJobService extends JobService {
    public static final String CHANNEL_ID = "wishlist_resume_watch";
    private ExecutorService executor;

    @Override public boolean onStartJob(JobParameters params) {
        if (executor != null) executor.shutdownNow();
        final ExecutorService runExecutor = Executors.newSingleThreadExecutor();
        executor = runExecutor;
        runExecutor.execute(() -> {
            boolean reschedule = false;
            try {
                WishlistRepository repo = new WishlistRepository(this);
                List<WishlistItem> items = repo.listAll();
                for (WishlistItem before : items) {
                    if (Thread.currentThread().isInterrupted()) break;
                    if (before.url == null || before.url.isBlank()) continue;
                    WishlistCrawler.Result result = WishlistCrawler.fetch(before);
                    repo.updateCrawl(before.id, result);
                    WishlistItem after = repo.get(before.id);
                    if (before.monitorResume && becameAvailable(before.status, after == null ? null : after.status)) {
                        notifyResume(after == null ? before : after);
                    }
                    try {
                        Thread.sleep(900L);
                    } catch (InterruptedException ignored) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            } catch (RuntimeException error) {
                reschedule = true;
            } finally {
                jobFinished(params, reschedule);
                runExecutor.shutdown();
                if (executor == runExecutor) executor = null;
            }
        });
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) {
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
        return true;
    }

    private static boolean becameAvailable(String oldStatus, String newStatus) {
        if (!"AVAILABLE".equals(newStatus)) return false;
        return "UNAVAILABLE".equals(oldStatus) || "COMING_SOON".equals(oldStatus);
    }

    private void notifyResume(WishlistItem item) {
        if (item == null) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "Wishlist 再開通知", NotificationManager.IMPORTANCE_DEFAULT));
        }
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("wishlist_item_id", item.id);
        PendingIntent pi = PendingIntent.getActivity(this, item.id.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String price = item.currentPrice == null ? "" : "  ¥" + String.format("%,d", item.currentPrice);
        android.app.Notification n = new android.app.Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(com.cmyk.bookmarkslauncher.R.drawable.ic_launcher)
                .setContentTitle("Wishlist 再開")
                .setContentText((item.title == null ? "商品" : item.title) + " が購入可能になりました" + price)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        try { nm.notify(item.id.hashCode(), n); } catch (SecurityException ignored) { }
    }
}
