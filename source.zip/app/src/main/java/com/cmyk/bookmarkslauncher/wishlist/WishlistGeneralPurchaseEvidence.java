package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Conservative item-local HTML purchase evidence for GENERAL sites only.
 * The marketplace branches never call this adapter. No status is inferred
 * from the absence of a button, a hidden sold-out template, or the footer.
 */
final class WishlistGeneralPurchaseEvidence {
    private static final Pattern H1 = Pattern.compile("(?is)<h1\\b[^>]*>.*?</h1\\s*>");
    private static final Pattern FORM = Pattern.compile("(?is)<form\\b([^>]*)>(.*?)</form\\s*>");
    private static final Pattern CONTROL = Pattern.compile("(?is)<(button|input|a)\\b([^>]*)>(?:((?:(?!</\\1).)*?)</\\1\\s*>)?");
    private static final Pattern QUANTITY = Pattern.compile("(?i)(?:name|id)\\s*=\\s*['\\\"]?(?:[^'\\\"\\s>]*(?:quantity|qty|amount|count|product_data\\[[0-9]+\\]))|type\\s*=\\s*['\\\"]?number");
    private static final Pattern BUY = Pattern.compile("(?i)(?:カートに入れる|カゴに入れる|かごに入れる|買い物かごに入れる|バスケットに入れる|購入する|注文する|買い物かごへ|add[\\s_-]*to[\\s_-]*(?:cart|bag)|add[\\s_-]*cart)");
    private static final Pattern ACTION = Pattern.compile("(?i)(?:cart|basket|checkout\\.add|checkout/add|addtocart|add_to_cart|add-cart)");
    private static final Pattern DISABLED = Pattern.compile("(?i)(?:\\sdisabled(?:\\s|=|>|$)|\\shidden(?:\\s|=|>|$)|aria-disabled\\s*=\\s*['\\\"]?true|aria-hidden\\s*=\\s*['\\\"]?true|display\\s*:\\s*none|visibility\\s*:\\s*hidden)");
    private static final Pattern PRODUCT_MARKER = Pattern.compile("(?i)(?:product|goods|item|detail|purchase|buy|cart|basket)");
    private static final Pattern BODY_TEXT = Pattern.compile("(?s)<[^>]+>");
    private WishlistGeneralPurchaseEvidence() { }

    static WishlistAvailabilityExtractor.Result inspect(String html, URL page) {
        if (html == null || page == null || !WishlistCrawler.isSingleProductPage(page)
                || MarketplaceIdentity.site(page) != MarketplaceIdentity.Site.OTHER) return null;
        // The main item's heading, not a header/sidebar recommendation, anchors
        // the inspection. Without it, an unscoped buy button is never evidence.
        Matcher h1 = H1.matcher(html);
        if (!h1.find()) return null;
        int start = h1.end();
        int end = Math.min(html.length(), start + 17000);
        String scope = html.substring(start, end);
        // Only trim at recognizable section headings; incidental text in a
        // description must not silently hide the real product controls.
        Matcher relatedHeading = Pattern.compile("(?is)<h[2-6]\\b[^>]*>[^<]*(?:関連商品|おすすめ商品|この商品を見た)[^<]*</h[2-6]>").matcher(scope);
        if (relatedHeading.find()) scope = scope.substring(0, relatedHeading.start());
        int qualifying = 0;
        Matcher forms = FORM.matcher(scope);
        while (forms.find()) {
            String attrs = forms.group(1), body = forms.group(2);
            if (DISABLED.matcher(attrs).find()) continue;
            // A variant that has no selected sellable option isn't proof of
            // purchase availability (e.g. size/cover combinations).
            if (unresolvedRequiredVariant(body)) continue;
            boolean quantity = QUANTITY.matcher(body).find();
            boolean cartAction = ACTION.matcher(attrs).find() || ACTION.matcher(body).find();
            boolean ownProduct = containsProductId(body, page);
            if (!(quantity || ownProduct) || !(cartAction || PRODUCT_MARKER.matcher(attrs).find())) continue;
            if (enabledBuyControl(body) && !visibleSoldNotice(body)) qualifying++;
        }
        // JS/image/link carts without a FORM still need a product-local quantity
        // control and a real buy action. This cannot prove stock on a listing.
        if (qualifying == 0 && QUANTITY.matcher(scope).find()
                && !unresolvedRequiredVariant(scope)) {
            Matcher controls = CONTROL.matcher(scope);
            int good = 0;
            while (controls.find()) {
                String tag=controls.group(1).toLowerCase(Locale.ROOT);
                String attrs=controls.group(2);
                if (DISABLED.matcher(attrs).find()) continue;
                String content=(controls.group(3)==null?"":BODY_TEXT.matcher(controls.group(3)).replaceAll(" "));
                String label=attrs+" "+content;
                if (!BUY.matcher(label).find() && !("input".equals(tag) && ACTION.matcher(attrs).find())) continue;
                // A global cart link with no item-specific action isn't enough.
                if ("a".equals(tag) && !ACTION.matcher(attrs).find()) continue;
                if (!"a".equals(tag) && !ACTION.matcher(label).find() && !BUY.matcher(content).find()) continue;
                good++;
            }
            if (good == 1 && !visibleSoldNotice(scope)) qualifying = 1;
        }
        if (qualifying == 1)
            return new WishlistAvailabilityExtractor.Result("AVAILABLE", false, "通常通販サイトの商品固有購入操作（HTML）");
        return null;
    }

    private static boolean unresolvedRequiredVariant(String html) {
        Matcher required = Pattern.compile("(?is)<select\\b[^>]*\\brequired(?:\\s|=|>)[^>]*>(.*?)</select\\s*>").matcher(html);
        while (required.find()) {
            String options = required.group(1);
            // Selection may be controlled by JavaScript at runtime. Do not
            // guess the active variation from pre-rendered HTML.
            if (!Pattern.compile("(?is)<option\\b[^>]*\\bselected(?:\\s|=|>)[^>]*\\bvalue\\s*=\\s*['\"]?[^'\"\\s>]+").matcher(options).find())
                return true;
        }
        return false;
    }

    private static boolean enabledBuyControl(String html) {
        Matcher controls = CONTROL.matcher(html);
        while (controls.find()) {
            String attrs=controls.group(2);
            if (DISABLED.matcher(attrs).find()) continue;
            String content=controls.group(3)==null?"":BODY_TEXT.matcher(controls.group(3)).replaceAll(" ");
            if (BUY.matcher(attrs+" "+content).find()) return true;
        }
        return false;
    }
    private static boolean visibleSoldNotice(String html) {
        // HTML alone cannot distinguish a visible sold-out notice from a hidden
        // template. If both a buy button and item-local sold-out text exist,
        // keep UNKNOWN and let rendered-DOM verification decide.
        String content = html.replaceAll("(?is)<(?:script|style|noscript)\\b[^>]*>.*?</(?:script|style|noscript)\\s*>", " ");
        return Pattern.compile("(?i)(?:売り切れ|売切れ|完売|在庫切れ|sold\\s*out|out\\s*of\\s*stock)").matcher(content).find();
    }
    private static boolean containsProductId(String html, URL page) {
        String query=page.getQuery();
        if (query != null) {
            Matcher id=Pattern.compile("(?i)(?:^|&)(?:product_id|pid|eci_product)=([a-z0-9_-]+)").matcher(query);
            if (id.find()) {
                String value=Pattern.quote(id.group(1));
                return Pattern.compile("(?i)(?:product_id|product_data|item_id|goods_id)[^<>]{0,160}"+value).matcher(html).find();
            }
        }
        Matcher end=Pattern.compile("(?i)(?:/detail/|/view/item/|/item_detail_|/shop/g/g)([a-z0-9_-]+)").matcher(page.getPath());
        if (!end.find()) return false;
        return Pattern.compile("(?i)(?:product_id|item_id|goods_id|product_code|sku)[^<>]{0,160}"+Pattern.quote(end.group(1))).matcher(html).find();
    }
}
