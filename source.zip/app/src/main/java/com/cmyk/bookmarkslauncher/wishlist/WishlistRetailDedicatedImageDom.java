package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/** Independent read-only ZOZO gallery, never used for Joshin or other shops. */
public final class WishlistRetailDedicatedImageDom {
    private WishlistRetailDedicatedImageDom() { }

    public static String javascript(URL url) {
        if (WishlistRetailDedicatedMode.forUrl(url) != WishlistRetailDedicatedMode.ZOZO)
            return "JSON.stringify([])";
        return SCRIPT.replace("__HOST__", JSONObject.quote(url.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(url.getPath().replaceAll("/+$", "").toLowerCase(Locale.ROOT)))
                .replace("__GOODS__", JSONObject.quote(WishlistRetailDedicatedMode.zozoGoodsId(url)));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 try{
  const host=__HOST__,path=__PATH__,goods=__GOODS__;
  const empty=()=>JSON.stringify([]),clean=s=>String(s||'').toLowerCase().replace(/\\/+$/,'');
  if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host||
     clean(location.pathname)!==path)return empty();
  const main=document.querySelector('main,[role=main],#main,#contents,#content')||document.body;
  if(!main)return empty();
  const bad='header,nav,footer,aside,[class*=recommend],[class*=related],'+
    '[class*=ranking],[class*=pickup],[id*=recommend],[id*=related]';
  const live=e=>{if(!e||e.closest(bad))return false;
    for(let a=e;a;a=a.parentElement){if(a.hidden||a.getAttribute('aria-hidden')==='true')return false;
      const s=getComputedStyle(a);if(s.display==='none'||s.visibility==='hidden')return false;}return true;};
  const titles=[...main.querySelectorAll('h1')].filter(live);
  if(titles.length!==1||String(titles[0].textContent||'').trim().length<3)return empty();
  const canonical=document.querySelector('link[rel=canonical]');
  let verified=false;
  if(canonical&&canonical.href){try{
    const c=new URL(canonical.href,location.href);
    // The canonical may drop ?did or a mobile /sp/ prefix, but the goods ID
    // must still exactly identify the saved product.
    const cm=c.pathname.toLowerCase().replace(/\\/+$/,'');
    verified=c.hostname.toLowerCase()===host&&new RegExp('/goods(?:-sale)?/'+goods+'$').test(cm);
    if(!verified)return empty();
  }catch(_){return empty();}}
  else verified=!!(goods&&path.endsWith('/'+goods));
  if(!verified)return empty();
  const found=new Map();
  const add=(raw,score)=>{try{
    if(typeof raw!=='string'||raw.length>2200||raw.length<8)return;
    const u=new URL(raw.replace(/&amp;/g,'&'),location.href);
    if(u.protocol!=='https:'||u.username||u.password)return;
    const s=u.pathname.toLowerCase();
    if(/logo|banner|avatar|icon|recommend|related|ranking|payment|tracking|placeholder|noimage/.test(s))return;
    if(!(/\\.(?:jpe?g|webp|png|avif)(?:$|[?#])/i.test(u.href)||/\\/images?\\//i.test(s)))return;
    if(!found.has(u.href)||found.get(u.href)<score)found.set(u.href,score);
  }catch(_){}};
  const norm=s=>String(s||'').replace(/[\\s　]/g,'').toLowerCase();
  const title=norm(titles[0].textContent);
  const selectors=['[data-testid*=gallery] img','[data-testid*=goods] img',
    '[class*=GoodsImage] img','[class*=goodsImage] img',
    '[class*=ProductImage] img','[class*=productImage] img',
    '[class*=Gallery] img','[class*=gallery] img',
    'img[itemprop=image]','[class*=GoodsDetail] img','[class*=goodsDetail] img'];
  for(const selector of selectors){
    for(const im of [...main.querySelectorAll(selector)].slice(0,15)){
      if(!live(im))continue;
      const alt=norm(im.alt);
      if(alt.length>=7 && !title.includes(alt) && !alt.includes(title) &&
         !/商品画像|イメージ|画像|image|photo|色|カラー/.test(alt))continue;
      for(const k of ['data-original','data-zoom-image','data-src','src'])add(im.getAttribute(k),180);
      add(im.currentSrc,188);
      const sets=(im.getAttribute('srcset')||im.getAttribute('data-srcset')||'').split(',');
      for(const part of sets.slice(0,12))add(part.trim().split(/\\s+/)[0],190);
    }
  }
  // OGP describes this exact canonical product; it is not a page-wide image search.
  const og=document.querySelector('meta[property="og:image:secure_url"],meta[property="og:image"]');
  if(og)add(og.content,125);
  return JSON.stringify([...found.entries()].sort((a,b)=>b[1]-a[1]).slice(0,6).map(x=>x[0]));
 }catch(_){return JSON.stringify([]);}
})()
""";
}
