package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;

/**
 * Shared product identifier source for all GENERAL evidence techniques.
 * Route syntax is read-only; a query identifier cannot silently override a
 * conflicting path identifier. Merchant-specific route adapters stay here,
 * rather than being copied into technique B/C/D/E/F/G implementations.
 */
public final class WishlistGeneralProductIdentity {
    private WishlistGeneralProductIdentity() { }

    public static String code(URL url) {
        if (url == null) return "";
        if (WishlistGeneralShopItem.isDetail(url)) return WishlistGeneralShopItem.code(url);
        String path = url.getPath().replaceAll("/+$", "");
        String item = path.substring(path.lastIndexOf('/') + 1);
        if (item.toLowerCase(Locale.ROOT).endsWith(".html")) item = item.substring(0,item.length()-5);
        if (!item.matches("(?i)[a-z0-9_-]{5,30}")) item = "";
        // Product identity carried by an Edion item query is stronger than
        // a generic "detail.html" basename; never reuse category parameters.
        if (url.getPath().equalsIgnoreCase("/detail.html") && url.getQuery() != null
                && (url.getHost().equalsIgnoreCase("www.edion.com")
                    || url.getHost().equalsIgnoreCase("edion.com"))) {
            java.util.regex.Matcher idQuery = java.util.regex.Pattern.compile(
                    "(?i)(?:^|&)p_cd=([0-9]{8,14})(?:&|$)").matcher(url.getQuery());
            if (idQuery.find()) item=idQuery.group(1);
        }
        // dショッピング etc. may identify the exact product in ?sku=<item>.
        // Only accept a query identifier when it agrees with the path item.
        String query = url.getQuery();
        if (query != null && query.matches("(?i)(?:^|.*&)sku=[a-z0-9_-]{5,30}(?:&.*|$)")) {
            java.util.regex.Matcher skuQuery = java.util.regex.Pattern.compile(
                    "(?i)(?:^|&)sku=([a-z0-9_-]{5,30})(?:&|$)").matcher(query);
            if (skuQuery.find() && item.equalsIgnoreCase(skuQuery.group(1))) item = skuQuery.group(1);
        }
        return item;
    }
}
