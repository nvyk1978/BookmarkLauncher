package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Safe, read-only JSON-LD evidence for previously unknown GENERAL shops.
 * No unknown site gains an inferred availability state: item URL and the Product
 * structured-data URL MUST identify exactly the same item. */
public final class WishlistGeneralVerifiedUnknownDom {
    private WishlistGeneralVerifiedUnknownDom() { }
    private static final Pattern DETAIL = Pattern.compile(
            "(?i)(?:^|/)(?:products?|items?|goods|detail|p|pd)/[a-z0-9_-]*[0-9][a-z0-9_-]{4,}(?:\\.html)?/?$");
    private static final Pattern HTML_ITEM = Pattern.compile(
            "(?i)(?:^|/)[a-z0-9_-]*(?:product|item|goods)[-_][a-z0-9_-]*[0-9]{5,}\\.html$");
    private static final Pattern KEY = Pattern.compile("(?i)(?:^|&)(?:product_id|productid|item_id|itemid|goods_id|goodsid|sku|pid)=([a-z0-9_-]*[0-9][a-z0-9_-]{3,})(?:&|$)");
    public static boolean candidate(URL u) {
        if (u == null || !"https".equalsIgnoreCase(u.getProtocol())) return false;
        if (WishlistGeneralMarketplaceIdentity.isGuarded(u)) return false;
        String p=u.getPath();
        if (p==null || p.matches("(?i).*(?:category|search|ranking|collections?|list|cart|login|account).*"))return false;
        if (DETAIL.matcher(p).find() || HTML_ITEM.matcher(p).find()) return true;
        Matcher m=KEY.matcher(u.getQuery()==null?"":u.getQuery());
        return m.find() && !p.matches("(?i).*/(?:search|category|list|collections?)/?.*");
    }
    public static boolean samePage(URL saved, URL actual) {
        if (!candidate(saved) || actual==null || !"https".equalsIgnoreCase(actual.getProtocol()))return false;
        String x=saved.getHost().toLowerCase(Locale.ROOT).replaceFirst("^www\\.","");
        String y=actual.getHost().toLowerCase(Locale.ROOT).replaceFirst("^www\\.","");
        if(!x.equals(y) || !saved.getPath().replaceAll("/+$", "").equalsIgnoreCase(actual.getPath().replaceAll("/+$", "")))return false;
        Matcher m=KEY.matcher(saved.getQuery()==null?"":saved.getQuery());
        if (!m.find())return true;
        String key=m.group(0).replaceAll("^&|=.*$", "").toLowerCase(Locale.ROOT);
        Matcher other=Pattern.compile("(?i)(?:^|&)"+Pattern.quote(key)+"=([a-z0-9_-]+)(?:&|$)")
                .matcher(actual.getQuery()==null?"":actual.getQuery());
        return other.find() && m.group(1).equalsIgnoreCase(other.group(1));
    }
    private static String quoted(String s) {
        StringBuilder b = new StringBuilder("'");
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(c=='\\'||c=='\'') b.append('\\').append(c);
            else if(c<' ' || c==0x2028 || c==0x2029)
                b.append(String.format(Locale.ROOT,"\\u%04x",(int)c));
            else b.append(c);
        }
        return b.append('\'').toString();
    }
    public static String javascript(URL saved) {
        if(!candidate(saved))return "'{}'";
        String expectedHost=saved.getHost().toLowerCase(Locale.ROOT).replaceFirst("^www\\.", "");
        String path=saved.getPath().replaceAll("/+$", "");
        Matcher m=KEY.matcher(saved.getQuery()==null?"":saved.getQuery());
        String itemKey=m.find()?m.group(0).replaceAll("^&|=.*$", "").toLowerCase(Locale.ROOT):"";
        String itemValue="";
        m=KEY.matcher(saved.getQuery()==null?"":saved.getQuery());
        if(m.find())itemValue=m.group(1);
        return SCRIPT.replace("__HOST__",quoted(expectedHost)).replace("__PATH__",quoted(path))
                .replace("__KEY__",quoted(itemKey)).replace("__VALUE__",quoted(itemValue));
    }
    public static String imageJavascript(URL saved) {
        return "(function(){try{const o=JSON.parse("+javascript(saved)+");return JSON.stringify(o.images||[]);}"+
                "catch(_){return '[]';}})()";
    }
    private static final String SCRIPT = """
(function(){'use strict';
 const out={value:'',currency:'',images:[],reason:'missing-verified-product'};
 try{
  const expectedHost=__HOST__,expectedPath=__PATH__,key=__KEY__,value=__VALUE__;
  const host=h=>String(h).toLowerCase().replace(/^www\\./,'');
  const path=p=>String(p).replace(/\\/+$/,'').toLowerCase();
  const same=u=>{try{const v=new URL(u,location.href);
    return v.protocol==='https:'&&host(v.hostname)===expectedHost&&path(v.pathname)===path(expectedPath)
      &&(!key||v.searchParams.get(key)===value);
   }catch(_){return false;}};
  if(!same(location.href)){out.reason='item-url-mismatch';return JSON.stringify(out);}
  const products=[];
  const walk=(o,d)=>{if(!o||d>9||products.length>30)return;
    if(Array.isArray(o)){o.slice(0,50).forEach(x=>walk(x,d+1));return;}
    if(typeof o!=='object')return;
    const ty=String(o['@type']||'').toLowerCase();
    if(ty==='product'||ty.endsWith('/product')||ty.endsWith(':product'))products.push(o);
    for(const k of ['@graph','mainEntity','item'])if(o[k])walk(o[k],d+1);
  };
  for(const s of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,30)){
    try{if((s.textContent||'').length<2000000)walk(JSON.parse(s.textContent||''),0);}catch(_){}
  }
  const matching=products.filter(p=>[p.url,p['@id'],p.mainEntityOfPage].some(v=>{
   if(v&&typeof v==='object')v=v['@id']||v.url;
   return typeof v==='string'&&same(v);
  }));
  if(matching.length!==1){out.reason=matching.length?'multiple-products':'id-unverified';return JSON.stringify(out);}
  const product=matching[0];
  const offers=Array.isArray(product.offers)?product.offers:[product.offers];
  const prices=new Set();
  for(const offer of offers.slice(0,12)){
   if(!offer||typeof offer!=='object')continue;
   const ty=String(offer['@type']||'').toLowerCase();
   if(ty.includes('aggregateoffer'))continue;
   const cc=String(offer.priceCurrency||offer.priceSpecification&&offer.priceSpecification.priceCurrency||'').toUpperCase();
   const raw=offer.price||offer.priceSpecification&&offer.priceSpecification.price;
   if(cc!=='JPY'||raw==null)continue;
   const p=String(raw).replace(/[¥￥,\\s円]/g,'');
   if(/^\\d+(?:\\.0+)?$/.test(p)&&Number(p)>=1&&Number(p)<=100000000)
      prices.add('¥'+Number(p));
  }
  if(prices.size===1){out.value=[...prices][0];out.currency='JPY';}
  const seen=new Set();
  const image=v=>{if(!v||seen.size>=6)return;
    if(Array.isArray(v)){v.slice(0,10).forEach(image);return;}
    if(typeof v==='object'){image(v.url||v.contentUrl);return;}
    try{const u=new URL(v,location.href);
      if(u.protocol!=='https:'||/(?:logo|banner|icon|tracking|campaign|sprite|placeholder|avatar|noimage)/i.test(u.pathname))return;
      if(/\\.(?:svg|gif)(?:$|[?#])/i.test(u.href))return;
      if(/\\.(?:jpe?g|png|webp|avif)(?:$|[?#])/i.test(u.href)||/\\/images?\\//i.test(u.pathname))seen.add(u.href);
    }catch(_){}
  };
  image(product.image);
  out.images=[...seen];
  out.reason=prices.size>1?'contradictory-prices':out.value?'bound-price':out.images.length?'bound-images':'bound-item-empty';
  return JSON.stringify(out);
 }catch(_){out.reason='script-error';return JSON.stringify(out);}
})()
""";
}
