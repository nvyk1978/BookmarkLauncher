package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/** MUJI-only read-only product evidence, isolated from GENERAL A-F and ASKUL. */
final class MujiProductDom {
    private MujiProductDom() { }

    static String stockEvidence(URL requested) {
        if (!WishlistMode.isMujiProduct(requested))
            return "JSON.stringify({status:'UNKNOWN',reason:'not-muji-product'})";
        String expectedPath = requested.getPath().replaceAll("/+$", "");
        String jan = expectedPath.substring(expectedPath.lastIndexOf('/') + 1);
        return SCRIPT.replace("__HOST__", JSONObject.quote(requested.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(expectedPath))
                .replace("__JAN__", JSONObject.quote(jan));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const r={status:'UNKNOWN',reason:'pending',product:false,sku:false,
   cart:0,enabled:0,hidden:0,disabled:0,quantity:0,positive:false,negative:false,
   jsonProduct:false,jsonStock:false,stockSource:'none'};
 const done=()=>JSON.stringify(r);
 try{
   if(location.protocol!=='https:'||location.hostname.toLowerCase()!==__HOST__||
      location.pathname.replace(/\\/+$/,'')!==__PATH__){
     r.reason='url-mismatch';return done();
   }
   const jan=__JAN__;
   const main=document.querySelector('main,[role=main],#main,#content')||document.body;
   if(!main){r.reason='body-pending';return done();}
   function text(n){return String((n&&(n.innerText||n.textContent))||'').replace(/\\u00a0|　/g,' ').trim();}
   function visible(n){
     if(!n||n.hidden||n.hasAttribute('inert')||n.getAttribute('aria-hidden')==='true')return false;
     for(let p=n;p;p=p.parentElement){
       if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return false;
       let st=getComputedStyle(p);
       if(st.display==='none'||st.visibility==='hidden'||st.visibility==='collapse'||Number(st.opacity)===0)return false;
     }return true;
   }
   function active(n){return visible(n)&&!n.disabled&&!n.readOnly&&!n.hasAttribute('disabled')&&
       n.getAttribute('aria-disabled')!=='true'&&
       !/(?:disabled|soldout|sold-out|unavailable)/i.test(String(n.className||''));}
   const heading=[...main.querySelectorAll('h1')].filter(visible);
   if(heading.length!==1||text(heading[0]).length<3){r.reason='title-pending';return done();}
   const title=text(heading[0]);
   const root=heading[0].closest('[itemtype*=Product],#product-detail,#productDetail,[class*=productDetail],'+
     '[class*=product-detail],[data-testid*=product-detail]')||main;
   const content=text(root);
   const start=content.indexOf(title);
   if(start<0){r.reason='title-unbound';return done();}
   let local=content.slice(start,start+6500);
   const cut=/(?:関連商品|こちらもおすすめ|この商品を見た|レビュー|商品詳細)/.exec(local);
   if(cut&&cut.index>100)local=local.slice(0,cut.index);
   r.product=local.length>=35;
   if(!r.product){r.reason='product-pending';return done();}
   const bad='header,footer,nav,aside,[class*=recommend],[class*=related],'+
     '[class*=ranking],[class*=suggest],[class*=carousel]';
   const add=/(?:カート|カゴ|かご|買い物かご)\\s*(?:に|へ)?\\s*(?:入れる|追加)|add\\s+to\\s+cart/i;
   const view=/(?:カート|カゴ|かご)\\s*(?:を)?\\s*(?:見る|確認)|view\\s+cart/i;
   const buttons=[...main.querySelectorAll('button,input[type=submit],input[type=button]')].slice(0,200);
   const found=[];
   for(const b of buttons){
     if(b.closest(bad))continue;
     const label=[text(b),b.getAttribute('aria-label'),b.getAttribute('title'),b.value].filter(Boolean).join(' ').slice(0,250);
     // #products_cart is the real product CTA; don't treat the header mini-cart as an add action.
     if(!add.test(label)||view.test(label))continue;
     r.cart++;
     if(!active(b)){
       if(!visible(b))r.hidden++;else r.disabled++;
       continue;
     }
     if(b.id!=='products_cart'&&!b.getAttribute('data-testid')&&!b.closest('form,[class*=product],[class*=cart]'))continue;
     found.push(b);r.enabled++;
   }
   if(found.length!==1){r.reason=found.length?'ambiguous-live-cart':'no-live-product-cart';return done();}
   // A responsive duplicate can be present in hidden markup. Only one LIVE button counts.
   const ctrl=found[0];
   const qtyNodes=[...main.querySelectorAll('input[type=number],input[name*=quantity],'+
     'input[name*=qty],select[name*=quantity],[role=spinbutton]')];
   r.quantity=qtyNodes.filter(active).length;
   // Generic notices, store inventory and delivery FAQs are not proof for this SKU.
   const stockTags=[...root.querySelectorAll('[data-testid*=stock],[class*=stock],'+
     '[id*=stock],[aria-label*=在庫]')].slice(0,85).filter(n=>visible(n)&&!n.closest(bad));
   const positive=/^(?:ネットストア|オンライン)?在庫\\s*[:：]?\\s*(?:あり|有り|わずか|残りわずか|残少)(?:\\s|$)/;
   const negative=/(?:ネットストア|オンライン)?在庫\\s*[:：]?\\s*(?:なし|切れ|無し)|在庫切れ|品切れ|販売終了|販売中止|注文できません|ご注文できません/;
   // Only short visible stock badges INSIDE the actual product container count.
   for(const node of stockTags){
     const s=text(node);
     if(s.length>85||s.length<3)continue;
     if(positive.test(s)){r.positive=true;r.stockSource='product-stock-badge';}
     if(negative.test(s))r.negative=true;
   }
   // Restrict explicit negative text to the immediate product CTA region.
   const panel=ctrl.closest('[class*=buy],[class*=cart],[class*=purchase],form')||ctrl.parentElement;
   if(panel&&negative.test(text(panel).slice(0,550)))r.negative=true;
   // Stock in structured offers is accepted ONLY when the Product JSON-LD
   // identifies the exact 13-digit JAN OR the canonical product URL.
   function scan(obj,depth){
     if(!obj||depth>7)return;
     if(Array.isArray(obj)){for(const e of obj.slice(0,30))scan(e,depth+1);return;}
     if(typeof obj!=='object')return;
     const typ=String(obj['@type']||'').toLowerCase();
     if(typ==='product'||typ.endsWith('/product')){
       const ids=[obj.sku,obj.productID,obj.productId,obj.gtin13,obj.gtin].map(x=>String(x||''));
       const url=String(obj.url||obj['@id']||'');
       // A contradictory explicit product ID cannot be overridden by a
       // canonical URL which might belong to a variant or recommendation.
       const present=ids.filter(x=>x.length>0);
       // MUJI product pages show an 8-digit 商品番号 even when the URL is
       // a 13-digit JAN. Confirm the short code in THIS product's text.
       const short=jan.slice(-8);
       const shortLabel=new RegExp('商品番号\\\\s*[:：]?\\\\s*'+short+'(?![0-9])');
       const shortVerified=ids.includes(short)&&shortLabel.test(local);
       const same=ids.includes(jan)||shortVerified||
          (present.length===0&&url.includes('/cmdty/detail/'+jan));
       if(same){
         r.sku=true;r.jsonProduct=true;
         const offers=Array.isArray(obj.offers)?obj.offers:[obj.offers];
         for(const o of offers){
           if(!o||typeof o!=='object')continue;
           const availability=String(o.availability||'');
           if(/(?:OutOfStock|SoldOut|Discontinued)$/i.test(availability))r.negative=true;
           if(/(?:InStock|LimitedAvailability)$/i.test(availability)){
             r.jsonStock=true;r.stockSource='sku-structured-offer';
           }
         }
       }
     }
     if(obj['@graph'])scan(obj['@graph'],depth+1);
     if(obj.mainEntity)scan(obj.mainEntity,depth+1);
   }
   for(const sc of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,30)){
     try{scan(JSON.parse(sc.textContent||'null'),0);}catch(_){ }
   }
   // A matching URL, product title, exact live CTA and SKU-bound in-stock
   // offer support an AVAILABLE verdict; cart visibility alone NEVER does.
   if(r.negative){r.reason='negative-or-conflicting-stock';return done();}
   if(r.jsonProduct&&r.jsonStock&&r.enabled===1){
     r.status='AVAILABLE';r.reason='verified-muji-sku-stock-cart';return done();
   }
   // An explicit short visible badge is still insufficient when we cannot
   // prove its association to the exact 13-digit product.
   r.reason=r.jsonProduct?'stock-unverified':'sku-or-stock-unverified';
   return done();
 }catch(_){r.reason='dom-error';return done();}
})()
""";
}
