package com.cmyk.bookmarkslauncher.googlemaps;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/**
 * Builds a small static map thumbnail from OpenStreetMap raster tiles.
 * This is intentionally used only for one-off Google Maps bookmark thumbnails;
 * it is not an offline tile cache or interactive map implementation.
 */
final class StaticMapThumbnail {
    private StaticMapThumbnail() {}

    private static final int TILE_SIZE = 256;
    private static final int ZOOM = 16;
    private static final int GRID = 3;
    private static final int BASE_CROP_SIZE = 450;
    private static final int OUTPUT_SIZE = 512;
    private static final int N_LIGHT_RED = 0xFF662211;

    public static boolean generate(double latitude, double longitude, File target) {
        return generate(latitude, longitude, target, GoogleMapsStateStore.DEFAULT_SCALE);
    }

    public static boolean generate(double latitude, double longitude, File target, float scale) {
        if (target == null || latitude < -90d || latitude > 90d || longitude < -180d || longitude > 180d) {
            return false;
        }

        latitude = Math.max(-85.05112878d, Math.min(85.05112878d, latitude));
        scale = GoogleMapsStateStore.clampScale(scale);
        int cropSize = Math.round(BASE_CROP_SIZE / scale);
        cropSize = Math.max(1, Math.min(TILE_SIZE * GRID, cropSize));
        double tiles = 1 << ZOOM;
        double worldX = (longitude + 180d) / 360d * tiles;
        double latRad = Math.toRadians(latitude);
        double worldY = (1d - Math.log(Math.tan(latRad) + 1d / Math.cos(latRad)) / Math.PI) / 2d * tiles;

        int centerTileX = (int) Math.floor(worldX);
        int centerTileY = (int) Math.floor(worldY);
        int baseX = centerTileX - 1;
        int baseY = centerTileY - 1;

        Bitmap mosaic = Bitmap.createBitmap(TILE_SIZE * GRID, TILE_SIZE * GRID, Bitmap.Config.ARGB_8888);
        Canvas mosaicCanvas = new Canvas(mosaic);
        mosaicCanvas.drawColor(Color.rgb(235, 235, 235));

        int loaded = 0;
        for (int row = 0; row < GRID; row++) {
            for (int col = 0; col < GRID; col++) {
                Bitmap tile = downloadTile(ZOOM, baseX + col, baseY + row);
                if (tile == null) continue;
                mosaicCanvas.drawBitmap(tile, col * TILE_SIZE, row * TILE_SIZE, null);
                tile.recycle();
                loaded++;
            }
        }
        if (loaded < 4) {
            mosaic.recycle();
            return false;
        }

        float centerPxX = (float) ((worldX - baseX) * TILE_SIZE);
        float centerPxY = (float) ((worldY - baseY) * TILE_SIZE);
        int left = Math.round(centerPxX - cropSize / 2f);
        int top = Math.round(centerPxY - cropSize / 2f);
        left = Math.max(0, Math.min(mosaic.getWidth() - cropSize, left));
        top = Math.max(0, Math.min(mosaic.getHeight() - cropSize, top));

        Bitmap cropped = Bitmap.createBitmap(mosaic, left, top, cropSize, cropSize);
        Bitmap output = Bitmap.createScaledBitmap(cropped, OUTPUT_SIZE, OUTPUT_SIZE, true)
                .copy(Bitmap.Config.ARGB_8888, true);
        cropped.recycle();
        mosaic.recycle();

        Canvas canvas = new Canvas(output);
        float cropToOutput = OUTPUT_SIZE / (float) cropSize;
        float markerX = (centerPxX - left) * cropToOutput;
        float markerY = (centerPxY - top) * cropToOutput;
        drawPin(canvas, markerX, markerY);
        drawAttribution(canvas);

        File parent = target.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            output.recycle();
            return false;
        }
        try (FileOutputStream out = new FileOutputStream(target, false)) {
            boolean ok = output.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.flush();
            output.recycle();
            return ok;
        } catch (Exception e) {
            output.recycle();
            return false;
        }
    }

    private static Bitmap downloadTile(int zoom, int x, int y) {
        int count = 1 << zoom;
        if (y < 0 || y >= count) return null;
        int wrappedX = ((x % count) + count) % count;
        HttpURLConnection connection = null;
        try {
            URL url = new URL(String.format(Locale.US,
                    "https://tile.openstreetmap.org/%d/%d/%d.png", zoom, wrappedX, y));
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(6000);
            connection.setReadTimeout(7000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "BookmarkLauncher/0.1.36 Android static bookmark thumbnail");
            connection.setRequestProperty("Accept", "image/png,image/*;q=0.8,*/*;q=0.5");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return null;
            return BitmapFactory.decodeStream(connection.getInputStream());
        } catch (Exception ignored) {
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    /** Pin tip is exactly on the requested coordinate. */
    private static void drawPin(Canvas canvas, float cx, float tipY) {
        float height = 58f;
        float width = 42f;
        float top = tipY - height;
        float midY = top + height * 0.36f;
        float half = width / 2f;

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(N_LIGHT_RED);
        paint.setStyle(Paint.Style.FILL);

        Path pin = new Path();
        pin.moveTo(cx, tipY);
        pin.cubicTo(cx - 5f, tipY - 8f, cx - half, top + height * 0.60f, cx - half, midY);
        pin.cubicTo(cx - half, top + 7f, cx - 9f, top, cx, top);
        pin.cubicTo(cx + 9f, top, cx + half, top + 7f, cx + half, midY);
        pin.cubicTo(cx + half, top + height * 0.60f, cx + 5f, tipY - 8f, cx, tipY);
        pin.close();
        canvas.drawPath(pin, paint);

        paint.setColor(Color.WHITE);
        canvas.drawCircle(cx, top + height * 0.35f, 7.5f, paint);
    }

    private static void drawAttribution(Canvas canvas) {
        final String text = "© OpenStreetMap contributors";
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setTextSize(13f);
        textPaint.setColor(Color.BLACK);
        float textWidth = textPaint.measureText(text);
        float baseline = OUTPUT_SIZE - 7f;

        Paint bg = new Paint();
        bg.setColor(0xCCFFFFFF);
        canvas.drawRect(new RectF(4f, baseline - 15f, 12f + textWidth, OUTPUT_SIZE - 3f), bg);
        canvas.drawText(text, 8f, baseline, textPaint);
    }
}
