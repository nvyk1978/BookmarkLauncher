package com.cmyk.bookmarkslauncher;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** NS準拠の診断ログ。BookmarkLauncherのクラッシュ調査イベントも記録する。 */
public final class DiagLog {
    private static final String FILE_NAME = "bookmarklauncher-diagnostic.log";
    private static final SimpleDateFormat FORMAT =
            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.JAPAN);
    private static Thread.UncaughtExceptionHandler previousHandler;
    private static boolean installed;

    private DiagLog() {}

    static synchronized void installCrashHandler(Context context) {
        if (installed) return;
        installed = true;
        Context app = context.getApplicationContext();
        previousHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            write(app, "FATAL thread=" + thread.getName() + " " + stackTrace(throwable));
            if (previousHandler != null) previousHandler.uncaughtException(thread, throwable);
        });
    }

    public static synchronized void write(Context context, String message) {
        try (FileWriter w = new FileWriter(new File(context.getFilesDir(), FILE_NAME), true)) {
            w.write(FORMAT.format(new Date()) + " " + message + "\n");
        } catch (Throwable ignored) { }
    }

    static String stackTrace(Throwable t) {
        if (t == null) return "unknown";
        try {
            StringWriter sw = new StringWriter();
            t.printStackTrace(new PrintWriter(sw));
            return sw.toString().replace('\n', ' ').replace('\r', ' ');
        } catch (Throwable ignored) {
            return t.getClass().getName() + ": " + String.valueOf(t.getMessage());
        }
    }

    static synchronized String read(Context context) {
        File f = new File(context.getFilesDir(), FILE_NAME);
        if (!f.exists()) return "ログはまだありません。\n";
        StringBuilder out = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = r.readLine()) != null) out.append(line).append('\n');
        } catch (Exception e) {
            return "ログ読込エラー: " + e + "\n";
        }
        return out.toString();
    }

    static synchronized void clear(Context context) {
        File f = new File(context.getFilesDir(), FILE_NAME);
        if (f.exists()) f.delete();
    }

    static String versionName(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return info.versionName == null ? "unknown" : info.versionName;
        } catch (Exception ignored) { return "unknown"; }
    }

    static long versionCode(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) return info.getLongVersionCode();
            return info.versionCode;
        } catch (Exception ignored) { return -1L; }
    }

    static synchronized String report(Context context) {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.trim();
        String model = Build.MODEL == null ? "" : Build.MODEL.trim();
        String device = (manufacturer + " " + model).trim();
        if (device.isEmpty()) device = "unknown";
        return "BookmarkLauncher diagnostic report\n"
                + "Generated: " + FORMAT.format(new Date()) + "\n"
                + "Device: " + device + "\n"
                + "Android: " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\n"
                + "App: " + versionName(context) + " (" + versionCode(context) + ")\n"
                + "\n--- LOG ---\n" + read(context);
    }
}
