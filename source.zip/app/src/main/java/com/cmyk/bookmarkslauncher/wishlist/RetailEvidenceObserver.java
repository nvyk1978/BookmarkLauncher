package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONObject;

/** Secondary evidence stage: observe main-product and variant-bound signals,
 * never infer stock from unrelated recommendations or click a purchase button.
 * The result contains only bounded evidence flags, not scraped personal data. */
final class RetailEvidenceObserver {
    private RetailEvidenceObserver() { }
    static String wrap(String siteScript, WishlistMode mode, String expectedQuery) {
        String observer=SCRIPT.replace("__MODE__",JSONObject.quote(mode.name()))
                .replace("__EXPECTED_QUERY__", JSONObject.quote(expectedQuery==null?"":expectedQuery));
        return "(function(){try{const raw="+siteScript+";"
                +"const result=JSON.parse(typeof raw==='string'?raw:'{}');"
                +"const proof="+observer+";"
                +"result.observation=proof;"
                +"if(proof.state==='AVAILABLE'||proof.state==='UNAVAILABLE'){"
                +"if(result.status==='UNKNOWN'||!result.status){result.status=proof.state;result.reason=proof.source;}"
                +"else if(result.status!==proof.state){result.status='UNKNOWN';result.reason='stock-evidence-conflict';}"
                +"}return JSON.stringify(result);"
                +"}catch(e){return '{}';}})()";
    }
    private static final String SCRIPT = """
(function(){'use strict';
try {
 const out={state:'UNKNOWN',source:'none',signature:'',ready:document.readyState==='complete',loading:false};
 const mode=__MODE__, params=new URLSearchParams(__EXPECTED_QUERY__);
 const visible=e=>{if(!e||!e.getClientRects||!e.getClientRects().length)return false;
   const s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0';};
 const txt=e=>String((e&&(e.innerText||e.textContent||e.value||e.getAttribute('aria-label')))||'').replace(/\\s+/g,' ').trim().slice(0,400);
 const selected=e=>!!e&&(e.matches('[aria-selected="true"],[aria-pressed="true"],[data-selected="true"],.selected,[class*="Selected"],[class*="selected"]')||
   (e.querySelector('[aria-selected="true"],[aria-pressed="true"],[data-selected="true"]')!==null));
 const nodes=(r,q)=>{try{return [...r.querySelectorAll(q)].filter(visible).slice(0,90);}catch(_){return [];}};
 const h=document.querySelector('main h1,h1');
 const main=document.querySelector('[data-testid="product-detail"],#productDetail,#productDetails,#detailMain,#productMain,main')||document.body;
 if(!h || !((mode==='UNIQLO' && /^\\/jp\\/ja\\/products\\/E[0-9]{6}-[0-9]{3}\\/[0-9]{2}\\/?$/.test(location.pathname)) ||
      (mode==='YODOBASHI' && /^\\/product\\/[0-9]{12,20}\\/?$/.test(location.pathname)) ||
      (mode==='BICCAMERA' && /^\\/bc\\/item\\/[0-9]{5,15}\\/?$/.test(location.pathname))))return out;
 const purchase=nodes(main,'button,input[type="submit"],[role="button"],a').filter(e=>
   /カートに入れる|ショッピングカートに入れる|バッグに入れる|購入する|注文する|再入荷通知|在庫なし|売り切れ/.test(txt(e)));
 const blocked=e=>e.disabled||e.getAttribute('aria-disabled')==='true'||
   /(?:disabled|unavailable|soldout|sold-out)/i.test(String(e.className||''))||e.closest('[aria-hidden="true"],[inert]');
 const rootText=txt(main).slice(0,400);
 const parts=[];
 if(mode==='UNIQLO'){
   const map=[['color','colorDisplayCode','[data-color-code],[data-color-display-code]'],
      ['size','sizeDisplayCode','[data-size-code],[data-size-display-code]'],
      ['length','pldDisplayCode','[data-length-code],[data-pld-display-code]']];
   let conflict=false, matched=0, visibleOptions=0;
   for(const [key,param,selector] of map){
     const expected=params.get(param);if(!expected){conflict=true;continue;}
     const current=new URLSearchParams(location.search).get(param);
     if(current&&current!==expected){conflict=true;continue;}
     const options=nodes(main,selector);
     visibleOptions+=options.length;
     const active=options.filter(selected);
     if(active.length){
       const values=active.flatMap(e=>[e.getAttribute('data-'+key+'-code'),e.getAttribute('data-'+key+'-display-code'),
              key==='length'?e.getAttribute('data-pld-display-code'):null]).filter(Boolean);
       if(values.some(v=>v!==expected))conflict=true;
       else if(values.some(v=>v===expected))matched++;
     }else if(current===expected)matched++;
     parts.push(key+':'+(active.length?'selected':current===expected?'url':'not-explicit'));
   }
   const exactUrl=map.every(([,p])=>new URLSearchParams(location.search).get(p)===params.get(p));
   // A stock label on another color/size must not be used. Prefer controls with
   // matching selected variant data, or the precise URL plus a single purchase panel.
   const safe=!conflict&&(matched===3||exactUrl);
   const scope=main.querySelector('[data-testid*="purchase"],[data-testid*="stock"],[class*="PurchaseArea"],[class*="purchase-area"]')||null;
   const candidates=scope?purchase.filter(e=>scope.contains(e)):purchase;
   const actions=candidates.filter(e=>/カートに入れる|バッグに入れる|注文する/.test(txt(e)));
   const sold=candidates.filter(e=>/再入荷通知|在庫なし|売り切れ/.test(txt(e)));
   const scoped=scope?txt(scope):'';
   const label=nodes(main,'[data-testid*="stock"],[aria-live],[class*="stock"],[class*="Stock"]')
     .filter(e=>!e.closest('[class*="recommend"],[class*="related"],[id*="recommend"],[id*="related"]'))
     .map(txt).filter(t=>t&&t.length<120);
   const positives=label.filter(t=>/在庫あり|在庫残りわずか|購入可能/.test(t)&&!/在庫なし|店舗在庫/.test(t));
   const negatives=label.filter(t=>/在庫なし|売り切れ|販売終了|再入荷通知/.test(t)&&!/店舗在庫/.test(t));
   if(safe && actions.length===1 && !blocked(actions[0]) && negatives.length===0 &&
       (positives.length>0 || /在庫あり|在庫残りわずか/.test(scoped))) {
     out.state='AVAILABLE';out.source='variant-purchase-evidence';
   }else if(safe && (negatives.length===1||sold.length===1) && !actions.some(e=>!blocked(e)) && positives.length===0){
     out.state='UNAVAILABLE';out.source='variant-unavailable-evidence';
   }else out.source=conflict?'variant-conflict':safe?'variant-stock-insufficient':'variant-selection-not-proven';
   parts.push('sel'+matched,'conf'+(conflict?1:0),'choices'+visibleOptions,'action'+actions.length,
     'sold'+sold.length,'pos'+positives.length,'neg'+negatives.length,'scope'+!!scope);
 }else if(mode==='YODOBASHI'){
   const action=purchase.filter(e=>/カートに入れる|ショッピングカートに入れる/.test(txt(e)));
   const exact=action.filter(e=>!blocked(e)&&e.tagName!=='A'&&
        !e.closest('[class*="recommend"],[class*="related"],[id*="recommend"],[id*="related"]'));
   const near=exact.length===1?(exact[0].closest('[class*="buy"],[class*="Buy"],[class*="cart"],[class*="Cart"],section,form')||exact[0].parentElement):null;
   const nearText=txt(near);
   const positive=/在庫あり|在庫残少|在庫僅少|残りわずか|在庫わずか/.test(nearText);
   const negative=/在庫なし|売り切れ|販売終了|販売休止|販売中止|入荷未定/.test(nearText);
   const labels=nodes(main,'[class*="stock"],[class*="Stock"],[id*="stock"],[id*="Stock"]')
       .filter(e=>!e.closest('[class*="recommend"],[class*="related"],[id*="recommend"],[id*="related"]'))
       .map(txt).filter(t=>t.length<120);
   const good=labels.some(t=>/在庫あり|在庫残少|在庫僅少|残りわずか/.test(t)&&!/在庫なし/.test(t));
   const bad=labels.some(t=>/在庫なし|売り切れ|販売終了|販売休止/.test(t));
   if(exact.length===1&&(positive||good)&&!negative&&!bad){out.state='AVAILABLE';out.source='same-item-cart-stock';}
   else if(exact.length===0&&(negative||bad)&&!good){out.state='UNAVAILABLE';out.source='same-item-soldout';}
   else out.source='stock-evidence-insufficient';
   parts.push('action'+action.length,'exact'+exact.length,'good'+good,'bad'+bad,'near'+positive+negative);
 }else if(mode==='BICCAMERA'){
   // Keep the validated site extractor as the primary authority here.
   out.source='bic-site-extractor';parts.push('purchase'+purchase.length);
 }
 out.loading=document.readyState!=='complete'||nodes(main,'[aria-busy="true"],[data-loading="true"],[role="progressbar"]')
    .length>0;
 const imgs=nodes(main,'img').filter(e=>e.getAttribute('src')||e.getAttribute('data-src'));
 parts.push('ready'+document.readyState,'h'+!!h,'images'+imgs.length,
       'loaded'+imgs.filter(e=>e.complete&&e.naturalWidth>80).length,'loading'+out.loading);
 out.signature=parts.join('|').slice(0,240);
 return out;
}catch(_){return {state:'UNKNOWN',source:'observer-exception',signature:'error',ready:false,loading:false};}
})()
""";
}
