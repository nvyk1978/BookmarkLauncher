package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.FrameLayout;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.net.URL;

/** Hidden foreground renderer, shared lifecycle ONLY. All field selectors live in site classes. */
public final class LargeRetailWebViewProbe {
    public interface Callback { void complete(WishlistCrawler.Result result); }
    private final FrameLayout parent;
    private final Handler main=new Handler(Looper.getMainLooper());
    private WebView web;
    private Callback callback;
    private URL expectedUrl;
    private WishlistMode mode;
    private boolean done;
    private int tries;
    private boolean evaluating;
    private boolean captureStarted;
    private long lastEvaluatedAt;
    private long startedAt;
    /** Evidence-aware observation: only changes to bounded product signals justify retries. */
    private String lastEvidence="";
    private int unchangedObservations;
    private long lastEvidenceChangedAt;
    private boolean observedReady;
    private boolean observedLoading;
    private boolean stockConflict;
    private int activationStep;

    private int mainHttpStatus;
    private int mainNetworkErrorCode;
    /** Only a final main-document failure can override a competing HTTP timeout.
     * Never infer 403 from elapsed time alone. */
    public String mainFrameFailureState() {
        if (mainHttpStatus == 401 || mainHttpStatus == 403 || mainHttpStatus == 429)
            return WishlistSiteState.ACCESS_RESTRICTED;
        if (mainHttpStatus == 404 || mainHttpStatus == 410)
            return WishlistSiteState.PAGE_MISSING;
        if (mainHttpStatus >= 400) return WishlistSiteState.TEMPORARY_ERROR;
        if (mainNetworkErrorCode == WebViewClient.ERROR_TIMEOUT)
            return WishlistSiteState.TIMEOUT;
        if (mainNetworkErrorCode != 0) return WishlistSiteState.CONNECT_FAILED;
        return null;
    }
    private String lastDomReason="not evaluated";
    private WishlistCrawler.Result strongest;
    private void trace(String phase, String detail) { RetailDiagnostics.event(mode, "webview."+phase, detail); }
    private final Runnable timeout=()->{
        Log.w("RetailGiant", "WebView deadline mode="+mode+" attempts="+tries
                +" HTTP="+mainHttpStatus+" savedFields="+fields(strongest)
                +" lastReason="+lastDomReason);
        trace("deadline","attempts="+tries+" mainHTTP="+mainHttpStatus+" mainError="+mainNetworkErrorCode+" fields="+fields(strongest));
        finishWithImageCapture(); // Preserve fields; BIC may still have painted image pixels.
    };
    private static String fields(WishlistCrawler.Result r){
        return r==null?"none":("name="+(r.title!=null)+",image="+(r.imageUrl!=null)
                +",price="+(r.price!=null)+",stock="+r.availabilityExplicit);
    }
    public LargeRetailWebViewProbe(FrameLayout parent){this.parent=parent;}
    public void start(String sourceUrl, WishlistMode savedMode, Callback cb){
        cancel();
        done=false;tries=0;evaluating=false;captureStarted=false;lastEvaluatedAt=0;
        lastEvidence="";unchangedObservations=0;observedReady=false;observedLoading=true;stockConflict=false;activationStep=0;
        strongest=null;callback=cb;mode=savedMode;
        lastDomReason="no DOM response";
        mainHttpStatus=0;mainNetworkErrorCode=0;
        startedAt=android.os.SystemClock.elapsedRealtime();
        lastEvidenceChangedAt=startedAt;
        if(Looper.myLooper()!=Looper.getMainLooper()){trace("invalidThread","not-main");finish(null);return;}
        try{
            expectedUrl=new URL(sourceUrl);
            if(!"https".equalsIgnoreCase(expectedUrl.getProtocol())
                    ||!WishlistCrawler.isAllowedUrl(expectedUrl)
                    ||WishlistMode.forLargeRetailUrl(expectedUrl)!=mode){trace("urlRejected","mode-or-host-mismatch");finish(null);return;}
            web=new WebView(parent.getContext());
            // Fully transparent WebViews can defer the compositor and lazy-loaded
            // product images. Keep the renderer active behind the host's UI.
            web.setAlpha(mode==WishlistMode.BICCAMERA?0.01f:0f);web.setBackgroundColor(Color.TRANSPARENT);
            web.setClickable(false);web.setLongClickable(false);web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setLoadsImagesAutomatically(true);
            web.getSettings().setBlockNetworkImage(false);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            parent.addView(web,0,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            web.setWebChromeClient(new WebChromeClient(){
                @Override public void onProgressChanged(WebView view,int progress){
                    if(!done && progress>=30 && (progress==100 || tries==0)) inspect(view);
                }
            });
            web.setWebViewClient(new WebViewClient(){
                @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap favicon){
                    Log.d("RetailGiant", "Page started mode="+mode+" sameItem="+isSameItem(url));
                    trace("pageStart","sameItem="+isSameItem(url)+" host="+RetailDiagnostics.host(url));
                }
                @Override public void onReceivedHttpError(WebView v,WebResourceRequest req,android.webkit.WebResourceResponse response){
                    if(req.isForMainFrame()) {
                        mainHttpStatus=response.getStatusCode();
                        Log.w("RetailGiant", "Main document HTTP="+mainHttpStatus+" mode="+mode);
                        trace("mainHttp","status="+mainHttpStatus);
                    }
                }
                @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest request){
                    return request.isForMainFrame()&&!isSameItem(request.getUrl().toString());
                }
                @Override public void onPageFinished(WebView v,String url){
                    if(!done&&isSameItem(url))main.postDelayed(()->inspect(v),250);
                }
                @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError error){
                    if(req.isForMainFrame()) {
                        mainNetworkErrorCode=error==null?0:error.getErrorCode();
                        trace("mainError","code="+mainNetworkErrorCode+" fields="+fields(strongest));
                        Log.w("RetailGiant", "Main frame error mode="+mode+" code="
                                +mainNetworkErrorCode+" fields="+fields(strongest));
                        // Some heavyweight stores render useful cached/main DOM before
                        // the main-frame network error. Probe it once before ending;
                        // never synthesize a product from a blocked/error page.
                        if(isSameItem(v.getUrl()))main.postDelayed(()->{
                            if(!done)inspect(v);
                        },300);
                        else finish(strongest);
                    }
                }
            });
            main.postDelayed(timeout,mode==WishlistMode.BICCAMERA?25000:
                    mode==WishlistMode.YODOBASHI?23000:16500);
            web.loadUrl(sourceUrl);
            // Start inspecting while subresources still load. Some retailer sites
            // never reach onPageFinished within the deadline.
            main.postDelayed(()->inspect(web),1500);
            Log.i("RetailGiant", "Probe start mode="+mode+" url="+expectedUrl.getHost());
            trace("start","host="+expectedUrl.getHost()+" deadlineMs="+(mode==WishlistMode.BICCAMERA?25000:mode==WishlistMode.YODOBASHI?23000:16500));
        }catch(Exception error){Log.w("RetailGiant", "WebView setup",error);trace("setupError","type="+RetailDiagnostics.error(error));finish(null);}
    }
    private boolean isSameItem(String target){
        try{return WishlistMode.sameLargeRetailVariant(expectedUrl,new URL(target));}
        catch(Exception ignored){return false;}
    }
    private void inspect(WebView w){
        if(done||w==null||w!=web||evaluating)return;
        if(!isSameItem(w.getUrl())) {
            // Initial about:blank is not an identity mismatch; retry until deadline.
            main.postDelayed(()->inspect(w),1100);
            if(tries == 0)trace("notReady","host="+RetailDiagnostics.host(w.getUrl()));
            return;
        }
        // The previous 12-attempt limit ended Yodobashi at 5.8s despite a 23s
        // deadline. Throttle bursty onProgressChanged calls, but keep probing.
        long now=android.os.SystemClock.elapsedRealtime();
        if (now-lastEvaluatedAt<1200) return;
        lastEvaluatedAt=now;
        evaluating=true;
        tries++;
        String js;
        if(mode==WishlistMode.UNIQLO){
            // Bind the originally registered clothing variant. UNIQLO may strip
            // query parameters from its own rendered URL; never adopt a different
            // variant simply because a DOM node happens to be selected.
            String query=expectedUrl.getQuery()==null?"":expectedUrl.getQuery();
            js=UniqloProductExtractor.domScript().replace("\"__EXPECTED_QUERY__\"",
                    JSONObject.quote(query));
        }
        else if(mode==WishlistMode.YODOBASHI)js=YodobashiProductExtractor.domScript();
        else if(mode==WishlistMode.BICCAMERA)js=BicCameraProductExtractor.domScript();
        else{finish(null);return;}
        // The second stage observes *identity-bound* stock and purchase evidence;
        // site extractors remain the primary source for already-working fields.
        js=RetailEvidenceObserver.wrap(js,mode,expectedUrl.getQuery());
        w.evaluateJavascript(js,raw->{
            evaluating=false;
            if(done||w!=web||!isSameItem(w.getUrl()))return;
            WishlistCrawler.Result result=null;
            try{
                Object parsed=new JSONTokener(raw==null?"null":raw).nextValue();
                if(parsed instanceof String){
                    JSONObject obj=new JSONObject((String)parsed);
                    result=new WishlistCrawler.Result();
                    result.acquisitionMode=mode;
                    result.resolvedUrl=w.getUrl();
                    result.httpCode=200;
                    result.siteState=WishlistSiteState.OK;
                    lastDomReason=obj.optString("reason","no product evidence");
                    JSONObject observation=obj.optJSONObject("observation");
                    if(observation!=null){
                        String signature=observation.optString("signature", "");
                        if(!signature.isEmpty()) {
                            long observedAt=android.os.SystemClock.elapsedRealtime();
                            if(!signature.equals(lastEvidence)) {
                                unchangedObservations=0;
                                lastEvidence=signature;
                                lastEvidenceChangedAt=observedAt;
                                trace("evidenceChange","attempt="+tries+" source="
                                        +observation.optString("source", "none")+" status="
                                        +observation.optString("state", "UNKNOWN"));
                            }else unchangedObservations++;
                        }
                        observedReady=observation.optBoolean("ready",false);
                        observedLoading=observation.optBoolean("loading",true);
                    }
                    if(mode==WishlistMode.YODOBASHI && obj.has("priceEvidence") && tries<=3)
                        trace("priceEvidence",obj.optString("priceEvidence").replaceAll("[^a-zA-Z0-9=,]",""));
                    String title=obj.optString("title","").trim();
                    if(title.length()>=3&&title.length()<400)result.title=title;
                    String image=obj.optString("image","");
                    if(image.startsWith("https://"))result.imageUrl=image;
                    if (mode == WishlistMode.BICCAMERA) {
                        org.json.JSONArray imageArray = obj.optJSONArray("images");
                        if (imageArray != null) {
                            java.util.ArrayList<String> candidates = new java.util.ArrayList<>();
                            for (int i=0;i<Math.min(imageArray.length(),10);i++) {
                                String candidate=imageArray.optString(i,"");
                                if(candidate.startsWith("https://") && !candidates.contains(candidate))
                                    candidates.add(candidate);
                            }
                            result.retailImageCandidates = candidates;
                            if(result.imageUrl==null&&!candidates.isEmpty())result.imageUrl=candidates.get(0);
                        }
                    }
                    long price=obj.optLong("price",0);
                    if(price>=100&&price<100000000)result.price=price;
                    String observedStock=obj.optString("status", "UNKNOWN");
                    result.status=("AVAILABLE".equals(observedStock)||"UNAVAILABLE".equals(observedStock))
                            ?observedStock:"UNKNOWN";
                    result.availabilityExplicit=!"UNKNOWN".equals(result.status);
                    result.availabilityReason=obj.optString("reason","サイト専用DOM解析");
                    result.sourceName=expectedUrl.getHost();
                    result.success=result.title!=null||result.imageUrl!=null||result.price!=null
                            ||result.availabilityExplicit;
                    if(!result.success)result=null;
                }
            }catch(Exception e){Log.d("RetailGiant", "DOM result not usable", e);trace("domParseError","attempt="+tries+" type="+RetailDiagnostics.error(e));}
            if(result!=null){
                if("stock-evidence-conflict".equals(result.availabilityReason)){
                    stockConflict=true;
                    if(strongest!=null){
                        strongest.status="UNKNOWN";
                        strongest.availabilityExplicit=false;
                        strongest.availabilityReason=result.availabilityReason;
                    }
                    trace("stockConflict","observer-and-site-disagree");
                }
                if(strongest==null) strongest=result;
                else {
                    if(result.title!=null)strongest.title=result.title;
                    if(result.imageUrl!=null)strongest.imageUrl=result.imageUrl;
                    if (mode == WishlistMode.BICCAMERA && result.retailImageCandidates != null
                            && !result.retailImageCandidates.isEmpty()) {
                        java.util.LinkedHashSet<String> merged = new java.util.LinkedHashSet<>(strongest.retailImageCandidates);
                        merged.addAll(result.retailImageCandidates);
                        strongest.retailImageCandidates = new java.util.ArrayList<>(merged);
                    }
                    if(result.price!=null)strongest.price=result.price;
                    if(result.availabilityExplicit && !stockConflict){
                        if(strongest.availabilityExplicit && !strongest.status.equals(result.status)){
                            // Conflicting evidence across hydration phases: do not
                            // turn a transient UI state into a stock assertion.
                            stockConflict=true;
                            strongest.status="UNKNOWN";
                            strongest.availabilityExplicit=false;
                            strongest.availabilityReason="商品本体の在庫根拠が矛盾";
                            trace("stockConflict", "observations-disagree");
                        }else{
                            strongest.status=result.status;
                            strongest.availabilityExplicit=true;
                            strongest.availabilityReason=result.availabilityReason;
                        }
                    }
                }
                // Let client-side hydration/price/image settle without delaying
                // unnecessarily once all fields have trustworthy evidence.
                if(strongest.title!=null && strongest.imageUrl!=null
                        && strongest.price!=null && (strongest.availabilityExplicit
                            || mode==WishlistMode.BICCAMERA)){
                    finishWithImageCapture();return;
                }
            }
            // Unlike blind DOM polling, safely exercise an exact registered
            // clothing selection to trigger the site's deferred stock panel.
            // At most three clicks (one per axis), NEVER purchase/cart actions.
            if(mode==WishlistMode.UNIQLO && tries>=2 && activationStep<3
                    && strongest!=null && !strongest.availabilityExplicit && observedReady){
                int step=activationStep++;
                w.evaluateJavascript(RetailVariantActivator.script(expectedUrl.getQuery(),step), response->{
                    trace("variantStep","axis="+step+" result="+(response==null?"null":
                            response.replaceAll("[^a-zA-Z-]","")));
                    if(!done)main.postDelayed(()->inspect(w),950);
                });
                return;
            }
            trace("domAttempt","n="+tries+" fields="+fields(strongest)+" reason="+lastDomReason);
            Log.d("RetailGiant", "DOM mode="+mode+" attempt="+tries
                    +" elapsedMs="+(android.os.SystemClock.elapsedRealtime()-startedAt)
                    +" fields="+fields(strongest)+" reason="+lastDomReason);
            long elapsed=android.os.SystemClock.elapsedRealtime()-startedAt;
            long sinceEvidence=android.os.SystemClock.elapsedRealtime()-lastEvidenceChangedAt;
            // No more blind loops over an unchanged completed document. Stock
            // remains UNKNOWN (never an invented available/unavailable claim).
            if(elapsed>=8000 && unchangedObservations>=3 && sinceEvidence>=4400
                    && observedReady && !observedLoading) {
                trace("noProgress","attempts="+tries+" elapsedMs="+elapsed
                        +" missingStock="+(strongest==null||!strongest.availabilityExplicit));
                finishWithImageCapture();return;
            }
            main.postDelayed(()->inspect(w),1350);
        });
    }
    /** Only BIC may capture pixels, after the original product identity/DOM
     * checks have succeeded. Never pass rendered bytes to GENERAL or other stores. */
    private void finishWithImageCapture() {
        if(done||captureStarted)return;
        if(mode==WishlistMode.BICCAMERA && strongest!=null && strongest.imageUrl!=null && web!=null){
            captureStarted=true;
            main.removeCallbacks(timeout);
            trace("captureStart","image=true");
            RetailWebViewImageCapture.start(web,expectedUrl,strongest,bytes->{
                if(done)return;
                if(bytes!=null)strongest.retailRenderedImageBytes=bytes;
                trace("captureEnd","bytes="+(bytes==null?0:bytes.length));
                finish(strongest);
            });
        }else finish(strongest);
    }
    private void finish(WishlistCrawler.Result result){
        if(done)return;
        done=true;main.removeCallbacks(timeout);
        trace("finish","elapsedMs="+(android.os.SystemClock.elapsedRealtime()-startedAt)+" fields="+fields(result)+" mainHTTP="+mainHttpStatus+" mainError="+mainNetworkErrorCode+" state="+mainFrameFailureState()+" attempts="+tries+" reason="+lastDomReason);
        Log.i("RetailGiant", "Probe end mode="+mode+" elapsedMs="
                +(android.os.SystemClock.elapsedRealtime()-startedAt)
                +" fields="+fields(result)+" mainHTTP="+mainHttpStatus
                +" mainNetworkError="+mainNetworkErrorCode
                +" failureState="+mainFrameFailureState()
                +" lastReason="+lastDomReason);
        WebView old=web;web=null;
        if(old!=null){old.stopLoading();old.setWebViewClient(new WebViewClient());parent.removeView(old);old.destroy();}
        Callback cb=callback;callback=null;
        if(cb!=null)cb.complete(result);
    }
    public void cancel(){
        if(Looper.myLooper()!=Looper.getMainLooper())return;
        callback=null;finish(null);
    }
}
