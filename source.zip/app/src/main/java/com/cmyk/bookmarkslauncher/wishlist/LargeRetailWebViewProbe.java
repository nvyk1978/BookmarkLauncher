package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.FrameLayout;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.net.URL;

/** Hidden foreground renderer, shared lifecycle ONLY. All field selectors live in site classes. */
public final class LargeRetailWebViewProbe {
    public interface Callback { void complete(WishlistCrawler.Result result); }
    private final FrameLayout parent;
    private final Handler main=new Handler(Looper.getMainLooper());
    private WebView web;
    private Callback callback;
    private URL expectedUrl;
    private WishlistMode mode;
    private boolean done;
    private int tries;
    private boolean evaluating;
    private long startedAt;
    private int mainHttpStatus;
    private WishlistCrawler.Result strongest;
    private final Runnable timeout=()->{
        Log.w("RetailGiant", "WebView deadline mode="+mode+" attempts="+tries
                +" HTTP="+mainHttpStatus+" savedFields="+fields(strongest));
        finish(strongest); // Preserve fields obtained before a slow resource stalled the page.
    };
    private static String fields(WishlistCrawler.Result r){
        return r==null?"none":("name="+(r.title!=null)+",image="+(r.imageUrl!=null)
                +",price="+(r.price!=null)+",stock="+r.availabilityExplicit);
    }
    public LargeRetailWebViewProbe(FrameLayout parent){this.parent=parent;}
    public void start(String sourceUrl, WishlistMode savedMode, Callback cb){
        cancel();
        done=false;tries=0;evaluating=false;strongest=null;callback=cb;mode=savedMode;
        mainHttpStatus=0;startedAt=android.os.SystemClock.elapsedRealtime();
        if(Looper.myLooper()!=Looper.getMainLooper()){finish(null);return;}
        try{
            expectedUrl=new URL(sourceUrl);
            if(!"https".equalsIgnoreCase(expectedUrl.getProtocol())
                    ||!WishlistCrawler.isAllowedUrl(expectedUrl)
                    ||WishlistMode.forLargeRetailUrl(expectedUrl)!=mode){finish(null);return;}
            web=new WebView(parent.getContext());
            web.setAlpha(0f);web.setBackgroundColor(Color.TRANSPARENT);
            web.setClickable(false);web.setLongClickable(false);web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            parent.addView(web,0,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            web.setWebChromeClient(new WebChromeClient(){
                @Override public void onProgressChanged(WebView view,int progress){
                    if(!done && progress>=30 && (progress==100 || tries==0)) inspect(view);
                }
            });
            web.setWebViewClient(new WebViewClient(){
                @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap favicon){
                    Log.d("RetailGiant", "Page started mode="+mode+" sameItem="+isSameItem(url));
                }
                @Override public void onReceivedHttpError(WebView v,WebResourceRequest req,android.webkit.WebResourceResponse response){
                    if(req.isForMainFrame()) {
                        mainHttpStatus=response.getStatusCode();
                        Log.w("RetailGiant", "Main document HTTP="+mainHttpStatus+" mode="+mode);
                    }
                }
                @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest request){
                    return request.isForMainFrame()&&!isSameItem(request.getUrl().toString());
                }
                @Override public void onPageFinished(WebView v,String url){
                    if(!done&&isSameItem(url))main.postDelayed(()->inspect(v),250);
                }
                @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError error){
                    if(req.isForMainFrame()) {
                        Log.w("RetailGiant", "Main frame error mode="+mode+" code="
                                +(error==null?0:error.getErrorCode())+" fields="+fields(strongest));
                        finish(strongest);
                    }
                }
            });
            main.postDelayed(timeout,16500);
            web.loadUrl(sourceUrl);
            // Start inspecting while subresources still load. Some retailer sites
            // never reach onPageFinished within the deadline.
            main.postDelayed(()->inspect(web),1500);
            Log.i("RetailGiant", "Probe start mode="+mode+" url="+expectedUrl.getHost());
        }catch(Exception error){Log.w("RetailGiant", "WebView setup",error);finish(null);}
    }
    private boolean isSameItem(String target){
        try{return WishlistMode.sameLargeRetailVariant(expectedUrl,new URL(target));}
        catch(Exception ignored){return false;}
    }
    private void inspect(WebView w){
        if(done||w==null||w!=web||evaluating)return;
        if(!isSameItem(w.getUrl())) {
            // Initial about:blank is not an identity mismatch; retry until bounded deadline.
            if(tries < 12)main.postDelayed(()->inspect(w),1100);
            return;
        }
        if(tries>=12) {finish(strongest);return;}
        evaluating=true;
        tries++;
        String js;
        if(mode==WishlistMode.UNIQLO)js=UniqloProductExtractor.domScript();
        else if(mode==WishlistMode.YODOBASHI)js=YodobashiProductExtractor.domScript();
        else if(mode==WishlistMode.BICCAMERA)js=BicCameraProductExtractor.domScript();
        else{finish(null);return;}
        w.evaluateJavascript(js,raw->{
            evaluating=false;
            if(done||w!=web||!isSameItem(w.getUrl()))return;
            WishlistCrawler.Result result=null;
            try{
                Object parsed=new JSONTokener(raw==null?"null":raw).nextValue();
                if(parsed instanceof String){
                    JSONObject obj=new JSONObject((String)parsed);
                    result=new WishlistCrawler.Result();
                    result.acquisitionMode=mode;
                    result.resolvedUrl=w.getUrl();
                    result.httpCode=200;
                    result.siteState=WishlistSiteState.OK;
                    String title=obj.optString("title","").trim();
                    if(title.length()>=3&&title.length()<400)result.title=title;
                    String image=obj.optString("image","");
                    if(image.startsWith("https://"))result.imageUrl=image;
                    long price=obj.optLong("price",0);
                    if(price>=100&&price<100000000)result.price=price;
                    result.status="AVAILABLE".equals(obj.optString("status"))?"AVAILABLE":"UNKNOWN";
                    result.availabilityExplicit="AVAILABLE".equals(result.status);
                    result.availabilityReason=obj.optString("reason","サイト専用DOM解析");
                    result.sourceName=expectedUrl.getHost();
                    result.success=result.title!=null||result.imageUrl!=null||result.price!=null
                            ||result.availabilityExplicit;
                    if(!result.success)result=null;
                }
            }catch(Exception e){Log.d("RetailGiant", "DOM result not usable", e);}
            if(result!=null){
                if(strongest==null) strongest=result;
                else {
                    if(result.title!=null)strongest.title=result.title;
                    if(result.imageUrl!=null)strongest.imageUrl=result.imageUrl;
                    if(result.price!=null)strongest.price=result.price;
                    if("AVAILABLE".equals(result.status)){
                        strongest.status=result.status;
                        strongest.availabilityExplicit=true;
                        strongest.availabilityReason=result.availabilityReason;
                    }
                }
                // Let client-side hydration/price/image settle without delaying
                // unnecessarily once all fields have trustworthy evidence.
                if(strongest.title!=null && strongest.imageUrl!=null
                        && strongest.price!=null && strongest.availabilityExplicit){
                    finish(strongest);return;
                }
            }
            Log.d("RetailGiant", "DOM mode="+mode+" attempt="+tries
                    +" elapsedMs="+(android.os.SystemClock.elapsedRealtime()-startedAt)
                    +" fields="+fields(strongest));
            if(tries<12)main.postDelayed(()->inspect(w),1150);
            else finish(strongest);
        });
    }
    private void finish(WishlistCrawler.Result result){
        if(done)return;
        done=true;main.removeCallbacks(timeout);
        Log.i("RetailGiant", "Probe end mode="+mode+" elapsedMs="
                +(android.os.SystemClock.elapsedRealtime()-startedAt)
                +" fields="+fields(result)+" mainHTTP="+mainHttpStatus);
        WebView old=web;web=null;
        if(old!=null){old.stopLoading();old.setWebViewClient(new WebViewClient());parent.removeView(old);old.destroy();}
        Callback cb=callback;callback=null;
        if(cb!=null)cb.complete(result);
    }
    public void cancel(){
        if(Looper.myLooper()!=Looper.getMainLooper())return;
        callback=null;finish(null);
    }
}
