package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.net.URL;

/** Hidden foreground renderer, shared lifecycle ONLY. All field selectors live in site classes. */
public final class LargeRetailWebViewProbe {
    public interface Callback { void complete(WishlistCrawler.Result result); }
    private final FrameLayout parent;
    private final Handler main=new Handler(Looper.getMainLooper());
    private WebView web;
    private Callback callback;
    private URL expectedUrl;
    private WishlistMode mode;
    private boolean done;
    private int tries;
    private WishlistCrawler.Result strongest;
    private final Runnable timeout=()->finish(null);
    public LargeRetailWebViewProbe(FrameLayout parent){this.parent=parent;}
    public void start(String sourceUrl, WishlistMode savedMode, Callback cb){
        cancel();
        done=false;tries=0;strongest=null;callback=cb;mode=savedMode;
        if(Looper.myLooper()!=Looper.getMainLooper()){finish(null);return;}
        try{
            expectedUrl=new URL(sourceUrl);
            if(!"https".equalsIgnoreCase(expectedUrl.getProtocol())
                    ||!WishlistCrawler.isAllowedUrl(expectedUrl)
                    ||WishlistMode.forLargeRetailUrl(expectedUrl)!=mode){finish(null);return;}
            web=new WebView(parent.getContext());
            web.setAlpha(0f);web.setBackgroundColor(Color.TRANSPARENT);
            web.setClickable(false);web.setLongClickable(false);web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            parent.addView(web,0,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            web.setWebViewClient(new WebViewClient(){
                @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest request){
                    return request.isForMainFrame()&&!isSameItem(request.getUrl().toString());
                }
                @Override public void onPageFinished(WebView v,String url){
                    if(!done&&isSameItem(url))main.postDelayed(()->inspect(v),800);
                }
                @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError error){
                    if(req.isForMainFrame())finish(null);
                }
            });
            main.postDelayed(timeout,16500);
            web.loadUrl(sourceUrl);
        }catch(Exception error){Log.w("RetailGiant", "WebView setup",error);finish(null);}
    }
    private boolean isSameItem(String target){
        try{return WishlistMode.sameLargeRetailProduct(expectedUrl,new URL(target));}
        catch(Exception ignored){return false;}
    }
    private void inspect(WebView w){
        if(done||w!=web||!isSameItem(w.getUrl()))return;
        tries++;
        String js;
        if(mode==WishlistMode.UNIQLO)js=UniqloProductExtractor.domScript();
        else if(mode==WishlistMode.YODOBASHI)js=YodobashiProductExtractor.domScript();
        else if(mode==WishlistMode.BICCAMERA)js=BicCameraProductExtractor.domScript();
        else{finish(null);return;}
        w.evaluateJavascript(js,raw->{
            if(done||w!=web||!isSameItem(w.getUrl()))return;
            WishlistCrawler.Result result=null;
            try{
                Object parsed=new JSONTokener(raw==null?"null":raw).nextValue();
                if(parsed instanceof String){
                    JSONObject obj=new JSONObject((String)parsed);
                    result=new WishlistCrawler.Result();
                    result.acquisitionMode=mode;
                    result.resolvedUrl=w.getUrl();
                    result.httpCode=200;
                    result.siteState=WishlistSiteState.OK;
                    String title=obj.optString("title","").trim();
                    if(title.length()>=3&&title.length()<400)result.title=title;
                    String image=obj.optString("image","");
                    if(image.startsWith("https://"))result.imageUrl=image;
                    long price=obj.optLong("price",0);
                    if(price>=100&&price<100000000)result.price=price;
                    result.status="AVAILABLE".equals(obj.optString("status"))?"AVAILABLE":"UNKNOWN";
                    result.availabilityExplicit="AVAILABLE".equals(result.status);
                    result.availabilityReason=obj.optString("reason","サイト専用DOM解析");
                    result.sourceName=expectedUrl.getHost();
                    result.success=result.title!=null||result.imageUrl!=null||result.price!=null
                            ||result.availabilityExplicit;
                    if(!result.success)result=null;
                }
            }catch(Exception e){Log.d("RetailGiant", "DOM result not usable", e);}
            if(result!=null){
                if(strongest==null) strongest=result;
                else {
                    if(result.title!=null)strongest.title=result.title;
                    if(result.imageUrl!=null)strongest.imageUrl=result.imageUrl;
                    if(result.price!=null)strongest.price=result.price;
                    if("AVAILABLE".equals(result.status)){
                        strongest.status=result.status;
                        strongest.availabilityExplicit=true;
                        strongest.availabilityReason=result.availabilityReason;
                    }
                }
                // Let client-side hydration/price/image settle without delaying
                // unnecessarily once all fields have trustworthy evidence.
                if(strongest.title!=null && strongest.imageUrl!=null
                        && strongest.price!=null && strongest.availabilityExplicit){
                    finish(strongest);return;
                }
            }
            if(tries<7)main.postDelayed(()->inspect(w),1100);
            else finish(strongest);
        });
    }
    private void finish(WishlistCrawler.Result result){
        if(done)return;
        done=true;main.removeCallbacks(timeout);
        WebView old=web;web=null;
        if(old!=null){old.stopLoading();old.setWebViewClient(new WebViewClient());parent.removeView(old);old.destroy();}
        Callback cb=callback;callback=null;
        if(cb!=null)cb.complete(result);
    }
    public void cancel(){
        if(Looper.myLooper()!=Looper.getMainLooper())return;
        callback=null;finish(null);
    }
}
