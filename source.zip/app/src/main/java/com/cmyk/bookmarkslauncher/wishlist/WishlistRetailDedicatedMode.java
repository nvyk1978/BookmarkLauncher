package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Merchant-isolated GENERAL submodes. The stored acquisitionMode intentionally
 * remains GENERAL so already-saved cards, prices and images need no migration.
 * No other merchant (including Joshin) can enter any of these submodes.
 */
public enum WishlistRetailDedicatedMode {
    NONE, EDION, AU, ZOZO, ISETAN;

    public static WishlistRetailDedicatedMode forUrl(URL u) {
        if (u == null || !"https".equalsIgnoreCase(u.getProtocol())
                || !WishlistCrawler.isAllowedUrl(u)
                || MarketplaceIdentity.site(u) != MarketplaceIdentity.Site.OTHER) return NONE;
        String host = u.getHost().toLowerCase(Locale.ROOT);
        String path = u.getPath().toLowerCase(Locale.ROOT);
        if ((host.equals("edion.com") || host.equals("www.edion.com"))
                && path.equals("/detail.html")
                && query(u, "p_cd").matches("[0-9]{8,14}")) return EDION;
        // Exact Mitsukoshi-Isetan product pages only. No search/category paths.
        boolean isetanHost = host.equals("mistore.jp") || host.equals("www.mistore.jp")
                || host.equals("isetan.mistore.jp");
        if (isetanHost && (path.matches("^/shopping/product/[0-9]{15,30}\\.html$")
                || path.matches("^/onlinestore/product/[a-z0-9_-]{8,40}\\.html$"))) return ISETAN;
        if ((host.equals("zozo.jp") || host.equals("www.zozo.jp"))
                && zozoGoodsId(u) != null) return ZOZO;
        // AU brand host family; never match lookalike suffixes or shop listings.
        boolean auHost = host.equals("au.com") || host.endsWith(".au.com")
                || host.equals("wowma.jp") || host.endsWith(".wowma.jp")
                || host.equals("aupaymarket.com") || host.endsWith(".aupaymarket.com");
        if (auHost && (WishlistCrawler.isSingleProductPage(u)
                || WishlistGeneralAlphabetDom.candidateUrl(u))) return AU;
        return NONE;
    }

    public static boolean isZozoHost(URL u) {
        if (u == null) return false;
        String host = u.getHost().toLowerCase(Locale.ROOT);
        return host.equals("zozo.jp") || host.equals("www.zozo.jp");
    }

    /** Only a goods-ID product path, never a shop, keyword page or ranking. */
    public static String zozoGoodsId(URL u) {
        if (!isZozoHost(u)) return null;
        String path = u.getPath().toLowerCase(Locale.ROOT).replaceAll("/+$", "");
        // ZOZO app / mobile links may omit the shop prefix. Each still embeds
        // a numeric goods ID. The optional /sp/ prefix carries no identity.
        Matcher m = Pattern.compile("^/(?:sp/)?(?:shop/[a-z0-9_-]+/)?goods(?:-sale)?/([0-9]{5,15})$")
                .matcher(path);
        return m.matches() ? m.group(1) : null;
    }

    public static String query(URL u, String key) {
        if (u == null || u.getQuery() == null) return "";
        for (String pair : u.getQuery().split("&")) {
            String[] kv = pair.split("=", 2);
            if (kv.length == 2 && kv[0].equalsIgnoreCase(key)) return kv[1];
        }
        return "";
    }
}
