package com.cmyk.bookmarkslauncher;

import android.text.Html;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Threads ONLY: resolve an official /share/ wrapper and read the post's PUBLIC
 * Open Graph metadata.  A generic Threads login page, another post, or an
 * unresolved share URL never becomes a bookmark post title. No sessions,
 * untrusted third-party link expanders or private API endpoints are used.
 */
final class ThreadsBookmarkMetadata {
    private ThreadsBookmarkMetadata() { }

    static final class Result {
        final String postUrl;
        final String title;
        final String imageUrl;
        Result(String postUrl, String title, String imageUrl) {
            this.postUrl = postUrl;
            this.title = title;
            this.imageUrl = imageUrl;
        }
    }

    private static final Pattern POST = Pattern.compile("^/(?:@[^/]+/post|t)/[A-Za-z0-9_-]{5,45}/?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern SHARE = Pattern.compile("^/share/[A-Za-z0-9_-]{5,90}/?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern TAG = Pattern.compile("(?is)<(?:meta|link)\\b[^>]*>");
    private static final Pattern ATTR = Pattern.compile("([a-zA-Z_:][a-zA-Z0-9_:.-]*)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))");
    private static final int MAX_HTML = 512 * 1024;

    static boolean handles(String text) {
        try {
            URL url = new URL(text);
            String host = url.getHost().toLowerCase(Locale.ROOT);
            return "https".equalsIgnoreCase(url.getProtocol()) && url.getUserInfo() == null
                    && (host.equals("threads.com") || host.endsWith(".threads.com")
                    || host.equals("threads.net") || host.endsWith(".threads.net"));
        } catch (Exception ex) { return false; }
    }

    static boolean post(String text) {
        if (!handles(text)) return false;
        try { return POST.matcher(new URL(text).getPath()).matches(); }
        catch (Exception ex) { return false; }
    }

    static boolean share(String text) {
        if (!handles(text)) return false;
        try { return SHARE.matcher(new URL(text).getPath()).matches(); }
        catch (Exception ex) { return false; }
    }

    private static String safe(String s) {
        if (s == null) return "";
        String value = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString()
                .replaceAll("[\\p{Cntrl}&&[^\\n]]+", " ")
                .replaceAll("\\s+", " ").trim();
        return value.length() > 220 ? value.substring(0, 220).trim() : value;
    }

    private static String title(String rawTitle, String description) {
        String desc = safe(description);
        String t = safe(rawTitle);
        // A URL with /post/ is NOT by itself proof that a login, challenge or
        // bare social-network shell contains post text.
        String generic = "(?i).*(?:log\\s*in(?:\\s+to)?\\s+threads|"
                + "sign\\s*in\\s+to\\s+threads|join\\s+threads|"
                + "open\\s+threads|instagram's threads|threadsにログイン|"
                + "threadsでログイン|captcha|robot check|access denied|"
                + "セキュリティチェック|ページが見つかりません).*";
        if (desc.length() >= 8 && !desc.matches(generic)
                && !desc.matches("(?i)^(?:view|see|check out|open) (?:this |the )?(?:post|thread).*"))
            return desc;
        if (t.length() >= 8 && !t.matches(generic)
                && !t.matches("(?i)^threads(?:\\s*[|•-]\\s*instagram)?$"))
            return t;
        return null;
    }

    /** Images must come from the officially verified post's public OG metadata. */
    private static String safeImage(String candidate, String pageUrl) {
        if (candidate == null || candidate.isBlank()) return null;
        try {
            URL u = new URL(new URL(pageUrl), candidate);
            if (!"https".equalsIgnoreCase(u.getProtocol()) || u.getUserInfo() != null) return null;
            String host = u.getHost().toLowerCase(Locale.ROOT);
            boolean accepted = host.equals("cdninstagram.com") || host.endsWith(".cdninstagram.com")
                    || host.equals("fbcdn.net") || host.endsWith(".fbcdn.net")
                    || host.equals("threads.com") || host.endsWith(".threads.com")
                    || host.equals("threads.net") || host.endsWith(".threads.net");
            return accepted ? u.toExternalForm() : null;
        } catch (Exception ex) { return null; }
    }

    private static String canonical(String candidate, String pageUrl) {
        if (candidate == null || candidate.isBlank()) return null;
        try {
            String absolute = new URL(new URL(pageUrl), candidate).toExternalForm();
            return post(absolute) ? absolute : null;
        } catch (Exception ex) { return null; }
    }

    /** The DOM is trusted only when its current page or OG/canonical link is a post permalink. */
    static Result fromJavascript(String escaped, String originalUrl) {
        if (!handles(originalUrl) || escaped == null) return null;
        try {
            Object value = new JSONTokener(escaped).nextValue();
            JSONObject o = new JSONObject(String.valueOf(value));
            String current = o.optString("current", "");
            if (!handles(current) || o.optBoolean("gate", false)) return null;
            String own = canonical(current, current);
            String link = canonical(o.optString("canonical", ""), current);
            String og = canonical(o.optString("ogUrl", ""), current);
            String target = own != null ? own : link != null ? link : og;
            // Share short codes don't encode a post ID. Only an explicit
            // official permalink can prove which post is being described.
            if (target == null || (link != null && og != null && !samePost(link, og))) return null;
            if (own != null && ((link != null && !samePost(own, link))
                    || (og != null && !samePost(own, og)))) return null;
            String name = title(o.optString("title", ""), o.optString("description", ""));
            if (name == null && own != null && o.optBoolean("postArticle", false))
                name = title("", o.optString("postText", ""));
            return name == null ? null : new Result(target, name,
                    safeImage(o.optString("image", ""), current));
        } catch (Exception ignored) { return null; }
    }

    private static boolean samePost(String a, String b) {
        if (a == null || b == null) return false;
        try {
            String aPath = new URL(a).getPath().replaceAll("/$", "");
            String bPath = new URL(b).getPath().replaceAll("/$", "");
            if (aPath.equalsIgnoreCase(bPath)) return true;
            // /t/CODE and /@user/post/CODE are two official permalink
            // shapes for the same post shortcode.
            String aCode = aPath.substring(aPath.lastIndexOf('/') + 1);
            String bCode = bPath.substring(bPath.lastIndexOf('/') + 1);
            return aCode.equals(bCode) && aCode.length() >= 5;
        }
        catch (Exception ignored) { return false; }
    }

    /** Read-only DOM extraction; no post content outside a proven permalink is saved. */
    static String javascript() {
        return "(function(){try{var m=function(k){var e=document.querySelector('meta[property=\\\"'+k+'\\\"],meta[name=\\\"'+k+'\\\"]');return e?e.getAttribute('content')||'':''};"
                + "var c=document.querySelector('link[rel=\\\"canonical\\\"]');"
                + "var body=(document.body&&(document.body.innerText||document.body.textContent)||'').slice(0,1600);"
                + "return JSON.stringify({current:location.href,canonical:c?c.href:'',ogUrl:m('og:url'),"
                + "title:m('og:title')||m('twitter:title')||document.title||'',"
                + "description:m('og:description')||m('twitter:description')||'',"
                + "gate:/(?:captcha|verify you are human|robot check|access denied|本人確認|セキュリティチェック)/i.test(body)});"
                + "}catch(e){return '{}';}})()";
    }

    private static Map<String, String> attrs(String tag) {
        HashMap<String, String> out = new HashMap<>();
        Matcher m = ATTR.matcher(tag);
        while (m.find()) out.put(m.group(1).toLowerCase(Locale.ROOT),
                m.group(2) != null ? m.group(2) : m.group(3) != null ? m.group(3) : m.group(4));
        return out;
    }

    static Result parseHtml(String html, String finalUrl) {
        if (!handles(finalUrl) || html == null) return null;
        String title = "", description = "", canonical = "", ogUrl = "", image = "";
        Matcher tags = TAG.matcher(html.substring(0, Math.min(html.length(), MAX_HTML)));
        while (tags.find()) {
            Map<String, String> a = attrs(tags.group());
            String key = a.getOrDefault("property", a.getOrDefault("name", "")).toLowerCase(Locale.ROOT);
            String value = a.getOrDefault("content", "");
            if ("og:title".equals(key) || ("twitter:title".equals(key) && title.isBlank())) title = value;
            if ("og:description".equals(key)
                    || ("twitter:description".equals(key) && description.isBlank())) description = value;
            if ("og:url".equals(key)) ogUrl = value;
            if ("og:image".equals(key) || ("twitter:image".equals(key) && image.isBlank())) image = value;
            if (a.getOrDefault("rel", "").equalsIgnoreCase("canonical")) canonical = a.getOrDefault("href", "");
        }
        String own = post(finalUrl) ? finalUrl : null;
        String can = canonical(canonical, finalUrl);
        String og = canonical(ogUrl, finalUrl);
        String target = own != null ? own : can != null ? can : og;
        if (target == null || (can != null && og != null && !samePost(can, og))) return null;
        if (own != null && ((can != null && !samePost(own, can))
                || (og != null && !samePost(own, og)))) return null;
        String name = title(title, description);
        return name == null ? null : new Result(target, name, safeImage(image, finalUrl));
    }

    /** A bounded HTTPS-only redirect read; normal bookmarks never invoke it. */
    static Result fetchPublic(String source) {
        if (!handles(source) || (!share(source) && !post(source))) return null;
        String current = source;
        for (int i = 0; i < 5; i++) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(current);
                conn = (HttpURLConnection) url.openConnection();
                conn.setInstanceFollowRedirects(false);
                conn.setConnectTimeout(4500);
                conn.setReadTimeout(4500);
                conn.setRequestProperty("Accept", "text/html,application/xhtml+xml");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36");
                int status = conn.getResponseCode();
                if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
                    String location = conn.getHeaderField("Location");
                    if (location == null) return null;
                    String next = new URL(url, location).toExternalForm();
                    if (!handles(next)) return null;
                    current = next;
                    continue;
                }
                if (status != 200 || conn.getContentType() == null
                        || !conn.getContentType().toLowerCase(Locale.ROOT).contains("text/html")) return null;
                try (InputStream in = conn.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                    byte[] b = new byte[8192]; int n;
                    while (output.size() < MAX_HTML && (n = in.read(b, 0,
                            Math.min(b.length, MAX_HTML - output.size()))) != -1) output.write(b, 0, n);
                    return parseHtml(new String(output.toByteArray(), StandardCharsets.UTF_8), current);
                }
            } catch (Exception ex) { return null; }
            finally { if (conn != null) conn.disconnect(); }
        }
        return null;
    }
}
