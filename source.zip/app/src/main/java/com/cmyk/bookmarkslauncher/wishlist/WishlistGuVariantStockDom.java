package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import org.json.JSONObject;

/** Exact-GU product read-only selected-variant stock inspector.
 * A displayed price or add-to-cart button is NEVER a size/color selection. */
public final class WishlistGuVariantStockDom {
    private WishlistGuVariantStockDom() { }
    public static String javascript(URL url) {
        if (WishlistGeneralShopItem.merchant(url) != WishlistGeneralShopItem.Merchant.GU)
            return "JSON.stringify({status:'UNKNOWN',reason:'not-gu'})";
        return SCRIPT.replace("__PATH__",JSONObject.quote(url.getPath().replaceAll("/+$", "")))
                .replace("__ID__",JSONObject.quote(WishlistGeneralShopItem.code(url)));
    }
    private static final String SCRIPT = """
(function(){'use strict';
 const out={status:'UNKNOWN',reason:'variant-not-selected',bound:false,heading:0,
  heroCarts:0,heroDisabled:0,heroPrice:false,heroSold:false,variants:false,
  colorSelected:false,sizeSelected:false,stockLabel:'none',
  colorCandidates:0,sizeCandidates:0,selectedControls:0,skuLabel:false,
  cartTestId:'none',variantEvidence:'none'};
 const done=()=>JSON.stringify(out);
 try{
  const u=new URL(location.href),path=__PATH__,code=__ID__;
  if(u.protocol!=='https:'||!['www.gu-global.com','gu-global.com'].includes(u.hostname)
      ||u.pathname.replace(/\\/+$/,'').toLowerCase()!==path.toLowerCase()){
   out.reason='item-url-mismatch';return done();}
  const canonical=document.querySelector('link[rel=canonical]');
  if(canonical&&canonical.href){const c=new URL(canonical.href,location.href);
   if(!['www.gu-global.com','gu-global.com'].includes(c.hostname)
       ||c.pathname.replace(/\\/+$/,'').toLowerCase()!==path.toLowerCase()){
    out.reason='canonical-mismatch';return done();}}
  const main=document.querySelector('main,[role=main]')||document.body;
  if(!main){out.reason='item-root-missing';return done();}
  const visible=e=>{if(!e)return false;
   for(let n=e;n;n=n.parentElement){if(n.hidden||n.getAttribute('aria-hidden')==='true')return false;
    const s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden')return false;}
   return true;};
  const text=e=>String((e&&(e.innerText||e.textContent))||'').trim();
  const headings=[...main.querySelectorAll('h1')].filter(visible);
  out.heading=headings.length;
  if(headings.length!==1||text(headings[0]).length<4){out.reason='heading-unverified';return done();}
  out.bound=true;
  // The product code must remain in the exact URL; other product cards do not
  // carry its selected size. Never infer inventory from price or the CTA.
  const priceMeta=[...main.querySelectorAll('[data-testid*=price], [itemprop=price]')]
    .filter(visible).slice(0,12);
  out.heroPrice=priceMeta.some(e=>/(?:[¥￥]\\s*[0-9]|[0-9]\\s*円|^[0-9][0-9,.]*$)/.test(text(e)));
  const selectors=[...main.querySelectorAll('select,button,[role=radio],[role=option],[role=button],input[type=radio]')]
    .filter(visible).slice(0,800);
  let size='',color='',stock='',stateNode=null;
  for(const e of selectors){
   const near=(e.closest('[data-testid],[data-test],[aria-label]')||e.parentElement||e);
   const k=[e.getAttribute('data-testid'),e.getAttribute('aria-label'),e.getAttribute('name'),
      near.getAttribute('data-testid'),near.getAttribute('aria-label'),near.getAttribute('name')]
      .filter(Boolean).join(' ').toLowerCase();
   if(/(?:size|サイズ)/i.test(k))out.sizeCandidates++;
   if(/(?:color|colour|カラー|色選択)/i.test(k))out.colorCandidates++;
   const selected=e.tagName==='SELECT'?(e.selectedIndex>0&&!!e.value):
     (e.getAttribute('aria-selected')==='true'||e.getAttribute('aria-checked')==='true'||
      e.getAttribute('aria-pressed')==='true'||e.getAttribute('data-selected')==='true'||
      e.getAttribute('data-state')==='checked'||e.getAttribute('data-state')==='selected'||
      (e.matches&&e.matches('input:checked'))||
      /(?:^|\s)(?:selected|is-selected)(?:\s|$)/i.test(String(e.className||'')));
   // A placeholder or disabled control is not a chosen variant.
   if(e.disabled||/(?:選択してください|選んでください|select (?:a )?(?:size|color))/i.test(text(e)))continue;
   if(!selected)continue;
   out.selectedControls++;
   if(/(?:size|サイズ)/i.test(k)){size=String(e.value||text(e)).slice(0,60);stateNode=near;}
   if(/(?:color|colour|カラー|色選択)/i.test(k))color=String(e.value||text(e)).slice(0,60);
  }
  out.sizeSelected=!!size;out.colorSelected=!!color;out.variants=!!size&&!!color;
  const controls=[...main.querySelectorAll('button')].filter(visible);
  out.heroCarts=controls.filter(e=>/(?:カートに入れる|カートに追加|add to cart)/i.test(text(e))&&!e.disabled).length;
  out.heroDisabled=controls.filter(e=>/(?:カートに入れる|カートに追加|add to cart)/i.test(text(e))&&e.disabled).length;
  const carts=controls.filter(e=>/(?:カートに入れる|カートに追加|add to cart)/i.test(text(e)));
  out.cartTestId=carts.length===1?String(carts[0].getAttribute('data-testid')||'none').slice(0,45):'none';
  // Deliberately no inference from a live CTA: default SKU, selected color
  // and selected size must be established before stock can be classified.
  out.variantEvidence=!out.colorCandidates&&!out.sizeCandidates?'selectors-not-found':
    !out.colorSelected&&!out.sizeSelected?'selection-not-represented':
    !out.colorSelected?'color-unconfirmed':!out.sizeSelected?'size-unconfirmed':'confirmed';
  if(!out.variants){out.reason='selected-color-size-unverified';return done();}
  // Only the selected size's immediate region, not global page text/store
  // inventory/related product banners, can establish in-stock/out-of-stock.
  const region=stateNode&&(stateNode.closest('[data-testid*=size],[data-testid*=stock],[role=radiogroup]')||stateNode.parentElement||stateNode);
  stock=text(region).slice(0,280);
  if(/(?:在庫あり|在庫残りわずか)/.test(stock)&&!/(?:在庫なし|在庫切れ)/.test(stock)){
   out.status='AVAILABLE';out.stockLabel='in';out.reason='selected-variant-online-in-stock';
  }else if(/(?:在庫なし|在庫切れ)/.test(stock)&&!/(?:在庫あり|在庫残りわずか)/.test(stock)){
   out.status='UNAVAILABLE';out.stockLabel='out';out.heroSold=true;out.reason='selected-variant-online-out-of-stock';
  }else out.reason='selected-variant-stock-unverified';
  return done();
 }catch(_){out.reason='gu-script-error';return done();}
})()
""";
}
