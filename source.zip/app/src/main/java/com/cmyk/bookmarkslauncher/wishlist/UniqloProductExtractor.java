package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** UNIQLO mode ONLY. Product + color/size/length must never be inferred from another SKU. */
final class UniqloProductExtractor {
    private static final Pattern TITLE=Pattern.compile("(?is)<h1\\b[^>]*>(.*?)</h1>");
    private UniqloProductExtractor() {}
    static void parse(String html, URL page, WishlistCrawler.Result out) {
        if(WishlistMode.forLargeRetailUrl(page)!=WishlistMode.UNIQLO || !LargeRetailHtml.validCanonical(html,page)){
            out.availabilityReason="UNIQLOの商品同一性が確認できません";return;
        }
        // Three independent data paths; empty fields never erase a previous success.
        Matcher t=TITLE.matcher(html);
        out.title=LargeRetailHtml.cleanTitle(t.find()?t.group(1).replaceAll("<[^>]+>","")
                :LargeRetailHtml.ogTitle(html),"UNIQLO");
        out.imageUrl=LargeRetailHtml.mainImage(html,"UNIQLO");
        // Only use price metadata bound to this exact product page; text such as
        // ¥0 alteration fee or a different size must not become the sale price.
        out.price=LargeRetailHtml.metaYenPrice(html);
        out.status="UNKNOWN";
        out.availabilityReason="UNIQLO選択カラー・サイズ・レングスの在庫は描画DOMで確認が必要";
    }
    static String domScript(){return LargeRetailDomScripts.uniqlo();}
}
