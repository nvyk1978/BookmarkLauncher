package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Stock ONLY; strong product-specific evidence or UNKNOWN, never page-wide sold-out scans. */
final class MarketplaceAvailabilityExtractor {
    private static final Pattern BUTTON=Pattern.compile("(?is)<button\\b([^>]*)>(.*?)</button\\s*>");
    private static final Pattern INPUT=Pattern.compile("(?is)<input\\b([^>]*)>");
    private static final Pattern INACTIVE=Pattern.compile("(?i)(?:\\sdisabled(?:[\\s=>]|$)|aria-disabled\\s*=\\s*['\"]?true|aria-hidden\\s*=\\s*['\"]?true|display\\s*:\\s*none|visibility\\s*:\\s*hidden)");
    private static final Pattern CART=Pattern.compile("(?i)(?:add[-_.]?to[-_.]?cart|submit\\.add-to-cart|buy[-_.]?now|カートに入れる|買い物かごに入れる|かごに入れる|カゴに入れる|購入する|注文する|basket|cart-button)");
    private static final Pattern PRODUCT_BLOCK=Pattern.compile("(?is)<(?:div|section|form)\\b[^>]*\\b(?:id|class)\\s*=\\s*['\"][^'\"]*(?:buybox|buy-box|product-detail|item-detail|productInfo|product-info|purchase|add-to-cart|cart-form)[^'\"]*['\"][^>]*>");
    private static final Pattern UNAVAILABLE=Pattern.compile("(?i)売り切れ|売切れ|完売|在庫切れ|sold\\s*out|out\\s*of\\s*stock");
    private MarketplaceAvailabilityExtractor(){}
    static WishlistAvailabilityExtractor.Result parse(String html,URL page){
        MarketplaceIdentity identity=MarketplaceIdentity.from(page);
        if(identity==null||!identity.verified(html,page))return new WishlistAvailabilityExtractor.Result("UNKNOWN",false,"対象商品URL未確認");
        JSONObject product=MarketplaceProductJsonLd.find(html,page);
        String structured="UNKNOWN";
        if(product!=null){
            Set<String> states=new HashSet<>();
            offers(product.opt("offers"),states,0);
            if(states.size()>1)return new WishlistAvailabilityExtractor.Result("UNKNOWN",false,"商品のバリエーションに在庫状態の相違");
            if(states.size()==1)structured=states.iterator().next();
        }
        boolean cart=hasMainCart(html,identity);
        if(!"UNKNOWN".equals(structured)){
            if("UNAVAILABLE".equals(structured)&&cart)return new WishlistAvailabilityExtractor.Result("UNKNOWN",false,"商品固有在庫情報と購入操作が矛盾");
            return new WishlistAvailabilityExtractor.Result(structured,true,"対象商品JSON-LDの在庫情報");
        }
        if(cart)return new WishlistAvailabilityExtractor.Result("AVAILABLE",false,"商品固有の購入操作を確認");
        return new WishlistAvailabilityExtractor.Result("UNKNOWN",false,"対象商品の在庫情報・購入操作が未確認");
    }
    private static void offers(Object node,Set<String> dest,int depth){
        if(node==null||depth>8)return;
        if(node instanceof JSONArray){JSONArray a=(JSONArray)node;for(int i=0;i<Math.min(40,a.length());i++)offers(a.opt(i),dest,depth+1);}
        if(node instanceof JSONObject){
            JSONObject o=(JSONObject)node;
            String state=WishlistAvailabilityExtractor.parseAvailability(o.optString("availability",null));
            if(!"UNKNOWN".equals(state))dest.add(state);
            offers(o.opt("offers"),dest,depth+1);
            offers(o.opt("hasVariant"),dest,depth+1);
        }
    }
    private static boolean hasMainCart(String html,MarketplaceIdentity identity){
        // Amazon's add-to-cart ID and name are attached to the requested ASIN's
        // main buy-box, unlike the numerous page-wide related product buttons.
        if(identity.site==MarketplaceIdentity.Site.AMAZON){
            String block=block(html,"buybox","desktop_buybox","addToCart","atcRedesignId","buyBoxInner");
            return block!=null&&hasCartControl(block);
        }
        // Rakuten/Yahoo: require an identified product purchase block.
        Matcher scopes=PRODUCT_BLOCK.matcher(html);
        int examined=0;
        while(scopes.find()&&examined++<18){
            String open=scopes.group();
            if(open.matches("(?is).*?(?:recommend|related|ranking|review|sidebar).*"))continue;
            String fragment=html.substring(scopes.start(),Math.min(html.length(),scopes.start()+7000));
            // Clip before related/product-ranking region; do not scan all products.
            Matcher unrelated=Pattern.compile("(?i)recommend|related|ranking|関連商品|おすすめ商品").matcher(fragment);
            if(unrelated.find())fragment=fragment.substring(0,unrelated.start());
            if(hasCartControl(fragment))return true;
        }
        return false;
    }
    private static String block(String html,String... markers){
        for(String marker:markers){
            Pattern p=Pattern.compile("(?is)<(?:div|section|form)\\b[^>]*\\bid\\s*=\\s*['\"]"+Pattern.quote(marker)+"['\"][^>]*>");
            Matcher match=p.matcher(html);
            if(match.find())return html.substring(match.end(),Math.min(html.length(),match.end()+6000));
        }
        return null;
    }
    private static boolean hasCartControl(String html){
        Matcher buttons=BUTTON.matcher(html);
        while(buttons.find()){
            String attrs=buttons.group(1);
            if(INACTIVE.matcher(attrs).find())continue;
            String label=attrs+" "+buttons.group(2).replaceAll("(?s)<[^>]*>"," ");
            if(CART.matcher(label).find()&&!UNAVAILABLE.matcher(label).find())return true;
        }
        Matcher inputs=INPUT.matcher(html);
        while(inputs.find()){
            String attrs=inputs.group(1);
            if(INACTIVE.matcher(attrs).find())continue;
            if(CART.matcher(attrs).find()&&!UNAVAILABLE.matcher(attrs).find())return true;
        }
        return false;
    }
}
