package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import org.json.JSONObject;

/** Isolated read-only availability evidence for four exact GENERAL item routes.
 * No cart clicks, no cross-product price/stock, no automatic variant selection.
 * A known route alone NEVER proves product inventory. */
public final class WishlistGeneralShopStockDom {
    private WishlistGeneralShopStockDom() { }
    public static boolean supports(URL u) { return WishlistGeneralShopItem.isDetail(u); }
    public static String javascript(URL original) {
        if (!supports(original)) return "JSON.stringify({status:'UNKNOWN',reason:'not-supported'})";
        return SCRIPT.replace("__HOST__",JSONObject.quote(original.getHost().toLowerCase(java.util.Locale.ROOT)))
            .replace("__PATH__",JSONObject.quote(original.getPath().replaceAll("/+$", "")))
            .replace("__ID__",JSONObject.quote(WishlistGeneralShopItem.code(original)))
            .replace("__SHOP__",JSONObject.quote(WishlistGeneralShopItem.merchant(original).name()));
    }
    private static final String SCRIPT = """
(function(){'use strict';
 const o={status:'UNKNOWN',reason:'uninspected',bound:false,heading:0,heroCarts:0,
  heroDisabled:0,heroSold:false,heroPrice:false,variants:false,canonical:'missing'};
 const done=()=>JSON.stringify(o);
 try{
  const shop=__SHOP__,expectedHost=__HOST__,expectedPath=__PATH__,item=__ID__;
  const host=h=>String(h||'').toLowerCase().replace(/^www\\./,'');
  const norm=p=>String(p||'').replace(/\\/+$/,'').toLowerCase();
  const same=u=>{try{const x=new URL(u,location.href);
    return x.protocol==='https:'&&host(x.hostname)===host(expectedHost)&&norm(x.pathname)===norm(expectedPath);
   }catch(_){return false;}};
  if(!same(location.href)){o.reason='item-url-mismatch';return done();}
  const canon=document.querySelector('link[rel=canonical]');
  if(canon&&canon.href){o.canonical=same(canon.href)?'same':'different';
    if(o.canonical==='different'){o.reason='wrong-canonical';return done();}}
  const main=document.querySelector('main,[role=main],#main,#contents,#content')||document.body;
  if(!main){o.reason='no-main';return done();}
  const blocked='header,nav,footer,aside,[class*=recommend],[id*=recommend],'+
    '[class*=related],[id*=related],[class*=ranking],[class*=carousel]';
  const text=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ').trim();
  const visible=e=>{if(!e||e.closest(blocked))return false;
    for(let p=e;p;p=p.parentElement){if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return false;
      const s=getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||Number(s.opacity)===0)return false;
    }return true;};
  const h1s=[...main.querySelectorAll('h1')].filter(visible);
  o.heading=h1s.length;
  if(h1s.length!==1||text(h1s[0]).length<3){o.reason='item-heading-unverified';return done();}
  const h1=h1s[0];
  // Strict item route plus its unique primary H1; no other product links or body-wide stock data.
  o.bound=true;
  // The product hero ends before the next h2/related section. This excludes
  // Green Beans' many enabled recommendation-grid cart buttons.
  const stop=main.querySelectorAll('h2,h3,[data-test*=recommend],[id*=recommend]');
  let end=null;
  for(const s of stop){if(h1.compareDocumentPosition(s)&Node.DOCUMENT_POSITION_FOLLOWING){
    end=s;break;}}
  const after=e=>!!(h1.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_FOLLOWING);
  const before=e=>!end||!!(e.compareDocumentPosition(end)&Node.DOCUMENT_POSITION_FOLLOWING);
  const heroElements=[...main.querySelectorAll('button,[role=button],input[type=submit],input[type=button]')]
    .filter(e=>after(e)&&before(e)&&!e.closest(blocked));
  const add=/(?:カート|カゴ|かご)\\s*(?:に|へ)?\\s*(?:入れる|追加)|購入手続きへ|購入する|今すぐ購入|add\\s*to\\s*cart|buy\\s*now/i;
  const cart=heroElements.filter(e=>add.test([text(e),e.value,e.getAttribute('aria-label')].filter(Boolean).join(' ').slice(0,160)));
  const enabled=cart.filter(e=>visible(e)&&!e.disabled&&!e.hasAttribute('disabled')&&e.getAttribute('aria-disabled')!=='true');
  o.heroCarts=enabled.length;o.heroDisabled=cart.length-enabled.length;
  const region=[];
  let element=h1;
  while(element&&region.join(' ').length<3500){
    element=element.nextElementSibling;
    if(!element||element===end||/^H[23]$/.test(element.tagName))break;
    region.push(text(element).slice(0,1000));
  }
  // Main text can be nested within containers; restrict to the substring
  // starting at the unique H1, ending at recommendations / product-description section.
  const whole=text(main),begin=whole.indexOf(text(h1));
  let local=begin>=0?whole.slice(begin,begin+2300):'';
  // Stop at the actual next section heading, not an arbitrary promo title.
  // An unrelated sale banner may say 売り切れ次第終了 even while this product is in stock.
  if(end){const marker=text(end);const pos=marker?local.indexOf(marker): -1;
    if(pos>35)local=local.slice(0,pos);}
  const cut=local.search(/(?:関連商品|よく一緒に|おすすめ商品|商品説明|商品の説明|レビュー)/);
  if(cut>35)local=local.slice(0,cut);
  o.heroPrice=/(?:[¥￥]\\s*[0-9][0-9,]{1,8}|[0-9][0-9,]{1,8}\\s*円)/.test(local.slice(0,900));
  // A negative status is only actionable when isolated to the product hero.
  const sold=/(?:売り切れました|売り切れ|売切れ|完売|在庫切れ|在庫なし|sold\\s*out|out\\s*of\\s*stock)/i;
  const positive=/(?:在庫\\s*[:：]?\\s*(?:あり|有り)|在庫あり|in\\s*stock|購入可能)/i;
  o.heroSold=sold.test(local);
  const variantControls=[...main.querySelectorAll('select[required],[aria-required=true]')].filter(visible);
  o.variants=variantControls.length>0&&variantControls.every(x=>x.tagName==='SELECT'?
    !!x.value&&x.selectedIndex>=0:(x.getAttribute('aria-selected')==='true'||x.getAttribute('aria-checked')==='true'));
  if(shop==='MERCARI'){
    // The sale status is an explicit one-item label near the saved listing's H1.
    if(/売り切れました/.test(local.slice(0,1100))){o.status='UNAVAILABLE';o.reason='listing-sold-label';return done();}
    if(enabled.length===1&&o.heroPrice&&!o.heroSold){o.status='AVAILABLE';o.reason='item-purchase-button';return done();}
    o.reason='listing-sale-state-unverified';return done();
  }
  if(o.heroSold&&shop!=='LOHACO'){o.reason='negative-item-evidence';return done();}
  if(shop==='GREENBEANS'){
    // Exact /products/<numeric>/details + one H1 + one live action BEFORE recommendations,
    // plus a matching local displayed price. Cart actions in related cards excluded.
    if(enabled.length===1&&o.heroPrice){o.status='AVAILABLE';o.reason='hero-price-and-cart';}
    else o.reason=enabled.length?'ambiguous-hero-cart':'hero-cart-unverified';
    return done();
  }
  if(shop==='LOHACO'){
    // LOHACO's checkout button can sit in a separate sibling after the first
    // H2, not directly after H1. Do not silently classify a recommendation:
    // compare only the SAME main product area and require a unique live CTA,
    // unambiguous item price and no sold-out text. This is the observed
    // default-region offer, not a promise for every destination postcode.
    const actions=[...main.querySelectorAll('button,[role=button],input[type=submit],input[type=button]')];
    // A product CTA can be hosted in one open ShadowRoot in the same main area.
    // Never enter header, nav or unrelated recommendation shadow subtrees.
    for(const host of [...main.querySelectorAll('*')].slice(0,1700)){
      if(host.shadowRoot&&!host.closest(blocked)&&after(host)){
        for(const el of [...host.shadowRoot.querySelectorAll('button,[role=button],input[type=submit],input[type=button]')].slice(0,40))
          actions.push(el);
      }
    }
    const itemActions=actions.filter(e=>!e.closest(blocked)&&visible(e)
        &&(e.getRootNode&&e.getRootNode().host?true:after(e))
        &&!e.disabled&&!e.hasAttribute('disabled')
        &&e.getAttribute('aria-disabled')!=='true'
        &&add.test([text(e),e.value,e.getAttribute('aria-label'),e.getAttribute('title')]
          .filter(Boolean).join(' ').slice(0,180)));
    const section=text(main).slice(0,8500),at=section.indexOf(text(h1));
    const afterTitle=at<0?'':section.slice(at+text(h1).length,at+text(h1).length+2200);
    const itemIntro=afterTitle.split(/(?:関連商品|おすすめ商品|よく一緒に|レビュー一覧|プロモーション)/)[0];
    const priceMention=itemIntro.match(/(?:[¥￥]\s*[0-9][0-9,]{1,8}|[0-9][0-9,]{1,8}\s*円)/);
    const beforePrice=priceMention?itemIntro.slice(Math.max(0,priceMention.index-20),priceMention.index).trim():'';
    const salePrice=!!priceMention&&!/(?:送料|配送料|手数料|ポイント|クーポン|割引)\s*[:：は別途]*$/.test(beforePrice);
    const localSold=/(?:売り切れました|売り切れ(?!次第)|売切れ|在庫切れ|在庫なし|完売|sold\s*out|out\s*of\s*stock)/i.test(itemIntro);
    o.heroCarts=itemActions.length;
    o.heroPrice=salePrice;
    o.heroSold=localSold;
    if(itemActions.length===1&&salePrice&&!localSold){
      o.status='AVAILABLE';o.reason='item-main-live-cart';
    } else o.reason=itemActions.length>1?'ambiguous-item-actions':
       !salePrice?'item-price-unverified':localSold?'negative-item-evidence':'hero-cart-unverified';
    return done();
  }
  if(shop==='GU'){
    // Size/color may be unselected: don't assert stock from page price or generic CTA.
    if(enabled.length===1&&o.variants&&positive.test(local)){o.status='AVAILABLE';o.reason='selected-variant-stock';}
    else o.reason='selected-variant-unverified';
    return done();
  }
  o.reason='not-supported';return done();
 }catch(_){o.reason='dom-error';return done();}
})()
""";
}
