package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import org.json.JSONArray;
import java.net.URL;
import java.util.Locale;

/**
 * Amazon product image recovery ONLY. Does not parse name, price or stock, and never
 * writes database fields. Foreground + user-requested, no background polling.
 */
public final class WishlistImageWebViewProbe {
    public interface Callback { void completed(String imageUrl); }
    private final Handler main = new Handler(Looper.getMainLooper());
    private final FrameLayout parent;
    private WebView web;
    private Callback callback;
    private String originalHost;
    private boolean finished;
    private final Runnable timeout = () -> finish(null);

    public WishlistImageWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public static boolean isAmazonUrl(String text) {
        try {
            URL url = new URL(text);
            String host = url.getHost().toLowerCase(Locale.ROOT);
            return "https".equalsIgnoreCase(url.getProtocol()) && WishlistCrawler.isAllowedUrl(url)
                    && (host.equals("amazon.co.jp") || host.endsWith(".amazon.co.jp"));
        } catch (Exception ignored) { return false; }
    }

    public void start(String urlText, Callback onDone) {
        cancel();
        callback = onDone;
        finished = false;
        if (Looper.myLooper() != Looper.getMainLooper() || !isAmazonUrl(urlText)) {
            finish(null); return;
        }
        try {
            originalHost = new URL(urlText).getHost().toLowerCase(Locale.ROOT);
            web = new WebView(parent.getContext());
            web.setBackgroundColor(Color.TRANSPARENT);
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            // Behind Wishlist cards, with a full viewport for lazily initialized images.
            parent.addView(web, 0, p);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return request.isForMainFrame() && !isAllowedPage(request.getUrl().toString());
                }
                @Override public void onPageFinished(WebView view, String url) {
                    if (finished || !isAllowedPage(url)) return;
                    main.postDelayed(() -> { if (!finished && view == web) inspect(view); }, 1200);
                }
                @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError error) {
                    if (req.isForMainFrame()) finish(null);
                }
            });
            main.postDelayed(timeout, 14000);
            web.loadUrl(urlText);
        } catch (Exception ignored) { finish(null); }
    }

    private boolean isAllowedPage(String text) {
        return isAmazonUrl(text);
    }

    private void inspect(WebView view) {
        // Select the main product image only: no generic page images, ads or recommendations.
        // The JavaScript returns only a candidate HTTPS URL. No page code is injected.
        final String js = "(function(){"+
                "function valid(s){if(!s||typeof s!=='string')return '';"+
                "try{var u=new URL(s,location.href);var h=u.hostname.toLowerCase();"+
                "if(u.protocol!=='https:')return '';"+
                "if(!(h==='media-amazon.com'||h.endsWith('.media-amazon.com')||"+
                "h==='ssl-images-amazon.com'||h.endsWith('.ssl-images-amazon.com')))return '';"+
                "return u.href;}catch(e){return '';}}"+
                "function dynamic(el){var raw=el.getAttribute('data-a-dynamic-image');"+
                "if(!raw)return '';try{var v=JSON.parse(raw),b='',area=0;"+
                "Object.keys(v).forEach(function(k){var d=v[k],a=Array.isArray(d)?d[0]*d[1]:0;"+
                "if(a>area&&valid(k)){b=k;area=a;}});return valid(b);}catch(e){return '';}}"+
                "var ids=['#landingImage','#imgBlkFront','#ebooksImgBlkFront',"+
                "'#imgTagWrapperId img','#main-image-container img',"+
                "'#main-image','#ivLargeImage img'];"+
                "for(var i=0;i<ids.length;i++){var el=document.querySelector(ids[i]);if(!el)continue;"+
                "var x=dynamic(el)||valid(el.getAttribute('data-old-hires'))||"+
                "valid(el.getAttribute('data-a-hires'))||valid(el.currentSrc)||"+
                "valid(el.getAttribute('data-src'))||valid(el.getAttribute('src'));"+
                "if(x)return x;}"+
                "var meta=document.querySelector('meta[property=\"og:image:secure_url\"],meta[property=\"og:image\"]');"+
                "return meta?valid(meta.content):'';"+
                "})()";
        try {
            view.evaluateJavascript(js, returned -> {
                if (finished) return;
                try {
                    String result = new JSONArray("[" + returned + "]").optString(0, "");
                    finish(allowedImage(result) ? result : null);
                } catch (Exception ignored) { finish(null); }
            });
        } catch (Exception ignored) { finish(null); }
    }

    private static boolean allowedImage(String link) {
        try {
            URL url = new URL(link);
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) return false;
            String h = url.getHost().toLowerCase(Locale.ROOT);
            return h.equals("media-amazon.com") || h.endsWith(".media-amazon.com") ||
                    h.equals("ssl-images-amazon.com") || h.endsWith(".ssl-images-amazon.com");
        } catch (Exception ignored) { return false; }
    }

    private void finish(String imageUrl) {
        if (finished) return;
        finished = true;
        main.removeCallbacks(timeout);
        Callback cb = callback;
        callback = null;
        if (web != null) {
            WebView old = web;
            web = null;
            try { old.stopLoading(); old.loadUrl("about:blank"); parent.removeView(old); old.destroy(); }
            catch (Exception ignored) { }
        }
        if (cb != null) cb.completed(imageUrl);
    }

    public void cancel() { callback = null; finish(null); }
}
