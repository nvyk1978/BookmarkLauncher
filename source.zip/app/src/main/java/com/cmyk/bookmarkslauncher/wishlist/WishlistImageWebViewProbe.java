package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import org.json.JSONArray;
import java.net.URL;
import java.util.Locale;

/**
 * Amazon product image recovery ONLY. Does not parse name, price or stock, and never
 * writes database fields. Foreground + user-requested, no background polling.
 */
public final class WishlistImageWebViewProbe {
    public interface Callback { void completed(String imageUrl); }
    private final Handler main = new Handler(Looper.getMainLooper());
    private final FrameLayout parent;
    private WebView web;
    private Callback callback;
    private String originalHost;
    private MarketplaceIdentity expectedProduct;
    private boolean finished;
    private boolean pendingInspection;
    private int attempts;
    private static final int MAX_INSPECTIONS = 9;
    private final Runnable timeout = () -> finish(null);

    public WishlistImageWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public static boolean isAmazonUrl(String text) {
        try {
            URL url = new URL(text);
            String host = url.getHost().toLowerCase(Locale.ROOT);
            return "https".equalsIgnoreCase(url.getProtocol()) && WishlistCrawler.isAllowedUrl(url)
                    && (host.equals("amazon.co.jp") || host.endsWith(".amazon.co.jp"));
        } catch (Exception ignored) { return false; }
    }

    public void start(String urlText, Callback onDone) {
        cancel();
        callback = onDone;
        finished = false;
        attempts = 0;
        pendingInspection = false;
        if (Looper.myLooper() != Looper.getMainLooper() || !isAmazonUrl(urlText)) {
            finish(null); return;
        }
        try {
            URL initialUrl = new URL(urlText);
            expectedProduct = MarketplaceIdentity.from(initialUrl);
            if (expectedProduct == null || expectedProduct.site != MarketplaceIdentity.Site.AMAZON) {
                finish(null); return;
            }
            originalHost = initialUrl.getHost().toLowerCase(Locale.ROOT);
            web = BackgroundDomWebView.create(parent.getContext());





            web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setClickable(false);
            web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.setVerticalScrollBarEnabled(false);
            web.setHorizontalScrollBarEnabled(false);

            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return request.isForMainFrame() && !isAllowedPage(request.getUrl().toString());
                }
                @Override public void onPageFinished(WebView view, String url) {
                    if (finished || !isAllowedPage(url)) return;
                    // Amazon frequently injects its primary image after page-finished.
                    // Retry a small, bounded number of times rather than giving up on
                    // the first empty DOM snapshot.
                    scheduleInspection(view, 750);
                }
                @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError error) {
                    if (req.isForMainFrame()) finish(null);
                }
            });
            main.postDelayed(timeout, 18000);
            web.loadUrl(urlText);
        } catch (Exception ignored) { finish(null); }
    }

    private boolean isAllowedPage(String text) {
        try { return isAmazonUrl(text) && expectedProduct != null
                && expectedProduct.matches(new URL(text)); }
        catch (Exception ignored) { return false; }
    }

    private void scheduleInspection(WebView view, long delayMs) {
        if (finished || pendingInspection || view != web) return;
        pendingInspection = true;
        main.postDelayed(() -> {
            pendingInspection = false;
            if (!finished && view == web) inspect(view);
        }, delayMs);
    }

    private void inspect(WebView view) {
        attempts++;
        // Image pipeline only. Return the primary product's HTTPS image URL,
        // never a pricing value, script text, listing thumbnail or advertisement.
        final String js = "(function(){"+
                "function valid(s){if(!s||typeof s!=='string')return '';"+
                "try{var u=new URL(s,location.href),h=u.hostname.toLowerCase();"+
                "if(u.protocol!=='https:')return '';"+
                "if(!(h==='media-amazon.com'||h.endsWith('.media-amazon.com')||"+
                "h==='ssl-images-amazon.com'||h.endsWith('.ssl-images-amazon.com')))return '';"+
                "if(u.pathname.indexOf('/images/I/')!==0)return '';"+
                "return u.href;}catch(e){return '';}}"+
                "function dynamic(el){var raw=el.getAttribute('data-a-dynamic-image');"+
                "if(!raw)return '';try{var v=JSON.parse(raw),b='',area=0;"+
                "Object.keys(v).forEach(function(k){var d=v[k],a=Array.isArray(d)?d[0]*d[1]:0;"+
                "if(a>area&&valid(k)){b=k;area=a;}});return valid(b);}catch(e){return '';}}"+
                "function srcset(el){var s=el.getAttribute('srcset')||'';"+
                "if(!s)return '';var parts=s.split(','),best='';"+
                "for(var i=parts.length-1;i>=0;i--){var u=valid(parts[i].trim().split(/\\s+/)[0]);"+
                "if(u){best=u;break;}}return best;}"+
                "function candidate(el){if(!el)return '';"+
                "return dynamic(el)||valid(el.getAttribute('data-old-hires'))||"+
                "valid(el.getAttribute('data-a-hires'))||valid(el.getAttribute('data-main-image'))||"+
                "srcset(el)||valid(el.currentSrc)||valid(el.getAttribute('data-src'))||"+
                "valid(el.getAttribute('src'));}"+
                "var selectors=['#landingImage','#imgBlkFront','#ebooksImgBlkFront',"+
                "'#imgTagWrapperId img','#main-image-container img',"+
                "'#main-image','#ivLargeImage img','#imageBlock img[data-a-dynamic-image]',"+
                "'#imageBlock img'];"+
                "for(var i=0;i<selectors.length;i++){var x=candidate(document.querySelector(selectors[i]));"+
                "if(x)return x;}"+
                "return '';"+
                "})()";
        try {
            view.evaluateJavascript(js, returned -> {
                if (finished || view != web) return;
                String result = null;
                try { result = new JSONArray("[" + returned + "]").optString(0, ""); }
                catch (Exception ignored) { }
                if (allowedImage(result)) {
                    finish(result);
                } else if (attempts < MAX_INSPECTIONS) {
                    scheduleInspection(view, 1100);
                } else {
                    finish(null);
                }
            });
        } catch (Exception ignored) { finish(null); }
    }

    private static boolean allowedImage(String link) {
        try {
            URL url = new URL(link);
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) return false;
            String h = url.getHost().toLowerCase(Locale.ROOT);
            return (h.equals("media-amazon.com") || h.endsWith(".media-amazon.com") ||
                    h.equals("ssl-images-amazon.com") || h.endsWith(".ssl-images-amazon.com"))
                    && url.getPath().startsWith("/images/I/");
        } catch (Exception ignored) { return false; }
    }

    private void finish(String imageUrl) {
        if (finished) return;
        finished = true;
        main.removeCallbacks(timeout);
        Callback cb = callback;
        callback = null;
        if (web != null) {
            WebView old = web;
            web = null;
            try { old.stopLoading(); old.loadUrl("about:blank");  old.destroy(); }
            catch (Exception ignored) { }
        }
        if (cb != null) cb.completed(imageUrl);
    }

    public void cancel() { callback = null; finish(null); }
}
