package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Purchase-availability ONLY. No price, image, title or page-reachability logic.
 * A banner/related-product/template's "売り切れ" must never mark the current item sold out.
 * Where the signals disagree, report UNKNOWN instead of an incorrect UNAVAILABLE.
 */
final class WishlistAvailabilityExtractor {
    private static final Pattern LD_SCRIPT = Pattern.compile(
            "(?is)<script\\b([^>]*)>(.*?)</script\\s*>");
    private static final Pattern PRODUCT_TYPE = Pattern.compile(
            "(?is)\\\"@type\\\"\\s*:\\s*(?:\\\"(?:https?://[^\\\"]*[/#])?Product\\\"|\\[[^\\]]{0,180}\\\"Product\\\"[^\\]]*\\])");
    private static final Pattern BUTTON = Pattern.compile("(?is)<button\\b([^>]*)>(.*?)</button\\s*>");
    private static final Pattern INPUT = Pattern.compile("(?is)<input\\b([^>]*)>");
    private static final Pattern ATTR_VALUE = Pattern.compile("(?is)\\bvalue\\s*=\\s*(?:\\\"([^\\\"]*)\\\"|'([^']*)'|([^\\s>]+))");
    private static final Pattern ACTIVE_CART_TEXT = Pattern.compile(
            "(?i)(?:カートに入れる|買い物かごに入れる|カゴに入れる|購入する|注文する|add\\s+to\\s+(?:cart|bag))");
    private static final Pattern SOLD_OUT_TEXT = Pattern.compile(
            "(?i)(?:売り切れ|売切れ|完売|在庫切れ|sold\\s*out|out\\s*of\\s*stock)");
    private static final Pattern INACTIVE_ATTR = Pattern.compile(
            "(?i)(?:\\sdisabled(?:\\s|=|$)|\\shidden(?:\\s|=|$)|aria-hidden\\s*=\\s*['\\\"]?true|aria-disabled\\s*=\\s*['\\\"]?true|display\\s*:\\s*none|visibility\\s*:\\s*hidden)");

    private WishlistAvailabilityExtractor() { }

    static Result parse(String html, URL page, String productOfferAvailability, String metaAvailability) {
        if (html == null || page == null) return new Result("UNKNOWN", false);
        if (!isProductDetail(page)) return new Result("UNKNOWN", false);

        // Only accept structured stock metadata if there is ONE unambiguous
        // Product node in the JSON-LD. Else it might belong to a recommendation.
        int productCount = countProductNodes(html);
        String raw = productCount == 1 ? productOfferAvailability : null;
        // A product:availability meta may be site-wide or refer to a variant.
        // Do not treat it as proof of a sold-out product without a Product node.
        if (raw == null && productCount == 1) raw = metaAvailability;
        String structured = parseAvailability(raw);
        // Variable products may have multiple Offer entries with different
        // availability values. The first Offer is NOT necessarily the selected
        // purchasable variant. Never inherit a sibling variant's sold-out state.
        if (hasConflictingOffers(html)) structured = "UNKNOWN";
        boolean enabledCart = hasEnabledCartControl(html);

        if ("UNAVAILABLE".equals(structured) && enabledCart) {
            // E.g. hidden template says "完売" but a usable cart button is present.
            return new Result("UNKNOWN", false);
        }
        if (!"UNKNOWN".equals(structured)) return new Result(structured, true);

        // An enabled, current-product cart button is weak positive evidence only.
        // Visible status cannot be proven from raw HTML; conflicting page-wide
        // text (including hidden template content) forces UNKNOWN.
        if (enabledCart && !SOLD_OUT_TEXT.matcher(html).find())
            return new Result("AVAILABLE", false);
        return new Result("UNKNOWN", false);
    }

    static final class Result {
        final String status;
        final boolean explicit;
        Result(String status, boolean explicit) { this.status = status; this.explicit = explicit; }
    }

    static String parseAvailability(String raw) {
        if (raw == null) return "UNKNOWN";
        String s = raw.toLowerCase(Locale.ROOT).trim();
        if (s.endsWith("/instock") || s.endsWith("#instock") || s.equals("instock")
                || s.endsWith("/preorder") || s.endsWith("/presale")) return "AVAILABLE";
        if (s.endsWith("/outofstock") || s.endsWith("/soldout") || s.endsWith("/discontinued")
                || s.equals("outofstock") || s.equals("soldout") || s.equals("discontinued")) return "UNAVAILABLE";
        if (s.endsWith("/prelaunch") || s.equals("prelaunch")) return "COMING_SOON";
        return "UNKNOWN";
    }

    private static boolean isProductDetail(URL url) {
        String host = url.getHost().toLowerCase(Locale.ROOT);
        String path = url.getPath().toLowerCase(Locale.ROOT);
        // Keep Amazon's dedicated name/price/image pipelines unchanged.
        if (host.equals("amazon.co.jp") || host.endsWith(".amazon.co.jp") || host.equals("amazon.com") || host.endsWith(".amazon.com"))
            return path.matches("(?i).*/(?:dp|gp/product)/[a-z0-9]{10}(?:/.*)?");
        return WishlistCrawler.isSingleProductPage(url);
    }

    private static boolean hasConflictingOffers(String html) {
        Pattern availability = Pattern.compile("(?is)\\\"availability\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
        Matcher scripts = LD_SCRIPT.matcher(html);
        String seen = null;
        while (scripts.find()) {
            if (!scripts.group(1).toLowerCase(Locale.ROOT).contains("application/ld+json")) continue;
            Matcher m = availability.matcher(scripts.group(2));
            while (m.find()) {
                String found = parseAvailability(m.group(1));
                if ("UNKNOWN".equals(found)) continue;
                if (seen != null && !seen.equals(found)) return true;
                seen = found;
            }
        }
        return false;
    }

    private static int countProductNodes(String html) {
        Matcher scripts = LD_SCRIPT.matcher(html);
        int count = 0;
        while (scripts.find()) {
            if (!scripts.group(1).toLowerCase(Locale.ROOT).contains("application/ld+json")) continue;
            Matcher nodes = PRODUCT_TYPE.matcher(scripts.group(2));
            while (nodes.find()) {
                if (++count > 1) return count;
            }
        }
        return count;
    }

    private static boolean hasEnabledCartControl(String html) {
        Matcher btn = BUTTON.matcher(html);
        int found = 0;
        while (btn.find()) {
            if (inactive(btn.group(1))) continue;
            String label = btn.group(2).replaceAll("(?s)<[^>]*>", " ").replace("&nbsp;", " ");
            if (ACTIVE_CART_TEXT.matcher(label).find() && ++found > 1) return false;
        }
        Matcher input = INPUT.matcher(html);
        while (input.find()) {
            String tag = input.group(1);
            if (inactive(tag)) continue;
            Matcher value = ATTR_VALUE.matcher(tag);
            if (value.find()) {
                String label = value.group(1) != null ? value.group(1) : value.group(2) != null ? value.group(2) : value.group(3);
                if (ACTIVE_CART_TEXT.matcher(label).find() && ++found > 1) return false;
            }
        }
        return found == 1;
    }

    private static boolean inactive(String attrs) { return INACTIVE_ATTR.matcher(attrs).find(); }
}
