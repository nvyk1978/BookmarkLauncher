package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Product stock ONLY; never reads prices or images, and never changes site state.
 * A page-wide sold-out label, related product or hidden control is not proof of
 * the requested item's status. UNKNOWN is intentional for ambiguous variants.
 */
final class WishlistAvailabilityExtractor {
    private static final Pattern SCRIPT = Pattern.compile("(?is)<script\\b([^>]*)>(.*?)</script\\s*>");
    private static final Pattern MAIN = Pattern.compile("(?is)<main\\b[^>]*>(.*?)</main\\s*>");
    private static final Pattern FORM = Pattern.compile("(?is)<form\\b([^>]*)>(.*?)</form\\s*>");
    private static final Pattern BUTTON = Pattern.compile("(?is)<button\\b([^>]*)>(.*?)</button\\s*>");
    private static final Pattern INPUT = Pattern.compile("(?is)<input\\b([^>]*)>");
    private static final Pattern ATTR_VALUE = Pattern.compile("(?is)\\bvalue\\s*=\\s*(?:\\\"([^\\\"]*)\\\"|'([^']*)'|([^\\s>]+))");
    private static final Pattern CART_TEXT = Pattern.compile("(?i)(?:カートに入れる|買い物かごに入れる|カゴに入れる|購入する|注文する|add\\s+to\\s+(?:cart|bag))");
    private static final Pattern SOLD_TEXT = Pattern.compile("(?i)(?:売り切れ|売切れ|完売|在庫切れ|sold\\s*out|out\\s*of\\s*stock)");
    private static final Pattern INACTIVE = Pattern.compile("(?i)(?:\\sdisabled(?:\\s|=|$)|\\shidden(?:\\s|=|$)|aria-hidden\\s*=\\s*['\\\"]?true|aria-disabled\\s*=\\s*['\\\"]?true|display\\s*:\\s*none|visibility\\s*:\\s*hidden)");
    private static final Pattern CART_ACTION = Pattern.compile("(?i)(?:cart|basket|add_to_cart|add-item|additem|buy)");

    private WishlistAvailabilityExtractor() { }

    static Result parse(String html, URL page, String ignoredFirstProductAvailability, String metaAvailability) {
        if (html == null || page == null) return new Result("UNKNOWN", false, "ページ未取得");
        // An item URL or a uniquely URL-matched Product graph is required.
        boolean detail = isProductDetail(page);
        WishlistShopAvailabilityExtractor.Evidence shop =
                WishlistShopAvailabilityExtractor.inspect(html, page);
        if (shop != null && !"UNKNOWN".equals(shop.status))
            return new Result(shop.status, shop.explicit, shop.reason);
        ProductMatch match = matchProduct(html, page);
        if (!detail && !match.matchedByUrl) return new Result("UNKNOWN", false, "商品詳細ページと特定できず");

        if (match.product != null) {
            OfferState offer = new OfferState();
            readOffers(match.product.opt("offers"), offer, 0);
            if (offer.conflict) return new Result("UNKNOWN", false, "商品のバリエーションに異なる在庫状態");
            if (!"UNKNOWN".equals(offer.status)) {
                // Structured data must be for THIS item. Never inherit any
                // page-wide or related item's availability.
                if ("UNAVAILABLE".equals(offer.status) && hasProductCart(html, detail, match.matchedByUrl))
                    return new Result("UNKNOWN", false, "商品固有の在庫表示と購入ボタンが矛盾");
                return new Result(offer.status, true, "商品固有JSON-LD");
            }
        }

        // Site-wide meta is not reliable when multiple products appear.
        if (match.productCount == 1 && detail && match.product != null) {
            String meta = parseAvailability(metaAvailability);
            if (!"UNKNOWN".equals(meta)) {
                if ("UNAVAILABLE".equals(meta) && hasProductCart(html, true, match.matchedByUrl))
                    return new Result("UNKNOWN", false, "メタ情報と購入ボタンが矛盾");
                return new Result(meta, true, "商品ページの在庫メタ情報");
            }
        }

        // Enabled, item-specific purchase controls are positive evidence, but
        // never infer UNAVAILABLE from arbitrary sold-out words or disabled forms.
        if (hasProductCart(html, detail, match.matchedByUrl)
                && (match.productCount <= 1 || match.matchedByUrl))
            return new Result("AVAILABLE", false, "有効な商品購入フォーム");
        return new Result("UNKNOWN", false, shop != null ? shop.reason :
                (match.productCount > 1 && !match.matchedByUrl
                ? "関連商品と対象商品を区別できず" : "商品固有の在庫根拠不足"));
    }

    /** Optional note keyword identifies one heading block in a multi-item page.
     * Only a buyable, product-local cart form is positive evidence; no page-wide
     * or unrelated item's sold-out string may mark this item unavailable. */
    static Result parseNoteSection(WishlistNoteSection section) {
        if (section == null || section.after == null)
            return new Result("UNKNOWN", false, "備考欄の商品を特定できず");
        String scoped = section.after;
        // The heading detector already stops before the next product heading;
        // additionally cap the candidate to the immediate content below it.
        scoped = scoped.substring(0, Math.min(scoped.length(), 5000));
        Matcher forms = FORM.matcher(scoped);
        while (forms.find()) {
            String attrs = forms.group(1);
            String html = forms.group(2);
            if (INACTIVE.matcher(attrs).find() || SOLD_TEXT.matcher(html).find()) continue;
            if (CART_ACTION.matcher(attrs).find() && hasEnabledCartControl(html))
                return new Result("AVAILABLE", false, "備考欄の対象商品に紐づく購入フォーム");
        }
        return new Result("UNKNOWN", false, "備考欄の対象商品に購入可能なフォームが見つからず");
    }

    static final class Result {
        final String status;
        final boolean explicit;
        final String reason;
        Result(String status, boolean explicit, String reason) {
            this.status = status; this.explicit = explicit; this.reason = reason;
        }
    }

    static String parseAvailability(String raw) {
        if (raw == null) return "UNKNOWN";
        String s = raw.toLowerCase(Locale.ROOT).trim();
        if (s.endsWith("/instock") || s.endsWith("#instock") || s.equals("instock")
                || s.endsWith("/preorder") || s.endsWith("/presale")) return "AVAILABLE";
        if (s.endsWith("/outofstock") || s.endsWith("/soldout") || s.endsWith("/discontinued")
                || s.equals("outofstock") || s.equals("soldout") || s.equals("discontinued")) return "UNAVAILABLE";
        if (s.endsWith("/prelaunch") || s.equals("prelaunch")) return "COMING_SOON";
        return "UNKNOWN";
    }

    private static final class OfferState {
        String status = "UNKNOWN";
        boolean conflict;
        void add(String value) {
            String stock = parseAvailability(value);
            if ("UNKNOWN".equals(stock)) return;
            if (!"UNKNOWN".equals(status) && !status.equals(stock)) conflict = true;
            else status = stock;
        }
    }

    private static void readOffers(Object node, OfferState state, int depth) {
        if (node == null || depth > 8 || state.conflict) return;
        if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < Math.min(arr.length(), 50); i++) readOffers(arr.opt(i), state, depth + 1);
        } else if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            state.add(obj.optString("availability", null));
            readOffers(obj.opt("offers"), state, depth + 1);
            readOffers(obj.opt("hasVariant"), state, depth + 1);
        }
    }

    private static final class ProductMatch {
        JSONObject product;
        boolean matchedByUrl;
        int productCount;
        final List<JSONObject> products = new ArrayList<>();
    }

    private static ProductMatch matchProduct(String html, URL page) {
        ProductMatch match = new ProductMatch();
        Matcher scripts = SCRIPT.matcher(html);
        while (scripts.find()) {
            if (!scripts.group(1).toLowerCase(Locale.ROOT).contains("application/ld+json")) continue;
            try {
                String json = scripts.group(2).trim().replaceAll("(?s)^<!--|-->$", "");
                Object node = json.startsWith("[") ? new JSONArray(json) : new JSONObject(json);
                collectProducts(node, match.products, 0);
            } catch (Exception ignored) { /* A broken JSON-LD script cannot prove stock. */ }
        }
        match.productCount = match.products.size();
        JSONObject identified = null;
        int matches = 0;
        for (JSONObject product : match.products) {
            if (matchesPage(product, page)) { identified = product; matches++; }
        }
        if (matches == 1) { match.product = identified; match.matchedByUrl = true; }
        else if (matches == 0 && match.productCount == 1 && isProductDetail(page)) {
            // An explicitly DIFFERENT URL means this solitary Product node is
            // likely a recommendation, not the page's own item.
            JSONObject only = match.products.get(0);
            if (!only.has("url") && !only.has("@id") && !only.has("mainEntityOfPage"))
                match.product = only;
        }
        // Multiple matches might be distinct variants, not necessarily the requested item.
        return match;
    }

    private static void collectProducts(Object node, List<JSONObject> dest, int depth) {
        if (node == null || depth > 11 || dest.size() >= 60) return;
        if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < Math.min(arr.length(), 70); i++) collectProducts(arr.opt(i), dest, depth + 1);
        } else if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            if (isProductType(obj.opt("@type"))) dest.add(obj);
            String[] keys = {"@graph", "mainEntity", "itemListElement", "item", "about", "hasPart"};
            for (String k : keys) collectProducts(obj.opt(k), dest, depth + 1);
        }
    }

    private static boolean isProductType(Object types) {
        if (types instanceof JSONArray) {
            JSONArray arr = (JSONArray) types;
            for (int i = 0; i < arr.length(); i++) if (isProductType(arr.opt(i))) return true;
        }
        if (types instanceof String) {
            String s = ((String) types).toLowerCase(Locale.ROOT);
            return s.equals("product") || s.endsWith("/product") || s.endsWith(":product");
        }
        return false;
    }

    private static boolean matchesPage(JSONObject product, URL page) {
        return matchesUrl(product.opt("url"), page) || matchesUrl(product.opt("@id"), page)
                || matchesUrl(product.opt("mainEntityOfPage"), page);
    }
    private static boolean matchesUrl(Object node, URL page) {
        if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < Math.min(12, arr.length()); i++) if (matchesUrl(arr.opt(i), page)) return true;
        } else if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            return matchesUrl(obj.opt("@id"), page) || matchesUrl(obj.opt("url"), page);
        } else if (node instanceof String) {
            try {
                URL other = new URL(page, (String) node);
                if (!other.getHost().equalsIgnoreCase(page.getHost())) return false;
                String a = trimPath(other.getPath()), b = trimPath(page.getPath());
                if (a.equals("/") || !a.equals(b)) return false;
                if (a.endsWith("/index.php")) {
                    String idA = productId(other.getQuery()), idB = productId(page.getQuery());
                    return idA != null && idA.equals(idB);
                }
                return true;
            } catch (Exception ignored) { }
        }
        return false;
    }
    private static String trimPath(String path) {
        String p = path == null ? "/" : path.toLowerCase(Locale.ROOT);
        return p.replaceAll("/+$", "").isEmpty() ? "/" : p.replaceAll("/+$", "");
    }
    private static String productId(String query) {
        if (query == null) return null;
        Matcher matcher = Pattern.compile("(?i)(?:^|&)product_id=([0-9]+)(?:&|$)").matcher(query);
        return matcher.find() ? matcher.group(1) : null;
    }

    static boolean isProductDetail(URL url) {
        if (MarketplaceIdentity.from(url) != null) return true;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        String path = url.getPath().toLowerCase(Locale.ROOT);
        if (host.equals("amazon.co.jp") || host.endsWith(".amazon.co.jp") || host.equals("amazon.com") || host.endsWith(".amazon.com"))
            return path.matches("(?i).*/(?:dp|gp/product)/[a-z0-9]{10}(?:/.*)?");
        return WishlistCrawler.isSingleProductPage(url)
                || path.matches("(?i).*/(?:items|item|goods|detail)/[^/]+/?");
    }

    private static boolean hasProductCart(String html, boolean detail, boolean urlMatchedProduct) {
        // No matching product identification -> never infer from a listing.
        if (!detail && !urlMatchedProduct) return false;
        Matcher main = MAIN.matcher(html);
        String scope = main.find() ? main.group(1) : html;
        Matcher forms = FORM.matcher(scope);
        while (forms.find()) {
            // A form far down a large main section is often a recommendation.
            if (scope.length() > 10000 && forms.start() > scope.length() / 2) break;
            String attrs = forms.group(1), inside = forms.group(2);
            if (INACTIVE.matcher(attrs).find() || SOLD_TEXT.matcher(inside).find()) continue;
            if (!hasEnabledCartControl(inside)) continue;
            // Restrict unscoped fallback to actual add-to-cart forms; unrelated
            // product recommendations cannot prove the main item's stock.
            if (mainPatternAvailable(html) || CART_ACTION.matcher(attrs).find()
                    || urlMatchedProduct) return true;
        }
        // Some stores use JS-powered buttons with no containing form.
        // Only use them on identifiable product pages with one main area.
        return mainPatternAvailable(html) && hasEnabledCartControl(scope)
                && !SOLD_TEXT.matcher(scope.substring(0, Math.min(1200, scope.length()))).find();
    }
    private static boolean mainPatternAvailable(String html) { return MAIN.matcher(html).find(); }
    private static boolean hasEnabledCartControl(String html) {
        Matcher button = BUTTON.matcher(html);
        while (button.find()) {
            if (INACTIVE.matcher(button.group(1)).find()) continue;
            String label = button.group(2).replaceAll("(?s)<[^>]*>", " ").replace("&nbsp;", " ");
            if (CART_TEXT.matcher(label).find()) return true;
        }
        Matcher input = INPUT.matcher(html);
        while (input.find()) {
            String attrs = input.group(1);
            if (INACTIVE.matcher(attrs).find()) continue;
            Matcher value = ATTR_VALUE.matcher(attrs);
            if (value.find()) {
                String label = value.group(1) != null ? value.group(1) : value.group(2) != null ? value.group(2) : value.group(3);
                if (CART_TEXT.matcher(label).find()) return true;
            }
        }
        return false;
    }
}
