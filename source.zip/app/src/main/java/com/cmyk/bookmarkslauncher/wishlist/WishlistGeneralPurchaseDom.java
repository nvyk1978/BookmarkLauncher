package com.cmyk.bookmarkslauncher.wishlist;

/** Read-only renderer inspection for a single GENERAL item; never clicks. */
final class WishlistGeneralPurchaseDom {
    private WishlistGeneralPurchaseDom() { }
    static String javascript() {
        return "(function(){try{" +
          "var root=document.querySelector('main,[role=main],#main,#contents')||document.body;" +
          "if(!root)return 'UNKNOWN';" +
          "var h=root.querySelector('.product-detail h1,.product-detail h2,.item-detail h1,.item-detail h2,[itemprop=name],h1')||root.querySelector('h2');if(!h)return 'UNKNOWN';" +
          "var buy=/(?:カートに入れる|かごに入れる|カゴに入れる|買い物かごに入れる|バスケットに入れる|購入する|注文する|add\\s*to\\s*(?:cart|bag))/i;" +
          "var action=/(?:cart|basket|checkout\\.add|add.to.cart|add.cart|buy)/i;" +
          "var no=/(?:売り切れ|売切れ|完売|在庫切れ|sold\\s*out|out\\s*of\\s*stock)/i;" +
          "function vis(e){if(!e||e.disabled||e.getAttribute('aria-disabled')==='true'||!e.getClientRects().length)return false;" +
          "for(var n=e;n;n=n.parentElement){if(n.hidden||n.getAttribute('aria-hidden')==='true')return false;" +
          "var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0)return false;}return true;}" +
          "var product=h.closest('[itemtype*=Product],.product-detail,.product_detail,.item-detail,.item_detail,.product,.goods-detail,#product_detail,#productDetail,#goods_detail')||root;" +
          "if(product!==root&&!product.contains(h))return 'UNKNOWN';" +
          "var controls=product.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a[href],a[onclick],[role=button]');" +
          "var hits=[];for(var i=0;i<controls.length&&i<250;i++){var b=controls[i];if(!vis(b))continue;" +
          "if(b.closest('header,footer,nav,aside,[class*=related],[class*=recommend],[id*=related],[id*=recommend],[class*=ranking]'))continue;" +
          "var name=(b.innerText||b.textContent||'')+' '+(b.value||'')+' '+(b.getAttribute('alt')||'')+' '+(b.getAttribute('title')||'')+' '+(b.getAttribute('aria-label')||'');" +
          "var meta=(b.getAttribute('name')||'')+' '+(b.getAttribute('id')||'')+' '+(b.getAttribute('onclick')||'')+' '+(b.getAttribute('href')||'');" +
          "if(!buy.test(name)&&!(action.test(meta)&&/(?:add|buy|購入|注文)/i.test(meta)))continue;" +
          "var form=b.closest('form');if(form&&!vis(form))continue;" +
          "var area=form||b.closest('.purchase,.buybox,.product-form,.cart_area,.add-cart,.product-info,.item-detail')||b.parentElement;" +
          "if(!area||!product.contains(area))continue;" +
          "var sold=area.querySelectorAll('[class*=stock],[class*=sold],[class*=outofstock],[class*=out-of-stock],[id*=stock],[id*=sold]');" +
          "var conflict=false;for(var z=0;z<sold.length&&z<35;z++)if(vis(sold[z])&&no.test(sold[z].textContent||''))conflict=true;" +
          "if(conflict)continue;" +
          "var qty=area.querySelector('input[type=number],input[name*=quantity],input[name*=qty],select[name*=quantity],select[name*=qty]');" +
          "if(!qty){var near=b.parentElement;for(var k=0;k<4&&near&&product.contains(near);k++,near=near.parentElement){qty=near.querySelector('input[type=number],input[name*=quantity],input[name*=qty]');if(qty)break;}}" +
          "if(!qty){var all=product.querySelectorAll('input[type=number],input[name*=quantity],input[name*=qty]');if(all.length===1)qty=all[0];}" +
          "if(!qty&&!form)continue;" +
          "var variants=area.querySelectorAll('select[required]');var unresolved=false;for(var v=0;v<variants.length;v++){if(vis(variants[v])&&(!variants[v].value||variants[v].selectedIndex<0)){unresolved=true;break;}}if(unresolved)continue;" +
          "if(qty&&(!vis(qty)||qty.disabled))continue;" +
          "hits.push(b);}" +
          "return hits.length===1?'AVAILABLE':'UNKNOWN';" +
          "}catch(e){return 'UNKNOWN';}})()";
    }
}
