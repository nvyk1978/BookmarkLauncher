package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/** Read-only ZOZO title recovery; separate from variant stock decisions. */
public final class WishlistZozoProductTitleDom {
    private WishlistZozoProductTitleDom() { }

    public static boolean supports(URL u) {
        return u != null && "https".equalsIgnoreCase(u.getProtocol())
                && WishlistCrawler.isAllowedUrl(u)
                && WishlistRetailDedicatedMode.forUrl(u) == WishlistRetailDedicatedMode.ZOZO
                && WishlistRetailDedicatedMode.zozoGoodsId(u) != null;
    }

    public static String javascript(URL u) {
        if (!supports(u)) return "JSON.stringify({title:'',reason:'unsupported'})";
        return SCRIPT.replace("__ITEM__", JSONObject.quote(WishlistRetailDedicatedMode.zozoGoodsId(u)))
                .replace("__DID__", JSONObject.quote(WishlistRetailDedicatedMode.query(u,"did")))
                .replace("__SHOP__", JSONObject.quote(WishlistRetailDedicatedMode.zozoShopId(u)==null
                        ? "" : WishlistRetailDedicatedMode.zozoShopId(u)));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const r={title:'',reason:'unverified'},done=()=>JSON.stringify(r);
 try{
  const goods=__ITEM__,did=__DID__,shop=__SHOP__;
  const host=h=>h==='zozo.jp'||h==='www.zozo.jp';
  const path=p=>String(p||'').toLowerCase().replace(/\\/+$/,'').match(
     /^\\/(?:sp\\/)?(?:shop\\/([a-z0-9_-]+)\\/)?goods(?:-sale)?\\/([0-9]{5,15})$/);
  const actual=path(location.pathname);
  if(location.protocol!=='https:'||!host(location.hostname.toLowerCase())||
      !actual||actual[2]!==goods||(shop&&actual[1]&&actual[1]!==shop)){
    r.reason='product-url-mismatch';return done();}
  if(did&&new URLSearchParams(location.search).get('did')!==did){
    r.reason='variant-url-mismatch';return done();}
  const canonical=document.querySelector('link[rel=canonical]');
  let canon=false;
  if(canonical&&canonical.href){
    let u;try{u=new URL(canonical.href,location.href);}catch(_){r.reason='canonical-invalid';return done();}
    const c=path(u.pathname);
    if(!host(u.hostname.toLowerCase())||!c||c[2]!==goods||
       (shop&&c[1]&&c[1]!==shop)) {r.reason='canonical-different-product';return done();}
    canon=true;
  }
  const main=document.querySelector('main,[role=main],#main,#contents,#content')||document.body;
  if(!main){r.reason='body-pending';return done();}
  const norm=s=>String(s||'').replace(/\\u00a0|　/g,' ').replace(/\\s+/g,' ').trim();
  const exclude='header,nav,footer,aside,[class*=recommend],[class*=related],'+
       '[class*=ranking],[class*=pickup],[class*=breadcrumb]';
  const visible=e=>{if(!e||e.closest(exclude))return false;
    for(let p=e;p;p=p.parentElement){if(p.hidden||p.hasAttribute('inert')||
      p.getAttribute('aria-hidden')==='true')return false;
      const s=getComputedStyle(p);
      if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||Number(s.opacity)===0)return false;
    }return true;};
  const heads=[...main.querySelectorAll('h1')].filter(visible)
    .map(e=>norm(e.innerText||e.textContent)).filter(Boolean);
  const unique=[...new Set(heads)];
  if(unique.length!==1||unique[0].length<3||unique[0].length>240||
     /^(?:ZOZOTOWN|商品詳細|商品一覧|検索結果|カート|お探しのページ)$/i.test(unique[0])){
      r.reason='zozo-product-heading-missing';return done();}
  const text=norm(main.innerText||main.textContent).slice(0,110000);
  const inquiry=[...text.matchAll(/問い合わせ番号\\s*[:：]?\\s*([0-9]{5,15})\\s*[（(]ZOZO[）)]/g)];
  const inquiryBound=inquiry.some(m=>Number(m[1])===Number(goods)||
      Number(m[1])===Number(goods)+1000000);
  const itemAttr=[...main.querySelectorAll('[data-goods-id],[data-product-id],[itemprop=sku]')]
    .filter(e=>!e.closest(exclude)).some(e=>['data-goods-id','data-product-id','content']
      .some(k=>e.getAttribute(k)===goods));
  // Page pathname alone is not enough: require matching canonical or on-page
  // ZOZO inquiry ID. Never borrow related-products' names or shop headings.
  if(!(canon||inquiryBound||itemAttr)){
    r.reason='zozo-product-id-unverified';return done();}
  r.title=unique[0];r.reason='verified-rendered-heading';return done();
 }catch(_){r.reason='script-error';return done();}
})()
""";
}
