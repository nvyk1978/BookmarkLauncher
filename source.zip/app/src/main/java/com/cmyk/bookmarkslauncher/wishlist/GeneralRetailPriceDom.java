package com.cmyk.bookmarkslauncher.wishlist;

/** Noninteractive, SKU-bound gross-price reader for ASKUL and MonotaRO only. */
final class GeneralRetailPriceDom {
    private GeneralRetailPriceDom() { }

    static String javascript(String host, String sku) {
        if (sku == null || !sku.matches("[A-Za-z0-9_-]{5,20}"))
            return "JSON.stringify({value:'',currency:'',reason:'invalid-sku'})";
        boolean askul = host.equals("askul.co.jp") || host.equals("www.askul.co.jp");
        String item = sku.replace("'", "");
        return "(function(){try{" +
                "var sku='" + item + "',askul=" + askul + ";" +
                "function empty(r){return JSON.stringify({value:'',currency:'',reason:r});}" +
                "var path=(location.pathname||'').replace(/\\/+$/,'').toLowerCase();" +
                "var expected=askul?'/p/'+sku.toLowerCase():'/p/'+sku.slice(0,4)+'/'+sku.slice(4);" +
                "if(path!==expected)return empty('url-mismatch');" +
                "var main=document.querySelector('main,[role=main],#main,#contents,#productDetail,#product-detail')||document.body;" +
                "var title=main.querySelector('h1')||document.querySelector('h1');" +
                "if(!title||!title.textContent.trim())return empty('title-missing');" +
                "var text=(main.innerText||main.textContent||'').replace(/\\u00a0/g,' ');" +
                "var skuAt=text.toUpperCase().indexOf(sku.toUpperCase());" +
                // Some retailers render SKU outside their <main>, in a sibling
                // product detail section. Fall back to the document's visible
                // text, never to untrusted unrelated JSON-LD recommendations.
                "if(skuAt<0&&main!==document.body){text=(document.body.innerText||document.body.textContent||'').replace(/\\u00a0/g,' ');skuAt=text.toUpperCase().indexOf(sku.toUpperCase());}" +
                "if(skuAt<0)return empty('sku-not-visible');" +
                "var near=text.slice(Math.max(0,skuAt-125),Math.min(text.length,skuAt+sku.length+125));" +
                "if(near.indexOf(askul?'お申込番号':'注文コード')<0)return empty('sku-marker-missing');" +
                "var t=title.innerText||title.textContent||'';" +
                "var start=text.indexOf(t.trim());" +
                "if(start<0||skuAt<start||skuAt-start>6500)return empty('product-section-missing');" +
                "var scoped=text.slice(start,Math.min(text.length,Math.max(skuAt+550,start+2800)));" +
                "var cut=scoped.search(/(?:関連商品|おすすめ商品|この商品を見た|新着商品|配送オプション|配送料|商品レビュー|ご利用案内)/);" +
                "if(cut>=0)scoped=scoped.slice(0,cut);" +
                // ASKU's visible product panel: ¥103（税込）, while shipping
                // separately displays ¥385（税込）. MonotaRO: 販売価格(税込)￥252
                // next to 販売価格(税別)￥229. Require a tax-INCLUSIVE label.
                "var re=askul?/[￥¥]\\s*([0-9][0-9,]*)\\s*(?:円\\s*)?[（(]\\s*税込\\s*[）)]|(?:税込価格|販売価格[（(]税込[）)])\\s*[:：]?\\s*[￥¥]\\s*([0-9][0-9,]*)/:" +
                "/(?:販売価格|販売価額)\\s*[（(]\\s*税込\\s*[）)]\\s*[:：]?\\s*[￥¥]\\s*([0-9][0-9,]*)/;" +
                "var match=scoped.match(re);if(!match)return empty('gross-label-missing');" +
                "var raw=(match[1]||match[2]||'').replace(/,/g,'');var n=Number(raw);" +
                "if(!Number.isSafeInteger(n)||n<1||n>100000000)return empty('gross-invalid');" +
                "return JSON.stringify({value:'¥'+raw,currency:'JPY',reason:'verified-gross'});" +
                "}catch(e){return JSON.stringify({value:'',currency:'',reason:'script-error'});}})()";
    }
}
