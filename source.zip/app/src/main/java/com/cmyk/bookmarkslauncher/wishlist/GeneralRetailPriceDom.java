package com.cmyk.bookmarkslauncher.wishlist;

/** Strictly read-only gross-price DOM probe for an exact ASKUL/MonotaRO SKU. */
final class GeneralRetailPriceDom {
    private GeneralRetailPriceDom() { }

    static String javascript(String host, String sku) {
        if (sku == null || !sku.matches("[A-Za-z0-9_-]{5,20}"))
            return "JSON.stringify({value:'',currency:''})";
        boolean askul = host.equals("askul.co.jp") || host.equals("www.askul.co.jp");
        String item = sku.replace("'", "");
        return "(function(){try{" +
                "var sku='" + item + "',askul=" + askul + ";" +
                "var path=(location.pathname||'').replace(/\\/+$/,'').toLowerCase();" +
                "var expected=askul?'/p/'+sku.toLowerCase():'/p/'+sku.slice(0,4)+'/'+sku.slice(4);" +
                "if(path!==expected)return JSON.stringify({value:'',currency:''});" +
                "var main=document.querySelector('main,[role=main],#main,#contents,#productDetail,#product-detail')||document.body;" +
                "var title=main.querySelector('h1');if(!title||!title.textContent.trim())return JSON.stringify({value:'',currency:''});" +
                "var text=(main.innerText||main.textContent||'').replace(/\\u00a0/g,' ');" +
                "var skuAt=text.toUpperCase().indexOf(sku.toUpperCase());" +
                "if(skuAt<0)return JSON.stringify({value:'',currency:''});" +
                "var near=text.slice(Math.max(0,skuAt-110),Math.min(text.length,skuAt+sku.length+110));" +
                "if(near.indexOf(askul?'お申込番号':'注文コード')<0)return JSON.stringify({value:'',currency:''});" +
                "var start=text.indexOf(title.innerText.trim());if(start<0)start=0;" +
                "var scoped=text.slice(start,Math.min(text.length,Math.max(skuAt+250,start+2600)));" +
                "var cut=scoped.search(/(?:関連商品|おすすめ商品|この商品を見た|新着商品)/);if(cut>=0)scoped=scoped.slice(0,cut);" +
                "var re=askul?/[￥¥]\\s*([0-9][0-9,]*)\\s*[（(]\\s*税込\\s*[）)]/:" +
                "/(?:販売価格|販売価額)\\s*[（(]\\s*税込\\s*[）)]\\s*[￥¥]\\s*([0-9][0-9,]*)/;" +
                "var match=scoped.match(re);if(!match)return JSON.stringify({value:'',currency:''});" +
                "var raw=match[1].replace(/,/g,'');var n=Number(raw);" +
                "if(!Number.isSafeInteger(n)||n<1||n>100000000)return JSON.stringify({value:'',currency:''});" +
                "return JSON.stringify({value:'¥'+raw,currency:'JPY'});" +
                "}catch(e){return JSON.stringify({value:'',currency:''});}})()";
    }
}
