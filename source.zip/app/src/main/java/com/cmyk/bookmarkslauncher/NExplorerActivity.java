package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;
import com.cmyk.bookmarkslauncher.ui.NDialog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * N Standard's N Explorer UI, adapted to BookmarkLauncher's logical Home/folder tree.
 * No device/app files are exposed here: Home is the fixed root and only folder nodes are listed.
 */
public final class NExplorerActivity extends Activity {
    public static final String EXTRA_START_FOLDER_ID = "com.cmyk.bookmarkslauncher.extra.START_FOLDER_ID";
    public static final String RESULT_FOLDER_ID = "com.cmyk.bookmarkslauncher.result.FOLDER_ID";

    private static final int DARK = Color.rgb(37, 32, 32);        // #252020
    private static final int GRAY = Color.rgb(69, 64, 64);        // #454040
    private static final int LGRAY = Color.rgb(101, 96, 96);      // #656060
    private static final int LBLUE = Color.rgb(68, 85, 119);      // #445577
    private static final int WHITE_UI = Color.rgb(169, 169, 153); // #A9A999
    private static final int TEXT = Color.WHITE;

    private BookmarkRepository repo;
    private String currentFolderId;
    private TextView pathView;
    private LinearLayout folderList;
    private GripScrollHost scrollHost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        repo = new BookmarkRepository(this);
        String requested = getIntent() == null ? null : getIntent().getStringExtra(EXTRA_START_FOLDER_ID);
        BookmarkNode start = requested == null ? null : repo.get(requested);
        currentFolderId = start != null && start.deletedAt == null && start.isFolder() ? start.id : null;
        buildUi();
        refresh();
    }

    private void configureWindow() {
        Window w = getWindow();
        if (w == null) return;
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.dimAmount = 0.58f;
        w.setAttributes(lp);
        w.setGravity(Gravity.CENTER);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus) return;
        Window w = getWindow();
        if (w == null) return;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        w.setLayout(Math.min(screenWidth - dp(20), Math.round(screenWidth * 0.92f)), WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(8));
        // Current N Standard rule: explorer main surface is N Gray.
        root.setBackground(roundRect(GRAY, 12));

        TextView title = text("エクスプローラ", 20, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(4), dp(3), dp(4), dp(10));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView storageView = text("ホーム", 16, TEXT);
        storageView.setGravity(Gravity.CENTER_VERTICAL);
        storageView.setPadding(dp(12), 0, dp(12), 0);
        // Current N Standard rule: storage selector is N Dark Gray. BookmarkLauncher has one fixed root.
        storageView.setBackground(roundRect(DARK, 10));
        root.addView(storageView, new LinearLayout.LayoutParams(-1, dp(42)));

        pathView = text("", 12, WHITE_UI);
        pathView.setSingleLine(true);
        pathView.setEllipsize(TextUtils.TruncateAt.START);
        pathView.setPadding(dp(4), dp(7), dp(4), dp(7));
        root.addView(pathView, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        TextView parentButton = managerButton("‹  戻る");
        TextView newFolderButton = managerButton("＋  新規フォルダ");
        nav.addView(parentButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        nav.addView(newFolderButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        root.addView(nav);

        folderList = new LinearLayout(this);
        folderList.setOrientation(LinearLayout.VERTICAL);
        scrollHost = new GripScrollHost(this, folderList);
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int listHeight = Math.min(dp(440), Math.max(dp(250), screenHeight - dp(300)));
        root.addView(scrollHost, new LinearLayout.LayoutParams(-1, listHeight));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        TextView cancel = actionText("キャンセル");
        TextView confirm = actionText("このフォルダを選択");
        actions.addView(cancel, new LinearLayout.LayoutParams(0, dp(48), 0.32f));
        actions.addView(confirm, new LinearLayout.LayoutParams(0, dp(48), 0.68f));
        root.addView(actions, new LinearLayout.LayoutParams(-1, dp(52)));

        parentButton.setOnClickListener(v -> goParent());
        newFolderButton.setOnClickListener(v -> showCreateFolder());
        cancel.setOnClickListener(v -> finish());
        confirm.setOnClickListener(v -> {
            Intent result = new Intent();
            if (currentFolderId != null) result.putExtra(RESULT_FOLDER_ID, currentFolderId);
            setResult(RESULT_OK, result);
            finish();
        });

        setContentView(root);
    }

    private void refresh() {
        pathView.setText(buildPath());
        folderList.removeAllViews();
        List<BookmarkNode> folders = folders(currentFolderId);
        if (folders.isEmpty()) {
            TextView empty = text("フォルダはありません", 14, WHITE_UI);
            empty.setPadding(dp(12), dp(22), dp(12), dp(22));
            folderList.addView(empty);
        } else {
            for (BookmarkNode folder : folders) addFolderRow(folder);
        }
        scrollHost.post(() -> {
            scrollHost.scroll.scrollTo(0, 0);
            scrollHost.updateThumb();
        });
    }

    private List<BookmarkNode> folders(String parentId) {
        ArrayList<BookmarkNode> out = new ArrayList<>();
        for (BookmarkNode node : repo.children(parentId)) if (node.isFolder()) out.add(node);
        Collections.sort(out, (a, b) -> a.displayName().compareToIgnoreCase(b.displayName()));
        return out;
    }

    private void addFolderRow(BookmarkNode folder) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        row.setBackgroundColor(DARK);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_n_folder);
        icon.setPadding(dp(6), dp(6), dp(6), dp(6));
        icon.setBackground(roundRect(LBLUE, 9));
        row.addView(icon, new LinearLayout.LayoutParams(dp(32), dp(32)));

        TextView name = text(folder.displayName(), 14, TEXT);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setPadding(dp(10), 0, 0, 0);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(38), 1f));

        row.setOnClickListener(v -> {
            BookmarkNode fresh = repo.get(folder.id);
            if (fresh == null || fresh.deletedAt != null || !fresh.isFolder()) return;
            currentFolderId = fresh.id;
            refresh();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
        lp.bottomMargin = dp(1);
        folderList.addView(row, lp);
    }

    private void goParent() {
        if (currentFolderId == null) return;
        BookmarkNode current = repo.get(currentFolderId);
        currentFolderId = current == null ? null : current.parentId;
        refresh();
    }

    private String buildPath() {
        if (currentFolderId == null) return "ホーム";
        ArrayList<String> parts = new ArrayList<>();
        String cursor = currentFolderId;
        int guard = 0;
        while (cursor != null && guard++ < 128) {
            BookmarkNode node = repo.get(cursor);
            if (node == null || node.deletedAt != null || !node.isFolder()) break;
            parts.add(node.displayName());
            cursor = node.parentId;
        }
        Collections.reverse(parts);
        StringBuilder path = new StringBuilder("ホーム");
        for (String part : parts) path.append(" / ").append(part);
        return path.toString();
    }

    private void showCreateFolder() {
        NDialog.showInput(this, "新規フォルダ", "フォルダ名", "", false, "作成", text -> {
            if (text == null || text.isBlank()) return;
            repo.createFolder(currentFolderId, text);
            refresh();
        });
    }

    private TextView text(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private TextView managerButton(String value) {
        TextView view = text(value, 14, TEXT);
        view.setGravity(Gravity.CENTER);
        return view;
    }

    private TextView actionText(String value) {
        TextView view = text(value, 14, TEXT);
        view.setGravity(Gravity.CENTER);
        view.setSingleLine(true);
        view.setPadding(dp(4), 0, dp(4), 0);
        return view;
    }

    private GradientDrawable roundRect(int color, float radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    /** N Standard / PriceRec rule: thin visible thumb + 30dp direct-grab hit area. */
    private final class GripScrollHost extends FrameLayout {
        final TrackingScrollView scroll;
        final View thumb;
        final View hit;
        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable fade;
        int thumbHeight;
        boolean dragging;

        GripScrollHost(Context context, View child) {
            super(context);
            scroll = new TrackingScrollView(context);
            scroll.setVerticalScrollBarEnabled(false);
            scroll.addView(child, new ScrollView.LayoutParams(-1, -2));
            addView(scroll, new FrameLayout.LayoutParams(-1, -1));

            thumb = new View(context);
            fade = () -> thumb.animate().alpha(0f).setDuration(260).start();
            thumb.setBackground(roundRect(WHITE_UI, 2));
            FrameLayout.LayoutParams thumbParams = new FrameLayout.LayoutParams(dp(4), dp(40), Gravity.END | Gravity.TOP);
            thumbParams.rightMargin = dp(2);
            addView(thumb, thumbParams);

            hit = new View(context);
            FrameLayout.LayoutParams hitParams = new FrameLayout.LayoutParams(dp(30), -1, Gravity.END);
            addView(hit, hitParams);
            hit.setOnTouchListener((v, event) -> handleGrip(event));
            post(this::updateThumb);
        }

        void showThumb() {
            handler.removeCallbacks(fade);
            thumb.animate().cancel();
            thumb.setAlpha(1f);
            if (!dragging) handler.postDelayed(fade, 900);
        }

        void updateThumb() {
            if (scroll.getChildCount() == 0 || getHeight() <= 0) return;
            int content = scroll.getChildAt(0).getHeight();
            int viewport = scroll.getHeight();
            int range = Math.max(0, content - viewport);
            if (range <= 0) {
                thumb.setVisibility(View.GONE);
                return;
            }
            thumb.setVisibility(View.VISIBLE);
            thumbHeight = Math.max(dp(36), Math.round(viewport * (viewport / (float) Math.max(viewport, content))));
            thumbHeight = Math.min(viewport, thumbHeight);
            int track = Math.max(1, viewport - thumbHeight);
            float ratio = scroll.getScrollY() / (float) Math.max(1, range);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) thumb.getLayoutParams();
            lp.height = thumbHeight;
            lp.topMargin = Math.round(track * ratio);
            lp.gravity = Gravity.END | Gravity.TOP;
            lp.rightMargin = dp(2);
            thumb.setLayoutParams(lp);
        }

        boolean handleGrip(MotionEvent event) {
            if (thumb.getVisibility() != View.VISIBLE) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = true;
                    showThumb();
                    moveTo(event.getY());
                    return true;
                case MotionEvent.ACTION_MOVE:
                    moveTo(event.getY());
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    showThumb();
                    return true;
                default:
                    return false;
            }
        }

        void moveTo(float y) {
            if (scroll.getChildCount() == 0) return;
            int content = scroll.getChildAt(0).getHeight();
            int viewport = scroll.getHeight();
            int range = Math.max(0, content - viewport);
            int track = Math.max(1, viewport - thumbHeight);
            float ratio = Math.max(0f, Math.min(1f, (y - thumbHeight / 2f) / track));
            scroll.scrollTo(0, Math.round(range * ratio));
            updateThumb();
        }

        final class TrackingScrollView extends ScrollView {
            TrackingScrollView(Context context) { super(context); }

            @Override
            protected void onScrollChanged(int l, int t, int oldl, int oldt) {
                super.onScrollChanged(l, t, oldl, oldt);
                updateThumb();
                showThumb();
            }

            @Override
            protected void onSizeChanged(int w, int h, int oldw, int oldh) {
                super.onSizeChanged(w, h, oldw, oldh);
                post(GripScrollHost.this::updateThumb);
            }
        }
    }
}
