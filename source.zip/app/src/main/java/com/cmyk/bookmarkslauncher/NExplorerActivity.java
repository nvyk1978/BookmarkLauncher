package com.cmyk.bookmarkslauncher;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;
import com.cmyk.bookmarkslauncher.ui.NDialog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * N Explorer.
 * Default mode selects a BookmarkLauncher folder. Image-pick mode browses MediaStore images
 * with the same N Explorer surface and returns the selected image Uri.
 */
public final class NExplorerActivity extends Activity {
    public static final String EXTRA_START_FOLDER_ID = "com.cmyk.bookmarkslauncher.extra.START_FOLDER_ID";
    public static final String RESULT_FOLDER_ID = "com.cmyk.bookmarkslauncher.result.FOLDER_ID";

    public static final String EXTRA_MODE = "com.cmyk.bookmarkslauncher.extra.NEXPLORER_MODE";
    public static final int MODE_BOOKMARK_FOLDER = 0;
    public static final int MODE_IMAGE_PICK = 1;
    public static final String RESULT_FILE_URI = "com.cmyk.bookmarkslauncher.result.FILE_URI";
    public static final String RESULT_FILE_NAME = "com.cmyk.bookmarkslauncher.result.FILE_NAME";

    private static final int REQ_IMAGE_PERMISSION = 8401;
    private static final int IMAGE_PAGE_SIZE = 150;

    private static final int DARK = Color.rgb(37, 32, 32);        // #252020
    private static final int GRAY = Color.rgb(69, 64, 64);        // #454040
    private static final int LGRAY = Color.rgb(101, 96, 96);      // #656060
    private static final int LBLUE = Color.rgb(68, 85, 119);      // #445577
    private static final int WHITE_UI = Color.rgb(169, 169, 153); // #A9A999
    private static final int GREEN = Color.rgb(34, 119, 51);      // #227733
    private static final int TEXT = Color.WHITE;

    private BookmarkRepository repo;
    private boolean imagePickMode;
    private String currentFolderId;
    private TextView storageView;
    private TextView pathView;
    private LinearLayout folderList;
    private GripScrollHost scrollHost;
    private TextView secondaryButton;
    private TextView confirmButton;

    private final List<String> mediaVolumes = new ArrayList<>();
    private String currentVolume = MediaStore.VOLUME_EXTERNAL_PRIMARY;
    private String currentMediaPath = "";
    private ImageEntry selectedImage;
    private View selectedImageRow;
    private TextView selectedImageCheck;

    // MediaStore can contain many thousands of rows. Never enumerate it on the UI thread.
    private final ExecutorService mediaExecutor = Executors.newSingleThreadExecutor();
    private final Map<String, MediaIndex> mediaIndexes = new HashMap<>();
    private int mediaLoadGeneration;
    private int visibleImageLimit = IMAGE_PAGE_SIZE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        imagePickMode = getIntent() != null && getIntent().getIntExtra(EXTRA_MODE, MODE_BOOKMARK_FOLDER) == MODE_IMAGE_PICK;
        if (imagePickMode) {
            initMediaVolumes();
        } else {
            repo = new BookmarkRepository(this);
            String requested = getIntent() == null ? null : getIntent().getStringExtra(EXTRA_START_FOLDER_ID);
            BookmarkNode start = requested == null ? null : repo.get(requested);
            currentFolderId = start != null && start.deletedAt == null && start.isFolder() ? start.id : null;
        }
        buildUi();
        if (imagePickMode) ensureImagePermission();
        else refreshBookmarkFolders();
    }

    private void configureWindow() {
        Window w = getWindow();
        if (w == null) return;
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.dimAmount = 0.58f;
        w.setAttributes(lp);
        w.setGravity(Gravity.CENTER);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus) return;
        Window w = getWindow();
        if (w == null) return;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        w.setLayout(Math.max(dp(120), screenWidth - dp(30)), WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(8));
        root.setBackground(roundRect(GRAY, 12));

        TextView title = text("エクスプローラ", 20, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(4), dp(3), dp(4), dp(10));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        storageView = text(imagePickMode ? storageLabel(currentVolume) : "ホーム", 16, TEXT);
        storageView.setGravity(Gravity.CENTER_VERTICAL);
        storageView.setPadding(dp(12), 0, dp(12), 0);
        storageView.setBackground(roundRect(DARK, 10));
        root.addView(storageView, new LinearLayout.LayoutParams(-1, dp(42)));

        pathView = text("", 12, WHITE_UI);
        pathView.setSingleLine(true);
        pathView.setEllipsize(TextUtils.TruncateAt.START);
        pathView.setPadding(dp(4), dp(7), dp(4), dp(7));
        root.addView(pathView, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        TextView parentButton = NDiagnosticLog.makeDialogAction(this, "戻る");
        secondaryButton = NDiagnosticLog.makeDialogAction(this, imagePickMode ? "ストレージ切替" : "＋新規フォルダ");
        parentButton.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        secondaryButton.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        nav.addView(parentButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        nav.addView(secondaryButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(48)));

        folderList = new LinearLayout(this);
        folderList.setOrientation(LinearLayout.VERTICAL);
        scrollHost = new GripScrollHost(this, folderList);
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int listHeight = Math.min(dp(440), Math.max(dp(250), screenHeight - dp(300)));
        root.addView(scrollHost, new LinearLayout.LayoutParams(-1, listHeight));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        TextView cancel = NDiagnosticLog.makeDialogAction(this, "キャンセル");
        confirmButton = NDiagnosticLog.makeDialogAction(this, imagePickMode ? "この画像を選択" : "このフォルダを選択");
        cancel.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        confirmButton.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(confirmButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(actions, new LinearLayout.LayoutParams(-1, dp(52)));

        parentButton.setOnClickListener(v -> goParent());
        secondaryButton.setOnClickListener(v -> {
            if (imagePickMode) cycleStorage();
            else showCreateFolder();
        });
        storageView.setOnClickListener(v -> {
            if (imagePickMode) cycleStorage();
        });
        cancel.setOnClickListener(v -> finish());
        confirmButton.setOnClickListener(v -> confirmSelection());
        if (imagePickMode) setImageConfirmEnabled(false);

        setContentView(root);
    }

    private void confirmSelection() {
        if (imagePickMode) {
            if (selectedImage == null || selectedImage.uri == null) return;
            Intent result = new Intent();
            result.putExtra(RESULT_FILE_URI, selectedImage.uri.toString());
            result.putExtra(RESULT_FILE_NAME, selectedImage.name);
            setResult(RESULT_OK, result);
            finish();
            return;
        }
        Intent result = new Intent();
        if (currentFolderId != null) result.putExtra(RESULT_FOLDER_ID, currentFolderId);
        setResult(RESULT_OK, result);
        finish();
    }

    private void goParent() {
        if (imagePickMode) {
            if (currentMediaPath.isEmpty()) return;
            String path = trimTrailingSlash(currentMediaPath);
            int slash = path.lastIndexOf('/');
            currentMediaPath = slash < 0 ? "" : path.substring(0, slash + 1);
            visibleImageLimit = IMAGE_PAGE_SIZE;
            clearImageSelection();
            refreshImages();
            return;
        }
        if (currentFolderId == null) return;
        BookmarkNode current = repo.get(currentFolderId);
        currentFolderId = current == null ? null : current.parentId;
        refreshBookmarkFolders();
    }

    private void refreshBookmarkFolders() {
        pathView.setText(buildBookmarkPath());
        folderList.removeAllViews();
        List<BookmarkNode> folders = bookmarkFolders(currentFolderId);
        if (folders.isEmpty()) {
            TextView empty = text("フォルダはありません", 14, WHITE_UI);
            empty.setPadding(dp(12), dp(22), dp(12), dp(22));
            folderList.addView(empty);
        } else {
            for (BookmarkNode folder : folders) addBookmarkFolderRow(folder);
        }
        resetScroll();
    }

    private List<BookmarkNode> bookmarkFolders(String parentId) {
        ArrayList<BookmarkNode> out = new ArrayList<>();
        for (BookmarkNode node : repo.children(parentId)) if (node.isFolder()) out.add(node);
        Collections.sort(out, (a, b) -> a.displayName().compareToIgnoreCase(b.displayName()));
        return out;
    }

    private void addBookmarkFolderRow(BookmarkNode folder) {
        LinearLayout row = baseRow();
        row.addView(folderIcon(), new LinearLayout.LayoutParams(dp(32), dp(32)));
        TextView name = text(folder.displayName(), 14, TEXT);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setPadding(dp(10), 0, 0, 0);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(38), 1f));
        row.setOnClickListener(v -> {
            BookmarkNode fresh = repo.get(folder.id);
            if (fresh == null || fresh.deletedAt != null || !fresh.isFolder()) return;
            currentFolderId = fresh.id;
            refreshBookmarkFolders();
        });
        addListRow(row);
    }

    private String buildBookmarkPath() {
        if (currentFolderId == null) return "ホーム";
        ArrayList<String> parts = new ArrayList<>();
        String cursor = currentFolderId;
        int guard = 0;
        while (cursor != null && guard++ < 128) {
            BookmarkNode node = repo.get(cursor);
            if (node == null || node.deletedAt != null || !node.isFolder()) break;
            parts.add(node.displayName());
            cursor = node.parentId;
        }
        Collections.reverse(parts);
        StringBuilder path = new StringBuilder("ホーム");
        for (String part : parts) path.append(" / ").append(part);
        return path.toString();
    }

    private void showCreateFolder() {
        NDialog.showInput(this, "新規フォルダ", "フォルダ名", "", false, "作成", value -> {
            if (value == null || value.isBlank()) return;
            repo.createFolder(currentFolderId, value);
            refreshBookmarkFolders();
        });
    }

    private void initMediaVolumes() {
        Set<String> available = new LinkedHashSet<>();
        try {
            available.addAll(MediaStore.getExternalVolumeNames(this));
        } catch (Throwable ignored) {
        }
        if (available.isEmpty()) available.add(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        mediaVolumes.addAll(available);
        mediaVolumes.sort((a, b) -> {
            if (MediaStore.VOLUME_EXTERNAL_PRIMARY.equals(a)) return -1;
            if (MediaStore.VOLUME_EXTERNAL_PRIMARY.equals(b)) return 1;
            return a.compareToIgnoreCase(b);
        });
        currentVolume = mediaVolumes.get(0);
    }

    private String storageLabel(String volume) {
        if (MediaStore.VOLUME_EXTERNAL_PRIMARY.equals(volume)) return "内部ストレージ";
        return "外部ストレージ";
    }

    private void cycleStorage() {
        if (!imagePickMode || mediaVolumes.size() <= 1) return;
        int index = mediaVolumes.indexOf(currentVolume);
        currentVolume = mediaVolumes.get((index + 1) % mediaVolumes.size());
        currentMediaPath = "";
        visibleImageLimit = IMAGE_PAGE_SIZE;
        clearImageSelection();
        storageView.setText(storageLabel(currentVolume));
        refreshImages();
    }

    private boolean hasImagePermission() {
        if (Build.VERSION.SDK_INT >= 34) {
            return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensureImagePermission() {
        if (hasImagePermission()) {
            refreshImages();
            return;
        }
        if (Build.VERSION.SDK_INT >= 34) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}, REQ_IMAGE_PERMISSION);
        } else if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_IMAGE_PERMISSION);
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_IMAGE_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_IMAGE_PERMISSION) return;
        if (hasImagePermission()) refreshImages();
        else showPermissionRequired();
    }

    private void showPermissionRequired() {
        pathView.setText(storageLabel(currentVolume));
        folderList.removeAllViews();
        TextView message = text("画像へのアクセス許可が必要です", 14, TEXT);
        message.setGravity(Gravity.CENTER);
        message.setPadding(dp(12), dp(22), dp(12), dp(10));
        folderList.addView(message, new LinearLayout.LayoutParams(-1, -2));
        TextView retry = NDiagnosticLog.makeDialogAction(this, "権限を許可");
        retry.setGravity(Gravity.CENTER);
        retry.setOnClickListener(v -> ensureImagePermission());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.setMargins(dp(24), dp(4), dp(24), 0);
        folderList.addView(retry, lp);
        setImageConfirmEnabled(false);
        resetScroll();
    }

    private void refreshImages() {
        if (!hasImagePermission()) {
            showPermissionRequired();
            return;
        }
        storageView.setText(storageLabel(currentVolume));
        pathView.setText(buildMediaPath());
        clearImageSelection();

        MediaIndex cached = mediaIndexes.get(currentVolume);
        if (cached != null) {
            renderMediaIndex(cached);
            return;
        }

        folderList.removeAllViews();
        TextView loading = text("画像を読み込み中…", 14, WHITE_UI);
        loading.setPadding(dp(12), dp(22), dp(12), dp(22));
        folderList.addView(loading);
        resetScroll();

        final String volume = currentVolume;
        final int generation = ++mediaLoadGeneration;
        mediaExecutor.execute(() -> {
            long started = SystemClock.elapsedRealtime();
            MediaIndex index;
            try {
                index = loadMediaIndex(volume);
                DiagLog.write(this, "NEX_IMAGE_INDEX volume=" + volume
                        + " count=" + index.totalImages
                        + " ms=" + (SystemClock.elapsedRealtime() - started));
            } catch (SecurityException e) {
                DiagLog.write(this, "NEX_IMAGE_PERMISSION_ERROR " + e.getClass().getSimpleName());
                runOnUiThread(() -> {
                    if (generation == mediaLoadGeneration && !isFinishing()) showPermissionRequired();
                });
                return;
            } catch (Throwable t) {
                DiagLog.write(this, "NEX_IMAGE_QUERY_ERROR " + DiagLog.stackTrace(t));
                index = new MediaIndex();
            }
            final MediaIndex loaded = index;
            runOnUiThread(() -> {
                if (generation != mediaLoadGeneration || isFinishing() || isDestroyed()) return;
                mediaIndexes.put(volume, loaded);
                // The user may have switched storage while the query was running.
                if (!volume.equals(currentVolume)) return;
                renderMediaIndex(loaded);
            });
        });
    }

    private MediaIndex loadMediaIndex(String volume) {
        MediaIndex index = new MediaIndex();
        Uri collection = MediaStore.Images.Media.getContentUri(volume);
        String[] projection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.RELATIVE_PATH,
                MediaStore.Images.Media.MIME_TYPE,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_MODIFIED
        };
        String selection = MediaStore.Images.Media.IS_PENDING + "=0";
        if (Build.VERSION.SDK_INT >= 30) selection += " AND " + MediaStore.Images.Media.IS_TRASHED + "=0";
        try (Cursor cursor = getContentResolver().query(collection, projection, selection, null, null)) {
            if (cursor == null) return index;
            int idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
            int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
            int pathCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH);
            int mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
            int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
            int dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
            while (cursor.moveToNext()) {
                String rel = normalizePath(cursor.getString(pathCol));
                index.paths.add(rel);
                long id = cursor.getLong(idCol);
                String name = cursor.getString(nameCol);
                String mime = cursor.getString(mimeCol);
                long size = cursor.getLong(sizeCol);
                long modified = cursor.getLong(dateCol);
                index.imagesByPath.computeIfAbsent(rel, key -> new ArrayList<>())
                        .add(new ImageEntry(ContentUris.withAppendedId(collection, id), name, mime, size, modified));
                index.totalImages++;
            }
        }
        for (List<ImageEntry> images : index.imagesByPath.values()) {
            images.sort(Comparator.comparing(a -> a.name == null ? "" : a.name, String.CASE_INSENSITIVE_ORDER));
        }
        return index;
    }

    private void renderMediaIndex(MediaIndex index) {
        pathView.setText(buildMediaPath());
        folderList.removeAllViews();
        TreeSet<String> folders = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (String rel : index.paths) {
            if (!rel.startsWith(currentMediaPath)) continue;
            String remainder = rel.substring(currentMediaPath.length());
            if (remainder.isEmpty()) continue;
            int slash = remainder.indexOf('/');
            String child = slash >= 0 ? remainder.substring(0, slash) : remainder;
            if (!child.isBlank()) folders.add(child);
        }
        List<ImageEntry> images = index.imagesByPath.get(currentMediaPath);
        if (images == null) images = Collections.emptyList();

        for (String folder : folders) addMediaFolderRow(folder);
        int visibleCount = Math.min(images.size(), visibleImageLimit);
        for (int i = 0; i < visibleCount; i++) addImageRow(images.get(i));
        if (visibleCount < images.size()) {
            int remaining = images.size() - visibleCount;
            TextView more = NDiagnosticLog.makeDialogAction(this, "さらに表示（" + remaining + "件）");
            more.setGravity(Gravity.CENTER);
            more.setOnClickListener(v -> {
                visibleImageLimit += IMAGE_PAGE_SIZE;
                clearImageSelection();
                renderMediaIndex(index);
            });
            LinearLayout.LayoutParams moreLp = new LinearLayout.LayoutParams(-1, dp(48));
            moreLp.setMargins(dp(12), dp(6), dp(12), dp(6));
            folderList.addView(more, moreLp);
        }

        if (folders.isEmpty() && images.isEmpty()) {
            TextView empty = text("画像はありません", 14, WHITE_UI);
            empty.setPadding(dp(12), dp(22), dp(12), dp(22));
            folderList.addView(empty);
        }
        resetScroll();
    }

    @Override
    protected void onDestroy() {
        mediaLoadGeneration++;
        mediaExecutor.shutdownNow();
        super.onDestroy();
    }

    private String normalizePath(String path) {
        if (path == null || path.isBlank()) return "";
        String out = path.replace('\\', '/');
        while (out.startsWith("/")) out = out.substring(1);
        return out.endsWith("/") ? out : out + "/";
    }

    private String trimTrailingSlash(String path) {
        if (path == null) return "";
        String out = path;
        while (out.endsWith("/") && !out.isEmpty()) out = out.substring(0, out.length() - 1);
        return out;
    }

    private String buildMediaPath() {
        String label = storageLabel(currentVolume);
        if (currentMediaPath.isEmpty()) return label;
        return label + " / " + trimTrailingSlash(currentMediaPath).replace("/", " / ");
    }

    private void addMediaFolderRow(String folder) {
        LinearLayout row = baseRow();
        row.addView(folderIcon(), new LinearLayout.LayoutParams(dp(32), dp(32)));
        TextView name = text(folder, 14, TEXT);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setPadding(dp(10), 0, 0, 0);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(38), 1f));
        row.setOnClickListener(v -> {
            currentMediaPath = currentMediaPath + folder + "/";
            visibleImageLimit = IMAGE_PAGE_SIZE;
            clearImageSelection();
            refreshImages();
        });
        addListRow(row);
    }

    private void addImageRow(ImageEntry image) {
        LinearLayout row = baseRow();

        TextView icon = text("▣", 18, WHITE_UI);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(roundRect(DARK, 7));
        row.addView(icon, new LinearLayout.LayoutParams(dp(32), dp(32)));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setGravity(Gravity.CENTER_VERTICAL);
        labels.setPadding(dp(10), 0, dp(4), 0);
        TextView name = text(image.name == null ? "画像" : image.name, 14, TEXT);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        TextView meta = text(formatSize(image.size), 11, WHITE_UI);
        labels.addView(name, new LinearLayout.LayoutParams(-1, dp(23)));
        labels.addView(meta, new LinearLayout.LayoutParams(-1, dp(17)));
        row.addView(labels, new LinearLayout.LayoutParams(0, dp(42), 1f));

        TextView check = text("✓", 16, Color.WHITE);
        check.setGravity(Gravity.CENTER);
        check.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        check.setBackground(circle(GREEN));
        check.setVisibility(View.INVISIBLE);
        row.addView(check, new LinearLayout.LayoutParams(dp(28), dp(28)));

        row.setOnClickListener(v -> selectImage(image, row, check));
        addListRow(row);
    }

    private String formatSize(long bytes) {
        if (bytes <= 0) return "";
        if (bytes < 1024 * 1024) return String.format(Locale.JAPAN, "%.0f KB", bytes / 1024f);
        return String.format(Locale.JAPAN, "%.1f MB", bytes / (1024f * 1024f));
    }

    private void selectImage(ImageEntry image, View row, TextView check) {
        if (selectedImageRow != null) selectedImageRow.setBackgroundColor(DARK);
        if (selectedImageCheck != null) selectedImageCheck.setVisibility(View.INVISIBLE);
        selectedImage = image;
        selectedImageRow = row;
        selectedImageCheck = check;
        row.setBackgroundColor(LGRAY);
        check.setVisibility(View.VISIBLE);
        setImageConfirmEnabled(true);
    }

    private void clearImageSelection() {
        selectedImage = null;
        selectedImageRow = null;
        selectedImageCheck = null;
        setImageConfirmEnabled(false);
    }

    private void setImageConfirmEnabled(boolean enabled) {
        if (confirmButton == null || !imagePickMode) return;
        confirmButton.setEnabled(enabled);
        confirmButton.setAlpha(enabled ? 1f : 0.42f);
    }

    private LinearLayout baseRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        row.setBackgroundColor(DARK);
        return row;
    }

    private ImageView folderIcon() {
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_n_folder);
        icon.setPadding(dp(6), dp(6), dp(6), dp(6));
        icon.setBackground(roundRect(LBLUE, 9));
        return icon;
    }

    private void addListRow(View row) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
        lp.bottomMargin = dp(1);
        folderList.addView(row, lp);
    }

    private void resetScroll() {
        if (scrollHost == null) return;
        scrollHost.post(() -> {
            scrollHost.scroll.scrollTo(0, 0);
            scrollHost.updateThumb();
        });
    }

    private TextView text(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private GradientDrawable roundRect(int color, float radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private GradientDrawable circle(int color) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setColor(color);
        return drawable;
    }

    private static final class MediaIndex {
        final Set<String> paths = new HashSet<>();
        final Map<String, List<ImageEntry>> imagesByPath = new HashMap<>();
        int totalImages;
    }

    private static final class ImageEntry {
        final Uri uri;
        final String name;
        final String mime;
        final long size;
        final long modified;

        ImageEntry(Uri uri, String name, String mime, long size, long modified) {
            this.uri = uri;
            this.name = name;
            this.mime = mime;
            this.size = size;
            this.modified = modified;
        }
    }

    /** N Standard / PriceRec rule: thin visible thumb + 30dp direct-grab hit area. */
    private final class GripScrollHost extends FrameLayout {
        final TrackingScrollView scroll;
        final View thumb;
        final View hit;
        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable fade;
        int thumbHeight;
        boolean dragging;

        GripScrollHost(Context context, View child) {
            super(context);
            scroll = new TrackingScrollView(context);
            scroll.setVerticalScrollBarEnabled(false);
            scroll.addView(child, new ScrollView.LayoutParams(-1, -2));
            addView(scroll, new FrameLayout.LayoutParams(-1, -1));

            thumb = new View(context);
            fade = () -> thumb.animate().alpha(0f).setDuration(260).start();
            thumb.setBackground(roundRect(WHITE_UI, 2));
            FrameLayout.LayoutParams thumbParams = new FrameLayout.LayoutParams(dp(4), dp(40), Gravity.END | Gravity.TOP);
            thumbParams.rightMargin = dp(2);
            addView(thumb, thumbParams);

            hit = new View(context);
            FrameLayout.LayoutParams hitParams = new FrameLayout.LayoutParams(dp(30), -1, Gravity.END);
            addView(hit, hitParams);
            hit.setOnTouchListener((v, event) -> handleGrip(event));
            post(this::updateThumb);
        }

        void showThumb() {
            handler.removeCallbacks(fade);
            thumb.animate().cancel();
            thumb.setAlpha(1f);
            if (!dragging) handler.postDelayed(fade, 900);
        }

        void updateThumb() {
            if (scroll.getChildCount() == 0 || getHeight() <= 0) return;
            int content = scroll.getChildAt(0).getHeight();
            int viewport = scroll.getHeight();
            int range = Math.max(0, content - viewport);
            if (range <= 0) {
                thumb.setVisibility(View.GONE);
                return;
            }
            thumb.setVisibility(View.VISIBLE);
            thumbHeight = Math.max(dp(36), Math.round(viewport * (viewport / (float) Math.max(viewport, content))));
            thumbHeight = Math.min(viewport, thumbHeight);
            int track = Math.max(1, viewport - thumbHeight);
            float ratio = scroll.getScrollY() / (float) Math.max(1, range);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) thumb.getLayoutParams();
            lp.height = thumbHeight;
            lp.topMargin = Math.round(track * ratio);
            lp.gravity = Gravity.END | Gravity.TOP;
            lp.rightMargin = dp(2);
            thumb.setLayoutParams(lp);
        }

        boolean handleGrip(MotionEvent event) {
            if (thumb.getVisibility() != View.VISIBLE) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = true;
                    showThumb();
                    moveTo(event.getY());
                    return true;
                case MotionEvent.ACTION_MOVE:
                    moveTo(event.getY());
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    showThumb();
                    return true;
                default:
                    return false;
            }
        }

        void moveTo(float y) {
            if (scroll.getChildCount() == 0) return;
            int content = scroll.getChildAt(0).getHeight();
            int viewport = scroll.getHeight();
            int range = Math.max(0, content - viewport);
            int track = Math.max(1, viewport - thumbHeight);
            float ratio = Math.max(0f, Math.min(1f, (y - thumbHeight / 2f) / track));
            scroll.scrollTo(0, Math.round(range * ratio));
            updateThumb();
        }

        final class TrackingScrollView extends ScrollView {
            TrackingScrollView(Context context) { super(context); }

            @Override
            protected void onScrollChanged(int l, int t, int oldl, int oldt) {
                super.onScrollChanged(l, t, oldl, oldt);
                updateThumb();
                showThumb();
            }

            @Override
            protected void onSizeChanged(int w, int h, int oldw, int oldh) {
                super.onSizeChanged(w, h, oldw, oldh);
                post(GripScrollHost.this::updateThumb);
            }
        }
    }
}
