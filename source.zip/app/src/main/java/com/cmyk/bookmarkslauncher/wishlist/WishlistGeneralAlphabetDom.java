package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/**
 * Read-only, host-independent GENERAL recovery engines.  The stages derive from
 * the product-binding strategies developed for ASKUL (B), Yodobashi (C),
 * Bic Camera (D), UNIQLO (E) and MUJI (F).  The original site-locked handlers
 * are NOT replaced.  Stages may only inspect the already verified product URL;
 * they do not click, navigate, read form values or imply stock from a cart link.
 *
 * A is the existing WishlistGeneralPurchaseDom and is run by the caller first.
 */
public final class WishlistGeneralAlphabetDom {
    private WishlistGeneralAlphabetDom() { }
    public static final char[] FALLBACK_ORDER = {'B','C','D','E','F'};

    /** Product-looking unknown routes may be inspected only with stronger
     * on-page SKU/structured Product identity; listings remain rejected. */
    public static boolean candidateUrl(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())
                || !WishlistCrawler.isAllowedUrl(url)) return false;
        if (MarketplaceIdentity.site(url) != MarketplaceIdentity.Site.OTHER) return false;
        String path = url.getPath().toLowerCase(Locale.ROOT).replaceAll("/+$", "");
        if (path.matches("(?i).*/(?:search|category|categories|collections|brand|brands|cart|basket|checkout|login|account|list|ranking)(?:/.*)?"))
            return false;
        String[] segments = path.split("/");
        String last = segments.length == 0 ? "" : segments[segments.length - 1];
        return segments.length >= 3 && last.matches("[a-z0-9_-]{5,30}(?:\\.html)?")
                && !last.equals("index.html");
    }

    public static String source(URL url, char stage) {
        boolean known = WishlistCrawler.isSingleProductPage(url);
        if (url == null || "BCDEF".indexOf(stage) < 0
                || !"https".equalsIgnoreCase(url.getProtocol())
                || !WishlistCrawler.isAllowedUrl(url)
                || !(known || candidateUrl(url)))
            return "JSON.stringify({status:'UNKNOWN',reason:'not-product'})";
        String path = url.getPath().replaceAll("/+$", "");
        String item = path.substring(path.lastIndexOf('/') + 1);
        if (item.toLowerCase(Locale.ROOT).endsWith(".html")) item = item.substring(0,item.length()-5);
        if (!item.matches("(?i)[a-z0-9_-]{5,30}")) item = "";
        // Product identity carried by an Edion item query is stronger than
        // a generic "detail.html" basename; never reuse category parameters.
        if (url.getPath().equalsIgnoreCase("/detail.html") && url.getQuery() != null
                && (url.getHost().equalsIgnoreCase("www.edion.com")
                    || url.getHost().equalsIgnoreCase("edion.com"))) {
            java.util.regex.Matcher idQuery = java.util.regex.Pattern.compile(
                    "(?i)(?:^|&)p_cd=([0-9]{8,14})(?:&|$)").matcher(url.getQuery());
            if (idQuery.find()) item=idQuery.group(1);
        }
        // dショッピング etc. may identify the exact product in ?sku=<item>.
        // Only accept a query identifier when it agrees with the path item.
        String query = url.getQuery();
        if (query != null && query.matches("(?i)(?:^|.*&)sku=[a-z0-9_-]{5,30}(?:&.*|$)")) {
            java.util.regex.Matcher skuQuery = java.util.regex.Pattern.compile(
                    "(?i)(?:^|&)sku=([a-z0-9_-]{5,30})(?:&|$)").matcher(query);
            if (skuQuery.find() && item.equalsIgnoreCase(skuQuery.group(1))) item = skuQuery.group(1);
        }
        // Same-document URL and mode remain bound at both Java/WebView and JS layers.
        return SCRIPT.replace("__HOST__", JSONObject.quote(url.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(path))
                .replace("__ITEM__", JSONObject.quote(item))
                .replace("__STAGE__", JSONObject.quote(String.valueOf(stage)))
                .replace("__KNOWN__", known ? "true" : "false");
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const r={status:'UNKNOWN',reason:'pending',stage:__STAGE__,product:false,
   sku:false,positive:false,negative:false,cart:0,hiddenCart:0,disabledCart:0,enabled:0,quantity:0,
   jsonBound:false,stockSource:'none'};
 const done=()=>JSON.stringify(r);
 try {
  const host=__HOST__, path=__PATH__, code=__ITEM__, knownUrl=__KNOWN__;
  if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host ||
     location.pathname.replace(/\\/+$/,'').toLowerCase()!==path.toLowerCase()){
    r.reason='document-mismatch';return done();
  }
  const body=document.body;if(!body){r.reason='body-pending';return done();}
  const main=document.querySelector('main,[role=main],#main,#contents,#content,#productDetail')||body;
  const bad='header,nav,footer,aside,[class*=recommend],[class*=related],'+
    '[id*=recommend],[id*=related],[class*=ranking],[class*=carousel],'+
    '[class*=suggest],[class*=cross-sell],[class*=pickup]';
  const words=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ').trim();
  function live(e){
    if(!e||e.disabled||e.readOnly||e.hasAttribute('disabled')||
       e.getAttribute('aria-disabled')==='true')return false;
    if(/(?:^|[\\s_-])(?:disabled|soldout|sold-out|unavailable)(?:$|[\\s_-])/i.test(String(e.className||'')))return false;
    for(let p=e;p;p=p.parentElement){
      if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return false;
      const st=getComputedStyle(p);
      if(st.display==='none'||st.visibility==='hidden'||st.visibility==='collapse'||Number(st.opacity)===0)return false;
    }return true;
  }
  const headings=[...main.querySelectorAll('h1')].filter(e=>live(e)&&!e.closest(bad));
  if(headings.length!==1){r.reason='ambiguous-heading';return done();}
  const heading=headings[0],title=words(heading);
  if(title.length<3||title.length>360){r.reason='heading-invalid';return done();}
  const root=heading.closest('[itemtype*=Product],#productDetail,#product-detail,'+
    '.product-detail,.product_detail,.productDetail,.p-product-detail,'+
    '.product-page,.item-detail,.item_detail,.product-info')||main;
  // The first heading check excluded hidden, header, and related-product h1.
  // Reuse EXACTLY that filter, rather than counting invisible responsive clones.
  const productHeadings=[...root.querySelectorAll('h1')].filter(e=>live(e)&&!e.closest(bad));
  if(!root.contains(heading)||productHeadings.length!==1||productHeadings[0]!==heading){
    r.reason='multiple-products';return done();
  }
  const all=words(root),at=all.indexOf(title);
  if(at<0){r.reason='heading-unbound';return done();}
  let local=all.slice(at,at+9500);
  const cut=/(?:関連商品|おすすめ商品|この商品を見た|人気商品|こちらもおすすめ|他の商品|ランキング)/.exec(local);
  if(cut&&cut.index>100)local=local.slice(0,cut.index);
  r.product=local.length>=70;
  if(!r.product){r.reason='product-text-pending';return done();}
  const negative=/(?:在庫\\s*[:：]?\\s*(?:なし|無し|切れ)|売り切れ|売切れ|完売|販売終了|取扱終了|ネットストア在庫なし|オンライン在庫なし|out\\s*of\\s*stock|sold\\s*out|最大注文数\\s*(?:は|:)\\s*0)/i;
  const positive=/(?:在庫\\s*[:：]?\\s*(?:あり|有り|有|残少|僅少)|ネットストア在庫\\s*[:：]?\\s*(?:あり|有り)|オンライン在庫\\s*[:：]?\\s*(?:あり|有り)|in\\s*stock|残りわずか|在庫残少|在庫僅少)/i;
  // Text evidence comes only from the heading-bounded main product; no global banners.
  r.negative=negative.test(local);r.positive=positive.test(local);
  if(r.negative){r.reason='negative-or-conflicting-stock';return done();}
  const itemMarker=code?new RegExp('(?:^|[^a-zA-Z0-9])'+code+'(?:$|[^a-zA-Z0-9])','i'):null;
  // A product code appearing ELSEWHERE on a page cannot validate a wrong SKU.
  // Keep Japanese merchant labels and ZOZO's 問い合わせ番号 adjacent to the id.
  const claimPattern=/(?:商品番号|商品コード|品番|お申込番号|注文番号|お問い合わせ番号|問い合わせ番号|ZOZO品番|SKU|JAN|型番)\\s*(?:[（(]ZOZO[）)])?\\s*[:：#№]?\\s*([a-z0-9_-]{5,30})/ig;
  const claims=[];let claim;
  while((claim=claimPattern.exec(local))&&claims.length<16)claims.push(claim[1]);
  const shortCode=/^[0-9]{13}$/.test(code)?code.slice(-8):'';
  r.sku=!!code&&claims.some(x=>x.toLowerCase()===code.toLowerCase()||
    (!!shortCode&&x===shortCode));
  // Even a formally recognized URL must not override a contradicting item
  // number printed for the displayed product. UNKNOWN is safer than AVAILABLE.
  if(claims.length&&!r.sku){r.reason='contradictory-product-id';return done();}
  const add=/(?:カート|カゴ|かご|買い物かご|お買い物かご|バッグ|バスケット)\\s*(?:に|へ)?\\s*(?:入れる|追加)|商品を\\s*(?:カート|カゴ|かご)\\s*に追加|購入する|今すぐ購入|注文する|add[\\s_-]*to[\\s_-]*(?:cart|bag|basket)|buy\\s*(?:it\\s*)?now/i;
  const view=/(?:カート|カゴ|かご|買い物かご)\\s*(?:を)?\\s*(?:見る|確認)|(?:view|go\\s*to|open)\\s*(?:the\\s*)?(?:cart|bag|basket)|(?:proceed\\s*to\\s*)?checkout/i;
  const qty='input[type=number],input[name*=quantity],input[name*=qty],'+
    'select[name*=quantity],select[name*=qty],[role=spinbutton]';
  const controls=[];
  for(const c of [...root.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a[href],[role=button]')].slice(0,350)){
    if(c.closest(bad))continue;
    const label=[words(c),c.value,c.getAttribute('aria-label'),c.getAttribute('title'),c.getAttribute('alt')].filter(Boolean).join(' ').slice(0,240);
    if(!add.test(label)||view.test(label))continue;
    // Responsive MUJI pages contain hidden copies of #products_cart. Count
    // only interactable controls; hidden/disabled clones must not turn one
    // real product purchase control into an ambiguous set.
    if(!live(c)){
      const disabled=c.disabled||c.readOnly||c.hasAttribute('disabled')||
        c.getAttribute('aria-disabled')==='true'||
        /(?:^|[\\s_-])(?:disabled|soldout|sold-out|unavailable)(?:$|[\\s_-])/i.test(String(c.className||''));
      if(disabled)r.disabledCart++;else r.hiddenCart++;
      continue;
    }
    r.cart++;
    const panel=c.closest('form,[class*=purchase],[class*=buybox],[class*=buy-box],'+
      '[class*=cart-area],[class*=cart_area],[class*=product-form],[class*=order],section')||c.parentElement;
    if(!panel||!root.contains(panel)||panel.closest(bad))continue;
    let nearQty=panel.querySelector(qty);
    if(!nearQty){for(let p=c.parentElement,k=0;p&&k<4&&root.contains(p);p=p.parentElement,k++){
      nearQty=p.querySelector(qty);if(nearQty)break;
    }}
    if(!nearQty){const one=[...root.querySelectorAll(qty)].filter(v=>live(v)&&!v.closest(bad));
      if(one.length===1)nearQty=one[0];}
    if(nearQty&&!live(nearQty))nearQty=null;
    // A product form can contain other mandatory unselected variants.
    const required=[...panel.querySelectorAll('select[required],[aria-required=true]')].filter(live);
    if(required.some(e=>e.tagName==='SELECT'&&(!e.value||e.selectedIndex<0)))continue;
    const attrs=[c.id,c.name,c.getAttribute('data-sku'),c.getAttribute('data-product-id'),
      c.getAttribute('data-action'),panel.getAttribute('data-sku'),panel.getAttribute('data-product-id'),
      panel.getAttribute('id')].filter(Boolean).join(' ');
    const attrBound=!!(itemMarker&&itemMarker.test(attrs));
    controls.push({c,panel,nearQty:!!nearQty,attrBound,label});
    if(nearQty)r.quantity++;
  }
  r.enabled=controls.length;
  // Two responsive add links may be the SAME operation (sticky/inline).  A
  // shared exact href is required for de-duplication; two different actions
  // remain ambiguous, and stock + product identity are still mandatory.
  const unique=[];
  for(const hit of controls){
    const raw=hit.c.getAttribute('href');
    let target='';
    try{if(raw&&raw!=='#'&&!/^javascript:/i.test(raw)){
      const u=new URL(raw,location.href);
      if(u.origin===location.origin)target=u.pathname+u.search;
    }}catch(_){ }
    if(target&&unique.some(u=>u.target===target)){
      r.duplicateCart=(r.duplicateCart||0)+1;continue;
    }
    unique.push({...hit,target});
  }
  if(unique.length!==1||r.cart===0){
    r.reason=unique.length===0?(r.cart===0?'no-live-cart':'cart-unbound'):'ambiguous-live-cart';
    return done();
  }
  const hit=unique[0],panelText=words(hit.panel).slice(0,2500);
  if(negative.test(panelText)){r.reason='negative-panel';return done();}
  const localPositive=positive.test(panelText);
  // A stage may never certify a product merely from a generic "view cart" link.
  // Each letter uses its own verified merchant strategy, never host assumptions.
  let jsonState='UNKNOWN';
  if(r.stage==='D'||r.stage==='E'||r.stage==='F'){
    const matches=[];
    const walk=(v,depth)=>{if(!v||depth>5)return;if(Array.isArray(v)){for(const x of v)walk(x,depth+1);return;}
      if(typeof v!=='object')return;
      const types=Array.isArray(v['@type'])?v['@type']:[v['@type']];
      if(types.some(t=>String(t).toLowerCase()==='product'))matches.push(v);
      if(v['@graph'])walk(v['@graph'],depth+1);
      if(v.mainEntity)walk(v.mainEntity,depth+1);};
    for(const tag of document.querySelectorAll('script[type="application/ld+json"]')){
      try{walk(JSON.parse(tag.textContent||'null'),0);}catch(_){ }
    }
    const linked=matches.filter(obj=>{
      const candidates=[obj.url,obj['@id'],obj.mainEntityOfPage];
      const sameUrl=candidates.some(x=>{try{const raw=typeof x==='object'?(x&&x['@id']):x;
        if(!raw)return false;const u=new URL(String(raw),location.href);
        return u.origin===location.origin&&u.pathname.replace(/\\/+$/,'')===path;
      }catch(_){return false;}});
      // Accept an exact SKU match only, not a related Product description.
      const ids=[obj.sku,obj.productID,obj.productId,obj.gtin13,obj.gtin]
        .filter(x=>x!==undefined&&x!==null&&String(x).length>0);
      const sameSku=!!code&&ids.some(x=>String(x).toLowerCase()===code.toLowerCase());
      const short=code.length===13?code.slice(-8):'';
      const labelledShort=!!short&&new RegExp('商品番号\\\\s*[:：]?\\\\s*'+short+'(?![0-9])').test(local);
      const sameShort=labelledShort&&ids.some(x=>String(x)===short);
      // Contradictory explicit IDs cannot be overridden by a shared page URL.
      return sameSku||sameShort||(sameUrl&&ids.length===0);
    });
    if(linked.length===1){r.jsonBound=true;const offers=Array.isArray(linked[0].offers)?linked[0].offers:[linked[0].offers];
      if(offers.length&&offers.every(o=>o&&/^(?:https?:\\/\\/schema.org\\/)?(?:InStock|LimitedAvailability)$/i.test(String(o.availability||''))))jsonState='AVAILABLE';
      else if(offers.length&&offers.every(o=>o&&/^(?:https?:\\/\\/schema.org\\/)?(?:OutOfStock|SoldOut)$/i.test(String(o.availability||''))))jsonState='UNAVAILABLE';
    }
  }
  if(jsonState==='UNAVAILABLE'){r.reason='structured-negative';return done();}
  // On an unknown URL shape, require an actual SKU or URL-matched structured
  // Product. A bare h1 plus a cart control cannot establish a single product.
  if(!knownUrl && !(r.sku||hit.attrBound||r.jsonBound)){
    r.reason='new-site-product-unbound';return done();
  }
  if(r.stage==='B'){
    // ASKUL: SKU-bound product, quantity, explicit visible stock and cart.
    if((r.sku||hit.attrBound)&&r.positive&&hit.nearQty&&localPositive){
      r.status='AVAILABLE';r.reason='sku-stock-quantity-cart';
    }else r.reason='sku-stock-or-quantity-missing';
  }else if(r.stage==='C'){
    // Yodobashi: lone product buybox and positive local selling-stock label.
    if(r.positive&&localPositive&&(hit.panel.matches('form')||hit.nearQty||r.sku||hit.attrBound)){
      r.status='AVAILABLE';r.reason='local-buybox-stock-cart';
    }else r.reason='local-buybox-unverified';
  }else if(r.stage==='D'){
    // Bic Camera: URL-bound Product offer with InStock and live product cart.
    if(r.jsonBound&&jsonState==='AVAILABLE'&&(r.positive||localPositive)){
      r.status='AVAILABLE';r.reason='structured-same-product-cart';
    }else r.reason='structured-offer-or-stock-unverified';
  }else if(r.stage==='E'){
    // UNIQLO: selection-dependent; NEVER infer a color/size from page defaults.
    const variants=[...root.querySelectorAll('select[required],[aria-required=true],[data-variant-selected]')]
      .filter(e=>live(e)&&!e.closest(bad));
    const allSelected=variants.length>0&&variants.every(e=>
      e.tagName==='SELECT'?!!e.value&&e.selectedIndex>=0:
      e.getAttribute('data-variant-selected')==='true'||e.getAttribute('aria-checked')==='true');
    if(allSelected&&hit.nearQty&&(r.positive||jsonState==='AVAILABLE')){
      r.status='AVAILABLE';r.reason='selected-variant-stock-cart';
    }else r.reason='variant-not-proven';
  }else if(r.stage==='F'){
    // Port the positive JSON-LD binding proven by MUJI's dedicated engine:
    // an exact-SKU/URL-bound InStock offer and a single real product CTA can
    // verify availability without a numeric quantity field.  Site-independent
    // F uses the same read-only evidence standard, never the MUJI hostname.
    // MUJI: the cart button may remain enabled after stock is gone. Need a
    // product-bound explicit stock signal in addition to the live cart.
    // MUJI may leave the button live when the online item is out of stock.
    // Require either verified stock text in this product's own buybox or an
    // exact-URL/SKU-linked Product offer claiming InStock. Neither a cart
    // button nor a store-availability popup alone can establish availability.
    if((hit.nearQty&&r.positive&&localPositive)||
       (r.jsonBound&&jsonState==='AVAILABLE'&&
        (r.sku||hit.attrBound||knownUrl||!location.search))){
      r.stockSource=r.jsonBound&&jsonState==='AVAILABLE'?'same-product-offer':'visible-buybox';
      r.status='AVAILABLE';r.reason='dynamic-product-positive-stock-cart';
    }else r.reason=hit.nearQty?'stock-unverified':'quantity-unverified';
  }
  return done();
 }catch(_){r.reason='dom-error';return done();}
})()
""";
}
