package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/**
 * Shared GENERAL read-only evidence collector. Site-specific page handlers are
 * never copied into the alphabet. B-F inject only their distinctive evidence
 * evaluation policy (WishlistGeneralEvidenceTechniques) into this single
 * verified-URL/identity/cart/structured-Product reader. G is the reusable
 * variant-row technique with a conservative ZOZO-specific identity adapter.
 * H delegates only exact Mercari item URLs to its existing, isolated listing
 * state inspector. No Mercari selector is copied to the shared techniques.
 * A remains the legacy GENERAL inspector and is run by the caller first.
 * Nothing here clicks, navigates, or assumes a live cart proves availability.
 */
public final class WishlistGeneralAlphabetDom {
    private WishlistGeneralAlphabetDom() { }
    public static final char[] FALLBACK_ORDER = {'B','C','D','E','F','G','H'};

    /** Product-looking unknown routes may be inspected only with stronger
     * on-page SKU/structured Product identity; listings remain rejected. */
    public static boolean candidateUrl(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())
                || !WishlistCrawler.isAllowedUrl(url)) return false;
        if (MarketplaceIdentity.site(url) != MarketplaceIdentity.Site.OTHER) return false;
        String path = url.getPath().toLowerCase(Locale.ROOT).replaceAll("/+$", "");
        if (path.matches("(?i).*/(?:search|category|categories|collections|brand|brands|cart|basket|checkout|login|account|list|ranking)(?:/.*)?"))
            return false;
        String[] segments = path.split("/");
        String last = segments.length == 0 ? "" : segments[segments.length - 1];
        return segments.length >= 3 && last.matches("[a-z0-9_-]{5,30}(?:\\.html)?")
                && !last.equals("index.html");
    }

    public static String source(URL url, char stage) {
        if (stage == 'G') return WishlistGeneralVariantStockDom.source(url);
        if (stage == 'H') return WishlistMercariItemStockDom.javascript(url);
        boolean known = WishlistCrawler.isSingleProductPage(url);
        if (url == null || "BCDEF".indexOf(stage) < 0
                || !"https".equalsIgnoreCase(url.getProtocol())
                || !WishlistCrawler.isAllowedUrl(url)
                || !(known || candidateUrl(url)))
            return "JSON.stringify({status:'UNKNOWN',reason:'not-product'})";
        String path = url.getPath().replaceAll("/+$", "");
        String item = WishlistGeneralProductIdentity.code(url);
        // Same-document URL and mode remain bound at both Java/WebView and JS layers.
        return SCRIPT.replace("__HOST__", JSONObject.quote(url.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(path))
                .replace("__ITEM__", JSONObject.quote(item))
                .replace("__STAGE__", JSONObject.quote(String.valueOf(stage)))
                .replace("__KNOWN__", known ? "true" : "false")
                .replace("__POLICY_TECHNIQUE__", WishlistGeneralEvidenceTechniques.script(stage));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const r={status:'UNKNOWN',reason:'pending',stage:__STAGE__,product:false,
   sku:false,positive:false,negative:false,cart:0,hiddenCart:0,disabledCart:0,enabled:0,quantity:0,
   jsonBound:false,stockSource:'none',identity:'none',claimCount:0,cartKind:'none',skippedLinks:0,outsideCart:0};
 const done=()=>JSON.stringify(r);
 try {
  const host=__HOST__, path=__PATH__, code=__ITEM__, knownUrl=__KNOWN__;
  if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host ||
     location.pathname.replace(/\\/+$/,'').toLowerCase()!==path.toLowerCase()){
    r.reason='document-mismatch';return done();
  }
  // ZOZO supports many independent size/colour stock rows. A generic
  // product-wide stock phrase must never certify a different ?did= variant.
  // A is already downgraded to UNVERIFIED by the caller; B-F defer only
  // ZOZO product pages to the identity- and variant-bound G engine.
  if(/^(?:www\\.)?zozo\\.jp$/.test(host)&&
     /^\\/shop\\/[a-z0-9_-]+\\/goods(?:-sale)?\\/[0-9]{5,15}$/i.test(path)){
    r.reason='zozo-variant-route-to-g';return done();
  }
  const body=document.body;if(!body){r.reason='body-pending';return done();}
  const main=document.querySelector('main,[role=main],#main,#contents,#content,#productDetail')||body;
  const bad='header,nav,footer,aside,[class*=recommend],[class*=related],'+
    '[id*=recommend],[id*=related],[class*=ranking],[class*=carousel],'+
    '[class*=suggest],[class*=cross-sell],[class*=pickup]';
  const words=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ').trim();
  function live(e){
    if(!e||e.disabled||e.readOnly||e.hasAttribute('disabled')||
       e.getAttribute('aria-disabled')==='true')return false;
    if(/(?:^|[\\s_-])(?:disabled|soldout|sold-out|unavailable)(?:$|[\\s_-])/i.test(String(e.className||'')))return false;
    for(let p=e;p;p=p.parentElement){
      if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return false;
      const st=getComputedStyle(p);
      if(st.display==='none'||st.visibility==='hidden'||st.visibility==='collapse'||Number(st.opacity)===0)return false;
    }return true;
  }
  const headings=[...main.querySelectorAll('h1')].filter(e=>live(e)&&!e.closest(bad));
  if(headings.length!==1){r.reason='ambiguous-heading';return done();}
  const heading=headings[0],title=words(heading);
  if(title.length<3||title.length>360){r.reason='heading-invalid';return done();}
  const root=heading.closest('[itemtype*=Product],#productDetail,#product-detail,'+
    '.product-detail,.product_detail,.productDetail,.p-product-detail,'+
    '.product-page,.item-detail,.item_detail,.product-info')||main;
  // The first heading check excluded hidden, header, and related-product h1.
  // Reuse EXACTLY that filter, rather than counting invisible responsive clones.
  const productHeadings=[...root.querySelectorAll('h1')].filter(e=>live(e)&&!e.closest(bad));
  if(!root.contains(heading)||productHeadings.length!==1||productHeadings[0]!==heading){
    r.reason='multiple-products';return done();
  }
  const all=words(root),at=all.indexOf(title);
  if(at<0){r.reason='heading-unbound';return done();}
  let local=all.slice(at,at+9500);
  const cut=/(?:関連商品|おすすめ商品|この商品を見た|人気商品|こちらもおすすめ|他の商品|ランキング)/.exec(local);
  if(cut&&cut.index>100)local=local.slice(0,cut.index);
  r.product=local.length>=70;
  if(!r.product){r.reason='product-text-pending';return done();}
  const negative=/(?:在庫\\s*[:：]?\\s*(?:なし|無し|切れ)|売り切れ|売切れ|完売|販売終了|取扱終了|ネットストア在庫なし|オンライン在庫なし|out\\s*of\\s*stock|sold\\s*out|最大注文数\\s*(?:は|:)\\s*0)/i;
  const positive=/(?:在庫\\s*[:：]?\\s*(?:あり|有り|有|残少|僅少)|ネットストア在庫\\s*[:：]?\\s*(?:あり|有り)|オンライン在庫\\s*[:：]?\\s*(?:あり|有り)|in\\s*stock|残りわずか|在庫残少|在庫僅少)/i;
  // Text evidence comes only from the heading-bounded main product; no global banners.
  r.negative=negative.test(local);r.positive=positive.test(local);
  if(r.negative){r.reason='negative-or-conflicting-stock';return done();}
  const itemMarker=code?new RegExp('(?:^|[^a-zA-Z0-9])'+code+'(?:$|[^a-zA-Z0-9])','i'):null;
  // A product code appearing ELSEWHERE on a page cannot validate a wrong SKU.
  // Keep Japanese merchant labels and ZOZO's 問い合わせ番号 adjacent to the id.
  const claimPattern=/(?:商品番号|商品コード|品番|お申込番号|注文番号|お問い合わせ番号|問い合わせ番号|ZOZO品番|SKU|JAN|型番)\\s*(?:[（(]ZOZO[）)])?\\s*[:：#№]?\\s*([a-z0-9_-]{5,30})/ig;
  const claims=[];let claim;
  while((claim=claimPattern.exec(local))&&claims.length<16)claims.push(claim[1]);
  r.claimCount=claims.length;
  const shortCode=/^[0-9]{13}$/.test(code)?code.slice(-8):'';
  r.sku=!!code&&claims.some(x=>x.toLowerCase()===code.toLowerCase()||
    (!!shortCode&&x===shortCode));
  if(r.sku)r.identity='same-labeled-sku';
  // ZOZO publicly prints a ZOZO 問い合わせ番号 that is frequently exactly
  // goods-id + 1000000.  It is NOT a general SKU equivalence rule: accept
  // only a ZOZO-labelled ID inside the main product, on an exact ZOZO goods URL.
  const zozoHost=/^(?:www\\.)?zozo\\.jp$/.test(host);
  const zozoPath=/^\\/shop\\/[a-z0-9_-]+\\/goods(?:-sale)?\\/[0-9]{5,15}$/i.test(path);
  if(zozoHost&&zozoPath&&/^\\d{5,15}$/.test(code)){
    const wanted=String(Number(code)+1000000);
    const inMain=words(main).slice(0,90000);
    const zozoLabels=[...inMain.matchAll(/問い合わせ番号\\s*[:：]?\\s*([0-9]{5,15})\\s*[（(]ZOZO[）)]/g)].slice(0,5);
    if(zozoLabels.some(x=>x[1]===code||x[1]===wanted)){
      r.sku=true;r.identity='zozo-labelled-id';
    }
  }
  // A nonmatching merchant identifier might be a STORE number (ZOZO shows
  // both ZOZO and store codes). Do not use it as a global contradiction on ZOZO.
  // Otherwise preserve the strict conflicting-SKU safety rule.
  if(claims.length&&!r.sku){r.reason='contradictory-product-id';return done();}
  const add=/(?:カート|カゴ|かご|買い物かご|お買い物かご|バッグ|バスケット)\\s*(?:に|へ)?\\s*(?:入れる|追加)|商品を\\s*(?:カート|カゴ|かご)\\s*に追加|購入する|今すぐ購入|注文する|add[\\s_-]*to[\\s_-]*(?:cart|bag|basket)|buy\\s*(?:it\\s*)?now/i;
  const view=/(?:カート|カゴ|かご|買い物かご)\\s*(?:を)?\\s*(?:見る|確認)|(?:view|go\\s*to|open)\\s*(?:the\\s*)?(?:cart|bag|basket)|(?:proceed\\s*to\\s*)?checkout/i;
  const qty='input[type=number],input[name*=quantity],input[name*=qty],'+
    'select[name*=quantity],select[name*=qty],[role=spinbutton]';
  // Distinguish an actual absence of a cart from purchase links outside
  // the selected product root (e.g. responsive site shell / embedded frame).
  // Outside-root actions are diagnostic ONLY; never make them AVAILABLE.
  for(const el of [...main.querySelectorAll('button,a[href],[role=button]')].slice(0,260)){
    if(!root.contains(el)&&!el.closest(bad)&&add.test(words(el).slice(0,100)))r.outsideCart++;
  }
  const controls=[];
  for(const c of [...root.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a[href],[role=button]')].slice(0,350)){
    if(c.closest(bad))continue;
    const label=[words(c),c.value,c.getAttribute('aria-label'),c.getAttribute('title'),c.getAttribute('alt')].filter(Boolean).join(' ').slice(0,240);
    if(!add.test(label)||view.test(label))continue;
    // Responsive MUJI pages contain hidden copies of #products_cart. Count
    // only interactable controls; hidden/disabled clones must not turn one
    // real product purchase control into an ambiguous set.
    if(!live(c)){
      const disabled=c.disabled||c.readOnly||c.hasAttribute('disabled')||
        c.getAttribute('aria-disabled')==='true'||
        /(?:^|[\\s_-])(?:disabled|soldout|sold-out|unavailable)(?:$|[\\s_-])/i.test(String(c.className||''));
      if(disabled)r.disabledCart++;else r.hiddenCart++;
      continue;
    }
    r.cart++;
    const panel=c.closest('form,[class*=purchase],[class*=buybox],[class*=buy-box],'+
      '[class*=cart-area],[class*=cart_area],[class*=product-form],[class*=order],section')||c.parentElement;
    if(!panel||!root.contains(panel)||panel.closest(bad))continue;
    let nearQty=panel.querySelector(qty);
    if(!nearQty){for(let p=c.parentElement,k=0;p&&k<4&&root.contains(p);p=p.parentElement,k++){
      nearQty=p.querySelector(qty);if(nearQty)break;
    }}
    if(!nearQty){const one=[...root.querySelectorAll(qty)].filter(v=>live(v)&&!v.closest(bad));
      if(one.length===1)nearQty=one[0];}
    if(nearQty&&!live(nearQty))nearQty=null;
    // A product form can contain other mandatory unselected variants.
    const required=[...panel.querySelectorAll('select[required],[aria-required=true]')].filter(live);
    if(required.some(e=>e.tagName==='SELECT'&&(!e.value||e.selectedIndex<0)))continue;
    const attrs=[c.id,c.name,c.getAttribute('data-sku'),c.getAttribute('data-product-id'),
      c.getAttribute('data-action'),panel.getAttribute('data-sku'),panel.getAttribute('data-product-id'),
      panel.getAttribute('id')].filter(Boolean).join(' ');
    const attrBound=!!(itemMarker&&itemMarker.test(attrs));
    controls.push({c,panel,nearQty:!!nearQty,attrBound,label});
    if(nearQty)r.quantity++;
  }
  r.enabled=controls.length;
  // Two responsive add links may be the SAME operation (sticky/inline).  A
  // shared exact href is required for de-duplication; two different actions
  // remain ambiguous, and stock + product identity are still mandatory.
  const unique=[];
  for(const hit of controls){
    const raw=hit.c.getAttribute('href');
    let target='';
    try{if(raw&&raw!=='#'&&!/^javascript:/i.test(raw)){
      const u=new URL(raw,location.href);
      if(u.origin===location.origin)target=u.pathname+u.search;
    }}catch(_){ }
    if(target&&unique.some(u=>u.target===target)){
      r.duplicateCart=(r.duplicateCart||0)+1;continue;
    }
    unique.push({...hit,target});
  }
  // Product detail pages can carry an informational purchase link PLUS an
  // actual cart button. Prefer the single live ADD button when all other
  // candidates are links; NEVER merge different real cart buttons or infer
  // stock from choosing an action.
  let resolved=unique;
  if(unique.length>1){
    const buttons=unique.filter(h=>h.c.tagName!=='A');
    const links=unique.filter(h=>h.c.tagName==='A');
    if(buttons.length===1&&links.length===unique.length-1){
      resolved=buttons;r.skippedLinks=links.length;r.cartKind='button-over-links';
    }
  }
  if(resolved.length!==1||r.cart===0){
    r.reason=resolved.length===0?(r.cart===0?'no-live-cart':'cart-unbound'):'ambiguous-live-cart';
    return done();
  }
  const hit=resolved[0],panelText=words(hit.panel).slice(0,2500);
  if(r.cartKind==='none')r.cartKind=hit.c.tagName==='A'?'purchase-link':'purchase-button';
  if(negative.test(panelText)){r.reason='negative-panel';return done();}
  const localPositive=positive.test(panelText);
  // A stage may never certify a product merely from a generic "view cart" link.
  // Each letter uses its own verified merchant strategy, never host assumptions.
  let jsonState='UNKNOWN';
  if(r.stage==='D'||r.stage==='E'||r.stage==='F'){
    const matches=[];
    const walk=(v,depth)=>{if(!v||depth>5)return;if(Array.isArray(v)){for(const x of v)walk(x,depth+1);return;}
      if(typeof v!=='object')return;
      const types=Array.isArray(v['@type'])?v['@type']:[v['@type']];
      if(types.some(t=>String(t).toLowerCase()==='product'))matches.push(v);
      if(v['@graph'])walk(v['@graph'],depth+1);
      if(v.mainEntity)walk(v.mainEntity,depth+1);};
    for(const tag of document.querySelectorAll('script[type="application/ld+json"]')){
      try{walk(JSON.parse(tag.textContent||'null'),0);}catch(_){ }
    }
    const linked=matches.filter(obj=>{
      const candidates=[obj.url,obj['@id'],obj.mainEntityOfPage];
      const sameUrl=candidates.some(x=>{try{const raw=typeof x==='object'?(x&&x['@id']):x;
        if(!raw)return false;const u=new URL(String(raw),location.href);
        return u.origin===location.origin&&u.pathname.replace(/\\/+$/,'')===path;
      }catch(_){return false;}});
      // Accept an exact SKU match only, not a related Product description.
      const ids=[obj.sku,obj.productID,obj.productId,obj.gtin13,obj.gtin]
        .filter(x=>x!==undefined&&x!==null&&String(x).length>0);
      const sameSku=!!code&&ids.some(x=>String(x).toLowerCase()===code.toLowerCase());
      const short=code.length===13?code.slice(-8):'';
      const labelledShort=!!short&&new RegExp('商品番号\\\\s*[:：]?\\\\s*'+short+'(?![0-9])').test(local);
      const sameShort=labelledShort&&ids.some(x=>String(x)===short);
      // Contradictory explicit IDs cannot be overridden by a shared page URL.
      return sameSku||sameShort||(sameUrl&&ids.length===0);
    });
    if(linked.length===1){r.jsonBound=true;const offers=Array.isArray(linked[0].offers)?linked[0].offers:[linked[0].offers];
      if(offers.length&&offers.every(o=>o&&/^(?:https?:\\/\\/schema.org\\/)?(?:InStock|LimitedAvailability)$/i.test(String(o.availability||''))))jsonState='AVAILABLE';
      else if(offers.length&&offers.every(o=>o&&/^(?:https?:\\/\\/schema.org\\/)?(?:OutOfStock|SoldOut)$/i.test(String(o.availability||''))))jsonState='UNAVAILABLE';
    }
  }
  if(jsonState==='UNAVAILABLE'){r.reason='structured-negative';return done();}
  // On an unknown URL shape, require an actual SKU or URL-matched structured
  // Product. A bare h1 plus a cart control cannot establish a single product.
  if(!knownUrl && !(r.sku||hit.attrBound||r.jsonBound)){
    r.reason='new-site-product-unbound';return done();
  }
  __POLICY_TECHNIQUE__
  return done();
 }catch(_){r.reason='dom-error';return done();}
})()
""";
}
