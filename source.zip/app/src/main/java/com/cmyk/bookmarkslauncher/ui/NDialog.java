package com.cmyk.bookmarkslauncher.ui;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.QrUtils;
import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.googlemaps.GoogleMapsModule;
import com.cmyk.bookmarkslauncher.youtube.YouTubeModule;

import java.io.File;
import java.text.DateFormat;
import java.util.Date;

public final class NDialog {
    public interface ChoiceListener { void onChoice(int which); }
    public interface TextListener { void onText(String text); }
    public interface DeleteListener { void onDelete(); }
    public interface CopyListener { void onCopy(); }
    public interface FolderDeleteListener { void onDelete(boolean protectContents); }
    public interface RenameListener { void onRename(String newName); }
    public interface ThumbnailRefreshCallback { void onComplete(BookmarkNode updatedNode, boolean success); }
    public interface ThumbnailRefreshListener { void onRefresh(ThumbnailRefreshCallback callback); }
    public interface OfflineActionsListener {
        void onOpen();
        void onSaveOrUpdate();
        void onDelete();
    }
    public interface QrScanCallback {
        void onScanned(String value);
        void onError(String message);
    }
    public interface QrScanListener { void onScan(QrScanCallback callback); }
    public interface QrImageLoadListener { void onLoad(QrScanCallback callback); }
    public interface QrCreateListener { void onCreate(String name, String value); }

    /** Live handle for the bookmark property sheet so offline state can refresh in-place. */
    public static final class BookmarkDetailsHandle {
        private final Activity activity;
        private final Dialog dialog;
        private final LinearLayout offlineRow;
        private final OfflineActionsListener offlineActionsListener;

        private BookmarkDetailsHandle(Activity activity, Dialog dialog, LinearLayout offlineRow,
                                      OfflineActionsListener offlineActionsListener) {
            this.activity = activity;
            this.dialog = dialog;
            this.offlineRow = offlineRow;
            this.offlineActionsListener = offlineActionsListener;
        }

        public boolean isShowing() {
            return dialog != null && dialog.isShowing();
        }

        public void setOfflineSaved(boolean saved) {
            if (offlineRow == null) return;
            activity.runOnUiThread(() -> renderOfflineActions(activity, offlineRow, saved, offlineActionsListener));
        }
    }

    private static final int D_GRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int L_GRAY = 0xFF656060;
    private static final int L_BLUE = 0xFF445577;
    private static final int L_RED = 0xFF662211;
    private static final int ORANGE = 0xFF775500;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int ICON = 0xFFA9A999;

    private NDialog() {}

    public static void showChoices(Activity activity, String title, String[] items, int destructiveIndex, ChoiceListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);
        for (int i = 0; i < items.length; i++) {
            final int index = i;
            TextView row = action(activity, items[i], i == destructiveIndex ? L_RED : GRAY);
            row.setOnClickListener(v -> {
                dialog.dismiss();
                listener.onChoice(index);
            });
            root.addView(row, lpMatchWrap(0, 4, 0, 4));
        }
        dialog.setContentView(root);
        show(activity, dialog);
    }

    /**
     * Launcher-style context menu: one large rounded N-gray sheet with simple left-aligned
     * white rows. These rows are intentionally not pill buttons.
     */
    public static void showPlainMenu(Activity activity, String title, String[] items, ChoiceListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        if (title != null && !title.isBlank()) addTitle(activity, root, title, Gravity.CENTER_VERTICAL);
        ScrollView scroll = new ScrollView(activity);
        LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        for (int i = 0; i < items.length; i++) {
            final int index = i;
            TextView row = new TextView(activity);
            row.setText(items[i]);
            row.setTextColor(TEXT);
            row.setTextSize(18);
            row.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            row.setPadding(dp(activity, 4), 0, dp(activity, 4), 0);
            row.setBackgroundColor(0x00000000);
            row.setOnClickListener(v -> {
                dialog.dismiss();
                if (listener != null) listener.onChoice(index);
            });
            list.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 58)));
        }
        int maxHeight = Math.round(activity.getResources().getDisplayMetrics().heightPixels * 0.62f);
        int menuHeight = Math.min(maxHeight, dp(activity, Math.max(1, items.length) * 58));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, menuHeight));
        dialog.setContentView(root);
        show(activity, dialog);
    }

    /** Dedicated destructive-action confirmation using the N dialog layout. */
    public static void showDeleteConfirmation(Activity activity, String message, DeleteListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);

        TextView body = new TextView(activity);
        body.setText(message);
        body.setTextColor(TEXT);
        body.setTextSize(18);
        body.setGravity(Gravity.CENTER);
        body.setPadding(dp(activity, 8), dp(activity, 12), dp(activity, 8), dp(activity, 18));
        root.addView(body, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // A destructive confirmation is intentionally centered rather than using the
        // right-aligned action-row convention used by the property sheets.
        LinearLayout buttons = new LinearLayout(activity);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);

        TextView cancel = action(activity, "キャンセル", GRAY);
        cancel.setGravity(Gravity.CENTER);
        cancel.setSingleLine(true);
        cancel.setMinWidth(dp(activity, 112));
        cancel.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(cancel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(activity, 44)));

        Space gap = new Space(activity);
        buttons.addView(gap, new LinearLayout.LayoutParams(dp(activity, 10), 1));

        TextView delete = action(activity, "削除", L_RED);
        delete.setGravity(Gravity.CENTER);
        delete.setSingleLine(true);
        delete.setMinWidth(dp(activity, 88));
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            if (listener != null) listener.onDelete();
        });
        buttons.addView(delete, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(activity, 44)));
        root.addView(buttons, lpMatchWrap(0, 0, 0, 0));

        dialog.setContentView(root);
        showDeleteConfirmationWindow(activity, dialog);
    }

    public static void showMessage(Activity activity, String title, String message) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);

        ScrollView scroll = new ScrollView(activity);
        TextView body = new TextView(activity);
        body.setText(message);
        body.setTextColor(TEXT);
        body.setTextSize(15);
        body.setLineSpacing(0f, 1.12f);
        body.setPadding(dp(activity, 4), dp(activity, 2), dp(activity, 4), dp(activity, 12));
        scroll.addView(body, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 280)));

        addCloseRow(activity, root, dialog);
        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showQrCreate(Activity activity, QrScanListener scanListener, QrImageLoadListener imageLoadListener, QrCreateListener createListener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, "QR作成", Gravity.CENTER_VERTICAL);

        int square = Math.max(dp(activity, 180), activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 72));
        FrameLayout capture = new FrameLayout(activity);
        capture.setBackground(roundRect(activity, D_GRAY, 12));
        capture.setClipToOutline(true);

        ImageView qrImage = new ImageView(activity);
        qrImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        qrImage.setPadding(dp(activity, 14), dp(activity, 14), dp(activity, 14), dp(activity, 14));
        qrImage.setVisibility(View.GONE);
        capture.addView(qrImage, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView captureText = new TextView(activity);
        captureText.setText("撮影");
        captureText.setTextColor(TEXT);
        captureText.setTextSize(20);
        captureText.setGravity(Gravity.CENTER);
        capture.addView(captureText, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout.LayoutParams captureLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, square);
        captureLp.setMargins(0, dp(activity, 4), 0, dp(activity, 12));
        root.addView(capture, captureLp);

        TextView imageLoad = action(activity, "画像読み込み", L_BLUE);
        imageLoad.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams imageLoadLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 44));
        imageLoadLp.setMargins(0, 0, 0, dp(activity, 12));
        root.addView(imageLoad, imageLoadLp);

        addFieldLabel(activity, root, "名前");
        EditText name = new EditText(activity);
        name.setSingleLine(true);
        name.setText("QR");
        name.setSelectAllOnFocus(true);
        name.setTextColor(TEXT);
        name.setHintTextColor(ICON);
        name.setTextSize(16);
        name.setPadding(dp(activity, 12), 0, dp(activity, 12), 0);
        name.setBackground(roundRect(activity, D_GRAY, 10));
        root.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 48)));

        addFieldLabel(activity, root, "内容");
        TextView payloadView = new TextView(activity);
        payloadView.setText("未撮影");
        payloadView.setTextColor(ICON);
        payloadView.setTextSize(14);
        payloadView.setMaxLines(4);
        payloadView.setEllipsize(TextUtils.TruncateAt.END);
        payloadView.setTextIsSelectable(true);
        payloadView.setPadding(dp(activity, 2), dp(activity, 2), dp(activity, 2), dp(activity, 8));
        root.addView(payloadView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        String[] payload = {null};
        LinearLayout buttons = buttonRow(activity);
        TextView cancel = action(activity, "キャンセル", GRAY);
        cancel.setGravity(Gravity.CENTER);
        cancel.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(cancel, new LinearLayout.LayoutParams(dp(activity, 112), dp(activity, 46)));
        Space gap = new Space(activity);
        buttons.addView(gap, new LinearLayout.LayoutParams(dp(activity, 10), 1));
        TextView add = action(activity, "登録", L_BLUE);
        add.setGravity(Gravity.CENTER);
        add.setEnabled(false);
        add.setAlpha(0.45f);
        add.setOnClickListener(v -> {
            String value = payload[0];
            if (value == null || value.isBlank()) return;
            String title = name.getText().toString().trim();
            dialog.dismiss();
            if (createListener != null) createListener.onCreate(title, value);
        });
        buttons.addView(add, new LinearLayout.LayoutParams(dp(activity, 96), dp(activity, 46)));
        root.addView(buttons, lpMatchWrap(12, 4, 0, 0));

        QrScanCallback resultCallback = new QrScanCallback() {
            @Override public void onScanned(String value) {
                activity.runOnUiThread(() -> {
                    capture.setEnabled(true);
                    imageLoad.setEnabled(true);
                    if (value == null || value.isBlank()) return;
                    Bitmap bitmap = QrUtils.render(value, 1000);
                    if (bitmap == null) {
                        Toast.makeText(activity, "QR再生成に失敗しました", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    payload[0] = value;
                    qrImage.setImageBitmap(bitmap);
                    qrImage.setVisibility(View.VISIBLE);
                    captureText.setVisibility(View.GONE);
                    payloadView.setText(value);
                    payloadView.setTextColor(TEXT);
                    add.setEnabled(true);
                    add.setAlpha(1f);
                });
            }

            @Override public void onError(String message) {
                activity.runOnUiThread(() -> {
                    capture.setEnabled(true);
                    imageLoad.setEnabled(true);
                    if (message != null && !message.isBlank()) {
                        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        };

        capture.setOnClickListener(v -> {
            if (scanListener == null) return;
            capture.setEnabled(false);
            imageLoad.setEnabled(false);
            scanListener.onScan(resultCallback);
        });
        imageLoad.setOnClickListener(v -> {
            if (imageLoadListener == null) return;
            capture.setEnabled(false);
            imageLoad.setEnabled(false);
            imageLoadListener.onLoad(resultCallback);
        });

        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showQrPreview(Activity activity, BookmarkNode node, Runnable savePng) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, node == null ? "QR" : node.displayName(), Gravity.CENTER_VERTICAL);

        int square = Math.max(dp(activity, 220), activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 72));
        FrameLayout frame = buildQrFrame(activity, node == null ? null : node.url);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, square);
        lp.setMargins(0, dp(activity, 4), 0, dp(activity, 12));
        root.addView(frame, lp);

        LinearLayout bottom = bottomRow(activity);
        TextView save = action(activity, "PNG保存", L_BLUE);
        save.setGravity(Gravity.CENTER);
        save.setOnClickListener(v -> {
            if (savePng != null) savePng.run();
        });
        bottom.addView(save, new LinearLayout.LayoutParams(dp(activity, 112), dp(activity, 44)));
        addFlexibleSpacer(activity, bottom);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        bottom.addView(close, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));
        root.addView(bottom, lpMatchWrap(4, 0, 0, 0));

        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showQrDetails(Activity activity, BookmarkNode node,
                                     RenameListener renameListener,
                                     Runnable copyPayload,
                                     Runnable savePng,
                                     DeleteListener deleteListener) {
        Dialog dialog = swipeDismissDialog(activity);
        LinearLayout root = root(activity);

        TextView header = editableTitle(activity, node.displayName());
        header.setOnClickListener(v -> showInput(activity, "名前を編集", "表示名", header.getText().toString(), false, "保存", text -> {
            if (text.isBlank()) return;
            header.setText(text);
            if (renameListener != null) renameListener.onRename(text);
        }));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46)));

        int square = Math.max(dp(activity, 180), activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 72));
        FrameLayout frame = buildQrFrame(activity, node.url);
        LinearLayout.LayoutParams frameLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, square);
        frameLp.setMargins(0, dp(activity, 4), 0, dp(activity, 12));
        root.addView(frame, frameLp);

        addFieldLabel(activity, root, "内容");
        LinearLayout payloadRow = new LinearLayout(activity);
        payloadRow.setOrientation(LinearLayout.HORIZONTAL);
        payloadRow.setGravity(Gravity.TOP);
        TextView payload = new TextView(activity);
        payload.setText(empty(node.url) ? "—" : node.url);
        payload.setTextColor(TEXT);
        payload.setTextSize(14);
        payload.setMaxLines(4);
        payload.setEllipsize(TextUtils.TruncateAt.END);
        payload.setTextIsSelectable(true);
        payload.setPadding(dp(activity, 2), 0, dp(activity, 4), dp(activity, 8));
        payloadRow.addView(payload, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView copy = thinCapsule(activity, "コピー", D_GRAY);
        copy.setOnClickListener(v -> { if (copyPayload != null) copyPayload.run(); });
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(dp(activity, 66), dp(activity, 30));
        copyLp.setMargins(dp(activity, 8), 0, 0, 0);
        payloadRow.addView(copy, copyLp);
        root.addView(payloadRow, lpMatchWrap(0, 2, 0, 0));

        DateFormat f = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        root.addView(compactField(activity, "登録", f.format(new Date(node.createdAt))), lpMatchWrap(4, 4, 0, 0));

        LinearLayout bottom = bottomRow(activity);
        TextView delete = action(activity, "削除", L_RED);
        delete.setGravity(Gravity.CENTER);
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            if (deleteListener != null) deleteListener.onDelete();
        });
        bottom.addView(delete, new LinearLayout.LayoutParams(dp(activity, 84), dp(activity, 44)));
        Space gap = new Space(activity);
        bottom.addView(gap, new LinearLayout.LayoutParams(dp(activity, 8), 1));
        TextView save = action(activity, "PNG保存", L_BLUE);
        save.setGravity(Gravity.CENTER);
        save.setOnClickListener(v -> { if (savePng != null) savePng.run(); });
        bottom.addView(save, new LinearLayout.LayoutParams(dp(activity, 112), dp(activity, 44)));
        addFlexibleSpacer(activity, bottom);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        bottom.addView(close, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));
        root.addView(bottom, lpMatchWrap(10, 0, 0, 0));

        dialog.setContentView(root);
        show(activity, dialog);
    }

    private static FrameLayout buildQrFrame(Activity activity, String value) {
        FrameLayout frame = new FrameLayout(activity);
        frame.setBackground(roundRect(activity, D_GRAY, 12));
        frame.setClipToOutline(true);
        Bitmap bitmap = QrUtils.render(value, 1200);
        if (bitmap != null) {
            ImageView image = new ImageView(activity);
            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            image.setPadding(dp(activity, 14), dp(activity, 14), dp(activity, 14), dp(activity, 14));
            image.setImageBitmap(bitmap);
            frame.addView(image, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            TextView unavailable = new TextView(activity);
            unavailable.setText("QRを表示できません");
            unavailable.setTextColor(ICON);
            unavailable.setGravity(Gravity.CENTER);
            frame.addView(unavailable, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        return frame;
    }

    public static BookmarkDetailsHandle showBookmarkDetails(Activity activity, BookmarkNode node,
                                           RenameListener renameListener,
                                           ThumbnailRefreshListener thumbnailRefreshListener,
                                           DeleteListener deleteListener,
                                           CopyListener copyListener,
                                           OfflineActionsListener offlineActionsListener) {
        Dialog dialog = swipeDismissDialog(activity);
        LinearLayout root = root(activity);

        TextView header = editableTitle(activity, node.displayName());
        header.setOnClickListener(v -> showInput(activity, "名前を編集", "表示名", header.getText().toString(), false, "保存", text -> {
            if (text.isBlank()) return;
            header.setText(text);
            if (renameListener != null) renameListener.onRename(text);
        }));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46)));

        int square = Math.max(dp(activity, 180), activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 72));
        FrameLayout thumbnail = buildThumbnail(activity, node.screenshotPath);
        LinearLayout.LayoutParams thumbLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, square);
        thumbLp.setMargins(0, dp(activity, 4), 0, dp(activity, 14));
        root.addView(thumbnail, thumbLp);
        TextView siteNameValue = addFieldValue(activity, root, "サイト名", node.siteNameOrFallback());
        TextView pageTitleValue = addFieldValue(activity, root, "ページタイトル", empty(node.pageTitle) ? "—" : node.pageTitle);
        TextView urlValue = addUrlFieldValue(activity, root, empty(node.url) ? "—" : node.url, empty(node.url) ? null : () -> {
            ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard == null) return;
            clipboard.setPrimaryClip(ClipData.newPlainText("URL", node.url));
            Toast.makeText(activity, "URLをコピーしました", Toast.LENGTH_SHORT).show();
        });

        thumbnail.setOnClickListener(v -> {
            if (thumbnailRefreshListener == null) return;
            setThumbnailLoading(thumbnail, true);
            thumbnailRefreshListener.onRefresh((updatedNode, success) -> activity.runOnUiThread(() -> {
                setThumbnailLoading(thumbnail, false);
                if (success && updatedNode != null) {
                    setThumbnailImage(activity, thumbnail, updatedNode.screenshotPath);
                    header.setText(updatedNode.displayName());
                    siteNameValue.setText(updatedNode.siteNameOrFallback());
                    pageTitleValue.setText(empty(updatedNode.pageTitle) ? "—" : updatedNode.pageTitle);
                }
            }));
        });

        GoogleMapsModule.attachThumbnailScaleGestureIfHandled(activity, thumbnail, node,
                new GoogleMapsModule.ThumbnailScaleListener() {
                    @Override
                    public void onPreviewScale(float relativeScale) {
                        activity.runOnUiThread(() -> setThumbnailPreviewScale(thumbnail, relativeScale));
                    }

                    @Override
                    public void onRenderStarted() {
                        // Deliberately keep the currently transformed map visible. Showing the
                        // loading spinner here made the pinch feel like a stop-and-redraw action.
                    }

                    @Override
                    public void onRenderComplete(boolean success, boolean requiresCapture, String screenshotPath) {
                        activity.runOnUiThread(() -> {
                            if (success) {
                                setThumbnailImage(activity, thumbnail, screenshotPath);
                                setThumbnailPreviewScale(thumbnail, 1f);
                                setThumbnailLoading(thumbnail, false);
                                return;
                            }
                            if (!requiresCapture || thumbnailRefreshListener == null) {
                                setThumbnailPreviewScale(thumbnail, 1f);
                                setThumbnailLoading(thumbnail, false);
                                return;
                            }
                            // Older Maps bookmarks may not yet have isolated coordinate state.
                            // Resolve it once, while keeping the transformed preview on screen.
                            setThumbnailLoading(thumbnail, true);
                            thumbnailRefreshListener.onRefresh((updatedNode, refreshSuccess) -> activity.runOnUiThread(() -> {
                                setThumbnailLoading(thumbnail, false);
                                setThumbnailPreviewScale(thumbnail, 1f);
                                if (refreshSuccess && updatedNode != null) {
                                    setThumbnailImage(activity, thumbnail, updatedNode.screenshotPath);
                                    header.setText(updatedNode.displayName());
                                    siteNameValue.setText(updatedNode.siteNameOrFallback());
                                    pageTitleValue.setText(empty(updatedNode.pageTitle) ? "—" : updatedNode.pageTitle);
                                                }
                            }));
                        });
                    }
                });

        DateFormat f = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        LinearLayout dates = new LinearLayout(activity);
        dates.setOrientation(LinearLayout.HORIZONTAL);
        dates.setGravity(Gravity.CENTER_VERTICAL);
        dates.addView(compactField(activity, "ブックマーク", f.format(new Date(node.createdAt))),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        dates.addView(compactField(activity, "最終アクセス",
                        node.lastAccessedAt == null ? "未アクセス" : f.format(new Date(node.lastAccessedAt))),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(dates, lpMatchWrap(6, 4, 0, 0));

        boolean specialWeb = GoogleMapsModule.handles(node.url) || YouTubeModule.handles(node.url);
        LinearLayout offlineRow = null;
        if (!specialWeb) {
            addFieldLabel(activity, root, "オフラインビューイング");
            offlineRow = new LinearLayout(activity);
            offlineRow.setOrientation(LinearLayout.HORIZONTAL);
            offlineRow.setGravity(Gravity.CENTER_VERTICAL);
            offlineRow.setClipChildren(false);
            offlineRow.setClipToPadding(false);
            offlineRow.setPadding(dp(activity, 2), dp(activity, 3), dp(activity, 2), dp(activity, 5));
            renderOfflineActions(activity, offlineRow, node.offlineSavedAt != null, offlineActionsListener);
            root.addView(offlineRow, lpMatchWrap(0, 0, 0, 2));
        }

        LinearLayout bottom = bottomRow(activity);
        TextView delete = action(activity, "削除", L_RED);
        delete.setGravity(Gravity.CENTER);
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            if (deleteListener != null) deleteListener.onDelete();
        });
        bottom.addView(delete, new LinearLayout.LayoutParams(dp(activity, 84), dp(activity, 44)));

        Space leftGap = new Space(activity);
        bottom.addView(leftGap, new LinearLayout.LayoutParams(dp(activity, 8), 1));
        TextView copy = action(activity, "複製", L_BLUE);
        copy.setGravity(Gravity.CENTER);
        copy.setOnClickListener(v -> {
            dialog.dismiss();
            if (copyListener != null) copyListener.onCopy();
        });
        bottom.addView(copy, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));

        addFlexibleSpacer(activity, bottom);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        bottom.addView(close, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));
        root.addView(bottom, lpMatchWrap(12, 0, 0, 0));

        dialog.setContentView(root);
        show(activity, dialog);
        return new BookmarkDetailsHandle(activity, dialog, offlineRow, offlineActionsListener);
    }


    public static void showAppDetails(Activity activity, BookmarkNode node,
                                      RenameListener renameListener,
                                      DeleteListener deleteListener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);

        TextView header = editableTitle(activity, node.displayName());
        header.setOnClickListener(v -> showInput(activity, "名前を編集", "表示名", header.getText().toString(), false, "保存", text -> {
            if (text.isBlank()) return;
            header.setText(text);
            if (renameListener != null) renameListener.onRename(text);
        }));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46)));

        addField(activity, root, "パッケージ", empty(node.url) ? "—" : node.url);

        DateFormat f = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        LinearLayout dates = new LinearLayout(activity);
        dates.setOrientation(LinearLayout.HORIZONTAL);
        dates.setGravity(Gravity.CENTER_VERTICAL);
        dates.addView(compactField(activity, "追加", f.format(new Date(node.createdAt))),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        dates.addView(compactField(activity, "最終アクセス",
                        node.lastAccessedAt == null ? "未起動" : f.format(new Date(node.lastAccessedAt))),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(dates, lpMatchWrap(6, 4, 0, 0));

        LinearLayout bottom = bottomRow(activity);
        TextView delete = action(activity, "削除", L_RED);
        delete.setGravity(Gravity.CENTER);
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            if (deleteListener != null) deleteListener.onDelete();
        });
        bottom.addView(delete, new LinearLayout.LayoutParams(dp(activity, 84), dp(activity, 44)));
        addFlexibleSpacer(activity, bottom);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        bottom.addView(close, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));
        root.addView(bottom, lpMatchWrap(12, 0, 0, 0));

        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showFolderDetails(Activity activity, BookmarkNode node, int childCount,
                                         RenameListener renameListener,
                                         FolderDeleteListener deleteListener) {
        Dialog dialog = swipeDismissDialog(activity);
        LinearLayout root = root(activity);

        TextView header = editableTitle(activity, node.displayName());
        header.setOnClickListener(v -> showInput(activity, "フォルダ名", "フォルダ名", header.getText().toString(), false, "保存", text -> {
            if (text.isBlank()) return;
            header.setText(text);
            if (renameListener != null) renameListener.onRename(text);
        }));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46)));

        addField(activity, root, "内容", childCount + "件");
        DateFormat f = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        addField(activity, root, "作成", f.format(new Date(node.createdAt)));

        final boolean[] protect = {true};
        LinearLayout protectionRow = new LinearLayout(activity);
        protectionRow.setOrientation(LinearLayout.HORIZONTAL);
        protectionRow.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        ProtectionToggle toggle = new ProtectionToggle(activity, true);
        toggle.setOnStateChanged(enabled -> protect[0] = enabled);
        protectionRow.addView(toggle, new LinearLayout.LayoutParams(dp(activity, 52), dp(activity, 30)));
        TextView protectLabel = new TextView(activity);
        protectLabel.setText("中身を保護");
        protectLabel.setTextColor(TEXT);
        protectLabel.setTextSize(14);
        protectLabel.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(activity, 36));
        labelLp.setMargins(dp(activity, 8), 0, 0, 0);
        protectionRow.addView(protectLabel, labelLp);
        root.addView(protectionRow, lpMatchWrap(8, 6, 0, 0));

        LinearLayout bottom = bottomRow(activity);
        TextView delete = action(activity, "削除", L_RED);
        delete.setGravity(Gravity.CENTER);
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            if (deleteListener != null) deleteListener.onDelete(protect[0]);
        });
        bottom.addView(delete, new LinearLayout.LayoutParams(dp(activity, 84), dp(activity, 44)));
        addFlexibleSpacer(activity, bottom);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        bottom.addView(close, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));
        root.addView(bottom, lpMatchWrap(2, 0, 0, 0));

        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showInput(Activity activity, String title, String hint, String initial,
                                 boolean uriInput, String positiveLabel, TextListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);

        EditText input = new EditText(activity);
        input.setSingleLine(true);
        input.setText(initial == null ? "" : initial);
        input.setHint(hint);
        input.setTextColor(TEXT);
        input.setHintTextColor(ICON);
        input.setTextSize(16);
        input.setPadding(dp(activity, 14), 0, dp(activity, 14), 0);
        input.setBackground(roundRect(activity, GRAY, 12));
        input.setInputType(uriInput
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 52)));

        LinearLayout buttons = buttonRow(activity);
        TextView cancel = action(activity, "キャンセル", GRAY);
        cancel.setGravity(Gravity.CENTER);
        cancel.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(cancel, new LinearLayout.LayoutParams(dp(activity, 112), dp(activity, 46)));

        Space gap = new Space(activity);
        buttons.addView(gap, new LinearLayout.LayoutParams(dp(activity, 8), 1));

        TextView ok = action(activity, positiveLabel, L_BLUE);
        ok.setGravity(Gravity.CENTER);
        ok.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            dialog.dismiss();
            listener.onText(text);
        });
        buttons.addView(ok, new LinearLayout.LayoutParams(dp(activity, 96), dp(activity, 46)));
        root.addView(buttons, lpMatchWrap(14, 12, 0, 0));

        dialog.setContentView(root);
        dialog.setOnShowListener(d -> {
            input.requestFocus();
            if (initial != null && !initial.isBlank()) input.selectAll();
            Window w = dialog.getWindow();
            if (w != null) w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        });
        show(activity, dialog);
    }

    private static FrameLayout buildThumbnail(Activity activity, String path) {
        FrameLayout frame = new FrameLayout(activity);
        frame.setBackground(roundRect(activity, GRAY, 12));
        frame.setClipToOutline(true);

        ImageView image = new ImageView(activity);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setTag("thumbnail_image");
        frame.addView(image, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView placeholder = new TextView(activity);
        placeholder.setText("サムネイル未取得\nタップで取得");
        placeholder.setTextColor(ICON);
        placeholder.setTextSize(14);
        placeholder.setGravity(Gravity.CENTER);
        placeholder.setTag("thumbnail_placeholder");
        frame.addView(placeholder, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ProgressBar progress = new ProgressBar(activity);
        progress.setIndeterminate(true);
        if (progress.getIndeterminateDrawable() != null) {
            progress.getIndeterminateDrawable().setTint(L_GRAY);
        }
        progress.setVisibility(View.GONE);
        progress.setTag("thumbnail_progress");
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(activity, 42), dp(activity, 42), Gravity.CENTER);
        frame.addView(progress, pp);

        setThumbnailImage(activity, frame, path);
        return frame;
    }

    private static void setThumbnailImage(Activity activity, FrameLayout frame, String path) {
        ImageView image = findTagged(frame, "thumbnail_image", ImageView.class);
        TextView placeholder = findTagged(frame, "thumbnail_placeholder", TextView.class);
        Bitmap bitmap = null;
        if (path != null && !path.isBlank()) {
            File file = new File(path);
            if (file.isFile()) bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
        }
        if (bitmap != null) {
            image.setImageBitmap(bitmap);
            image.setVisibility(View.VISIBLE);
            placeholder.setVisibility(View.GONE);
        } else {
            image.setImageDrawable(null);
            image.setVisibility(View.GONE);
            placeholder.setVisibility(View.VISIBLE);
        }
    }

    private static void setThumbnailPreviewScale(FrameLayout frame, float scale) {
        ImageView image = findTagged(frame, "thumbnail_image", ImageView.class);
        float safe = Float.isNaN(scale) || Float.isInfinite(scale) ? 1f : Math.max(0.35f, Math.min(3f, scale));
        if (image.getWidth() > 0 && image.getHeight() > 0) {
            image.setPivotX(image.getWidth() / 2f);
            image.setPivotY(image.getHeight() / 2f);
        }
        image.setScaleX(safe);
        image.setScaleY(safe);
    }

    private static void setThumbnailLoading(FrameLayout frame, boolean loading) {
        ProgressBar progress = findTagged(frame, "thumbnail_progress", ProgressBar.class);
        TextView placeholder = findTagged(frame, "thumbnail_placeholder", TextView.class);
        ImageView image = findTagged(frame, "thumbnail_image", ImageView.class);
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        if (loading) {
            // While fetching, show only the N-light-gray seek circle.
            placeholder.setVisibility(View.GONE);
        } else if (image.getVisibility() != View.VISIBLE) {
            placeholder.setVisibility(View.VISIBLE);
        }
        frame.setEnabled(!loading);
    }

    @SuppressWarnings("unchecked")
    private static <T extends View> T findTagged(ViewGroup root, String tag, Class<T> type) {
        for (int i = 0; i < root.getChildCount(); i++) {
            View child = root.getChildAt(i);
            if (tag.equals(child.getTag()) && type.isInstance(child)) return (T) child;
        }
        throw new IllegalStateException("missing view " + tag);
    }

    private static View compactField(Activity activity, String label, String value) {
        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(activity, 2), dp(activity, 2), dp(activity, 8), dp(activity, 4));
        TextView l = new TextView(activity);
        l.setText(label);
        l.setTextColor(ICON);
        l.setTextSize(12);
        box.addView(l, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView v = new TextView(activity);
        v.setText(value);
        v.setTextColor(TEXT);
        v.setTextSize(13);
        v.setSingleLine(true);
        box.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private static TextView editableTitle(Activity activity, String title) {
        TextView tv = new TextView(activity);
        tv.setText(title);
        tv.setTextColor(TEXT);
        tv.setTextSize(20);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setClickable(true);
        return tv;
    }

    private static void addField(Activity activity, LinearLayout root, String label, String value) {
        addFieldValue(activity, root, label, value);
    }

    private static void addFieldLabel(Activity activity, LinearLayout root, String label) {
        TextView labelView = new TextView(activity);
        labelView.setText(label);
        labelView.setTextColor(ICON);
        labelView.setTextSize(12);
        root.addView(labelView, lpMatchWrap(4, 2, 2, 2));
    }

    private static TextView addFieldValue(Activity activity, LinearLayout root, String label, String value) {
        addFieldLabel(activity, root, label);
        TextView valueView = new TextView(activity);
        valueView.setText(value);
        valueView.setTextColor(TEXT);
        valueView.setTextSize(15);
        valueView.setTextIsSelectable(true);
        valueView.setPadding(dp(activity, 2), 0, dp(activity, 2), dp(activity, 8));
        root.addView(valueView, lpMatchWrap(0, 4, 0, 0));
        return valueView;
    }

    private static TextView addUrlFieldValue(Activity activity, LinearLayout root, String value, Runnable copyAction) {
        addFieldLabel(activity, root, "URL");

        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setClipChildren(false);
        row.setClipToPadding(false);
        row.setPadding(0, dp(activity, 4), 0, dp(activity, 7));
        row.setMinimumHeight(dp(activity, 50));

        TextView valueView = new TextView(activity);
        valueView.setText(value);
        valueView.setTextColor(TEXT);
        valueView.setTextSize(15);
        valueView.setMaxLines(2);
        valueView.setEllipsize(TextUtils.TruncateAt.END);
        valueView.setHorizontallyScrolling(false);
        valueView.setTextIsSelectable(copyAction == null);
        valueView.setPadding(dp(activity, 2), 0, dp(activity, 2), 0);
        if (copyAction != null) {
            valueView.setClickable(true);
            valueView.setOnClickListener(v -> copyAction.run());
        }
        row.addView(valueView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (copyAction != null) {
            TextView copy = thinCapsule(activity, "コピー", D_GRAY);
            copy.setOnClickListener(v -> copyAction.run());
            LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(dp(activity, 66), dp(activity, 30));
            copyLp.gravity = Gravity.TOP;
            copyLp.setMargins(dp(activity, 8), 0, 0, 0);
            row.addView(copy, copyLp);
        }

        root.addView(row, lpMatchWrap(0, 2, 0, 0));
        return valueView;
    }

    private static void renderOfflineActions(Activity activity, LinearLayout row, boolean saved,
                                             OfflineActionsListener listener) {
        row.removeAllViews();
        if (!saved) {
            TextView save = thinCapsule(activity, "保存", ORANGE);
            save.setOnClickListener(v -> {
                if (listener != null) listener.onSaveOrUpdate();
            });
            row.addView(save, new LinearLayout.LayoutParams(dp(activity, 68), dp(activity, 30)));
            return;
        }

        TextView open = thinCapsule(activity, "表示", D_GRAY);
        open.setOnClickListener(v -> {
            if (listener != null) listener.onOpen();
        });
        row.addView(open, new LinearLayout.LayoutParams(dp(activity, 68), dp(activity, 30)));

        TextView remove = thinCapsule(activity, "削除", L_RED);
        remove.setOnClickListener(v -> {
            if (listener != null) listener.onDelete();
        });
        LinearLayout.LayoutParams removeLp = new LinearLayout.LayoutParams(dp(activity, 68), dp(activity, 30));
        removeLp.setMargins(dp(activity, 7), 0, 0, 0);
        row.addView(remove, removeLp);
    }

    private static TextView thinCapsule(Activity activity, String text, int background) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(TEXT);
        tv.setTextSize(13);
        tv.setSingleLine(true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(activity, 12), 0, dp(activity, 12), 0);
        tv.setBackground(roundRect(activity, background, 999));
        tv.setClickable(true);
        tv.setFocusable(true);
        return tv;
    }

    private static void addCloseRow(Activity activity, LinearLayout root, Dialog dialog) {
        LinearLayout buttons = buttonRow(activity);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(close, new LinearLayout.LayoutParams(dp(activity, 96), dp(activity, 46)));
        root.addView(buttons, lpMatchWrap(10, 8, 0, 0));
    }

    /**
     * Bookmark/folder property sheet gesture: a deliberate vertical swipe in either
     * direction dismisses the dialog. Multi-touch is ignored so Google Maps pinch
     * gestures never accidentally close the sheet.
     */
    private static Dialog swipeDismissDialog(Activity activity) {
        Dialog dialog = new Dialog(activity) {
            private float downX;
            private float downY;
            private boolean tracking;
            private boolean multiTouch;

            @Override
            public boolean dispatchTouchEvent(MotionEvent event) {
                int action = event.getActionMasked();
                if (action == MotionEvent.ACTION_DOWN) {
                    downX = event.getX();
                    downY = event.getY();
                    tracking = true;
                    multiTouch = false;
                } else if (action == MotionEvent.ACTION_POINTER_DOWN || event.getPointerCount() > 1) {
                    multiTouch = true;
                } else if (action == MotionEvent.ACTION_UP && tracking) {
                    float dx = event.getX() - downX;
                    float dy = event.getY() - downY;
                    tracking = false;
                    float vertical = Math.abs(dy);
                    float horizontal = Math.abs(dx);
                    if (!multiTouch
                            && vertical >= dp(activity, 72)
                            && vertical >= horizontal * 1.35f) {
                        dismiss();
                        return true;
                    }
                } else if (action == MotionEvent.ACTION_CANCEL) {
                    tracking = false;
                    multiTouch = false;
                }
                return super.dispatchTouchEvent(event);
            }
        };
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        return dialog;
    }

    private static Dialog baseDialog(Activity activity) {
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        return dialog;
    }

    private static LinearLayout root(Activity activity) {
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(activity, 18), dp(activity, 18), dp(activity, 18), dp(activity, 18));
        root.setBackground(roundRect(activity, GRAY, 18));
        return root;
    }

    private static void addTitle(Activity activity, LinearLayout root, String title, int gravity) {
        TextView tv = new TextView(activity);
        tv.setText(title);
        tv.setTextColor(TEXT);
        tv.setTextSize(20);
        tv.setGravity(gravity);
        root.addView(tv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46)));
    }

    private static TextView action(Activity activity, String text, int background) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(TEXT);
        tv.setTextSize(16);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(dp(activity, 14), 0, dp(activity, 14), 0);
        int resolvedBackground = background == GRAY ? L_BLUE : background;
        // Buttons are pill-shaped; menu rows use showPlainMenu() and remain backgroundless.
        tv.setBackground(roundRect(activity, resolvedBackground, 999));
        return tv;
    }

    private static LinearLayout buttonRow(Activity activity) {
        LinearLayout row = new LinearLayout(activity);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        return row;
    }

    private static LinearLayout bottomRow(Activity activity) {
        LinearLayout row = new LinearLayout(activity);
        row.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private static void addFlexibleSpacer(Activity activity, LinearLayout row) {
        Space spacer = new Space(activity);
        row.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
    }


    private static void showDeleteConfirmationWindow(Activity activity, Dialog dialog) {
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams();
            p.copyFrom(w.getAttributes());
            int screen = activity.getResources().getDisplayMetrics().widthPixels;
            p.width = Math.min(screen - dp(activity, 36), dp(activity, 360));
            p.height = WindowManager.LayoutParams.WRAP_CONTENT;
            p.gravity = Gravity.CENTER;
            w.setAttributes(p);
        }
    }

    private static void show(Activity activity, Dialog dialog) {
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams();
            p.copyFrom(w.getAttributes());
            p.width = activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 36);
            p.height = WindowManager.LayoutParams.WRAP_CONTENT;
            p.gravity = Gravity.CENTER;
            w.setAttributes(p);
        }
    }

    private static GradientDrawable roundRect(Activity activity, int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(activity, radiusDp));
        return d;
    }

    private static GradientDrawable oval(Activity activity, int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    private static LinearLayout.LayoutParams lpMatchWrap(int top, int bottom, int left, int right) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(left, top, right, bottom);
        return lp;
    }

    private static int dp(Activity activity, int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    private static boolean empty(String s) { return s == null || s.isBlank(); }

    private interface StateListener { void onStateChanged(boolean enabled); }

    private static final class ProtectionToggle extends FrameLayout {
        private final Activity activity;
        private final View thumb;
        private boolean enabled;
        private StateListener listener;

        ProtectionToggle(Activity activity, boolean initial) {
            super(activity);
            this.activity = activity;
            setClickable(true);
            thumb = new View(activity);
            addView(thumb);
            setOnClickListener(v -> setEnabledState(!enabled, true));
            setEnabledState(initial, false);
        }

        void setOnStateChanged(StateListener listener) {
            this.listener = listener;
        }

        private void setEnabledState(boolean value, boolean notify) {
            enabled = value;
            setBackground(roundRect(activity, enabled ? ORANGE : GRAY, 18));
            thumb.setBackground(oval(activity, ICON));
            LayoutParams lp = new LayoutParams(dp(activity, 22), dp(activity, 22), Gravity.CENTER_VERTICAL | (enabled ? Gravity.END : Gravity.START));
            lp.setMargins(dp(activity, 4), dp(activity, 4), dp(activity, 4), dp(activity, 4));
            thumb.setLayoutParams(lp);
            if (notify && listener != null) listener.onStateChanged(enabled);
        }
    }
}
