package com.cmyk.bookmarkslauncher.ui;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import java.io.File;
import java.text.DateFormat;
import java.util.Date;

public final class NDialog {
    public interface ChoiceListener { void onChoice(int which); }
    public interface TextListener { void onText(String text); }
    public interface DeleteListener { void onDelete(); }
    public interface FolderDeleteListener { void onDelete(boolean protectContents); }

    private static final int D_GRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int L_GRAY = 0xFF656060;
    private static final int L_BLUE = 0xFF445577;
    private static final int L_RED = 0xFF662211;
    private static final int ORANGE = 0xFF775500;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int ICON = 0xFFA9A999;

    private NDialog() {}

    public static void showChoices(Activity activity, String title, String[] items, int destructiveIndex, ChoiceListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);
        for (int i = 0; i < items.length; i++) {
            final int index = i;
            TextView row = action(activity, items[i], i == destructiveIndex ? L_RED : GRAY);
            row.setOnClickListener(v -> {
                dialog.dismiss();
                listener.onChoice(index);
            });
            root.addView(row, lpMatchWrap(0, 4, 0, 4));
        }
        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showMessage(Activity activity, String title, String message) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);

        ScrollView scroll = new ScrollView(activity);
        TextView body = new TextView(activity);
        body.setText(message);
        body.setTextColor(TEXT);
        body.setTextSize(15);
        body.setLineSpacing(0f, 1.12f);
        body.setPadding(dp(activity, 4), dp(activity, 2), dp(activity, 4), dp(activity, 12));
        scroll.addView(body, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 280)));

        addCloseRow(activity, root, dialog);
        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showBookmarkDetails(Activity activity, BookmarkNode node, DeleteListener deleteListener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, node.title == null ? "ブックマーク" : node.title, Gravity.CENTER);

        View thumbnail = buildThumbnail(activity, node.screenshotPath);
        LinearLayout.LayoutParams thumbLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 180));
        thumbLp.setMargins(0, dp(activity, 4), 0, dp(activity, 14));
        root.addView(thumbnail, thumbLp);

        addField(activity, root, "サイト名", node.title == null ? "—" : node.title);
        addField(activity, root, "URL", node.url == null ? "—" : node.url);

        DateFormat f = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        addField(activity, root, "ブックマーク日", f.format(new Date(node.createdAt)));
        addField(activity, root, "最終アクセス日",
                node.lastAccessedAt == null ? "未アクセス" : f.format(new Date(node.lastAccessedAt)));
        addField(activity, root, "オフラインビューイング",
                node.offlineSavedAt == null ? "未設定" : "保存済み  " + f.format(new Date(node.offlineSavedAt)));

        LinearLayout bottom = bottomRow(activity);
        TextView delete = action(activity, "削除", L_RED);
        delete.setGravity(Gravity.CENTER);
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            if (deleteListener != null) deleteListener.onDelete();
        });
        bottom.addView(delete, new LinearLayout.LayoutParams(dp(activity, 84), dp(activity, 44)));
        addFlexibleSpacer(activity, bottom);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        bottom.addView(close, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));
        root.addView(bottom, lpMatchWrap(12, 0, 0, 0));

        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showFolderDetails(Activity activity, BookmarkNode node, int childCount,
                                         FolderDeleteListener deleteListener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, node.title == null ? "フォルダ" : node.title, Gravity.CENTER);

        addField(activity, root, "フォルダ名", node.title == null ? "—" : node.title);
        addField(activity, root, "内容", childCount + "件");
        DateFormat f = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        addField(activity, root, "作成日", f.format(new Date(node.createdAt)));

        final boolean[] protect = {true};
        LinearLayout bottom = bottomRow(activity);

        TextView delete = action(activity, "削除", L_RED);
        delete.setGravity(Gravity.CENTER);
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            if (deleteListener != null) deleteListener.onDelete(protect[0]);
        });
        bottom.addView(delete, new LinearLayout.LayoutParams(dp(activity, 84), dp(activity, 44)));

        Space gap = new Space(activity);
        bottom.addView(gap, new LinearLayout.LayoutParams(dp(activity, 10), 1));

        TextView protectLabel = new TextView(activity);
        protectLabel.setText("中身を保護");
        protectLabel.setTextColor(TEXT);
        protectLabel.setTextSize(13);
        protectLabel.setGravity(Gravity.CENTER_VERTICAL);
        bottom.addView(protectLabel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(activity, 44)));

        Space smallGap = new Space(activity);
        bottom.addView(smallGap, new LinearLayout.LayoutParams(dp(activity, 7), 1));

        ProtectionToggle toggle = new ProtectionToggle(activity, true);
        toggle.setOnStateChanged(enabled -> protect[0] = enabled);
        bottom.addView(toggle, new LinearLayout.LayoutParams(dp(activity, 52), dp(activity, 30)));

        addFlexibleSpacer(activity, bottom);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        bottom.addView(close, new LinearLayout.LayoutParams(dp(activity, 92), dp(activity, 44)));

        root.addView(bottom, lpMatchWrap(12, 0, 0, 0));
        dialog.setContentView(root);
        show(activity, dialog);
    }

    public static void showInput(Activity activity, String title, String hint, String initial,
                                 boolean uriInput, String positiveLabel, TextListener listener) {
        Dialog dialog = baseDialog(activity);
        LinearLayout root = root(activity);
        addTitle(activity, root, title, Gravity.CENTER_VERTICAL);

        EditText input = new EditText(activity);
        input.setSingleLine(true);
        input.setText(initial == null ? "" : initial);
        input.setHint(hint);
        input.setTextColor(TEXT);
        input.setHintTextColor(ICON);
        input.setTextSize(16);
        input.setPadding(dp(activity, 14), 0, dp(activity, 14), 0);
        input.setBackground(roundRect(activity, GRAY, 12));
        input.setInputType(uriInput
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 52)));

        LinearLayout buttons = buttonRow(activity);
        TextView cancel = action(activity, "キャンセル", GRAY);
        cancel.setGravity(Gravity.CENTER);
        cancel.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(cancel, new LinearLayout.LayoutParams(dp(activity, 112), dp(activity, 46)));

        Space gap = new Space(activity);
        buttons.addView(gap, new LinearLayout.LayoutParams(dp(activity, 8), 1));

        TextView ok = action(activity, positiveLabel, L_BLUE);
        ok.setGravity(Gravity.CENTER);
        ok.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            dialog.dismiss();
            listener.onText(text);
        });
        buttons.addView(ok, new LinearLayout.LayoutParams(dp(activity, 96), dp(activity, 46)));
        root.addView(buttons, lpMatchWrap(14, 12, 0, 0));

        dialog.setContentView(root);
        dialog.setOnShowListener(d -> {
            input.requestFocus();
            Window w = dialog.getWindow();
            if (w != null) w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        });
        show(activity, dialog);
    }

    private static View buildThumbnail(Activity activity, String path) {
        if (path != null && !path.isBlank()) {
            File file = new File(path);
            if (file.isFile()) {
                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                if (bitmap != null) {
                    ImageView image = new ImageView(activity);
                    image.setImageBitmap(bitmap);
                    image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    image.setBackground(roundRect(activity, GRAY, 12));
                    image.setClipToOutline(true);
                    return image;
                }
            }
        }

        TextView placeholder = new TextView(activity);
        placeholder.setText("サムネイル未取得");
        placeholder.setTextColor(ICON);
        placeholder.setTextSize(14);
        placeholder.setGravity(Gravity.CENTER);
        placeholder.setBackground(roundRect(activity, GRAY, 12));
        return placeholder;
    }

    private static void addField(Activity activity, LinearLayout root, String label, String value) {
        TextView labelView = new TextView(activity);
        labelView.setText(label);
        labelView.setTextColor(ICON);
        labelView.setTextSize(12);
        root.addView(labelView, lpMatchWrap(4, 2, 2, 2));

        TextView valueView = new TextView(activity);
        valueView.setText(value);
        valueView.setTextColor(TEXT);
        valueView.setTextSize(15);
        valueView.setTextIsSelectable(true);
        valueView.setPadding(dp(activity, 2), 0, dp(activity, 2), dp(activity, 8));
        root.addView(valueView, lpMatchWrap(0, 4, 0, 0));
    }

    private static void addCloseRow(Activity activity, LinearLayout root, Dialog dialog) {
        LinearLayout buttons = buttonRow(activity);
        TextView close = action(activity, "閉じる", GRAY);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(close, new LinearLayout.LayoutParams(dp(activity, 96), dp(activity, 46)));
        root.addView(buttons, lpMatchWrap(10, 8, 0, 0));
    }

    private static Dialog baseDialog(Activity activity) {
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        return dialog;
    }

    private static LinearLayout root(Activity activity) {
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(activity, 18), dp(activity, 18), dp(activity, 18), dp(activity, 18));
        root.setBackground(roundRect(activity, D_GRAY, 18));
        return root;
    }

    private static void addTitle(Activity activity, LinearLayout root, String title, int gravity) {
        TextView tv = new TextView(activity);
        tv.setText(title);
        tv.setTextColor(TEXT);
        tv.setTextSize(20);
        tv.setGravity(gravity);
        root.addView(tv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46)));
    }

    private static TextView action(Activity activity, String text, int background) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(TEXT);
        tv.setTextSize(16);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(dp(activity, 14), 0, dp(activity, 14), 0);
        tv.setBackground(roundRect(activity, background, 12));
        return tv;
    }

    private static LinearLayout buttonRow(Activity activity) {
        LinearLayout row = new LinearLayout(activity);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        return row;
    }

    private static LinearLayout bottomRow(Activity activity) {
        LinearLayout row = new LinearLayout(activity);
        row.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private static void addFlexibleSpacer(Activity activity, LinearLayout row) {
        Space spacer = new Space(activity);
        row.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
    }

    private static void show(Activity activity, Dialog dialog) {
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams();
            p.copyFrom(w.getAttributes());
            p.width = activity.getResources().getDisplayMetrics().widthPixels - dp(activity, 36);
            p.height = WindowManager.LayoutParams.WRAP_CONTENT;
            p.gravity = Gravity.CENTER;
            w.setAttributes(p);
        }
    }

    private static GradientDrawable roundRect(Activity activity, int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(activity, radiusDp));
        return d;
    }

    private static GradientDrawable oval(Activity activity, int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    private static LinearLayout.LayoutParams lpMatchWrap(int top, int bottom, int left, int right) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(left, top, right, bottom);
        return lp;
    }

    private static int dp(Activity activity, int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    private interface StateListener { void onStateChanged(boolean enabled); }

    private static final class ProtectionToggle extends FrameLayout {
        private final Activity activity;
        private final View thumb;
        private boolean enabled;
        private StateListener listener;

        ProtectionToggle(Activity activity, boolean initial) {
            super(activity);
            this.activity = activity;
            setClickable(true);
            thumb = new View(activity);
            addView(thumb);
            setOnClickListener(v -> setEnabledState(!enabled, true));
            setEnabledState(initial, false);
        }

        void setOnStateChanged(StateListener listener) {
            this.listener = listener;
        }

        private void setEnabledState(boolean value, boolean notify) {
            enabled = value;
            setBackground(roundRect(activity, enabled ? ORANGE : GRAY, 18));
            thumb.setBackground(oval(activity, ICON));
            LayoutParams lp = new LayoutParams(dp(activity, 22), dp(activity, 22), Gravity.CENTER_VERTICAL | (enabled ? Gravity.END : Gravity.START));
            lp.setMargins(dp(activity, 4), dp(activity, 4), dp(activity, 4), dp(activity, 4));
            thumb.setLayoutParams(lp);
            if (notify && listener != null) listener.onStateChanged(enabled);
        }
    }
}
