package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Exact GENERAL-only item routes for four independently hosted shops.
 * Identifying the URL is NOT an inventory verdict. Never recognize listings. */
public final class WishlistGeneralShopItem {
    private WishlistGeneralShopItem() { }
    public enum Merchant { NONE, GREENBEANS, LOHACO, GU, MERCARI }

    private static final Pattern GREEN = Pattern.compile("^/products/([0-9]{8,18})/details/?$",Pattern.CASE_INSENSITIVE);
    private static final Pattern LOHACO = Pattern.compile("^/store/[a-z0-9_-]{2,45}/item/([a-z0-9_-]{5,50})/?$",Pattern.CASE_INSENSITIVE);
    private static final Pattern GU = Pattern.compile("^/jp/ja/products/(E[0-9]{6}-[0-9]{3})/[0-9]{2}/?$",Pattern.CASE_INSENSITIVE);
    private static final Pattern MERCARI = Pattern.compile("^/item/(m[0-9]{8,15})/?$",Pattern.CASE_INSENSITIVE);

    public static Merchant merchant(URL u) {
        if (u == null || !"https".equalsIgnoreCase(u.getProtocol()) || !WishlistCrawler.isAllowedUrl(u)) return Merchant.NONE;
        String host=u.getHost().toLowerCase(Locale.ROOT);
        String path=u.getPath();
        if ((host.equals("greenbeans.com") || host.equals("www.greenbeans.com")) && GREEN.matcher(path).matches())return Merchant.GREENBEANS;
        if (host.equals("lohaco.yahoo.co.jp") && LOHACO.matcher(path).matches())return Merchant.LOHACO;
        if ((host.equals("gu-global.com") || host.equals("www.gu-global.com")) && GU.matcher(path).matches())return Merchant.GU;
        if (host.equals("jp.mercari.com") && MERCARI.matcher(path).matches())return Merchant.MERCARI;
        return Merchant.NONE;
    }
    public static boolean isDetail(URL u) { return merchant(u)!=Merchant.NONE; }
    public static String code(URL u) {
        Matcher matcher;
        switch(merchant(u)) {
            case GREENBEANS: matcher=GREEN.matcher(u.getPath()); break;
            case LOHACO: matcher=LOHACO.matcher(u.getPath()); break;
            case GU: matcher=GU.matcher(u.getPath()); break;
            case MERCARI: matcher=MERCARI.matcher(u.getPath()); break;
            default: return "";
        }
        return matcher.matches()?matcher.group(1):"";
    }
    /** Only the exact original item and merchant family; query may vary for size/color selection. */
    public static boolean sameProduct(URL expected, URL actual) {
        Merchant x=merchant(expected);
        if (x==Merchant.NONE || x!=merchant(actual))return false;
        if(!code(expected).equalsIgnoreCase(code(actual)))return false;
        String left=expected.getPath().replaceAll("/+$","");
        String right=actual.getPath().replaceAll("/+$","");
        return left.equalsIgnoreCase(right);
    }
}
