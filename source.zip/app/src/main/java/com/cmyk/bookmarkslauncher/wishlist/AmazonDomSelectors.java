package com.cmyk.bookmarkslauncher.wishlist;
/** Amazon-only rendered DOM rules. Never dispatch to another shop's parser. */
final class AmazonDomSelectors {
    private AmazonDomSelectors(){}
    static String stock(String asin) {
        String expected = asin == null ? "" : asin.replaceAll("[^A-Za-z0-9]", "").toUpperCase(java.util.Locale.ROOT);
        return "(function(){try{\n"
                + "var expected='" + expected + "';\n"
                + "function visible(el){if(!el||!el.getClientRects().length||el.disabled||el.getAttribute('aria-disabled')==='true')return false;for(var n=el;n;n=n.parentElement){var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||n.hidden||Number(s.opacity)===0)return false;}return true;}\n"
                + "function allowed(el){return el&&!el.closest('[class*=related],[class*=recommend],[id*=related],[id*=recommend],[class*=ranking],[id*=ranking],[class*=sims-],[id*=sims-],nav,footer,header');}\n"
                + "var actual=document.querySelector('#ASIN,input[name=\"ASIN\"],input[name=\"asin\"]');\n"
                + "if(actual&&actual.value&&String(actual.value).toUpperCase()!==expected)return 'UNKNOWN';\n"
                + "var roots=['#buybox','#desktop_buybox','#buyBoxInner','#buybox_feature_div','#addToCart_feature_div','#desktop_qualifiedBuyBox','#atcRedesignId','#mobileBuyBox','#ppd','#dp-container'];\n"
                + "var ctrls=['#add-to-cart-button','input[name=\"submit.add-to-cart\"]','#buy-now-button','input[name=\"submit.buy-now\"]','button[name=\"submit.add-to-cart\"]','[data-action=\"add-to-cart\"]'];\n"
                + "for(var i=0;i<roots.length;i++){\n"
                + " var root=document.querySelector(roots[i]);if(!root||!allowed(root))continue;\n"
                + " for(var j=0;j<ctrls.length;j++){\n"
                + "  var c=root.querySelector(ctrls[j]);if(!c||!visible(c)||!allowed(c))continue;\n"
                + "  var name=String(c.id||'')+' '+String(c.name||'')+' '+String(c.value||c.innerText||'');\n"
                + "  if(/add.to.cart|buy.now|カート|購入/i.test(name))return 'AVAILABLE';\n"
                + " }\n"
                + "}\n"
                + "return 'UNKNOWN';\n"
                + "}catch(e){return 'UNKNOWN';}})()\n";
    }
    static String price(){return "(function(){try{\nfunction visible(el){if(!el||!el.getClientRects().length||el.disabled||el.getAttribute('aria-disabled')==='true')return false;for(var n=el;n;n=n.parentElement){var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||n.hidden)return false;}return true;}\nfunction clean(el){return (el.getAttribute('content')||el.innerText||el.textContent||el.value||'').replace(/\\s+/g,' ').trim();}\nfunction safe(el){return el&&!el.closest('[class*=related],[class*=recommend],[id*=related],[id*=recommend],[class*=ranking],[id*=ranking]');}\nvar scope=document.querySelector('main')||document.body;\nvar ids=[\"#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen\",\"#corePrice_feature_div .priceToPay .a-offscreen\",\"#price_inside_buybox\",\"#priceblock_ourprice\"];for(var i=0;i<ids.length;i++){var el=document.querySelector(ids[i]);if(el&&safe(el)&&visible(el)){var v=clean(el);if(v.length<95&&!/送料|参考価格|ポイント|割引|関連商品/.test(v))return JSON.stringify({value:v,currency:'JPY'});}}return JSON.stringify({value:'',currency:''});;\n}catch(e){return '';}})()";}
    static String images(){return "(function(){try{\nfunction visible(el){if(!el||!el.getClientRects().length||el.disabled||el.getAttribute('aria-disabled')==='true')return false;for(var n=el;n;n=n.parentElement){var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||n.hidden)return false;}return true;}\nfunction clean(el){return (el.getAttribute('content')||el.innerText||el.textContent||el.value||'').replace(/\\s+/g,' ').trim();}\nfunction safe(el){return el&&!el.closest('[class*=related],[class*=recommend],[id*=related],[id*=recommend],[class*=ranking],[id*=ranking]');}\nvar scope=document.querySelector('main')||document.body;\nvar ids=[\"#landingImage\",\"#imgTagWrapperId img\",\"#imageBlock img\"],out=[];for(var i=0;i<ids.length;i++){var e=document.querySelector(ids[i]);if(!e||!safe(e))continue;var raw=e.getAttribute('data-old-hires')||e.getAttribute('data-src')||e.currentSrc||e.getAttribute('src');if(!raw)continue;try{var u=new URL(raw,location.href);if(u.protocol==='https:')out.push(u.href);}catch(err){}if(out.length)break;}if(!out.length){var og=document.querySelector('meta[property=\"og:image\"]');if(og&&og.content){try{var url=new URL(og.content,location.href);if(url.protocol==='https:')out.push(url.href);}catch(err){}}}return JSON.stringify(out.slice(0,6));;\n}catch(e){return '';}})()";}
}
