package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;

/** Joshin item routes only.  Category pages contain no terminal 8-15 digit item file. */
public final class WishlistJoshinProductIdentity {
    private WishlistJoshinProductIdentity() { }

    public static boolean isDetail(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())
                || !WishlistCrawler.isAllowedUrl(url)) return false;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        if (!("joshinweb.jp".equals(host) || "www.joshinweb.jp".equals(host))) return false;
        return url.getPath().matches("(?i)^/[a-z0-9_-]+/[0-9]{1,7}/[0-9]{8,15}\\.html$");
    }

    /** Joshin may canonicalize the category number; the terminal JAN must remain identical. */
    public static boolean sameItem(URL original, URL loaded) {
        return isDetail(original) && isDetail(loaded)
                && itemCode(original).equalsIgnoreCase(itemCode(loaded))
                && original.getHost().equalsIgnoreCase(loaded.getHost());
    }

    public static String itemCode(URL url) {
        if (!isDetail(url)) return "";
        String path = url.getPath();
        return path.substring(path.lastIndexOf('/') + 1, path.length() - 5);
    }
}
