package com.cmyk.bookmarkslauncher.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;

public final class SearchWidgetView extends FrameLayout {
    public interface Listener {
        void onSearch(String query);
        boolean onLongPress(SearchWidgetView view);
    }

    private static final int N_DGRAY = 0xFF252020;
    private static final int N_LGRAY = 0xFF656060;
    private static final int N_TEXT = 0xFFFFFFFF;

    private final EditText input;
    private Listener listener;
    private int cellY;

    public SearchWidgetView(Context context, int cellY) {
        super(context);
        this.cellY = Math.max(0, cellY);
        setClickable(true);
        setFocusable(true);
        setElevation(0f);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(N_DGRAY);
        bg.setCornerRadius(dp(18));
        setBackground(bg);

        input = new EditText(context);
        input.setSingleLine(true);
        input.setTextColor(N_TEXT);
        input.setHintTextColor(N_LGRAY);
        input.setHint("検索");
        input.setTextSize(16);
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setPadding(dp(18), 0, dp(18), 0);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_NORMAL);
        addView(input, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || (event != null && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                String q = input.getText() == null ? "" : input.getText().toString().trim();
                if (!q.isEmpty() && listener != null) listener.onSearch(q);
                return true;
            }
            return false;
        });

        setOnLongClickListener(v -> listener != null && listener.onLongPress(this));
        input.setOnLongClickListener(v -> listener != null && listener.onLongPress(this));
    }

    public void setListener(Listener listener) { this.listener = listener; }
    public int getCellY() { return cellY; }
    public void setCellY(int cellY) { this.cellY = Math.max(0, cellY); }
    public EditText getInput() { return input; }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
