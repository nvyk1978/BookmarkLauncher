package com.cmyk.bookmarkslauncher.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;

public final class SearchWidgetView extends FrameLayout {
    public interface Listener {
        void onSearch(String query);
        boolean onDragRequest(SearchWidgetView view);
    }

    private static final int N_LGRAY = 0xFF656060;
    private static final int N_ICON = 0xFFA9A999;
    private static final int N_TEXT = 0xFFFFFFFF;

    private final EditText input;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final int touchSlop;
    private Listener listener;
    private int cellX;
    private int cellY;
    private float downRawX;
    private float downRawY;
    private boolean longPressArmed;
    private boolean dragStarted;

    private final Runnable armLongPress = () -> {
        longPressArmed = true;
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
    };

    public SearchWidgetView(Context context, int cellX, int cellY) {
        super(context);
        this.cellX = Math.max(0, cellX);
        this.cellY = Math.max(0, cellY);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setClickable(true);
        setFocusable(true);
        setElevation(0f);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(N_LGRAY);
        bg.setCornerRadius(dp(16));
        setBackground(bg);

        input = new EditText(context);
        input.setSingleLine(true);
        input.setTextColor(N_TEXT);
        input.setHintTextColor(N_ICON);
        input.setHint("検索");
        input.setTextSize(15);
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setPadding(dp(15), 0, dp(15), 0);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_NORMAL);
        // Suppress the automatic long-press ActionMode. We deliberately show it only when a
        // long-press is released without moving; moving after the long-press starts widget drag.
        input.setLongClickable(false);
        ActionMode.Callback editMenuFilter = new ActionMode.Callback() {
            @Override public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                removeSearchActions(menu);
                return true;
            }
            @Override public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                removeSearchActions(menu);
                return true;
            }
            @Override public boolean onActionItemClicked(ActionMode mode, MenuItem item) { return false; }
            @Override public void onDestroyActionMode(ActionMode mode) { }
        };
        input.setCustomSelectionActionModeCallback(editMenuFilter);
        input.setCustomInsertionActionModeCallback(editMenuFilter);
        addView(input, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || (event != null && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                String q = input.getText() == null ? "" : input.getText().toString().trim();
                if (!q.isEmpty() && listener != null) listener.onSearch(q);
                return true;
            }
            return false;
        });
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                handler.removeCallbacks(armLongPress);
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                longPressArmed = false;
                dragStarted = false;
                handler.postDelayed(armLongPress, ViewConfiguration.getLongPressTimeout());
                break;

            case MotionEvent.ACTION_MOVE:
                if (longPressArmed && !dragStarted) {
                    float dx = event.getRawX() - downRawX;
                    float dy = event.getRawY() - downRawY;
                    if (dx * dx + dy * dy > touchSlop * touchSlop) {
                        dragStarted = listener != null && listener.onDragRequest(this);
                        if (dragStarted) {
                            handler.removeCallbacks(armLongPress);
                            return true;
                        }
                    }
                }
                break;

            case MotionEvent.ACTION_UP:
                handler.removeCallbacks(armLongPress);
                if (longPressArmed && !dragStarted) {
                    // Let the EditText consume UP first so its pressed/cursor state is clean, then
                    // invoke the native selection ActionMode manually.
                    super.dispatchTouchEvent(event);
                    input.requestFocus();
                    input.setLongClickable(true);
                    input.performLongClick();
                    input.setLongClickable(false);
                    longPressArmed = false;
                    return true;
                }
                longPressArmed = false;
                break;

            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(armLongPress);
                longPressArmed = false;
                dragStarted = false;
                break;
        }
        return super.dispatchTouchEvent(event);
    }

    private static void removeSearchActions(Menu menu) {
        if (menu == null) return;
        for (int i = menu.size() - 1; i >= 0; i--) {
            MenuItem item = menu.getItem(i);
            CharSequence title = item.getTitle();
            Intent intent = item.getIntent();
            boolean titledSearch = title != null && ("search".equalsIgnoreCase(title.toString().trim())
                    || "検索".equals(title.toString().trim()));
            boolean processSearch = intent != null && Intent.ACTION_PROCESS_TEXT.equals(intent.getAction())
                    && title != null && title.toString().toLowerCase().contains("search");
            if (titledSearch || processSearch) menu.removeItem(item.getItemId());
        }
    }

    public void setListener(Listener listener) { this.listener = listener; }
    public int getCellX() { return cellX; }
    public int getCellY() { return cellY; }
    public void setCell(int cellX, int cellY) {
        this.cellX = Math.max(0, cellX);
        this.cellY = Math.max(0, cellY);
    }
    public EditText getInput() { return input; }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
