package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.regex.Pattern;

/** Classifies marketplace HTTP documents BEFORE any metadata can be committed.
 * UNKNOWN URL != other product; only a bound Product can recover an UNKNOWN URL.
 * No page-wide social cards, prices or product listings are trusted.
 */
final class WishlistGeneralMarketplacePageEvidence {
    final boolean verified;
    final String reason;
    private WishlistGeneralMarketplacePageEvidence(boolean verified, String reason) {
        this.verified = verified;
        this.reason = reason;
    }
    static WishlistGeneralMarketplacePageEvidence inspect(String html, URL saved, URL landed) {
        WishlistGeneralMarketplaceIdentity.ItemRelation relation =
                WishlistGeneralMarketplaceIdentity.relation(saved, landed);
        if (relation == WishlistGeneralMarketplaceIdentity.ItemRelation.DIFFERENT)
            return new WishlistGeneralMarketplacePageEvidence(false, "different-item");
        if (html == null || html.isBlank())
            return new WishlistGeneralMarketplacePageEvidence(false, "empty-document");
        // Many normal storefront bundles contain 'captcha' in JavaScript.
        // Only a dedicated visible page heading/title can classify a challenge;
        // mere keywords in script/data source must never block product parsing.
        String head = html.substring(0, Math.min(html.length(), 60000));
        if (Pattern.compile("(?is)<(?:title|h1)\\b[^>]*>\\s*[^<]{0,90}"
                + "(?:captcha|verify you are human|access denied|robot check)"
                + "[^<]{0,90}</(?:title|h1)\\s*>").matcher(head).find())
            return new WishlistGeneralMarketplacePageEvidence(false, "challenge-page");
        // A URL-bound Product can be present on a rewritten URL, but an unbound
        // Product, product recommendation or social preview is NOT evidence.
        if (WishlistGenericJsonLdProduct.find(html, saved) != null)
            return new WishlistGeneralMarketplacePageEvidence(true, "bound-jsonld");
        if (relation == WishlistGeneralMarketplaceIdentity.ItemRelation.SAME)
            return new WishlistGeneralMarketplacePageEvidence(true, "same-item-url");
        return new WishlistGeneralMarketplacePageEvidence(false, "unbound-landing");
    }
}
