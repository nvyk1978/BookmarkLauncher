package com.cmyk.bookmarkslauncher.youtube;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.cmyk.bookmarkslauncher.DiagLog;
import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * YouTube-only thumbnail capture.
 *
 * No WebView is used here. A video ID is resolved from the URL, the best available
 * official YouTube thumbnail is downloaded, center-cropped to 1:1 and stored as the
 * bookmark screenshot. Page chrome, controls and text therefore never enter the image.
 */
final class YouTubeCaptureManager {
    interface Listener {
        void onComplete(boolean success, BookmarkNode updatedNode, String message);
    }

    private static final String USER_AGENT = "Mozilla/5.0 Android BookmarkLauncher";
    private static final int MIN_USEFUL_WIDTH = 320;

    private final Activity activity;
    private final BookmarkRepository repo;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final AtomicInteger generation = new AtomicInteger();

    YouTubeCaptureManager(Activity activity, BookmarkRepository repo) {
        this.activity = activity;
        this.repo = repo;
    }

    void capture(BookmarkNode node, Listener listener) {
        if (node == null || node.url == null || node.url.isBlank()) {
            complete(listener, false, node, "URLがありません");
            return;
        }
        String videoId = YouTubeLink.extractVideoId(node.url);
        if (videoId == null) {
            complete(listener, false, node, "YouTube動画IDを取得できませんでした");
            return;
        }

        final int token = generation.incrementAndGet();
        final String nodeId = node.id;
        final String originalUrl = node.url;
        io.execute(() -> captureOnWorker(token, nodeId, originalUrl, videoId, listener));
    }

    void cancel() {
        generation.incrementAndGet();
    }

    void destroy() {
        generation.incrementAndGet();
        io.shutdownNow();
    }

    private void captureOnWorker(int token, String nodeId, String originalUrl, String videoId, Listener listener) {
        Bitmap source = null;
        Bitmap square = null;
        try {
            DiagLog.write(activity, "YOUTUBE_CAPTURE_START id=" + videoId);
            source = downloadBestThumbnail(videoId, token);
            if (!isCurrent(token)) return;
            if (source == null) {
                DiagLog.write(activity, "YOUTUBE_THUMBNAIL_FAILED id=" + videoId);
                complete(listener, false, repo.get(nodeId), "YouTubeサムネイルを取得できませんでした");
                return;
            }

            int sourceWidth = source.getWidth();
            int sourceHeight = source.getHeight();
            square = centerCropSquare(source);
            File assets = new File(activity.getFilesDir(), "bookmark_assets");
            if (!assets.exists() && !assets.mkdirs()) throw new IllegalStateException("asset directory");
            File screenshot = new File(assets, nodeId + "_thumb.jpg");
            saveBitmap(square, screenshot);

            String title = fetchOEmbedTitle(originalUrl, videoId, token);
            if (!isCurrent(token)) return;
            repo.updateCapturedMetadata(nodeId, "YouTube", title, title,
                    null, screenshot.getAbsolutePath(), false);
            BookmarkNode updated = repo.get(nodeId);
            DiagLog.write(activity, "YOUTUBE_CAPTURE_OK id=" + videoId
                    + " size=" + sourceWidth + "x" + sourceHeight
                    + " title=" + safe(title));
            complete(listener, true, updated, null);
        } catch (Throwable t) {
            if (!isCurrent(token)) return;
            DiagLog.write(activity, "YOUTUBE_CAPTURE_ERROR id=" + videoId + " " + t.getClass().getSimpleName()
                    + ":" + safe(t.getMessage()));
            complete(listener, false, repo.get(nodeId), "YouTubeサムネイル取得に失敗しました");
        } finally {
            if (square != null && square != source && !square.isRecycled()) square.recycle();
            if (source != null && !source.isRecycled()) source.recycle();
        }
    }

    private Bitmap downloadBestThumbnail(String videoId, int token) {
        String[] names = {"maxresdefault.jpg", "sddefault.jpg", "hqdefault.jpg", "0.jpg"};
        for (String name : names) {
            if (!isCurrent(token)) return null;
            Bitmap bitmap = downloadBitmap("https://i.ytimg.com/vi/" + videoId + "/" + name);
            if (bitmap == null) continue;
            if (bitmap.getWidth() >= MIN_USEFUL_WIDTH && bitmap.getHeight() >= 180) return bitmap;
            bitmap.recycle();
        }
        return null;
    }

    private Bitmap downloadBitmap(String address) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(6000);
            connection.setReadTimeout(7000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", USER_AGENT);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return null;
            try (InputStream in = connection.getInputStream()) {
                return BitmapFactory.decodeStream(in);
            }
        } catch (Throwable ignored) {
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String fetchOEmbedTitle(String originalUrl, String videoId, int token) {
        if (!isCurrent(token)) return null;
        HttpURLConnection connection = null;
        try {
            String watchUrl = YouTubeLink.canonicalWatchUrl(videoId);
            String endpoint = "https://www.youtube.com/oembed?format=json&url="
                    + URLEncoder.encode(watchUrl, StandardCharsets.UTF_8.name());
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", USER_AGENT);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return null;
            StringBuilder json = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) json.append(line);
            }
            String title = new JSONObject(json.toString()).optString("title", null);
            return clean(title);
        } catch (Throwable ignored) {
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static Bitmap centerCropSquare(Bitmap source) {
        int side = Math.min(source.getWidth(), source.getHeight());
        int left = Math.max(0, (source.getWidth() - side) / 2);
        int top = Math.max(0, (source.getHeight() - side) / 2);
        Bitmap crop = Bitmap.createBitmap(source, left, top, side, side);
        if (side == 512) return crop;
        Bitmap scaled = Bitmap.createScaledBitmap(crop, 512, 512, true);
        if (scaled != crop && crop != source) crop.recycle();
        return scaled;
    }

    private static void saveBitmap(Bitmap bitmap, File file) throws Exception {
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)) {
                throw new IllegalStateException("compress failed");
            }
            out.flush();
        }
    }

    private boolean isCurrent(int token) {
        return generation.get() == token && !Thread.currentThread().isInterrupted();
    }

    private void complete(Listener listener, boolean success, BookmarkNode node, String message) {
        if (listener == null) return;
        activity.runOnUiThread(() -> listener.onComplete(success, node, message));
    }

    private static String clean(String value) {
        if (value == null) return null;
        String v = value.trim();
        return v.isEmpty() ? null : v;
    }

    private static String safe(String value) {
        if (value == null) return "null";
        return value.replace('\n', ' ').replace('\r', ' ');
    }
}
