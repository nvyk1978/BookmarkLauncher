package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONObject;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Requested product name only; independent of images, stock and price. */
final class YahooNameExtractor {
    private static final Pattern META=Pattern.compile("(?is)<meta\\b[^>]*>");
    private static final Pattern ATTR=Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')",Pattern.CASE_INSENSITIVE);
    private YahooNameExtractor(){}
    static String find(String html, URL page) {
        MarketplaceIdentity identity=MarketplaceIdentity.from(page);
        if(identity==null||identity.site!=MarketplaceIdentity.Site.YAHOO||!identity.verified(html,page))return null;
        JSONObject product=YahooProductJsonLd.find(html,page);
        if(product!=null){
            String name=clean(product.optString("name",null));
            if(name!=null)return name;
        }
        Matcher tags=META.matcher(html);
        while(tags.find()){
            String tag=tags.group();
            String prop=attr(tag,"property");
            if("og:title".equalsIgnoreCase(prop))return clean(attr(tag,"content"));
        }
        return null;
    }
    private static String attr(String tag,String name){Matcher m=ATTR.matcher(tag);while(m.find())if(name.equalsIgnoreCase(m.group(1)))return m.group(2)!=null?m.group(2):m.group(3);return null;}
    private static String clean(String s){
        if(s==null)return null;
        String x=s.replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replaceAll("\\s+"," ").trim();
        return x.isEmpty()?null:x;
    }
}
