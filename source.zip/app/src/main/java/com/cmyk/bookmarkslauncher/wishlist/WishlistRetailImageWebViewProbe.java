package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;
import java.net.URL;
import java.util.Locale;

/**
 * Foreground-only image recovery for non-Amazon product DETAIL pages.
 * Deliberately separate from the proven Amazon image pipeline, and never
 * parses or writes product titles, availability or prices.
 */
public final class WishlistRetailImageWebViewProbe {
    public interface Callback { void completed(String[] imageUrls); }
    public interface Trace { void record(String stage, String evidence); }
    private Trace trace;
    public void setTrace(Trace listener) { trace = listener; }
    private void trace(String stage, String reason) {
        if (trace != null) trace.record(stage, reason);
    }
    private final FrameLayout parent;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private Callback callback;
    private String originalHost;
    private URL originalRetailUrl;
    private WishlistMode probeMode;
    private MarketplaceIdentity expectedMarketplace;
    private boolean unknownGeneralDetail;
    private String verifiedMarketplaceTitle;
    public String verifiedMarketplaceTitle() { return verifiedMarketplaceTitle; }
    private boolean done;
    private int inspections;
    private boolean queued;
    private final Runnable timeout = () -> {
        if (originalRetailUrl != null
                && WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
            trace("deadline", "savedMarketItem=true attempts="+inspections);
        finish(null);
    };
    private static final int MAX_INSPECTIONS = 7;

    public WishlistRetailImageWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public void start(String urlText, WishlistMode mode, Callback cb) {
        cancel();
        callback = cb;
        probeMode = mode;
        done = false;
        inspections = 0;
        queued = false;
        unknownGeneralDetail = false;
        verifiedMarketplaceTitle = null;
        if (Looper.myLooper() != Looper.getMainLooper()) {
            trace("skip","reason=off-main-thread"); finish(null); return;
        }
        try {
            URL u = new URL(urlText);
            if (!"https".equalsIgnoreCase(u.getProtocol()) || !WishlistCrawler.isAllowedUrl(u)
                    || WishlistImageWebViewProbe.isAmazonUrl(urlText)
                    || !(WishlistCrawler.isSingleProductPage(u)
                        || (mode == WishlistMode.GENERAL && WishlistGeneralVerifiedUnknownDom.candidate(u))
                        || WishlistRetailDedicatedMode.forUrl(u) == WishlistRetailDedicatedMode.ZOZO)) {
                trace("skip","reason=non-product-or-insecure-url"); finish(null); return;
            }
            if (mode == null || mode == WishlistMode.UNRESOLVED
                    || WishlistMode.forDirectUrl(urlText) != mode) {
                trace("skip","reason=mode-mismatch"); finish(null); return;
            }
            originalHost = u.getHost().toLowerCase(Locale.ROOT);
            originalRetailUrl = u;
            if (WishlistGeneralMarketplaceIdentity.isDetail(u))
                trace("route", "savedMarketItem=true source=saved-item identityRequired=true");
            unknownGeneralDetail = mode == WishlistMode.GENERAL
                    && !WishlistCrawler.isSingleProductPage(u)
                    && WishlistGeneralVerifiedUnknownDom.candidate(u);
            expectedMarketplace = MarketplaceIdentity.from(u);
            if (MarketplaceIdentity.site(u) != MarketplaceIdentity.Site.OTHER
                    && expectedMarketplace == null) {
                trace("skip","reason=marketplace-unverified"); finish(null); return;
            }
            web = BackgroundDomWebView.create(parent.getContext());


            web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setClickable(false);
            web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.setVerticalScrollBarEnabled(false);
            web.setHorizontalScrollBarEnabled(false);

            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                    return request.isForMainFrame() && !sameShop(request.getUrl().toString());
                }
                @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                    if (done) return;
                    boolean same = sameShop(url);
                    if (WishlistRetailDedicatedMode.forUrl(originalRetailUrl) == WishlistRetailDedicatedMode.ZOZO)
                        trace("page.started", "sameItem="+same);
                    if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
                        trace("navigation", "phase=started sameItem="+same);
                    if (same && (mode == WishlistMode.MUJI
                            || WishlistJoshinProductIdentity.isDetail(originalRetailUrl)))
                        schedule(v, 2300);
                    // ZOZO loads several scripts after the main document starts.
                    // onPageFinished may not fire in time due to trackers, so
                    // begin bounded image DOM sampling independently of it.
                    else if (same && WishlistRetailDedicatedMode.forUrl(originalRetailUrl) == WishlistRetailDedicatedMode.ZOZO)
                        schedule(v, 2600);
                    else if (same && (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)
                            || unknownGeneralDetail)) schedule(v, 2100);
                }
                @Override public void onPageFinished(WebView v, String url) {
                    boolean same = sameShop(url);
                    trace("page.finished","sameItem="+same);
                    if (!done && same) schedule(v, 650);
                }
                @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError error) {
                    if (req.isForMainFrame()) {
                        trace("main.error","reason=webview-load-error");
                        finish(null);
                    }
                }
                @Override public void onReceivedHttpError(WebView v, WebResourceRequest req,
                                                           android.webkit.WebResourceResponse response) {
                    if (req.isForMainFrame() && originalRetailUrl != null
                            && GeneralRetailIdentity.store(originalRetailUrl) != null)
                        RetailDiagnostics.general(originalRetailUrl,"image.webview.http",
                                "code="+response.getStatusCode());
                    if (req.isForMainFrame()) trace("main.http","code="+response.getStatusCode());
                }
            });
            main.postDelayed(timeout, 18000);
            trace("load.start","productDetail=true mode="+mode);
            web.loadUrl(urlText);
        } catch (Exception e) {
            trace("skip","reason=start-exception"); finish(null);
        }
    }

    private boolean sameShop(String urlText) {
        try {
            URL u = new URL(urlText);
            return "https".equalsIgnoreCase(u.getProtocol()) && WishlistCrawler.isAllowedUrl(u)
                    && (u.getHost().equalsIgnoreCase(originalHost)
                        || (originalRetailUrl != null
                            && WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)
                            && WishlistGeneralMarketplaceIdentity.relation(originalRetailUrl, u)
                                != WishlistGeneralMarketplaceIdentity.ItemRelation.DIFFERENT))
                    && (expectedMarketplace==null || expectedMarketplace.matches(u))
                    && (!unknownGeneralDetail || WishlistGeneralVerifiedUnknownDom.samePage(originalRetailUrl, u))
                    && (originalRetailUrl == null || !WishlistMode.isMujiProduct(originalRetailUrl)
                        || originalRetailUrl.getPath().replaceAll("/+$", "")
                            .equalsIgnoreCase(u.getPath().replaceAll("/+$", "")))
                    && (originalRetailUrl == null || !WishlistHonmaProductDom.isDetail(originalRetailUrl)
                        || WishlistHonmaProductDom.sameItem(originalRetailUrl,u))
                    && (originalRetailUrl == null || !WishlistJoshinProductIdentity.isDetail(originalRetailUrl)
                        || WishlistJoshinProductIdentity.sameItem(originalRetailUrl, u))
                    && (originalRetailUrl == null || GeneralRetailIdentity.store(originalRetailUrl) == null
                        || GeneralRetailIdentity.sameProduct(originalRetailUrl, u))
                    && (originalRetailUrl == null || !WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)
                        || WishlistGeneralMarketplaceIdentity.relation(originalRetailUrl, u)
                            != WishlistGeneralMarketplaceIdentity.ItemRelation.DIFFERENT);
        } catch (Exception ignored) { return false; }
    }

    private void schedule(WebView view, long ms) {
        if (done || queued || view != web) return;
        queued = true;
        main.postDelayed(() -> { queued = false; if (!done && view == web) inspect(view); }, ms);
    }

    private void inspect(WebView view) {
        inspections++;
        trace("dom.inspect","attempt="+inspections);
        // Only image URLs are inspected; prices and titles remain separate.
        final String js =
                "(function(){\n" +
                "'use strict';\n" +
                "var list=[], seen={};\n" +
                "var market="+(expectedMarketplace!=null)+";\n" +
                "var path=location.pathname||'';\n" +
                "var match=path.match(/(?:item_detail_|\\/item-detail\\/|\\/product\\/|\\/detail\\/)([0-9]{3,})(?:[/.]|$)/i);\n" +
                "var itemId=match?match[1]:'';\n" +
                "if(/^\\/p\\/[a-z0-9_-]{5,20}\\/?$/i.test(path)&&/askul\\.co\\.jp$/i.test(location.hostname))itemId=path.split('/')[2];\n" +
                "if(/^\\/p\\/\\d{4}\\/\\d{4}\\/?$/.test(path)&&/monotaro\\.com$/i.test(location.hostname))itemId=path.split('/')[2]+path.split('/')[3];\n" +
                "if(!itemId){var params=new URLSearchParams(location.search||'');" +
                "itemId=params.get('pid')||params.get('eci_product')||params.get('product_id')||'';}\n" +
                "if(!/^[a-z0-9_-]{2,40}$/i.test(itemId))itemId='';\n" +
                "function valid(raw){\n" +
                "  if(!raw)return '';\n" +
                "  try{var u=new URL(String(raw).replace(/&amp;/g,'&'),location.href);\n" +
                "    if(u.protocol!=='https:' || !/\\.(?:jpe?g|png|webp|avif)(?:$|[?#])/i.test(u.href) && !/\\/images?\\//i.test(u.pathname))return '';\n" +
                "    if(/logo|banner|icon|payment|cart|recommend|related|tracking|spacer|placeholder|noimage/i.test(u.pathname))return '';\n" +
                "    return u.href;\n" +
                "  }catch(e){return '';}\n" +
                "}\n" +
                "function add(raw,weight){\n" +
                "  var u=valid(raw);if(!u)return;\n" +
                "  var key=u;\n" +
                "  if(itemId && u.indexOf(itemId)>=0)weight+=130;\n" +
                "  if(path.indexOf('/item-detail/')>=0 && /image\\.raku-uru\\.jp\\//.test(u))weight+=100;\n" +
                "  if(!(key in seen)||seen[key]<weight)seen[key]=weight;\n" +
                "}\n" +
                "function processImage(el,weight){\n" +
                "  if(!el)return;\n" +
                "  var hint=String(el.id||'')+' '+String(el.className||'')+' '+String(el.alt||'');\n" +
                "  if(/logo|banner|icon|payment|cart|recommend|related|social|spacer|placeholder|header|footer/i.test(hint))return;\n" +
                "  var attrs=['data-zoom-image','data-large-image','data-original','data-src','data-lazy-src','src'];\n" +
                "  for(var k=0;k<attrs.length;k++)add(el.getAttribute(attrs[k]),weight);\n" +
                "  var sets=el.getAttribute('data-srcset')||el.getAttribute('srcset')||'';\n" +
                "  if(sets){var parts=sets.split(',');for(var j=0;j<parts.length;j++)add(parts[j].trim().split(/\\s+/)[0],weight+3);}\n" +
                "  add(el.currentSrc,weight+1);\n" +
                "  var a=el.closest('a[href]');\n" +
                "  if(a) add(a.getAttribute('href'),weight+15);\n" +
                "}\n" +
                // Marketplaces: primary image/OGP only. The generic ranking and
                // page-wide gallery search below could include recommendations.
                "if(market){\n" +
                "var sels=['img[itemprop=image]','#mainImage','#mainImage img','#item-image img',"+
                "'.item-image img','.item-photo img','.product-detail__image img',"+
                "'.product-gallery img','#product-image img'];\n"+
                "for(var k=0;k<sels.length;k++){var el=document.querySelector(sels[k]);"+
                "if(!el||el.closest('[class*=recommend],[class*=related],[id*=recommend],[id*=related]'))continue;"+
                "processImage(el,200);if(Object.keys(seen).length)break;}\n"+
                "if(!Object.keys(seen).length){var m=document.querySelector('meta[property=\"og:image\"]');"+
                "if(m)add(m.content,120);}\n"+
                "return JSON.stringify(Object.keys(seen).slice(0,6));}\n"+
                "// A file number in the URL also identifies images used by small independent shops.\n" +
                "if(itemId){document.querySelectorAll('img,a[href],source[srcset]').forEach(function(el){\n" +
                "  var raw=el.getAttribute('href')||el.getAttribute('src')||el.getAttribute('data-src')||'';\n" +
                "  if(raw.indexOf(itemId)>=0){if(el.tagName==='IMG')processImage(el,220);else add(raw,220);}\n" +
                "});}\n" +
                "// Prioritize main gallery and zoom anchors, including multiple images per item.\n" +
                "var selectors=['img[itemprop=\"image\"]','[itemprop=\"image\"] img','[data-fancybox*=\"product\"] img',\n" +
                "'[data-lightbox*=\"product\"] img','.product-detail__image img','.product-detail img',\n" +
                "'.productDetail__image img','.productDetail img','.product-image img','.productImage img',\n" +
                "'.p-productDetail__image img','.p-product-detail__image img',\n" +
                "'.product-gallery img','.product_gallery img','.product-photo img','.product-photo__image img',\n" +
                "'#mainImage img','#main-image img','#mainImage','.main-image img',\n" +
                "'.item-image img','.item-photo img','.itemPhoto img','.item-detail img',\n" +
                "'.itemDetail img','.item-detail__image img','#item_photo img','#item_image img',\n" +
                "'#productImg img','.swiper-slide-active img','.slick-current img'];\n" +
                "selectors.forEach(function(sel){document.querySelectorAll(sel).forEach(function(el){processImage(el,180);});});\n" +
                "// Some platforms use an image CDN inside an otherwise unmarked product gallery.\n" +
                "if(path.indexOf('/item-detail/')>=0){document.querySelectorAll('img').forEach(function(el){\n" +
                "  var s=(el.getAttribute('data-src')||el.getAttribute('src')||'');\n" +
                "  if(s.indexOf('image.raku-uru.jp')>=0)processImage(el,135);\n" +
                "});}\n" +
                "// Main-content images only: require a unique large photo or a product-specific hint.\n" +
                "var scope=document.querySelector('main,[role=\"main\"],#main,#contents,.item-detail,.product-detail');\n" +
                "if(scope){\n" +
                "  var imgs=scope.querySelectorAll('img'),candidates=[];\n" +
                "  for(var i=0;i<Math.min(imgs.length,90);i++){\n" +
                "    var img=imgs[i],hint=(String(img.id||'')+' '+String(img.className||'')+' '+String(img.alt||''));\n" +
                "    if(/logo|banner|icon|payment|cart|recommend|related|shipping|social|placeholder/i.test(hint))continue;\n" +
                "    var p=img.closest('[class],[id]');\n" +
                "    var cls=p?(String(p.className||'')+' '+String(p.id||'')):'';\n" +
                "    if(/recommend|related|popular|other-products|sidebar/i.test(cls))continue;\n" +
                "    if(/product|item|photo|gallery|detail|main-image/i.test(hint+' '+cls))processImage(img,105);\n" +
                "    else if((img.naturalWidth||0)>=160 && (img.naturalHeight||0)>=160)candidates.push(img);\n" +
                "  }\n" +
                "  if(candidates.length===1)processImage(candidates[0],90);\n" +
                "}\n" +
                "var meta=document.querySelector('meta[property=\"og:image:secure_url\"],meta[property=\"og:image\"],meta[name=\"twitter:image\"]');\n" +
                "if(meta)add(meta.content,70);\n" +
                "Object.keys(seen).forEach(function(k){if(seen[k]>=70)list.push([k,seen[k]]);});\n" +
                "list.sort(function(a,b){return b[1]-a[1];});\n" +
                "return JSON.stringify(list.slice(0,6).map(function(x){return x[0];}));\n" +
                "})()\n";
        final boolean verifiedFeedFallback = WishlistVerifiedProductImageDom.supports(originalRetailUrl, probeMode);
        // ZOZO's price is already known. Only its missing image uses the
        // identity-checked product feed first; other proven image paths remain unchanged.
        final boolean dedicatedZozo = WishlistRetailDedicatedMode.forUrl(originalRetailUrl)
                == WishlistRetailDedicatedMode.ZOZO;
        final boolean zozoFeedFirst = !dedicatedZozo && verifiedFeedFallback
                && WishlistZozoVariantDom.supports(originalRetailUrl);
        final boolean guardedProduct = probeMode == WishlistMode.GENERAL
                && WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl);
        String actualJs = unknownGeneralDetail
                ? WishlistGeneralVerifiedUnknownDom.imageJavascript(originalRetailUrl)
                : guardedProduct
                ? WishlistGeneralMarketplaceImageDom.javascript(originalRetailUrl)
                : WishlistHonmaProductDom.isDetail(originalRetailUrl)
                ? WishlistHonmaProductDom.imageJavascript(originalRetailUrl)
                : dedicatedZozo
                ? WishlistRetailDedicatedImageDom.javascript(originalRetailUrl)
                : WishlistJoshinProductIdentity.isDetail(originalRetailUrl)
                ? WishlistGeneralGalleryImageTechnique.javascript(originalRetailUrl,
                        WishlistJoshinProductIdentity.itemCode(originalRetailUrl))
                : (zozoFeedFirst ? WishlistVerifiedProductImageDom.javascript(originalRetailUrl, probeMode) : js);

        if(expectedMarketplace!=null){
            switch(expectedMarketplace.site){
                case RAKUTEN: actualJs=RakutenDomSelectors.images();break;
                case YAHOO: actualJs=YahooDomSelectors.images();break;
                default: finish(null);return; // Amazon has a wholly separate image probe.
            }
        }
        try {
            view.evaluateJavascript(actualJs, response -> {
                if (done || view != web) return;
                List<String> urls = new ArrayList<>();
                try {
                    // Android evaluateJavascript quotes the returned JSON array.
                    String arrayText = new JSONArray("[" + response + "]").optString(0, "");
                    JSONArray values = new JSONArray(arrayText);
                    for (int i = 0; i < Math.min(values.length(), 6); i++) {
                        String link = values.optString(i, "");
                        if (isSafeImage(link) && !urls.contains(link)) urls.add(link);
                    }
                } catch (Exception ignored) { }
                if (!urls.isEmpty()) {
                    trace("dom.candidates","source="+(unknownGeneralDetail?"url-bound-jsonld":guardedProduct?"item-bound-general":
                            dedicatedZozo?"zozo-dedicated":zozoFeedFirst?"verified-feed":"legacy-gallery")
                            +" count="+urls.size());
                    // Image and name remain independent. A gallery is NOT
                    // proof of title identity; evaluate canonical/URL-bound
                    // product metadata separately before destroying this WebView.
                    if (guardedProduct) {
                        final String[] verifiedUrls=urls.toArray(new String[0]);
                        final boolean[] responded={false};
                        final Runnable deadline=() -> {
                            if (!responded[0] && !done) { responded[0]=true; finish(verifiedUrls); }
                        };
                        main.postDelayed(deadline, 1250);
                        try {
                            view.evaluateJavascript(WishlistGeneralMarketplaceVerifiedDom.javascript(originalRetailUrl), raw -> {
                                if (responded[0] || done || view != web) return;
                                responded[0]=true;
                                main.removeCallbacks(deadline);
                                String reason="unreadable";
                                try {
                                    String objText=new JSONArray("["+raw+"]").optString(0, "");
                                    org.json.JSONObject obj=new org.json.JSONObject(objText);
                                    String title=obj.optString("title", "").replaceAll("\\s+", " ").trim();
                                    if (title.length()>=4 && title.length()<=240) verifiedMarketplaceTitle=title;
                                    reason=obj.optString("reason", "unreadable");
                                } catch (Exception ignored) { reason="invalid-result"; }
                                trace("metadata", "title="+(verifiedMarketplaceTitle!=null)
                                        +" reason="+reason.replaceAll("[^a-z-]", ""));
                                finish(verifiedUrls);
                            });
                        } catch (Exception ignored) {main.removeCallbacks(deadline);responded[0]=true;finish(verifiedUrls);}
                        return;
                    }
                    finish(urls.toArray(new String[0])); return;
                }
                if (guardedProduct || unknownGeneralDetail) {
                    trace("dom.reject", "reason="+(unknownGeneralDetail ? "no-url-bound-product-json" : "no-bound-gallery-or-product-json")
                            +" attempt="+inspections);
                    if (inspections < MAX_INSPECTIONS) schedule(view, 1200);
                    else finish(null);
                    return;
                }
                // Keep ZOZO's preexisting gallery as a fallback when the stricter
                // product feed cannot identify its exact image on this visit.
                if (zozoFeedFirst || dedicatedZozo) {
                    try {
                        // A verified, merchant-specific gallery is preferred;
                        // keep the old gallery as a read-only failure fallback.
                        view.evaluateJavascript(js, legacyResult -> {
                            if (done || view != web) return;
                            List<String> legacyUrls = decodeImageCandidates(legacyResult);
                            if (!legacyUrls.isEmpty()) {
                                trace("dom.candidates","source=legacy-fallback count="+legacyUrls.size());
                                finish(legacyUrls.toArray(new String[0]));
                            }
                            else if (inspections < MAX_INSPECTIONS) schedule(view, 1200);
                            else finish(null);
                        });
                    } catch (Exception ignored) {
                        if (inspections < MAX_INSPECTIONS) schedule(view, 1200);
                        else finish(null);
                    }
                    return;
                }
                // Supplemental, read-only structured Product image evidence.
                // Never replace Joshin or a gallery that already found images.
                if (verifiedFeedFallback && !zozoFeedFirst) {
                    try {
                        view.evaluateJavascript(WishlistVerifiedProductImageDom.javascript(originalRetailUrl, probeMode), result -> {
                            if (done || view != web) return;
                            List<String> feedUrls = decodeImageCandidates(result);
                            if (!feedUrls.isEmpty()) finish(feedUrls.toArray(new String[0]));
                            else if (inspections < MAX_INSPECTIONS) schedule(view, 1200);
                            else finish(null);
                        });
                    } catch (Exception ignored) {
                        if (inspections < MAX_INSPECTIONS) schedule(view, 1200);
                        else finish(null);
                    }
                } else if (inspections < MAX_INSPECTIONS) schedule(view, 1200);
                else finish(null);
            });
        } catch (Exception ignored) { finish(null); }
    }

    private static List<String> decodeImageCandidates(String response) {
        List<String> urls = new ArrayList<>();
        try {
            String value = new JSONArray("[" + response + "]").optString(0, "");
            JSONArray array = new JSONArray(value);
            for (int i = 0; i < Math.min(6, array.length()); i++) {
                String link = array.optString(i, "");
                if (isSafeImage(link) && !urls.contains(link)) urls.add(link);
            }
        } catch (Exception ignored) { }
        return urls;
    }

    private static boolean isSafeImage(String value) {
        try {
            URL u = new URL(value);
            return "https".equalsIgnoreCase(u.getProtocol()) && WishlistCrawler.isAllowedUrl(u)
                    && !u.getPath().toLowerCase(Locale.ROOT).endsWith(".svg");
        } catch (Exception ignored) { return false; }
    }

    private void finish(String[] urls) {
        if (done) return;
        done = true;
        main.removeCallbacks(timeout);
        Callback cb = callback;
        callback = null;
        if (web != null) {
            WebView old = web;
            web = null;
            try { old.stopLoading(); old.loadUrl("about:blank");  old.destroy(); }
            catch (Exception ignored) { }
        }
        if (cb != null) cb.completed(urls);
    }
    public void cancel() { callback = null; finish(null); }
}
