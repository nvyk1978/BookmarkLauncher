package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import org.json.JSONArray;
import java.net.URL;
import java.util.Locale;

/**
 * Foreground-only image recovery for non-Amazon product DETAIL pages.
 * Deliberately separate from the proven Amazon image pipeline, and never
 * parses or writes product titles, availability or prices.
 */
public final class WishlistRetailImageWebViewProbe {
    public interface Callback { void completed(String imageUrl); }
    private final FrameLayout parent;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private Callback callback;
    private String originalHost;
    private boolean done;
    private int inspections;
    private boolean queued;
    private final Runnable timeout = () -> finish(null);
    private static final int MAX_INSPECTIONS = 7;

    public WishlistRetailImageWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public void start(String urlText, Callback cb) {
        cancel();
        callback = cb;
        done = false;
        inspections = 0;
        queued = false;
        if (Looper.myLooper() != Looper.getMainLooper()) { finish(null); return; }
        try {
            URL u = new URL(urlText);
            if (!"https".equalsIgnoreCase(u.getProtocol()) || !WishlistCrawler.isAllowedUrl(u)
                    || WishlistImageWebViewProbe.isAmazonUrl(urlText)
                    || !WishlistCrawler.isSingleProductPage(u)) { finish(null); return; }
            originalHost = u.getHost().toLowerCase(Locale.ROOT);
            web = new WebView(parent.getContext());
            web.setBackgroundColor(Color.TRANSPARENT);
            // Attached and laid out for lazy JS image loading, but never painted.
            web.setAlpha(0f);
            web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setClickable(false);
            web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.setVerticalScrollBarEnabled(false);
            web.setHorizontalScrollBarEnabled(false);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            parent.addView(web, 0, lp);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                    return request.isForMainFrame() && !sameShop(request.getUrl().toString());
                }
                @Override public void onPageFinished(WebView v, String url) {
                    if (!done && sameShop(url)) schedule(v, 650);
                }
                @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError error) {
                    if (req.isForMainFrame()) finish(null);
                }
            });
            main.postDelayed(timeout, 18000);
            web.loadUrl(urlText);
        } catch (Exception e) { finish(null); }
    }

    private boolean sameShop(String urlText) {
        try {
            URL u = new URL(urlText);
            return "https".equalsIgnoreCase(u.getProtocol()) && WishlistCrawler.isAllowedUrl(u)
                    && u.getHost().equalsIgnoreCase(originalHost);
        } catch (Exception ignored) { return false; }
    }

    private void schedule(WebView view, long ms) {
        if (done || queued || view != web) return;
        queued = true;
        main.postDelayed(() -> { queued = false; if (!done && view == web) inspect(view); }, ms);
    }

    private void inspect(WebView view) {
        inspections++;
        // Choose an image from the main product only; category images, suggestions,
        // navigation logos and tracking pixels are not valid fallbacks.
        final String js = "(function(){"+
                "function valid(s){if(!s)return '';try{var u=new URL(s,location.href);"+
                "if(u.protocol!=='https:'||/\\.(svg)(?:$|\\?)/i.test(u.pathname))return '';"+
                "return u.href;}catch(e){return '';}}"+
                "function pick(el){if(!el)return '';"+
                "var attr=['data-zoom-image','data-large-image','data-original','data-src','data-lazy-src','src'];"+
                "for(var k=0;k<attr.length;k++){var v=valid(el.getAttribute(attr[k]));if(v)return v;}"+
                "var sets=el.getAttribute('data-srcset')||el.getAttribute('srcset')||'';"+
                "if(sets){var seg=sets.split(',');for(var z=seg.length-1;z>=0;z--){"+
                "var w=valid(seg[z].trim().split(/\\s+/)[0]);if(w)return w;}}"+
                "return valid(el.currentSrc);}"+
                "var sels=['img[itemprop=image]','[itemprop=image] img',"+
                "'.product-detail__image img','.product-detail img',"+
                "'.productDetail__image img','.productDetail img',"+
                "'.product-image img','.productImage img',"+
                "'.p-productDetail__image img','.p-product-detail__image img',"+
                "'#mainImage img','#main-image img','#mainImage',"+
                "'.main-image img','.item-image img','.product-photo img',"+
                "'.product-photo__image img','.item-photo img','.itemPhoto img',"+
                "'.item-detail img','.itemDetail img','.item-detail__image img',"+
                "'#item_photo img','#item_image img','#productImg img',"+
                "'.swiper-slide-active img','.product_gallery img'];"+
                "for(var i=0;i<sels.length;i++){var e=document.querySelector(sels[i]);"+
                "if(e){var src=pick(e);if(src&&"+
                "((!e.naturalWidth||e.naturalWidth>=72)&&(!e.naturalHeight||e.naturalHeight>=72)))return src;}}"+
                // Fallback for small independent stores with no product CSS class.
                // Choose only one sizeable image inside the product's main content;
                // never take a header logo or a recommended-product carousel.
                "var scope=document.querySelector('main,[role=main],#main,.item-detail,.product-detail');"+
                "if(scope){var imgs=scope.querySelectorAll('img');var found='';var count=0;"+
                "for(var j=0;j<Math.min(100,imgs.length);j++){var e=imgs[j];"+
                "var hint=((e.id||'')+' '+(e.className||'')+' '+(e.alt||'')).toLowerCase();"+
                "if(/logo|banner|icon|payment|shipping|cart|social|recommend|関連|おすすめ/.test(hint))continue;"+
                "if((e.naturalWidth||0)<160||(e.naturalHeight||0)<160)continue;"+
                "var link=pick(e);if(!link)continue;found=link;count++;if(count>1)break;}"+
                "if(count===1)return found;}"+
                "var product=document.querySelector('main [itemtype*=Product], [itemtype*=Product]');"+
                "if(product){var e=product.querySelector('img');var s=pick(e);if(s)return s;}"+
                "var meta=document.querySelector('meta[property=\"og:image:secure_url\"],"+
                "meta[property=\"og:image\"],meta[name=\"twitter:image\"]');"+
                "return meta?valid(meta.content):'';"+
                "})()";
        try {
            view.evaluateJavascript(js, response -> {
                if (done || view != web) return;
                String link = null;
                try { link = new JSONArray("[" + response + "]").optString(0, ""); }
                catch (Exception ignored) { }
                if (isSafeImage(link)) finish(link);
                else if (inspections < MAX_INSPECTIONS) schedule(view, 1200);
                else finish(null);
            });
        } catch (Exception ignored) { finish(null); }
    }

    private static boolean isSafeImage(String value) {
        try {
            URL u = new URL(value);
            return "https".equalsIgnoreCase(u.getProtocol()) && WishlistCrawler.isAllowedUrl(u)
                    && !u.getPath().toLowerCase(Locale.ROOT).endsWith(".svg");
        } catch (Exception ignored) { return false; }
    }

    private void finish(String url) {
        if (done) return;
        done = true;
        main.removeCallbacks(timeout);
        Callback cb = callback;
        callback = null;
        if (web != null) {
            WebView old = web;
            web = null;
            try { old.stopLoading(); old.loadUrl("about:blank"); parent.removeView(old); old.destroy(); }
            catch (Exception ignored) { }
        }
        if (cb != null) cb.completed(url);
    }
    public void cancel() { callback = null; finish(null); }
}
