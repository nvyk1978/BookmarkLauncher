package com.cmyk.bookmarkslauncher.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class BookmarkRepository {
    private final BookmarksDbHelper helper;

    public BookmarkRepository(Context context) {
        helper = new BookmarksDbHelper(context.getApplicationContext());
    }

    public List<BookmarkNode> children(String parentId) {
        List<BookmarkNode> out = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        String selection = parentId == null ? "parent_id IS NULL AND deleted_at IS NULL" : "parent_id=? AND deleted_at IS NULL";
        String[] args = parentId == null ? null : new String[]{parentId};
        try (Cursor c = db.query("nodes", null, selection, args, null, null, "sort_index ASC, created_at ASC")) {
            while (c.moveToNext()) out.add(read(c));
        }
        return out;
    }

    public BookmarkNode get(String id) {
        SQLiteDatabase db = helper.getReadableDatabase();
        try (Cursor c = db.query("nodes", null, "id=?", new String[]{id}, null, null, null, "1")) {
            return c.moveToFirst() ? read(c) : null;
        }
    }

    public BookmarkNode createBookmark(String parentId, String title, String url) {
        long now = System.currentTimeMillis();
        BookmarkNode n = new BookmarkNode();
        n.id = UUID.randomUUID().toString();
        n.type = BookmarkNode.TYPE_BOOKMARK;
        n.parentId = parentId;
        n.title = title == null || title.isBlank() ? url : title;
        n.url = url;
        n.createdAt = now;
        n.updatedAt = now;
        n.sortIndex = nextSortIndex(parentId);
        insert(n);
        return n;
    }

    public BookmarkNode createFolder(String parentId, String title) {
        long now = System.currentTimeMillis();
        BookmarkNode n = new BookmarkNode();
        n.id = UUID.randomUUID().toString();
        n.type = BookmarkNode.TYPE_FOLDER;
        n.parentId = parentId;
        n.title = title == null || title.isBlank() ? "新しいフォルダ" : title;
        n.createdAt = now;
        n.updatedAt = now;
        n.sortIndex = nextSortIndex(parentId);
        insert(n);
        return n;
    }


    public BookmarkNode createFolderFromNodes(String parentId, String draggedId, String targetId) {
        List<BookmarkNode> before = children(parentId);
        int insertAt = before.size();
        for (int i = 0; i < before.size(); i++) {
            String id = before.get(i).id;
            if (id.equals(draggedId) || id.equals(targetId)) insertAt = Math.min(insertAt, i);
        }

        BookmarkNode folder = createFolder(parentId, "新しいフォルダ");
        moveToParent(targetId, folder.id);
        moveToParent(draggedId, folder.id);

        List<String> order = new ArrayList<>();
        for (BookmarkNode n : before) {
            if (!n.id.equals(draggedId) && !n.id.equals(targetId)) order.add(n.id);
        }
        insertAt = Math.max(0, Math.min(insertAt, order.size()));
        order.add(insertAt, folder.id);
        reorder(parentId, order);
        List<String> folderOrder = new ArrayList<>();
        folderOrder.add(targetId);
        folderOrder.add(draggedId);
        reorder(folder.id, folderOrder);
        return folder;
    }

    public boolean moveToParent(String id, String newParentId) {
        BookmarkNode node = get(id);
        if (node == null) return false;
        if (id.equals(newParentId)) return false;
        if (node.isFolder() && isDescendant(newParentId, id)) return false;

        String oldParentId = node.parentId;
        ContentValues v = new ContentValues();
        if (newParentId == null) v.putNull("parent_id"); else v.put("parent_id", newParentId);
        v.put("sort_index", nextSortIndex(newParentId));
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
        compactSort(oldParentId);
        compactSort(newParentId);
        return true;
    }

    private boolean isDescendant(String possibleChildId, String folderId) {
        if (possibleChildId == null) return false;
        String cursorId = possibleChildId;
        int guard = 0;
        while (cursorId != null && guard++ < 128) {
            if (cursorId.equals(folderId)) return true;
            BookmarkNode n = get(cursorId);
            if (n == null) return false;
            cursorId = n.parentId;
        }
        return false;
    }

    private void compactSort(String parentId) {
        List<BookmarkNode> items = children(parentId);
        List<String> ids = new ArrayList<>();
        for (BookmarkNode n : items) ids.add(n.id);
        reorder(parentId, ids);
    }

    public void touchAccess(String id) {
        ContentValues v = new ContentValues();
        long now = System.currentTimeMillis();
        v.put("last_accessed_at", now);
        v.put("updated_at", now);
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
    }

    public void resize(String id, int spanX, int spanY) {
        ContentValues v = new ContentValues();
        v.put("span_x", Math.max(1, Math.min(2, spanX)));
        v.put("span_y", Math.max(1, Math.min(2, spanY)));
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
    }

    public void reorder(String parentId, List<String> ids) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < ids.size(); i++) {
                ContentValues v = new ContentValues();
                v.put("sort_index", i);
                v.put("updated_at", System.currentTimeMillis());
                db.update("nodes", v, "id=?", new String[]{ids.get(i)});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public void softDelete(String id) {
        ContentValues v = new ContentValues();
        long now = System.currentTimeMillis();
        v.put("deleted_at", now);
        v.put("updated_at", now);
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
    }

    private int nextSortIndex(String parentId) {
        SQLiteDatabase db = helper.getReadableDatabase();
        String where = parentId == null ? "parent_id IS NULL" : "parent_id=?";
        String[] args = parentId == null ? null : new String[]{parentId};
        try (Cursor c = db.query("nodes", new String[]{"COALESCE(MAX(sort_index), -1)"}, where, args, null, null, null)) {
            return c.moveToFirst() ? c.getInt(0) + 1 : 0;
        }
    }

    private void insert(BookmarkNode n) {
        ContentValues v = new ContentValues();
        v.put("id", n.id);
        v.put("external_source", n.externalSource);
        v.put("external_id", n.externalId);
        v.put("type", n.type);
        v.put("parent_id", n.parentId);
        v.put("title", n.title);
        v.put("url", n.url);
        v.put("sort_index", n.sortIndex);
        v.put("span_x", n.spanX);
        v.put("span_y", n.spanY);
        v.put("created_at", n.createdAt);
        v.put("updated_at", n.updatedAt);
        helper.getWritableDatabase().insertOrThrow("nodes", null, v);
    }

    private BookmarkNode read(Cursor c) {
        BookmarkNode n = new BookmarkNode();
        n.id = s(c, "id");
        n.externalSource = s(c, "external_source");
        n.externalId = s(c, "external_id");
        n.type = i(c, "type");
        n.parentId = s(c, "parent_id");
        n.title = s(c, "title");
        n.url = s(c, "url");
        n.sortIndex = i(c, "sort_index");
        n.spanX = i(c, "span_x");
        n.spanY = i(c, "span_y");
        n.createdAt = l(c, "created_at");
        n.updatedAt = l(c, "updated_at");
        n.lastAccessedAt = nullableLong(c, "last_accessed_at");
        n.deletedAt = nullableLong(c, "deleted_at");
        n.faviconPath = s(c, "favicon_path");
        n.screenshotPath = s(c, "screenshot_path");
        n.offlinePath = s(c, "offline_path");
        n.offlineSavedAt = nullableLong(c, "offline_saved_at");
        return n;
    }

    private static String s(Cursor c, String name) { int x = c.getColumnIndexOrThrow(name); return c.isNull(x) ? null : c.getString(x); }
    private static int i(Cursor c, String name) { return c.getInt(c.getColumnIndexOrThrow(name)); }
    private static long l(Cursor c, String name) { return c.getLong(c.getColumnIndexOrThrow(name)); }
    private static Long nullableLong(Cursor c, String name) { int x = c.getColumnIndexOrThrow(name); return c.isNull(x) ? null : c.getLong(x); }
}
