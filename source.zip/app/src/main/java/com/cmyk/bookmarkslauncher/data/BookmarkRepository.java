package com.cmyk.bookmarkslauncher.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class BookmarkRepository {
    private final BookmarksDbHelper helper;

    public BookmarkRepository(Context context) {
        helper = new BookmarksDbHelper(context.getApplicationContext());
    }

    public List<BookmarkNode> children(String parentId) {
        List<BookmarkNode> out = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        String selection = parentId == null ? "parent_id IS NULL AND deleted_at IS NULL" : "parent_id=? AND deleted_at IS NULL";
        String[] args = parentId == null ? null : new String[]{parentId};
        try (Cursor c = db.query("nodes", null, selection, args, null, null,
                "CASE WHEN cell_y < 0 THEN 1 ELSE 0 END, cell_y ASC, cell_x ASC, sort_index ASC, created_at ASC")) {
            while (c.moveToNext()) out.add(read(c));
        }
        return out;
    }

    public BookmarkNode get(String id) {
        SQLiteDatabase db = helper.getReadableDatabase();
        try (Cursor c = db.query("nodes", null, "id=?", new String[]{id}, null, null, null, "1")) {
            return c.moveToFirst() ? read(c) : null;
        }
    }

    public BookmarkNode createBookmark(String parentId, String title, String url) {
        long now = System.currentTimeMillis();
        BookmarkNode n = new BookmarkNode();
        n.id = UUID.randomUUID().toString();
        n.type = BookmarkNode.TYPE_BOOKMARK;
        n.parentId = parentId;
        n.title = title == null || title.isBlank() ? url : title;
        n.url = url;
        n.createdAt = now;
        n.updatedAt = now;
        n.sortIndex = nextSortIndex(parentId);
        insert(n);
        return n;
    }

    public BookmarkNode createFolder(String parentId, String title) {
        long now = System.currentTimeMillis();
        BookmarkNode n = new BookmarkNode();
        n.id = UUID.randomUUID().toString();
        n.type = BookmarkNode.TYPE_FOLDER;
        n.parentId = parentId;
        n.title = title == null || title.isBlank() ? "新しいフォルダ" : title;
        n.createdAt = now;
        n.updatedAt = now;
        n.sortIndex = nextSortIndex(parentId);
        insert(n);
        return n;
    }

    public BookmarkNode createFolderFromNodes(String parentId, String draggedId, String targetId) {
        BookmarkNode target = get(targetId);
        int targetX = target == null ? -1 : target.cellX;
        int targetY = target == null ? -1 : target.cellY;

        BookmarkNode folder = createFolder(parentId, "新しいフォルダ");
        moveToParent(targetId, folder.id);
        moveToParent(draggedId, folder.id);
        updatePosition(folder.id, targetX, targetY);
        ensurePositions(folder.id, 4, 5);
        return folder;
    }

    public boolean moveToParent(String id, String newParentId) {
        BookmarkNode node = get(id);
        if (node == null) return false;
        if (id.equals(newParentId)) return false;
        if (node.isFolder() && isDescendant(newParentId, id)) return false;

        String oldParentId = node.parentId;
        ContentValues v = new ContentValues();
        if (newParentId == null) v.putNull("parent_id"); else v.put("parent_id", newParentId);
        v.put("sort_index", nextSortIndex(newParentId));
        v.put("cell_x", -1);
        v.put("cell_y", -1);
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
        compactSort(oldParentId);
        compactSort(newParentId);
        return true;
    }

    private boolean isDescendant(String possibleChildId, String folderId) {
        if (possibleChildId == null) return false;
        String cursorId = possibleChildId;
        int guard = 0;
        while (cursorId != null && guard++ < 128) {
            if (cursorId.equals(folderId)) return true;
            BookmarkNode n = get(cursorId);
            if (n == null) return false;
            cursorId = n.parentId;
        }
        return false;
    }

    private void compactSort(String parentId) {
        List<BookmarkNode> items = children(parentId);
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < items.size(); i++) {
                ContentValues v = new ContentValues();
                v.put("sort_index", i);
                db.update("nodes", v, "id=?", new String[]{items.get(i).id});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }


    public void rename(String id, String title) {
        if (title == null || title.isBlank()) return;
        ContentValues v = new ContentValues();
        v.put("title", title.trim());
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
    }

    public boolean moveToParentAtPosition(String id, String newParentId, int cellX, int cellY) {
        BookmarkNode node = get(id);
        if (node == null) return false;
        if (id.equals(newParentId)) return false;
        if (node.isFolder() && isDescendant(newParentId, id)) return false;

        String oldParentId = node.parentId;
        ContentValues v = new ContentValues();
        if (newParentId == null) v.putNull("parent_id"); else v.put("parent_id", newParentId);
        v.put("sort_index", nextSortIndex(newParentId));
        v.put("cell_x", Math.max(0, cellX));
        v.put("cell_y", Math.max(0, cellY));
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
        compactSort(oldParentId);
        return true;
    }

    public void deletePreservingFolderChildren(String id) {
        BookmarkNode node = get(id);
        if (node == null) return;
        if (!node.isFolder()) {
            softDelete(id);
            return;
        }

        List<BookmarkNode> directChildren = children(id);
        String destinationParent = node.parentId;
        int next = nextSortIndex(destinationParent);
        long now = System.currentTimeMillis();
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (BookmarkNode child : directChildren) {
                ContentValues v = new ContentValues();
                if (destinationParent == null) v.putNull("parent_id"); else v.put("parent_id", destinationParent);
                v.put("sort_index", next++);
                v.put("cell_x", -1);
                v.put("cell_y", -1);
                v.put("updated_at", now);
                db.update("nodes", v, "id=?", new String[]{child.id});
            }

            ContentValues deleted = new ContentValues();
            deleted.put("deleted_at", now);
            deleted.put("updated_at", now);
            db.update("nodes", deleted, "id=?", new String[]{id});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        compactSort(destinationParent);
    }

    public void touchAccess(String id) {
        ContentValues v = new ContentValues();
        long now = System.currentTimeMillis();
        v.put("last_accessed_at", now);
        v.put("updated_at", now);
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
    }

    public void resize(String id, int spanX, int spanY) {
        ContentValues v = new ContentValues();
        v.put("span_x", Math.max(1, Math.min(2, spanX)));
        v.put("span_y", Math.max(1, Math.min(2, spanY)));
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
    }

    public void updatePosition(String id, int cellX, int cellY) {
        ContentValues v = new ContentValues();
        v.put("cell_x", cellX);
        v.put("cell_y", cellY);
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
    }

    public void updatePositions(String parentId, List<BookmarkNode> items) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            List<BookmarkNode> sorted = new ArrayList<>(items);
            sorted.sort((a, b) -> {
                int y = Integer.compare(a.cellY, b.cellY);
                if (y != 0) return y;
                int x = Integer.compare(a.cellX, b.cellX);
                if (x != 0) return x;
                return a.id.compareTo(b.id);
            });
            for (int i = 0; i < sorted.size(); i++) {
                BookmarkNode n = sorted.get(i);
                ContentValues v = new ContentValues();
                v.put("cell_x", n.cellX);
                v.put("cell_y", n.cellY);
                v.put("sort_index", i);
                v.put("updated_at", System.currentTimeMillis());
                db.update("nodes", v, "id=?", new String[]{n.id});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public void ensurePositions(String parentId, int columns, int rows) {
        List<BookmarkNode> items = children(parentId);
        if (items.isEmpty()) return;
        boolean[][] occupied = new boolean[Math.max(1, rows)][Math.max(1, columns)];
        boolean changed = false;

        for (BookmarkNode n : items) {
            int sx = Math.max(1, Math.min(columns, n.spanX));
            int sy = Math.max(1, Math.min(rows, n.spanY));
            if (fits(occupied, n.cellX, n.cellY, sx, sy)) {
                mark(occupied, n.cellX, n.cellY, sx, sy, true);
            } else {
                n.cellX = -1;
                n.cellY = -1;
                changed = true;
            }
        }

        for (BookmarkNode n : items) {
            if (n.cellX >= 0 && n.cellY >= 0) continue;
            int sx = Math.max(1, Math.min(columns, n.spanX));
            int sy = Math.max(1, Math.min(rows, n.spanY));
            int[] p = firstFit(occupied, columns, rows, sx, sy);
            if (p != null) {
                n.cellX = p[0];
                n.cellY = p[1];
                mark(occupied, p[0], p[1], sx, sy, true);
                changed = true;
            }
        }

        if (changed) updatePositions(parentId, items);
    }

    private static int[] firstFit(boolean[][] occupied, int columns, int rows, int spanX, int spanY) {
        for (int y = 0; y <= rows - spanY; y++) {
            for (int x = 0; x <= columns - spanX; x++) {
                if (fits(occupied, x, y, spanX, spanY)) return new int[]{x, y};
            }
        }
        return null;
    }

    private static boolean fits(boolean[][] occupied, int x, int y, int spanX, int spanY) {
        if (x < 0 || y < 0 || y + spanY > occupied.length || x + spanX > occupied[0].length) return false;
        for (int yy = y; yy < y + spanY; yy++) {
            for (int xx = x; xx < x + spanX; xx++) {
                if (occupied[yy][xx]) return false;
            }
        }
        return true;
    }

    private static void mark(boolean[][] occupied, int x, int y, int spanX, int spanY, boolean value) {
        if (x < 0 || y < 0) return;
        for (int yy = y; yy < y + spanY && yy < occupied.length; yy++) {
            for (int xx = x; xx < x + spanX && xx < occupied[0].length; xx++) {
                occupied[yy][xx] = value;
            }
        }
    }

    public void reorder(String parentId, List<String> ids) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < ids.size(); i++) {
                ContentValues v = new ContentValues();
                v.put("sort_index", i);
                v.put("updated_at", System.currentTimeMillis());
                db.update("nodes", v, "id=?", new String[]{ids.get(i)});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public void softDelete(String id) {
        ContentValues v = new ContentValues();
        long now = System.currentTimeMillis();
        v.put("deleted_at", now);
        v.put("updated_at", now);
        helper.getWritableDatabase().update("nodes", v, "id=?", new String[]{id});
    }

    private int nextSortIndex(String parentId) {
        SQLiteDatabase db = helper.getReadableDatabase();
        String where = parentId == null ? "parent_id IS NULL" : "parent_id=?";
        String[] args = parentId == null ? null : new String[]{parentId};
        try (Cursor c = db.query("nodes", new String[]{"COALESCE(MAX(sort_index), -1)"}, where, args, null, null, null)) {
            return c.moveToFirst() ? c.getInt(0) + 1 : 0;
        }
    }

    private void insert(BookmarkNode n) {
        ContentValues v = new ContentValues();
        v.put("id", n.id);
        v.put("external_source", n.externalSource);
        v.put("external_id", n.externalId);
        v.put("type", n.type);
        v.put("parent_id", n.parentId);
        v.put("title", n.title);
        v.put("url", n.url);
        v.put("sort_index", n.sortIndex);
        v.put("cell_x", n.cellX);
        v.put("cell_y", n.cellY);
        v.put("span_x", n.spanX);
        v.put("span_y", n.spanY);
        v.put("created_at", n.createdAt);
        v.put("updated_at", n.updatedAt);
        helper.getWritableDatabase().insertOrThrow("nodes", null, v);
    }

    private BookmarkNode read(Cursor c) {
        BookmarkNode n = new BookmarkNode();
        n.id = s(c, "id");
        n.externalSource = s(c, "external_source");
        n.externalId = s(c, "external_id");
        n.type = i(c, "type");
        n.parentId = s(c, "parent_id");
        n.title = s(c, "title");
        n.url = s(c, "url");
        n.sortIndex = i(c, "sort_index");
        n.cellX = i(c, "cell_x");
        n.cellY = i(c, "cell_y");
        n.spanX = i(c, "span_x");
        n.spanY = i(c, "span_y");
        n.createdAt = l(c, "created_at");
        n.updatedAt = l(c, "updated_at");
        n.lastAccessedAt = nullableLong(c, "last_accessed_at");
        n.deletedAt = nullableLong(c, "deleted_at");
        n.faviconPath = s(c, "favicon_path");
        n.screenshotPath = s(c, "screenshot_path");
        n.offlinePath = s(c, "offline_path");
        n.offlineSavedAt = nullableLong(c, "offline_saved_at");
        return n;
    }

    private static String s(Cursor c, String name) { int x = c.getColumnIndexOrThrow(name); return c.isNull(x) ? null : c.getString(x); }
    private static int i(Cursor c, String name) { return c.getInt(c.getColumnIndexOrThrow(name)); }
    private static long l(Cursor c, String name) { return c.getLong(c.getColumnIndexOrThrow(name)); }
    private static Long nullableLong(Cursor c, String name) { int x = c.getColumnIndexOrThrow(name); return c.isNull(x) ? null : c.getLong(x); }
}
