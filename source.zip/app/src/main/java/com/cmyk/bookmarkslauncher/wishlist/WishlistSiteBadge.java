package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;

/**
 * Presentation-only site chip for Wish cards. Does not change persisted modes,
 * crawler dispatch, product identity, prices, names, stock, or saved URLs.
 */
public final class WishlistSiteBadge {
    private WishlistSiteBadge() {}

    public static String forCard(String savedUrl, WishlistMode savedMode) {
        String urlLabel = forSavedUrl(savedUrl);
        if (!urlLabel.isEmpty()) return urlLabel;
        return savedMode == null ? "" : savedMode.cardLabel();
    }

    public static String forSavedUrl(String raw) {
        if (raw == null || raw.isBlank()) return "";
        try {
            URL u = new URL(raw.trim());
            String scheme = u.getProtocol();
            if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) return "";
            String host = u.getHost().toLowerCase(Locale.ROOT);
            if (onHost(host, "zozo.jp")) return "ZOZO";
            if (onHost(host, "nitori-net.jp") || onHost(host, "nitori.co.jp")) return "ニトリ";
            if (onHost(host, "askul.co.jp")) return "ASKUL";
            if (onHost(host, "monotaro.com")) return "モノタロウ";
        } catch (Exception ignored) { }
        return "";
    }

    private static boolean onHost(String host, String domain) {
        // A lookalike suffix (e.g. fake-zozo.jp or zozo.jp.evil.test) is not a shop.
        return host.equals(domain) || host.endsWith("." + domain);
    }
}
