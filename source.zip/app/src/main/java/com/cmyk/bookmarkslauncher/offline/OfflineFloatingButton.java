package com.cmyk.bookmarkslauncher.offline;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.cmyk.bookmarkslauncher.R;

/** N-style circular save/update control used by OfflineWebActivity. */
final class OfflineFloatingButton extends FrameLayout {
    private static final int D_GRAY = 0xFF252020;
    private static final int ICON = 0xFFA9A999;
    private final ImageView icon;

    OfflineFloatingButton(Context context) {
        super(context);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(D_GRAY);
        setBackground(bg);
        setClickable(true);
        setFocusable(true);
        setElevation(dp(8));

        icon = new ImageView(context);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        icon.setImageTintList(ColorStateList.valueOf(ICON));
        int inset = dp(10);
        LayoutParams p = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER);
        p.setMargins(inset, inset, inset, inset);
        addView(icon, p);
        setSaved(false);
    }

    void setSaved(boolean saved) {
        icon.setImageResource(saved ? R.drawable.ic_offline_refresh : R.drawable.ic_offline_add);
    }

    void setIconColor(int color) {
        icon.setImageTintList(ColorStateList.valueOf(color));
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
