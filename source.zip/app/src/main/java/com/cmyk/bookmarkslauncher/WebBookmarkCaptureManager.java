package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;

import org.json.JSONTokener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One-shot hidden WebView used to refresh bookmark metadata, favicon and a 1:1 top-page thumbnail.
 * The WebView is attached off-screen so it still has a real layout/draw pass.
 */
final class WebBookmarkCaptureManager {
    interface Listener {
        void onComplete(boolean success, BookmarkNode updatedNode, String message);
    }

    private final Activity activity;
    private final FrameLayout host;
    private final BookmarkRepository repo;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private WebView webView;
    private Bitmap receivedIcon;
    private String activeNodeId;
    private Runnable pendingFinish;
    private int finishAttempts;
    /** Invalidates late asynchronous Threads results after a new capture/cancel. */
    private volatile long captureSession;

    WebBookmarkCaptureManager(Activity activity, FrameLayout host, BookmarkRepository repo) {
        this.activity = activity;
        this.host = host;
        this.repo = repo;
    }

    public void capture(BookmarkNode node, Listener listener) {
        if (node == null || node.url == null || node.url.isBlank()) {
            if (listener != null) listener.onComplete(false, node, "URLがありません");
            return;
        }
        host.post(() -> startCapture(node.id, node.url, listener));
    }

    void cancel() {
        cancelActive();
    }

    public void destroy() {
        cancelActive();
        io.shutdownNow();
    }

    private void startCapture(String nodeId, String url, Listener listener) {
        cancelActive();
        activeNodeId = nodeId;
        receivedIcon = null;
        finishAttempts = 0;

        WebView w = new WebView(activity);
        webView = w;
        // Keep the capture WebView fully off-screen/transparent while still laid out and drawable.
        // Direct webView.draw(canvas) below still captures its contents without flashing its
        // default background behind the N dialog/home UI.
        w.setBackgroundColor(Color.TRANSPARENT);
        w.setAlpha(0f);
        w.setVerticalScrollBarEnabled(false);
        w.setHorizontalScrollBarEnabled(false);
        WebSettings settings = w.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        int screenWidth = Math.max(1, activity.getResources().getDisplayMetrics().widthPixels);
        int renderWidth = Math.min(1080, Math.max(720, screenWidth));
        int renderHeight = Math.max(renderWidth * 2, 1280);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(renderWidth, renderHeight);
        lp.leftMargin = -renderWidth - 64;
        lp.topMargin = 0;
        host.addView(w, lp);

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onReceivedIcon(WebView view, Bitmap icon) {
                if (!nodeId.equals(activeNodeId) || icon == null) return;
                receivedIcon = icon.copy(Bitmap.Config.ARGB_8888, false);
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String loadedUrl) {
                if (!nodeId.equals(activeNodeId)) return;
                scheduleFinish(nodeId, url, listener, 850L);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame() && nodeId.equals(activeNodeId)) {
                    // Some pages report a transient resource error before a redirect succeeds.
                    scheduleFinish(nodeId, url, listener, 1200L);
                }
            }
        });

        w.loadUrl(url);
    }

    private void scheduleFinish(String nodeId, String originalUrl, Listener listener, long delayMs) {
        if (pendingFinish != null) main.removeCallbacks(pendingFinish);
        pendingFinish = () -> finishCapture(nodeId, originalUrl, listener);
        main.postDelayed(pendingFinish, delayMs);
    }

    private void finishCapture(String nodeId, String originalUrl, Listener listener) {
        WebView w = webView;
        if (w == null || !nodeId.equals(activeNodeId)) return;
        if (w.getProgress() < 100 && finishAttempts++ < 3) {
            scheduleFinish(nodeId, originalUrl, listener, 500L);
            return;
        }

        w.scrollTo(0, 0);
        final boolean isThreads = ThreadsBookmarkMetadata.handles(originalUrl);
        final long session = captureSession;
        String pageTitle = clean(w.getTitle());
        String siteScript = "(function(){" +
                "var a=['meta[property=\\\"og:site_name\\\"]','meta[name=\\\"application-name\\\"]','meta[name=\\\"apple-mobile-web-app-title\\\"]'];" +
                "for(var i=0;i<a.length;i++){var e=document.querySelector(a[i]);if(e&&e.content)return e.content;}return '';})()";
        String iconScript = "(function(){var e=document.querySelector('link[rel~=\\\"icon\\\"]');return e&&e.href?e.href:'';})()";
        String titleScript = isThreads ? ThreadsBookmarkMetadata.javascript() : "null";

        w.evaluateJavascript(siteScript, siteValue -> {
            if (!nodeId.equals(activeNodeId) || webView != w) return;
            String siteName = isThreads ? "Threads" : cleanJs(siteValue);
            if (siteName == null || siteName.isBlank())
                siteName = fallbackSiteName(w.getUrl() == null ? originalUrl : w.getUrl());
            final String finalSiteName = siteName;

            w.evaluateJavascript(titleScript, threadValue -> {
                if (!nodeId.equals(activeNodeId) || webView != w) return;
                ThreadsBookmarkMetadata.Result threadPost = isThreads
                        ? ThreadsBookmarkMetadata.fromJavascript(threadValue, originalUrl) : null;
                // A share-code link alone contains no post identity. Never save
                // the title of a login page, verification view or Threads home.
                final String finalTitle = isThreads
                        ? (threadPost == null ? null : threadPost.title) : pageTitle;
                w.evaluateJavascript(iconScript, iconValue -> {
                    if (!nodeId.equals(activeNodeId) || webView != w) return;
                    String iconUrl = cleanJs(iconValue);
                    try {
                        File assets = new File(activity.getFilesDir(), "bookmark_assets");
                        if (!assets.exists() && !assets.mkdirs()) throw new IllegalStateException("asset directory");

                        File screenshot = new File(assets, nodeId + "_thumb.jpg");
                        String screenshotPath = null;
                        try {
                            saveSquareScreenshot(w, screenshot);
                            screenshotPath = screenshot.getAbsolutePath();
                        } catch (Exception captureError) {
                            // Threads may intentionally expose only an external
                            // public preview. Do not let a failed GPU screenshot
                            // suppress the verified public metadata fallback.
                            if (!isThreads) throw captureError;
                            android.util.Log.w("BookmarkCapture", "threads screenshot unavailable");
                        }

                        String faviconPath = null;
                        if (receivedIcon != null) {
                            File favicon = new File(assets, nodeId + "_favicon.png");
                            saveBitmap(receivedIcon, favicon, Bitmap.CompressFormat.PNG, 100);
                            faviconPath = favicon.getAbsolutePath();
                        }

                        repo.updateWebMetadata(nodeId, finalSiteName, finalTitle,
                                faviconPath, screenshotPath);
                        if (isThreads) {
                            // Screenshot/blank HTML is not a successful Threads post
                            // capture. Emit exactly ONE completion after verified post
                            // evidence, or explicitly fail; never a false-positive.
                            fetchThreadsPublicMetadataAsync(nodeId, originalUrl,
                                    threadPost, assets, session, listener);
                        } else {
                            BookmarkNode updated = repo.get(nodeId);
                            if (listener != null) listener.onComplete(true, updated, null);
                        }
                        if (faviconPath == null) {
                            String candidate = iconUrl;
                            if (candidate == null || candidate.isBlank())
                                candidate = defaultFaviconUrl(w.getUrl() == null ? originalUrl : w.getUrl());
                            fetchFaviconAsync(nodeId, candidate, assets, isThreads ? null : listener);
                        }
                    } catch (Exception e) {
                        BookmarkNode updated = repo.get(nodeId);
                        if (listener != null) listener.onComplete(false, updated, "サムネイル取得に失敗しました");
                    } finally {
                        clearWebView(nodeId);
                    }
                });
            });
        });
    }

    private void fetchThreadsPublicMetadataAsync(String nodeId, String originalUrl,
                                                  ThreadsBookmarkMetadata.Result fromPage,
                                                  File assets, long session, Listener listener) {
        io.execute(() -> {
            // A resolved post from the live DOM takes precedence. The HTTP
            // fallback uses only public HTTPS pages and exact official post
            // permalink/canonical evidence; it never accepts a login shell.
            ThreadsBookmarkMetadata.Result result = fromPage != null
                    ? fromPage : ThreadsBookmarkMetadata.fetchPublic(originalUrl);
            if (session != captureSession) return;
            BookmarkNode current = repo.get(nodeId);
            if (current == null || current.deletedAt != null || !originalUrl.equals(current.url)) {
                main.post(() -> {
                    if (session == captureSession && listener != null)
                        listener.onComplete(false, repo.get(nodeId), "ブックマークのURLが変更されました");
                });
                return;
            }
            boolean verified = result != null && result.title != null && !result.title.isBlank();
            boolean imageSaved = false;
            if (verified) {
                repo.updateWebMetadata(nodeId, "Threads", result.title, null, null);
                imageSaved = saveThreadsPublicPreview(nodeId, originalUrl, result.imageUrl, assets, session);
            }
            final boolean complete = verified;
            final boolean saved = imageSaved;
            android.util.Log.i("BookmarkCapture", "threads.post.done verified=" + complete
                    + " image=" + saved + " urlKind="
                    + (ThreadsBookmarkMetadata.share(originalUrl) ? "share" : "permalink"));
            main.post(() -> {
                if (session != captureSession || listener == null) return;
                listener.onComplete(complete, repo.get(nodeId), complete ? null
                        : "Threadsの投稿情報を確認できませんでした（ログイン・転送・公開範囲を確認）");
            });
        });
    }

    /** Never fetch an arbitrary OG image: ThreadsBookmarkMetadata limits the
     * host to official public media CDNs, and redirects are not followed. */
    private boolean saveThreadsPublicPreview(String id, String originalUrl, String imageUrl,
                                             File assets, long session) {
        if (imageUrl == null || imageUrl.isBlank() || session != captureSession) return false;
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(imageUrl).openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(3200);
            conn.setReadTimeout(3800);
            conn.setRequestProperty("Accept", "image/jpeg,image/png,image/webp");
            if (conn.getResponseCode() != 200) return false;
            String type = conn.getContentType();
            if (type == null || !type.toLowerCase(java.util.Locale.ROOT).startsWith("image/")) return false;
            int length = conn.getContentLength();
            if (length > 4_000_000) return false;
            byte[] bytes;
            try (InputStream in = conn.getInputStream();
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int n;
                while ((n = in.read(buffer)) != -1) {
                    if (out.size() + n > 4_000_000) return false;
                    out.write(buffer, 0, n);
                }
                bytes = out.toByteArray();
            }
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
            if (opts.outWidth < 80 || opts.outHeight < 80) return false;
            opts.inJustDecodeBounds = false;
            opts.inSampleSize = Math.max(1, Math.max(opts.outWidth, opts.outHeight) / 1024);
            Bitmap source = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
            if (source == null) return false;
            Bitmap cropped = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888);
            try {
                Canvas canvas = new Canvas(cropped);
                float side = Math.min(source.getWidth(), source.getHeight());
                int left = Math.round((source.getWidth() - side) / 2f);
                int top = Math.round((source.getHeight() - side) / 2f);
                canvas.drawBitmap(source,
                        new Rect(left, top, left + (int) side, top + (int) side),
                        new Rect(0, 0, 512, 512), null);
                if (session != captureSession) return false;
                BookmarkNode node = repo.get(id);
                if (node == null || node.deletedAt != null || !originalUrl.equals(node.url)) return false;
                File file = new File(assets, id + "_thumb.jpg");
                saveBitmap(cropped, file, Bitmap.CompressFormat.JPEG, 88);
                repo.updateWebMetadata(id, "Threads", null, null, file.getAbsolutePath());
                return true;
            } finally { cropped.recycle(); source.recycle(); }
        } catch (Exception ignored) { return false; }
        finally { if (conn != null) conn.disconnect(); }
    }

    private void fetchFaviconAsync(String nodeId, String iconUrl, File assets, Listener listener) {
        if (iconUrl == null || iconUrl.isBlank()) return;
        io.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(iconUrl).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 Android BookmarkLauncher");
                if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 400) return;
                Bitmap bitmap = android.graphics.BitmapFactory.decodeStream(connection.getInputStream());
                if (bitmap == null) return;
                File favicon = new File(assets, nodeId + "_favicon.png");
                saveBitmap(bitmap, favicon, Bitmap.CompressFormat.PNG, 100);
                repo.updateFaviconPath(nodeId, favicon.getAbsolutePath());
                activity.runOnUiThread(() -> {
                    if (listener != null) listener.onComplete(true, repo.get(nodeId), null);
                });
            } catch (Exception ignored) {
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private static void saveSquareScreenshot(WebView webView, File target) throws Exception {
        int side = Math.max(1, Math.min(webView.getWidth(), webView.getHeight()));
        Bitmap bitmap = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
        // The host WebView is visually hidden with alpha=0. A direct
        // draw() must temporarily remove that alpha, otherwise some Android
        // WebView/GPU implementations capture an all-white thumbnail.
        float alpha = webView.getAlpha();
        try {
            webView.setAlpha(1f);
            webView.draw(canvas);
        } finally {
            webView.setAlpha(alpha);
        }
        saveBitmap(bitmap, target, Bitmap.CompressFormat.JPEG, 90);
        bitmap.recycle();
    }

    private static void saveBitmap(Bitmap bitmap, File file, Bitmap.CompressFormat format, int quality) throws Exception {
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            if (!bitmap.compress(format, quality, out)) throw new IllegalStateException("compress failed");
            out.flush();
        }
    }

    private void cancelActive() {
        captureSession++;
        if (pendingFinish != null) {
            main.removeCallbacks(pendingFinish);
            pendingFinish = null;
        }
        if (webView != null) {
            try {
                webView.stopLoading();
                host.removeView(webView);
                webView.destroy();
            } catch (Exception ignored) {
            }
            webView = null;
        }
        receivedIcon = null;
        activeNodeId = null;
    }

    private void clearWebView(String nodeId) {
        if (!nodeId.equals(activeNodeId)) return;
        if (webView != null) {
            WebView old = webView;
            webView = null;
            host.removeView(old);
            old.destroy();
        }
        pendingFinish = null;
        receivedIcon = null;
        activeNodeId = null;
    }

    private static String clean(String value) {
        if (value == null) return null;
        String v = value.trim();
        return v.isEmpty() ? null : v;
    }

    private static String cleanJs(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            Object parsed = new JSONTokener(value).nextValue();
            if (parsed == null) return null;
            return clean(String.valueOf(parsed));
        } catch (Exception ignored) {
            return clean(value.replace("\\\"", "\"").replaceAll("^\"|\"$", ""));
        }
    }

    private static String fallbackSiteName(String url) {
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            if (host == null || host.isBlank()) return "ブックマーク";
            if (host.startsWith("www.")) host = host.substring(4);
            String[] parts = host.split("\\.");
            String base = parts.length == 0 ? host : parts[0];
            if (base.isBlank()) return host;
            return Character.toUpperCase(base.charAt(0)) + base.substring(1);
        } catch (Exception ignored) {
            return "ブックマーク";
        }
    }

    private static String defaultFaviconUrl(String url) {
        try {
            Uri uri = Uri.parse(url);
            if (uri.getScheme() == null || uri.getHost() == null) return null;
            return uri.getScheme() + "://" + uri.getHost() + "/favicon.ico";
        } catch (Exception ignored) {
            return null;
        }
    }
}
