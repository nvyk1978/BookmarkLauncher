package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Product-image ONLY for Rakuten/Yahoo; no page-wide image enumeration. */
final class YahooImageExtractor {
    private static final Pattern META=Pattern.compile("(?is)<meta\\b[^>]*>");
    private static final Pattern ATTR=Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')",Pattern.CASE_INSENSITIVE);
    private static final Pattern IMAGE=Pattern.compile("(?is)<img\\b[^>]*>");
    private static final Pattern HERO=Pattern.compile("(?i)(?:^|[-_\\s])(?:main|product|item|goods)[-_]?(?:image|img|photo|picture|gallery)(?:$|[-_\\s])|itemImg|item-image|image-main");
    private static final Pattern REJECT=Pattern.compile("(?i)recommend|related|ranking|sidebar|review|banner|logo|placeholder|noimage|no-image|tracking|icon|avatar|advertis");
    private YahooImageExtractor(){}
    static List<String> candidates(String html,URL page){
        MarketplaceIdentity identity=MarketplaceIdentity.from(page);
        if(identity==null||identity.site!=MarketplaceIdentity.Site.YAHOO||!identity.verified(html,page))return java.util.Collections.emptyList();
        LinkedHashSet<String> urls=new LinkedHashSet<>();
        JSONObject product=YahooProductJsonLd.find(html,page);
        if(product!=null)readImages(product.opt("image"),page,urls,0);
        // A canonical-verified product's own OGP is safer than unknown thumbnail rows.
        Matcher meta=META.matcher(html);
        while(meta.find()){
            String tag=meta.group();
            String property=first(attr(tag,"property"),attr(tag,"name"));
            if(property!=null&&(property.equalsIgnoreCase("og:image")||property.equalsIgnoreCase("og:image:secure_url")||property.equalsIgnoreCase("twitter:image"))){
                add(page,attr(tag,"content"),urls);
            }
        }
        // If OGP and Product JSON-LD are unavailable, only images marked as
        // the PRIMARY product/gallery image qualify; never take the first <img>.
        if(urls.isEmpty()){
            Matcher images=IMAGE.matcher(html);
            while(images.find()){
                String tag=images.group();
                String marker=first(attr(tag,"id"),attr(tag,"class"));
                if(marker==null||!HERO.matcher(marker).find()||REJECT.matcher(marker).find())continue;
                for(String a:new String[]{"data-zoom-image","data-large-image","data-original","data-src","src"})add(page,attr(tag,a),urls);
                if(!urls.isEmpty())break;
            }
        }
        return new ArrayList<>(urls);
    }
    private static void readImages(Object node,URL page,LinkedHashSet<String> list,int depth){
        if(node==null||depth>4||list.size()>=8)return;
        if(node instanceof String){add(page,(String)node,list);}
        else if(node instanceof JSONArray){JSONArray arr=(JSONArray)node;for(int n=0;n<Math.min(8,arr.length());n++)readImages(arr.opt(n),page,list,depth+1);}
        else if(node instanceof JSONObject){JSONObject obj=(JSONObject)node;readImages(obj.opt("url"),page,list,depth+1);readImages(obj.opt("contentUrl"),page,list,depth+1);}
    }
    private static void add(URL page,String raw,LinkedHashSet<String> list){
        if(raw==null||raw.isBlank())return;
        try{
            URL u=new URL(page,raw.replace("&amp;","&").replace("&#38;","&"));
            if(!"https".equalsIgnoreCase(u.getProtocol())||!WishlistCrawler.isAllowedUrl(u))return;
            if(REJECT.matcher(u.getPath()).find())return;
            list.add(u.toString());
        }catch(Exception ignored){}
    }
    private static String attr(String tag,String name){Matcher m=ATTR.matcher(tag);while(m.find())if(name.equalsIgnoreCase(m.group(1)))return m.group(2)!=null?m.group(2):m.group(3);return null;}
    private static String first(String a,String b){return a!=null?a:b;}
}
