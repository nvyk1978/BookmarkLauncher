package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;

/** Read-only SHEIN-only price and purchase evidence from the SAME rendered item.
 * This does not navigate, click, call an API or inspect unrelated storefronts.
 * An item URL + matching canonical/heading is a prerequisite to DOM evidence.
 */
final class WishlistSheinItemDom {
    private WishlistSheinItemDom() { }

    static String javascript(URL saved) {
        if (saved == null || !saved.getHost().toLowerCase(Locale.ROOT).endsWith("shein.com"))
            return "'{}'";
        String id = WishlistGeneralMarketplaceIdentity.itemId(saved);
        if (id == null) return "'{}'";
        return SCRIPT.replace("__ITEM__", id);
    }

    private static final String SCRIPT = """
(function(){'use strict';
const item='__ITEM__';
const out={value:'',currency:'',priceSource:'none',priceNodes:0,priceTokens:0,
  priceLabel:false,stock:'UNKNOWN',stockReason:'not-inspected',cartCount:0,
  productHeading:false,identity:'unverified',jsonOffers:0};
try{
 const itemId=raw=>{try{
  const u=new URL(raw,location.href);
  if(u.protocol!=='https:'||!(u.hostname.toLowerCase()==='shein.com'||u.hostname.toLowerCase().endsWith('.shein.com')))return '';
  const m=u.pathname.match(/(?:^|[-/])p-([0-9]{5,15})(?:-cat-[0-9]{1,12})?\\.html$/i);
  return m?m[1]:'';
 }catch(_){return ''}};
 const current=itemId(location.href);
 if(current&&current!==item){out.identity='other-item';return JSON.stringify(out);}
 const canonical=document.querySelector('link[rel="canonical"]');
 const canon=canonical?(canonical.href||canonical.getAttribute('href')||''):'';
 const canonicalId=canon?itemId(canon):'';
 if(canonicalId&&canonicalId!==item){out.identity='canonical-other-item';return JSON.stringify(out);}
 // Never use a page-wide price on an unbound navigation. The live mobile
 // SHEIN URL + canonical both identify the requested product ID.
 if(current!==item){out.identity='url-unbound';return JSON.stringify(out);}
 const heads=[...document.querySelectorAll('main h1,[role="main"] h1,[class*="product-intro"] h1,[class*="productIntro"] h1,h1')];
 const uniq=[...new Set(heads)];
 const clean=t=>String(t||'').replace(/\\s+/g,' ').trim();
 const h=uniq.find(n=>{const t=clean(n.textContent);return t.length>=8&&t.length<=240
   &&!/^(?:SHEIN|Home|Products|Log in|Shopping Cart|Login)$/i.test(t)
   &&!n.closest('header,footer,nav,aside,[class*="recommend"],[class*="related"]');});
 if(!h){out.identity='no-product-heading';return JSON.stringify(out);}
 out.productHeading=true;
 const shell=h.closest('[class*="product-intro"],[class*="productIntro"],[class*="product-detail"],[class*="productDetail"],main,[role="main"]')||document.querySelector('main,[role="main"]');
 if(!shell){out.identity='no-product-region';return JSON.stringify(out);}
 out.identity=canonicalId===item?'same-url-canonical':'same-url-heading';
 const forbidden=e=>!!(e&&e.closest&&e.closest('header,footer,nav,aside,[class*="recommend"],[class*="related"],'
   +'[class*="similar"],[class*="carousel"],[class*="suggest"],[class*="cross-sell"],[class*="best-sell"],'
   +'[class*="old-price"],[class*="original-price"],[class*="list-price"],[class*="strikethrough"],del,s'));
 const amount=raw=>{
  const t=clean(raw);if(t.length>85||/(?:USD|EUR|GBP|\\$|€|£)/i.test(t))return '';
  const m=t.match(/(?:[¥￥]\\s*([0-9][0-9,]*)(?:\\.0+)?|([0-9][0-9,]*)\\s*円)/);
  if(!m)return '';
  const n=Number((m[1]||m[2]).replace(/,/g,''));
  return Number.isSafeInteger(n)&&n>=1&&n<=100000000?'¥'+n:'';
 };
 const candidates=[];
 // A wide selector deliberately stays INSIDE the verified product region;
 // related, discounts, original prices and global promotion widgets are out.
 const selectors=['[data-testid*="price"]','[data-test*="price"]','[data-product-price]',
  '[itemprop="price"]','[class*="sale-price"]','[class*="salePrice"]',
  '[class*="current-price"]','[class*="currentPrice"]','[class*="product-price"]',
  '[class*="productPrice"]','[class*="head-price"]','[class*="headPrice"]',
  '[class*="price-current"]','[class*="priceCurrent"]'];
 for(const sel of selectors){
  for(const el of [...shell.querySelectorAll(sel)].slice(0,18)){
   if(forbidden(el))continue;
   const raw=el.getAttribute('content')||el.getAttribute('data-product-price')||el.textContent||'';
   const v=amount(raw);
   if(!v)continue;
   // A node displaying multiple different figures is not a current price.
   const found=clean(raw).match(/(?:[¥￥]\\s*[0-9][0-9,]*(?:\\.0+)?|[0-9][0-9,]*\\s*円)/g)||[];
   if(found.length!==1)continue;
   candidates.push({value:v,source:'product-price-node'});
  }
 }
 out.priceNodes=candidates.length;
 // SHEIN's rendered detail also has a semantic "Price and availability"
 // section; in some layouts its number is NOT nested in product-intro.
 // Only use a tightly bounded phrase AFTER this exact label and BEFORE
 // variant, delivery, related items or reviews. Not a first-page yen guess.
 const main=h.closest('main,[role="main"]')||shell;
 const mainText=String(main.innerText||main.textContent||'').slice(0,5500);
 const title=clean(h.textContent||'');
 let after=mainText.indexOf(h.innerText||h.textContent||'');
 after=after>=0?after+String(h.innerText||h.textContent||'').length:0;
 let nearby=mainText.slice(after,after+1900);
 let cut=nearby.search(/(?:Recommended|You May Also Like|Similar Items|Customer Reviews|関連商品|おすすめ商品)/i);
 if(cut>=0)nearby=nearby.slice(0,cut);
 out.priceTokens=(nearby.match(/[¥￥]\\s*\\d[\\d,]*/g)||[]).length;
 const label=nearby.match(/(?:Price\\s*(?:and|&)\\s*Availability|Current Price|販売価格|商品価格|税込価格)\\s*[:：]?\\s*/i);
 if(label){
  out.priceLabel=true;
  const scope=nearby.slice(label.index+label[0].length,label.index+label[0].length+260);
  const stop=scope.search(/(?:Available\\s+(?:Colors|Sizes)|Please choose|Choose Size|Size Guide|ADD TO CART|Add to Bag|Shipping|配送|商品詳細|原産国|数量)/i);
  const bounded=stop>=0?scope.slice(0,stop):scope;
  // The CURRENT sale price is first. A struck-through old price follows it.
  // No price can be accepted from an empty or unrelated region.
  const v=amount(bounded);
  if(v)candidates.push({value:v,source:'labeled-current-price'});
 }
 // Unlike selecting the first price in the document, a product-scoped
 // exact label is highly specific. If other price nodes disagree, reject.
 const prices=[...new Set(candidates.map(x=>x.value))];
 if(prices.length===1){out.value=prices[0];out.currency='JPY';
  out.priceSource=candidates.some(x=>x.source==='labeled-current-price')?'labeled-current-price':'product-price-node';}
 else if(prices.length>1)out.priceSource='conflicting-prices';
 else out.priceSource=out.priceLabel?'label-without-jpy':'no-local-price';
 // Product-bound JSON-LD offers may prove availability, even without a price.
 const offers=[];
 function visit(x,d){if(!x||d>6)return;
  if(Array.isArray(x)){for(const v of x.slice(0,30))visit(v,d+1);return;}
  if(typeof x!=='object')return;
  const type=String(x['@type']||'').toLowerCase();
  if(type==='product'||type.endsWith('/product')){
   const links=[x.url,x['@id'],x.mainEntityOfPage].map(v=>v&&typeof v==='object'?(v['@id']||v.url):v);
   if(links.some(v=>v&&itemId(v)===item)){
    const os=Array.isArray(x.offers)?x.offers:[x.offers];
    for(const o of os){if(o&&typeof o==='object')offers.push(o);}
   }
  }
  for(const k of ['@graph','mainEntity','item'])if(x[k])visit(x[k],d+1);
 }
 for(const s of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,25)){
  try{if((s.textContent||'').length<1500000)visit(JSON.parse(s.textContent||''),0);}catch(_){}
 }
 out.jsonOffers=offers.length;
 const states=[...new Set(offers.map(o=>String(o.availability||'').split('/').pop().toLowerCase()).filter(Boolean))];
 if(states.length===1&&states[0]==='instock'){
  out.stock='AVAILABLE';out.stockReason='item-bound-jsonld-instock';
 } else if(states.length===1&&states[0]==='outofstock'){
  out.stock='UNAVAILABLE';out.stockReason='item-bound-jsonld-outofstock';
 }
 // The merchant's product-local purchase action is another positive signal.
 // The global header cart and recommendations are NEVER purchase evidence.
 let purchase=0;
 for(const el of [...main.querySelectorAll('button,[role="button"],input[type="submit"]')].slice(0,160)){
  if(forbidden(el))continue;
  const label=clean(el.getAttribute('aria-label')||el.getAttribute('value')||el.textContent||'');
  if(!/^(?:ADD TO CART|ADD TO BAG|Add to basket|カートに入れる|カートに追加|バッグに追加)$/i.test(label))continue;
  const style=typeof getComputedStyle==='function'?getComputedStyle(el):null;
  if(el.disabled||el.hasAttribute('disabled')||el.getAttribute('aria-disabled')==='true'||el.hidden
     ||(style&&(style.display==='none'||style.visibility==='hidden')))continue;
  // Only a cart action in the SAME identified product detail region.
  const local=el.closest('[class*="product-intro"],[class*="productIntro"],'
    +'[class*="product-detail"],[class*="productDetail"],[class*="buy-box"],[class*="buyBox"]');
  if(!local||!main.contains(local))continue;
  purchase++;
 }
 out.cartCount=purchase;
 if(out.stock==='UNKNOWN'){
  if(purchase===1){out.stock='AVAILABLE';out.stockReason='item-local-enabled-cart';}
  else out.stockReason=purchase>1?'ambiguous-purchase-controls':'no-item-bound-purchase-evidence';
 }
 return JSON.stringify(out);
}catch(_){out.stock='UNKNOWN';out.stockReason='script-error';return JSON.stringify(out);}
})()
""";
}
