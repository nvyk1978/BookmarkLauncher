package com.cmyk.bookmarkslauncher.wishlist;

/** Evaluates HIRAKI's actual color/size row. Never reads stock SYMBOL LEGENDS. */
final class HirakiStockDom {
    private HirakiStockDom() { }
    static String javascript(String productId) {
        if (productId == null || !productId.matches("[0-9]{1,12}")) return "'UNKNOWN'";
        return "(function(){try{\n" +
                "var sku='"+productId+"';\n" +
                "if(!/^\\/ec\\/pro\\/disp\\/1\\/[0-9]+\\/?$/.test(location.pathname)||!location.pathname.replace(/\\/$/,'').endsWith('/'+sku))return 'UNKNOWN';\n" +
                "var body=document.body; if(!body)return 'UNKNOWN';\n" +
                "var title=Array.from(document.querySelectorAll('h1')).find(function(e){return (e.textContent||'').trim().length>2;});\n" +
                "if(!title)return 'UNKNOWN';\n" +
                "var anchor=(title.parentElement&&title.parentElement.parentElement)||title.parentElement||body;\n" +
                "var label=(anchor.textContent||'').slice(0,900);\n" +
                "var bt=body.innerText||''; var titlePos=bt.indexOf((title.innerText||'').trim());\n" +
                "if(titlePos>=0)label+=' '+bt.slice(Math.max(0,titlePos-160),titlePos+80);\n" +
                "if(!new RegExp('品番\\\\s*[:：]?\\\\s*'+sku+'(?![0-9])').test(label))return 'UNKNOWN';\n" +
                "function visible(e){if(!e)return false;for(var x=e;x;x=x.parentElement){if(x.hidden)return false;var s=getComputedStyle(x);if(s.display==='none'||s.visibility==='hidden')return false;}return true;}\n" +
                "function active(e){return !!e&&!e.disabled&&!e.readOnly&&e.getAttribute('aria-disabled')!=='true'&&visible(e);}\n" +
                "function text(e){return ((e&&e.textContent)||'').replace(/\\s+/g,' ').trim();}\n" +
                "var root=title.closest('main,[role=main],#contents,#container,#main,.product-detail')||body;\n" +
                "var carts=Array.from(root.querySelectorAll('button,input[type=submit],input[type=button],a[href]')).filter(function(e){\n" +
                "var t=(e.innerText||e.value||e.textContent||e.getAttribute('aria-label')||'').trim();\n" +
                "return active(e)&&/カートに入れる|買い物かごに入れる/.test(t)&&!e.closest('header,nav,footer,[class*=recommend],[class*=related]');});\n" +
                "var tables=Array.from(root.querySelectorAll('table')).filter(function(t){return /在庫/.test(text(t))&&/数量/.test(text(t));});\n" +
                "var states=[];\n" +
                "tables.forEach(function(table){\n" +
                "var before=(table.previousElementSibling&&text(table.previousElementSibling))||'';\n" +
                "var block=table.parentElement;var heading=text(table.querySelector('thead')||table);\n" +
                "var surrounding=(before+' '+(block&&block!==root?text(block).slice(0,240):'')+' '+heading);\n" +
                "if(!/\\(\\s*99\\s*\\)|（\\s*99\\s*）/.test(surrounding))return;\n" +
                "Array.from(table.querySelectorAll('tr')).forEach(function(row){\n" +
                "var q=row.querySelector('input[type=number],input[type=text],input[name*=qty],input[name*=quantity]');\n" +
                "if(!q)return;var cells=Array.from(row.querySelectorAll('td'));if(cells.length<2)return;\n" +
                "var stock=cells[cells.length-2];var v=text(stock);var code=(stock.className||'')+' '+(stock.getAttribute('title')||'')+' '+(stock.getAttribute('aria-label')||'');\n" +
                "if(/×|✕|完売|売り切れ|在庫切れ/.test(v)||/sold.?out|out.?of.?stock/.test(code))states.push('UNAVAILABLE');\n" +
                "else if(active(q)&&carts.length===1&&(/○|◯|△|在庫あり|在庫わずか|入荷後発送|後日発送/.test(v)||!v)&& !/sold.?out|out.?of.?stock/.test((row.className||'')+' '+code))states.push('AVAILABLE');\n" +
                "});\n" +
                "});\n" +
                "if(!states.length)return 'UNKNOWN';\n" +
                "return states.every(function(x){return x==='AVAILABLE';})?'AVAILABLE':states.every(function(x){return x==='UNAVAILABLE';})?'UNAVAILABLE':'UNKNOWN';\n" +
                "}catch(e){return 'UNKNOWN';}})()";
    }
}
