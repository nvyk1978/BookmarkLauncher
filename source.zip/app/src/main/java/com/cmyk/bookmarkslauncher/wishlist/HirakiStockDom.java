package com.cmyk.bookmarkslauncher.wishlist;

/** HIRAKI's item-bound color/size inventory DOM. Stock legends do not prove stock. */
final class HirakiStockDom {
    private HirakiStockDom() { }

    /** Bounded JSON evidence for card-local diagnostics; no click or cart mutation. */
    static String stockEvidence(String productId) {
        if (productId == null || !productId.matches("[0-9]{1,12}"))
            return "JSON.stringify({status:'UNKNOWN',reason:'invalid-sku'})";
        return """
(function(){'use strict';
 const out={status:'UNKNOWN',reason:'no-evidence',skuMatch:false,color99:false,
   tableFound:0,rowFound:0,qtyFound:0,qtyEnabled:0,cartFound:0,cartEnabled:0,cartAction:0,cartTextHint:0,
   stockIcon:0,stockPositive:0,stockNegative:0,forms:0,imageControls:0,
   cartForms:0,skuBoundForms:0,cartAttributeHints:0};
 const done=()=>JSON.stringify(out);
 try{
 const sku='__SKU__';
 const path=(location.pathname||'').replace(/\\/+$/,'');
 if(path!=='/ec/pro/disp/1/'+sku){out.reason='url-mismatch';return done();}
 const body=document.body;if(!body){out.reason='body-missing';return done();}
 const t=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ').replace(/\\s+/g,' ').trim();
 const title=document.querySelector('h1');
 if(!title||t(title).length<3){out.reason='title-missing';return done();}
 const full=t(body),titlePos=full.indexOf(t(title));
 const idMatch=new RegExp('品番\\\\s*[:：]?\\\\s*'+sku+'(?![0-9])');
 out.skuMatch=titlePos>=0&&idMatch.test(full.slice(Math.max(0,titlePos-650),titlePos+650));
 if(!out.skuMatch){out.reason='sku-missing';return done();}
 const root=title.closest('main,[role=main],#contents,#container,#main,.product-detail')||body;
 const enabled=e=>{
   if(!e||e.disabled||e.readOnly||e.hasAttribute('disabled')||e.getAttribute('aria-disabled')==='true')return false;
   if(/disabled|sold.?out|out.?of.?stock|unavailable/i.test(String(e.className||'')))return false;
   for(let p=e;p;p=p.parentElement){if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return false;
     const style=getComputedStyle(p);if(style.display==='none'||style.visibility==='hidden'||style.visibility==='collapse'||Number(style.opacity)===0)return false;
   }
   return true;
 };
 const allControls=Array.from(root.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],a[href],[role=button],[onclick],[data-action],[data-cart]'));
 const forms=Array.from(root.querySelectorAll('form'));
 out.forms=forms.length;
 out.imageControls=allControls.filter(e=>e.matches('input[type=image]')||!!e.querySelector('img')).length;
 for(const f of forms){
   const action=[f.action,f.getAttribute('action'),f.id,f.className].filter(Boolean).join(' ');
   if(/cart|basket|カート|かご/i.test(action))out.cartForms++;
   if(f.querySelector('input[value="'+sku+'"],input[name*=product],input[name*=item]'))out.skuBoundForms++;
 }
 out.cartAttributeHints=allControls.filter(e=>
   /cart|basket|カート|かご/i.test([e.id,e.className,e.getAttribute('src'),e.getAttribute('href')].filter(Boolean).join(' '))).length;
 const carts=allControls.filter(e=>{
   if(e.closest('header,nav,footer,aside,[class*=related],[class*=recommend],[class*=ranking],[class*=modal],[class*=dialog]'))return false;
   const img=e.querySelector('img[alt]');
   const label=[t(e),e.value,e.getAttribute('aria-label'),e.getAttribute('title'),e.getAttribute('alt'),img&&img.getAttribute('alt')].filter(Boolean).join(' ');
   const action=[e.getAttribute('onclick'),e.getAttribute('data-action'),e.getAttribute('data-cart'),e.getAttribute('name'),e.id,e.className,
     e.getAttribute('href'),e.getAttribute('src')].filter(Boolean).join(' ');
   const cartText=/(?:カート|買い物かご)\s*に\s*入れる|add\s*to\s*cart/i.test(label);
   const cartAction=/(?:add.?to.?cart|add.?cart|cart.?add|put.?cart|shopping.?cart|cartin|add.?basket)/i.test(action);
   if(cartText)out.cartTextHint++;
   // A broad div with informational text is not a purchase control.
   const actionable=e.matches('button,input[type=submit],input[type=button],input[type=image],a[href],[role=button]')
       || !!e.getAttribute('onclick') || !!e.getAttribute('data-action') || !!e.getAttribute('data-cart');
   if(actionable&&cartAction)out.cartAction++;
   if(!actionable||(!cartText&&!cartAction))return false;
   if(e.querySelectorAll('button,[onclick],[data-action]').length>0&&!e.matches('button,input,a'))return false;
   const near=e.closest('form,.item-detail,.product-detail,#contents,#main')||root;
   if(!near||!root.contains(near))return false;
   return true;
 });
 out.cartFound=carts.length;out.cartEnabled=carts.filter(enabled).length;
 const tables=Array.from(root.querySelectorAll('table')).filter(table=>{
   const head=t(table.querySelector('thead')||table).slice(0,280);
   return /在庫/.test(head)&&/数量/.test(head);
 });
 out.tableFound=tables.length;
 const pos=/[（(]\\s*99\\s*[）)]/;
 for(const table of tables){
   // The (99) color label must PRECEDE the table near the actual size rows.
   // A color legend elsewhere in the document is never sufficient.
   let before='';
   try{const range=document.createRange();range.setStart(root,0);range.setEndBefore(table);
      before=range.toString().slice(-450);}catch(_){ }
   if(!before){let prev=table.previousElementSibling;
      for(let k=0;k<5&&prev;k++,prev=prev.previousElementSibling)before=t(prev)+' '+before;}
   const ownLabel=t(table).slice(0,160);
   if(!pos.test(before.slice(-260))&&!pos.test(ownLabel)){continue;}
   out.color99=true;
   let rows=Array.from(table.querySelectorAll('tr'));
   for(const row of rows){
     const cells=Array.from(row.querySelectorAll('td'));
     if(cells.length<2)continue;
     const qty=Array.from(row.querySelectorAll('input')).find(x=>{
       const type=String(x.type||'text').toLowerCase();
       return ['text','number','tel'].includes(type)&&!x.hidden;
     });
     if(!qty)continue;
     out.rowFound++;out.qtyFound++;
     const qtyOK=enabled(qty)&&!(qty.max!==''&&Number(qty.max)===0);
     if(qtyOK)out.qtyEnabled++;
     const stock=cells[cells.length-2];
     const icons=Array.from(stock.querySelectorAll('img,svg,[title],[aria-label],[data-stock],[data-status],i'));
     out.stockIcon+=icons.length;
     const rowCodes=[t(stock),stock.className,stock.getAttribute('title'),stock.getAttribute('aria-label'),
       row.className,row.getAttribute('data-stock'),row.getAttribute('data-status'),
       ...icons.flatMap(el=>[el.getAttribute('alt'),el.getAttribute('title'),el.getAttribute('aria-label'),
         el.getAttribute('data-stock'),el.getAttribute('data-status'),el.className&&typeof el.className==='string'?el.className:''])]
       .filter(Boolean).join(' ');
     const negative=/(?:×|✕|完売|売り切れ|在庫切れ|sold.?out|out.?of.?stock|stock.?none|unavailable|not.?available)/i.test(rowCodes);
     const positive=/(?:○|◯|△|在庫あり|在庫わずか|入荷後発送|後日発送|in.?stock|\\bavailable\\b)/i.test(rowCodes);
     if(negative)out.stockNegative++;
     if(positive)out.stockPositive++;
     // The active quantity field and enabled product cart are valid purchase
     // controls for the exact color 99 row even if its stock icon has no alt.
     if(!negative&&qtyOK&&out.cartEnabled>=1&&out.cartEnabled<=2&&out.cartFound<=2){
       out.status='AVAILABLE';out.reason=positive?'color99-icon-quantity-cart':'color99-quantity-cart';
     }else if(negative){out.status='UNAVAILABLE';out.reason='color99-row-sold-out';}
   }
 }
 if(!out.color99){out.reason='color99-table-missing';return done();}
 if(!out.rowFound){out.reason='color99-quantity-row-missing';return done();}
 if(out.stockNegative>0&&out.status==='AVAILABLE'){out.status='UNKNOWN';out.reason='conflicting-stock';return done();}
 if(out.status==='UNKNOWN')out.reason=out.qtyEnabled===0?'quantity-disabled':out.cartEnabled===0?'cart-missing':'stock-evidence-insufficient';
 return done();
 }catch(_){out.reason='dom-error';return done();}
})()
""".replace("__SKU__",productId);
    }

    /** Original status-only contract retained for safe internal reuse. */
    static String javascript(String productId) {
        return "(function(){try{return JSON.parse(" + stockEvidence(productId)
                + ").status;}catch(_){return 'UNKNOWN';}})()";
    }
}
