package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/**
 * Diagnostics ONLY: observe why visible merchant purchase operations remain
 * unbound to the requested item. No purchase clicks and no stock verdict.
 * Never exports product names, identifiers, URLs or cookies into the card log.
 */
public final class WishlistRetailStockIdentityAuditDom {
    private WishlistRetailStockIdentityAuditDom() { }

    public static boolean supports(URL u) {
        if (u == null || !"https".equalsIgnoreCase(u.getProtocol())
                || !WishlistCrawler.isAllowedUrl(u)
                || MarketplaceIdentity.site(u) != MarketplaceIdentity.Site.OTHER
                || !WishlistCrawler.isSingleProductPage(u)) return false;
        String host = u.getHost().toLowerCase(Locale.ROOT);
        return host.equals("zozo.jp") || host.equals("www.zozo.jp")
                || host.equals("edion.com") || host.equals("www.edion.com")
                || host.equals("au.com") || host.endsWith(".au.com")
                || host.equals("wowma.jp") || host.endsWith(".wowma.jp")
                || host.equals("aupaymarket.com") || host.endsWith(".aupaymarket.com");
    }

    public static String javascript(URL u) {
        if (!supports(u)) return "JSON.stringify({reason:'unsupported'})";
        String path = u.getPath().replaceAll("/+$", "");
        String item = WishlistGeneralProductIdentity.code(u);
        return SCRIPT.replace("__HOST__", JSONObject.quote(u.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(path.toLowerCase(Locale.ROOT)))
                .replace("__ITEM__", JSONObject.quote(item.toLowerCase(Locale.ROOT)));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const r={reason:'unknown',sameDocument:false,canonical:'missing',heading:0,
    itemClaim:false,productSchema:false,activeAdd:0,hiddenAdd:0,selectedVariant:false};
 const done=()=>JSON.stringify(r);
 try{
   const h=__HOST__, p=__PATH__,item=__ITEM__;
   if(location.protocol!=='https:'||location.hostname.toLowerCase()!==h||
       location.pathname.replace(/\\/+$/,'').toLowerCase()!==p){
      r.reason='document-mismatch'; return done();
   }
   r.sameDocument=true;
   const canonical=document.querySelector('link[rel=canonical]');
   if(canonical&&canonical.href){
     try{const u=new URL(canonical.href,location.href);
       r.canonical=(u.hostname.toLowerCase()===h&&
         u.pathname.replace(/\\/+$/,'').toLowerCase()===p)?'match':'different';
     }catch(_){r.canonical='invalid';}
   }
   const root=document.querySelector('main,[role=main],#main,#contents,#content')||document.body;
   if(!root){r.reason='empty-document';return done();}
   const visible=e=>{if(!e||e.closest('header,nav,footer,aside'))return false;
     for(let x=e;x;x=x.parentElement){if(x.hidden||x.getAttribute('aria-hidden')==='true')return false;
       const s=getComputedStyle(x);if(s.display==='none'||s.visibility==='hidden')return false;}return true;};
   r.heading=[...root.querySelectorAll('h1')].filter(visible).length;
   r.itemClaim=!!(item&&[...root.querySelectorAll('[data-product-id],[data-sku],[data-item-id]')]
     .some(e=>visible(e)&&['data-product-id','data-sku','data-item-id']
     .some(k=>String(e.getAttribute(k)||'').toLowerCase()===item)));
   r.productSchema=[...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,20)
     .some(e=>/"@type"\\s*:\\s*"Product"/i.test(e.textContent||''));
   const adds=[...root.querySelectorAll('button,[role=button],input[type=submit],a[href]')]
     .filter(e=>/(?:カート|カゴ|かご|バッグ)\\s*(?:に|へ)?\\s*(?:入れる|追加)|add\\s*to\\s*(?:cart|bag)/i
       .test([e.innerText,e.textContent,e.value,e.getAttribute('aria-label')].filter(Boolean).join(' ').slice(0,120)));
   r.activeAdd=adds.filter(e=>visible(e)&&!e.disabled&&e.getAttribute('aria-disabled')!=='true').length;
   r.hiddenAdd=adds.filter(e=>!visible(e)).length;
   r.selectedVariant=!!root.querySelector('[data-did],[data-detail-id],[aria-selected=true],[data-selected=true]');
   r.reason='observed';
   return done();
 }catch(_){r.reason='dom-error';return done();}
})()
""";
}
