package com.cmyk.bookmarkslauncher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** ImgStalker 0.1.151 HeaderIconKind.DIAGNOSTIC: identical vector geometry.
 * Wishlist final palette: N Gray disc / N White document icon. */
final class ImgStalkerDiagnosticIconView extends View {
    private static final int N_GRAY = 0xFF454040;
    private static final int N_WHITE = 0xFFA9A999;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    ImgStalkerDiagnosticIconView(Context context) {
        super(context);
        setClickable(true);
        setFocusable(true);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_GRAY);
        canvas.drawCircle(cx, cy, Math.min(getWidth(), getHeight()) / 2f, paint);

        // Original ImgStalker solid document and three knockout text lines.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_WHITE);
        RectF doc = new RectF(cx - dp(8.2f), cy - dp(10.0f), cx + dp(8.2f), cy + dp(10.0f));
        canvas.drawRoundRect(doc, dp(2.3f), dp(2.3f), paint);
        paint.setColor(N_GRAY);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2.4f));
        paint.setStrokeCap(Paint.Cap.ROUND);
        canvas.drawLine(cx - dp(4.2f), cy - dp(4.5f), cx + dp(4.2f), cy - dp(4.5f), paint);
        canvas.drawLine(cx - dp(4.2f), cy, cx + dp(4.2f), cy, paint);
        canvas.drawLine(cx - dp(4.2f), cy + dp(4.5f), cx + dp(1.6f), cy + dp(4.5f), paint);
        paint.setColor(N_WHITE);
    }
}
