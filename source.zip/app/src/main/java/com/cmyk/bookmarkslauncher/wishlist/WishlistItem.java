package com.cmyk.bookmarkslauncher.wishlist;

public final class WishlistItem {
    public String id;
    public String sourceNodeId;
    public String title;
    public String url;
    public String sourceName;
    /** Editable note; can also identify a specific product on multi-item pages. */
    public String note;
    public String thumbnailPath;
    public String faviconPath;
    public String previewImageUrl;
    public String previewPath;
    public boolean userTitleEdited;
    public boolean userImageEdited;
    public Long registeredPrice;
    public Long currentPrice;
    /** FROM or RANGE; separate from exact currentPrice and price history. */
    public String priceQuoteKind;
    public Long priceMinimum;
    public Long priceMaximum;
    public Long lastPriceCheckedAt;
    public boolean priceFetchOk;
    public String lastPriceError;
    public String status;
    public String previousStatus;
    public boolean monitorResume;
    public int sortIndex;
    public long createdAt;
    public long updatedAt;
}
