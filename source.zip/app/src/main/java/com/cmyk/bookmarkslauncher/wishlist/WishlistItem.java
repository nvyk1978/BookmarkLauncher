package com.cmyk.bookmarkslauncher.wishlist;

public final class WishlistItem {
    public String id;
    public String sourceNodeId;
    public String title;
    public String url;
    public String sourceName;
    public String thumbnailPath;
    public String faviconPath;
    public String previewImageUrl;
    public String previewPath;
    public boolean userTitleEdited;
    public Long registeredPrice;
    public Long currentPrice;
    public Long lastPriceCheckedAt;
    public boolean priceFetchOk;
    public String status;
    public String previousStatus;
    public boolean monitorResume;
    public int sortIndex;
    public long createdAt;
    public long updatedAt;
}
