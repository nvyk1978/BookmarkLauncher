package com.cmyk.bookmarkslauncher.wishlist;

/**
 * Read-only, pre-classifier DOM inventory for difficult GENERAL product pages.
 * This script does NOT use ProductEvidenceScopeDom or site purchase selectors,
 * does NOT click anything, and NEVER returns form values, complete HTML, page
 * text, URLs, cookies or credentials. It reports a bounded structural outline
 * of actual DOM controls (including accessible same-origin frames/open shadows).
 * A DOM inventory is evidence about the document, NOT proof of availability.
 */
final class WishlistRawPurchaseDomAudit {
    private WishlistRawPurchaseDomAudit() { }

    static String javascript() {
        return """
(function(){'use strict';
 const out={ready:String(document.readyState||'unknown'),bodyChars:0,cartText:false,
   controls:0,buttons:0,quantities:0,cartNamed:0,enabledNamed:0,
   frames:0,readable:0,unreadable:0,shadows:0,visited:0,limit:false,
   samples:[],error:'none'};
 const cart=/(?:カート|買い物かご|カゴ|かご|cart|basket|購入|注文)/i;
 const buy=/(?:カート\\s*に\\s*入れる|カゴ\\s*に\\s*入れる|かご\\s*に\\s*入れる|add\\s*to\\s*cart|add.?cart|cart.?add|注文する|購入する)/i;
 const qty='input[type=number],input[name*=quantity],input[name*=qty],select[name*=quantity],select[name*=qty]';
 const product='main,#main,#contents,[role=main],[class*=product],[class*=item-detail],#productDetail,#product_detail';
 const selectors='button,input[type=submit],input[type=button],input[type=image],a,[role=button],[onclick],[data-action],[data-cart],[data-testid],svg';
 function clean(s,n){let v=String(s||'').replace(/[^a-zA-Z0-9_\\-]/g,'');
   if(/(?:token|session|auth|key|secret|password)/i.test(v)||v.length>60)return '-';
   return v.slice(0,n||28)||'-';}
 function lab(c){
   // Never return free-form page text, user input or arbitrary attribute values.
   let t=String(c.getAttribute('aria-label')||'')+' '+String(c.getAttribute('title')||'')+' '+
     String(c.getAttribute('alt')||'')+' '+String(c.textContent||'').slice(0,200)+' ';
   if(c.matches('input[type=submit],input[type=button]'))t+=String(c.getAttribute('value')||'').slice(0,100);
   return buy.test(t)?'purchase':cart.test(t)?'cart':'none';
 }
 function attrs(c){return Array.from(c.attributes||[]).map(a=>a.name).filter(n=>
   /^(?:aria-|data-|onclick$|type$|role$|name$|disabled$|href$|src$|title$|alt$)/i.test(n))
   .slice(0,7).map(n=>clean(n,28)).join('.')||'-';}
 function live(c){
   if(c.disabled||c.hasAttribute('disabled')||c.getAttribute('aria-disabled')==='true')return 'disabled';
   for(let p=c;p;p=p.parentElement){
     if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return 'hidden';
     const s=getComputedStyle(p);
     if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse')return 'hidden';
   }
   return 'enabled';
 }
 function nearby(c){
   for(let p=c,k=0;p&&k<4;p=p.parentElement,k++){
     if(p.querySelector&&p.querySelector(qty))return true;
   }return false;
 }
 function probe(root,scope,depth){
   if(!root||!root.querySelectorAll||depth>3||out.visited>13000)return;
   try{
     const nodes=root.querySelectorAll(selectors);
     const take=Math.min(nodes.length,1800);out.controls+=nodes.length;
     for(let i=0;i<take;i++){
       const c=nodes[i];out.visited++;
       if(c.matches('button,input[type=submit],input[type=button],input[type=image],[role=button]'))out.buttons++;
       const kind=lab(c), near=nearby(c), state=live(c);
       const inProduct=!!c.closest(product);
       const unrelated=!!c.closest('header,nav,footer,aside,[class*=recommend],[class*=related]');
       if(kind!=='none'){out.cartNamed++;if(state==='enabled')out.enabledNamed++;}
       if((kind!=='none'||near||(inProduct&&!unrelated&&c.matches('button,input[type=submit],input[type=button],input[type=image],[role=button]')))&&out.samples.length<32){
         const detail={scope:scope.slice(0,15),tag:clean(c.tagName,10),id:clean(c.id,25),
           cls:clean(String(c.className&&typeof c.className==='string'?c.className.split(' ')[0]:''),28),
           attrs:attrs(c),label:kind,state:state,nearQty:near,
           onclick:c.hasAttribute('onclick'),product:inProduct,shadow:scope.indexOf('shadow')>=0};
         // Prefer an actionable-looking candidate; sample at most 24 nodes for bounded output.
         out.samples.push(detail);
       }
       if(out.visited>13000){out.limit=true;break;}
     }
     out.quantities+=root.querySelectorAll(qty).length;
     if(out.visited>13000||depth>=3)return;
     const els=root.querySelectorAll('*');
     for(let i=0;i<Math.min(els.length,6000);i++){
       const e=els[i];
       if(e.shadowRoot){out.shadows++;probe(e.shadowRoot,'shadow'+depth,depth+1);}
       if(e.tagName==='IFRAME'){
         out.frames++;
         try{const d=e.contentDocument;
           if(d&&d.documentElement){out.readable++;probe(d,'frame'+depth,depth+1);}
           else out.unreadable++;
         }catch(_){out.unreadable++;}
       }
       if(out.visited>13000){out.limit=true;break;}
     }
   }catch(e){out.error='dom-traversal';}
 }
 try{
   const b=document.body;
   out.bodyChars=b?String(b.textContent||'').length:0;
   out.cartText=!!(b&&cart.test(b.textContent||''));
   if(b)probe(document,'main',0);
   // Output only the most relevant bounded structural fingerprints; no text/URLs.
   out.samples=out.samples.sort((a,b)=>
     (b.label==='purchase'?8:b.label==='cart'?5:0)+(b.nearQty?2:0)+(b.product?1:0)-
     ((a.label==='purchase'?8:a.label==='cart'?5:0)+(a.nearQty?2:0)+(a.product?1:0)))
     .slice(0,7);
 }catch(e){out.error='audit-exception';}
 return JSON.stringify(out);
})()
""";
    }
}
