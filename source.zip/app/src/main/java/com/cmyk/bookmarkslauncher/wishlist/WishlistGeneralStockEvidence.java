package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Generic positive inventory evidence for a single retail product.
 * This is deliberately narrow and never guesses out-of-stock from page text.
 * Marketplace parsers do not invoke this helper.
 */
final class WishlistGeneralStockEvidence {
    private static final Pattern H1 = Pattern.compile("(?is)<h1\\b[^>]*>.*?</h1\\s*>");
    private static final Pattern STRIP = Pattern.compile("(?is)<(?:script|style|noscript)\\b[^>]*>.*?</(?:script|style|noscript)\\s*>|<[^>]*>");
    private static final Pattern RELATED = Pattern.compile("(?i)関連商品|おすすめ商品|この商品を見た|よく一緒に購入|他の商品");
    private static final Pattern STOCK = Pattern.compile("(?i)(?:^|[\\s　])在庫(?:状況|数)?\\s*[:：]?\\s*(?:在庫)?(あり|なし|切れ|わずか)(?:[\\s　]|$)");
    private WishlistGeneralStockEvidence() { }

    static WishlistAvailabilityExtractor.Result inspect(String html, URL page) {
        if (html == null || !WishlistCrawler.isSingleProductPage(page)) return null;
        Matcher h = H1.matcher(html);
        if (!h.find()) return null;
        // Only the immediate item section, not a shop-wide notice or recommendations.
        String block = html.substring(h.end(), Math.min(html.length(), h.end() + 6500));
        block = STRIP.matcher(block).replaceAll(" ").replace("&nbsp;", " ")
                .replaceAll("[\\s　]+", " ");
        Matcher related = RELATED.matcher(block);
        if (related.find()) block = block.substring(0, related.start());
        Matcher stock = STOCK.matcher(block);
        String state = null;
        while (stock.find()) {
            String value = stock.group(1);
            String candidate = "あり".equals(value) ? "AVAILABLE" : "UNKNOWN";
            if (state != null && !state.equals(candidate)) return null;
            state = candidate;
        }
        // Never label unavailable from text alone; hidden templates and variants
        // can contain an out-of-stock message that does not apply to the item.
        return "AVAILABLE".equals(state)
                ? new WishlistAvailabilityExtractor.Result("AVAILABLE", true, "対象商品近傍の在庫あり表示") : null;
    }
}
