package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** Compatibility entry point for already-created Wishlist notification intents. */
public final class WishlistActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        String id = getIntent() == null ? null : getIntent().getStringExtra("item_id");
        Intent home = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("wishlist_item_id", id);
        startActivity(home);
        finish();
        overridePendingTransition(0, 0);
    }
}
