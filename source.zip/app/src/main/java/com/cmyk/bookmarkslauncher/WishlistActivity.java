package com.cmyk.bookmarkslauncher;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.wishlist.WishlistCrawler;
import com.cmyk.bookmarkslauncher.wishlist.WishlistItem;
import com.cmyk.bookmarkslauncher.wishlist.WishlistRepository;
import com.cmyk.bookmarkslauncher.wishlist.WishlistScheduler;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class WishlistActivity extends Activity {
    private static final int BG = 0xFF303030;
    private static final int DGRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int LGRAY = 0xFF656060;
    private static final int BLUE = 0xFF223355;
    private static final int LBLUE = 0xFF445577;
    private static final int RED = 0xFF441100;
    private static final int LRED = 0xFF662211;
    private static final int ORANGE = 0xFF775500;
    private static final int WHITE = 0xFFA9A999;
    private static final int GREEN = 0xFF227733;
    private static final int TEXT = 0xFFFFFFFF;
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;
    private static final long PURCHASE_PROMPT_MIN_MS = 15_000L;

    private WishlistRepository repo;
    private FrameLayout root;
    private LinearLayout listBox;
    private TextView empty;
    private View purchaseBar;
    private String expandedId;
    private String query = "";
    private final Set<Long> filterTags = new HashSet<>();
    private Long minPrice;
    private Long maxPrice;
    private String pendingPurchaseItemId;
    private long pendingExternalStart;
    private boolean leftForProduct;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private SharedPreferences promptPrefs;
    private float returnSwipeDownX;
    private float returnSwipeDownY;
    private boolean returnSwipeCandidate;
    private boolean returnSwipeTriggered;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0x80000000);
        getWindow().setNavigationBarColor(BG);
        repo = new WishlistRepository(this);
        promptPrefs = getSharedPreferences("wishlist_purchase_prompt", MODE_PRIVATE);
        WishlistScheduler.ensureScheduled(this);
        expandedId = getIntent() == null ? null : getIntent().getStringExtra("item_id");
        setContentView(buildUi());
        refreshList();
        maybeRefreshStale();
    }

    @Override protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        int action = ev.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            returnSwipeDownX = ev.getRawX();
            returnSwipeDownY = ev.getRawY();
            returnSwipeCandidate = true;
            returnSwipeTriggered = false;
        } else if (action == MotionEvent.ACTION_MOVE && returnSwipeCandidate && !returnSwipeTriggered) {
            float dx = ev.getRawX() - returnSwipeDownX;
            float dy = ev.getRawY() - returnSwipeDownY;
            if (dx < -dp(110) && Math.abs(dx) > Math.abs(dy) * 1.50f) {
                returnSwipeTriggered = true;
                returnSwipeCandidate = false;
                returnToBookmarks();
                return true;
            }
            if (Math.abs(dy) > dp(48) || dx > dp(18)) returnSwipeCandidate = false;
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            returnSwipeCandidate = false;
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void onBackPressed() {
        returnToBookmarks();
    }

    private void returnToBookmarks() {
        Intent home = new Intent(this, MainActivity.class);
        home.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(home);
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override protected void onResume() {
        super.onResume();
        if (leftForProduct) {
            leftForProduct = false;
            long elapsed = SystemClock.elapsedRealtime() - pendingExternalStart;
            if (elapsed >= PURCHASE_PROMPT_MIN_MS && pendingPurchaseItemId != null) showPurchasePrompt(pendingPurchaseItemId);
        }
    }

    private View buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12), dp(48), dp(12), dp(18));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = capsule("‹", DGRAY, 28);
        back.setOnClickListener(v -> returnToBookmarks());
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView title = text("Wishlist", 24, WHITE, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        titleLp.leftMargin = dp(10);
        head.addView(title, titleLp);
        page.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, dp(4), 0, dp(78));
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listBox, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        empty = text("Wishlistは空です", 15, LGRAY, false);
        empty.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams emptyLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64), Gravity.CENTER);
        emptyLp.leftMargin = dp(28); emptyLp.rightMargin = dp(28);
        root.addView(empty, emptyLp);

        FrameLayout searchFab = new FrameLayout(this);
        searchFab.setBackground(circle(DGRAY));
        searchFab.setElevation(dp(8));
        SearchIcon icon = new SearchIcon(this);
        searchFab.addView(icon, new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        searchFab.setContentDescription("Wishlist検索");
        searchFab.setOnClickListener(v -> showSearchDialog());
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END | Gravity.BOTTOM);
        fabLp.setMargins(0, 0, dp(18), dp(24));
        root.addView(searchFab, fabLp);
        return root;
    }

    private void refreshList() {
        List<WishlistItem> all = repo.listAll();
        List<WishlistItem> visible = new ArrayList<>();
        for (WishlistItem item : all) if (matches(item)) visible.add(item);
        listBox.removeAllViews();
        for (WishlistItem item : visible) listBox.addView(itemRow(item));
        empty.setVisibility(visible.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private boolean matches(WishlistItem item) {
        if (item == null) return false;
        if (query != null && !query.isBlank()) {
            String hay = ((item.title == null ? "" : item.title) + " " + (item.url == null ? "" : item.url) + " " + (item.sourceName == null ? "" : item.sourceName)).toLowerCase(Locale.ROOT);
            if (!hay.contains(query.trim().toLowerCase(Locale.ROOT))) return false;
        }
        if (!filterTags.isEmpty()) {
            Set<Long> assigned = repo.tagsForItem(item.id);
            if (!assigned.containsAll(filterTags)) return false;
        }
        if (minPrice != null || maxPrice != null) {
            // Price filtering is only allowed to use a price confirmed by the latest crawl.
            // A failed refresh keeps the previous value for history/display, but never treats it as current.
            if (!item.priceFetchOk || item.currentPrice == null) return false;
            if (minPrice != null && item.currentPrice < minPrice) return false;
            if (maxPrice != null && item.currentPrice > maxPrice) return false;
        }
        return true;
    }

    private View itemRow(WishlistItem item) {
        boolean expanded = item.id.equals(expandedId);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setTag(item.id);
        card.setBackground(roundRect(DGRAY, 12));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(0, 0, 0, dp(6));
        card.setLayoutParams(cardLp);

        LinearLayout line = new LinearLayout(this);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setPadding(dp(4), dp(4), dp(8), dp(4));
        TextView grip = text("≡", 24, WHITE, true);
        grip.setGravity(Gravity.CENTER);
        grip.setContentDescription("並べ替え");
        line.addView(grip, new LinearLayout.LayoutParams(dp(34), dp(48)));
        attachGrip(grip, item.id, card);

        View thumb = thumbnail(item);
        line.addView(thumb, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout nameBox = new LinearLayout(this);
        nameBox.setOrientation(LinearLayout.VERTICAL);
        nameBox.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(item.title == null || item.title.isBlank() ? "商品" : item.title, 14, TEXT, true);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nameBox.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(25)));
        TextView sub = text(collapsedSub(item), 11, statusColor(item.status), false);
        sub.setSingleLine(true);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nameBox.addView(sub, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(19)));
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        nameLp.leftMargin = dp(8);
        line.addView(nameBox, nameLp);

        TextView price = text(price(item.currentPrice), 14, item.currentPrice == null ? LGRAY : TEXT, true);
        price.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        line.addView(price, new LinearLayout.LayoutParams(dp(92), dp(48)));
        line.setOnClickListener(v -> {
            expandedId = item.id.equals(expandedId) ? null : item.id;
            refreshList();
        });
        card.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
        if (expanded) card.addView(expandedView(item), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    private View expandedView(WishlistItem item) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(42), dp(4), dp(10), dp(12));

        TextView url = text(item.url == null ? "" : item.url, 11, LGRAY, false);
        url.setMaxLines(2);
        url.setEllipsize(android.text.TextUtils.TruncateAt.END);
        box.addView(url);

        LinearLayout prices = new LinearLayout(this);
        prices.setGravity(Gravity.CENTER_VERTICAL);
        prices.addView(field("登録時", price(item.registeredPrice)), new LinearLayout.LayoutParams(0, dp(44), 1f));
        prices.addView(field("現在", price(item.currentPrice)), new LinearLayout.LayoutParams(0, dp(44), 1f));
        box.addView(prices);

        List<WishlistRepository.PricePoint> history = repo.priceHistory(item.id, 2);
        String change = "価格変動：—";
        if (history.size() >= 2) {
            long d = history.get(0).price - history.get(1).price;
            change = "価格変動：" + shortDate(history.get(1).checkedAt) + "から " + (d > 0 ? "+" : "") + "¥" + String.format(Locale.JAPAN, "%,d", d);
        }
        TextView priceChange = text(change, 12, ORANGE, false);
        box.addView(priceChange, lp(dp(2), dp(3)));
        String registeredDiff = "登録時比：—";
        if (item.registeredPrice != null && item.currentPrice != null) {
            long d = item.currentPrice - item.registeredPrice;
            registeredDiff = "登録時比：" + (d > 0 ? "+" : "") + "¥" + String.format(Locale.JAPAN, "%,d", d);
        }
        box.addView(text(registeredDiff, 12, WHITE, false), lp(0, dp(6)));

        TextView checked = text("最終確認：" + (item.lastPriceCheckedAt == null ? "未取得" : dateTime(item.lastPriceCheckedAt)) + (item.priceFetchOk ? "" : "  取得失敗"), 11, LGRAY, false);
        box.addView(checked, lp(0, dp(8)));

        Flow tags = new Flow(this);
        List<WishlistRepository.Tag> assigned = repo.tagsForItemResolved(item.id);
        for (WishlistRepository.Tag t : assigned) tags.addView(tagChip(t.name, false));
        RoundPlusIcon addTag = new RoundPlusIcon(this, ORANGE, TEXT);
        addTag.setContentDescription("タグ追加");
        addTag.setOnClickListener(v -> showTagDialog(item.id));
        tags.addView(addTag, new ViewGroup.LayoutParams(dp(30), dp(30)));
        box.addView(tags, lp(0, dp(8)));

        int purchaseCount = repo.purchaseCount(item.id);
        TextView bought = text("購入済み " + purchaseCount + "回", 13, TEXT, true);
        box.addView(bought, lp(0, dp(5)));
        List<WishlistRepository.Purchase> purchases = repo.purchases(item.id, 3);
        for (WishlistRepository.Purchase p : purchases) {
            TextView row = text(shortDate(p.purchasedAt) + "  " + price(p.price), 11, WHITE, false);
            row.setOnLongClickListener(v -> {
                repo.deletePurchase(p.id);
                refreshList();
                return true;
            });
            box.addView(row, lp(0, dp(2)));
        }

        TextView monitor = capsule(item.monitorResume ? "再開監視 ON" : "再開監視 OFF", item.monitorResume ? ORANGE : GRAY, 12);
        monitor.setOnClickListener(v -> {
            boolean next = !item.monitorResume;
            repo.setMonitor(item.id, next);
            if (next) requestNotificationPermission();
            WishlistScheduler.ensureScheduled(this);
            refreshList();
        });
        box.addView(monitor, new LinearLayout.LayoutParams(dp(116), dp(34)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView open = capsule("商品ページ", LBLUE, 12);
        open.setOnClickListener(v -> openProduct(item));
        TextView update = capsule("今すぐ更新", ORANGE, 12);
        update.setOnClickListener(v -> refreshOne(item.id));
        TextView buy = capsule("購入を記録", BLUE, 12);
        buy.setOnClickListener(v -> { repo.addPurchase(item.id, item.currentPrice); refreshList(); });
        TextView delete = capsule("削除", LRED, 12);
        delete.setOnClickListener(v -> showDeleteDialog(item));
        addAction(actions, open); addAction(actions, update); addAction(actions, buy); addAction(actions, delete);
        box.addView(actions, lp(dp(8), 0));
        return box;
    }

    private void addAction(LinearLayout row, TextView v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(36), 1f);
        p.rightMargin = dp(5);
        row.addView(v, p);
    }

    private void attachGrip(TextView grip, String id, View row) {
        final float[] downY = new float[1];
        final boolean[] moving = new boolean[1];
        grip.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (hasFilters()) return false;
                    downY[0] = e.getRawY();
                    moving[0] = false;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!moving[0] && Math.abs(e.getRawY() - downY[0]) > dp(8)) {
                        moving[0] = true;
                        v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                        row.setElevation(dp(8));
                    }
                    if (moving[0]) reorderToward(id, e.getRawY());
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    row.setElevation(0f);
                    if (moving[0] && e.getActionMasked() == MotionEvent.ACTION_UP) persistCurrentOrder();
                    moving[0] = false;
                    return true;
            }
            return true;
        });
    }

    private boolean hasFilters() { return (query != null && !query.isBlank()) || !filterTags.isEmpty() || minPrice != null || maxPrice != null; }

    private void reorderToward(String id, float rawY) {
        int from = -1, to = -1;
        for (int i=0;i<listBox.getChildCount();i++) {
            View child=listBox.getChildAt(i);
            Object tag=child.getTag();
            if (id.equals(tag)) from=i;
            int[] loc=new int[2]; child.getLocationOnScreen(loc);
            if (rawY >= loc[1] && rawY <= loc[1]+child.getHeight()) to=i;
        }
        if (from < 0 || to < 0 || from == to) return;
        View moving=listBox.getChildAt(from);
        listBox.removeViewAt(from);
        listBox.addView(moving,to);
    }

    private void persistCurrentOrder() {
        List<String> ids=new ArrayList<>();
        for(int i=0;i<listBox.getChildCount();i++) {
            Object tag=listBox.getChildAt(i).getTag(); if(tag instanceof String) ids.add((String)tag);
        }
        if (!ids.isEmpty()) repo.updateOrder(ids);
    }

    private View thumbnail(WishlistItem item) {
        FrameLayout f=new FrameLayout(this); f.setBackground(roundRect(GRAY, 9)); f.setClipToOutline(true);
        String path=item.faviconPath!=null?item.faviconPath:item.thumbnailPath;
        if(path!=null) {
            try { Bitmap b=BitmapFactory.decodeFile(path); if(b!=null){ ImageView i=new ImageView(this); i.setScaleType(ImageView.ScaleType.CENTER_CROP); i.setImageBitmap(b); f.addView(i,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)); } } catch(Throwable ignored){}
        }
        return f;
    }

    private void showSearchDialog() {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(14),dp(16),dp(14)); box.setBackground(roundRect(LGRAY,14));
        TextView title=text("検索",18,TEXT,true); box.addView(title,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(38)));
        EditText q=input("商品名・URL"); q.setText(query); box.addView(q,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(46)));
        LinearLayout prices=new LinearLayout(this); prices.setGravity(Gravity.CENTER_VERTICAL);
        EditText min=input("最低価格"); min.setInputType(InputType.TYPE_CLASS_NUMBER); if(minPrice!=null)min.setText(String.valueOf(minPrice));
        EditText max=input("最高価格"); max.setInputType(InputType.TYPE_CLASS_NUMBER); if(maxPrice!=null)max.setText(String.valueOf(maxPrice));
        prices.addView(min,new LinearLayout.LayoutParams(0,dp(44),1f)); Space sp=new Space(this); prices.addView(sp,new LinearLayout.LayoutParams(dp(8),1)); prices.addView(max,new LinearLayout.LayoutParams(0,dp(44),1f)); box.addView(prices,lp(dp(8),0));
        TextView tagTitle=text("タグ",13,TEXT,true); box.addView(tagTitle,lp(dp(10),dp(4)));
        ScrollView tagScroll=new ScrollView(this); LinearLayout tagList=new LinearLayout(this); tagList.setOrientation(LinearLayout.VERTICAL); tagScroll.addView(tagList);
        Set<Long> selected=new HashSet<>(filterTags);
        for(WishlistRepository.Tag t:repo.listTags()) tagList.addView(checkRow(t,selected));
        box.addView(tagScroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(220)));
        LinearLayout buttons=new LinearLayout(this); buttons.setGravity(Gravity.CENTER_VERTICAL);
        TextView update=capsule("価格更新",ORANGE,12); TextView clear=capsule("クリア",GRAY,12); TextView apply=capsule("適用",LBLUE,12); TextView close=capsule("閉じる",GRAY,12);
        addAction(buttons,update); addAction(buttons,clear); addAction(buttons,apply); addAction(buttons,close); box.addView(buttons,lp(dp(10),0));
        update.setOnClickListener(v -> refreshAllNow(() -> Toast.makeText(this,"価格を更新しました",Toast.LENGTH_SHORT).show()));
        clear.setOnClickListener(v -> { query=""; filterTags.clear(); minPrice=null; maxPrice=null; d.dismiss(); refreshList(); });
        apply.setOnClickListener(v -> {
            query=q.getText().toString(); filterTags.clear(); filterTags.addAll(selected); minPrice=number(min.getText().toString()); maxPrice=number(max.getText().toString());
            boolean priceSearch=minPrice!=null||maxPrice!=null;
            d.dismiss();
            if(priceSearch) refreshAllNow(this::refreshList); else refreshList();
        });
        close.setOnClickListener(v -> d.dismiss());
        d.setContentView(box); showDialog(d);
    }

    private View checkRow(WishlistRepository.Tag t, Set<Long> selected) {
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4),dp(3),dp(4),dp(3));
        TextView check=text(selected.contains(t.id)?"✓":"",15,TEXT,true); check.setGravity(Gravity.CENTER); check.setBackground(circle(selected.contains(t.id)?GREEN:GRAY)); row.addView(check,new LinearLayout.LayoutParams(dp(28),dp(28)));
        TextView name=text(t.name,14,TEXT,false); LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(0,dp(38),1f); nlp.leftMargin=dp(10); row.addView(name,nlp);
        row.setOnClickListener(v -> { if(!selected.add(t.id))selected.remove(t.id); check.setText(selected.contains(t.id)?"✓":""); check.setBackground(circle(selected.contains(t.id)?GREEN:GRAY)); });
        return row;
    }

    private View tagManageRow(String itemId, WishlistRepository.Tag t, Set<Long> selected, LinearLayout container) {
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(2),dp(2),dp(4),dp(2));
        row.setTag(t.id);
        row.setBackground(roundRect(DGRAY,7));

        TextView handle=text("☰",22,LGRAY,false);
        handle.setGravity(Gravity.CENTER);
        handle.setContentDescription(t.name+"を並べ替え");
        row.addView(handle,new LinearLayout.LayoutParams(dp(38),dp(40)));

        TextView check=text(selected.contains(t.id)?"✓":"",15,TEXT,true);
        check.setGravity(Gravity.CENTER);
        check.setBackground(circle(selected.contains(t.id)?GREEN:GRAY));
        row.addView(check,new LinearLayout.LayoutParams(dp(28),dp(28)));

        TextView name=text(t.name,14,TEXT,selected.contains(t.id));
        LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(0,dp(40),1f);
        nlp.leftMargin=dp(10);
        row.addView(name,nlp);

        row.setOnClickListener(v->{
            boolean on;
            if(selected.add(t.id)){
                on=true;
                repo.addTagToItem(itemId,t.id);
            }else{
                selected.remove(t.id);
                on=false;
                repo.removeTagFromItem(itemId,t.id);
            }
            check.setText(on?"✓":"");
            check.setBackground(circle(on?GREEN:GRAY));
            name.setTypeface(null,on?Typeface.BOLD:Typeface.NORMAL);
        });

        final float[] downY={0f};
        final boolean[] moving={false};
        handle.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    downY[0]=e.getRawY(); moving[0]=false;
                    if(v.getParent()!=null)v.getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if(!moving[0]&&Math.abs(e.getRawY()-downY[0])>dp(6)){
                        moving[0]=true;
                        v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                        row.setElevation(dp(8));
                    }
                    if(moving[0])reorderTagToward(row,e.getRawY(),container);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if(v.getParent()!=null)v.getParent().requestDisallowInterceptTouchEvent(false);
                    row.setElevation(dp(2));
                    if(moving[0]&&e.getActionMasked()==MotionEvent.ACTION_UP)persistTagOrder(container);
                    moving[0]=false;
                    return true;
                default:return true;
            }
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(44));
        lp.bottomMargin=dp(4);
        row.setLayoutParams(lp);
        return row;
    }

    private void reorderTagToward(View moving,float rawY,LinearLayout container){
        int from=container.indexOfChild(moving),to=-1;
        if(from<0)return;
        for(int i=0;i<container.getChildCount();i++){
            View child=container.getChildAt(i);
            int[] loc=new int[2]; child.getLocationOnScreen(loc);
            if(rawY>=loc[1]&&rawY<=loc[1]+child.getHeight()){to=i;break;}
        }
        if(to<0||to==from)return;
        container.removeViewAt(from);
        container.addView(moving,to);
    }

    private void persistTagOrder(LinearLayout container){
        List<Long> ids=new ArrayList<>();
        for(int i=0;i<container.getChildCount();i++){
            Object tag=container.getChildAt(i).getTag();
            if(tag instanceof Long)ids.add((Long)tag);
        }
        if(!ids.isEmpty())repo.setTagOrder(ids);
    }

    private void showTagDialog(String itemId) {
        Dialog d=new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(14),dp(16),dp(14)); box.setBackground(roundRect(LGRAY,14));
        box.addView(text("タグ選択",18,TEXT,true),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(38)));
        Set<Long> selected=new HashSet<>(repo.tagsForItem(itemId));
        LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL);
        Runnable rebuild=()->{
            rows.removeAllViews();
            for(WishlistRepository.Tag t:repo.listTags()) {
                View r=tagManageRow(itemId,t,selected,rows);
                r.setOnLongClickListener(v->{ showTagRenameDelete(t,()->showTagDialog(itemId)); d.dismiss(); return true;});
                rows.addView(r);
            }
        };
        rebuild.run();
        ScrollView scroll=new ScrollView(this); scroll.addView(rows); box.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(230)));
        LinearLayout create=new LinearLayout(this); create.setGravity(Gravity.CENTER_VERTICAL);
        EditText input=input("新しいタグ");
        RoundPlusIcon plus=new RoundPlusIcon(this,ORANGE,TEXT); plus.setContentDescription("タグ追加");
        create.addView(input,new LinearLayout.LayoutParams(0,dp(44),1f));
        FrameLayout plusSlot=new FrameLayout(this); LinearLayout.LayoutParams slotLp=new LinearLayout.LayoutParams(dp(52),dp(44)); slotLp.leftMargin=dp(8); create.addView(plusSlot,slotLp);
        plusSlot.addView(plus,new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.CENTER));
        box.addView(create,lp(dp(8),0));
        plus.setOnClickListener(v->{
            WishlistRepository.Tag t=repo.createTag(input.getText().toString());
            if(t==null){
                Toast.makeText(this,"タグ名を入力してください",Toast.LENGTH_SHORT).show();
                return;
            }
            selected.add(t.id);
            repo.addTagToItem(itemId,t.id);
            input.setText("");
            rebuild.run();
        });
        LinearLayout bottom=new LinearLayout(this); TextView apply=capsule("適用",LBLUE,12); TextView close=capsule("閉じる",GRAY,12); bottom.addView(apply,new LinearLayout.LayoutParams(0,dp(42),1f)); Space gap=new Space(this); bottom.addView(gap,new LinearLayout.LayoutParams(dp(8),1)); bottom.addView(close,new LinearLayout.LayoutParams(0,dp(42),1f)); box.addView(bottom,lp(dp(10),0));
        apply.setOnClickListener(v->{ repo.setTagsForItem(itemId,selected); d.dismiss(); });
        close.setOnClickListener(v->{ repo.setTagsForItem(itemId,selected); d.dismiss(); });
        d.setOnDismissListener(v->refreshList());
        d.setContentView(box); showDialog(d);
    }

    private void showTagRenameDelete(WishlistRepository.Tag tag, Runnable after) {
        Dialog d=new Dialog(this); d.requestWindowFeature(Window.FEATURE_NO_TITLE); LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setPadding(dp(16),dp(14),dp(16),dp(14)); b.setBackground(roundRect(LGRAY,14)); EditText in=input("タグ名"); in.setText(tag.name); b.addView(in,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(46))); LinearLayout row=new LinearLayout(this); TextView del=capsule("削除",LRED,12); TextView save=capsule("保存",LBLUE,12); TextView close=capsule("閉じる",GRAY,12); addAction(row,del);addAction(row,save);addAction(row,close);b.addView(row,lp(dp(10),0)); del.setOnClickListener(v->{repo.deleteTag(tag.id);d.dismiss();after.run();});save.setOnClickListener(v->{repo.renameTag(tag.id,in.getText().toString());d.dismiss();after.run();});close.setOnClickListener(v->d.dismiss());d.setContentView(b);showDialog(d);
    }

    private void openProduct(WishlistItem item) {
        if(item.url==null||item.url.isBlank())return;
        pendingPurchaseItemId=item.id; pendingExternalStart=SystemClock.elapsedRealtime(); leftForProduct=true;
        try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(item.url)));}catch(Exception e){leftForProduct=false;Toast.makeText(this,"商品ページを開けません",Toast.LENGTH_SHORT).show();}
    }

    private void showPurchasePrompt(String itemId) {
        long today = System.currentTimeMillis() / DAY_MS;
        if (promptPrefs != null) {
            if (promptPrefs.getBoolean("never_" + itemId, false)) return;
            if (promptPrefs.getLong("skipday_" + itemId, -1L) == today) return;
        }
        if(purchaseBar!=null){root.removeView(purchaseBar);purchaseBar=null;}
        WishlistItem item=repo.get(itemId); if(item==null)return;
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(12),dp(5),dp(8),dp(5));bar.setBackground(roundRect(DGRAY,12));
        LinearLayout msgBox=new LinearLayout(this);msgBox.setOrientation(LinearLayout.VERTICAL);msgBox.setGravity(Gravity.CENTER_VERTICAL);
        TextView msg=text("購入しましたか？",14,TEXT,true);msgBox.addView(msg,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(28)));
        TextView never=text("この商品では今後表示しない",10,LGRAY,false);never.setOnClickListener(v->{if(promptPrefs!=null)promptPrefs.edit().putBoolean("never_"+itemId,true).apply();hidePurchasePrompt();});msgBox.addView(never,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(22)));
        bar.addView(msgBox,new LinearLayout.LayoutParams(0,dp(50),1f));
        TextView add=capsule("購入済みに追加",BLUE,12);TextView x=capsule("×",GRAY,16);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(122),dp(38));ap.rightMargin=dp(6);bar.addView(add,ap);bar.addView(x,new LinearLayout.LayoutParams(dp(42),dp(38)));
        add.setOnClickListener(v->{repo.addPurchase(itemId,item.currentPrice);hidePurchasePrompt();refreshList();});
        x.setOnClickListener(v->{if(promptPrefs!=null)promptPrefs.edit().putLong("skipday_"+itemId,today).apply();hidePurchasePrompt();});
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(64),Gravity.BOTTOM);p.setMargins(dp(12),0,dp(12),dp(18));root.addView(bar,p);purchaseBar=bar;
    }
    private void hidePurchasePrompt(){if(purchaseBar!=null){root.removeView(purchaseBar);purchaseBar=null;}}

    private void refreshOne(String id) {
        Toast.makeText(this,"更新中…",Toast.LENGTH_SHORT).show(); io.execute(()->{WishlistItem before=repo.get(id);if(before!=null){WishlistCrawler.Result r=WishlistCrawler.fetch(before.url);repo.updateCrawl(id,r);}runOnUiThread(this::refreshList);});
    }

    private void refreshAllNow(Runnable done) {
        Toast.makeText(this,"Wishlistを更新中…",Toast.LENGTH_SHORT).show(); io.execute(()->{for(WishlistItem i:repo.listAll()){if(Thread.currentThread().isInterrupted())break; WishlistCrawler.Result r=WishlistCrawler.fetch(i.url);repo.updateCrawl(i.id,r);try{Thread.sleep(350);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}}runOnUiThread(()->{refreshList();if(done!=null)done.run();});});
    }

    private void maybeRefreshStale() {
        long now=System.currentTimeMillis(); boolean stale=false; for(WishlistItem i:repo.listAll())if(i.lastPriceCheckedAt==null||now-i.lastPriceCheckedAt>DAY_MS){stale=true;break;} if(!stale)return; io.execute(()->{for(WishlistItem i:repo.listAll()){if(i.lastPriceCheckedAt!=null&&now-i.lastPriceCheckedAt<=DAY_MS)continue;WishlistCrawler.Result r=WishlistCrawler.fetch(i.url);repo.updateCrawl(i.id,r);try{Thread.sleep(350);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}}runOnUiThread(this::refreshList);});
    }

    private void showDeleteDialog(WishlistItem item) {
        android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(this).setMessage("Wishlistから削除しますか？").setNegativeButton("キャンセル",null).setPositiveButton("削除",(d,w)->{repo.delete(item.id);if(item.id.equals(expandedId))expandedId=null;refreshList();}).create();dialog.setOnShowListener(x->{if(dialog.getWindow()!=null)dialog.getWindow().setBackgroundDrawable(roundRect(LGRAY,14));});dialog.show();
    }

    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},811);}

    private String collapsedSub(WishlistItem i){String s=statusLabel(i.status); if(i.monitorResume)s+="  • 再開監視";return s;}
    private int statusColor(String s){if("AVAILABLE".equals(s))return WHITE;if("UNAVAILABLE".equals(s))return LRED;if("COMING_SOON".equals(s))return ORANGE;return LGRAY;}
    private String statusLabel(String s){if("AVAILABLE".equals(s))return "購入可能";if("UNAVAILABLE".equals(s))return "現在購入不可";if("COMING_SOON".equals(s))return "未開始";return "状態未確認";}
    private static String price(Long p){return p==null?"—":"¥"+String.format(Locale.JAPAN,"%,d",p);}
    private String dateTime(long t){return DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(t));}
    private String shortDate(long t){return new java.text.SimpleDateFormat("M/d",Locale.JAPAN).format(new Date(t));}
    private Long number(String s){try{String v=s==null?"":s.replace(",","").trim();return v.isBlank()?null:Long.parseLong(v);}catch(Exception e){return null;}}

    private TextView field(String label,String value){LinearLayout b=new LinearLayout(this);return text(label+"  "+value,12,TEXT,false);}
    private EditText input(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(DGRAY);e.setHintTextColor(GRAY);e.setTextSize(14);e.setHint(hint);e.setPadding(dp(12),0,dp(12),0);e.setBackground(roundRect(WHITE,999));return e;}
    private TextView text(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setIncludeFontPadding(false);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private TextView capsule(String s,int color,float size){TextView t=text(s,size,TEXT,true);t.setGravity(Gravity.CENTER);t.setBackground(roundRect(color,999));t.setPadding(dp(8),0,dp(8),0);return t;}
    private TextView tagChip(String s,boolean add){TextView t=capsule(s,add?ORANGE:GRAY,12);t.setPadding(dp(10),0,dp(10),0);t.setMinHeight(dp(30));return t;}
    private GradientDrawable roundRect(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable circle(int color){GradientDrawable d=new GradientDrawable();d.setShape(GradientDrawable.OVAL);d.setColor(color);return d;}
    private LinearLayout.LayoutParams lp(int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,top,0,bottom);return p;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void showDialog(Dialog d){d.setOnShowListener(x->{Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);WindowManager.LayoutParams p=w.getAttributes();p.width=getResources().getDisplayMetrics().widthPixels-dp(32);p.height=WindowManager.LayoutParams.WRAP_CONTENT;p.gravity=Gravity.CENTER;w.setAttributes(p);}});d.show();}

    private static final class RoundPlusIcon extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fg = new Paint(Paint.ANTI_ALIAS_FLAG);
        RoundPlusIcon(Activity c, int background, int iconColor) {
            super(c);
            bg.setColor(background);
            bg.setStyle(Paint.Style.FILL);
            fg.setColor(iconColor);
            fg.setStyle(Paint.Style.STROKE);
            fg.setStrokeCap(Paint.Cap.ROUND);
            fg.setStrokeWidth(c.getResources().getDisplayMetrics().density * 2.4f);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight(), cx=w/2f, cy=h/2f;
            float r=Math.min(w,h)*.48f;
            c.drawCircle(cx,cy,r,bg);
            float arm=r*.43f;
            c.drawLine(cx-arm,cy,cx+arm,cy,fg);
            c.drawLine(cx,cy-arm,cx,cy+arm,fg);
        }
    }

    private static final class SearchIcon extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        SearchIcon(Activity c){super(c);p.setColor(WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(c.getResources().getDisplayMetrics().density*2.8f);p.setStrokeCap(Paint.Cap.ROUND);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();float r=Math.min(w,h)*.27f;float cx=w*.43f,cy=h*.43f;c.drawCircle(cx,cy,r,p);c.drawLine(cx+r*.72f,cy+r*.72f,w*.78f,h*.78f,p);}
    }

    private static final class Flow extends ViewGroup {
        private final int gap;
        Flow(Activity c){super(c);gap=Math.round(6*c.getResources().getDisplayMetrics().density);}
        @Override protected LayoutParams generateDefaultLayoutParams(){return new MarginLayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);}
        @Override protected LayoutParams generateLayoutParams(android.util.AttributeSet attrs){return new MarginLayoutParams(getContext(),attrs);}
        @Override protected LayoutParams generateLayoutParams(LayoutParams p){return new MarginLayoutParams(p);}
        @Override protected boolean checkLayoutParams(LayoutParams p){return p instanceof MarginLayoutParams;}
        @Override protected void onMeasure(int ws,int hs){int w=MeasureSpec.getSize(ws),x=getPaddingLeft(),y=getPaddingTop(),line=0;for(int i=0;i<getChildCount();i++){View v=getChildAt(i);measureChild(v,ws,hs);if(x+v.getMeasuredWidth()+getPaddingRight()>w&&x>getPaddingLeft()){x=getPaddingLeft();y+=line+gap;line=0;}x+=v.getMeasuredWidth()+gap;line=Math.max(line,v.getMeasuredHeight());}setMeasuredDimension(w,y+line+getPaddingBottom());}
        @Override protected void onLayout(boolean ch,int l,int t,int r,int b){int x=getPaddingLeft(),y=getPaddingTop(),line=0,w=r-l;for(int i=0;i<getChildCount();i++){View v=getChildAt(i);if(x+v.getMeasuredWidth()+getPaddingRight()>w&&x>getPaddingLeft()){x=getPaddingLeft();y+=line+gap;line=0;}v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());x+=v.getMeasuredWidth()+gap;line=Math.max(line,v.getMeasuredHeight());}}
    }
}
