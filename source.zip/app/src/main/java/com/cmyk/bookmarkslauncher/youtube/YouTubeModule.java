package com.cmyk.bookmarkslauncher.youtube;

import android.app.Activity;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;

/** Public facade for BookmarkLauncher's isolated YouTube integration. */
public final class YouTubeModule {
    private YouTubeModule() {}

    public interface CaptureCallback {
        void onComplete(boolean success, BookmarkNode updatedNode, String message);
    }

    public interface CaptureController {
        void capture(BookmarkNode node, CaptureCallback callback);
        void cancel();
        void destroy();
    }

    public static boolean handles(String url) {
        return YouTubeLink.isYouTubeUrl(url);
    }

    public static CaptureController createCaptureController(Activity activity, BookmarkRepository repo) {
        final YouTubeCaptureManager manager = new YouTubeCaptureManager(activity, repo);
        return new CaptureController() {
            @Override
            public void capture(BookmarkNode node, CaptureCallback callback) {
                manager.capture(node, callback == null ? null : callback::onComplete);
            }

            @Override
            public void cancel() {
                manager.cancel();
            }

            @Override
            public void destroy() {
                manager.destroy();
            }
        };
    }
}
