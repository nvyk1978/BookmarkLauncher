package com.cmyk.bookmarkslauncher.wishlist;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

public final class WishlistScheduler {
    private static final int JOB_ID = 9184;
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;
    private WishlistScheduler() {}

    public static void ensureScheduled(Context context) {
        JobScheduler js = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        for (JobInfo info : js.getAllPendingJobs()) if (info.getId() == JOB_ID) return;
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(context, WishlistCrawlJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(DAY_MS)
                .build();
        js.schedule(job);
    }
}
