package com.cmyk.bookmarkslauncher.wishlist;

import android.text.Html;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Keyword-scoped JPY price only. Does not consume product-title parser output. */
final class WishlistNotePriceExtractor {
    private static final Pattern YEN=Pattern.compile("(?:[¥￥]\\s*([0-9][0-9,]*)|([0-9][0-9,]*)\\s*円)");
    private static final Pattern SKIP=Pattern.compile("(?:送料|手数料|梱包料|ポイント|値引|割引)[^。]{0,14}$");
    static Long price(String after) {
        String text=Html.fromHtml(after.replaceAll("(?is)<(?:script|style)\\b[^>]*>.*?</(?:script|style)>", " "),
                Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("[\\s　]+"," ");
        // Ignore distant product recommendations and unrelated footer notices.
        if(text.length()>900)text=text.substring(0,900);
        HashSet<Long> prices=new HashSet<>();
        Matcher m=YEN.matcher(text);
        while(m.find()) {
            String before=text.substring(Math.max(0,m.start()-18),m.start());
            if(SKIP.matcher(before).find())continue;
            String n=(m.group(1)!=null?m.group(1):m.group(2)).replace(",", "");
            try {long p=Long.parseLong(n);if(p>0&&p<=100000000)prices.add(p);}catch(NumberFormatException ignored){}
        }
        // Multiple prices in the same block are variants, not one reliable value.
        return prices.size()==1?prices.iterator().next():null;
    }
}
