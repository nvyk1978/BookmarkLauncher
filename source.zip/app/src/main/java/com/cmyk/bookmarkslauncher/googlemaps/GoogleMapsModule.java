package com.cmyk.bookmarkslauncher.googlemaps;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.widget.FrameLayout;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;

/**
 * The only public entry point for BookmarkLauncher's Google Maps integration.
 *
 * Keep Maps-specific URL parsing, share-title cleanup, WebView/Geocoder capture,
 * static-map generation and pin rendering behind this facade. Normal bookmark
 * code should only ask this module whether it handles a URL, then delegate.
 */
public final class GoogleMapsModule {
    private GoogleMapsModule() {}

    private static final int N_DGRAY = 0xFF252020;
    private static final int N_LRED = 0xFF662211;

    public interface CaptureCallback {
        void onComplete(boolean success, BookmarkNode updatedNode, String message);
    }

    public interface CaptureController {
        void capture(BookmarkNode node, CaptureCallback callback);
        void cancel();
        void destroy();
    }

    public static CaptureController createCaptureController(Activity activity, FrameLayout host, BookmarkRepository repo) {
        final GoogleMapsCaptureManager manager = new GoogleMapsCaptureManager(activity, host, repo);
        return new CaptureController() {
            @Override
            public void capture(BookmarkNode node, CaptureCallback callback) {
                manager.capture(node, callback == null ? null : callback::onComplete);
            }

            @Override
            public void cancel() {
                manager.cancel();
            }

            @Override
            public void destroy() {
                manager.destroy();
            }
        };
    }

    public static boolean handles(String url) {
        return GoogleMapsLink.isGoogleMapsUrl(url);
    }

    /**
     * Returns a Maps-specific initial title, or null when the URL is not Google Maps.
     * The returned fallback is always safe for immediate DB insertion; the capture
     * flow later replaces it with the resolved shop/facility name.
     */
    public static String resolveSharedTitle(CharSequence sharedText, CharSequence subject, String url) {
        if (!handles(url)) return null;
        String text = sharedText == null ? null : sharedText.toString();
        String fromText = GoogleMapsLink.extractSharedPlaceName(text, url);
        if (fromText != null) return fromText;
        String fromSubject = subject == null ? null : GoogleMapsLink.cleanPlaceName(subject.toString());
        return fromSubject != null ? fromSubject : url;
    }

    /** Draws the complete Google Maps bookmark tile and returns true when handled. */
    public static boolean drawBookmarkIfHandled(Canvas canvas, Paint paint, String url, RectF bounds) {
        if (!handles(url) || canvas == null || paint == null || bounds == null) return false;
        float radius = bounds.width() / 2f;
        float cx = bounds.centerX();
        float cy = bounds.centerY();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_DGRAY);
        canvas.drawCircle(cx, cy, radius, paint);
        drawPin(canvas, paint, cx, cy, radius * 1.46f * 0.80f * 0.20f);
        return true;
    }

    /** Draws the pin used inside a folder preview. Call only for a URL handled by this module. */
    public static void drawPreviewPin(Canvas canvas, Paint paint, float cx, float cy, float radius) {
        if (canvas == null || paint == null) return;
        drawPin(canvas, paint, cx, cy, radius * 1.42f * 0.80f * 0.20f);
    }

    private static void drawPin(Canvas canvas, Paint paint, float cx, float cy, float height) {
        float scale = height / 120f;
        float left = cx - 50f * scale;
        float top = cy - 60f * scale;

        Path path = new Path();
        path.setFillType(Path.FillType.EVEN_ODD);
        path.moveTo(left + 50f * scale, top + 4f * scale);
        path.cubicTo(left + 28f * scale, top + 4f * scale,
                left + 12f * scale, top + 21f * scale,
                left + 12f * scale, top + 43f * scale);
        path.cubicTo(left + 12f * scale, top + 70f * scale,
                left + 43f * scale, top + 109f * scale,
                left + 48f * scale, top + 115f * scale);
        path.cubicTo(left + 49f * scale, top + 117f * scale,
                left + 51f * scale, top + 117f * scale,
                left + 52f * scale, top + 115f * scale);
        path.cubicTo(left + 57f * scale, top + 109f * scale,
                left + 88f * scale, top + 70f * scale,
                left + 88f * scale, top + 43f * scale);
        path.cubicTo(left + 88f * scale, top + 21f * scale,
                left + 72f * scale, top + 4f * scale,
                left + 50f * scale, top + 4f * scale);
        path.close();
        path.addCircle(left + 50f * scale, top + 46f * scale, 18f * scale, Path.Direction.CW);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_LRED);
        canvas.drawPath(path, paint);
    }
}
