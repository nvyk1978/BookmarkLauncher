package com.cmyk.bookmarkslauncher.googlemaps;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.FrameLayout;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;

/**
 * The only public entry point for BookmarkLauncher's Google Maps integration.
 *
 * Keep Maps-specific URL parsing, share-title cleanup, WebView/Geocoder capture,
 * static-map generation and pin rendering behind this facade. Normal bookmark
 * code should only ask this module whether it handles a URL, then delegate.
 */
public final class GoogleMapsModule {
    private GoogleMapsModule() {}

    private static final int N_DGRAY = 0xFF252020;
    private static final int N_LRED = 0xFF662211;
    private static final ExecutorService MAP_RENDER_EXECUTOR = Executors.newSingleThreadExecutor();

    public interface CaptureCallback {
        void onComplete(boolean success, BookmarkNode updatedNode, String message);
    }

    public interface CaptureController {
        void capture(BookmarkNode node, CaptureCallback callback);
        void cancel();
        void destroy();
    }

    public static CaptureController createCaptureController(Activity activity, FrameLayout host, BookmarkRepository repo) {
        final GoogleMapsCaptureManager manager = new GoogleMapsCaptureManager(activity, host, repo);
        return new CaptureController() {
            @Override
            public void capture(BookmarkNode node, CaptureCallback callback) {
                manager.capture(node, callback == null ? null : callback::onComplete);
            }

            @Override
            public void cancel() {
                manager.cancel();
            }

            @Override
            public void destroy() {
                manager.destroy();
            }
        };
    }

    public static boolean handles(String url) {
        return GoogleMapsLink.isGoogleMapsUrl(url);
    }

    /**
     * Returns a Maps-specific initial title, or null when the URL is not Google Maps.
     * The returned fallback is always safe for immediate DB insertion; the capture
     * flow later replaces it with the resolved shop/facility name.
     */
    public static String resolveSharedTitle(CharSequence sharedText, CharSequence subject, String url) {
        if (!handles(url)) return null;
        String text = sharedText == null ? null : sharedText.toString();
        String fromText = GoogleMapsLink.extractSharedPlaceName(text, url);
        if (fromText != null) return fromText;
        String fromSubject = subject == null ? null : GoogleMapsLink.cleanPlaceName(subject.toString());
        return fromSubject != null ? fromSubject : url;
    }

    /** Draws the complete Google Maps bookmark tile and returns true when handled. */
    public static boolean drawBookmarkIfHandled(Canvas canvas, Paint paint, String url, RectF bounds) {
        if (!handles(url) || canvas == null || paint == null || bounds == null) return false;
        float radius = bounds.width() / 2f;
        float cx = bounds.centerX();
        float cy = bounds.centerY();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_DGRAY);
        canvas.drawCircle(cx, cy, radius, paint);
        drawPin(canvas, paint, cx, cy, radius * 1.46f * 0.70f);
        return true;
    }

    /** Draws the pin used inside a folder preview. Call only for a URL handled by this module. */
    public static void drawPreviewPin(Canvas canvas, Paint paint, float cx, float cy, float radius) {
        if (canvas == null || paint == null) return;
        drawPin(canvas, paint, cx, cy, radius * 1.42f * 0.70f);
    }


    public interface ThumbnailScaleListener {
        /** Called continuously during a pinch. 1.0 is the bitmap scale at gesture start. */
        default void onPreviewScale(float relativeScale) {}
        void onRenderStarted();
        void onRenderComplete(boolean success, boolean requiresCapture, String screenshotPath);
    }

    /**
     * Installs pinch-to-zoom only for Google Maps thumbnails. The gesture changes the
     * map coverage, not merely the ImageView transform: when the fingers are released
     * the static map is rebuilt from tiles and the per-bookmark scale is persisted.
     *
     * @return true when this bookmark is handled by the Maps module.
     */
    public static boolean attachThumbnailScaleGestureIfHandled(Activity activity, View target,
                                                                 BookmarkNode node, ThumbnailScaleListener listener) {
        if (activity == null || target == null || node == null || !handles(node.url)) return false;

        final float[] gestureStart = {GoogleMapsStateStore.getScale(activity, node.id)};
        final float[] pendingScale = {gestureStart[0]};
        final boolean[] pinchSeen = {false};

        ScaleGestureDetector detector = new ScaleGestureDetector(activity,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScaleBegin(ScaleGestureDetector d) {
                        gestureStart[0] = GoogleMapsStateStore.getScale(activity, node.id);
                        pendingScale[0] = gestureStart[0];
                        pinchSeen[0] = true;
                        if (listener != null) listener.onPreviewScale(1f);
                        return true;
                    }

                    @Override
                    public boolean onScale(ScaleGestureDetector d) {
                        pendingScale[0] = GoogleMapsStateStore.clampScale(pendingScale[0] * d.getScaleFactor());
                        float relative = gestureStart[0] <= 0f ? 1f : pendingScale[0] / gestureStart[0];
                        if (listener != null) listener.onPreviewScale(relative);
                        return true;
                    }

                    @Override
                    public void onScaleEnd(ScaleGestureDetector d) {
                        float finalScale = GoogleMapsStateStore.clampScale(pendingScale[0]);
                        if (Math.abs(finalScale - gestureStart[0]) < 0.015f) {
                            if (listener != null) listener.onPreviewScale(1f);
                            return;
                        }
                        // Keep the transformed current bitmap visible while a sharp map for the
                        // new coverage is rendered in the background. The detail dialog resets
                        // the transform only after the replacement bitmap has been installed.
                        GoogleMapsStateStore.saveScale(activity, node.id, finalScale);
                        regenerateSavedMap(activity, node, finalScale, listener);
                    }
                });

        target.setOnTouchListener((v, event) -> {
            boolean wasScaling = detector.isInProgress();
            detector.onTouchEvent(event);
            boolean scaling = detector.isInProgress();
            int action = event.getActionMasked();
            boolean multiTouch = event.getPointerCount() > 1 || action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_POINTER_UP;
            boolean consume = wasScaling || scaling || multiTouch || pinchSeen[0];
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                boolean hadPinch = pinchSeen[0];
                pinchSeen[0] = false;
                if (hadPinch) return true;
            }
            return consume;
        });
        return true;
    }

    private static void regenerateSavedMap(Activity activity, BookmarkNode node, float scale, ThumbnailScaleListener listener) {
        if (listener != null) listener.onRenderStarted();
        GoogleMapsStateStore.SavedCoordinates coordinates = GoogleMapsStateStore.getCoordinates(activity, node.id);
        if (coordinates == null) {
            activity.runOnUiThread(() -> {
                if (listener != null) listener.onRenderComplete(false, true, node.screenshotPath);
            });
            return;
        }

        MAP_RENDER_EXECUTOR.execute(() -> {
            String path = null;
            boolean success = false;
            try {
                File target;
                if (node.screenshotPath != null && !node.screenshotPath.isBlank()) {
                    target = new File(node.screenshotPath);
                } else {
                    File assets = new File(activity.getFilesDir(), "bookmark_assets");
                    if (!assets.exists()) assets.mkdirs();
                    target = new File(assets, node.id + "_thumb.jpg");
                }
                success = StaticMapThumbnail.generate(coordinates.latitude, coordinates.longitude, target, scale);
                if (success) path = target.getAbsolutePath();
            } catch (Throwable ignored) {
            }
            final boolean ok = success;
            final String finalPath = path;
            activity.runOnUiThread(() -> {
                if (listener != null) listener.onRenderComplete(ok, false, finalPath);
            });
        });
    }

    private static void drawPin(Canvas canvas, Paint paint, float cx, float cy, float height) {
        float scale = height / 120f;
        float left = cx - 50f * scale;
        float top = cy - 60f * scale;

        Path path = new Path();
        path.setFillType(Path.FillType.EVEN_ODD);
        path.moveTo(left + 50f * scale, top + 4f * scale);
        path.cubicTo(left + 28f * scale, top + 4f * scale,
                left + 12f * scale, top + 21f * scale,
                left + 12f * scale, top + 43f * scale);
        path.cubicTo(left + 12f * scale, top + 70f * scale,
                left + 43f * scale, top + 109f * scale,
                left + 48f * scale, top + 115f * scale);
        path.cubicTo(left + 49f * scale, top + 117f * scale,
                left + 51f * scale, top + 117f * scale,
                left + 52f * scale, top + 115f * scale);
        path.cubicTo(left + 57f * scale, top + 109f * scale,
                left + 88f * scale, top + 70f * scale,
                left + 88f * scale, top + 43f * scale);
        path.cubicTo(left + 88f * scale, top + 21f * scale,
                left + 72f * scale, top + 4f * scale,
                left + 50f * scale, top + 4f * scale);
        path.close();
        path.addCircle(left + 50f * scale, top + 46f * scale, 18f * scale, Path.Direction.CW);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_LRED);
        canvas.drawPath(path, paint);
    }
}
