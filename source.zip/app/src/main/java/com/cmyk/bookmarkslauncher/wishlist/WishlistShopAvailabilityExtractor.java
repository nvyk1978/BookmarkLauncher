package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Site-specific purchase evidence only. Never changes name/image/price parsing. */
final class WishlistShopAvailabilityExtractor {
    static final class Evidence {
        final String status, reason;
        final boolean explicit;
        Evidence(String status, boolean explicit, String reason) {
            this.status = status; this.explicit = explicit; this.reason = reason;
        }
    }
    private static final Pattern LINK = Pattern.compile("(?is)<a\\b([^>]*)>(.*?)</a\\s*>");
    private static final Pattern FORM = Pattern.compile("(?is)<form\\b([^>]*)>(.*?)</form\\s*>");
    private static final Pattern INPUT_QUANTITY = Pattern.compile("(?i)(?:type\\s*=\\s*['\"]?number|name\\s*=\\s*['\"]?(?:quantity|qty|count))");
    private static final Pattern BUY = Pattern.compile("(?i)(?:カートに入れる|買い物かごに入れる|購入する)");
    private static final Pattern DISABLED = Pattern.compile("(?i)(?:\\sdisabled(?:\\s|=|>)|aria-disabled\\s*=\\s*['\"]?true|display\\s*:\\s*none)");
    private WishlistShopAvailabilityExtractor() { }
    static Evidence inspect(String html, URL page) {
        if (html == null || page == null) return null;
        String host = page.getHost().toLowerCase(Locale.ROOT);
        String path = page.getPath().toLowerCase(Locale.ROOT);
        if (host.equals("nakasima-inc.shop") && path.matches("/item-detail/[0-9]+/?")) {
            // Raku-uru uses external cart links and quantity controls, not an
            // ordinary action=cart POST form. Header's generic 'カート' is excluded.
            Matcher links = LINK.matcher(html);
            while (links.find()) {
                String attrs = links.group(1), label = links.group(2).replaceAll("(?s)<[^>]*>", " ");
                if (!BUY.matcher(label).find() || DISABLED.matcher(attrs).find()) continue;
                if (!(attrs.contains("cart.raku-uru.jp") || attrs.contains("addCart")
                        || attrs.contains("add-cart"))) continue;
                String near = html.substring(Math.max(0, links.start() - 1500), links.start());
                if (INPUT_QUANTITY.matcher(near).find())
                    return new Evidence("AVAILABLE", false, "らくうる商品数量欄と有効な購入リンク");
            }
            return new Evidence("UNKNOWN", false, "らくうるの商品固有購入リンクを検証できず");
        }
        if (host.endsWith("torikan.net") && path.matches(".*/products/detail/[0-9]+/?")) {
            // EC-CUBE: require a matching product-id hidden input and an
            // enabled add-to-cart control in the SAME form.
            String id = path.replaceAll(".*/detail/([0-9]+)/?", "$1");
            Matcher forms = FORM.matcher(html);
            while (forms.find()) {
                String body = forms.group(2);
                if (!Pattern.compile("(?is)name\\s*=\\s*['\"]?product_id['\"]?[^>]*value\\s*=\\s*['\"]?"+Pattern.quote(id)+"(?:['\"\\s>])").matcher(body).find()) continue;
                if (BUY.matcher(body.replaceAll("(?s)<[^>]*>"," ")).find()
                        && !DISABLED.matcher(forms.group(1)).find())
                    return new Evidence("AVAILABLE", false, "EC-CUBE対象商品フォーム");
            }
            return new Evidence("UNKNOWN", false, "EC-CUBE対象商品の購入フォーム未検証");
        }
        if (host.equals("eshop.fumuroya.com") && path.matches("/product/detail/[0-9]+/?"))
            return new Evidence("UNKNOWN", false, "不室屋の動的購入操作は表示状態を要検証");
        return null;
    }
}
