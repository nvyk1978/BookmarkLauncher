package com.cmyk.bookmarkslauncher.wishlist;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Independent, bounded, read-only Premium Bandai official shop-list fallback.
 *
 * The /item/item-NNN detail route frequently returns a verification shell
 * instead of product data. The official shop's publicly listed product card
 * carries the exact ID alongside its price/status; NEVER use a nearby card,
 * shop header or absence from a list as evidence about the saved item.
 *
 * Background-thread use only. No login, purchasing, search endpoint or
 * challenge bypass. Shop lists are newest-first, so an older saved product
 * may not be in the bounded pages and must remain UNKNOWN.
 */
public final class WishlistPremiumBandaiListingLookup {
    private WishlistPremiumBandaiListingLookup() { }

    private static final Pattern ITEM = Pattern.compile("^/item/item-([0-9]{7,13})/?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern CARD = Pattern.compile("(?is)<div\\s+class\\s*=\\s*['\"]article_area['\"]\\s*>(.*?)<!--\\s*/\\s*article_area\\s*-->");
    private static final Pattern CARD_ID = Pattern.compile("/item/item-([0-9]{7,13})/", Pattern.CASE_INSENSITIVE);
    private static final Pattern TITLE = Pattern.compile("(?is)<p\\s+class=['\"]article_title['\"]\\s*>\\s*<a\\b[^>]*>(.*?)</a>");
    private static final Pattern PRICE = Pattern.compile("(?is)<p\\s+class=['\"]price['\"]\\s*>\\s*([0-9][0-9,]*)\\s*円");
    private static final Pattern IMAGE = Pattern.compile("(?is)<div\\s+class=['\"]article_photo_s['\"]\\s*>\\s*<a\\b[^>]*>\\s*<img\\b[^>]*\\bsrc=['\"]([^'\"]+)['\"]");
    private static final Pattern ICON = Pattern.compile("(?i)/bc/img/icon/([a-z_0-9]+)\\.gif");
    private static final Pattern TAG = Pattern.compile("(?s)<[^>]*>");
    private static final String[] SHOPS = {
            "tamashiiwebshouten", "hobby", "carddas",
            "gundambase/a0001", "gundambase/a0002"
    };
    private static final int MAX_PAGES = 8;
    private static final int MAX_RESPONSE_BYTES = 850_000;

    public static final class Result {
        public final String itemId;
        public final String title;
        public final Long price;
        public final String image;
        /** AVAILABLE, UNAVAILABLE or UNKNOWN. The value is about one item. */
        public final String status;
        public final String statusReason;
        Result(String id, String name, Long yen, String photo, String stock, String reason) {
            itemId=id;title=name;price=yen;image=photo;status=stock;statusReason=reason;
        }
    }

    public static boolean supports(URL itemUrl) {
        if (itemUrl==null || !"https".equalsIgnoreCase(itemUrl.getProtocol())) return false;
        String host=itemUrl.getHost().toLowerCase(Locale.ROOT);
        return ("p-bandai.jp".equals(host) || "www.p-bandai.jp".equals(host))
                && ITEM.matcher(itemUrl.getPath()).matches();
    }

    /** Only exact official cards, not text around a product ID. Pure/fixture-testable. */
    public static Result parseListing(URL savedItem, String html) {
        if(!supports(savedItem) || html==null || !html.contains("article_area")) return null;
        Matcher wanted=ITEM.matcher(savedItem.getPath());
        if(!wanted.matches()) return null;
        String id=wanted.group(1);
        Result found=null;
        Matcher cards=CARD.matcher(html);
        while(cards.find()) {
            String card=cards.group(1);
            Matcher ids=CARD_ID.matcher(card);
            Set<String> cardIds=new HashSet<>();
            while(ids.find())cardIds.add(ids.group(1));
            // A mixed promotional/multi-product block cannot certify a card.
            if(cardIds.size()!=1 || !cardIds.contains(id)) continue;
            Matcher name=TITLE.matcher(card);
            if(!name.find()) continue;
            String title=decode(name.group(1));
            if(title.length()<3 || title.length()>240) continue;
            Matcher price=PRICE.matcher(card);
            Long yen=null;
            if(price.find()) {
                String digits=price.group(1).replace(",", "");
                try { long value=Long.parseLong(digits);if(value>=1&&value<=20_000_000) yen=value; }
                catch(NumberFormatException ignored) { }
                // Conflicting prices in one card are not an exact product price.
                if(price.find() && !price.group(1).replace(",", "").equals(digits))yen=null;
            }
            Matcher photo=IMAGE.matcher(card);
            String img=null;
            if(photo.find()) {
                String raw=decodeEntities(photo.group(1));
                try {
                    URL abs=new URL(new URL("https://p-bandai.jp/"), raw.startsWith("//")?"https:"+raw:raw);
                    if("https".equalsIgnoreCase(abs.getProtocol()) && abs.getUserInfo()==null)
                        img=abs.toString();
                }catch(Exception ignored) { }
            }
            Set<String> icons=new HashSet<>();
            Matcher im=ICON.matcher(card);
            while(im.find()) icons.add(im.group(1).toUpperCase(Locale.ROOT));
            boolean reserve=icons.contains("ITEM_RESERVE");
            boolean ended=icons.contains("ITEM_RESERVE_END")||icons.contains("ITEM_SALE_END")
                    ||icons.contains("ITEM_OUT_OF_STOCK");
            String status=reserve&&ended?"UNKNOWN":ended?"UNAVAILABLE":reserve?"AVAILABLE":"UNKNOWN";
            String reason=reserve&&ended?"contradicting-state-icons":ended?"official-ended-icon"
                    :reserve?"official-reserve-icon":"no-decisive-state-icon";
            Result result=new Result(id,title,yen,img,status,reason);
            // Multiple cards for the SAME ID must agree. Otherwise none is safe.
            if(found!=null && (!found.title.equals(result.title)
                    || (found.price!=null && result.price!=null && !found.price.equals(result.price))
                    || !found.status.equals(result.status)))return null;
            found=result;
        }
        return found;
    }

    /** A miss does NOT mean the item is sold out. Limits both network and time. */
    public static Result lookup(URL savedItem, String userAgent) {
        if(!supports(savedItem))return null;
        long deadline=System.nanoTime()+16_000_000_000L;
        int requests=0;
        for(String shop:SHOPS) {
            int limit=shop.startsWith("gundambase/")?1:2;
            for(int page=0;page<limit && requests<MAX_PAGES;page++) {
                if(System.nanoTime()>=deadline)return null;
                requests++;
                String path="/"+shop+"/list-da20-n"+page+"/";
                String html=fetch(path,userAgent);
                if(html!=null) {
                    Result result=parseListing(savedItem,html);
                    if(result!=null)return result;
                }
                if(requests<MAX_PAGES)try{Thread.sleep(250);}catch(InterruptedException ex){
                    Thread.currentThread().interrupt();return null;
                }
            }
        }
        return null;
    }

    private static String fetch(String path, String userAgent) {
        HttpURLConnection c=null;
        try {
            // A constant same-host allowlist of public shop listings. Never visit
            // private /search, /mypage, product checkout or a redirected host.
            c=(HttpURLConnection)new URL("https://p-bandai.jp"+path).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(1800);
            c.setReadTimeout(2300);
            c.setRequestProperty("User-Agent", userAgent==null || userAgent.isBlank()
                    ? "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                    : userAgent);
            c.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9");
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8");
            if(c.getResponseCode()!=200)return null;
            String contentType=c.getContentType();
            if(contentType!=null && !contentType.toLowerCase(Locale.ROOT).contains("html"))return null;
            ByteArrayOutputStream b=new ByteArrayOutputStream();
            try(InputStream s=c.getInputStream()){
                byte[] block=new byte[8192];int read;
                while((read=s.read(block))>=0){
                    if(read==0)continue;
                    if(b.size()+read>MAX_RESPONSE_BYTES)return null;
                    b.write(block,0,read);
                }
            }
            // Public shop listings were observed as Shift_JIS (Windows-31J).
            return new String(b.toByteArray(),Charset.forName("windows-31j"));
        }catch(Exception ignored){return null;}
        finally{if(c!=null)c.disconnect();}
    }

    private static String decode(String markup) {
        return decodeEntities(TAG.matcher(markup).replaceAll(" ")).replaceAll("\\s+"," ").trim();
    }
    private static String decodeEntities(String text) {
        String s=text.replace("&nbsp;"," ").replace("&amp;","&")
                .replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"")
                .replace("&#39;","'").replace("&#039;","'");
        Matcher m=Pattern.compile("&#(x[0-9a-fA-F]+|[0-9]+);").matcher(s);
        StringBuffer out=new StringBuffer();
        while(m.find()) {
            try {
                String x=m.group(1);
                int cp=x.charAt(0)=='x'?Integer.parseInt(x.substring(1),16):Integer.parseInt(x);
                m.appendReplacement(out,Matcher.quoteReplacement(Character.isValidCodePoint(cp)?new String(Character.toChars(cp)):""));
            }catch(Exception e){m.appendReplacement(out,Matcher.quoteReplacement(m.group(0)));}
        }
        m.appendTail(out);
        return out.toString();
    }
}
