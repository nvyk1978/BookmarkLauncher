package com.cmyk.bookmarkslauncher.wishlist;

import android.text.Html;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;

/**
 * Isolated adapter for Honma Store's packaging shop (NOT honma-store.com).
 * Item identity is the /shop/products/view/<internal-id> route. The printed
 * 商品コード is a different number and must NOT be compared to the route id.
 * All gross-price and stock evidence must come from the one-item detail, never
 * a /shop/products/index/category listing, shipping table or recommendations.
 */
public final class WishlistHonmaProductDom {
    private static final Pattern ITEM = Pattern.compile("(?i)^/shop/products/view/([1-9][0-9]{0,9})(?:/category(?::|%3a)[0-9]{1,7})?/?$");
    private static final Pattern SCRIPTS = Pattern.compile("(?is)<(?:script|style|noscript)\\b[^>]*>.*?</(?:script|style|noscript)\\s*>");
    private static final Pattern HEADING = Pattern.compile("(?is)<h([1-3])\\b[^>]*>(.*?)</h\\1\\s*>");
    private static final Pattern IMG = Pattern.compile("(?is)<img\\b[^>]*>");
    private static final Pattern ATTR = Pattern.compile("(?i)([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))");
    // Honma prints table labels and values in separate cells. Android's rendered
    // text can insert spaces, pipes or newlines between them.
    private static final Pattern GROSS = Pattern.compile("税込\\s*価格[^0-9]{0,65}([1-9][0-9,]{0,9})\\s*円");
    private static final Pattern NET = Pattern.compile("販売\\s*価格[^0-9]{0,65}[1-9][0-9,]{0,9}\\s*円");
    private static final Pattern CODE = Pattern.compile("商品\\s*コード[^0-9]{0,65}[0-9]{3,9}(?![0-9])");
    private static final Pattern CODE_MARKER = Pattern.compile("商品\\s*コード");
    private static final Pattern DETAIL_MARKER = Pattern.compile("商品\\s*詳細");
    private static final Pattern FALSE_IMAGE = Pattern.compile("(?i)logo|banner|icon|detail_icon|nav|side|header|footer|cart|payment|shipping|noimage|placeholder|spacer|recommend|related|calendar");
    private WishlistHonmaProductDom() { }

    public static String itemId(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())) return null;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        if (!host.equals("www.honma-store.net") && !host.equals("honma-store.net")) return null;
        Matcher match = ITEM.matcher(url.getPath());
        return match.matches() ? match.group(1) : null;
    }
    public static boolean isDetail(URL url) { return itemId(url) != null; }
    public static boolean sameItem(URL original, URL destination) {
        String a = itemId(original), b = itemId(destination);
        return a != null && a.equals(b);
    }
    /** Route identity + first bounded item price table, independent of table layout.
     * Never parse product indexes, recommendations or a shipping-price table. */
    private static String boundedDetail(String html, URL url) {
        if (!isDetail(url) || html == null || html.isBlank()) return null;
        String withoutScripts = SCRIPTS.matcher(html).replaceAll(" ");
        String text = Html.fromHtml(withoutScripts, Html.FROM_HTML_MODE_LEGACY).toString()
                .replace('\u00a0',' ').replace('\u3000',' ').replaceAll("[\\s\u200b]+", " ");
        Matcher marker = CODE_MARKER.matcher(text);
        while (marker.find()) {
            // The detail is the first local price table following a product code;
            // it must contain exactly one distinct tax-inclusive total.
            int limit=Math.min(text.length(), marker.start()+1300);
            Matcher detail=DETAIL_MARKER.matcher(text);
            if (detail.find(marker.end()) && detail.start()<limit) limit=detail.start();
            String block=text.substring(marker.start(),limit);
            if (!CODE.matcher(block).find() || !NET.matcher(block).find()) continue;
            Matcher gross=GROSS.matcher(block);
            String amount=null;
            while(gross.find()) {
                if (amount!=null && !amount.equals(gross.group(1))) return null; // ambiguous product totals; do not guess
                amount=gross.group(1);
            }
            if(amount!=null)return block;
        }
        return null;
    }
    public static Long grossPrice(String html, URL url) {
        String block = boundedDetail(html, url);
        if (block == null) return null;
        Matcher m = GROSS.matcher(block);
        if (!m.find()) return null;
        try {
            long price = Long.parseLong(m.group(1).replace(",",""));
            return price > 0 && price < 100_000_000L ? price : null;
        } catch (Exception e) { return null; }
    }
    public static String itemTitle(String html, URL url) {
        if (boundedDetail(html,url)==null) return null;
        Matcher heading=HEADING.matcher(SCRIPTS.matcher(html).replaceAll(" "));
        String result=null;
        while(heading.find()) {
            String text=Html.fromHtml(heading.group(2),Html.FROM_HTML_MODE_LEGACY)
                    .toString().replaceAll("[\\s\u3000]+", " ").trim();
            if (DETAIL_MARKER.matcher(text).find()) break;
            if(text.length()>=5 && text.length()<210 && !text.contains("商品ラインナップ")
                    && !text.contains("本間商店") && !text.contains("ご利用")
                    && !text.contains("ログイン") && !text.contains("ご注文")
                    && !text.contains("購入の前に") && !text.contains("人気カテゴリ")
                    && !text.contains("新着情報") && !text.matches("20[0-9]{2}年[0-9]{1,2}月")) result=text;
        }
        return result;
    }
    /** Static HTML hint only. Failing to recognize an image is preferable to an icon. */
    static List<String> imageCandidates(String html, URL url) {
        List<String> out=new ArrayList<>();
        if (boundedDetail(html,url)==null) return out;
        Matcher headings=HEADING.matcher(html);
        int codeAt=html.indexOf("商品コード");
        int start=-1;
        while(headings.find() && headings.start()<codeAt) start=headings.end();
        if(start<0 || codeAt<start || codeAt-start>20000) return out;
        Matcher images=IMG.matcher(html.substring(start,codeAt));
        LinkedHashSet<String> candidates=new LinkedHashSet<>();
        while(images.find() && candidates.size()<6) {
            String tag=images.group();
            String alt=attr(tag,"alt"), css=attr(tag,"class"), id=attr(tag,"id");
            if(FALSE_IMAGE.matcher((alt==null?"":alt)+" "+(css==null?"":css)+" "+(id==null?"":id)).find())continue;
            for(String key:new String[]{"data-original","data-large-image","data-src","src"}) {
                String s=attr(tag,key);
                if(s==null || FALSE_IMAGE.matcher(s).find())continue;
                try {
                    URL image=new URL(url,s.replace("&amp;","&"));
                    if("https".equalsIgnoreCase(image.getProtocol())
                            && WishlistCrawler.isAllowedUrl(image)
                            && image.getPath().matches("(?i).*\\.(?:jpe?g|png|webp)(?:$|/.*)")) {
                        candidates.add(image.toString()); break;
                    }
                }catch(Exception ignored) { }
            }
        }
        out.addAll(candidates);
        return out;
    }
    private static String attr(String tag,String key) {
        Matcher m=ATTR.matcher(tag);
        while(m.find())if(key.equalsIgnoreCase(m.group(1)))
            return m.group(2)!=null?m.group(2):m.group(3)!=null?m.group(3):m.group(4);
        return null;
    }
    /** DOM read is bound to the URL's exact internal item id; never clicks. */
    public static String priceJavascript(URL url) {
        return SCRIPT_HEAD.replace("__ITEM__",JSONObject.quote(itemId(url)==null?"":itemId(url))) + """
 const block=productBlock();
 if(!block)return JSON.stringify({value:'',currency:'',reason:'item-table-unverified'});
 return JSON.stringify({value:block.gross,currency:'JPY',reason:'honma-gross'});
 }catch(_){return JSON.stringify({value:'',currency:'',reason:'script-error'});}
 })()
 """;
    }
    public static String stockJavascript(URL url) {
        return SCRIPT_HEAD.replace("__ITEM__",JSONObject.quote(itemId(url)==null?"":itemId(url))) + """
 const block=productBlock();
 const r={status:'UNKNOWN',reason:'item-table-unverified',sameItem:!!block,positive:0,negative:0,cart:0,qty:0};
 const text=String(document.body?.innerText||document.body?.textContent||'');
 r.bodyChars=text.length;
 r.codeHint=/商品\\s*コード/.test(text);
 r.grossHint=/税込\\s*価格/.test(text);
 r.netHint=/販売\\s*価格/.test(text);
 r.detailHint=/商品\\s*詳細/.test(text);
 if(!block)return JSON.stringify(r);
 const negative=/(?:在庫\\s*[:：]?\\s*(?:なし|無し|切れ|0)|売り切れ|売切れ|完売|販売終了|取扱終了|品切れ)/i;
 r.negative=negative.test(block.text)?1:0;
 if(r.negative){r.reason='negative-item-text';return JSON.stringify(r);}
 // Purchase inputs are named 'purchase' on Honma, not necessarily 'cart',
 // and the visible count box need not have a qty/quantity name.
 const headings=[...document.querySelectorAll('h1,h2,h3')];
 const detailHeading=headings.find(e=>/商品\\s*詳細/.test((e.innerText||e.textContent||'').trim()));
 const titleHeading=headings.filter(e=>{
   const t=(e.innerText||e.textContent||'').trim();
   return t.length>=5&&t.length<210&&!/商品ラインナップ|ご利用について|商品詳細|お知らせ|購入の前に|20[0-9]{2}年|人気カテゴリ/.test(t);
 }).filter(e=>!detailHeading||(e.compareDocumentPosition(detailHeading)&Node.DOCUMENT_POSITION_FOLLOWING)).pop();
 function inItem(node){
   if(!node||node.closest('header,nav,footer,aside'))return false;
   if(titleHeading&&!(titleHeading.compareDocumentPosition(node)&Node.DOCUMENT_POSITION_FOLLOWING))return false;
   if(detailHeading&&!(node.compareDocumentPosition(detailHeading)&Node.DOCUMENT_POSITION_FOLLOWING))return false;
   return true;
 }
 const controls=[...document.querySelectorAll('input[type=submit],input[type=image],input[type=button],button')];
 for(const btn of controls){
   if(!inItem(btn)||btn.disabled||btn.hasAttribute('disabled')||btn.getAttribute('aria-disabled')==='true')continue;
   const style=getComputedStyle(btn);
   if(style.display==='none'||style.visibility==='hidden')continue;
   const label=[btn.name,btn.id,btn.value,btn.alt,btn.textContent,btn.getAttribute('onclick'),btn.getAttribute('src')].join(' ');
   if(!/(?:purchase|cart|basket|カートに入れる|カゴに入れる|かごに入れる)/i.test(label))continue;
   // An item-level form or purchase control in the detail buy-box is strong
   // evidence, but site-wide cart LINKS are never accepted.
   const form=btn.closest('form');
   if(form && form.closest('header,nav,footer,aside'))continue;
   const local=form||btn.parentElement;
   const inputs=local?[...local.querySelectorAll('input,select')]:[];
   const quantity=inputs.some(e=>e!==btn&&!e.disabled
     && (/qty|quantity|数量|個数|amount|count/i.test((e.name||'')+' '+(e.id||''))
          || (e.tagName==='INPUT'&&['text','number','tel'].includes((e.type||'').toLowerCase())
              &&/^[0-9]{1,4}$/.test(e.value||''))));
   if(quantity)r.qty++;
   r.cart++;
   if(quantity||/purchase/i.test(label)||/カートに入れる|カゴに入れる|かごに入れる/.test(label))r.positive++;
 }
 if(r.positive>0){r.status='AVAILABLE';r.reason='item-purchase-control';}
 else r.reason='no-item-purchase-control';
 return JSON.stringify(r);
 }catch(_){return JSON.stringify({status:'UNKNOWN',reason:'script-error',sameItem:false,positive:0,negative:0,cart:0,qty:0});}
 })()
 """;
    }
    public static String imageJavascript(URL url) {
        return SCRIPT_HEAD.replace("__ITEM__",JSONObject.quote(itemId(url)==null?"":itemId(url))) + """
 if(!productBlock())return '[]';
 const heads=[...document.querySelectorAll('h1,h2,h3')];
 const detailHead=heads.find(e=>/商品\\s*詳細/.test(e.innerText||e.textContent||''));
 const title=heads.filter(e=>{const t=(e.innerText||e.textContent||'').trim();
   return t.length>=5&&t.length<210&&!/商品ラインナップ|ご利用について|商品詳細|お知らせ|購入の前に|20[0-9]{2}年|人気カテゴリ/.test(t);
 }).filter(e=>!detailHead||(e.compareDocumentPosition(detailHead)&Node.DOCUMENT_POSITION_FOLLOWING)).pop();
 function local(e){
   if(!e||e.closest('header,nav,footer,aside'))return false;
   if(title&&!(title.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_FOLLOWING))return false;
   if(detailHead&&!(e.compareDocumentPosition(detailHead)&Node.DOCUMENT_POSITION_FOLLOWING))return false;
   return true;
 }
 const found=[];
 function add(raw){
   if(!raw)return;
   const parts=String(raw).match(/url\\(['"]?([^)'"]+)['"]?\\)/i);
   if(parts)raw=parts[1];
   try{const u=new URL(String(raw).replace(/&amp;/g,'&'),location.href);
     if(u.protocol!=='https:'||!/\\.(?:jpe?g|png|webp|avif)(?:$)/i.test(u.pathname))return;
     if(/logo|banner|icon|detail_icon|nav|side|header|footer|cart|payment|shipping|noimage|placeholder|spacer|recommend|related|calendar/i.test(u.pathname))return;
     if(!found.includes(u.href))found.push(u.href);
   }catch(_){}
 }
 const elements=[...document.querySelectorAll('img,source,a[href],[style],[data-src],[data-original],[data-image]')];
 for(const e of elements){
   if(!local(e))continue;
   const label=(e.id||'')+' '+(e.className||'')+' '+(e.alt||'');
   if(/logo|banner|icon|detail_icon|nav|side|header|footer|cart|payment|shipping|noimage|placeholder|spacer|recommend|related|calendar/i.test(label))continue;
   if(e.tagName==='IMG') {
     if(e.naturalWidth>0&&e.naturalWidth<100)continue;
     if(e.naturalHeight>0&&e.naturalHeight<100)continue;
   }
   for(const key of ['data-original','data-large-image','data-src','data-image','href','src','poster'])add(e.getAttribute(key));
   if(e.tagName==='IMG')add(e.currentSrc);
   const sty=e.getAttribute('style')||'';
   const url=sty.match(/url\\(\\s*['"]?([^)'"]+)['"]?\\s*\\)/i);
   if(url)add(url[1]);
   if(found.length>=5)break;
 }
 return JSON.stringify(found.slice(0,4));
 }catch(_){return '[]';}
 })()
 """;
    }
    private static final String SCRIPT_HEAD = """
 (function(){'use strict';try{
 const requested=__ITEM__;
 const match=location.pathname.match(/^\\/shop\\/products\\/view\\/([1-9][0-9]{0,9})(?:\\/category(?::|%3a)[0-9]+)?\\/?$/i);
 if(!/^(?:www\\.)?honma-store\\.net$/i.test(location.hostname)||location.protocol!=='https:'||
    !match||match[1]!==requested)return JSON.stringify({status:'UNKNOWN',reason:'wrong-document'});
 function productBlock(){
   // The product code and prices are separate table cells. Never require
   // them to be direct heading children or separated by whitespace alone.
   const text=String(document.body?.innerText||document.body?.textContent||'')
     .replace(/[\\u00a0\\u200b\\u3000]/g,' ').replace(/\\s+/g,' ');
   const markers=[...text.matchAll(/商品\\s*コード/g)];
   for(const marker of markers){
     const following=text.slice(marker.index,marker.index+1300);
     const boundary=following.search(/商品\\s*詳細/);
     const local=(boundary>=0?following.slice(0,boundary):following);
     if(!/商品\\s*コード[^0-9]{0,65}[0-9]{3,9}(?![0-9])/.test(local))continue;
     if(!/販売\\s*価格[^0-9]{0,65}[1-9][0-9,]{0,9}\\s*円/.test(local))continue;
     const totals=[...local.matchAll(/税込\\s*価格[^0-9]{0,65}([1-9][0-9,]{0,9})\\s*円/g)]
       .map(m=>m[1].replace(/,/g,''));
     if(!totals.length||totals.some(n=>n!==totals[0]))continue;
     const n=Number(totals[0]);
     if(!Number.isSafeInteger(n)||n<=0||n>=100000000)continue;
     return {text:local,gross:String(n)};
   }
   return null;
 }
 """;
}
