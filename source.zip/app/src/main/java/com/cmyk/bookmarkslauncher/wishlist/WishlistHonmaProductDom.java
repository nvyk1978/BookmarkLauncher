package com.cmyk.bookmarkslauncher.wishlist;

import android.text.Html;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;

/**
 * Isolated adapter for Honma Store's packaging shop (NOT honma-store.com).
 * Item identity is the /shop/products/view/<internal-id> route. The printed
 * 商品コード is a different number and must NOT be compared to the route id.
 * All gross-price and stock evidence must come from the one-item detail, never
 * a /shop/products/index/category listing, shipping table or recommendations.
 */
public final class WishlistHonmaProductDom {
    private static final Pattern ITEM = Pattern.compile("(?i)^/shop/products/view/([1-9][0-9]{0,9})(?:/category(?::|%3a)[0-9]{1,7})?/?$");
    private static final Pattern SCRIPTS = Pattern.compile("(?is)<(?:script|style|noscript)\\b[^>]*>.*?</(?:script|style|noscript)\\s*>");
    private static final Pattern HEADING = Pattern.compile("(?is)<h([1-3])\\b[^>]*>(.*?)</h\\1\\s*>");
    private static final Pattern IMG = Pattern.compile("(?is)<img\\b[^>]*>");
    private static final Pattern ATTR = Pattern.compile("(?i)([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))");
    private static final Pattern GROSS = Pattern.compile("税込価格\\s*[:：]?\\s*[¥￥]?\\s*([1-9][0-9,]{0,9})\\s*円");
    private static final Pattern NET = Pattern.compile("販売価格\\s*[:：]?\\s*[¥￥]?\\s*[0-9][0-9,]*\\s*円");
    private static final Pattern CODE = Pattern.compile("商品コード\\s*[:：]?\\s*[0-9]{3,9}");
    private static final Pattern FALSE_IMAGE = Pattern.compile("(?i)logo|banner|icon|detail_icon|nav|side|header|footer|cart|payment|shipping|noimage|placeholder|spacer|recommend|related|calendar");
    private WishlistHonmaProductDom() { }

    public static String itemId(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())) return null;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        if (!host.equals("www.honma-store.net") && !host.equals("honma-store.net")) return null;
        Matcher match = ITEM.matcher(url.getPath());
        return match.matches() ? match.group(1) : null;
    }
    public static boolean isDetail(URL url) { return itemId(url) != null; }
    public static boolean sameItem(URL original, URL destination) {
        String a = itemId(original), b = itemId(destination);
        return a != null && a.equals(b);
    }
    /** Only accept an explicitly labeled item section and a SINGLE gross total. */
    private static String boundedDetail(String html, URL url) {
        if (!isDetail(url) || html == null || html.isBlank()) return null;
        String withoutScripts = SCRIPTS.matcher(html).replaceAll(" ");
        String text = Html.fromHtml(withoutScripts, Html.FROM_HTML_MODE_LEGACY).toString()
                .replace('\u00a0',' ').replaceAll("[\\s　]+", " ");
        int code = text.indexOf("商品コード");
        if (code < 0) return null;
        // Within the first product's price block; a category/list does not pass
        // isDetail(), and unrelated footer prices cannot be accepted here.
        int end = text.indexOf("商品詳細", code);
        if (end < 0 || end - code > 1900 || end - code < 25) return null;
        String block = text.substring(code, end);
        if (!CODE.matcher(block).find() || !NET.matcher(block).find()) return null;
        Matcher gross = GROSS.matcher(block);
        if (!gross.find()) return null;
        if (gross.find()) return null; // ambiguous product totals; do not guess
        return block;
    }
    public static Long grossPrice(String html, URL url) {
        String block = boundedDetail(html, url);
        if (block == null) return null;
        Matcher m = GROSS.matcher(block);
        if (!m.find()) return null;
        try {
            long price = Long.parseLong(m.group(1).replace(",",""));
            return price > 0 && price < 100_000_000L ? price : null;
        } catch (Exception e) { return null; }
    }
    public static String itemTitle(String html, URL url) {
        if (boundedDetail(html, url) == null) return null;
        Matcher heading=HEADING.matcher(html);
        String result=null;
        // Product heading precedes 商品コード; menus have shorter or unrelated H2.
        int codeAt=html.indexOf("商品コード");
        while (heading.find() && heading.start() < codeAt) {
            String text=Html.fromHtml(heading.group(2),Html.FROM_HTML_MODE_LEGACY)
                    .toString().replaceAll("[\\s　]+", " ").trim();
            if (text.length()>=5 && text.length()<210
                    && !text.contains("商品ラインナップ") && !text.contains("本間商店")
                    && !text.contains("商品詳細") && !text.contains("ご利用")) result=text;
        }
        return result;
    }
    /** Static HTML hint only. Failing to recognize an image is preferable to an icon. */
    static List<String> imageCandidates(String html, URL url) {
        List<String> out=new ArrayList<>();
        if (boundedDetail(html,url)==null) return out;
        Matcher headings=HEADING.matcher(html);
        int codeAt=html.indexOf("商品コード");
        int start=-1;
        while(headings.find() && headings.start()<codeAt) start=headings.end();
        if(start<0 || codeAt<start || codeAt-start>20000) return out;
        Matcher images=IMG.matcher(html.substring(start,codeAt));
        LinkedHashSet<String> candidates=new LinkedHashSet<>();
        while(images.find() && candidates.size()<6) {
            String tag=images.group();
            String alt=attr(tag,"alt"), css=attr(tag,"class"), id=attr(tag,"id");
            if(FALSE_IMAGE.matcher((alt==null?"":alt)+" "+(css==null?"":css)+" "+(id==null?"":id)).find())continue;
            for(String key:new String[]{"data-original","data-large-image","data-src","src"}) {
                String s=attr(tag,key);
                if(s==null || FALSE_IMAGE.matcher(s).find())continue;
                try {
                    URL image=new URL(url,s.replace("&amp;","&"));
                    if("https".equalsIgnoreCase(image.getProtocol())
                            && WishlistCrawler.isAllowedUrl(image)
                            && image.getPath().matches("(?i).*\\.(?:jpe?g|png|webp)(?:$|/.*)")) {
                        candidates.add(image.toString()); break;
                    }
                }catch(Exception ignored) { }
            }
        }
        out.addAll(candidates);
        return out;
    }
    private static String attr(String tag,String key) {
        Matcher m=ATTR.matcher(tag);
        while(m.find())if(key.equalsIgnoreCase(m.group(1)))
            return m.group(2)!=null?m.group(2):m.group(3)!=null?m.group(3):m.group(4);
        return null;
    }
    /** DOM read is bound to the URL's exact internal item id; never clicks. */
    public static String priceJavascript(URL url) {
        return SCRIPT_HEAD.replace("__ITEM__",JSONObject.quote(itemId(url)==null?"":itemId(url))) + """
 const block=productBlock();
 if(!block)return JSON.stringify({value:'',currency:'',reason:'item-unverified'});
 const amounts=[...block.matchAll(/税込価格\\s*[:：]?\\s*[¥￥]?\\s*([1-9][0-9,]{0,9})\\s*円/g)];
 if(amounts.length!==1)return JSON.stringify({value:'',currency:'',reason:'gross-ambiguous'});
 return JSON.stringify({value:amounts[0][1].replace(/,/g,''),currency:'JPY',reason:'honma-gross'});
 }catch(_){return JSON.stringify({value:'',currency:'',reason:'script-error'});}
 })()
 """;
    }
    public static String stockJavascript(URL url) {
        return SCRIPT_HEAD.replace("__ITEM__",JSONObject.quote(itemId(url)==null?"":itemId(url))) + """
 const block=productBlock();
 const r={status:'UNKNOWN',reason:'pending',sameItem:!!block,positive:0,negative:0,cart:0,qty:0};
 if(!block){r.reason='item-unverified';return JSON.stringify(r);}
 const neg=/(?:在庫\\s*[:：]?\\s*(?:なし|無し|切れ|0)|売り切れ|売切れ|完売|販売終了|取扱終了|品切れ)/i;
 r.negative=neg.test(block)?1:0;
 if(r.negative){r.reason='negative-item-text';return JSON.stringify(r);}
 const area=document.querySelector('main,#main,#contents,#content,#container')||document.body;
 const productHeading=[...area.querySelectorAll('h1,h2,h3')].filter(e=>{
   const t=(e.innerText||e.textContent||'').trim();
   return t.length>=5&&t.length<210&&!/商品ラインナップ|商品詳細|ご利用について/.test(t);
 }).find(e=>{
   const section=(e.parentElement?.parentElement?.innerText||'');
   return /商品コード/.test(section)&&/税込価格/.test(section);
 });
 const detailHeading=[...area.querySelectorAll('h2,h3,h4')].find(e=>
   /商品詳細/.test((e.innerText||e.textContent||'').trim())&&
   (!productHeading||(productHeading.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_FOLLOWING)));
 const candidates=[...area.querySelectorAll('form')].filter(form=>{
   // The cart must be physically located in the saved item's buy box.
   // A header search form, footer cart and related-item card cannot prove stock.
   if(!productHeading||!(productHeading.compareDocumentPosition(form)&Node.DOCUMENT_POSITION_FOLLOWING))return false;
   if(detailHeading&&!(form.compareDocumentPosition(detailHeading)&Node.DOCUMENT_POSITION_FOLLOWING))return false;
   const str=(form.innerText||form.textContent||'').slice(0,1700);
   const fields=[...form.querySelectorAll('input,button,select')];
   const hints=(form.action||'')+' '+form.getAttribute('onsubmit')+' '+fields.map(e=>
     (e.name||'')+' '+(e.value||'')+' '+(e.alt||'')+' '+(e.src||'')+' '+e.getAttribute('onclick')).join(' ');
   return /(?:cart|basket|カート|かご|カゴ)/i.test(hints+' '+str);
 });
 for(const form of candidates) {
   const text=(form.innerText||form.textContent||'')+' '+form.getAttribute('action');
   const inputs=[...form.querySelectorAll('input,select')];
   const qty=inputs.some(e=>/qty|quantity|数量|個数|amount|count/i.test((e.name||'')+' '+(e.id||''))
        && !e.disabled && !e.hasAttribute('readonly'));
   const buttons=[...form.querySelectorAll('button,input[type=submit],input[type=image],input[type=button]')];
   const live=buttons.filter(e=>!e.disabled&&!e.hasAttribute('disabled')&&e.getAttribute('aria-disabled')!=='true'
     && getComputedStyle(e).display!=='none'&&getComputedStyle(e).visibility!=='hidden'
     && /(?:cart|basket|カート|カゴ|かご|買い物かご)/i.test((e.value||'')+' '+(e.alt||'')+' '+(e.src||'')+' '+(e.textContent||'')+' '+(e.getAttribute('onclick')||'')+' '+text.slice(0,100)));
   if(qty)r.qty++;r.cart+=live.length;
   if(qty&&live.length)r.positive++;
 }
 if(r.positive>0){r.status='AVAILABLE';r.reason='item-cart-qty';}
 else r.reason='no-verified-cart';
 return JSON.stringify(r);
 }catch(_){return JSON.stringify({status:'UNKNOWN',reason:'script-error',sameItem:false,positive:0,negative:0,cart:0,qty:0});}
 })()
 """;
    }
    public static String imageJavascript(URL url) {
        return SCRIPT_HEAD.replace("__ITEM__",JSONObject.quote(itemId(url)==null?"":itemId(url))) + """
 if(!productBlock())return '[]';
 const root=document.querySelector('main,#main,#contents,#content,#container')||document.body;
 const head=[...root.querySelectorAll('h1,h2,h3')].filter(e=>{
   const s=(e.innerText||e.textContent||'').trim();return s.length>=5&&s.length<210&&
     !/商品ラインナップ|ご利用について|商品詳細/.test(s);
 }).find(e=>{
   const after=(e.parentElement?.parentElement?.innerText||'').slice(0,2200);
   return /商品コード/.test(after)&&/税込価格/.test(after);
 })||[...root.querySelectorAll('h1,h2,h3')].filter(e=>{
   const s=(e.innerText||e.textContent||'').trim();return s.length>=5&&s.length<210;
 }).pop();
 if(!head)return '[]';
 const nodes=[...root.querySelectorAll('img')];
 const detailHead=[...root.querySelectorAll('h2,h3,h4')].find(e=>
   /商品詳細/.test((e.innerText||e.textContent||'').trim())&&
   (head.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_FOLLOWING));
 const first=nodes.filter(img=>(head.compareDocumentPosition(img)&Node.DOCUMENT_POSITION_FOLLOWING)
   &&(!detailHead||(img.compareDocumentPosition(detailHead)&Node.DOCUMENT_POSITION_FOLLOWING)));
 const list=[];
 for(const img of first.slice(0,25)) {
   if(img.closest('header,nav,footer,aside'))continue;
   const cls=(img.className||'')+' '+(img.id||'')+' '+(img.alt||'');
   if(/detail_icon|icon|logo|banner|cart|shipping|calendar|recommend|related|noimage|placeholder/i.test(cls))continue;
   const box=img.getBoundingClientRect();
   if((img.naturalWidth>0&&img.naturalWidth<160) || (img.naturalHeight>0&&img.naturalHeight<140))continue;
   if((img.naturalWidth===0||img.naturalHeight===0)&&box.width<160)continue;
   const source=img.currentSrc||img.getAttribute('data-original')||img.getAttribute('data-src')||img.getAttribute('src');
   try {const u=new URL(source,location.href);
     if(u.protocol==='https:'&&/\\.(?:jpe?g|png|webp)$/i.test(u.pathname)
       && !/detail_icon|icon|logo|banner|calendar|noimage|placeholder/i.test(u.pathname)) {
       if(!list.includes(u.href))list.push(u.href);
     }
   }catch(_){}
   if(list.length>=4)break;
 }
 return JSON.stringify(list);
 }catch(_){return '[]';}
 })()
 """;
    }
    private static final String SCRIPT_HEAD = """
 (function(){'use strict';try{
 const requested=__ITEM__;
 const match=location.pathname.match(/^\\/shop\\/products\\/view\\/([1-9][0-9]{0,9})(?:\\/category(?::|%3a)[0-9]+)?\\/?$/i);
 if(!/^(?:www\\.)?honma-store\\.net$/i.test(location.hostname)||location.protocol!=='https:'||
    !match||match[1]!==requested)return JSON.stringify({status:'UNKNOWN',reason:'wrong-document'});
 function productBlock(){
   const text=String(document.body?.innerText||'').replace(/\\u00a0|　/g,' ');
   const start=text.indexOf('商品コード');if(start<0)return null;
   const end=text.indexOf('商品詳細',start);
   if(end<0||end-start<25||end-start>1900)return null;
   const local=text.slice(start,end).replace(/\\s+/g,' ');
   if(!/商品コード\\s*[:：]?\\s*[0-9]{3,9}/.test(local)||
     !/販売価格\\s*[:：]?\\s*[0-9][0-9,]*\\s*円/.test(local)||
     !/税込価格\\s*[:：]?\\s*[0-9][0-9,]*\\s*円/.test(local))return null;
   return local;
 }
 """;
}
