package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Image-only candidates for an identified retail product detail URL.
 * Keeps the title, price, availability and their persistence pipelines untouched.
 * Low-confidence page-wide banners/recommendations are deliberately omitted.
 */
final class WishlistRetailImageCandidates {
    private static final Pattern TITLE_H1 = Pattern.compile("(?is)<h1\\b[^>]*>(.*?)</h1\\s*>");
    private static final Pattern STRIP_TAGS = Pattern.compile("(?is)<[^>]*>");
    private static final Pattern IMAGE = Pattern.compile("<img\\b[^>]*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern ATTR = Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern NUMBER = Pattern.compile("(?:item_detail_|/item-detail/|/product/|/detail/)([0-9]{3,})(?:[/.?]|$)", Pattern.CASE_INSENSITIVE);
    private static final Pattern REJECT = Pattern.compile("logo|banner|icon|payment|shipping|cart|recommend|related|social|header|footer|spacer|tracking|noimage|no-image|placeholder|thumbnail-placeholder", Pattern.CASE_INSENSITIVE);
    private static final Pattern PRODUCT_MARKERS = Pattern.compile("product[-_]?image|product[-_]?photo|product[-_]?gallery|product[-_]?detail|item[-_]?image|item[-_]?photo|item[-_]?detail|goods[-_]?image|main[-_]?image|main[-_]?photo|itemimg|detailimg|item[-_]?visual|slide[-_]?item|save_image|zoom|gallery|fancybox|lightbox|商品画像", Pattern.CASE_INSENSITIVE);

    private WishlistRetailImageCandidates() { }

    static List<String> fromHtml(String html, URL page) {
        if (html == null || page == null || html.isBlank()) return java.util.Collections.emptyList();
        Matcher num = NUMBER.matcher(page.getPath());
        String productNumber = num.find() ? num.group(1) : null;
        LinkedHashMap<String, Integer> candidates = new LinkedHashMap<>();
        String mainTitle = mainTitle(html);
        Matcher images = IMAGE.matcher(html);
        int examined = 0;
        while (images.find() && examined++ < 180) {
            String tag = images.group();
            Map<String, String> attrs = attributes(tag);
            String local = html.substring(Math.max(0, images.start() - 260), Math.min(html.length(), images.end() + 70));
            String alt = attrs.getOrDefault("alt", "");
            String cls = attrs.getOrDefault("class", "") + " " + attrs.getOrDefault("id", "");
            if (REJECT.matcher(alt + " " + cls).find()) continue;
            boolean wrapper = PRODUCT_MARKERS.matcher(local).find();
            // A matching alt/title is portable across storefront engines; do
            // not add unrelated gallery thumbnails based on CDN alone.
            int titleBonus = altConfidence(mainTitle, alt);
            boolean mainProduct = wrapper || titleBonus >= 100
                    || "image".equalsIgnoreCase(attrs.get("itemprop"));
            boolean ownedCdn = page.getPath().toLowerCase(Locale.ROOT).contains("item-detail/")
                    && local.toLowerCase(Locale.ROOT).contains("image.raku-uru.jp");
            boolean eccubeGallery = page.getHost().toLowerCase(Locale.ROOT).endsWith("torikan.net")
                    && page.getPath().matches("(?i).*/products/detail/[0-9]+/?")
                    && (PRODUCT_MARKERS.matcher(local).find()
                    || local.toLowerCase(Locale.ROOT).contains("/upload/save_image/"));
            String[] fields = {"data-zoom-image", "data-large-image", "data-original", "data-src", "data-lazy-src", "src"};
            for (String field : fields) {
                String link = absolute(page, attrs.get(field));
                rank(candidates, link, mainProduct || eccubeGallery, ownedCdn, productNumber, false, titleBonus);
            }
            for (String set : new String[]{attrs.get("data-srcset"), attrs.get("srcset")}) {
                if (set == null) continue;
                for (String part : set.split(",")) {
                    String[] pieces = part.trim().split("\\s+");
                    if (pieces.length > 0) rank(candidates, absolute(page, pieces[0]), mainProduct || eccubeGallery, ownedCdn, productNumber, false, titleBonus);
                }
            }
            // Product galleries often link a small <img> to its full-sized photo.
            int anchorAt = local.toLowerCase(Locale.ROOT).lastIndexOf("<a ");
            int closingTag = anchorAt < 0 ? -1 : local.toLowerCase(Locale.ROOT).indexOf("</a>", anchorAt);
            int imageAt = local.toLowerCase(Locale.ROOT).indexOf("<img");
            if (anchorAt >= 0 && (closingTag < 0 || closingTag > imageAt)) {
                int end = local.indexOf('>', anchorAt);
                if (end > anchorAt) {
                    String anchorUrl = absolute(page, attributes(local.substring(anchorAt, end + 1)).get("href"));
                    rank(candidates, anchorUrl, mainProduct || eccubeGallery, ownedCdn, productNumber, true, titleBonus);
                }
            }
        }
        List<Map.Entry<String, Integer>> sorted = new ArrayList<>(candidates.entrySet());
        sorted.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        List<String> urls = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : sorted) {
            if (entry.getValue() < 55) continue;
            urls.add(entry.getKey());
            if (urls.size() >= 6) break;
        }
        return urls;
    }

    private static void rank(Map<String, Integer> out, String link, boolean wrapper,
                             boolean ownedCdn, String productNumber, boolean fromAnchor, int titleBonus) {
        if (link == null) return;
        String lower = link.toLowerCase(Locale.ROOT);
        if (REJECT.matcher(lower).find() || lower.matches("(?s).*\\.svg(?:\\?.*)?$")) return;
        boolean imageFile = lower.matches("(?s).*\\.(?:jpg|jpeg|png|webp|avif)(?:[?#].*)?$");
        if (!imageFile && !lower.contains("/image/") && !lower.contains("/images/")) return;
        int score = imageFile ? 12 : 0;
        if (wrapper) score += 55;
        score += titleBonus;
        if (ownedCdn && lower.contains("image.raku-uru.jp/")) score += 75;
        if (productNumber != null && lower.contains(productNumber)) score += 110;
        if (fromAnchor) score += 12;
        out.put(link, Math.max(out.getOrDefault(link, 0), score));
    }

    private static String mainTitle(String html) {
        Matcher m = TITLE_H1.matcher(html);
        while (m.find()) {
            String clean = normalize(STRIP_TAGS.matcher(m.group(1)).replaceAll(" "));
            if (clean.length() >= 5 && clean.length() <= 120) return clean;
        }
        return "";
    }
    private static int altConfidence(String title, String alt) {
        String a = normalize(alt);
        if (title.isEmpty() || a.length() < 5) return 0;
        if (a.equals(title)) return 180;
        if ((title.contains(a) || a.contains(title)) && Math.min(title.length(), a.length()) >= 7)
            return 140;
        int shared = 0;
        while (shared < title.length() && shared < a.length()
                && title.charAt(shared) == a.charAt(shared)) shared++;
        return shared >= 7 ? 115 : 0;
    }
    private static String normalize(String value) {
        return value == null ? "" : value.replace("&nbsp;", " ")
                .replace("&amp;", "&").replaceAll("[\\s　\\p{Punct}（）・]+", "")
                .toLowerCase(Locale.ROOT);
    }

    private static Map<String, String> attributes(String tag) {
        Map<String, String> out = new HashMap<>();
        Matcher a = ATTR.matcher(tag);
        while (a.find()) {
            String value = a.group(2) == null ? (a.group(3) == null ? a.group(4) : a.group(3)) : a.group(2);
            if (value != null) out.putIfAbsent(a.group(1).toLowerCase(Locale.ROOT), value);
        }
        return out;
    }

    private static String absolute(URL page, String raw) {
        if (raw == null || raw.isBlank()) return null;
        try {
            String decoded = raw.trim().replace("&amp;", "&").replace("&#38;", "&");
            URL url = new URL(page, decoded);
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) return null;
            return url.toString();
        } catch (Exception ignored) { return null; }
    }
}
