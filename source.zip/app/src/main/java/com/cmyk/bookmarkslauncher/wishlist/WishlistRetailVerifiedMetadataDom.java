package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/**
 * Read-only, merchant-specific name and exact-tax-inclusive-price recovery from
 * the SAME identity-checked stock WebView.  Never harvests a search result,
 * related item's price, bare catalog list or an unverified redirect.
 * Joshin/MUJI/ASKUL and every previously proven price pipeline stay intact.
 */
public final class WishlistRetailVerifiedMetadataDom {
    private WishlistRetailVerifiedMetadataDom() { }

    public static boolean supports(URL url) {
        WishlistRetailDedicatedMode mode = WishlistRetailDedicatedMode.forUrl(url);
        return mode == WishlistRetailDedicatedMode.EDION
                || mode == WishlistRetailDedicatedMode.ISETAN;
    }

    public static String javascript(URL url) {
        if (!supports(url)) return "JSON.stringify({reason:'unsupported',title:'',price:null})";
        WishlistRetailDedicatedMode mode = WishlistRetailDedicatedMode.forUrl(url);
        return SCRIPT.replace("__MERCHANT__", JSONObject.quote(mode.name()))
                .replace("__HOST__", JSONObject.quote(url.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(url.getPath().replaceAll("/+$", "").toLowerCase(Locale.ROOT)))
                .replace("__CODE__", JSONObject.quote(mode == WishlistRetailDedicatedMode.EDION
                        ? WishlistRetailDedicatedMode.query(url, "p_cd") : ""));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const o={reason:'unverified',title:'',price:null}, done=()=>JSON.stringify(o);
 try {
   const merchant=__MERCHANT__, host=__HOST__, path=__PATH__, code=__CODE__;
   const clean=s=>String(s||'').replace(/\\/+$/,'').toLowerCase();
   const norm=s=>String(s||'').replace(/\\u00a0|　/g,' ').replace(/\\s+/g,' ').trim();
   if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host||
      clean(location.pathname)!==path){o.reason='redirect-or-document-mismatch';return done();}
   if(merchant==='EDION'&&new URLSearchParams(location.search).get('p_cd')!==code){
     o.reason='other-item-query';return done();}
   const canonical=document.querySelector('link[rel=canonical]');
   if(canonical&&canonical.href){
     let u;try{u=new URL(canonical.href,location.href);}catch(_){o.reason='invalid-canonical';return done();}
     if(u.hostname.toLowerCase()!==host||clean(u.pathname)!==path||
        (merchant==='EDION'&&u.searchParams.has('p_cd')&&u.searchParams.get('p_cd')!==code)){
       o.reason='other-item-canonical';return done();}
   }
   const scope=document.querySelector('main,[role=main],#main,#contents,#content,#itemDetail,#item_detail')||document.body;
   if(!scope){o.reason='body-pending';return done();}
   const exclude='header,footer,nav,aside,[class*=recommend],[class*=related],'+
     '[class*=ranking],[class*=pickup],[id*=recommend],[id*=related],'+
     '[class*=carousel],[class*=breadcrumb]';
   const visible=e=>{if(!e||e.closest(exclude))return false;
     for(let p=e;p;p=p.parentElement){if(p.hidden||p.getAttribute('aria-hidden')==='true'||
       p.hasAttribute('inert'))return false;
       const s=getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||Number(s.opacity)===0)return false;}
     return true;};
   // A genuine rendered detail heading, not the site's OGP, is mandatory.
   let nodes=[...scope.querySelectorAll('h1,[itemprop=name],#itemName,#item_name,.itemName,.product-name,.productName')]
     .filter(visible).slice(0,60);
   let names=[...new Set(nodes.map(e=>norm(e.innerText||e.textContent))
     .filter(s=>s.length>=4&&s.length<=240&&
       !/^(?:商品|商品詳細|商品情報|商品一覧|オンラインストア|カテゴリー|検索結果|エディオン|伊勢丹)$/.test(s)&&
       !/(?:403 Forbidden|503 Service|Access Denied|ページが見つかりません)/i.test(s)))];
   const headings=[...scope.querySelectorAll('h1')].filter(visible)
     .map(e=>norm(e.innerText||e.textContent)).filter(s=>names.includes(s));
   let title=[...new Set(headings)].length===1?[...new Set(headings)][0]:'';
   if(!title&&names.length===1)title=names[0];
   if(!title){o.reason='single-product-heading-missing';return done();}
   // The requested item needs its own purchase control (not a header cart).
   const controls=merchant==='EDION'
     ? [...scope.querySelectorAll('#into_cart,#skip_cart,a.btnOrange,button[type=submit]')]
     : [...scope.querySelectorAll('#purBtn,button[name*=purchase],button[name*=cart],button[type=submit]')];
   const purchases=controls.filter(e=>visible(e)&&!e.disabled&&
     e.getAttribute('aria-disabled')!=='true'&&
     (merchant==='EDION'? (e.id==='into_cart'||e.id==='skip_cart'||
       /カートに入れる|今すぐ購入/.test(norm(e.innerText||e.value)))
       : (e.id==='purBtn'||/カートに追加|カートに入れる/.test(norm(e.innerText||e.value)))));
   if(!purchases.length){o.reason='no-detail-purchase-control';return done();}
   const og=norm(document.querySelector('meta[property="og:title"]')?.getAttribute('content'));
   if(og&&og.length>3&&!og.includes(title)&&!title.includes(og)){
     // Different product title in metadata is a signal to refuse, not guess.
     o.reason='title-contradiction';return done();
   }
   o.title=title;o.reason='item-heading-verified';
   o.priceSource='none';o.priceCandidates=0;
   // EDION: the live detail has "WEB価格" followed by tax-exclusive then
   // tax-inclusive amounts. Coupon/related-product amounts are NOT competing
   // sale prices. Resolve the first uniquely labelled main item's gross price.
   // A WEB price without its own explicit 税込 amount is not sufficient.
   if(merchant==='EDION'){
     const bodyText=norm(scope.innerText||scope.textContent||'');
     const pos=bodyText.indexOf(title);
     if(pos>=0){
       const detail=bodyText.slice(pos+title.length,pos+title.length+5200);
       const web=/WEB\\s*価格|ＷＥＢ\\s*価格|エディオン\\s*価格/i.exec(detail);
       if(web && web.index < 3500){
         const section=detail.slice(web.index+web[0].length,
               web.index+web[0].length+210);
         // Find only amounts explicitly tagged 税込, before coupon or stock
         // sections. Do not use 31,364 tax-excl to guess 34,500 tax-in.
         const stop=/(?:クーポン|ポイント|還元|配送受取|在庫状況|出荷目安|店舗受取|カートに入れる|数量)/.exec(section);
         const priceText=stop?section.slice(0,stop.index):section;
         const prices=[];
         const gross=/(?:[￥¥]\\s*([0-9][0-9,]{1,8})|([0-9][0-9,]{1,8})\\s*円)\\s*[（(]?\\s*税込\\s*[)）]?/g;
         for(const m of priceText.matchAll(gross)){
           const n=Number((m[1]||m[2]).replace(/,/g,''));
           if(Number.isSafeInteger(n)&&n>=50&&n<=100000000)prices.push(n);
         }
         o.priceCandidates=prices.length;
         if(prices.length&&prices.every(n=>n===prices[0])){
           o.price=prices[0];o.priceSource='edion-web-gross';return done();
         }
         if(prices.length>1){o.reason='edion-main-price-conflict';return done();}
       }
     }
   }
   // General high-confidence metadata path remains unchanged for ISETAN and
   // for EDION pages with no trustworthy labelled WEB gross price.
   // No amount from shipping, points, reviews, recommended items or tax-exclusive price.
   let candidate=[];
   let primary=[];
   for(const e of scope.querySelectorAll('[itemprop=price],[data-product-price],'+
      '#itemPrice,#product-price,.itemPrice,.productPrice,.priceTaxIn,.price-tax-in')){
     if(!visible(e)||e.closest('s,del,strike,[class*=oldPrice],[class*=beforePrice],'+
       '[class*=originalPrice],[class*=listPrice],[class*=regularPrice],'+
       '[class*=taxExclude],[class*=tax-exclude]'))continue;
     let raw=norm(e.getAttribute('content')||e.getAttribute('data-product-price')||e.innerText||e.textContent);
     if(raw.length>130||/(?:送料|税別|税抜|ポイント|割引|値引|クーポン|～|〜|から)/.test(raw))continue;
     const matches=[...raw.matchAll(/(?:[￥¥]\\s*([0-9][0-9,]{1,8})|([0-9][0-9,]{1,8})\\s*円)/g)];
     if(matches.length!==1)continue;
     if(!/税込|tax.?incl/i.test(raw)&&!e.matches('[itemprop=price],[data-product-price],.priceTaxIn,.price-tax-in'))continue;
     const n=Number((matches[0][1]||matches[0][2]).replace(/,/g,''));
     if(Number.isSafeInteger(n)&&n>=50&&n<=100000000){
       candidate.push(n);
       if(e.matches('[itemprop=price],[data-product-price],#itemPrice,#product-price'))
         primary.push(n);
     }
   }
   if(primary.length&&primary.every(v=>v===primary[0])){
     o.price=primary[0];return done();
   }
   if(!candidate.length){
     const body=norm(scope.innerText||scope.textContent);
     const at=body.indexOf(title);
     if(at>=0){
       let text=body.slice(at+title.length,at+2600);
       const end=text.search(/(?:商品情報|カスタマーレビュー|関連商品|おすすめ商品|おすすめアイテム|商品の詳細)/);
       if(end>=0)text=text.slice(0,end);
       const re=/[￥¥]\\s*([0-9][0-9,]{1,8})\\s*[（(]?\\s*税込\\s*[)）]?|([0-9][0-9,]{1,8})\\s*円\\s*[（(]?\\s*税込\\s*[)）]?/g;
       for(const m of text.matchAll(re)){
         if(/(?:送料|配送料|ポイント|手数料|割引|値引)/.test(text.slice(Math.max(0,m.index-18),m.index)))continue;
         const n=Number((m[1]||m[2]).replace(/,/g,''));
         if(Number.isSafeInteger(n)&&n>=50&&n<=100000000)candidate.push(n);
       }
     }
   }
   // Same gross price may appear in more than one widget; disagreement is unsafe.
   if(candidate.length&&candidate.every(v=>v===candidate[0]))o.price=candidate[0];
   else if(candidate.length)o.reason='conflicting-gross-prices';
   return done();
 }catch(_){o.reason='metadata-dom-error';return done();}
})()
""";
}
