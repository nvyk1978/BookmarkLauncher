package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;

/** One product document and one WebView for the numbered read-only survey.
 *  000-007 preserve existing strategies. 008-039 run reusable patterns on
 *  foreign products, and additionally their exact original native site engine
 *  when eligible. Dynamic 040+ profiles are never simulated by a fake engine.
 *  A foreign site's saved product ID is never copied to this product. */
public final class WishlistNumberedSurveyDom {
    private WishlistNumberedSurveyDom() { }
    public static String javascript(URL url, List<String> catalog) {
        if (url == null || catalog == null || catalog.size()<WishlistNumberedTechniqueRegistry.builtinCount())
            return "JSON.stringify({results:[]})";
        StringBuilder js=new StringBuilder(180000);
        js.append("(function(){'use strict';const results=[];");
        // All old proven sources are executed independently, even after a success.
        // The first stage is the unchanged GENERAL evidence engine.
        for (int i=0;i<8;i++) {
            String engine=i==0?WishlistGeneralPurchaseDom.javascript()
                    :i==6?WishlistGeneralVariantStockDom.source(url)
                    :i==7?WishlistMercariItemStockDom.javascript(url)
                    :WishlistGeneralAlphabetDom.source(url,"BCDEF".charAt(i-1));
            js.append("try{const raw=(").append(engine).append(");let o=raw;")
              .append("if(typeof o==='string')try{o=JSON.parse(o)}catch(_){};")
              .append("if(typeof o==='string')o={status:o,reason:'legacy-general'};")
              .append("if(!o||typeof o!=='object')o={status:'UNKNOWN',reason:'non-object'};")
              .append("results.push({id:'").append(WishlistNumberedTechniqueRegistry.number(i))
              .append("',status:o.status||'UNKNOWN',reason:o.reason||'no-evidence',details:o});")
              .append("}catch(_){results.push({id:'").append(WishlistNumberedTechniqueRegistry.number(i))
              .append("',status:'UNKNOWN',reason:'js-error'});}");
        }
        // Same-JS-invocation specialist survey. Numbered modes 008..end all run.
        String scan=SPECIALIST.replace("__HOST__",JSONObject.quote(url.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__",JSONObject.quote(url.getPath().replaceAll("/+$","")))
                .replace("__CODE__",JSONObject.quote(WishlistGeneralProductIdentity.code(url)))
                .replace("__KNOWN__",WishlistCrawler.isSingleProductPage(url)?"true":"false")
                .replace("__BUILTINS__",String.valueOf(WishlistNumberedTechniqueRegistry.builtinCount()))
                .replace("__COUNT__",String.valueOf(catalog.size()));
        StringBuilder pending=new StringBuilder();
        for(int i=WishlistNumberedTechniqueRegistry.builtinCount();i<catalog.size();i++)
            if(catalog.get(i).startsWith("PENDING-")) {
                if(pending.length()>0)pending.append(',');
                pending.append('\'').append(WishlistNumberedTechniqueRegistry.number(i)).append('\'');
            }
        js.append("try{const survey=JSON.parse(").append(scan).append(");")
          .append("const inactive=new Set([").append(pending).append("]);")
          .append("if(survey&&Array.isArray(survey.results))for(const e of survey.results){")
          // Never execute an auto-registered profile with a fabricated
          // generic buybox. A real native engine must be available.
          .append("if(inactive.has(e.id)){e.status='UNKNOWN';e.reason='pending-three-field-proof';}")
          .append("if(Number(e.id)>=40){e.status='UNKNOWN';e.reason=inactive.has(e.id)?'pending-three-field-proof':'no-portable-executor';}")
          .append("e.engine='portable-pattern';results.push(e);}")
          .append("}catch(_){for(let i=8;i<").append(catalog.size()).append(";i++)")
          .append("results.push({id:String(i).padStart(3,'0'),status:'UNKNOWN',reason:'survey-error'});}");
        // The native, previously working specialist is never replaced with
        // an approximate 'shop name' heuristic on its own saved product.
        // Only read-only inspectors are dispatched, no navigation or clicks.
        for(int i=8;i<Math.min(catalog.size(), WishlistNumberedTechniqueRegistry.builtinCount());i++) {
            String source=WishlistNumberedNativeAdapters.javascript(url,i);
            if(source==null)continue;
            js.append("try{let nativeResult=(").append(source).append(");")
              .append("if(typeof nativeResult==='string')try{nativeResult=JSON.parse(nativeResult)}catch(_){nativeResult={status:nativeResult,reason:'native-text-result'};}")
              .append("if(typeof nativeResult!=='object'||!nativeResult)nativeResult={status:'UNKNOWN',reason:'native-unreadable'};")
              .append("const index=results.findIndex(e=>e.id==='").append(WishlistNumberedTechniqueRegistry.number(i)).append("');")
              .append("if(index>=0)results[index]={id:'").append(WishlistNumberedTechniqueRegistry.number(i))
              .append("',status:nativeResult.status||'UNKNOWN',reason:nativeResult.reason||'native-no-evidence',")
              .append("engine:'native-source',details:nativeResult};")
              .append("}catch(_){/* portable result remains UNKNOWN/safely guarded */}");
        }
        js.append("return JSON.stringify({results});})()");
        return js.toString();
    }
    private static final String SPECIALIST = """
(function(){'use strict';
 const results=[];const add=(id,predicate)=>results.push({id,status:predicate?'AVAILABLE':'UNKNOWN',reason:predicate?'matched-product-stock':'missing-bound-evidence'});
 try{
 const expectedHost=__HOST__,expectedPath=__PATH__,code=__CODE__,known=__KNOWN__;
 const path=(location.pathname||'').replace(/\\/+$/,'');
 if(location.protocol!=='https:'||location.hostname.toLowerCase()!==expectedHost||path.toLowerCase()!==expectedPath.toLowerCase()){
   for(let i=8;i<__COUNT__;i++)results.push({id:String(i).padStart(3,'0'),status:'UNKNOWN',reason:'document-mismatch'});
   return JSON.stringify({results,documentBound:false});
 }
 const body=document.querySelector('main,[role=main],#main,#contents,#product-detail')||document.body;
 if(!body){for(let i=8;i<__COUNT__;i++)results.push({id:String(i).padStart(3,'0'),status:'UNKNOWN',reason:'body-pending'});return JSON.stringify({results,documentBound:true});}
 const text=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\s+/g,' ').trim();
 const bad='header,nav,footer,aside,[class*=related],[class*=recommend],[class*=ranking]';
 const live=e=>{if(!e||e.disabled||e.hasAttribute('disabled')||e.getAttribute('aria-disabled')==='true')return false;
   for(let p=e;p;p=p.parentElement){if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return false;
     const s=getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0)return false;}return true;};
 const heads=[...body.querySelectorAll('h1')].filter(e=>!e.closest(bad)&&live(e)&&text(e).length>=3&&text(e).length<320);
 const root=heads.length===1?(heads[0].closest('form,[itemtype*=Product],.product-detail,.product_detail,#productDetail,.item-detail')||body):null;
 const focused=root?text(root).slice(0,16000):'';
 const negative=/(?:売り切れ|売切れ|完売|販売終了|在庫切れ|out\\s*of\\s*stock|sold\\s*out)/i.test(focused);
 const positive=/(?:在庫\\s*[:：]?\\s*(?:あり|有り|有|残りわずか|僅少)|in\\s*stock|在庫残少)/i.test(focused);
 const claimRe=/(?:商品番号|商品コード|品番|お申込番号|注文コード|SKU|JAN|商品ID)\\s*[:：#]?\\s*([a-z0-9_-]{5,30})/gi;
 const claims=[...focused.matchAll(claimRe)].slice(0,18).map(m=>m[1]);
 const sku=!!code&&claims.some(x=>x.toLowerCase()===code.toLowerCase());
 const contradictory=!!code&&claims.length>0&&!sku;
 let boundOffer=false,offerPositive=false,offerNegative=false,heroPrice=false;
 const products=[];
 const gather=(v,n)=>{if(n>4||!v||typeof v!=='object')return;
   if(Array.isArray(v)){for(const x of v.slice(0,8))gather(x,n+1);return;}
   if(/(?:^|\\W)Product(?:$|\\W)/i.test(String(v['@type']||'')))products.push(v);
   if(v['@graph'])gather(v['@graph'],n+1);
   if(v.mainEntity)gather(v.mainEntity,n+1);};
 for(const s of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,12))try{gather(JSON.parse(s.textContent||'null'),0);}catch(_){}
 const bound=products.filter(p=>{
   const urls=[p.url,p['@id'],p.mainEntityOfPage].filter(x=>typeof x==='string');
   let matching=false;for(const raw of urls)try{
     const u=new URL(raw,location.href);
     if(u.hostname===expectedHost&&u.pathname.replace(/\\/+$/,'').toLowerCase()===expectedPath.toLowerCase())matching=true;
   }catch(_){}
   const ids=[p.sku,p.productID,p.productId,p.gtin13].filter(Boolean).map(String);
   if(ids.length&&code&&!ids.some(x=>x.toLowerCase()===code.toLowerCase()))return false;
   return matching||(sku&&ids.some(x=>x.toLowerCase()===code.toLowerCase()));
 });
 if(bound.length===1){boundOffer=true;const p=bound[0];let offers=Array.isArray(p.offers)?p.offers:[p.offers];
   offers=offers.filter(Boolean);offerPositive=offers.length>0&&offers.every(o=>/^(?:https?:\\/\\/schema.org\\/)?(?:InStock|LimitedAvailability)$/i.test(String(o.availability||'')));
   offerNegative=offers.length>0&&offers.every(o=>/^(?:https?:\\/\\/schema.org\\/)?(?:OutOfStock|SoldOut)$/i.test(String(o.availability||'')));
   heroPrice=offers.some(o=>Number(String(o.price||'').replace(/,/g,''))>0);
 }
 const codeGuard=sku||boundOffer;
 const identity=!!root&&codeGuard&&!contradictory;
 const allControls=root?[...root.querySelectorAll('button,input[type=submit],input[type=image],a[href],[role=button]')].slice(0,350):[];
 const actions=allControls.filter(e=>!e.closest(bad)&&live(e)&&/(?:カート|カゴ|かご|バッグ|バスケット)\\s*(?:に|へ)?\\s*(?:入れる|追加)|add\\s*to\\s*(?:cart|bag)|今すぐ購入|注文する|buy\\s*now/i.test(text(e)+' '+(e.getAttribute('aria-label')||'')));
 const cart=actions.length===1;
 const qty=root&&[...root.querySelectorAll('input[type=number],input[name*=qty],input[name*=quantity],select[name*=quantity]')].some(live);
 const selected=root&&[...root.querySelectorAll('select[required],[aria-required=true]')].filter(live).every(e=>e.tagName!=='SELECT'||!!e.value);
 const selectedColor=root&&[...root.querySelectorAll('[data-color-selected="true"],[aria-label*=color][aria-checked="true"],select[name*=color] option:checked')].some(live);
 const selectedSize=root&&[...root.querySelectorAll('[data-size-selected="true"],[aria-label*=size][aria-checked="true"],select[name*=size] option:checked')].some(live);
 const variant=selectedColor&&selectedSize;
 const grossPrice=/(?:税込|販売価格|商品価格)\\s*[:：]?\\s*[￥¥]?[0-9,]{2,12}\\s*円?/.test(focused);
 if(!identity||negative||(!positive&&!offerPositive&&!offerNegative)){
   for(let i=8;i<__COUNT__;i++)results.push({id:String(i).padStart(3,'0'),status:'UNKNOWN',reason:!identity?'item-unverified':negative?'stock-conflict':'no-positive-stock'});
   return JSON.stringify({results,documentBound:true,identity,negative});
 }
 // All technique families execute without an originating-merchant hostname gate.
 // The source merchant remains metadata, never a proof of the current item.
  // 008 HIRAKI
  add('008',sku && qty && selected && positive && cart);
  // 009 FUMUROYA
  add('009',qty && positive && cart && !negative);
  // 010 JR-CENTRAL
  add('010',qty && selected && positive && cart);
  // 011 HONMA
  add('011',grossPrice && qty && positive && cart);
  // 012 ASKUL
  add('012',sku && qty && positive && cart);
  // 013 MONOTARO
  add('013',sku && cart && (positive || offerPositive));
  // 014 YUIKAN
  add('014',sku && cart && positive);
  // 015 NAKASHIMA
  add('015',sku && qty && positive && cart);
  // 016 TORIKAN
  add('016',sku && qty && positive && cart);
  // 017 GREENBEANS
  add('017',(sku || boundOffer) && (positive || offerPositive) && cart);
  // 018 LOHACO
  add('018',(sku || boundOffer) && (positive || offerPositive) && cart);
  // 019 GU
  add('019',selectedColor && selectedSize && cart && (positive || offerPositive));
  // 020 EDION
  add('020',(sku || boundOffer) && (positive || offerPositive) && cart);
  // 021 AU
  add('021',(sku || boundOffer) && (positive || offerPositive) && cart);
  // 022 ISETAN
  add('022',(sku || boundOffer) && (positive || offerPositive) && cart);
  // 023 AMAZON
  add('023',boundOffer && offerPositive && cart);
  // 024 RAKUTEN
  add('024',boundOffer && offerPositive && cart);
  // 025 YAHOO
  add('025',(sku || boundOffer) && (positive || offerPositive) && cart);
  // 026 SHEIN
  add('026',boundOffer && offerPositive && cart);
  // 027 TEMU
  add('027',boundOffer && offerPositive && cart);
  // 028 ALIEXPRESS
  add('028',boundOffer && offerPositive && cart);
  // 029 JOSHIN
  add('029',sku && qty && (positive || offerPositive) && cart);
  // 030 NITORI
  add('030',selected && positive && cart);
  // 031 CAINZ
  add('031',selected && positive && cart);
  // 032 UNIQLO
  add('032',selectedColor && selectedSize && (positive || offerPositive) && cart);
  // 033 YODOBASHI
  add('033',(sku || boundOffer) && (positive || offerPositive) && cart);
  // 034 BICCAMERA
  add('034',(sku || boundOffer) && (positive || offerPositive) && cart);
  // 035 MUJI
  add('035',boundOffer && offerPositive && cart);
  // 036 ZOZO
  add('036',variant && (sku || boundOffer) && (positive || offerPositive) && cart);
  // 037 MERCARI
  add('037',boundOffer && (offerPositive || offerNegative) && heroPrice);
  // 038 GREENBEANS
  add('038',sku && positive && cart);
  // 039 LOHACO
  add('039',sku && positive && cart);
  for(let i=__BUILTINS__;i<__COUNT__;i++)add(String(i).padStart(3,'0'),boundOffer&&offerPositive&&cart);
 return JSON.stringify({results,documentBound:true,identity,negative});
 }catch(e){for(let i=8;i<__COUNT__;i++)results.push({id:String(i).padStart(3,'0'),status:'UNKNOWN',reason:'dom-error'});return JSON.stringify({results,documentBound:false});}
})()
""";
}
