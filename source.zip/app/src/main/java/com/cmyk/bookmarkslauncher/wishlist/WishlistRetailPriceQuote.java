package com.cmyk.bookmarkslauncher.wishlist;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Only explicit product-price ranges; no title, image or availability dependency. */
public final class WishlistRetailPriceQuote {
    public final long minimum;
    public final Long maximum;
    public final String kind; // FROM or RANGE; never an exact observed price.

    private static final String AMOUNT = "(?:[¥￥]\\s*[0-9][0-9,]*|[0-9][0-9,]*\\s*円|[0-9][0-9,]*)";
    private static final Pattern LABELED = Pattern.compile(
            "(?:販売価格|商品価格|税込価格|価格)\\s*[:：]?\\s*(" + AMOUNT + "\\s*(?:～|〜|~|\\-|から|より|以上)\\s*(?:" + AMOUNT + ")?)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern BARE = Pattern.compile("^\\s*(" + AMOUNT + ")\\s*(～|〜|~|\\-|から|より|以上)\\s*(" + AMOUNT + ")?", Pattern.CASE_INSENSITIVE);
    private static final Pattern DIGITS = Pattern.compile("[0-9][0-9,]*");
    private static final Pattern STRIP = Pattern.compile("(?is)<(?:script|style|noscript)\\b[^>]*>.*?</(?:script|style|noscript)\\s*>|<[^>]*>");

    private WishlistRetailPriceQuote(long min, Long max) {
        minimum = min; maximum = max; kind = max == null ? "FROM" : "RANGE";
    }

    /** One consistent minimum/range may appear repeatedly in a single product page. */
    public static WishlistRetailPriceQuote fromHtml(String html) {
        if (html == null || html.isEmpty()) return null;
        String body = STRIP.matcher(html).replaceAll(" ")
                .replace("&yen;", "¥").replace("&#165;", "¥")
                .replace("&nbsp;", " ").replace("&amp;", "&")
                .replaceAll("[\\s　]+", " ");
        return fromLabeledText(body);
    }

    /** Called for a WebView price label, never for the product title. */
    public static WishlistRetailPriceQuote fromLabeledText(String text) {
        if (text == null) return null;
        Matcher matcher = LABELED.matcher(text);
        WishlistRetailPriceQuote found = null;
        while (matcher.find()) {
            // Do not mistake 参考価格/通常価格 for the active sale price.
            if (matcher.start() > 0 && !Character.isWhitespace(text.charAt(matcher.start() - 1))) continue;
            WishlistRetailPriceQuote quote = fromBareText(matcher.group(1));
            if (quote == null) continue;
            if (found != null && (found.minimum != quote.minimum
                    || (found.maximum == null ? quote.maximum != null : !found.maximum.equals(quote.maximum))))
                return null; // Ambiguous variants: never guess.
            found = quote;
        }
        return found;
    }

    public static WishlistRetailPriceQuote fromBareText(String text) {
        if (text == null) return null;
        Matcher m = BARE.matcher(text.trim());
        if (!m.find()) return null;
        String matched = m.group();
        if (!(matched.contains("¥") || matched.contains("￥") || matched.contains("円"))) return null;
        Long min = number(m.group(1));
        Long max = number(m.group(3));
        if (min == null || (max != null && max < min)) return null;
        return new WishlistRetailPriceQuote(min, max);
    }

    private static Long number(String s) {
        if (s == null) return null;
        Matcher m = DIGITS.matcher(s);
        if (!m.find()) return null;
        try {
            long value = Long.parseLong(m.group().replace(",", ""));
            return value >= 1 && value <= 100000000 ? value : null;
        } catch (NumberFormatException e) { return null; }
    }
}
