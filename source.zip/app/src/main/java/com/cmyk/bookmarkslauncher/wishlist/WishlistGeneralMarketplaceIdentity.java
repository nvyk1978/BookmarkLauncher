package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Exact item-URL adapter for SHEIN and AliExpress GENERAL cards only.
 * Never implies a price, image, title or availability solely from its URL. */
public final class WishlistGeneralMarketplaceIdentity {
    private WishlistGeneralMarketplaceIdentity() { }
    private static final Pattern SHEIN = Pattern.compile("(?i)(?:^|[-/])p-([0-9]{5,15})\\.html$");
    private static final Pattern ALI = Pattern.compile("(?i)^/(?:item|i)/([0-9]{9,19})\\.html$");

    static String itemId(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())) return null;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        Matcher m;
        if (shein(host)) {
            m = SHEIN.matcher(url.getPath());
            return m.find() ? m.group(1) : null;
        }
        if (ali(host)) {
            m = ALI.matcher(url.getPath());
            return m.matches() ? m.group(1) : null;
        }
        return null;
    }
    public static boolean isDetail(URL url) { return itemId(url) != null; }
    static boolean isGuarded(URL url) {
        if (url == null) return false;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        return shein(host) || ali(host);
    }
    private static boolean shein(String host) {
        return host.equals("shein.com") || host.endsWith(".shein.com");
    }
    private static boolean ali(String host) {
        return host.equals("aliexpress.com") || host.endsWith(".aliexpress.com");
    }
    /** Cross-subdomain canonical navigation is okay ONLY for identical item IDs. */
    public static boolean sameItem(URL expected, URL actual) {
        String id = itemId(expected);
        if (id == null || actual == null || !"https".equalsIgnoreCase(actual.getProtocol())) return false;
        String e = expected.getHost().toLowerCase(Locale.ROOT);
        String a = actual.getHost().toLowerCase(Locale.ROOT);
        boolean sameFamily = (shein(e) && shein(a)) || (ali(e) && ali(a));
        return sameFamily && id.equals(itemId(actual));
    }
    /** For a known single item, recover using the ORIGINAL saved product URL.
     * An HTTP redirect must never silently change which SKU a subsequent
     * price/image/stock WebView is allowed to inspect. Other sites are unchanged. */
    public static String preservedProbeUrl(String saved, String resolved) {
        try {
            URL original = new URL(saved);
            if (isDetail(original)) return original.toExternalForm();
        } catch (Exception ignored) { }
        return resolved == null ? saved : resolved;
    }

    static boolean obviousNonProductImage(String raw) {
        if (raw == null) return true;
        String s = raw.toLowerCase(Locale.ROOT);
        return s.matches("(?s).*(?:logo|banner|sprite|avatar|icon|promo|campaign|tracking|placeholder|spacer|payment|favicon|default-img|noimage).*")
                || s.matches("(?s).*\\.(?:svg|gif)(?:[?#].*)?$");
    }
    static boolean isItemBoundImage(String raw, URL page) {
        String id = itemId(page);
        return id != null && raw != null && raw.contains(id) && !obviousNonProductImage(raw);
    }
}
