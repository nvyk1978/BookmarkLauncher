package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Exact item-URL adapter for SHEIN and AliExpress GENERAL cards only.
 * Never implies a price, image, title or availability solely from its URL. */
public final class WishlistGeneralMarketplaceIdentity {
    private WishlistGeneralMarketplaceIdentity() { }
    private static final Pattern SHEIN = Pattern.compile("(?i)(?:^|[-/])p-([0-9]{5,15})(?:-cat-[0-9]{1,12})?\\.html$");
    private static final Pattern ALI = Pattern.compile("(?i)^/(?:item|i)/([0-9]{9,19})\\.html$");

    static String itemId(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())) return null;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        Matcher m;
        if (shein(host)) {
            m = SHEIN.matcher(url.getPath());
            return m.find() ? m.group(1) : null;
        }
        if (ali(host)) {
            m = ALI.matcher(url.getPath());
            return m.matches() ? m.group(1) : null;
        }
        return null;
    }
    public static boolean isDetail(URL url) { return itemId(url) != null; }
    static boolean isGuarded(URL url) {
        if (url == null) return false;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        return shein(host) || ali(host);
    }
    private static boolean shein(String host) {
        return host.equals("shein.com") || host.endsWith(".shein.com");
    }
    private static boolean ali(String host) {
        return host.equals("aliexpress.com") || host.endsWith(".aliexpress.com");
    }
    /** Distinguish a proven different item from a URL which simply omits its ID.
     * UNKNOWN is NOT evidence for metadata commitment: scripts must bind to the
     * requested item via same-item product data before any price/title is saved.
     * Invalid/off-site redirects are known-unsafe and remain DIFFERENT.
     */
    public enum ItemRelation { SAME, UNKNOWN, DIFFERENT }
    public static ItemRelation relation(URL expected, URL actual) {
        String id = itemId(expected);
        if (id == null || actual == null || !"https".equalsIgnoreCase(actual.getProtocol()))
            return ItemRelation.DIFFERENT;
        String e = expected.getHost().toLowerCase(Locale.ROOT);
        String a = actual.getHost().toLowerCase(Locale.ROOT);
        if (!((shein(e) && shein(a)) || (ali(e) && ali(a)))) return ItemRelation.DIFFERENT;
        String found = itemId(actual);
        return found == null ? ItemRelation.UNKNOWN
                : id.equals(found) ? ItemRelation.SAME : ItemRelation.DIFFERENT;
    }
    public static boolean sameItem(URL expected, URL actual) {
        return relation(expected, actual) == ItemRelation.SAME;
    }
    /** For a known single item, recover using the ORIGINAL saved product URL.
     * An HTTP redirect must never silently change which SKU a subsequent
     * price/image/stock WebView is allowed to inspect. Other sites are unchanged. */
    public static String preservedProbeUrl(String saved, String resolved) {
        try {
            URL original = new URL(saved);
            if (isDetail(original)) return original.toExternalForm();
        } catch (Exception ignored) { }
        return resolved == null ? saved : resolved;
    }

    /** SHEIN Japan desktop hostname uses /<product>-p-ID.html, unlike
     * m.shein.com/jp/<product>-p-ID.html. Do not manufacture a new SKU. */
    public static URL japanDesktopUrl(URL saved) {
        if (!isDetail(saved) || !"m.shein.com".equalsIgnoreCase(saved.getHost())) return null;
        try {
            String path = saved.getPath();
            if (!path.startsWith("/jp/")) return null;
            String desktopPath = path.substring(3); // /jp/Shirt -> /Shirt
            String query = saved.getQuery();
            URL alternate = new URL("https://jp.shein.com" + desktopPath
                    + (query == null || query.isEmpty() ? "" : "?" + query));
            return sameItem(saved, alternate) ? alternate : null;
        } catch (Exception ignored) { return null; }
    }

    /** Diagnostic only: never write query values, fragments or credentials. */
    public static String diagnosticRoute(String raw) {
        if (raw == null || raw.isBlank()) return "none";
        try {
            URL url = new URL(raw);
            String scheme = url.getProtocol().toLowerCase(Locale.ROOT);
            if (!"https".equals(scheme)) return "non-https";
            String host = url.getHost().toLowerCase(Locale.ROOT);
            String path = url.getPath();
            if (path == null) path = "";
            // Avoid logging user-provided free-text product slugs. Retain the
            // route shape and item ID, which are enough to diagnose redirects.
            String item = itemId(url);
            String suffix = item == null ? "" : " id=" + item;
            String shape = path.equals("/") || path.isEmpty() ? "/home" :
                    path.equals("/jp/") || path.equals("/jp") ? "/jp/home" :
                    path.matches("(?i).*(?:risk|challenge|captcha|robot).*") ? "/challenge" :
                    item != null ? (path.startsWith("/jp/") ? "/jp/item" : "/item") :
                    path.startsWith("/jp/") ? "/jp/non-item" :
                    path.startsWith("/item/") ? "/item/non-item" :
                    path.startsWith("/i/") ? "/i/non-item" : "/non-item";
            String category = path.matches("(?i).*?-cat-[0-9]{1,12}\\.html$") ? " cat=yes" : " cat=no";
            return host + shape + suffix + category;
        } catch (Exception ignored) { return "invalid-url"; }
    }

    static boolean obviousNonProductImage(String raw) {
        if (raw == null) return true;
        String s = raw.toLowerCase(Locale.ROOT);
        return s.matches("(?s).*(?:logo|banner|sprite|avatar|icon|promo|campaign|tracking|placeholder|spacer|payment|favicon|default-img|noimage).*")
                || s.matches("(?s).*\\.(?:svg|gif)(?:[?#].*)?$");
    }
    static boolean isItemBoundImage(String raw, URL page) {
        String id = itemId(page);
        return id != null && raw != null && raw.contains(id) && !obviousNonProductImage(raw);
    }
}
