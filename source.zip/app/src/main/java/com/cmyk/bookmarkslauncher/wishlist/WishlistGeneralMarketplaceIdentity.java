package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Exact item-URL adapter for SHEIN, AliExpress and Temu GENERAL cards only.
 * Never implies a price, image, title or availability solely from its URL. */
public final class WishlistGeneralMarketplaceIdentity {
    private WishlistGeneralMarketplaceIdentity() { }
    private static final Pattern SHEIN = Pattern.compile("(?i)(?:^|[-/])p-([0-9]{5,15})(?:-cat-[0-9]{1,12})?\\.html$");
    private static final Pattern ALI = Pattern.compile("(?i)^/(?:p/)?(?:item|i)/([0-9]{9,19})\\.html/?$");

    private static final Pattern TEMU = Pattern.compile("(?i)(?:^|/)\\S*-g-([0-9]{10,20})\\.html/?$");
    private static final Pattern TEMU_SIMPLE = Pattern.compile("(?i)^/(?:jp/)?g-([0-9]{10,20})\\.html/?$");

    public enum Merchant { SHEIN, ALIEXPRESS, TEMU, OTHER }
    public static Merchant merchant(URL url) {
        if (url == null) return Merchant.OTHER;
        String host=url.getHost().toLowerCase(Locale.ROOT);
        if (shein(host)) return Merchant.SHEIN;
        if (ali(host)) return Merchant.ALIEXPRESS;
        if (temu(host)) return Merchant.TEMU;
        return Merchant.OTHER;
    }
    private static String numericQuery(URL url, String key, int min, int max) {
        if (url.getQuery()==null) return null;
        Matcher m=Pattern.compile("(?i)(?:^|&)"+Pattern.quote(key)+"=([0-9]{"+min+","+max+"})(?:&|$)").matcher(url.getQuery());
        return m.find()?m.group(1):null;
    }
    static String itemId(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())) return null;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        Matcher m;
        if (shein(host)) {
            m = SHEIN.matcher(url.getPath());
            return m.find() ? m.group(1) : null;
        }
        if (ali(host)) {
            m = ALI.matcher(url.getPath());
            if (m.matches()) return m.group(1);
            if (url.getPath().matches("(?i)^/(?:p/)?item(?:\\.html)?/?$"))
                return numericQuery(url,"productId",9,19);
        }
        if (temu(host)) {
            m=TEMU.matcher(url.getPath());
            if (m.find()) return m.group(1);
            m=TEMU_SIMPLE.matcher(url.getPath());
            if (m.matches()) return m.group(1);
            if (url.getPath().matches("(?i)^/(?:jp/)?(?:goods|product)(?:\\.html)?/?$"))
                return numericQuery(url,"goods_id",10,20);
        }
        return null;
    }
    public static boolean isDetail(URL url) { return itemId(url) != null; }
    static boolean isGuarded(URL url) {
        if (url == null) return false;
        String host = url.getHost().toLowerCase(Locale.ROOT);
        return shein(host) || ali(host) || temu(host);
    }
    private static boolean shein(String host) {
        return host.equals("shein.com") || host.endsWith(".shein.com");
    }
    private static boolean ali(String host) {
        return host.equals("aliexpress.com") || host.endsWith(".aliexpress.com");
    }
    private static boolean temu(String host) {
        return host.equals("temu.com") || host.endsWith(".temu.com");
    }
    /** Distinguish a proven different item from a URL which simply omits its ID.
     * UNKNOWN is NOT evidence for metadata commitment: scripts must bind to the
     * requested item via same-item product data before any price/title is saved.
     * Invalid/off-site redirects are known-unsafe and remain DIFFERENT.
     */
    public enum ItemRelation { SAME, UNKNOWN, DIFFERENT }
    public static ItemRelation relation(URL expected, URL actual) {
        String id = itemId(expected);
        if (id == null || actual == null || !"https".equalsIgnoreCase(actual.getProtocol()))
            return ItemRelation.DIFFERENT;
        String e = expected.getHost().toLowerCase(Locale.ROOT);
        String a = actual.getHost().toLowerCase(Locale.ROOT);
        if (!((shein(e) && shein(a)) || (ali(e) && ali(a)) || (temu(e) && temu(a)))) return ItemRelation.DIFFERENT;
        String found = itemId(actual);
        return found == null ? ItemRelation.UNKNOWN
                : id.equals(found) ? ItemRelation.SAME : ItemRelation.DIFFERENT;
    }
    public static boolean sameItem(URL expected, URL actual) {
        return relation(expected, actual) == ItemRelation.SAME;
    }
    /** For a known single item, recover using the ORIGINAL saved product URL.
     * An HTTP redirect must never silently change which SKU a subsequent
     * price/image/stock WebView is allowed to inspect. Other sites are unchanged. */
    public static String preservedProbeUrl(String saved, String resolved) {
        try {
            URL original = new URL(saved);
            if (isDetail(original)) return original.toExternalForm();
        } catch (Exception ignored) { }
        return resolved == null ? saved : resolved;
    }

    /** One alternate official URL of THE SAME numeric item. This can recover
     * a regional web shell without crossing into an unrelated listing or
     * changing the stored product URL. Not a guarantee of merchant access. */
    public static URL fallbackExactItemUrl(URL saved) {
        if (!isDetail(saved)) return null;
        String id=itemId(saved);
        try {
            URL candidate=null;
            switch (merchant(saved)) {
                case ALIEXPRESS:
                    if (!"www.aliexpress.com".equalsIgnoreCase(saved.getHost()))
                        candidate=new URL("https://www.aliexpress.com/item/"+id+".html");
                    break;
                case TEMU:
                    // Use Temu's independently recognized goods-id route only
                    // when the original URL used a slug or /g-ID form.
                    candidate=new URL("https://www.temu.com/-g-"+id+".html");
                    break;
                default: break;
            }
            if (candidate != null && merchant(saved) == Merchant.TEMU
                    && saved.getHost().equalsIgnoreCase(candidate.getHost())
                    && saved.getPath().equalsIgnoreCase(candidate.getPath())) return null;
            return candidate!=null && sameItem(saved,candidate) ? candidate : null;
        } catch(Exception ignored) { return null; }
    }

    /** SHEIN Japan desktop hostname uses /<product>-p-ID.html, unlike
     * m.shein.com/jp/<product>-p-ID.html. Do not manufacture a new SKU. */
    public static URL japanDesktopUrl(URL saved) {
        if (!isDetail(saved) || !"m.shein.com".equalsIgnoreCase(saved.getHost())) return null;
        try {
            String path = saved.getPath();
            if (!path.startsWith("/jp/")) return null;
            String desktopPath = path.substring(3); // /jp/Shirt -> /Shirt
            String query = saved.getQuery();
            URL alternate = new URL("https://jp.shein.com" + desktopPath
                    + (query == null || query.isEmpty() ? "" : "?" + query));
            return sameItem(saved, alternate) ? alternate : null;
        } catch (Exception ignored) { return null; }
    }

    /** Diagnostic only: never write query values, fragments or credentials. */
    public static String diagnosticRoute(String raw) {
        if (raw == null || raw.isBlank()) return "none";
        try {
            URL url = new URL(raw);
            String scheme = url.getProtocol().toLowerCase(Locale.ROOT);
            if (!"https".equals(scheme)) return "non-https";
            String host = url.getHost().toLowerCase(Locale.ROOT);
            String path = url.getPath();
            if (path == null) path = "";
            // Avoid logging user-provided free-text product slugs. Retain the
            // route shape and item ID, which are enough to diagnose redirects.
            String item = itemId(url);
            String suffix = item == null ? "" : " id=" + item;
            String shape = path.equals("/") || path.isEmpty() ? "/home" :
                    path.equals("/jp/") || path.equals("/jp") ? "/jp/home" :
                    path.matches("(?i).*(?:risk|challenge|captcha|robot).*") ? "/challenge" :
                    item != null ? (path.startsWith("/jp/") ? "/jp/item" : "/item") :
                    path.startsWith("/jp/") ? "/jp/non-item" :
                    path.startsWith("/item/") ? "/item/non-item" :
                    path.startsWith("/i/") ? "/i/non-item" : "/non-item";
            String category = path.matches("(?i).*?-cat-[0-9]{1,12}\\.html$") ? " cat=yes" : " cat=no";
            return host + shape + suffix + category;
        } catch (Exception ignored) { return "invalid-url"; }
    }

    static boolean obviousNonProductImage(String raw) {
        if (raw == null) return true;
        String s = raw.toLowerCase(Locale.ROOT);
        return s.matches("(?s).*(?:logo|banner|sprite|avatar|icon|promo|campaign|tracking|placeholder|spacer|payment|favicon|default-img|noimage).*")
                || s.matches("(?s).*\\.(?:svg|gif)(?:[?#].*)?$");
    }
    static boolean isItemBoundImage(String raw, URL page) {
        String id = itemId(page);
        return id != null && raw != null && raw.contains(id) && !obviousNonProductImage(raw);
    }
}
