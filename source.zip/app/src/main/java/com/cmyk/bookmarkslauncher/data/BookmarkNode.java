package com.cmyk.bookmarkslauncher.data;

import java.net.URI;

public final class BookmarkNode {
    public static final int TYPE_BOOKMARK = 0;
    public static final int TYPE_FOLDER = 1;

    public String id;
    public String externalSource;
    public String externalId;
    public int type;
    public String parentId;
    public String title;
    public String siteName;
    public String pageTitle;
    public String customName;
    public String url;
    public int sortIndex;
    public int cellX = -1;
    public int cellY = -1;
    public int spanX = 1;
    public int spanY = 1;
    public long createdAt;
    public long updatedAt;
    public Long lastAccessedAt;
    public Long deletedAt;
    public String faviconPath;
    public String screenshotPath;
    public String offlinePath;
    public Long offlineSavedAt;

    public boolean isFolder() {
        return type == TYPE_FOLDER;
    }

    public String displayName() {
        if (isFolder()) return title == null || title.isBlank() ? "フォルダ" : title;
        if (customName != null && !customName.isBlank()) return customName;
        if (siteName != null && !siteName.isBlank()) return siteName;
        if (title != null && !title.isBlank() && !title.startsWith("http://") && !title.startsWith("https://")) return title;
        String fallback = fallbackSiteName(url);
        if (fallback != null) return fallback;
        if (title != null && !title.isBlank()) return title;
        return "ブックマーク";
    }

    public String siteNameOrFallback() {
        if (siteName != null && !siteName.isBlank()) return siteName;
        String fallback = fallbackSiteName(url);
        return fallback == null ? "—" : fallback;
    }

    private static String fallbackSiteName(String url) {
        if (url == null || url.isBlank()) return null;
        try {
            String host = new URI(url).getHost();
            if (host == null || host.isBlank()) return null;
            if (host.startsWith("www.")) host = host.substring(4);
            String[] parts = host.split("\\.");
            String base = parts.length == 0 ? host : parts[0];
            if (base.isBlank()) return host;
            return Character.toUpperCase(base.charAt(0)) + base.substring(1);
        } catch (Exception ignored) {
            return null;
        }
    }
}
