package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.net.URL;
import java.util.Locale;

/**
 * Foreground, manual-refresh-only stock probe for JS-rendered product forms.
 * Reports AVAILABLE only for a visible/enabled cart control in a product form.
 * Never reads or persists prices, titles, images or site-reachability state.
 * Unknown / redirect / script errors produce no database writes.
 */
public final class WishlistAvailabilityWebViewProbe {
    public interface Callback { void completed(String status); }
    public interface Trace { void record(String stage, String safeEvidence); }
    private Trace trace;
    public void setTrace(Trace listener) { trace = listener; }
    private void trace(String stage, String evidence) { if (trace != null) trace.record(stage,evidence); }
    private final FrameLayout parent;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private Callback callback;
    private String originHost;
    private String originPath;
    private String originalQuery;
    private MarketplaceIdentity expectedMarketplace;
    private boolean finished;
    private int specialRetries;
    private final Runnable timeout = () -> finish("UNKNOWN");

    public WishlistAvailabilityWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public void start(String urlText, WishlistMode mode, Callback done) {
        cancel();
        if (Looper.myLooper() != Looper.getMainLooper()) {
            if (done != null) done.completed("UNKNOWN");
            return;
        }
        callback = done;
        finished = false;
        specialRetries = 0;
        try {
            URL url = new URL(urlText);
            if (!WishlistAvailabilityExtractor.isProductDetail(url)) {
                finish("UNKNOWN"); return; // Never inspect a category/listing's unrelated buttons.
            }
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) {
                finish("UNKNOWN"); return;
            }
            if (mode == null || mode == WishlistMode.UNRESOLVED
                    || WishlistMode.forDirectUrl(urlText) != mode) { finish("UNKNOWN"); return; }
            expectedMarketplace = MarketplaceIdentity.from(url);
            originHost = url.getHost().toLowerCase(Locale.ROOT);
            originPath = url.getPath();
            originalQuery = url.getQuery();
            web = BackgroundDomWebView.create(parent.getContext());

            web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setClickable(false);
            web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.setVerticalScrollBarEnabled(false);
            web.setHorizontalScrollBarEnabled(false);

            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return request.isForMainFrame() && !allowed(request.getUrl().toString());
                }
                @Override public void onPageFinished(WebView view, String loaded) {
                    if (finished || !allowed(loaded)) return;
                    if ("askul.co.jp".equals(originHost) || "www.askul.co.jp".equals(originHost))
                        trace("page.finished", "sameSku=true");
                    main.postDelayed(() -> inspect(view), 1200L);
                }
                @Override public void onReceivedHttpError(WebView view, WebResourceRequest req,
                                                         android.webkit.WebResourceResponse response) {
                    if (req.isForMainFrame() && ("askul.co.jp".equals(originHost)
                            || "www.askul.co.jp".equals(originHost)))
                        trace("http", "code="+response.getStatusCode());
                }
                @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    if (request.isForMainFrame()) finish("UNKNOWN");
                }
            });
            boolean askul = "askul.co.jp".equals(originHost) || "www.askul.co.jp".equals(originHost);
            main.postDelayed(timeout, askul ? 19000L : 13000L);
            web.loadUrl(url.toString());
            if (askul) {
                final WebView skuProbeView = web;
                main.postDelayed(() -> inspect(skuProbeView), 2400L);
            }
        } catch (Exception ignored) { finish("UNKNOWN"); }
    }

    private URL safeOriginalUrl() {
        try { return new URL("https://" + originHost + originPath); }
        catch (Exception ignored) { return null; }
    }

    private boolean allowed(String urlText) {
        try {
            URL url = new URL(urlText);
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) return false;
            String host = url.getHost().toLowerCase(Locale.ROOT);
            if (originHost == null || originPath == null) return false;
            // A redirect to the store home or another product cannot prove the
            // original item's stock, even if the destination has a cart button.
            if (expectedMarketplace != null) return expectedMarketplace.matches(url);
            if (!url.getPath().equalsIgnoreCase(originPath)) return false;
            // A GENERAL product can be identified only in the query string
            // (Color Me, CS-Cart, 久世福). Never trust another item's cart.
            for (String key : new String[]{"product_id", "pid", "eci_product"}) {
                String expected = productQueryValue(originalQuery, key);
                if (expected != null && !expected.equalsIgnoreCase(productQueryValue(url.getQuery(), key)))
                    return false;
            }
            if (originHost.equals("amazon.co.jp") || originHost.endsWith(".amazon.co.jp"))
                return host.equals("amazon.co.jp") || host.endsWith(".amazon.co.jp");
            return host.equals(originHost);
        } catch (Exception ignored) { return false; }
    }

    private static String productQueryValue(String query, String key) {
        if (query == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                "(?i)(?:^|&)" + java.util.regex.Pattern.quote(key) + "=([a-z0-9_-]+)(?:&|$)")
                .matcher(query);
        return m.find() ? m.group(1) : null;
    }

    private void inspect(WebView current) {
        if (finished || current != web || !allowed(current.getUrl())) return;
        // Independent, conservative rendered-DOM adapter for verified single-item
        // pages. No click/navigation is performed, and no unrelated data is read.
        String store = originHost == null ? "" : originHost;
        if (store.equals("hiraki.co.jp") || store.equals("www.hiraki.co.jp")) {
            String sku = originPath.replaceAll("/+$", "").replaceAll(".*/", "");
            current.evaluateJavascript(HirakiStockDom.stockEvidence(sku), value -> {
                if (finished) return;
                String status="UNKNOWN", reason="unreadable", flags="";
                try {
                    Object raw = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    org.json.JSONObject obj = new org.json.JSONObject((String) raw);
                    status=obj.optString("status", "UNKNOWN");
                    reason=obj.optString("reason", "unreadable");
                    flags=" skuMatch="+obj.optBoolean("skuMatch",false)
                            +" color99="+obj.optBoolean("color99",false)
                            +" table="+obj.optInt("tableFound",0)
                            +" row="+obj.optInt("rowFound",0)
                            +" qty="+obj.optInt("qtyEnabled",0)
                            +" cart="+obj.optInt("cartEnabled",0)
                            +" cartAction="+obj.optInt("cartAction",0)
                            +" cartTextHint="+obj.optInt("cartTextHint",0)
                            +" icon="+obj.optInt("stockIcon",0)
                            +" pos="+obj.optInt("stockPositive",0)
                            +" neg="+obj.optInt("stockNegative",0);
                } catch (Exception ignored) { }
                String evidence="attempt="+(specialRetries+1)+" status="+status
                        +" reason="+reason+flags;
                trace("hiraki.evidence",evidence);
                RetailDiagnostics.hiraki("webview.stock",evidence);
                if ("AVAILABLE".equals(status)) { finish("AVAILABLE"); return; }
                if ("UNAVAILABLE".equals(status)) { finish("UNAVAILABLE"); return; }
                // Retry after a dynamic stock row is hydrated. Do not infer
                // availability from the separate five-symbol legend.
                if (++specialRetries < 5) main.postDelayed(() -> inspect(current), 1450L);
                else finish("UNKNOWN");
            });
            return;
        }
        if (GeneralRetailIdentity.storeFromText("https://"+store+originPath)) {
            String sku = GeneralRetailIdentity.itemId(safeOriginalUrl());
            if (sku == null) { finish("UNKNOWN"); return; }
            if ("ASKUL".equals(GeneralRetailIdentity.store(safeOriginalUrl()))) {
                current.evaluateJavascript(AskulProductDom.stockEvidence(sku), value -> {
                    if (finished) return;
                    String status = "UNKNOWN", evidence = "unreadable-result";
                    try {
                        Object raw = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                        org.json.JSONObject obj = new org.json.JSONObject((String) raw);
                        status = obj.optString("status", "UNKNOWN");
                        evidence = "skuMatch=" + obj.optBoolean("skuLabel",false)
                                + " stockFound=" + obj.optBoolean("stockFound",false)
                                + " cartFound=" + obj.optInt("cartFound",0)
                                + " cartEnabled=" + obj.optInt("cartEnabled",0)
                                + " cartDisabled=" + obj.optInt("cartDisabled",0)
                                + " restricted=" + obj.optBoolean("restricted",false)
                                + " reason=" + obj.optString("reason","unknown");
                    } catch (Exception ignored) { }
                    trace("evidence", "attempt=" + (specialRetries+1) + " " + evidence);
                    if ("AVAILABLE".equals(status)) { finish("AVAILABLE"); return; }
                    if ("UNAVAILABLE".equals(status)) { finish("UNAVAILABLE"); return; }
                    if (++specialRetries < 7) main.postDelayed(() -> inspect(current), 1700L);
                    else finish("UNKNOWN");
                });
                return;
            }
            current.evaluateJavascript(GeneralRetailStockDom.javascript(store, sku), value -> {
                if (finished) return;
                RetailDiagnostics.general(safeOriginalUrl(), "webview.stock",
                        "attempt="+(specialRetries+1)+" state="+value);
                if ("askul.co.jp".equals(originHost) || "www.askul.co.jp".equals(originHost))
                    trace("dom", "attempt="+(specialRetries+1)+" state="+value);
                if ("\"AVAILABLE\"".equals(value)) { finish("AVAILABLE"); return; }
                if ("\"UNAVAILABLE\"".equals(value)) { finish("UNAVAILABLE"); return; }
                if (++specialRetries < 4) main.postDelayed(() -> inspect(current), 1200L);
                else finish("UNKNOWN");
            });
            return;
        }
        if (store.equals("eshop.fumuroya.com") || store.equals("e-mono.jr-central.co.jp")) {
            current.evaluateJavascript(WishlistIndependentStockDom.javascript(store), value -> {
                if (finished) return;
                String status="UNKNOWN", reason="unreadable", flags="";
                try {
                    Object raw=new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    org.json.JSONObject o=new org.json.JSONObject((String)raw);
                    status=o.optString("status","UNKNOWN");
                    reason=o.optString("reason","unreadable");
                    flags=" title="+o.optBoolean("title",false)
                            +" qty="+o.optInt("qty",0)
                            +" cart="+o.optInt("cart",0)
                            +" enabled="+o.optInt("enabled",0)
                            +" negative="+o.optInt("negative",0)
                            +" selected="+o.optBoolean("selected",false);
                }catch(Exception ignored) { }
                trace(store.equals("eshop.fumuroya.com")?"fumuroya.evidence":"jr.evidence",
                        "attempt="+(specialRetries+1)+" status="+status+" reason="+reason+flags);
                if ("AVAILABLE".equals(status)) {finish("AVAILABLE");return;}
                if ("UNAVAILABLE".equals(status)) {finish("UNAVAILABLE");return;}
                if (++specialRetries < 5)main.postDelayed(()->inspect(current),1350L);
                else finish("UNKNOWN");
            });
            return;
        }
        if (store.equals("yuican-shop.com")) {
            current.evaluateJavascript(WishlistRemainingStockDom.javascript(store), value -> {
                if(finished)return;
                if("\"AVAILABLE\"".equals(value)){finish("AVAILABLE");return;}
                if(++specialRetries<5)main.postDelayed(()->inspect(current),1350);
                else finish("UNKNOWN");
            });
            return;
        }
        if (store.equals("nakasima-inc.shop")
                || store.equals("www.torikan.net") || store.equals("torikan.net")) {
            current.evaluateJavascript(shopPurchaseJavascript(store), value -> {
                if(finished)return;
                if("\"AVAILABLE\"".equals(value)){finish("AVAILABLE");return;}
                // Fumuroya hydrates dynamic purchase controls after page load.
                // Repeat only in this store; other successful site modes unchanged.
                if(store.equals("eshop.fumuroya.com") && ++specialRetries<5)
                    main.postDelayed(()->inspect(current),1350);
                else finish("UNKNOWN");
            });
            return;
        }
        if (expectedMarketplace != null) {
            String siteJs= expectedMarketplace.site==MarketplaceIdentity.Site.AMAZON ? AmazonDomSelectors.stock(expectedMarketplace.id)
                    : expectedMarketplace.site==MarketplaceIdentity.Site.RAKUTEN ? RakutenDomSelectors.stock()
                    : expectedMarketplace.site==MarketplaceIdentity.Site.YAHOO ? YahooDomSelectors.stock() : null;
            if(siteJs==null){finish("UNKNOWN");return;}
            current.evaluateJavascript(siteJs,v->finish("\"AVAILABLE\"".equals(v) ? "AVAILABLE" : "UNKNOWN"));
            return;
        }
        // GENERAL: DOM-based, product-local purchase verification. Independent
        // from name/image/price and isolated from the marketplace selectors.
        current.evaluateJavascript(WishlistGeneralPurchaseDom.javascript(),
                value -> finish("\"AVAILABLE\"".equals(value) ? "AVAILABLE" : "UNKNOWN"));
    }

    /** JS inspects only the *visible* purchase UI of the known product detail page.
     * No click is sent; the app never makes a purchase or adds items to a cart. */
    private static String shopPurchaseJavascript(String host) {
        String shop = host.replace("'", "");
        return "(function(){try{" +
                "var host='" + shop + "';" +
                "function visible(e){if(!e||e.disabled||e.getAttribute('aria-disabled')==='true'||!e.getClientRects().length)return false;" +
                "for(var p=e;p;p=p.parentElement){var s=getComputedStyle(p);" +
                "if(s.display==='none'||s.visibility==='hidden'||p.hidden||Number(s.opacity)===0)return false;}return true;}" +
                "var main=document.querySelector('main,#main,#contents,[role=main],#product_detail,#productDetail,.product-detail,.item-detail');" +
                "if(!main)main=document.body;if(!main)return 'UNKNOWN';" +
                "var product=main.querySelector('#product_detail,#productDetail,.product-detail,.item-detail,.product-info,.detail-item,.product__detail')||main;" +
                "var controls=product.querySelectorAll('button,input[type=submit],input[type=button],a[href],[role=button]');" +
                "var label=/(?:カートに入れる|買い物かごに入れる|かごに入れる|購入する|注文する|add\\s+to\\s+cart)/i;" +
                "var count=0;for(var i=0;i<controls.length&&i<130;i++){var b=controls[i];" +
                "if(!visible(b))continue;var name=(b.innerText||b.textContent||b.value||'')+' '+(b.getAttribute('aria-label')||'');" +
                "if(!label.test(name))continue;" +
                "if(b.closest('nav,header,footer,[class*=related],[class*=recommend],[id*=related],[id*=recommend]'))continue;" +
                "var group=b.closest('form,.purchase,.cart,.buy,.product-detail,.item-detail')||b.parentElement;" +
                "if(!group||!product.contains(group))continue;" +
                "var nearby=group.querySelector('input[type=number],input[name*=quantity],input[name*=Quantity],input[name*=qty],select[name*=quantity]');" +
                "if(!nearby){var previous=b.parentElement;for(var k=0;k<4&&previous&&product.contains(previous);k++,previous=previous.parentElement){" +
                "nearby=previous.querySelector('input[type=number],input[name*=quantity],input[name*=qty]');if(nearby)break;}}" +
                "if(!nearby){var quantities=product.querySelectorAll('input[type=number],input[name*=quantity],input[name*=qty],input[id*=quantity]');" +
                "if(quantities.length===1)nearby=quantities[0];}" +
                "if(!nearby&&!group.matches('form'))continue;" +
                "var notices=group.querySelectorAll('[class*=stock],[class*=sold],[class*=out-of-stock],[id*=stock]');" +
                "var sold=false;for(var z=0;z<notices.length&&z<25;z++){" +
                "if(visible(notices[z])&&/(?:売り切れ|売切れ|完売|在庫切れ|sold\\s*out)/i.test(notices[z].textContent||''))sold=true;}" +
                "if(sold)continue;" +

                "count++;break;}return count===1?'AVAILABLE':'UNKNOWN';" +
                "}catch(e){return 'UNKNOWN';}})()";
    }

    private void finish(String status) {
        if (finished) return;
        finished = true;
        main.removeCallbacks(timeout);
        WebView old = web;
        web = null;
        if (old != null) {
            old.stopLoading();
            old.setWebViewClient(new WebViewClient());
            
            old.destroy();
        }
        Callback done = callback;
        callback = null;
        if (done != null) done.completed(status);
    }

    public void cancel() {
        if (Looper.myLooper() != Looper.getMainLooper()) return;
        callback = null;
        finish("UNKNOWN");
    }
}
