package com.cmyk.bookmarkslauncher.wishlist;

import com.cmyk.bookmarkslauncher.DiagLog;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.ConsoleMessage;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.net.URL;
import java.util.Locale;

/**
 * Foreground, manual-refresh-only stock probe for JS-rendered product forms.
 * Reports AVAILABLE only for a visible/enabled cart control in a product form.
 * Never reads or persists prices, titles, images or site-reachability state.
 * Unknown / redirect / script errors produce no database writes.
 */
public final class WishlistAvailabilityWebViewProbe {
    public interface Callback { void completed(String status); }
    public interface Trace { void record(String stage, String safeEvidence); }
    public interface ModeProgress { void changed(String label); }
    private ModeProgress modeProgress;
    public void setModeProgress(ModeProgress listener) { modeProgress=listener; }
    private void publishMode(String label) {
        if (!finished && modeProgress != null) modeProgress.changed(label);
    }
    private Trace trace;
    public void setTrace(Trace listener) { trace = listener; }
    private void trace(String stage, String evidence) {
        if (trace != null) trace.record(stage,evidence);
        // App-wide diagnosis receives only bounded, non-sensitive cart audit
        // summaries. The detailed element inventory remains per-card only.
        if (stage != null && (stage.equals("dom.audit.summary") || stage.equals("dom.audit.verdict")
                || stage.equals("dom.audit.failure") || stage.equals("dom.audit.skip"))) {
            String safe = evidence == null ? "-" : evidence;
            if (safe.length() > 420) safe = safe.substring(0, 420);
            DiagLog.write(parent.getContext(), "Wish webview.cart.audit host="
                    + (originHost == null ? "-" : originHost) + " stage=" + stage + " " + safe);
        }
    }
    private final FrameLayout parent;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private Callback callback;
    private String originHost;
    private WishlistMode mode;
    private String originPath;
    private String originalQuery;
    private MarketplaceIdentity expectedMarketplace;
    private boolean finished;
    private int specialRetries;
    private boolean rawAuditEnabled;
    private int rawAuditSamples;
    private boolean auditPending;
    private int webErrorSamples;
    private boolean auditReceived;
    private boolean auditProductCartEnabled;
    private boolean auditPurchaseNamed;
    private int auditElements;
    private boolean mujiInspectionRunning;
    private int mainFrameHttpFailure;
    private boolean generalInspectionPending;
    private int generalInspectionRounds;
    private boolean identityAuditDone;
    private String verifiedProductTitle;
    private Long verifiedProductPrice;
    private boolean titleCaptureAttempted;
    // A single, read-only GENERAL 000+ sweep precedes every site's stock adapter.
    // GENERAL evidence may only be used for GENERAL cards and exactly-matched items.
    private boolean generalFirstDone;
    private String generalFirstVerified="UNKNOWN";
    // GENERAL mode classification and exact-item inspection have INDEPENDENT
    // 15 second windows. Both manual and batch use this same instance/path.
    private boolean pageInspectionStarted;
    private boolean pageWindowExpired;
    private final Runnable modeWindowTimeout = () -> {
        if (!finished && mode == WishlistMode.GENERAL && !pageInspectionStarted)
            beginPageInspection("mode-deadline");
    };
    private final Runnable pageWindowTimeout = () -> {
        if (!finished && mode == WishlistMode.GENERAL && pageInspectionStarted) {
            pageWindowExpired=true;
            trace("phase", "phase=page result=deadline budgetMs=15000");
            finish("UNKNOWN");
        }
    };
    private boolean nativeInspectionPending;
    private int pendingBodyObservations;
    private final Runnable timeout = () -> {
        trace("deadline", "host="+originHost+" attempts="+specialRetries
                +" urlVerified="+(web!=null && allowed(web.getUrl())));
        finish("UNKNOWN");
    };

    public WishlistAvailabilityWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public void start(String urlText, WishlistMode mode, Callback done) {
        cancel();
        if (Looper.myLooper() != Looper.getMainLooper()) {
            if (done != null) done.completed("UNKNOWN");
            return;
        }
        callback = done;
        this.mode = mode;
        finished = false;
        specialRetries = 0;
        rawAuditEnabled = false;
        rawAuditSamples = 0;
        auditPending = false;
        webErrorSamples = 0;
        auditReceived = false;
        auditProductCartEnabled = false;
        auditPurchaseNamed = false;
        auditElements = 0;
        generalInspectionPending = false;
        mainFrameHttpFailure = 0;
        mujiInspectionRunning = false;
        generalInspectionRounds = 0;
        identityAuditDone = false;
        verifiedProductTitle = null;
        dedicatedProofThisInspection=false;
        verifiedProductPrice = null;
        titleCaptureAttempted = false;
        generalFirstDone = false;
        generalFirstVerified = "UNKNOWN";
        pageInspectionStarted = false;
        pageWindowExpired = false;
        main.removeCallbacks(modeWindowTimeout);
        main.removeCallbacks(pageWindowTimeout);
        nativeInspectionPending = false;
        pendingBodyObservations = 0;
        try {
            URL url = new URL(urlText);
            if (!WishlistAvailabilityExtractor.isProductDetail(url)
                    && !(mode == WishlistMode.GENERAL && WishlistGeneralAlphabetDom.candidateUrl(url))
                    && !(mode == WishlistMode.GENERAL && WishlistRetailDedicatedMode.forUrl(url)
                        != WishlistRetailDedicatedMode.NONE)) {
                finish("UNKNOWN"); return; // Category/listing: no product evidence.
            }
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) {
                finish("UNKNOWN"); return;
            }
            if (mode == null || mode == WishlistMode.UNRESOLVED
                    || WishlistMode.forDirectUrl(urlText) != mode) { finish("UNKNOWN"); return; }
            expectedMarketplace = MarketplaceIdentity.from(url);
            originHost = url.getHost().toLowerCase(Locale.ROOT);
            originPath = url.getPath();
            originalQuery = url.getQuery();
            // Read-only DOM inspection is standard for all GENERAL product
            // refreshes. Marketplace and dedicated-mode classifiers are intact.
            rawAuditEnabled = mode == WishlistMode.GENERAL;
            web = BackgroundDomWebView.create(parent.getContext());
            // Only GU and Mercari: their client-rendered item state may never
            // hydrate in a detached WebView. Place an untouchable renderer
            // BEHIND the Wish page, as already done for marketplace price.
            // No other GENERAL site's WebView is changed.
            final WishlistGeneralShopDedicatedMode dedicatedShop =
                    mode == WishlistMode.GENERAL
                    ? WishlistGeneralShopDedicatedMode.forUrl(url)
                    : WishlistGeneralShopDedicatedMode.NONE;
            if (dedicatedShop != WishlistGeneralShopDedicatedMode.NONE) {
                web.setWillNotDraw(false);
                parent.addView(web, 0, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                trace("shop.renderer", "merchant="+dedicatedShop
                        +" attachedBehindPage=true readOnly=true");
            }

            web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setClickable(false);
            web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.setVerticalScrollBarEnabled(false);
            web.setHorizontalScrollBarEnabled(false);

            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            if (rawAuditEnabled) web.setWebChromeClient(new WebChromeClient() {
                @Override public boolean onConsoleMessage(ConsoleMessage message) {
                    if (!finished && message != null && webErrorSamples < 3
                            && message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                        webErrorSamples++;
                        String detail = message.message() == null ? "" : message.message();
                        // Console content can contain secrets; log category only.
                        String category = detail.matches("(?is).*\\b(TypeError|ReferenceError)\\b.*")
                                ? "runtime-type-or-reference"
                                : detail.matches("(?is).*(CSP|Content Security Policy|Refused to).*")
                                ? "csp" : detail.matches("(?is).*(CORS|cross.origin).*")
                                ? "cors" : "other-js-error";
                        trace("dom.audit.console", "category="+category
                                +" line="+Math.max(0,message.lineNumber()));
                    }
                    return false;
                }
            });
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return request.isForMainFrame() && !allowed(request.getUrl().toString());
                }
                @Override public void onPageStarted(WebView view, String loaded, android.graphics.Bitmap icon) {
                    if (finished || !allowed(loaded)) return;
                    // GENERAL can inspect a partially hydrated product before
                    // third-party trackers keep onPageFinished from arriving.
                    if (mode == WishlistMode.GENERAL || mode == WishlistMode.MUJI)
                        main.postDelayed(() -> inspect(view), 2100L);
                    if ("e-mono.jr-central.co.jp".equals(originHost))
                        trace("jr.page.started", "sameSku=true");
                    if (mode != WishlistMode.GENERAL && (
                            "e-mono.jr-central.co.jp".equals(originHost)
                            || "eshop.fumuroya.com".equals(originHost)
                            || "www.hiraki.co.jp".equals(originHost)
                            || "hiraki.co.jp".equals(originHost)))
                        main.postDelayed(() -> inspect(view), 2100L);
                }
                @Override public void onPageFinished(WebView view, String loaded) {
                    if (finished || !allowed(loaded)) return;
                    if ("askul.co.jp".equals(originHost) || "www.askul.co.jp".equals(originHost))
                        trace("page.finished", "sameSku=true");
                    if ("e-mono.jr-central.co.jp".equals(originHost))
                        trace("jr.page.finished", "sameSku=true");
                    if (rawAuditEnabled && !isDetailedAuditShop()) {
                        // Inspect GENERIC shops before their classifier completes.
                        main.postDelayed(() -> auditRawDom(view,"page-finished"), 150L);
                    }
                    main.postDelayed(() -> inspect(view), 1200L);
                }
                @Override public void onReceivedHttpError(WebView view, WebResourceRequest req,
                                                         android.webkit.WebResourceResponse response) {
                    if (rawAuditEnabled && webErrorSamples < 3 && response.getStatusCode() >= 400) {
                        webErrorSamples++;
                        trace("dom.audit.http", "scope="+(req.isForMainFrame()?"main":"subresource")
                                +" code="+response.getStatusCode());
                    }
                    // A genuine upstream 5xx main-document failure is not a
                    // product page. Never parse a tiny maintenance/error page
                    // as stock; subresource failures do not trigger this rule.
                    if (req.isForMainFrame() && mode == WishlistMode.GENERAL
                            && response.getStatusCode() >= 500) {
                        mainFrameHttpFailure = response.getStatusCode();
                        trace("dom.audit.skip", "reason=main-http-5xx code="+mainFrameHttpFailure);
                        finish("UNKNOWN");
                        return;
                    }
                    if (req.isForMainFrame() && ("askul.co.jp".equals(originHost)
                            || "www.askul.co.jp".equals(originHost)))
                        trace("http", "code="+response.getStatusCode());
                }
                @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    if (rawAuditEnabled && webErrorSamples < 3) {
                        webErrorSamples++;
                        trace("dom.audit.network", "scope="+(request.isForMainFrame()?"main":"subresource")
                                +" code="+error.getErrorCode());
                    }
                    if (request.isForMainFrame()) finish("UNKNOWN");
                }
            });
            boolean askul = "askul.co.jp".equals(originHost) || "www.askul.co.jp".equals(originHost);
            if (mode == WishlistMode.GENERAL) {
                trace("phase", "phase=mode budgetMs=15000 next=page-budgetMs-15000");
                main.postDelayed(modeWindowTimeout, 15000L);
            } else main.postDelayed(timeout, askul ? 19000L :
                    mode == WishlistMode.MUJI ? 16500L : 13000L);
            web.loadUrl(url.toString());
            if (rawAuditEnabled) {
                // Targeted difficult shops retain their proven early/settled
                // checkpoints; other GENERAL shops take a bounded early sample.
                final WebView auditWeb = web;
                if (isDetailedAuditShop()) {
                    main.postDelayed(() -> auditRawDom(auditWeb, "early"), 3100L);
                    main.postDelayed(() -> auditRawDom(auditWeb, "settled"), 5200L);
                } else {
                    main.postDelayed(() -> auditRawDom(auditWeb, "general"), 2400L);
                }
            }
            if (askul) {
                final WebView skuProbeView = web;
                main.postDelayed(() -> inspect(skuProbeView), 2400L);
            } else if ("www.hiraki.co.jp".equals(originHost)
                    || "hiraki.co.jp".equals(originHost)) {
                // Do not wait indefinitely for third-party scripts to finish.
                // Existing retries still verify the exact product/variant.
                final WebView hirakiProbe = web;
                main.postDelayed(() -> inspect(hirakiProbe), 6000L);
            } else if ("e-mono.jr-central.co.jp".equals(originHost)) {
                // JR pages can keep loading third-party scripts indefinitely.
                // Probe the verified product DOM without waiting for pageFinished.
                final WebView jrProbeView = web;
                main.postDelayed(() -> inspect(jrProbeView), 4200L);
                main.postDelayed(() -> inspect(jrProbeView), 8400L);
            }
        } catch (Exception ignored) { finish("UNKNOWN"); }
    }

    /** Two bounded snapshots of the actual DOM, independent of purchase filters.
     * No purchases, input values, raw document HTML, full text or URLs are read
     * into the card log. Unknown readiness will be recorded, not miscalled absent.
     */
    private boolean isDetailedAuditShop() {
        return "www.askul.co.jp".equals(originHost) || "askul.co.jp".equals(originHost)
                || "www.hiraki.co.jp".equals(originHost) || "hiraki.co.jp".equals(originHost)
                || "e-mono.jr-central.co.jp".equals(originHost);
    }

    private void auditRawDom(WebView current, String phase) {
        if (!rawAuditEnabled || finished || current != web || rawAuditSamples >= 2 || auditPending) return;
        if (!allowed(current.getUrl())) {
            trace("dom.audit.skip", "phase="+phase+" reason=unverified-product-url");
            return;
        }
        rawAuditSamples++;
        auditPending = true;
        try {
            current.evaluateJavascript(WishlistRawPurchaseDomAudit.javascript(), result -> {
                if (finished || current != web) return;
                auditPending = false;
                try {
                    Object unwrapped = new org.json.JSONTokener(result == null ? "null" : result).nextValue();
                    if (!(unwrapped instanceof String)) {
                        trace("dom.audit.failure", "phase="+phase+" result=not-string"); return;
                    }
                    org.json.JSONObject o = new org.json.JSONObject((String) unwrapped);
                    auditReceived = true;
                    trace("dom.audit.summary", "phase="+phase
                            +" ready="+o.optString("ready","unknown")
                            +" bodyChars="+o.optInt("bodyChars",0)
                            +" cartText="+o.optBoolean("cartText",false)
                            +" controls="+o.optInt("controls",0)
                            +" buttons="+o.optInt("buttons",0)
                            +" qty="+o.optInt("quantities",0)
                            +" named="+o.optInt("cartNamed",0)
                            +" enabledNamed="+o.optInt("enabledNamed",0)
                            +" frames="+o.optInt("frames",0)
                            +" readable="+o.optInt("readable",0)
                            +" blocked="+o.optInt("unreadable",0)
                            +" shadows="+o.optInt("shadows",0)
                            +" limited="+o.optBoolean("limit",false)
                            +" error="+o.optString("error","none"));
                    org.json.JSONArray samples = o.optJSONArray("samples");
                    if (samples != null) for (int i=0;i<Math.min(samples.length(),5);i++) {
                        org.json.JSONObject c = samples.optJSONObject(i);
                        if (c == null) continue;
                        auditElements++;
                        if (c.optBoolean("product",false) && "enabled".equals(c.optString("state"))
                                && !"none".equals(c.optString("label","none"))) {
                            auditProductCartEnabled = true;
                        }
                        if ("purchase".equals(c.optString("label","none"))) auditPurchaseNamed = true;
                        trace("dom.audit.element", "phase="+phase+" n="+(i+1)
                                +" scope="+c.optString("scope","-")
                                +" tag="+c.optString("tag","-")
                                +" id="+c.optString("id","-")
                                +" cls="+c.optString("cls","-")
                                +" attrs="+c.optString("attrs","-")
                                +" label="+c.optString("label","none")
                                +" state="+c.optString("state","unknown")
                                +" nearQty="+c.optBoolean("nearQty",false)
                                +" product="+c.optBoolean("product",false)
                                +" onclick="+c.optBoolean("onclick",false));
                    }
                } catch (Exception ignored) {
                    trace("dom.audit.failure", "phase="+phase+" reason=invalid-json");
                }
            });
        } catch (Exception ignored) {
            auditPending = false;
            trace("dom.audit.failure", "phase="+phase+" reason=javascript-not-evaluated");
        }
    }

    private URL safeOriginalUrl() {
        try { return new URL("https://" + originHost + originPath); }
        catch (Exception ignored) { return null; }
    }

    private URL originalAlphabetUrl() {
        try {
            return new URL("https://" + originHost + originPath
                    + (originalQuery == null ? "" : "?" + originalQuery));
        } catch (Exception ignored) { return null; }
    }

    private boolean allowed(String urlText) {
        try {
            URL url = new URL(urlText);
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) return false;
            String host = url.getHost().toLowerCase(Locale.ROOT);
            if (originHost == null || originPath == null) return false;
            // A redirect to the store home or another product cannot prove the
            // original item's stock, even if the destination has a cart button.
            if (expectedMarketplace != null) return expectedMarketplace.matches(url);
            // ZOZO's goods and goods-sale routes (with or without /shop/) are
            // aliases ONLY if the exact numerical goods ID and requested ?did
            // survive. Never allow a redirect to a listing or another shop SKU.
            // Isolated to ZOZO: Joshin and every other host retain old guards.
            URL saved = originalAlphabetUrl();
            if (mode == WishlistMode.GENERAL
                    && WishlistRetailDedicatedMode.forUrl(saved) == WishlistRetailDedicatedMode.ZOZO
                    && WishlistRetailDedicatedMode.isZozoHost(url)) {
                String expectedGoods = WishlistRetailDedicatedMode.zozoGoodsId(saved);
                String loadedGoods = WishlistRetailDedicatedMode.zozoGoodsId(url);
                String savedShop = WishlistRetailDedicatedMode.zozoShopId(saved);
                String loadedShop = WishlistRetailDedicatedMode.zozoShopId(url);
                String savedDid = WishlistRetailDedicatedMode.query(saved, "did");
                return expectedGoods != null && expectedGoods.equals(loadedGoods)
                        && (savedShop == null || loadedShop == null || savedShop.equals(loadedShop))
                        && (savedDid.isEmpty() || savedDid.equals(WishlistRetailDedicatedMode.query(url,"did")));
            }
            if (WishlistHonmaProductDom.isDetail(saved))
                return WishlistHonmaProductDom.sameItem(saved, url);
            if (!url.getPath().equalsIgnoreCase(originPath)) return false;
            // A GENERAL product can be identified only in the query string
            // (Color Me, CS-Cart, 久世福). Never trust another item's cart.
            for (String key : new String[]{"product_id", "pid", "eci_product", "p_cd", "sku"}) {
                String expected = productQueryValue(originalQuery, key);
                if (expected != null && !expected.equalsIgnoreCase(productQueryValue(url.getQuery(), key)))
                    return false;
            }
            if (originHost.equals("amazon.co.jp") || originHost.endsWith(".amazon.co.jp"))
                return host.equals("amazon.co.jp") || host.endsWith(".amazon.co.jp");
            if (mode == WishlistMode.GENERAL && WishlistGeneralShopItem.isDetail(originalAlphabetUrl()))
                return WishlistGeneralShopItem.sameProduct(originalAlphabetUrl(),url);
            return host.equals(originHost);
        } catch (Exception ignored) { return false; }
    }

    private static String productQueryValue(String query, String key) {
        if (query == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                "(?i)(?:^|&)" + java.util.regex.Pattern.quote(key) + "=([a-z0-9_-]+)(?:&|$)")
                .matcher(query);
        return m.find() ? m.group(1) : null;
    }

    private void beginPageInspection(String reason) {
        if (finished || mode != WishlistMode.GENERAL || pageInspectionStarted) return;
        pageInspectionStarted=true;
        generalFirstDone=true;
        generalInspectionPending=false;
        generalInspectionRounds=0;
        specialRetries=0;
        main.removeCallbacks(modeWindowTimeout);
        trace("phase", "phase=page reason="+reason+" budgetMs=15000 independent=true");
        main.postDelayed(pageWindowTimeout,15000L);
        final WebView current=web;
        if (current!=null) main.post(() -> inspect(current));
    }

    private void inspect(WebView current) {
        if (finished || current != web || generalInspectionPending || nativeInspectionPending
                || mainFrameHttpFailure >= 500) return;
        if (!allowed(current.getUrl())) {
            if ("e-mono.jr-central.co.jp".equals(originHost))
                trace("jr.skip", "reason=main-document-unverified");
            return;
        }
        // General mode 000+ is bounded by its OWN 15 seconds. GU/Mercari
        // dedicated inspectors then get a NEW 15 seconds independent of 000+.
        // One GENERAL 000+ sweep BEFORE other merchant/site-specific adapters,
        // on the same URL-verified WebView. Even a positive A result does not
        // bypass later stages or the dedicated proof. Marketplace/MUJI results
        // are observational only and cannot be promoted into stock availability.
        if (mode == WishlistMode.GENERAL && !pageInspectionStarted) {
            inspectNumberedFirst(current);
            return;
        }
        // Independent, conservative rendered-DOM adapter for verified single-item
        // pages. No click/navigation is performed, and no unrelated data is read.
        String store = originHost == null ? "" : originHost;
        if (mode == WishlistMode.MUJI && (store.equals("muji.com") || store.equals("www.muji.com"))) {
            publishMode("無印良品固有モード");
            inspectMuji(current);
            return;
        }
        // Honma's product route uses an internal item id; the printed product
        // code is different. No generic alphabet cart verdict may certify it.
        if (mode == WishlistMode.GENERAL
                && WishlistHonmaProductDom.isDetail(originalAlphabetUrl())) {
            inspectHonma(current);
            return;
        }
        // Premium Bandai: an enabled, item-local "予約する" is a purchase action,
        // but a site-wide cart or expired reservation cannot certify stock.
        if (mode == WishlistMode.GENERAL
                && WishlistPremiumBandaiStockDom.supports(originalAlphabetUrl())) {
            inspectPremiumBandai(current);
            return;
        }
        // Four site-specific, read-only proof sources. Run only AFTER 000+ and
        // never upgrade from a generic cart button / unrelated product tile.
        if (mode == WishlistMode.GENERAL
                && WishlistGeneralShopStockDom.supports(originalAlphabetUrl())) {
            inspectGeneralShop(current);
            return;
        }
        // Merchant-specific submode AFTER the one-time GENERAL 000+ sweep.
        // The saved acquisitionMode is never changed.
        if (mode == WishlistMode.GENERAL
                && WishlistRetailDedicatedMode.forUrl(originalAlphabetUrl())
                    != WishlistRetailDedicatedMode.NONE) {
            inspectDedicated(current);
            return;
        }
        if (store.equals("hiraki.co.jp") || store.equals("www.hiraki.co.jp")) {
            publishMode("ヒラキ固有モード");
            String sku = originPath.replaceAll("/+$", "").replaceAll(".*/", "");
            current.evaluateJavascript(HirakiStockDom.stockEvidence(sku), value -> {
                if (finished) return;
                String status="UNKNOWN", reason="unreadable", flags="";
                try {
                    Object raw = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    org.json.JSONObject obj = new org.json.JSONObject((String) raw);
                    status=obj.optString("status", "UNKNOWN");
                    reason=obj.optString("reason", "unreadable");
                    flags=" skuMatch="+obj.optBoolean("skuMatch",false)
                            +" color99="+obj.optBoolean("color99",false)
                            +" table="+obj.optInt("tableFound",0)
                            +" row="+obj.optInt("rowFound",0)
                            +" qty="+obj.optInt("qtyEnabled",0)
                            +" cart="+obj.optInt("cartEnabled",0)
                            +" cartAction="+obj.optInt("cartAction",0)
                            +" cartTextHint="+obj.optInt("cartTextHint",0)
                            +" icon="+obj.optInt("stockIcon",0)
                            +" forms="+obj.optInt("forms",0)
                            +" cartForms="+obj.optInt("cartForms",0)
                            +" boundForms="+obj.optInt("skuBoundForms",0)
                            +" imageControls="+obj.optInt("imageControls",0)
                            +" attrHints="+obj.optInt("cartAttributeHints",0)
                            +" shared="+obj.optInt("sharedCarts",0)
                            +" sharedReady="+obj.optInt("sharedEnabled",0)
                            +" sharedLinked="+obj.optInt("sharedLinked",0)
                            +" sharedOutside="+obj.optInt("sharedOutside",0)
                            +" nearest="+obj.optInt("sharedNearest",-1)
                            +" live="+obj.optInt("liveCartFound",0)
                            +" liveEnabled="+obj.optInt("liveCartEnabled",0)
                            +" actualHidden="+obj.optInt("actualCartHidden",0)
                            +" actualDisabled="+obj.optInt("actualCartDisabled",0)
                            +" actualSubmit="+obj.optInt("actualCartSubmit",0)
                            +" actualLive="+obj.optInt("actualCartSubmitLive",0)
                            +" actualLinked="+obj.optInt("actualCartLinked",0)
                            +" pos="+obj.optInt("stockPositive",0)
                            +" neg="+obj.optInt("stockNegative",0);
                } catch (Exception ignored) { }
                String evidence="attempt="+(specialRetries+1)+" status="+status
                        +" reason="+reason+flags;
                trace("hiraki.evidence",evidence);
                RetailDiagnostics.hiraki("webview.stock",evidence);
                if ("AVAILABLE".equals(status)) { finishDedicated("AVAILABLE"); return; }
                if ("UNAVAILABLE".equals(status)) { finishDedicated("UNAVAILABLE"); return; }
                // Retry after a dynamic stock row is hydrated. Do not infer
                // availability from the separate five-symbol legend.
                if (++specialRetries < 5) main.postDelayed(() -> inspect(current), 1450L);
                else finish("UNKNOWN");
            });
            return;
        }
        if (GeneralRetailIdentity.storeFromText("https://"+store+originPath)) {
            String sku = GeneralRetailIdentity.itemId(safeOriginalUrl());
            if (sku == null) { finish("UNKNOWN"); return; }
            if ("ASKUL".equals(GeneralRetailIdentity.store(safeOriginalUrl()))) {
                publishMode("ASKUL固有モード");
                current.evaluateJavascript(AskulProductDom.stockEvidence(sku), value -> {
                    if (finished) return;
                    String status = "UNKNOWN", evidence = "unreadable-result";
                    try {
                        Object raw = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                        org.json.JSONObject obj = new org.json.JSONObject((String) raw);
                        status = obj.optString("status", "UNKNOWN");
                        evidence = "skuMatch=" + obj.optBoolean("skuLabel",false)
                                + " stockFound=" + obj.optBoolean("stockFound",false)
                                + " cartFound=" + obj.optInt("cartFound",0)
                                + " cartEnabled=" + obj.optInt("cartEnabled",0)
                                + " cartDisabled=" + obj.optInt("cartDisabled",0)
                                + " restricted=" + obj.optBoolean("restricted",false)
                                + " controls=" + obj.optInt("domControls",0)
                                + " cartHint=" + obj.optBoolean("cartTextHint",false)
                                + " stockHint=" + obj.optBoolean("stockTextHint",false)
                                + " iframes=" + obj.optInt("iframes",0)
                                + " productArea=" + obj.optBoolean("productArea",false)
                                + " structured=" + obj.optBoolean("structuredProduct",false)
                                + " structuredOffer=" + obj.optBoolean("structuredOffer",false)
                                + " skuFrame=" + obj.optInt("skuFrames",0)
                                + " frameCart=" + obj.optInt("frameCart",0)
                                + " frameStock=" + obj.optInt("frameStock",0)
                                + " framesReadable=" + obj.optInt("accessibleFrames",0)
                                + " scopeCut=" + obj.optBoolean("scopeCut",false)
                                + " scopeBefore=" + obj.optBoolean("scopeBefore",false)
                                + " scopeAfter=" + obj.optBoolean("scopeAfter",false)
                                + " scopeChars=" + obj.optInt("scopeChars",0)
                                + " shared=" + obj.optInt("sharedCarts",0)
                                + " sharedReady=" + obj.optInt("sharedEnabled",0)
                                + " modal=" + obj.optInt("modalCartCandidates",0)
                                + " modalEnabled=" + obj.optInt("modalCartEnabled",0)
                                + " modalPurchase=" + obj.optInt("modalPurchaseNamed",0)
                                + " live=" + obj.optInt("liveCarts",0)
                                + " liveEnabled=" + obj.optInt("liveEnabled",0)
                                + " sharedOutside=" + obj.optInt("sharedOutside",0)
                                + " stockPositive=" + obj.optBoolean("localStockPositive",false)
                                + " stockNegative=" + obj.optBoolean("localStockNegative",false)
                                + " stockPosition=" + obj.optString("stockPosition","none")
                                + " reason=" + obj.optString("reason","unknown");
                        trace("askul.product.scope", "attempt=" + (specialRetries+1)
                                + " stockLabel=" + obj.optBoolean("productStockLabel",false)
                                + " conflict=" + obj.optBoolean("productStockConflict",false)
                                + " distance=" + obj.optInt("productStockDistance",-1)
                                + " cartCaption=" + obj.optBoolean("productPurchaseText",false)
                                + " quantity=" + obj.optBoolean("productQuantity",false)
                                + " windowChars=" + obj.optInt("productTextWindowChars",0)
                                + " windowReason=" + obj.optString("productWindowReason","none")
                                + " headingChars=" + obj.optInt("productHeadingChars",0)
                                + " markerPos=" + obj.optInt("productMarkerPos",-1)
                                + " nextSkuCut=" + obj.optBoolean("productNextSkuCut",false)
                                + " windowStock=" + obj.optBoolean("productWindowStock",false)
                                + " windowNegative=" + obj.optBoolean("productWindowNegative",false)
                                + " windowCart=" + obj.optBoolean("productWindowPurchase",false)
                                + " windowQty=" + obj.optBoolean("productWindowQuantity",false)
                                + " windowQtyControls=" + obj.optInt("productWindowQuantityControls",0)
                                + " modalStock=" + obj.optInt("modalTargetStock",0)
                                + " modalReady=" + obj.optInt("modalProductReady",0)
                                + " modalCart=" + obj.optInt("modalTargetCart",0)
                                + " modalOther=" + obj.optInt("modalTargetOther",0)
                                + " decision=" + obj.optString("reason","unknown"));
                    } catch (Exception ignored) { }
                    trace("evidence", "attempt=" + (specialRetries+1) + " " + evidence);
                    if ("AVAILABLE".equals(status)) { finishDedicated("AVAILABLE"); return; }
                    if ("UNAVAILABLE".equals(status)) { finishDedicated("UNAVAILABLE"); return; }
                    if (++specialRetries < 7) main.postDelayed(() -> inspect(current), 1700L);
                    else finish("UNKNOWN");
                });
                return;
            }
            publishMode("商品固有モード");
            current.evaluateJavascript(GeneralRetailStockDom.javascript(store, sku), value -> {
                if (finished) return;
                RetailDiagnostics.general(safeOriginalUrl(), "webview.stock",
                        "attempt="+(specialRetries+1)+" state="+value);
                if ("askul.co.jp".equals(originHost) || "www.askul.co.jp".equals(originHost))
                    trace("dom", "attempt="+(specialRetries+1)+" state="+value);
                if ("\"AVAILABLE\"".equals(value)) { finishDedicated("AVAILABLE"); return; }
                if ("\"UNAVAILABLE\"".equals(value)) { finishDedicated("UNAVAILABLE"); return; }
                if (++specialRetries < 4) main.postDelayed(() -> inspect(current), 1200L);
                else finish("UNKNOWN");
            });
            return;
        }
        if (store.equals("eshop.fumuroya.com") || store.equals("e-mono.jr-central.co.jp")) {
            publishMode(store.equals("e-mono.jr-central.co.jp")
                    ? "JR東海固有モード" : "不室屋固有モード");
            nativeInspectionPending = true;
            current.evaluateJavascript(WishlistIndependentStockDom.javascript(store), value -> {
                nativeInspectionPending = false;
                if (finished || current != web) return;
                String status="UNKNOWN", reason="unreadable", flags="";
                try {
                    Object raw=new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    org.json.JSONObject o=new org.json.JSONObject((String)raw);
                    status=o.optString("status","UNKNOWN");
                    reason=o.optString("reason","unreadable");
                    flags=" title="+o.optBoolean("title",false)
                            +" titleSource="+o.optString("titleSource","none")
                            +" headings="+o.optInt("headings",0)
                            +" variantSource="+o.optString("variantSource","none")
                            +" controls="+o.optInt("controls",0)
                            +" imageControls="+o.optInt("imageControls",0)
                            +" actionHints="+o.optInt("actionHints",0)
                            +" shared="+o.optInt("sharedCarts",0)
                            +" sharedReady="+o.optInt("sharedEnabled",0)
                            +" sharedLinked="+o.optInt("sharedLinked",0)
                            +" sharedOutside="+o.optInt("sharedOutside",0)
                            +" nearest="+o.optInt("sharedNearest",-1)
                            +" live="+o.optInt("liveCartFound",0)
                            +" liveEnabled="+o.optInt("liveCartEnabled",0)
                            +" imageCart="+o.optInt("verifiedImageCart",0)
                            +" imageEnabled="+o.optInt("verifiedImageEnabled",0)
                            +" qty="+o.optInt("qty",0)
                            +" cart="+o.optInt("cart",0)
                            +" enabled="+o.optInt("enabled",0)
                            +" negative="+o.optInt("negative",0)
                            +" selected="+o.optBoolean("selected",false);
                }catch(Exception ignored) { }
                trace(store.equals("eshop.fumuroya.com")?"fumuroya.evidence":"jr.evidence",
                        "attempt="+(specialRetries+1)+" status="+status+" reason="+reason+flags);
                if ("AVAILABLE".equals(status)) {finishDedicated("AVAILABLE");return;}
                if ("UNAVAILABLE".equals(status)) {finishDedicated("UNAVAILABLE");return;}
                // Missing body is an incomplete load, not five failed item checks.
                // The existing absolute WebView deadline still bounds retries.
                if ("body-missing".equals(reason)) {
                    pendingBodyObservations++;
                    trace("native.wait", "reason=body-missing observations="+pendingBodyObservations);
                    main.postDelayed(()->inspect(current),900L);
                } else if (++specialRetries < 5)
                    main.postDelayed(()->inspect(current),1350L);
                else finish("UNKNOWN");
            });
            return;
        }
        if (store.equals("yuican-shop.com")) {
            publishMode("ゆいかん固有モード");
            current.evaluateJavascript(WishlistRemainingStockDom.javascript(store), value -> {
                if(finished)return;
                if("\"AVAILABLE\"".equals(value)){finishDedicated("AVAILABLE");return;}
                if(++specialRetries<5)main.postDelayed(()->inspect(current),1350);
                else finish("UNKNOWN");
            });
            return;
        }
        if (store.equals("nakasima-inc.shop")
                || store.equals("www.torikan.net") || store.equals("torikan.net")) {
            publishMode("店舗固有モード");
            current.evaluateJavascript(shopPurchaseJavascript(store), value -> {
                if(finished)return;
                if("\"AVAILABLE\"".equals(value)){finishDedicated("AVAILABLE");return;}
                // Fumuroya hydrates dynamic purchase controls after page load.
                // Repeat only in this store; other successful site modes unchanged.
                if(store.equals("eshop.fumuroya.com") && ++specialRetries<5)
                    main.postDelayed(()->inspect(current),1350);
                else finish("UNKNOWN");
            });
            return;
        }
        if (expectedMarketplace != null) {
            publishMode(mode == null ? "サイト固有モード" : mode.name()+"固有モード");
            String siteJs= expectedMarketplace.site==MarketplaceIdentity.Site.AMAZON ? AmazonDomSelectors.stock(expectedMarketplace.id)
                    : expectedMarketplace.site==MarketplaceIdentity.Site.RAKUTEN ? RakutenDomSelectors.stock()
                    : expectedMarketplace.site==MarketplaceIdentity.Site.YAHOO ? YahooDomSelectors.stock() : null;
            if(siteJs==null){finish("UNKNOWN");return;}
            current.evaluateJavascript(siteJs,v->finishDedicated("\"AVAILABLE\"".equals(v) ? "AVAILABLE" : "UNKNOWN"));
            return;
        }
        // All numbered techniques are evaluated in the same verified document
        // on every generic retry, without a standalone unverified cart shortcut.
        inspectNumbered(current,false);
    }

    private void inspectPremiumBandai(WebView current) {
        if (finished || current != web || generalInspectionPending || !allowed(current.getUrl())) return;
        final URL original=originalAlphabetUrl();
        generalInspectionPending=true;
        publishMode("プレミアムバンダイ予約モード");
        try {
            current.evaluateJavascript(WishlistPremiumBandaiStockDom.javascript(original), value -> {
                generalInspectionPending=false;
                if (finished || current!=web) return;
                String status="UNKNOWN",reason="unreadable";
                boolean bound=false;
                int candidate=0, enabled=0;
                try {
                    Object raw=new org.json.JSONTokener(value==null?"null":value).nextValue();
                    if(raw instanceof String){
                        org.json.JSONObject o=new org.json.JSONObject((String)raw);
                        status=o.optString("status","UNKNOWN");
                        reason=o.optString("reason","unreadable");
                        bound=o.optBoolean("bound",false);
                        candidate=o.optInt("candidates",0);
                        enabled=o.optInt("enabled",0);
                    }
                } catch(Exception ignored) { }
                if(!reason.matches("[a-z0-9-]{1,56}"))reason="invalid";
                trace("bandai.reservation", "attempt="+(specialRetries+1)
                        +" id="+bound+" action=reserve candidates="+candidate
                        +" enabled="+enabled+" status="+status+" reason="+reason);
                if(bound && "AVAILABLE".equals(status)) {finishDedicated("AVAILABLE");return;}
                if(++specialRetries<4)main.postDelayed(()->inspect(current),1050L);
                else finish("UNKNOWN");
            });
        } catch(Exception ignored) {
            generalInspectionPending=false;
            if(++specialRetries<4)main.postDelayed(()->inspect(current),1050L);
            else finish("UNKNOWN");
        }
    }

    /** A shop's stricter SKU/size handler must not be replaced by a generic
     * cart-button guess. Only G's explicit ID+variant+local-stock proof may
     * rescue a specialist UNKNOWN result. */
    private boolean hasDedicatedStockInspector() {
        if (mode != WishlistMode.GENERAL) return true;
        URL original=originalAlphabetUrl();
        if (WishlistHonmaProductDom.isDetail(original)) return true;
        if (WishlistPremiumBandaiStockDom.supports(original)) return true;
        if (WishlistGeneralShopItem.isDetail(original)) return true;
        if (WishlistRetailDedicatedMode.forUrl(original)
                != WishlistRetailDedicatedMode.NONE) return true;
        if (originHost == null) return false;
        if (GeneralRetailIdentity.storeFromText("https://"+originHost+originPath)) return true;
        switch (originHost) {
            case "hiraki.co.jp": case "www.hiraki.co.jp":
            case "eshop.fumuroya.com": case "e-mono.jr-central.co.jp":
            case "yuican-shop.com": case "nakasima-inc.shop":
            case "www.torikan.net": case "torikan.net": return true;
            default: return expectedMarketplace != null;
        }
    }

    /** Every numbered technique executes in one read-only WebView snapshot.
     * Preserve dedicated merchant verification as a separate 15-second phase. */
    private void inspectNumberedFirst(WebView current) {
        inspectNumbered(current, true);
    }

    private void inspectHonma(WebView current) {
        if (finished || current != web || generalInspectionPending || !allowed(current.getUrl())) return;
        generalInspectionPending = true;
        publishMode("本間商店固有モード");
        try {
            current.evaluateJavascript(WishlistHonmaProductDom.stockJavascript(originalAlphabetUrl()), value -> {
                generalInspectionPending = false;
                if (finished || current != web) return;
                String status="UNKNOWN", reason="unreadable";
                boolean same=false;
                int qty=0, cart=0, positive=0, negative=0;
                String hints="";
                try {
                    Object raw=new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    if (raw instanceof String) {
                        org.json.JSONObject o=new org.json.JSONObject((String)raw);
                        status=o.optString("status","UNKNOWN");
                        reason=o.optString("reason","unreadable");
                        same=o.optBoolean("sameItem",false);
                        qty=o.optInt("qty",0);cart=o.optInt("cart",0);
                        positive=o.optInt("positive",0);negative=o.optInt("negative",0);
                        hints=" bodyChars="+o.optInt("bodyChars",0)
                                +" codeHint="+o.optBoolean("codeHint",false)
                                +" netHint="+o.optBoolean("netHint",false)
                                +" grossHint="+o.optBoolean("grossHint",false)
                                +" detailHint="+o.optBoolean("detailHint",false);
                    }
                } catch (Exception ignored) { }
                trace("honma.evidence","attempt="+(specialRetries+1)+" status="+status
                        +" reason="+(reason.matches("[a-z-]{1,50}")?reason:"invalid")
                        +" id="+same+" qty="+qty+" cart="+cart
                        +" positive="+positive+" negative="+negative+hints);
                if (same && positive>0 && negative==0 && "AVAILABLE".equals(status)) {
                    finishDedicated("AVAILABLE");return;
                }
                if (++specialRetries < 4) main.postDelayed(() -> inspect(current), 1200L);
                else finish("UNKNOWN");
            });
        } catch (Exception ignored) {
            generalInspectionPending = false;
            finish("UNKNOWN");
        }
    }

    /** The one-item DOM must prove the inventory of exactly this saved route.
     * A missing/ambiguous value stays UNKNOWN; no other site uses this adapter. */
    private void inspectGeneralShop(WebView current) {
        if (finished || current != web || generalInspectionPending || !allowed(current.getUrl())) return;
        final URL original=originalAlphabetUrl();
        if (!WishlistGeneralShopStockDom.supports(original)) {finish("UNKNOWN");return;}
        generalInspectionPending=true;
        WishlistGeneralShopDedicatedMode dedicatedShop=WishlistGeneralShopDedicatedMode.forUrl(original);
        publishMode(dedicatedShop == WishlistGeneralShopDedicatedMode.NONE
                ? WishlistGeneralShopItem.merchant(original).name()+"固有モード"
                : dedicatedShop.liveLabel());
        try {
            // Mercari's current listing page frequently renders no H1 at all.
            // Independently inspect embedded exact-item state rather than
            // rereading the same empty generic product-card selectors five times.
            final boolean mercariState = WishlistGeneralShopItem.merchant(original)
                    == WishlistGeneralShopItem.Merchant.MERCARI;
            final String inspectorScript = mercariState
                    ? WishlistMercariItemStockDom.javascript(original)
                    : dedicatedShop == WishlistGeneralShopDedicatedMode.GU
                    ? WishlistGuVariantStockDom.javascript(original)
                    : WishlistGeneralShopStockDom.javascript(original);
            current.evaluateJavascript(inspectorScript, value -> {
                generalInspectionPending=false;
                if (finished || current!=web) return;
                String status="UNKNOWN",reason="unreadable";
                boolean bound=false;
                int carts=0,disabled=0,headings=0;
                boolean price=false,negative=false,variant=false;
                boolean guColorSelected=false,guSizeSelected=false;
                int guColorCandidates=0,guSizeCandidates=0,guSelected=0;
                String guVariantEvidence="none";
                try {
                    Object raw=new org.json.JSONTokener(value==null?"null":value).nextValue();
                    if (raw instanceof String) {
                        org.json.JSONObject o=new org.json.JSONObject((String)raw);
                        status=o.optString("status","UNKNOWN");reason=o.optString("reason","unreadable");
                        bound=o.optBoolean("bound",false);
                        carts=o.optInt("heroCarts",0);disabled=o.optInt("heroDisabled",0);
                        headings=o.optInt("heading",0);price=o.optBoolean("heroPrice",false);
                        negative=o.optBoolean("heroSold",false);variant=o.optBoolean("variants",false);
                        if (dedicatedShop == WishlistGeneralShopDedicatedMode.GU) {
                            guColorSelected=o.optBoolean("colorSelected",false);
                            guSizeSelected=o.optBoolean("sizeSelected",false);
                            guColorCandidates=o.optInt("colorCandidates",0);
                            guSizeCandidates=o.optInt("sizeCandidates",0);
                            guSelected=o.optInt("selectedControls",0);
                            guVariantEvidence=o.optString("variantEvidence","none");
                        }
                    }
                }catch(Exception ignored) { }
                if (!reason.matches("[a-z0-9-]{1,56}")) reason="unreadable";
                trace("shop.item", "merchant="+WishlistGeneralShopItem.merchant(original)
                        +" reason="+reason+" status="+status+" id="+bound
                        +" headings="+headings+" cart="+carts+" disabled="+disabled
                        +" price="+price+" negative="+negative+" variant="+variant
                        +(dedicatedShop == WishlistGeneralShopDedicatedMode.GU
                                ? " selectedColor="+guColorSelected+" selectedSize="+guSizeSelected
                                    +" colorCandidates="+guColorCandidates+" sizeCandidates="+guSizeCandidates
                                    +" selectedControls="+guSelected+" variantEvidence="+guVariantEvidence : "")
                        +" attempt="+(++specialRetries));
                if (bound && headings==1 && ("AVAILABLE".equals(status)||"UNAVAILABLE".equals(status))) {
                    finish(status);return;
                }
                if (specialRetries < 5) main.postDelayed(() -> inspect(current),1150L);
                else finish("UNKNOWN");
            });
        } catch(Exception ignored) {
            generalInspectionPending=false;
            trace("shop.item", "reason=script-error");
            if (++specialRetries < 5) main.postDelayed(() -> inspect(current),1150L);
            else finish("UNKNOWN");
        }
    }

    /** Dedicated Edion/AU/ZOZO only: each merchant's identity + purchase proof,
     * no 000+ fallback or cross-shop inference. Price/image remain untouched. */
    private void inspectDedicated(WebView current) {
        if (finished || current != web || generalInspectionPending || !allowed(current.getUrl())) return;
        final URL original = originalAlphabetUrl();
        final WishlistRetailDedicatedMode merchant = WishlistRetailDedicatedMode.forUrl(original);
        if (merchant == WishlistRetailDedicatedMode.NONE) { finish("UNKNOWN"); return; }
        generalInspectionPending = true;
        publishMode(merchant.name()+"固有モード");
        try {
            current.evaluateJavascript(WishlistRetailDedicatedStockDom.javascript(original), value -> {
                generalInspectionPending = false;
                if (finished || current != web) return;
                String status="UNKNOWN", reason="unreadable";
                boolean idBound=false, variantBound=false;
                int carts=0, pairs=0, didNodes=0, didLocalCarts=0, didLocalStock=0;
                int didStateRecords=0, didStateStock=0, didStateContradictions=0, didStateExamined=0;
                int didStateOwnerMatched=0, didStateNestedStock=0, didStateUnproven=0;
                int didStateRecordWithStockKey=0;
                int didStateAvailabilityPositive=0,didStateAvailabilityNegative=0,didStateAvailabilityUnknown=0;
                String didStateKeyHints="none",didStateAvailabilityValues="none";
                try {
                    Object raw=new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    if (raw instanceof String) {
                        org.json.JSONObject o=new org.json.JSONObject((String)raw);
                        status=o.optString("status","UNKNOWN");
                        reason=o.optString("reason","unreadable");
                        idBound=o.optBoolean("idBound",false);
                        variantBound=o.optBoolean("variantBound",false);
                        carts=o.optInt("liveCarts",0);pairs=o.optInt("stockPairs",0);
                        didNodes=o.optInt("didNodes",0);didLocalCarts=o.optInt("didLocalCarts",0);
                        didLocalStock=o.optInt("didLocalStock",0);
                        didStateRecords=o.optInt("didStateRecords",0);
                        didStateStock=o.optInt("didStateStock",0);
                        didStateContradictions=o.optInt("didStateContradictions",0);
                        didStateExamined=o.optInt("didStateExamined",0);
                        didStateOwnerMatched=o.optInt("didStateOwnerMatched",0);
                        didStateNestedStock=o.optInt("didStateNestedStock",0);
                        didStateUnproven=o.optInt("didStateUnproven",0);
                        didStateRecordWithStockKey=o.optInt("didStateRecordWithStockKey",0);
                        didStateAvailabilityPositive=o.optInt("didStateAvailabilityPositive",0);
                        didStateAvailabilityNegative=o.optInt("didStateAvailabilityNegative",0);
                        didStateAvailabilityUnknown=o.optInt("didStateAvailabilityUnknown",0);
                        String values=o.optString("didStateAvailabilityValues","none");
                        if(values.matches("[A-Za-z0-9_,-]{1,190}"))didStateAvailabilityValues=values;
                        String hints=o.optString("didStateKeyHints","none");
                        if(hints.matches("[A-Za-z0-9_,]{1,190}"))didStateKeyHints=hints;
                    }
                } catch (Exception ignored) { }
                if (!reason.matches("[a-z0-9-]{1,55}")) reason="unreadable";
                trace("dedicated", "mode="+merchant+" status="+status+" reason="+reason
                        +" id="+idBound+" variant="+variantBound
                        +" carts="+carts+" pairs="+pairs
                        +" didNodes="+didNodes+" didLocalCarts="+didLocalCarts
                        +" didLocalStock="+didLocalStock
                        +" didStateRecords="+didStateRecords+" didStateStock="+didStateStock
                        +" didStateContradictions="+didStateContradictions
                        +" didStateExamined="+didStateExamined
                        +" didStateOwnerMatched="+didStateOwnerMatched
                        +" didStateNestedStock="+didStateNestedStock
                        +" didStateUnproven="+didStateUnproven
                        +" didStateRecordWithStockKey="+didStateRecordWithStockKey
                        +" didStateKeyHints="+didStateKeyHints
                        +" didStateAvailabilityPositive="+didStateAvailabilityPositive
                        +" didStateAvailabilityNegative="+didStateAvailabilityNegative
                        +" didStateAvailabilityUnknown="+didStateAvailabilityUnknown
                        +" didStateAvailabilityValues="+didStateAvailabilityValues
                        +" attempt="+(++generalInspectionRounds));
                if ("AVAILABLE".equals(status) && idBound && variantBound && pairs > 0) {
                    finishDedicated("AVAILABLE");return;
                }
                // A failure cannot overwrite previously successful data.
                if (generalInspectionRounds < 5)
                    main.postDelayed(() -> inspect(current), 1050L);
                else finish("UNKNOWN");
            });
        } catch (Exception ignored) {
            generalInspectionPending=false;
            trace("dedicated", "mode="+merchant+" status=UNKNOWN reason=script-error");
            finish("UNKNOWN");
        }
    }

    /** 000+ common survey. All techniques are evaluated before accepting ANY
     * stock; exact saved-item evidence is mandatory. This never changes the
     * saved acquisition mode, price, name or image pipelines. */
    private void inspectNumbered(WebView current, boolean firstPass) {
        if (finished || current != web || (firstPass && pageInspectionStarted)
                || generalInspectionPending || !allowed(current.getUrl())) return;
        generalInspectionPending=true;
        final URL original=originalAlphabetUrl();
        final java.util.List<String> catalog=WishlistNumberedTechniqueRegistry.catalog(parent.getContext());
        publishMode("GENERAL 000");
        try {
            current.evaluateJavascript(WishlistNumberedSurveyDom.javascript(original,catalog), raw -> {
                generalInspectionPending=false;
                if (finished || current != web || (firstPass && pageInspectionStarted)) return;
                boolean standardAvailable=false, numberedAvailable=false, mercariVerified=false;
                boolean variantVerified=false;
                try {
                    Object outer=new org.json.JSONTokener(raw==null?"null":raw).nextValue();
                    org.json.JSONObject result=new org.json.JSONObject((String)outer);
                    org.json.JSONArray rows=result.optJSONArray("results");
                    if(rows!=null) for(int i=0;i<rows.length();i++) {
                        org.json.JSONObject record=rows.optJSONObject(i);
                        if(record==null)continue;
                        String id=record.optString("id", "");
                        if(!id.matches("[0-9]{3}"))continue;
                        int n=Integer.parseInt(id);
                        if(n>=catalog.size())continue;
                        String status=record.optString("status","UNKNOWN");
                        String reason=record.optString("reason","none");
                        if(!reason.matches("[a-z0-9-]{1,60}"))reason="unreadable";
                        // The specialized survey checks current URL AND item-bound
                        // local stock. Legacy strategies retain their own proofs.
                        org.json.JSONObject details=record.optJSONObject("details");
                        if(n==0 && "AVAILABLE".equals(status))
                            standardAvailable=WishlistCrawler.isSingleProductPage(original);
                        if(n==6 && "AVAILABLE".equals(status) && details!=null)
                            variantVerified=details.optBoolean("idBound",false)
                                    && details.optBoolean("variantBound",false)
                                    && details.optInt("stockPairs",0)>0;
                        if(n==7 && details!=null && ("AVAILABLE".equals(status)||"UNAVAILABLE".equals(status))
                                && WishlistGeneralShopItem.merchant(original)==WishlistGeneralShopItem.Merchant.MERCARI
                                && details.optBoolean("bound",false)
                                && details.optInt("heading",0)==1 && details.optBoolean("heroPrice",false)) {
                            mercariVerified=true;
                            generalFirstVerified=status;
                        }
                        if(n>=1 && n!=7 && "AVAILABLE".equals(status))numberedAvailable=true;
                        String engine=record.optString("engine",n<8?"legacy-source":"unknown");
                        if(!engine.matches("[a-z0-9-]{1,40}"))engine="unreadable";
                        trace("numbered", "stage="+id+" technique="+catalog.get(n)
                                +" engine="+engine+" result="+status+" reason="+reason);
                    }
                } catch(Exception ex) {trace("numbered","result=UNKNOWN reason=invalid-snapshot");}
                // Source Mercari parser proves availability and sold-out; only
                // its exact listing path is allowed to make negative commits.
                if(mercariVerified){finish(generalFirstVerified);return;}
                if(mode==WishlistMode.GENERAL && (standardAvailable||numberedAvailable)
                        && (!hasDedicatedStockInspector() || (variantVerified
                           && !WishlistGeneralShopItem.isDetail(original)))) {
                    generalFirstVerified="AVAILABLE";
                    finish("AVAILABLE");return;
                }
                if(firstPass){
                    trace("route","general=complete stock=UNKNOWN next=site-specific");
                    beginPageInspection("mode-numbered-complete");
                }else if(generalInspectionRounds++<6) {
                    main.postDelayed(()->inspect(current),1350L);
                }else finish("UNKNOWN");
            });
        }catch(Exception ex){
            generalInspectionPending=false;
            trace("numbered","result=UNKNOWN reason=script-error");
            if(firstPass)beginPageInspection("mode-numbered-error");
            else finish("UNKNOWN");
        }
    }

    /** Isolated MUJI adapter: never invokes GENERAL alphabet scripts or clicks checkout. */
    private void inspectMuji(WebView current) {
        final URL url = originalAlphabetUrl();
        if (url == null || !WishlistMode.isMujiProduct(url)) { finish("UNKNOWN"); return; }
        if (mujiInspectionRunning) return;
        mujiInspectionRunning = true;
        try {
            current.evaluateJavascript(MujiProductDom.stockEvidence(url), value -> {
                mujiInspectionRunning = false;
                if (finished || current != web) return;
                String status = "UNKNOWN", reason = "unreadable";
                String evidence = "";
                try {
                    Object obj = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    org.json.JSONObject o = new org.json.JSONObject((String) obj);
                    status = o.optString("status", "UNKNOWN");
                    reason = o.optString("reason", "unreadable");
                    evidence = " product="+o.optBoolean("product",false)
                            +" sku="+o.optBoolean("sku",false)
                            +" cart="+o.optInt("cart",0)
                            +" enabled="+o.optInt("enabled",0)
                            +" hidden="+o.optInt("hidden",0)
                            +" disabled="+o.optInt("disabled",0)
                            +" qty="+o.optInt("quantity",0)
                            +" stock="+o.optBoolean("positive",false)
                            +" negative="+o.optBoolean("negative",false)
                            +" jsonProduct="+o.optBoolean("jsonProduct",false)
                            +" jsonStock="+o.optBoolean("jsonStock",false)
                            +" stockSrc="+o.optString("stockSource","none");
                } catch (Exception ignored) { }
                if (!reason.matches("[a-z0-9-]{1,55}")) reason = "unreadable";
                trace("muji.evidence", "attempt="+(specialRetries+1)
                        +" status="+status+" reason="+reason+evidence);
                if ("AVAILABLE".equals(status)) { finishDedicated("AVAILABLE"); return; }
                // UNKNOWN is deliberately the fallback even if a cart button is live:
                // MUJI documents cart buttons that remain active when stock is empty.
                if (++specialRetries < 6) main.postDelayed(() -> inspect(current), 1250L);
                else finish("UNKNOWN");
            });
        } catch (Exception ignored) {
            mujiInspectionRunning = false;
            trace("muji.evidence", "reason=script-error");
            if (++specialRetries < 6) main.postDelayed(() -> inspect(current), 1250L);
            else finish("UNKNOWN");
        }
    }

    /** JS inspects only the *visible* purchase UI of the known product detail page.
     * No click is sent; the app never makes a purchase or adds items to a cart. */
    private static String shopPurchaseJavascript(String host) {
        String shop = host.replace("'", "");
        return "(function(){try{" +
                "var host='" + shop + "';" +
                "function visible(e){if(!e||e.disabled||e.getAttribute('aria-disabled')==='true'||!e.getClientRects().length)return false;" +
                "for(var p=e;p;p=p.parentElement){var s=getComputedStyle(p);" +
                "if(s.display==='none'||s.visibility==='hidden'||p.hidden||Number(s.opacity)===0)return false;}return true;}" +
                "var main=document.querySelector('main,#main,#contents,[role=main],#product_detail,#productDetail,.product-detail,.item-detail');" +
                "if(!main)main=document.body;if(!main)return 'UNKNOWN';" +
                "var product=main.querySelector('#product_detail,#productDetail,.product-detail,.item-detail,.product-info,.detail-item,.product__detail')||main;" +
                "var controls=product.querySelectorAll('button,input[type=submit],input[type=button],a[href],[role=button]');" +
                "var label=/(?:カートに入れる|買い物かごに入れる|かごに入れる|購入する|注文する|add\\s+to\\s+cart)/i;" +
                "var count=0;for(var i=0;i<controls.length&&i<130;i++){var b=controls[i];" +
                "if(!visible(b))continue;var name=(b.innerText||b.textContent||b.value||'')+' '+(b.getAttribute('aria-label')||'');" +
                "if(!label.test(name))continue;" +
                "if(b.closest('nav,header,footer,[class*=related],[class*=recommend],[id*=related],[id*=recommend]'))continue;" +
                "var group=b.closest('form,.purchase,.cart,.buy,.product-detail,.item-detail')||b.parentElement;" +
                "if(!group||!product.contains(group))continue;" +
                "var nearby=group.querySelector('input[type=number],input[name*=quantity],input[name*=Quantity],input[name*=qty],select[name*=quantity]');" +
                "if(!nearby){var previous=b.parentElement;for(var k=0;k<4&&previous&&product.contains(previous);k++,previous=previous.parentElement){" +
                "nearby=previous.querySelector('input[type=number],input[name*=quantity],input[name*=qty]');if(nearby)break;}}" +
                "if(!nearby){var quantities=product.querySelectorAll('input[type=number],input[name*=quantity],input[name*=qty],input[id*=quantity]');" +
                "if(quantities.length===1)nearby=quantities[0];}" +
                "if(!nearby&&!group.matches('form'))continue;" +
                "var notices=group.querySelectorAll('[class*=stock],[class*=sold],[class*=out-of-stock],[id*=stock]');" +
                "var sold=false;for(var z=0;z<notices.length&&z<25;z++){" +
                "if(visible(notices[z])&&/(?:売り切れ|売切れ|完売|在庫切れ|sold\\s*out)/i.test(notices[z].textContent||''))sold=true;}" +
                "if(sold)continue;" +

                "count++;break;}return count===1?'AVAILABLE':'UNKNOWN';" +
                "}catch(e){return 'UNKNOWN';}})()";
    }

    /** Read after Callback.completed; never supplies an unverified page title. */
    public String verifiedProductTitle() { return verifiedProductTitle; }
    /** Only from the exact saved EDION / ISETAN rendered product DOM. */
    public Long verifiedProductPrice() { return verifiedProductPrice; }

    private boolean dedicatedProofThisInspection;
    /** True only when an item-bound site-specific inspector, not 000+,
     * returned a verified stock decision in THIS probe. */
    public boolean dedicatedStockProof() { return dedicatedProofThisInspection; }
    private void finishDedicated(String status) {
        if ("AVAILABLE".equals(status)||"UNAVAILABLE".equals(status))
            dedicatedProofThisInspection=true;
        finish(status);
    }

    private void finish(String status) {
        if (finished) return;
        // No premature UNKNOWN because a merchant's first 5 inspections were
        // empty: the exact-item page has its full, independent 15 seconds.
        // The site-specific inspector may exit immediately on valid stock proof.
        if ("UNKNOWN".equals(status) && mode == WishlistMode.GENERAL
                && pageInspectionStarted && !pageWindowExpired) {
            final WebView retry=web;
            if (retry!=null) main.postDelayed(() -> inspect(retry), 950L);
            return;
        }
        main.removeCallbacks(modeWindowTimeout);
        main.removeCallbacks(pageWindowTimeout);
        if ("UNKNOWN".equals(status) && mode == WishlistMode.GENERAL
                && "AVAILABLE".equals(generalFirstVerified)) {
            trace("route", "dedicated=unknown preserve=verified-general");
            finish("AVAILABLE");
            return;
        }
        // The page has already been rendered for its independent stock analysis.
        // Capture an exact-item title before destroying the SAME WebView; do not
        // start another request or modify the stock result when title is absent.
        if (!titleCaptureAttempted && callback != null && web != null
                && allowed(web.getUrl())) {
            URL original=originalAlphabetUrl();
            final boolean merchantMetadata=WishlistRetailVerifiedMetadataDom.supports(original);
            if (WishlistRetailProductTitleDom.supports(original) || merchantMetadata) {
                titleCaptureAttempted=true;
                final WebView inspecting=web;
                final boolean[] resolved={false};
                final Runnable fallback=() -> {
                    if (!resolved[0] && !finished) {resolved[0]=true;completeFinish(status);}
                };
                main.removeCallbacks(timeout);
                main.postDelayed(fallback, 1100L);
                try {
                    inspecting.evaluateJavascript(merchantMetadata
                            ? WishlistRetailVerifiedMetadataDom.javascript(original)
                            : WishlistRetailProductTitleDom.javascript(original), value -> {
                        if (resolved[0] || finished || inspecting!=web) return;
                        resolved[0]=true;
                        main.removeCallbacks(fallback);
                        String reason="unreadable";
                        try {
                            Object raw=new org.json.JSONTokener(value==null?"null":value).nextValue();
                            if (raw instanceof String) {
                                org.json.JSONObject result=new org.json.JSONObject((String)raw);
                                reason=result.optString("reason","unreadable");
                                String name=result.optString("title","").trim();
                                if (("verified-rendered-heading".equals(reason)
                                        || (merchantMetadata && ("item-heading-verified".equals(reason)
                                            || "conflicting-gross-prices".equals(reason))))
                                        && name.length()>=3 && name.length()<=240)
                                    verifiedProductTitle=name;
                                if (merchantMetadata && !result.isNull("price")) {
                                    long recovered=result.optLong("price",0L);
                                    if (recovered>=50L && recovered<=100000000L)
                                        verifiedProductPrice=recovered;
                                }
                            }
                        }catch(Exception ignored) { }
                        String canonicalKind="none";
                        try {
                            Object outer=new org.json.JSONTokener(value==null?"null":value).nextValue();
                            if (outer instanceof String) {
                                String kind=new org.json.JSONObject((String)outer)
                                        .optString("canonicalKind","none");
                                if (kind.matches("[a-z0-9-]{1,40}")) canonicalKind=kind;
                            }
                        }catch(Exception ignored) { }
                        trace("product.name", "verified="+(verifiedProductTitle!=null)
                                +" merchantMetadata="+merchantMetadata
                                +" price="+(verifiedProductPrice!=null)
                                +" reason="+(reason.matches("[a-z0-9-]{1,55}")?reason:"unreadable")
                                +" canonicalKind="+canonicalKind);
                        completeFinish(status);
                    });
                } catch(Exception ignored) {
                    main.removeCallbacks(fallback);resolved[0]=true;completeFinish(status);
                }
                return;
            }
        }
        completeFinish(status);
    }

    private void completeFinish(String status) {
        if (finished) return;
        if (rawAuditEnabled) {
            String verdict = "status=" + status + " examined=" + auditReceived
                    + " samples=" + auditElements + " enabledProductCartCandidate="
                    + auditProductCartEnabled + " namedPurchase=" + auditPurchaseNamed;
            // Raw DOM presence is never itself an availability decision.
            if (auditProductCartEnabled && "UNKNOWN".equals(status))
                verdict += " discrepancy=classifier-or-product-binding";
            else if (!auditReceived) verdict += " discrepancy=not-inspected";
            trace("dom.audit.verdict", verdict);
        }

        finished = true;
        main.removeCallbacks(timeout);
        main.removeCallbacks(modeWindowTimeout);
        main.removeCallbacks(pageWindowTimeout);
        WebView old = web;
        web = null;
        if (old != null) {
            old.stopLoading();
            old.setWebViewClient(new WebViewClient());
            // A mounted WebView MUST be detached before destroy; otherwise
            // subsequent items in a batch may retain a stale hidden renderer.
            if (old.getParent() instanceof ViewGroup)
                ((ViewGroup) old.getParent()).removeView(old);
            old.destroy();
        }
        Callback done = callback;
        callback = null;
        if (done != null) done.completed(status);
    }

    public void cancel() {
        if (Looper.myLooper() != Looper.getMainLooper()) return;
        callback = null;
        // Cancel must invalidate even an active GENERAL page-phase retry.
        pageWindowExpired=true;
        main.removeCallbacks(modeWindowTimeout);
        main.removeCallbacks(pageWindowTimeout);
        finish("UNKNOWN");
    }
}
