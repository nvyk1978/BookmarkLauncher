package com.cmyk.bookmarkslauncher.wishlist;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.net.URL;
import java.util.Locale;

/**
 * Foreground, manual-refresh-only stock probe for JS-rendered product forms.
 * Reports AVAILABLE only for a visible/enabled cart control in a product form.
 * Never reads or persists prices, titles, images or site-reachability state.
 * Unknown / redirect / script errors produce no database writes.
 */
public final class WishlistAvailabilityWebViewProbe {
    public interface Callback { void completed(boolean available); }
    private final FrameLayout parent;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private Callback callback;
    private String originHost;
    private String originPath;
    private MarketplaceIdentity expectedMarketplace;
    private boolean finished;
    private final Runnable timeout = () -> finish(false);

    public WishlistAvailabilityWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public void start(String urlText, WishlistMode mode, Callback done) {
        cancel();
        if (Looper.myLooper() != Looper.getMainLooper()) {
            if (done != null) done.completed(false);
            return;
        }
        callback = done;
        finished = false;
        try {
            URL url = new URL(urlText);
            if (!WishlistAvailabilityExtractor.isProductDetail(url)) {
                finish(false); return; // Never inspect a category/listing's unrelated buttons.
            }
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) {
                finish(false); return;
            }
            if (mode == null || mode == WishlistMode.UNRESOLVED
                    || WishlistMode.forDirectUrl(urlText) != mode) { finish(false); return; }
            expectedMarketplace = MarketplaceIdentity.from(url);
            originHost = url.getHost().toLowerCase(Locale.ROOT);
            originPath = url.getPath();
            web = new WebView(parent.getContext());
            web.setBackgroundColor(Color.TRANSPARENT);
            web.setAlpha(0f);
            web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setClickable(false);
            web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.setVerticalScrollBarEnabled(false);
            web.setHorizontalScrollBarEnabled(false);
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            parent.addView(web, 0, p);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return request.isForMainFrame() && !allowed(request.getUrl().toString());
                }
                @Override public void onPageFinished(WebView view, String loaded) {
                    if (finished || !allowed(loaded)) return;
                    main.postDelayed(() -> inspect(view), 1200L);
                }
                @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    if (request.isForMainFrame()) finish(false);
                }
            });
            main.postDelayed(timeout, 13000L);
            web.loadUrl(url.toString());
        } catch (Exception ignored) { finish(false); }
    }

    private boolean allowed(String urlText) {
        try {
            URL url = new URL(urlText);
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) return false;
            String host = url.getHost().toLowerCase(Locale.ROOT);
            if (originHost == null || originPath == null) return false;
            // A redirect to the store home or another product cannot prove the
            // original item's stock, even if the destination has a cart button.
            if (expectedMarketplace != null) return expectedMarketplace.matches(url);
            if (!url.getPath().equalsIgnoreCase(originPath)) return false;
            if (originHost.equals("amazon.co.jp") || originHost.endsWith(".amazon.co.jp"))
                return host.equals("amazon.co.jp") || host.endsWith(".amazon.co.jp");
            return host.equals(originHost);
        } catch (Exception ignored) { return false; }
    }

    private void inspect(WebView current) {
        if (finished || current != web || !allowed(current.getUrl())) return;
        // Independent, conservative rendered-DOM adapter for verified single-item
        // pages. No click/navigation is performed, and no unrelated data is read.
        String store = originHost == null ? "" : originHost;
        if (store.equals("nakasima-inc.shop") || store.equals("eshop.fumuroya.com")
                || store.equals("www.torikan.net") || store.equals("torikan.net")) {
            current.evaluateJavascript(shopPurchaseJavascript(store), value ->
                    finish("\"AVAILABLE\"".equals(value)));
            return;
        }
        if (expectedMarketplace != null) {
            String siteJs= expectedMarketplace.site==MarketplaceIdentity.Site.AMAZON ? AmazonDomSelectors.stock(expectedMarketplace.id)
                    : expectedMarketplace.site==MarketplaceIdentity.Site.RAKUTEN ? RakutenDomSelectors.stock()
                    : expectedMarketplace.site==MarketplaceIdentity.Site.YAHOO ? YahooDomSelectors.stock() : null;
            if(siteJs==null){finish(false);return;}
            current.evaluateJavascript(siteJs,v->finish("\"AVAILABLE\"".equals(v)));
            return;
        }
        // Check a real rendered control, not hidden templates or page-wide text.
        // Only forms with cart-oriented actions qualify; a related product button
        // outside a product form is deliberately UNKNOWN rather than AVAILABLE.
        String javascript = "(function(){try{" +
                "var root=document.querySelector('main')||document.body;" +
                "var market='"+(expectedMarketplace==null?"":expectedMarketplace.site.name())+"';"+
                "if(market){var base=market==='AMAZON'?document.querySelector('#buybox,#desktop_buybox,#addToCart,#buyBoxInner,#atcRedesignId,#addToCart_feature_div,#desktop_qualifiedBuyBox'):"+
                "document.querySelector('.product-detail,.item-detail,#productInfo,#itemInfo,.purchase,#purchase,#cart-form');"+
                "if(!base)return 'UNKNOWN';"+
                "var selectors=market==='AMAZON'?['#add-to-cart-button','input[name=\"submit.add-to-cart\"]','#buy-now-button']:"+
                "['button','input[type=submit]','input[type=button]'];"+
                "var controls=base.querySelectorAll(selectors.join(','));var good=0;"+
                "for(var z=0;z<controls.length&&z<45;z++){var b=controls[z];"+
                "var name=(b.getAttribute('name')||'')+' '+(b.getAttribute('id')||'')+' '+(b.value||b.innerText||'');"+
                "if(!/(?:add.to.cart|buy.now|カートに入れる|買い物かごに入れる|かごに入れる|購入する|注文する)/i.test(name))continue;"+
                "if(b.disabled||b.getAttribute('aria-disabled')==='true'||!b.getClientRects().length)continue;"+
                "var cs=getComputedStyle(b);if(cs.display==='none'||cs.visibility==='hidden')continue;good++;}"+
                "return good>0?'AVAILABLE':'UNKNOWN';}"+
                "if(!root)return 'UNKNOWN';" +
                "var cart=/(?:cart|basket|add.to.cart|add.item|buy)/i;" +
                "var label=/(?:カートに入れる|買い物かごに入れる|カゴに入れる|購入する|注文する|add\\s+to\\s+(?:cart|bag))/i;" +
                "function visible(e){if(!e||e.disabled||e.getAttribute('aria-disabled')==='true')return false;" +
                "if(!e.getClientRects().length)return false;" +
                "for(var n=e;n&&n!==root;n=n.parentElement){var s=getComputedStyle(n);" +
                "if(s.display==='none'||s.visibility==='hidden'||s.opacity==='0'||n.hidden)return false;}return true;}" +
                "var forms=root.querySelectorAll('form');var successes=0;" +
                "for(var i=0;i<forms.length&&i<80;i++){var f=forms[i];" +
                "if(!cart.test(f.getAttribute('action')||''))continue;" +
                "var buttons=f.querySelectorAll('button,input[type=submit],input[type=button]');" +
                "for(var j=0;j<buttons.length&&j<30;j++){var b=buttons[j];" +
                "if(visible(b)&&label.test(b.value||b.innerText||b.textContent||'')){successes++;break;}}}" +
                "return successes===1?'AVAILABLE':'UNKNOWN';" +
                "}catch(e){return 'UNKNOWN';}})()";
        current.evaluateJavascript(javascript, value -> finish("\"AVAILABLE\"".equals(value)));
    }

    /** JS inspects only the *visible* purchase UI of the known product detail page.
     * No click is sent; the app never makes a purchase or adds items to a cart. */
    private static String shopPurchaseJavascript(String host) {
        String shop = host.replace("'", "");
        return "(function(){try{" +
                "var host='" + shop + "';" +
                "function visible(e){if(!e||e.disabled||e.getAttribute('aria-disabled')==='true'||!e.getClientRects().length)return false;" +
                "for(var p=e;p;p=p.parentElement){var s=getComputedStyle(p);" +
                "if(s.display==='none'||s.visibility==='hidden'||p.hidden||Number(s.opacity)===0)return false;}return true;}" +
                "var main=document.querySelector('main,#main,#contents,[role=main],#product_detail,#productDetail,.product-detail,.item-detail');" +
                "if(!main)main=document.body;if(!main)return 'UNKNOWN';" +
                "var product=main.querySelector('#product_detail,#productDetail,.product-detail,.item-detail,.product-info,.detail-item,.product__detail')||main;" +
                "var controls=product.querySelectorAll('button,input[type=submit],input[type=button],a[href],[role=button]');" +
                "var label=/(?:カートに入れる|買い物かごに入れる|かごに入れる|購入する|注文する|add\\s+to\\s+cart)/i;" +
                "var count=0;for(var i=0;i<controls.length&&i<130;i++){var b=controls[i];" +
                "if(!visible(b))continue;var name=(b.innerText||b.textContent||b.value||'')+' '+(b.getAttribute('aria-label')||'');" +
                "if(!label.test(name))continue;" +
                "if(b.closest('nav,header,footer,[class*=related],[class*=recommend],[id*=related],[id*=recommend]'))continue;" +
                "var group=b.closest('form,.purchase,.cart,.buy,.product-detail,.item-detail')||b.parentElement;" +
                "if(!group||!product.contains(group))continue;" +
                "var nearby=group.querySelector('input[type=number],input[name*=quantity],input[name*=Quantity],input[name*=qty],select[name*=quantity]');" +
                "if(!nearby){var previous=b.parentElement;for(var k=0;k<4&&previous&&product.contains(previous);k++,previous=previous.parentElement){" +
                "nearby=previous.querySelector('input[type=number],input[name*=quantity],input[name*=qty]');if(nearby)break;}}" +
                "if(!nearby){var quantities=product.querySelectorAll('input[type=number],input[name*=quantity],input[name*=qty],input[id*=quantity]');" +
                "if(quantities.length===1)nearby=quantities[0];}" +
                "if(!nearby&&!group.matches('form'))continue;" +
                "var notices=group.querySelectorAll('[class*=stock],[class*=sold],[class*=out-of-stock],[id*=stock]');" +
                "var sold=false;for(var z=0;z<notices.length&&z<25;z++){" +
                "if(visible(notices[z])&&/(?:売り切れ|売切れ|完売|在庫切れ|sold\\s*out)/i.test(notices[z].textContent||''))sold=true;}" +
                "if(sold)continue;" +

                "count++;break;}return count===1?'AVAILABLE':'UNKNOWN';" +
                "}catch(e){return 'UNKNOWN';}})()";
    }

    private void finish(boolean available) {
        if (finished) return;
        finished = true;
        main.removeCallbacks(timeout);
        WebView old = web;
        web = null;
        if (old != null) {
            old.stopLoading();
            old.setWebViewClient(new WebViewClient());
            parent.removeView(old);
            old.destroy();
        }
        Callback done = callback;
        callback = null;
        if (done != null) done.completed(available);
    }

    public void cancel() {
        if (Looper.myLooper() != Looper.getMainLooper()) return;
        callback = null;
        finish(false);
    }
}
