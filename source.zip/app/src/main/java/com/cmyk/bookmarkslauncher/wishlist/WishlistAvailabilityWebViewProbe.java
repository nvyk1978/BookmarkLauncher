package com.cmyk.bookmarkslauncher.wishlist;

import com.cmyk.bookmarkslauncher.DiagLog;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.ConsoleMessage;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.net.URL;
import java.util.Locale;

/**
 * Foreground, manual-refresh-only stock probe for JS-rendered product forms.
 * Reports AVAILABLE only for a visible/enabled cart control in a product form.
 * Never reads or persists prices, titles, images or site-reachability state.
 * Unknown / redirect / script errors produce no database writes.
 */
public final class WishlistAvailabilityWebViewProbe {
    public interface Callback { void completed(String status); }
    public interface Trace { void record(String stage, String safeEvidence); }
    private Trace trace;
    public void setTrace(Trace listener) { trace = listener; }
    private void trace(String stage, String evidence) {
        if (trace != null) trace.record(stage,evidence);
        // App-wide diagnosis receives only bounded, non-sensitive cart audit
        // summaries. The detailed element inventory remains per-card only.
        if (stage != null && (stage.equals("dom.audit.summary") || stage.equals("dom.audit.verdict")
                || stage.equals("dom.audit.failure") || stage.equals("dom.audit.skip"))) {
            String safe = evidence == null ? "-" : evidence;
            if (safe.length() > 420) safe = safe.substring(0, 420);
            DiagLog.write(parent.getContext(), "Wish webview.cart.audit host="
                    + (originHost == null ? "-" : originHost) + " stage=" + stage + " " + safe);
        }
    }
    private final FrameLayout parent;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private Callback callback;
    private String originHost;
    private WishlistMode mode;
    private String originPath;
    private String originalQuery;
    private MarketplaceIdentity expectedMarketplace;
    private boolean finished;
    private int specialRetries;
    private boolean rawAuditEnabled;
    private int rawAuditSamples;
    private boolean auditPending;
    private int webErrorSamples;
    private boolean auditReceived;
    private boolean auditProductCartEnabled;
    private boolean auditPurchaseNamed;
    private int auditElements;
    private boolean mujiInspectionRunning;
    private int mainFrameHttpFailure;
    private boolean generalInspectionPending;
    private int generalInspectionRounds;
    private boolean identityAuditDone;
    private String verifiedProductTitle;
    private Long verifiedProductPrice;
    private boolean titleCaptureAttempted;
    private final Runnable timeout = () -> {
        trace("deadline", "host="+originHost+" attempts="+specialRetries
                +" urlVerified="+(web!=null && allowed(web.getUrl())));
        finish("UNKNOWN");
    };

    public WishlistAvailabilityWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public void start(String urlText, WishlistMode mode, Callback done) {
        cancel();
        if (Looper.myLooper() != Looper.getMainLooper()) {
            if (done != null) done.completed("UNKNOWN");
            return;
        }
        callback = done;
        this.mode = mode;
        finished = false;
        specialRetries = 0;
        rawAuditEnabled = false;
        rawAuditSamples = 0;
        auditPending = false;
        webErrorSamples = 0;
        auditReceived = false;
        auditProductCartEnabled = false;
        auditPurchaseNamed = false;
        auditElements = 0;
        generalInspectionPending = false;
        mainFrameHttpFailure = 0;
        mujiInspectionRunning = false;
        generalInspectionRounds = 0;
        identityAuditDone = false;
        verifiedProductTitle = null;
        verifiedProductPrice = null;
        titleCaptureAttempted = false;
        try {
            URL url = new URL(urlText);
            if (!WishlistAvailabilityExtractor.isProductDetail(url)
                    && !(mode == WishlistMode.GENERAL && WishlistGeneralAlphabetDom.candidateUrl(url))
                    && !(mode == WishlistMode.GENERAL && WishlistRetailDedicatedMode.forUrl(url)
                        != WishlistRetailDedicatedMode.NONE)) {
                finish("UNKNOWN"); return; // Category/listing: no product evidence.
            }
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) {
                finish("UNKNOWN"); return;
            }
            if (mode == null || mode == WishlistMode.UNRESOLVED
                    || WishlistMode.forDirectUrl(urlText) != mode) { finish("UNKNOWN"); return; }
            expectedMarketplace = MarketplaceIdentity.from(url);
            originHost = url.getHost().toLowerCase(Locale.ROOT);
            originPath = url.getPath();
            originalQuery = url.getQuery();
            // Read-only DOM inspection is standard for all GENERAL product
            // refreshes. Marketplace and dedicated-mode classifiers are intact.
            rawAuditEnabled = mode == WishlistMode.GENERAL;
            web = BackgroundDomWebView.create(parent.getContext());

            web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setClickable(false);
            web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.setVerticalScrollBarEnabled(false);
            web.setHorizontalScrollBarEnabled(false);

            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            if (rawAuditEnabled) web.setWebChromeClient(new WebChromeClient() {
                @Override public boolean onConsoleMessage(ConsoleMessage message) {
                    if (!finished && message != null && webErrorSamples < 3
                            && message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                        webErrorSamples++;
                        String detail = message.message() == null ? "" : message.message();
                        // Console content can contain secrets; log category only.
                        String category = detail.matches("(?is).*\\b(TypeError|ReferenceError)\\b.*")
                                ? "runtime-type-or-reference"
                                : detail.matches("(?is).*(CSP|Content Security Policy|Refused to).*")
                                ? "csp" : detail.matches("(?is).*(CORS|cross.origin).*")
                                ? "cors" : "other-js-error";
                        trace("dom.audit.console", "category="+category
                                +" line="+Math.max(0,message.lineNumber()));
                    }
                    return false;
                }
            });
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return request.isForMainFrame() && !allowed(request.getUrl().toString());
                }
                @Override public void onPageStarted(WebView view, String loaded, android.graphics.Bitmap icon) {
                    if (finished || !allowed(loaded)) return;
                    // GENERAL can inspect a partially hydrated product before
                    // third-party trackers keep onPageFinished from arriving.
                    if (mode == WishlistMode.GENERAL || mode == WishlistMode.MUJI)
                        main.postDelayed(() -> inspect(view), 2100L);
                    if ("e-mono.jr-central.co.jp".equals(originHost))
                        trace("jr.page.started", "sameSku=true");
                    if ("e-mono.jr-central.co.jp".equals(originHost)
                            || "eshop.fumuroya.com".equals(originHost)
                            || "www.hiraki.co.jp".equals(originHost)
                            || "hiraki.co.jp".equals(originHost))
                        main.postDelayed(() -> inspect(view), 2100L);
                }
                @Override public void onPageFinished(WebView view, String loaded) {
                    if (finished || !allowed(loaded)) return;
                    if ("askul.co.jp".equals(originHost) || "www.askul.co.jp".equals(originHost))
                        trace("page.finished", "sameSku=true");
                    if ("e-mono.jr-central.co.jp".equals(originHost))
                        trace("jr.page.finished", "sameSku=true");
                    if (rawAuditEnabled && !isDetailedAuditShop()) {
                        // Inspect GENERIC shops before their classifier completes.
                        main.postDelayed(() -> auditRawDom(view,"page-finished"), 150L);
                    }
                    main.postDelayed(() -> inspect(view), 1200L);
                }
                @Override public void onReceivedHttpError(WebView view, WebResourceRequest req,
                                                         android.webkit.WebResourceResponse response) {
                    if (rawAuditEnabled && webErrorSamples < 3 && response.getStatusCode() >= 400) {
                        webErrorSamples++;
                        trace("dom.audit.http", "scope="+(req.isForMainFrame()?"main":"subresource")
                                +" code="+response.getStatusCode());
                    }
                    // A genuine upstream 5xx main-document failure is not a
                    // product page. Never parse a tiny maintenance/error page
                    // as stock; subresource failures do not trigger this rule.
                    if (req.isForMainFrame() && mode == WishlistMode.GENERAL
                            && response.getStatusCode() >= 500) {
                        mainFrameHttpFailure = response.getStatusCode();
                        trace("dom.audit.skip", "reason=main-http-5xx code="+mainFrameHttpFailure);
                        finish("UNKNOWN");
                        return;
                    }
                    if (req.isForMainFrame() && ("askul.co.jp".equals(originHost)
                            || "www.askul.co.jp".equals(originHost)))
                        trace("http", "code="+response.getStatusCode());
                }
                @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    if (rawAuditEnabled && webErrorSamples < 3) {
                        webErrorSamples++;
                        trace("dom.audit.network", "scope="+(request.isForMainFrame()?"main":"subresource")
                                +" code="+error.getErrorCode());
                    }
                    if (request.isForMainFrame()) finish("UNKNOWN");
                }
            });
            boolean askul = "askul.co.jp".equals(originHost) || "www.askul.co.jp".equals(originHost);
            main.postDelayed(timeout, askul ? 19000L : mode == WishlistMode.MUJI ? 16500L : 13000L);
            web.loadUrl(url.toString());
            if (rawAuditEnabled) {
                // Targeted difficult shops retain their proven early/settled
                // checkpoints; other GENERAL shops take a bounded early sample.
                final WebView auditWeb = web;
                if (isDetailedAuditShop()) {
                    main.postDelayed(() -> auditRawDom(auditWeb, "early"), 3100L);
                    main.postDelayed(() -> auditRawDom(auditWeb, "settled"), 5200L);
                } else {
                    main.postDelayed(() -> auditRawDom(auditWeb, "general"), 2400L);
                }
            }
            if (askul) {
                final WebView skuProbeView = web;
                main.postDelayed(() -> inspect(skuProbeView), 2400L);
            } else if ("www.hiraki.co.jp".equals(originHost)
                    || "hiraki.co.jp".equals(originHost)) {
                // Do not wait indefinitely for third-party scripts to finish.
                // Existing retries still verify the exact product/variant.
                final WebView hirakiProbe = web;
                main.postDelayed(() -> inspect(hirakiProbe), 6000L);
            } else if ("e-mono.jr-central.co.jp".equals(originHost)) {
                // JR pages can keep loading third-party scripts indefinitely.
                // Probe the verified product DOM without waiting for pageFinished.
                final WebView jrProbeView = web;
                main.postDelayed(() -> inspect(jrProbeView), 4200L);
                main.postDelayed(() -> inspect(jrProbeView), 8400L);
            }
        } catch (Exception ignored) { finish("UNKNOWN"); }
    }

    /** Two bounded snapshots of the actual DOM, independent of purchase filters.
     * No purchases, input values, raw document HTML, full text or URLs are read
     * into the card log. Unknown readiness will be recorded, not miscalled absent.
     */
    private boolean isDetailedAuditShop() {
        return "www.askul.co.jp".equals(originHost) || "askul.co.jp".equals(originHost)
                || "www.hiraki.co.jp".equals(originHost) || "hiraki.co.jp".equals(originHost)
                || "e-mono.jr-central.co.jp".equals(originHost);
    }

    private void auditRawDom(WebView current, String phase) {
        if (!rawAuditEnabled || finished || current != web || rawAuditSamples >= 2 || auditPending) return;
        if (!allowed(current.getUrl())) {
            trace("dom.audit.skip", "phase="+phase+" reason=unverified-product-url");
            return;
        }
        rawAuditSamples++;
        auditPending = true;
        try {
            current.evaluateJavascript(WishlistRawPurchaseDomAudit.javascript(), result -> {
                if (finished || current != web) return;
                auditPending = false;
                try {
                    Object unwrapped = new org.json.JSONTokener(result == null ? "null" : result).nextValue();
                    if (!(unwrapped instanceof String)) {
                        trace("dom.audit.failure", "phase="+phase+" result=not-string"); return;
                    }
                    org.json.JSONObject o = new org.json.JSONObject((String) unwrapped);
                    auditReceived = true;
                    trace("dom.audit.summary", "phase="+phase
                            +" ready="+o.optString("ready","unknown")
                            +" bodyChars="+o.optInt("bodyChars",0)
                            +" cartText="+o.optBoolean("cartText",false)
                            +" controls="+o.optInt("controls",0)
                            +" buttons="+o.optInt("buttons",0)
                            +" qty="+o.optInt("quantities",0)
                            +" named="+o.optInt("cartNamed",0)
                            +" enabledNamed="+o.optInt("enabledNamed",0)
                            +" frames="+o.optInt("frames",0)
                            +" readable="+o.optInt("readable",0)
                            +" blocked="+o.optInt("unreadable",0)
                            +" shadows="+o.optInt("shadows",0)
                            +" limited="+o.optBoolean("limit",false)
                            +" error="+o.optString("error","none"));
                    org.json.JSONArray samples = o.optJSONArray("samples");
                    if (samples != null) for (int i=0;i<Math.min(samples.length(),5);i++) {
                        org.json.JSONObject c = samples.optJSONObject(i);
                        if (c == null) continue;
                        auditElements++;
                        if (c.optBoolean("product",false) && "enabled".equals(c.optString("state"))
                                && !"none".equals(c.optString("label","none"))) {
                            auditProductCartEnabled = true;
                        }
                        if ("purchase".equals(c.optString("label","none"))) auditPurchaseNamed = true;
                        trace("dom.audit.element", "phase="+phase+" n="+(i+1)
                                +" scope="+c.optString("scope","-")
                                +" tag="+c.optString("tag","-")
                                +" id="+c.optString("id","-")
                                +" cls="+c.optString("cls","-")
                                +" attrs="+c.optString("attrs","-")
                                +" label="+c.optString("label","none")
                                +" state="+c.optString("state","unknown")
                                +" nearQty="+c.optBoolean("nearQty",false)
                                +" product="+c.optBoolean("product",false)
                                +" onclick="+c.optBoolean("onclick",false));
                    }
                } catch (Exception ignored) {
                    trace("dom.audit.failure", "phase="+phase+" reason=invalid-json");
                }
            });
        } catch (Exception ignored) {
            auditPending = false;
            trace("dom.audit.failure", "phase="+phase+" reason=javascript-not-evaluated");
        }
    }

    private URL safeOriginalUrl() {
        try { return new URL("https://" + originHost + originPath); }
        catch (Exception ignored) { return null; }
    }

    private URL originalAlphabetUrl() {
        try {
            return new URL("https://" + originHost + originPath
                    + (originalQuery == null ? "" : "?" + originalQuery));
        } catch (Exception ignored) { return null; }
    }

    private boolean allowed(String urlText) {
        try {
            URL url = new URL(urlText);
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) return false;
            String host = url.getHost().toLowerCase(Locale.ROOT);
            if (originHost == null || originPath == null) return false;
            // A redirect to the store home or another product cannot prove the
            // original item's stock, even if the destination has a cart button.
            if (expectedMarketplace != null) return expectedMarketplace.matches(url);
            if (!url.getPath().equalsIgnoreCase(originPath)) return false;
            // A GENERAL product can be identified only in the query string
            // (Color Me, CS-Cart, 久世福). Never trust another item's cart.
            for (String key : new String[]{"product_id", "pid", "eci_product", "p_cd", "sku"}) {
                String expected = productQueryValue(originalQuery, key);
                if (expected != null && !expected.equalsIgnoreCase(productQueryValue(url.getQuery(), key)))
                    return false;
            }
            if (originHost.equals("amazon.co.jp") || originHost.endsWith(".amazon.co.jp"))
                return host.equals("amazon.co.jp") || host.endsWith(".amazon.co.jp");
            return host.equals(originHost);
        } catch (Exception ignored) { return false; }
    }

    private static String productQueryValue(String query, String key) {
        if (query == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                "(?i)(?:^|&)" + java.util.regex.Pattern.quote(key) + "=([a-z0-9_-]+)(?:&|$)")
                .matcher(query);
        return m.find() ? m.group(1) : null;
    }

    private void inspect(WebView current) {
        if (finished || current != web || generalInspectionPending || mainFrameHttpFailure >= 500) return;
        if (!allowed(current.getUrl())) {
            if ("e-mono.jr-central.co.jp".equals(originHost))
                trace("jr.skip", "reason=main-document-unverified");
            return;
        }
        // Independent, conservative rendered-DOM adapter for verified single-item
        // pages. No click/navigation is performed, and no unrelated data is read.
        String store = originHost == null ? "" : originHost;
        if (mode == WishlistMode.MUJI && (store.equals("muji.com") || store.equals("www.muji.com"))) {
            inspectMuji(current);
            return;
        }
        // Merchant-specific submode BEFORE generic A-G. The original GENERAL
        // acquisitionMode is retained for saved card/price compatibility.
        if (mode == WishlistMode.GENERAL
                && WishlistRetailDedicatedMode.forUrl(originalAlphabetUrl())
                    != WishlistRetailDedicatedMode.NONE) {
            inspectDedicated(current);
            return;
        }
        if (store.equals("hiraki.co.jp") || store.equals("www.hiraki.co.jp")) {
            String sku = originPath.replaceAll("/+$", "").replaceAll(".*/", "");
            current.evaluateJavascript(HirakiStockDom.stockEvidence(sku), value -> {
                if (finished) return;
                String status="UNKNOWN", reason="unreadable", flags="";
                try {
                    Object raw = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    org.json.JSONObject obj = new org.json.JSONObject((String) raw);
                    status=obj.optString("status", "UNKNOWN");
                    reason=obj.optString("reason", "unreadable");
                    flags=" skuMatch="+obj.optBoolean("skuMatch",false)
                            +" color99="+obj.optBoolean("color99",false)
                            +" table="+obj.optInt("tableFound",0)
                            +" row="+obj.optInt("rowFound",0)
                            +" qty="+obj.optInt("qtyEnabled",0)
                            +" cart="+obj.optInt("cartEnabled",0)
                            +" cartAction="+obj.optInt("cartAction",0)
                            +" cartTextHint="+obj.optInt("cartTextHint",0)
                            +" icon="+obj.optInt("stockIcon",0)
                            +" forms="+obj.optInt("forms",0)
                            +" cartForms="+obj.optInt("cartForms",0)
                            +" boundForms="+obj.optInt("skuBoundForms",0)
                            +" imageControls="+obj.optInt("imageControls",0)
                            +" attrHints="+obj.optInt("cartAttributeHints",0)
                            +" shared="+obj.optInt("sharedCarts",0)
                            +" sharedReady="+obj.optInt("sharedEnabled",0)
                            +" sharedLinked="+obj.optInt("sharedLinked",0)
                            +" sharedOutside="+obj.optInt("sharedOutside",0)
                            +" nearest="+obj.optInt("sharedNearest",-1)
                            +" live="+obj.optInt("liveCartFound",0)
                            +" liveEnabled="+obj.optInt("liveCartEnabled",0)
                            +" actualHidden="+obj.optInt("actualCartHidden",0)
                            +" actualDisabled="+obj.optInt("actualCartDisabled",0)
                            +" actualSubmit="+obj.optInt("actualCartSubmit",0)
                            +" actualLive="+obj.optInt("actualCartSubmitLive",0)
                            +" actualLinked="+obj.optInt("actualCartLinked",0)
                            +" pos="+obj.optInt("stockPositive",0)
                            +" neg="+obj.optInt("stockNegative",0);
                } catch (Exception ignored) { }
                String evidence="attempt="+(specialRetries+1)+" status="+status
                        +" reason="+reason+flags;
                trace("hiraki.evidence",evidence);
                RetailDiagnostics.hiraki("webview.stock",evidence);
                if ("AVAILABLE".equals(status)) { finish("AVAILABLE"); return; }
                if ("UNAVAILABLE".equals(status)) { finish("UNAVAILABLE"); return; }
                // Retry after a dynamic stock row is hydrated. Do not infer
                // availability from the separate five-symbol legend.
                if (++specialRetries < 5) main.postDelayed(() -> inspect(current), 1450L);
                else finish("UNKNOWN");
            });
            return;
        }
        if (GeneralRetailIdentity.storeFromText("https://"+store+originPath)) {
            String sku = GeneralRetailIdentity.itemId(safeOriginalUrl());
            if (sku == null) { finish("UNKNOWN"); return; }
            if ("ASKUL".equals(GeneralRetailIdentity.store(safeOriginalUrl()))) {
                current.evaluateJavascript(AskulProductDom.stockEvidence(sku), value -> {
                    if (finished) return;
                    String status = "UNKNOWN", evidence = "unreadable-result";
                    try {
                        Object raw = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                        org.json.JSONObject obj = new org.json.JSONObject((String) raw);
                        status = obj.optString("status", "UNKNOWN");
                        evidence = "skuMatch=" + obj.optBoolean("skuLabel",false)
                                + " stockFound=" + obj.optBoolean("stockFound",false)
                                + " cartFound=" + obj.optInt("cartFound",0)
                                + " cartEnabled=" + obj.optInt("cartEnabled",0)
                                + " cartDisabled=" + obj.optInt("cartDisabled",0)
                                + " restricted=" + obj.optBoolean("restricted",false)
                                + " controls=" + obj.optInt("domControls",0)
                                + " cartHint=" + obj.optBoolean("cartTextHint",false)
                                + " stockHint=" + obj.optBoolean("stockTextHint",false)
                                + " iframes=" + obj.optInt("iframes",0)
                                + " productArea=" + obj.optBoolean("productArea",false)
                                + " structured=" + obj.optBoolean("structuredProduct",false)
                                + " structuredOffer=" + obj.optBoolean("structuredOffer",false)
                                + " skuFrame=" + obj.optInt("skuFrames",0)
                                + " frameCart=" + obj.optInt("frameCart",0)
                                + " frameStock=" + obj.optInt("frameStock",0)
                                + " framesReadable=" + obj.optInt("accessibleFrames",0)
                                + " scopeCut=" + obj.optBoolean("scopeCut",false)
                                + " scopeBefore=" + obj.optBoolean("scopeBefore",false)
                                + " scopeAfter=" + obj.optBoolean("scopeAfter",false)
                                + " scopeChars=" + obj.optInt("scopeChars",0)
                                + " shared=" + obj.optInt("sharedCarts",0)
                                + " sharedReady=" + obj.optInt("sharedEnabled",0)
                                + " modal=" + obj.optInt("modalCartCandidates",0)
                                + " modalEnabled=" + obj.optInt("modalCartEnabled",0)
                                + " modalPurchase=" + obj.optInt("modalPurchaseNamed",0)
                                + " live=" + obj.optInt("liveCarts",0)
                                + " liveEnabled=" + obj.optInt("liveEnabled",0)
                                + " sharedOutside=" + obj.optInt("sharedOutside",0)
                                + " stockPositive=" + obj.optBoolean("localStockPositive",false)
                                + " stockNegative=" + obj.optBoolean("localStockNegative",false)
                                + " stockPosition=" + obj.optString("stockPosition","none")
                                + " reason=" + obj.optString("reason","unknown");
                        trace("askul.product.scope", "attempt=" + (specialRetries+1)
                                + " stockLabel=" + obj.optBoolean("productStockLabel",false)
                                + " conflict=" + obj.optBoolean("productStockConflict",false)
                                + " distance=" + obj.optInt("productStockDistance",-1)
                                + " cartCaption=" + obj.optBoolean("productPurchaseText",false)
                                + " quantity=" + obj.optBoolean("productQuantity",false)
                                + " windowChars=" + obj.optInt("productTextWindowChars",0)
                                + " windowReason=" + obj.optString("productWindowReason","none")
                                + " headingChars=" + obj.optInt("productHeadingChars",0)
                                + " markerPos=" + obj.optInt("productMarkerPos",-1)
                                + " nextSkuCut=" + obj.optBoolean("productNextSkuCut",false)
                                + " windowStock=" + obj.optBoolean("productWindowStock",false)
                                + " windowNegative=" + obj.optBoolean("productWindowNegative",false)
                                + " windowCart=" + obj.optBoolean("productWindowPurchase",false)
                                + " windowQty=" + obj.optBoolean("productWindowQuantity",false)
                                + " windowQtyControls=" + obj.optInt("productWindowQuantityControls",0)
                                + " modalStock=" + obj.optInt("modalTargetStock",0)
                                + " modalReady=" + obj.optInt("modalProductReady",0)
                                + " modalCart=" + obj.optInt("modalTargetCart",0)
                                + " modalOther=" + obj.optInt("modalTargetOther",0)
                                + " decision=" + obj.optString("reason","unknown"));
                    } catch (Exception ignored) { }
                    trace("evidence", "attempt=" + (specialRetries+1) + " " + evidence);
                    if ("AVAILABLE".equals(status)) { finish("AVAILABLE"); return; }
                    if ("UNAVAILABLE".equals(status)) { finish("UNAVAILABLE"); return; }
                    if (++specialRetries < 7) main.postDelayed(() -> inspect(current), 1700L);
                    else finish("UNKNOWN");
                });
                return;
            }
            current.evaluateJavascript(GeneralRetailStockDom.javascript(store, sku), value -> {
                if (finished) return;
                RetailDiagnostics.general(safeOriginalUrl(), "webview.stock",
                        "attempt="+(specialRetries+1)+" state="+value);
                if ("askul.co.jp".equals(originHost) || "www.askul.co.jp".equals(originHost))
                    trace("dom", "attempt="+(specialRetries+1)+" state="+value);
                if ("\"AVAILABLE\"".equals(value)) { finish("AVAILABLE"); return; }
                if ("\"UNAVAILABLE\"".equals(value)) { finish("UNAVAILABLE"); return; }
                if (++specialRetries < 4) main.postDelayed(() -> inspect(current), 1200L);
                else finish("UNKNOWN");
            });
            return;
        }
        if (store.equals("eshop.fumuroya.com") || store.equals("e-mono.jr-central.co.jp")) {
            current.evaluateJavascript(WishlistIndependentStockDom.javascript(store), value -> {
                if (finished) return;
                String status="UNKNOWN", reason="unreadable", flags="";
                try {
                    Object raw=new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    org.json.JSONObject o=new org.json.JSONObject((String)raw);
                    status=o.optString("status","UNKNOWN");
                    reason=o.optString("reason","unreadable");
                    flags=" title="+o.optBoolean("title",false)
                            +" titleSource="+o.optString("titleSource","none")
                            +" headings="+o.optInt("headings",0)
                            +" variantSource="+o.optString("variantSource","none")
                            +" controls="+o.optInt("controls",0)
                            +" imageControls="+o.optInt("imageControls",0)
                            +" actionHints="+o.optInt("actionHints",0)
                            +" shared="+o.optInt("sharedCarts",0)
                            +" sharedReady="+o.optInt("sharedEnabled",0)
                            +" sharedLinked="+o.optInt("sharedLinked",0)
                            +" sharedOutside="+o.optInt("sharedOutside",0)
                            +" nearest="+o.optInt("sharedNearest",-1)
                            +" live="+o.optInt("liveCartFound",0)
                            +" liveEnabled="+o.optInt("liveCartEnabled",0)
                            +" imageCart="+o.optInt("verifiedImageCart",0)
                            +" imageEnabled="+o.optInt("verifiedImageEnabled",0)
                            +" qty="+o.optInt("qty",0)
                            +" cart="+o.optInt("cart",0)
                            +" enabled="+o.optInt("enabled",0)
                            +" negative="+o.optInt("negative",0)
                            +" selected="+o.optBoolean("selected",false);
                }catch(Exception ignored) { }
                trace(store.equals("eshop.fumuroya.com")?"fumuroya.evidence":"jr.evidence",
                        "attempt="+(specialRetries+1)+" status="+status+" reason="+reason+flags);
                if ("AVAILABLE".equals(status)) {finish("AVAILABLE");return;}
                if ("UNAVAILABLE".equals(status)) {finish("UNAVAILABLE");return;}
                if (++specialRetries < 5)main.postDelayed(()->inspect(current),1350L);
                else finish("UNKNOWN");
            });
            return;
        }
        if (store.equals("yuican-shop.com")) {
            current.evaluateJavascript(WishlistRemainingStockDom.javascript(store), value -> {
                if(finished)return;
                if("\"AVAILABLE\"".equals(value)){finish("AVAILABLE");return;}
                if(++specialRetries<5)main.postDelayed(()->inspect(current),1350);
                else finish("UNKNOWN");
            });
            return;
        }
        if (store.equals("nakasima-inc.shop")
                || store.equals("www.torikan.net") || store.equals("torikan.net")) {
            current.evaluateJavascript(shopPurchaseJavascript(store), value -> {
                if(finished)return;
                if("\"AVAILABLE\"".equals(value)){finish("AVAILABLE");return;}
                // Fumuroya hydrates dynamic purchase controls after page load.
                // Repeat only in this store; other successful site modes unchanged.
                if(store.equals("eshop.fumuroya.com") && ++specialRetries<5)
                    main.postDelayed(()->inspect(current),1350);
                else finish("UNKNOWN");
            });
            return;
        }
        if (expectedMarketplace != null) {
            String siteJs= expectedMarketplace.site==MarketplaceIdentity.Site.AMAZON ? AmazonDomSelectors.stock(expectedMarketplace.id)
                    : expectedMarketplace.site==MarketplaceIdentity.Site.RAKUTEN ? RakutenDomSelectors.stock()
                    : expectedMarketplace.site==MarketplaceIdentity.Site.YAHOO ? YahooDomSelectors.stock() : null;
            if(siteJs==null){finish("UNKNOWN");return;}
            current.evaluateJavascript(siteJs,v->finish("\"AVAILABLE\"".equals(v) ? "AVAILABLE" : "UNKNOWN"));
            return;
        }
        // GENERAL: DOM-based, product-local purchase verification. Independent
        // from name/image/price and isolated from the marketplace selectors.
        // A = unchanged GENERAL.  Only when A has no purchase proof, inspect
        // independently ported store strategies B..F on this SAME WebView.
        generalInspectionPending = true;
        generalInspectionRounds++;
        // A always executes first, including previously unseen URL shapes.
        // On an unrecognized URL its result is only provisional until a later
        // stage confirms an exact product identity; never trust listing carts.
        final boolean recognizedItemUrl = WishlistCrawler.isSingleProductPage(originalAlphabetUrl());
        current.evaluateJavascript(WishlistGeneralPurchaseDom.javascript(), value -> {
            if (finished || current != web) return;
            // MUJI may show a usable "add to cart" control when stock is
            // unavailable. NITORI/CAINZ also have stock/fulfillment variants.
            // Require positive item-specific evidence from later strategies.
            boolean needsStockProof = "zozo.jp".equals(originHost)
                    || "www.zozo.jp".equals(originHost)
                    || "muji.com".equals(originHost)
                    || "www.muji.com".equals(originHost)
                    || "nitori-net.jp".equals(originHost)
                    || "www.nitori-net.jp".equals(originHost)
                    || "cainz.com".equals(originHost)
                    || "www.cainz.com".equals(originHost);
            if ("\"AVAILABLE\"".equals(value) && !needsStockProof && recognizedItemUrl) {
                trace("alphabet", "stage=A result=AVAILABLE");
                finish("AVAILABLE");
            } else {
                trace("alphabet", "stage=A result="
                        + ("\"AVAILABLE\"".equals(value) ? "UNVERIFIED" : "UNKNOWN"));
                inspectAlphabet(current, 0);
            }
        });
    }

    /** Dedicated Edion/AU/ZOZO only: each merchant's identity + purchase proof,
     * no A-G fallback or cross-shop inference. Price/image remain untouched. */
    private void inspectDedicated(WebView current) {
        if (finished || current != web || generalInspectionPending || !allowed(current.getUrl())) return;
        final URL original = originalAlphabetUrl();
        final WishlistRetailDedicatedMode merchant = WishlistRetailDedicatedMode.forUrl(original);
        if (merchant == WishlistRetailDedicatedMode.NONE) { finish("UNKNOWN"); return; }
        generalInspectionPending = true;
        try {
            current.evaluateJavascript(WishlistRetailDedicatedStockDom.javascript(original), value -> {
                generalInspectionPending = false;
                if (finished || current != web) return;
                String status="UNKNOWN", reason="unreadable";
                boolean idBound=false, variantBound=false;
                int carts=0, pairs=0;
                try {
                    Object raw=new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    if (raw instanceof String) {
                        org.json.JSONObject o=new org.json.JSONObject((String)raw);
                        status=o.optString("status","UNKNOWN");
                        reason=o.optString("reason","unreadable");
                        idBound=o.optBoolean("idBound",false);
                        variantBound=o.optBoolean("variantBound",false);
                        carts=o.optInt("liveCarts",0);pairs=o.optInt("stockPairs",0);
                    }
                } catch (Exception ignored) { }
                if (!reason.matches("[a-z0-9-]{1,55}")) reason="unreadable";
                trace("dedicated", "mode="+merchant+" status="+status+" reason="+reason
                        +" id="+idBound+" variant="+variantBound
                        +" carts="+carts+" pairs="+pairs
                        +" attempt="+(++generalInspectionRounds));
                if ("AVAILABLE".equals(status) && idBound && variantBound && pairs > 0) {
                    finish("AVAILABLE");return;
                }
                // A failure cannot overwrite previously successful data.
                if (generalInspectionRounds < 5)
                    main.postDelayed(() -> inspect(current), 1050L);
                else finish("UNKNOWN");
            });
        } catch (Exception ignored) {
            generalInspectionPending=false;
            trace("dedicated", "mode="+merchant+" status=UNKNOWN reason=script-error");
            finish("UNKNOWN");
        }
    }

    /** Serial A->B..G evidence techniques, one verified document and bounded WebView. */
    private void inspectAlphabet(WebView current, int index) {
        if (finished || current != web || !allowed(current.getUrl())) {
            generalInspectionPending = false;
            return;
        }
        if (index >= WishlistGeneralAlphabetDom.FALLBACK_ORDER.length) {
            generalInspectionPending = false;
            // A one-time observation immediately after the FIRST A-G pass:
            // stock probe deadlines are often reached before seven rounds.
            // This is diagnostics only; the result can NEVER upgrade UNKNOWN.
            java.net.URL url = originalAlphabetUrl();
            if (!identityAuditDone && WishlistRetailStockIdentityAuditDom.supports(url)) {
                identityAuditDone = true;
                current.evaluateJavascript(WishlistRetailStockIdentityAuditDom.javascript(url), value -> {
                    if (finished || current != web) return;
                    String summary = "reason=unreadable";
                    try {
                        Object raw = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                        org.json.JSONObject o = new org.json.JSONObject((String) raw);
                        String reason = o.optString("reason", "unreadable");
                        if (!reason.matches("[a-z0-9-]{1,35}")) reason = "unreadable";
                        String canonical = o.optString("canonical", "missing");
                        if (!canonical.matches("[a-z0-9-]{1,20}")) canonical = "unreadable";
                        summary = "reason="+reason+" document="+o.optBoolean("sameDocument",false)
                            +" canonical="+canonical+" headings="+o.optInt("heading",0)
                            +" itemClaim="+o.optBoolean("itemClaim",false)
                            +" schema="+o.optBoolean("productSchema",false)
                            +" activeAdd="+o.optInt("activeAdd",0)
                            +" hiddenAdd="+o.optInt("hiddenAdd",0)
                            +" selectedVariant="+o.optBoolean("selectedVariant",false);
                    } catch (Exception ignored) { }
                    trace("identity.audit", summary);
                    if (generalInspectionRounds < 7)
                        main.postDelayed(() -> inspect(current), 1350L);
                    else finish("UNKNOWN");
                });
            } else if (generalInspectionRounds < 7) {
                main.postDelayed(() -> inspect(current), 1350L);
            } else finish("UNKNOWN");
            return;
        }
        final char stage = WishlistGeneralAlphabetDom.FALLBACK_ORDER[index];
        try {
            String script = WishlistGeneralAlphabetDom.source(originalAlphabetUrl(), stage);
            current.evaluateJavascript(script, value -> {
                if (finished || current != web) return;
                String status = "UNKNOWN", reason = "unreadable";
                try {
                    Object raw = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    org.json.JSONObject out = new org.json.JSONObject((String)raw);
                    status = out.optString("status", "UNKNOWN");
                    reason = out.optString("reason", "no-evidence");
                } catch (Exception ignored) { }
                // Only fixed, bounded reason codes; never log page text or values.
                if (!reason.matches("[a-z0-9-]{1,55}")) reason = "unreadable";
                String evidence = "";
                try {
                    Object rawEvidence = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    if (rawEvidence instanceof String) {
                        org.json.JSONObject ev = new org.json.JSONObject((String) rawEvidence);
                        evidence = " product="+ev.optBoolean("product",false)
                                +" sku="+ev.optBoolean("sku",false)
                                +" cart="+ev.optInt("cart",0)
                                +" dedup="+ev.optInt("duplicateCart",0)
                                +" hidden="+ev.optInt("hiddenCart",0)
                                +" disabled="+ev.optInt("disabledCart",0)
                                +" enabled="+ev.optInt("enabled",0)
                                +" qty="+ev.optInt("quantity",0)
                                +" stock="+ev.optBoolean("positive",false)
                                +" negative="+ev.optBoolean("negative",false)
                                +" json="+ev.optBoolean("jsonBound",false)
                                +" stockSrc="+ev.optString("stockSource","none")
                                +" idProof="+ev.optString("identity","none")
                                +" claims="+ev.optInt("claimCount",0)
                                +" action="+ev.optString("cartKind","none")
                                +" linksIgnored="+ev.optInt("skippedLinks",0)
                                +" outsideCart="+ev.optInt("outsideCart",0)
                                +(stage == 'G' ? " zozoId="+ev.optBoolean("idBound",false)
                                        +" variant="+ev.optBoolean("variantBound",false)
                                        +" stockPairs="+ev.optInt("stockPairs",0)
                                        +" didRequired="+ev.optBoolean("didRequired",false) : "");
                    }
                } catch (Exception ignored) { }
                trace("alphabet", "stage="+stage+" technique="
                        +WishlistGeneralEvidenceTechniques.label(stage)
                        +" result="+status+" reason="+reason+evidence);
                if ("AVAILABLE".equals(status)) finish("AVAILABLE");
                else inspectAlphabet(current, index + 1);
            });
        } catch (Exception ignored) {
            trace("alphabet", "stage="+stage+" technique="
                    +WishlistGeneralEvidenceTechniques.label(stage)
                    +" result=UNKNOWN reason=script-error");
            inspectAlphabet(current, index + 1);
        }
    }

    /** Isolated MUJI adapter: never invokes GENERAL alphabet scripts or clicks checkout. */
    private void inspectMuji(WebView current) {
        final URL url = originalAlphabetUrl();
        if (url == null || !WishlistMode.isMujiProduct(url)) { finish("UNKNOWN"); return; }
        if (mujiInspectionRunning) return;
        mujiInspectionRunning = true;
        try {
            current.evaluateJavascript(MujiProductDom.stockEvidence(url), value -> {
                mujiInspectionRunning = false;
                if (finished || current != web) return;
                String status = "UNKNOWN", reason = "unreadable";
                String evidence = "";
                try {
                    Object obj = new org.json.JSONTokener(value == null ? "null" : value).nextValue();
                    org.json.JSONObject o = new org.json.JSONObject((String) obj);
                    status = o.optString("status", "UNKNOWN");
                    reason = o.optString("reason", "unreadable");
                    evidence = " product="+o.optBoolean("product",false)
                            +" sku="+o.optBoolean("sku",false)
                            +" cart="+o.optInt("cart",0)
                            +" enabled="+o.optInt("enabled",0)
                            +" hidden="+o.optInt("hidden",0)
                            +" disabled="+o.optInt("disabled",0)
                            +" qty="+o.optInt("quantity",0)
                            +" stock="+o.optBoolean("positive",false)
                            +" negative="+o.optBoolean("negative",false)
                            +" jsonProduct="+o.optBoolean("jsonProduct",false)
                            +" jsonStock="+o.optBoolean("jsonStock",false)
                            +" stockSrc="+o.optString("stockSource","none");
                } catch (Exception ignored) { }
                if (!reason.matches("[a-z0-9-]{1,55}")) reason = "unreadable";
                trace("muji.evidence", "attempt="+(specialRetries+1)
                        +" status="+status+" reason="+reason+evidence);
                if ("AVAILABLE".equals(status)) { finish("AVAILABLE"); return; }
                // UNKNOWN is deliberately the fallback even if a cart button is live:
                // MUJI documents cart buttons that remain active when stock is empty.
                if (++specialRetries < 6) main.postDelayed(() -> inspect(current), 1250L);
                else finish("UNKNOWN");
            });
        } catch (Exception ignored) {
            mujiInspectionRunning = false;
            trace("muji.evidence", "reason=script-error");
            if (++specialRetries < 6) main.postDelayed(() -> inspect(current), 1250L);
            else finish("UNKNOWN");
        }
    }

    /** JS inspects only the *visible* purchase UI of the known product detail page.
     * No click is sent; the app never makes a purchase or adds items to a cart. */
    private static String shopPurchaseJavascript(String host) {
        String shop = host.replace("'", "");
        return "(function(){try{" +
                "var host='" + shop + "';" +
                "function visible(e){if(!e||e.disabled||e.getAttribute('aria-disabled')==='true'||!e.getClientRects().length)return false;" +
                "for(var p=e;p;p=p.parentElement){var s=getComputedStyle(p);" +
                "if(s.display==='none'||s.visibility==='hidden'||p.hidden||Number(s.opacity)===0)return false;}return true;}" +
                "var main=document.querySelector('main,#main,#contents,[role=main],#product_detail,#productDetail,.product-detail,.item-detail');" +
                "if(!main)main=document.body;if(!main)return 'UNKNOWN';" +
                "var product=main.querySelector('#product_detail,#productDetail,.product-detail,.item-detail,.product-info,.detail-item,.product__detail')||main;" +
                "var controls=product.querySelectorAll('button,input[type=submit],input[type=button],a[href],[role=button]');" +
                "var label=/(?:カートに入れる|買い物かごに入れる|かごに入れる|購入する|注文する|add\\s+to\\s+cart)/i;" +
                "var count=0;for(var i=0;i<controls.length&&i<130;i++){var b=controls[i];" +
                "if(!visible(b))continue;var name=(b.innerText||b.textContent||b.value||'')+' '+(b.getAttribute('aria-label')||'');" +
                "if(!label.test(name))continue;" +
                "if(b.closest('nav,header,footer,[class*=related],[class*=recommend],[id*=related],[id*=recommend]'))continue;" +
                "var group=b.closest('form,.purchase,.cart,.buy,.product-detail,.item-detail')||b.parentElement;" +
                "if(!group||!product.contains(group))continue;" +
                "var nearby=group.querySelector('input[type=number],input[name*=quantity],input[name*=Quantity],input[name*=qty],select[name*=quantity]');" +
                "if(!nearby){var previous=b.parentElement;for(var k=0;k<4&&previous&&product.contains(previous);k++,previous=previous.parentElement){" +
                "nearby=previous.querySelector('input[type=number],input[name*=quantity],input[name*=qty]');if(nearby)break;}}" +
                "if(!nearby){var quantities=product.querySelectorAll('input[type=number],input[name*=quantity],input[name*=qty],input[id*=quantity]');" +
                "if(quantities.length===1)nearby=quantities[0];}" +
                "if(!nearby&&!group.matches('form'))continue;" +
                "var notices=group.querySelectorAll('[class*=stock],[class*=sold],[class*=out-of-stock],[id*=stock]');" +
                "var sold=false;for(var z=0;z<notices.length&&z<25;z++){" +
                "if(visible(notices[z])&&/(?:売り切れ|売切れ|完売|在庫切れ|sold\\s*out)/i.test(notices[z].textContent||''))sold=true;}" +
                "if(sold)continue;" +

                "count++;break;}return count===1?'AVAILABLE':'UNKNOWN';" +
                "}catch(e){return 'UNKNOWN';}})()";
    }

    /** Read after Callback.completed; never supplies an unverified page title. */
    public String verifiedProductTitle() { return verifiedProductTitle; }
    /** Only from the exact saved EDION / ISETAN rendered product DOM. */
    public Long verifiedProductPrice() { return verifiedProductPrice; }

    private void finish(String status) {
        if (finished) return;
        // The page has already been rendered for its independent stock analysis.
        // Capture an exact-item title before destroying the SAME WebView; do not
        // start another request or modify the stock result when title is absent.
        if (!titleCaptureAttempted && callback != null && web != null
                && allowed(web.getUrl())) {
            URL original=originalAlphabetUrl();
            final boolean merchantMetadata=WishlistRetailVerifiedMetadataDom.supports(original);
            if (WishlistRetailProductTitleDom.supports(original) || merchantMetadata) {
                titleCaptureAttempted=true;
                final WebView inspecting=web;
                final boolean[] resolved={false};
                final Runnable fallback=() -> {
                    if (!resolved[0] && !finished) {resolved[0]=true;completeFinish(status);}
                };
                main.removeCallbacks(timeout);
                main.postDelayed(fallback, 1100L);
                try {
                    inspecting.evaluateJavascript(merchantMetadata
                            ? WishlistRetailVerifiedMetadataDom.javascript(original)
                            : WishlistRetailProductTitleDom.javascript(original), value -> {
                        if (resolved[0] || finished || inspecting!=web) return;
                        resolved[0]=true;
                        main.removeCallbacks(fallback);
                        String reason="unreadable";
                        try {
                            Object raw=new org.json.JSONTokener(value==null?"null":value).nextValue();
                            if (raw instanceof String) {
                                org.json.JSONObject result=new org.json.JSONObject((String)raw);
                                reason=result.optString("reason","unreadable");
                                String name=result.optString("title","").trim();
                                if (("verified-rendered-heading".equals(reason)
                                        || (merchantMetadata && ("item-heading-verified".equals(reason)
                                            || "conflicting-gross-prices".equals(reason))))
                                        && name.length()>=3 && name.length()<=240)
                                    verifiedProductTitle=name;
                                if (merchantMetadata && !result.isNull("price")) {
                                    long recovered=result.optLong("price",0L);
                                    if (recovered>=50L && recovered<=100000000L)
                                        verifiedProductPrice=recovered;
                                }
                            }
                        }catch(Exception ignored) { }
                        trace("product.name", "verified="+(verifiedProductTitle!=null)
                                +" merchantMetadata="+merchantMetadata
                                +" price="+(verifiedProductPrice!=null)
                                +" reason="+(reason.matches("[a-z0-9-]{1,55}")?reason:"unreadable"));
                        completeFinish(status);
                    });
                } catch(Exception ignored) {
                    main.removeCallbacks(fallback);resolved[0]=true;completeFinish(status);
                }
                return;
            }
        }
        completeFinish(status);
    }

    private void completeFinish(String status) {
        if (finished) return;
        if (rawAuditEnabled) {
            String verdict = "status=" + status + " examined=" + auditReceived
                    + " samples=" + auditElements + " enabledProductCartCandidate="
                    + auditProductCartEnabled + " namedPurchase=" + auditPurchaseNamed;
            // Raw DOM presence is never itself an availability decision.
            if (auditProductCartEnabled && "UNKNOWN".equals(status))
                verdict += " discrepancy=classifier-or-product-binding";
            else if (!auditReceived) verdict += " discrepancy=not-inspected";
            trace("dom.audit.verdict", verdict);
        }
        finished = true;
        main.removeCallbacks(timeout);
        WebView old = web;
        web = null;
        if (old != null) {
            old.stopLoading();
            old.setWebViewClient(new WebViewClient());
            
            old.destroy();
        }
        Callback done = callback;
        callback = null;
        if (done != null) done.completed(status);
    }

    public void cancel() {
        if (Looper.myLooper() != Looper.getMainLooper()) return;
        callback = null;
        finish("UNKNOWN");
    }
}
