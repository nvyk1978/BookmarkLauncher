package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Shared HTML string primitives ONLY, no shared retailer extraction policy. */
final class LargeRetailHtml {
    private static final Pattern TAG = Pattern.compile("(?is)<(?:meta|link)\\b[^>]*>");
    private static final Pattern ATTR = Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))",Pattern.CASE_INSENSITIVE);
    private LargeRetailHtml() { }
    static String attr(String tag,String field) {
        Matcher m=ATTR.matcher(tag);
        while(m.find())if(field.equalsIgnoreCase(m.group(1)))return unescape(first(m.group(2),m.group(3),m.group(4)));
        return null;
    }
    static String first(String... values) {
        for(String v:values)if(v!=null&&!v.isBlank())return v;
        return null;
    }
    static String unescape(String value) {
        if(value==null)return null;
        return value.replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'")
                .replace("&lt;","<").replace("&gt;",">").replaceAll("\\s+"," ").trim();
    }
    static String meta(String html,String key) {
        if(html==null)return null;
        Matcher m=TAG.matcher(html);
        while(m.find()){
            String tag=m.group();
            if(key.equalsIgnoreCase(first(attr(tag,"property"),attr(tag,"name"),attr(tag,"itemprop"))))
                return attr(tag,"content");
        }
        return null;
    }
    static String ogTitle(String html) {return meta(html,"og:title");}
    static String mainImage(String html,String site) {
        String image=meta(html,"og:image");
        if(image==null||!image.startsWith("https://"))return null;
        try{
            String host=new URL(image).getHost().toLowerCase(Locale.ROOT);
            if(site.equals("UNIQLO") && !(host.equals("image.uniqlo.com")||host.endsWith(".uniqlo.com")))return null;
            if(site.equals("YODOBASHI") && !(host.endsWith(".yodobashi.com")||host.equals("yodobashi.com")))return null;
            if(site.equals("BICCAMERA") && !(host.endsWith(".biccamera.com")||host.equals("biccamera.com")))return null;
            return image;
        }catch(Exception ignored){return null;}
    }
    static Long metaYenPrice(String html) {
        String money=first(meta(html,"product:price:amount"),meta(html,"og:price:amount"));
        String currency=first(meta(html,"product:price:currency"),meta(html,"og:price:currency"));
        if(!"JPY".equalsIgnoreCase(currency)||money==null)return null;
        try{double n=Double.parseDouble(money.replace(",",""));return n>0&&n<100000000&&n==Math.rint(n)?(long)n:null;}
        catch(Exception ignored){return null;}
    }
    static boolean validCanonical(String html,URL requested) {
        Matcher m=TAG.matcher(html);
        while(m.find()){
            String tag=m.group();
            if(!"canonical".equalsIgnoreCase(attr(tag,"rel")))continue;
            String href=attr(tag,"href");
            if(href==null)return true;
            try{
                URL candidate=new URL(requested,href);
                return WishlistMode.sameLargeRetailProduct(requested,candidate);
            }catch(Exception ignored){return false;}
        }
        return true;
    }
    static String cleanTitle(String raw,String site){
        if(raw==null)return null;
        String result=unescape(raw).replaceAll("(?i)\\s*[\\|｜].*(?:通販|公式|ユニクロ|ヨドバシ|ビックカメラ).*$", "").trim();
        if(result.length()<3||result.length()>400||result.matches("(?is).*(captcha|access denied|robot check|アクセス制限).*"))return null;
        return result;
    }
}
