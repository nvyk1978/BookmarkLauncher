package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;

/** Isolated read-only ALI product snapshot. Exact item identity is mandatory;
 * no recommendation, global cart or promotional pricing may be committed. */
final class WishlistAliItemDom {
    private WishlistAliItemDom() { }
    static String javascript(URL saved) {
        if (WishlistGeneralMarketplaceIdentity.merchant(saved)
                != WishlistGeneralMarketplaceIdentity.Merchant.ALIEXPRESS) return "'{}'";
        String id=WishlistGeneralMarketplaceIdentity.itemId(saved);
        if (id == null) return "'{}'";
        return SCRIPT.replace("__ID__", id);
    }
    private static final String SCRIPT = """
(function(){'use strict';
const expected='__ID__',site='ALI';
const out={value:'',currency:'',title:'',reason:'id-unverified',source:'none',
 priceSource:'none',priceNodes:0,priceTokens:0,priceLabel:false,cartCount:0,jsonOffers:0,
 stockStatus:'UNKNOWN',stockReason:'no-item-bound-purchase-evidence',imageCandidates:[],
 itemEvidence:'none',pageKind:'unbound-url',verifiedReason:'product-data-unverified',
 canonical:'missing',canonicalRoute:'missing',heading:false,productNodes:0,
 ready:document.readyState||'unknown',bodyChars:0};
try{
 const family=(h)=>site==='TEMU'?(h==='temu.com'||h.endsWith('.temu.com')):
   (h==='aliexpress.com'||h.endsWith('.aliexpress.com'));
 const idOf=(raw)=>{try{
  const u=new URL(raw,location.href);
  if(u.protocol!=='https:'||!family(u.hostname.toLowerCase()))return '';
  if(site==='TEMU'){
    const p=u.pathname.match(/(?:^|\\/)\\S*-g-([0-9]{10,20})\\.html\\/?$/i)
      ||u.pathname.match(/^\\/(?:jp\\/)?g-([0-9]{10,20})\\.html\\/?$/i);
    if(p)return p[1];
    if(/^\\/(?:jp\\/)?(?:goods|product)(?:\\.html)?\\/?$/i.test(u.pathname))
      return /^\\d{10,20}$/.test(u.searchParams.get('goods_id')||'')?u.searchParams.get('goods_id'):'';
  }else{
    const p=u.pathname.match(/^\\/(?:p\\/)?(?:item|i)\\/([0-9]{9,19})\\.html\\/?$/i);
    if(p)return p[1];
    if(/^\\/(?:p\\/)?item(?:\\.html)?\\/?$/i.test(u.pathname))
      return /^\\d{9,19}$/.test(u.searchParams.get('productId')||'')?u.searchParams.get('productId'):'';
  }
  return '';
 }catch(_){return ''}};
 const current=idOf(location.href);
 out.pageKind=current===expected?'item-url':current?'other-item-url':'unbound-url';
 if(current&&current!==expected){out.reason='navigation-other-item';return JSON.stringify(out);}
 const canonicalNode=document.querySelector('link[rel="canonical"]');
 const canonicalUrl=canonicalNode&&(canonicalNode.href||canonicalNode.getAttribute('href'));
 if(canonicalUrl){const ci=idOf(canonicalUrl);
  out.canonical=ci===expected?'same-item':ci?'other-item':'non-item';
  try{const c=new URL(canonicalUrl,location.href);out.canonicalRoute=c.hostname.toLowerCase()+(ci?'/item':'/non-item');}catch(_){}
  if(ci&&ci!==expected){out.reason='canonical-other-item';return JSON.stringify(out);}
 }
 const bodyText=String(document.body&&(document.body.innerText||document.body.textContent)||'');
 out.bodyChars=bodyText.length;
 out.aliAudit={bodyChars:out.bodyChars,
  jsonLdNodes:document.querySelectorAll('script[type="application/ld+json"]').length,
  headings:document.querySelectorAll('h1').length,
  productPriceNodes:document.querySelectorAll('[itemprop="price"],[class*="product-price"]').length,
  hasRunParams:!!(typeof window!=='undefined' && window.runParams),
  appGate:/(?:open.*app|download.*app|アプリを開|アプリで開)/i.test(bodyText.slice(0,3000)),
  verifyGate:/(?:captcha|security check|verify you|認証|検証)/i.test(bodyText.slice(0,3000))};
 const pageTitle=String(document.title||'').slice(0,140);
 if(/(?:verify you are human|captcha|robot check|access denied|security check|security verification|人間であることを確認)/i.test(pageTitle)){
  out.reason='challenge-visible';return JSON.stringify(out);
 }
 const clean=s=>String(s||'').replace(/\\s+/g,' ').trim();
 const money=(raw,cur)=>{const s=clean(raw);
  if(!s||s.length>90||/(?:USD|EUR|GBP|\\$|€|£)/i.test(s))return '';
  if(String(cur||'').toUpperCase()!=='JPY'&&!/[¥￥円]/.test(s))return '';
  if(/\\d+\\.\\d*[1-9]/.test(s))return '';
  const m=s.match(/^(?:[¥￥]\\s*)?([0-9][0-9,]*)(?:\\.0+)?\\s*円?$/);
  if(!m)return '';
  const n=Number(m[1].replace(/,/g,''));
  return Number.isSafeInteger(n)&&n>=1&&n<=100000000?'¥'+n:'';
 };
 // A schema.org Offer may store its price in priceSpecification, or
 // use equal low/high bounds rather than a direct price. Read ONLY its
 // own JPY offer and reject any conflicting amounts/ranges.
 const offerMoney=(offer)=>{
  if(!offer||typeof offer!=='object')return '';
  const cur=String(offer.priceCurrency||'').toUpperCase();
  const amounts=[];
  const add=(v,c)=>{const m=money(v,c);if(m)amounts.push(m);};
  add(offer.price,cur);
  const specs=Array.isArray(offer.priceSpecification)?offer.priceSpecification:[offer.priceSpecification];
  for(const spec of specs.slice(0,4))if(spec&&typeof spec==='object'){
   const c=String(spec.priceCurrency||cur).toUpperCase();
   add(spec.price,c);
   if(spec.minPrice!=null && spec.maxPrice!=null){
    const lo=money(spec.minPrice,c),hi=money(spec.maxPrice,c);
    if(lo&&hi&&lo===hi)amounts.push(lo);
   }
  }
  if(offer.lowPrice!=null && offer.highPrice!=null){
   const lo=money(offer.lowPrice,cur),hi=money(offer.highPrice,cur);
   if(lo&&hi&&lo===hi)amounts.push(lo);
   else return ''; // Genuine price range: no single current price.
  }
  if(!amounts.length || new Set(amounts).size!==1)return '';
  // Avoid accepting JPY amount when another explicit offer currency says USD.
  if(cur && cur!=='JPY')return '';
  return amounts[0];
 };
 const safeImage=(raw)=>{try{
  if(typeof raw==='object'&&raw)raw=raw.url||raw.contentUrl||raw.src;
  if(typeof raw!=='string'||!raw)return '';
  const u=new URL(raw,location.href);
  if(u.protocol!=='https:'||/(?:logo|banner|sprite|icon|avatar|campaign|promot|placeholder|spacer|noimage|tracking|payment|favicon)/i.test(u.pathname))return '';
  if(/\\.(?:svg|gif)(?:$|[?#])/i.test(u.pathname))return '';
  return u.href;
 }catch(_){return ''}};
 const imageSet=new Set();
 const addImage=(raw)=>{const u=safeImage(raw);if(u&&imageSet.size<6)imageSet.add(u);};
 const titleOK=s=>{s=clean(s);return s.length>=8&&s.length<=240
  &&!(/^(?:home|temu|aliexpress|shopping cart|sign in|login|my orders)$/i.test(s))?s:'';};
 // Only Product records whose OWN link contains the exact requested product ID.
 const matchedProducts=[],unlinkedProducts=[];
 const visit=(o,d)=>{if(!o||d>7||matchedProducts.length>12)return;
  if(Array.isArray(o)){for(const v of o.slice(0,25))visit(v,d+1);return;}
  if(typeof o!=='object')return;
  const typ=String(o['@type']||'').toLowerCase();
  if(typ==='product'||typ.endsWith('/product')){
   out.productNodes++;
   const links=[o.url,o['@id'],o.mainEntityOfPage].map(x=>typeof x==='object'&&x?(x['@id']||x.url):x);
   // Merchants sometimes omit the Product URL in JSON-LD but expose the
   // exact stable item ID as a field. A generic Product without URL or ID
   // is NOT enough: search/recommendation payloads can be present on the page.
   const explicitIds=[o.productId,o.goodsId,o.goods_id,o.itemId,o.item_id,o.sku]
    .filter(x=>typeof x==='string'||typeof x==='number').map(String);
   if(links.some(u=>u&&idOf(u)===expected)
      ||(current===expected&&explicitIds.includes(expected)))matchedProducts.push(o);
   else if(current===expected && links.every(x=>!x)
           && ![o.productId,o.goodsId,o.goods_id,o.itemId,o.item_id]
              .some(x=>x!=null && String(x).trim())) unlinkedProducts.push(o);
  }
  for(const key of ['@graph','mainEntity','item'])if(o[key])visit(o[key],d+1);
 };
 for(const el of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,20)){
  try{if((el.textContent||'').length<1400000)visit(JSON.parse(el.textContent||''),0);}catch(_){}
 }
 out.aliAudit.boundProductRecords=matchedProducts.length;
 out.aliAudit.unlinkedProductRecords=unlinkedProducts.length;
 // Only redacted STRUCTURAL information. Do not log a merchant's raw name,
 // price, offer payload or HTML. Diagnose whether the single unlinked
 // Product is missing an identity-bearing name or an unambiguous JPY offer.
 const loneUnlinked=unlinkedProducts.length===1?unlinkedProducts[0]:null;
 const loneOffers=loneUnlinked?(Array.isArray(loneUnlinked.offers)
      ?loneUnlinked.offers:[loneUnlinked.offers]):[];
 const loneAmounts=new Set();
 for(const x of loneOffers.slice(0,6))if(x&&typeof x==='object'){
  const amount=offerMoney(x);if(amount)loneAmounts.add(amount);
 }
 out.aliAudit.unlinkedHasName=!!(loneUnlinked&&titleOK(loneUnlinked.name));
 out.aliAudit.unlinkedOfferCount=Math.min(30,loneOffers.filter(x=>x&&typeof x==='object').length);
 out.aliAudit.unlinkedSingleJpyPrice=loneAmounts.size===1;
 const currencies=new Set(loneOffers.filter(x=>x&&typeof x==='object')
   .map(x=>String(x.priceCurrency||'').toUpperCase()).filter(x=>/^[A-Z]{3}$/.test(x)));
 out.aliAudit.unlinkedCurrency=currencies.size===1?[...currencies][0]:'NONE';
 out.aliAudit.unlinkedPriceShape=loneOffers.slice(0,4).some(x=>x&&typeof x==='object'
   && x.price!=null)?'direct':loneOffers.slice(0,4).some(x=>x&&typeof x==='object'
   && x.priceSpecification)?'specification':loneOffers.slice(0,4).some(x=>x&&typeof x==='object'
   && x.lowPrice!=null && x.highPrice!=null)?'range':'missing';
 // AliExpress often leaves HTML empty and hydrates window.runParams
 // asynchronously. A nonempty runParams is usable ONLY if its OWN action
 // module identifies the exact saved listing; the URL itself is insufficient.
 // Do not use cross-item recommendations, storefront prices or currencies.
 if(current===expected){
  const state=typeof window==='object'&&window.runParams;
  const data=state&&typeof state==='object'?(state.data||state):null;
  const action=data?(data.actionModule||data.actionComponent||{}):{};
  const ownId=String(action.productId||action.product_id||action.itemId||'');
  out.aliAudit.runParamsItem=ownId===expected;
  if(ownId===expected){
   const title=data.titleModule||data.titleComponent||{};
   const price=data.priceModule||data.priceComponent||{};
   const currency=data.currencyModule||data.currencyComponent||{};
   const images=data.imageModule||data.imageComponent||{};
   const name=titleOK(title.subject||title.title||title.name);
   const code=String(currency.currencyCode||price.currencyCode||'').toUpperCase();
   const prices=new Set();
   for(const raw of [price.formatedActivityPrice,price.formatedPrice,
                     price.formattedActivityPrice,price.formattedPrice,
                     price.activityPrice,price.currentPrice]){
    const candidate=typeof raw==='object'&&raw?
       (raw.formattedAmount||raw.value||raw.amountWithSymbol):raw;
    const amount=money(candidate,code);
    if(amount)prices.add(amount);
   }
   if(name)out.title=name;
   if(prices.size===1){out.value=[...prices][0];out.currency='JPY';
    out.priceSource='item-id-runparams';}
   for(const list of [images.imagePathList,images.imageList,images.images])
    if(Array.isArray(list))for(const src of list.slice(0,8))addImage(src);
   out.itemEvidence='verified-product';out.pageKind='item-url';
   out.verifiedReason='item-id-runparams';
  }
 }
 // Ali's real item response may contain exactly ONE URL-less Product with
 // name/image but an Offer whose JPY price is missing. Keep field trust
 // SEPARATE: a single item-page Product can provide a provisional title and
 // product image, but never stock or price without stronger evidence.
 // Require a current exact item URL, no competing Products or conflicting
 // product IDs, no canonical for a different item, and a non-challenge page.
 // A metadata-only Product MUST NOT qualify as a fully verified numbered mode.
 let metadataOnly=false;
 if(matchedProducts.length===0 && unlinkedProducts.length===1
    && out.productNodes===1 && current===expected && out.canonical!=='other-item'
    && !out.aliAudit.verifyGate && !out.aliAudit.appGate) {
  const single=unlinkedProducts[0],name=titleOK(single.name);
  const offers=Array.isArray(single.offers)?single.offers:[single.offers];
  const amounts=new Set();
  for(const offer of offers.slice(0,6))if(offer&&typeof offer==='object'){
   const amount=offerMoney(offer);if(amount)amounts.add(amount);
  }
  if(name && amounts.size===1){
   matchedProducts.push(single);
   out.verifiedReason='single-item-jsonld';
  } else if(name && amounts.size===0){
   // Never infer a price from JPY currency alone, a price range, or a cart.
   // A readable Product record can still supply non-financial metadata.
   out.title=name;
   const imgs=Array.isArray(single.image)?single.image:[single.image];
   for(const img of imgs.slice(0,8))addImage(img);
   metadataOnly=true;
   out.itemEvidence='item-url-metadata';
   out.verifiedReason='single-item-jsonld-metadata';
  }
 }
 out.aliAudit.metadataOnly=metadataOnly;
 const structuredPrices=new Set(), structuredNames=new Set(), structuredStocks=new Set();
 for(const p of matchedProducts){
  const name=titleOK(p.name);if(name)structuredNames.add(name);
  const imgs=Array.isArray(p.image)?p.image:[p.image];for(const img of imgs.slice(0,8))addImage(img);
  const offers=Array.isArray(p.offers)?p.offers:[p.offers];
  for(const offer of offers.slice(0,12))if(offer&&typeof offer==='object'){
   out.jsonOffers++;
   const v=offerMoney(offer);if(v)structuredPrices.add(v);
   const status=String(offer.availability||'').split('/').pop().toLowerCase();
   if(status==='instock'||status==='outofstock')structuredStocks.add(status);
  }
 }
 if(structuredNames.size===1)out.title=[...structuredNames][0];
 if(structuredPrices.size===1){out.value=[...structuredPrices][0];out.currency='JPY';out.priceSource='item-bound-jsonld';}
 if(structuredStocks.size===1){out.stockStatus=structuredStocks.has('instock')?'AVAILABLE':'UNAVAILABLE';
  out.stockReason='item-bound-jsonld';}
 // Rendered prices require the currently visited exact URL, a product H1,
 // and a product detail container. Never use generic search, promotion or headers.
 const h=[...document.querySelectorAll('main h1,[role="main"] h1,h1[class*="product"],h1')]
  .find(n=>titleOK(n.textContent)&&!n.closest('header,footer,nav,aside,[class*="recommend"],[class*="related"]'));
 out.heading=!!h;
 if(current===expected&&h){
  const main=h.closest('main,[role="main"],#root')||document.querySelector('main,[role="main"]');
  let local=h.closest(site==='TEMU'?'[class*="goods-detail"],[class*="product-detail"],[class*="GoodsDetail"],[class*="productDetail"]':
    '[class*="product-detail"],[class*="productDetail"],[class*="pdp"],[class*="product-info"]');
  // The nearest main region is allowed only if heading is genuinely inside it.
  if(!local&&main&&main.contains&&main.contains(h))local=main;
  if(local){
   if(!out.title)out.title=titleOK(h.textContent);
   const forbidden=e=>!!(e&&e.closest&&e.closest('header,footer,nav,aside,[class*="recommend"],[class*="related"],'
    +'[class*="similar"],[class*="carousel"],[class*="promo"],[class*="original"],[class*="old-price"],del,s'));
   const selectors=site==='TEMU'?['[data-testid*="price"]','[data-test*="price"]','[class*="price-current"]',
    '[class*="Price_current"]','[class*="priceNow"]','[class*="price-now"]','[class*="sale-price"]','[itemprop="price"]']:
    ['[class*="product-price"]','[class*="productPrice"]','[class*="uniform-banner-box-price"]',
     '[class*="price--current"]','[class*="sale-price"]','[data-testid*="price"]','[itemprop="price"]'];
   const rendered=new Set();
   for(const sel of selectors)for(const el of [...local.querySelectorAll(sel)].slice(0,10)){
    if(forbidden(el))continue;
    const raw=clean(el.getAttribute('content')||el.textContent||'');
    // A current price node must contain ONE JPY amount, not strike-through/discount combos.
    const mentions=raw.match(/[¥￥]\\s*\\d[\\d,]*|\\d[\\d,]*\\s*円/g)||[];
    if(mentions.length!==1)continue;
    const v=money(mentions[0],'');if(v)rendered.add(v);
   }
   out.priceNodes=rendered.size;
   if(rendered.size===1){const val=[...rendered][0];
    if(!out.value||out.value===val){out.value=val;out.currency='JPY';out.priceSource='item-local-price';}
    else{out.value='';out.currency='';out.priceSource='conflicting-item-prices';}
   }else if(rendered.size>1){out.value='';out.currency='';out.priceSource='conflicting-item-prices';}
   // Product-gallery only. No general main/OG images.
   const imgs=site==='TEMU'?['[data-testid*="product-image"] img','[class*="goods-detail"] [class*="gallery"] img',
    '[class*="product-gallery"] img','[class*="GoodsDetail"] [class*="image"] img']:
    ['[class*="magnifier"] img','[class*="images-view"] img','[class*="product-gallery"] img',
     '[data-testid*="product-image"] img'];
   for(const sel of imgs)for(const img of [...local.querySelectorAll(sel)].slice(0,12)){
    if(forbidden(img))continue;
    for(const att of ['data-original','data-src','data-zoom-image','src'])addImage(img.getAttribute(att));
    addImage(img.currentSrc);
   }
  }
 }
 out.imageCandidates=[...imageSet];
 if(matchedProducts.length===1){out.itemEvidence='verified-product';out.pageKind='item-bound-jsonld';
   if(out.verifiedReason!=='single-item-jsonld')out.verifiedReason='verified-product-metadata';}
 else if(metadataOnly){out.itemEvidence='item-url-metadata';out.pageKind='item-url';
   out.verifiedReason='single-item-jsonld-metadata';}
 else if(current===expected&&out.title&&out.itemEvidence!=='verified-product'){out.itemEvidence='item-url-title';out.verifiedReason='verified-product-metadata';}
 if(out.value||out.title){out.reason=out.value?'bound-price':'verified-dom-metadata';out.source=out.priceSource;}
 else out.reason=current===expected?'product-data-unverified':'id-unverified';
 out.priceTokens=out.value?1:0;
 return JSON.stringify(out);
}catch(_){out.reason='script-error';return JSON.stringify(out);}
})()
""";
}
