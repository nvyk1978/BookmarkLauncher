package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;

/** Isolated read-only ALI product snapshot. Exact item identity is mandatory;
 * no recommendation, global cart or promotional pricing may be committed. */
final class WishlistAliItemDom {
    private WishlistAliItemDom() { }
    static String javascript(URL saved) {
        if (WishlistGeneralMarketplaceIdentity.merchant(saved)
                != WishlistGeneralMarketplaceIdentity.Merchant.ALIEXPRESS) return "'{}'";
        String id=WishlistGeneralMarketplaceIdentity.itemId(saved);
        if (id == null) return "'{}'";
        return SCRIPT.replace("__ID__", id);
    }
    private static final String SCRIPT = """
(function(){'use strict';
const expected='__ID__',site='ALI';
const out={value:'',currency:'',title:'',reason:'id-unverified',source:'none',
 priceSource:'none',priceNodes:0,priceTokens:0,priceLabel:false,cartCount:0,jsonOffers:0,
 stockStatus:'UNKNOWN',stockReason:'no-item-bound-purchase-evidence',imageCandidates:[],
 itemEvidence:'none',pageKind:'unbound-url',verifiedReason:'product-data-unverified',
 canonical:'missing',canonicalRoute:'missing',heading:false,productNodes:0,
 ready:document.readyState||'unknown',bodyChars:0};
try{
 const family=(h)=>site==='TEMU'?(h==='temu.com'||h.endsWith('.temu.com')):
   (h==='aliexpress.com'||h.endsWith('.aliexpress.com'));
 const idOf=(raw)=>{try{
  const u=new URL(raw,location.href);
  if(u.protocol!=='https:'||!family(u.hostname.toLowerCase()))return '';
  if(site==='TEMU'){
    const p=u.pathname.match(/(?:^|\\/)\\S*-g-([0-9]{10,20})\\.html\\/?$/i)
      ||u.pathname.match(/^\\/(?:jp\\/)?g-([0-9]{10,20})\\.html\\/?$/i);
    if(p)return p[1];
    if(/^\\/(?:jp\\/)?(?:goods|product)(?:\\.html)?\\/?$/i.test(u.pathname))
      return /^\\d{10,20}$/.test(u.searchParams.get('goods_id')||'')?u.searchParams.get('goods_id'):'';
  }else{
    const p=u.pathname.match(/^\\/(?:p\\/)?(?:item|i)\\/([0-9]{9,19})\\.html\\/?$/i);
    if(p)return p[1];
    if(/^\\/(?:p\\/)?item(?:\\.html)?\\/?$/i.test(u.pathname))
      return /^\\d{9,19}$/.test(u.searchParams.get('productId')||'')?u.searchParams.get('productId'):'';
  }
  return '';
 }catch(_){return ''}};
 const current=idOf(location.href);
 out.pageKind=current===expected?'item-url':current?'other-item-url':'unbound-url';
 if(current&&current!==expected){out.reason='navigation-other-item';return JSON.stringify(out);}
 const canonicalNode=document.querySelector('link[rel="canonical"]');
 const canonicalUrl=canonicalNode&&(canonicalNode.href||canonicalNode.getAttribute('href'));
 if(canonicalUrl){const ci=idOf(canonicalUrl);
  out.canonical=ci===expected?'same-item':ci?'other-item':'non-item';
  try{const c=new URL(canonicalUrl,location.href);out.canonicalRoute=c.hostname.toLowerCase()+(ci?'/item':'/non-item');}catch(_){}
  if(ci&&ci!==expected){out.reason='canonical-other-item';return JSON.stringify(out);}
 }
 const bodyText=String(document.body&&(document.body.innerText||document.body.textContent)||'');
 out.bodyChars=bodyText.length;
 const pageTitle=String(document.title||'').slice(0,140);
 if(/(?:verify you are human|captcha|robot check|access denied|security check|security verification|人間であることを確認)/i.test(pageTitle)){
  out.reason='challenge-visible';return JSON.stringify(out);
 }
 const clean=s=>String(s||'').replace(/\\s+/g,' ').trim();
 const money=(raw,cur)=>{const s=clean(raw);
  if(!s||s.length>90||/(?:USD|EUR|GBP|\\$|€|£)/i.test(s))return '';
  if(String(cur||'').toUpperCase()!=='JPY'&&!/[¥￥円]/.test(s))return '';
  if(/\\d+\\.\\d*[1-9]/.test(s))return '';
  const m=s.match(/^(?:[¥￥]\\s*)?([0-9][0-9,]*)(?:\\.0+)?\\s*円?$/);
  if(!m)return '';
  const n=Number(m[1].replace(/,/g,''));
  return Number.isSafeInteger(n)&&n>=1&&n<=100000000?'¥'+n:'';
 };
 const safeImage=(raw)=>{try{
  if(typeof raw==='object'&&raw)raw=raw.url||raw.contentUrl||raw.src;
  if(typeof raw!=='string'||!raw)return '';
  const u=new URL(raw,location.href);
  if(u.protocol!=='https:'||/(?:logo|banner|sprite|icon|avatar|campaign|promot|placeholder|spacer|noimage|tracking|payment|favicon)/i.test(u.pathname))return '';
  if(/\\.(?:svg|gif)(?:$|[?#])/i.test(u.pathname))return '';
  return u.href;
 }catch(_){return ''}};
 const imageSet=new Set();
 const addImage=(raw)=>{const u=safeImage(raw);if(u&&imageSet.size<6)imageSet.add(u);};
 const titleOK=s=>{s=clean(s);return s.length>=8&&s.length<=240
  &&!(/^(?:home|temu|aliexpress|shopping cart|sign in|login|my orders)$/i.test(s))?s:'';};
 // Only Product records whose OWN link contains the exact requested product ID.
 const matchedProducts=[];
 const visit=(o,d)=>{if(!o||d>7||matchedProducts.length>12)return;
  if(Array.isArray(o)){for(const v of o.slice(0,25))visit(v,d+1);return;}
  if(typeof o!=='object')return;
  const typ=String(o['@type']||'').toLowerCase();
  if(typ==='product'||typ.endsWith('/product')){
   out.productNodes++;
   const links=[o.url,o['@id'],o.mainEntityOfPage].map(x=>typeof x==='object'&&x?(x['@id']||x.url):x);
   if(links.some(u=>u&&idOf(u)===expected))matchedProducts.push(o);
  }
  for(const key of ['@graph','mainEntity','item'])if(o[key])visit(o[key],d+1);
 };
 for(const el of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,20)){
  try{if((el.textContent||'').length<1400000)visit(JSON.parse(el.textContent||''),0);}catch(_){}
 }
 const structuredPrices=new Set(), structuredNames=new Set(), structuredStocks=new Set();
 for(const p of matchedProducts){
  const name=titleOK(p.name);if(name)structuredNames.add(name);
  const imgs=Array.isArray(p.image)?p.image:[p.image];for(const img of imgs.slice(0,8))addImage(img);
  const offers=Array.isArray(p.offers)?p.offers:[p.offers];
  for(const offer of offers.slice(0,12))if(offer&&typeof offer==='object'){
   out.jsonOffers++;
   const v=money(offer.price,offer.priceCurrency);if(v)structuredPrices.add(v);
   const status=String(offer.availability||'').split('/').pop().toLowerCase();
   if(status==='instock'||status==='outofstock')structuredStocks.add(status);
  }
 }
 if(structuredNames.size===1)out.title=[...structuredNames][0];
 if(structuredPrices.size===1){out.value=[...structuredPrices][0];out.currency='JPY';out.priceSource='item-bound-jsonld';}
 if(structuredStocks.size===1){out.stockStatus=structuredStocks.has('instock')?'AVAILABLE':'UNAVAILABLE';
  out.stockReason='item-bound-jsonld';}
 // Rendered prices require the currently visited exact URL, a product H1,
 // and a product detail container. Never use generic search, promotion or headers.
 const h=[...document.querySelectorAll('main h1,[role="main"] h1,h1[class*="product"],h1')]
  .find(n=>titleOK(n.textContent)&&!n.closest('header,footer,nav,aside,[class*="recommend"],[class*="related"]'));
 out.heading=!!h;
 if(current===expected&&h){
  const main=h.closest('main,[role="main"],#root')||document.querySelector('main,[role="main"]');
  let local=h.closest(site==='TEMU'?'[class*="goods-detail"],[class*="product-detail"],[class*="GoodsDetail"],[class*="productDetail"]':
    '[class*="product-detail"],[class*="productDetail"],[class*="pdp"],[class*="product-info"]');
  // The nearest main region is allowed only if heading is genuinely inside it.
  if(!local&&main&&main.contains&&main.contains(h))local=main;
  if(local){
   if(!out.title)out.title=titleOK(h.textContent);
   const forbidden=e=>!!(e&&e.closest&&e.closest('header,footer,nav,aside,[class*="recommend"],[class*="related"],'
    +'[class*="similar"],[class*="carousel"],[class*="promo"],[class*="original"],[class*="old-price"],del,s'));
   const selectors=site==='TEMU'?['[data-testid*="price"]','[data-test*="price"]','[class*="price-current"]',
    '[class*="Price_current"]','[class*="priceNow"]','[class*="price-now"]','[class*="sale-price"]','[itemprop="price"]']:
    ['[class*="product-price"]','[class*="productPrice"]','[class*="uniform-banner-box-price"]',
     '[class*="price--current"]','[class*="sale-price"]','[data-testid*="price"]','[itemprop="price"]'];
   const rendered=new Set();
   for(const sel of selectors)for(const el of [...local.querySelectorAll(sel)].slice(0,10)){
    if(forbidden(el))continue;
    const raw=clean(el.getAttribute('content')||el.textContent||'');
    // A current price node must contain ONE JPY amount, not strike-through/discount combos.
    const mentions=raw.match(/[¥￥]\\s*\\d[\\d,]*|\\d[\\d,]*\\s*円/g)||[];
    if(mentions.length!==1)continue;
    const v=money(mentions[0],'');if(v)rendered.add(v);
   }
   out.priceNodes=rendered.size;
   if(rendered.size===1){const val=[...rendered][0];
    if(!out.value||out.value===val){out.value=val;out.currency='JPY';out.priceSource='item-local-price';}
    else{out.value='';out.currency='';out.priceSource='conflicting-item-prices';}
   }else if(rendered.size>1){out.value='';out.currency='';out.priceSource='conflicting-item-prices';}
   // Product-gallery only. No general main/OG images.
   const imgs=site==='TEMU'?['[data-testid*="product-image"] img','[class*="goods-detail"] [class*="gallery"] img',
    '[class*="product-gallery"] img','[class*="GoodsDetail"] [class*="image"] img']:
    ['[class*="magnifier"] img','[class*="images-view"] img','[class*="product-gallery"] img',
     '[data-testid*="product-image"] img'];
   for(const sel of imgs)for(const img of [...local.querySelectorAll(sel)].slice(0,12)){
    if(forbidden(img))continue;
    for(const att of ['data-original','data-src','data-zoom-image','src'])addImage(img.getAttribute(att));
    addImage(img.currentSrc);
   }
  }
 }
 out.imageCandidates=[...imageSet];
 if(matchedProducts.length===1){out.itemEvidence='verified-product';out.pageKind='item-bound-jsonld';out.verifiedReason='verified-product-metadata';}
 else if(current===expected&&out.title){out.itemEvidence='item-url-title';out.verifiedReason='verified-product-metadata';}
 if(out.value||out.title){out.reason=out.value?'bound-price':'verified-dom-metadata';out.source=out.priceSource;}
 else out.reason=current===expected?'product-data-unverified':'id-unverified';
 out.priceTokens=out.value?1:0;
 return JSON.stringify(out);
}catch(_){out.reason='script-error';return JSON.stringify(out);}
})()
""";
}
