package com.cmyk.bookmarkslauncher.wishlist;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.view.View;
import android.view.ViewGroup;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.Locale;

/**
 * Foreground, single-product, user-invoked price probe only.
 * Never extracts or edits name/image/status. No background crawl or repeated retry loops.
 */
public final class WishlistPriceWebViewProbe {
    public interface Callback { void completed(Long price, WishlistRetailPriceQuote quote, String problem); }
    /** Only non-sensitive progress counters/status; caller associates with a card ID. */
    public interface Trace { void record(String stage, String safeEvidence); }
    private Trace trace;
    public void setTrace(Trace trace) { this.trace = trace; }
    private void trace(String stage, String evidence) { if (trace != null) trace.record(stage, evidence); }
    private final Handler main = new Handler(Looper.getMainLooper());
    private final FrameLayout parent;
    private WebView web;
    private Callback callback;
    private boolean finished;
    private int inspections;
    private static final int MAX_INSPECTIONS = 5;
    private static final int GENERAL_PRODUCT_INSPECTIONS = 11;
    private static final int RETAIL_INSPECTIONS = 13;
    private static final int INDEPENDENT_INSPECTIONS = 13;
    private boolean retail;
    private boolean independentShop;
    private boolean generalProduct;
    private boolean unknownGeneralDetail;
    private boolean inspectionPending;
    private boolean inspectionRunning;
    private String lastReason = "uninspected";
    private String lastMarketEvidence;
    private int stableMarketEvidence;
    private boolean sheinRegionalRetry;
    private int mainHttpCode;
    private String askulStockStatus = "UNKNOWN";
    private String verifiedAskulTitle;
    private String verifiedMarketplaceTitle;
    private boolean askulTitleStarted;
    private int askulStockInspections;
    private Runnable askulStockDeadline;
    /** The same-identity ASKUL price DOM may also confirm this SKU's purchase state. */
    public String askulStockStatus() { return askulStockStatus; }
    /** An exact saved-SKU product heading captured from this SAME ASKUL WebView. */
    public String verifiedAskulTitle() { return verifiedAskulTitle; }
    public String verifiedMarketplaceTitle() { return verifiedMarketplaceTitle; }
    private boolean isAskul() { return "askul.co.jp".equals(originalHost) || "www.askul.co.jp".equals(originalHost); }
    private String originalHost;
    private URL originalRetailUrl;
    private MarketplaceIdentity expectedMarketplace;
    private final Runnable timeout = () -> {
        trace("timeout", "attempts="+inspections+" mainHTTP="+mainHttpCode+" reason="+lastReason);
        finish(null, "WebView読み込みタイムアウト");
    };

    public WishlistPriceWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public void start(String urlText, WishlistMode mode, Callback onDone) {
        cancel();
        callback=onDone;
        finished=false;
        inspections=0;
        inspectionPending=false;
        inspectionRunning=false;
        lastReason="uninspected";
        lastMarketEvidence=null;
        stableMarketEvidence=0;
        sheinRegionalRetry=false;
        mainHttpCode=0;
        askulStockStatus="UNKNOWN";
        verifiedAskulTitle=null;
        verifiedMarketplaceTitle=null;
        askulTitleStarted=false;
        askulStockInspections=0;
        askulStockDeadline=null;
        retail=false;
        independentShop=false;
        generalProduct=false;
        unknownGeneralDetail=false;
        if (Looper.myLooper()!=Looper.getMainLooper()) {
            finish(null,"WebViewはメインスレッド限定");return;
        }
        try {
            URL url=new URL(urlText);
            if (!WishlistCrawler.isAllowedUrl(url) || !"https".equalsIgnoreCase(url.getProtocol())) {
                finish(null,"安全なHTTPS URL以外は対象外");return;
            }
            if (mode == null || mode == WishlistMode.UNRESOLVED
                    || WishlistMode.forDirectUrl(urlText) != mode) {
                finish(null,"商品取得モードが保存済みモードと不一致");return;
            }
            originalHost=url.getHost().toLowerCase(Locale.ROOT);
            originalRetailUrl=url;
            trace("start", "mode="+mode+" savedMarketItem="
                    +WishlistGeneralMarketplaceIdentity.isDetail(url)
                    +" savedDetail="+WishlistCrawler.isSingleProductPage(url));
            retail=GeneralRetailIdentity.store(url)!=null;
            unknownGeneralDetail=mode==WishlistMode.GENERAL
                    && !WishlistCrawler.isSingleProductPage(url)
                    && WishlistGeneralVerifiedUnknownDom.candidate(url);
            generalProduct=(mode == WishlistMode.GENERAL || mode == WishlistMode.MUJI)
                    && (WishlistCrawler.isSingleProductPage(url) || unknownGeneralDetail);
            independentShop=mode==WishlistMode.GENERAL && (
                    ("eshop.fumuroya.com".equals(originalHost)
                            && url.getPath().matches("/product/detail/[0-9]+/?"))
                    || (("www.gojochoubei.co.jp".equals(originalHost)
                            || "gojochoubei.co.jp".equals(originalHost))
                            && url.getPath().matches("/view/item/[0-9]{12}/?")));
            expectedMarketplace=MarketplaceIdentity.from(url);
            if (MarketplaceIdentity.site(url)!=MarketplaceIdentity.Site.OTHER
                    && expectedMarketplace==null) { finish(null,"商品URLを特定できず");return; }
            trace("route", "generalProduct="+generalProduct+" marketHydration="
                    +(mode==WishlistMode.GENERAL
                       && WishlistGeneralMarketplaceIdentity.isDetail(url))
                    +" retail="+retail+" independent="+independentShop);
            web=BackgroundDomWebView.create(parent.getContext());

            // Detached DOM-only engine; no UI attachment or pixel extraction.


            web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setClickable(false);
            web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.setVerticalScrollBarEnabled(false);
            web.setHorizontalScrollBarEnabled(false);

            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request) {
                    if (!request.isForMainFrame()) return false;
                    return !allowedDestination(request.getUrl().toString());
                }
                @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap favicon) {
                    if (finished) return;
                    if (!allowedDestination(url)) {
                        trace("navigation.reject", "phase=started sameItem=false"); return;
                    }
                    if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)) {
                        String relation="invalid";
                        try { relation=WishlistGeneralMarketplaceIdentity.relation(
                                originalRetailUrl,new URL(url)).name(); } catch(Exception ignored) { }
                        trace("page.start", "marketRelation="+relation+" productUrl="
                                +"SAME".equals(relation));
                    }
                    if (retail || independentShop || generalProduct) {
                        trace("page.start", retail?"sameSku=true":
                                WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)
                                ? "marketNavigationChecked=true" : "sameItem=true");
                        // Some Japanese product sites never finish loading trackers;
                        // inspect the verified document before onPageFinished.
                        scheduleInspection(view, generalProduct && !retail && !independentShop ? 1800 : 1300);
                    }
                }
                @Override public void onPageFinished(WebView view,String url) {
                    if (finished) return;
                    if (!allowedDestination(url)) {
                        trace("navigation.reject", "phase=finished sameItem=false"); return;
                    }
                    if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)) {
                        String relation="invalid";
                        try { relation=WishlistGeneralMarketplaceIdentity.relation(
                                originalRetailUrl,new URL(url)).name(); } catch(Exception ignored) { }
                        trace("page.finished", "marketRelation="+relation+" attempts="+inspections);
                    }
                    if (retail || independentShop) trace("page.finished", "sameItem=true attempts="+inspections);
                    scheduleInspection(view,retail?350:independentShop?550:1400);
                }
                @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError error) {
                    if (req.isForMainFrame()) {
                        trace("network.error", "code="+error.getErrorCode());
                        finish(null,"WebView通信エラー");
                    }
                }
                @Override public void onReceivedHttpError(WebView view, WebResourceRequest req,
                                                           android.webkit.WebResourceResponse response) {
                    if (req.isForMainFrame() && originalRetailUrl != null
                            && (retail || WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))) {
                        mainHttpCode=response.getStatusCode();
                        trace("http", "code="+mainHttpCode);
                        RetailDiagnostics.general(originalRetailUrl, "price.webview.http",
                                "code="+mainHttpCode);
                    }
                }
            });
            main.postDelayed(timeout,retail?23000:independentShop?19000:
                    WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)?27000:
                    generalProduct?18000:14000);
            web.loadUrl(url.toString());
        }catch(Exception ex) {finish(null,"WebViewを開始できず");}
    }
    private boolean allowedDestination(String text) {
        try {
            URL dest=new URL(text);
            if(!"https".equalsIgnoreCase(dest.getProtocol()) || !WishlistCrawler.isAllowedUrl(dest))return false;
            String h=dest.getHost().toLowerCase(Locale.ROOT);
            if (expectedMarketplace!=null && !expectedMarketplace.matches(dest))return false;
            if(originalHost==null)return false;
            // Amazon sign-in / CAPTCHA redirects do not become new crawl targets.
            if(originalHost.equals("amazon.co.jp") || originalHost.endsWith(".amazon.co.jp"))
                return h.equals("amazon.co.jp") || h.endsWith(".amazon.co.jp");
            // The shop redirects category%3A<id> to category:<id> or removes
            // the category trail. Verify the internal product id, not text path.
            if (WishlistHonmaProductDom.isDetail(originalRetailUrl))
                return WishlistHonmaProductDom.sameItem(originalRetailUrl, dest);
            if (generalProduct && originalRetailUrl != null
                    && WishlistMode.isMujiProduct(originalRetailUrl)
                    && !originalRetailUrl.getPath().replaceAll("/+$", "")
                        .equalsIgnoreCase(dest.getPath().replaceAll("/+$", ""))) return false;
            if (unknownGeneralDetail && originalRetailUrl != null
                    && !WishlistGeneralVerifiedUnknownDom.samePage(originalRetailUrl, dest)) return false;
            if (independentShop && originalRetailUrl != null) {
                String expectedPath=originalRetailUrl.getPath().replaceAll("/+$", "");
                String actualPath=dest.getPath().replaceAll("/+$", "");
                if (!expectedPath.equalsIgnoreCase(actualPath)) return false;
            }
            WishlistGeneralMarketplaceIdentity.ItemRelation marketRelation = originalRetailUrl != null
                    && WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)
                    ? WishlistGeneralMarketplaceIdentity.relation(originalRetailUrl, dest) : null;
            // UNKNOWN URLs are inspected only within the original merchant family.
            // The item-bound JS refuses unbound page-wide names/prices, but a
            // verified same-item JSON state survives harmless URL rewriting.
            boolean guardedFamily = marketRelation != null
                    && marketRelation != WishlistGeneralMarketplaceIdentity.ItemRelation.DIFFERENT;
            return (h.equals(originalHost) || guardedFamily)
                    && (originalRetailUrl == null || GeneralRetailIdentity.store(originalRetailUrl) == null
                        || GeneralRetailIdentity.sameProduct(originalRetailUrl, dest))
                    && (marketRelation == null || guardedFamily);
        }catch(Exception ex){return false;}
    }
    private void scheduleInspection(WebView view,long millis) {
        if (finished || inspectionPending || inspectionRunning || web != view) return;
        inspectionPending=true;
        main.postDelayed(() -> {
            inspectionPending=false;
            if (!finished && view == web && !inspectionRunning) inspect(view);
        },millis);
    }

    private void inspect(WebView view) {
        if (finished || view != web || inspectionRunning) return;
        // Do not run page-wide generic selectors on a navigation that lost the
        // saved market item identity, even if the host is still the same.
        if ((retail || WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
                && (view.getUrl()==null || !allowedDestination(view.getUrl()))) {
            trace("dom.skip", "reason=unverified-navigation");
            return;
        }
        inspectionRunning=true;
        inspections++;
        // DOM selectors only; never execute site-provided data as a script.
        final boolean amazon=originalHost!=null && (originalHost.equals("amazon.co.jp") || originalHost.endsWith(".amazon.co.jp"));
        boolean recognizedDetail = false;
        try { recognizedDetail = WishlistCrawler.isSingleProductPage(new URL(view.getUrl())); }
        catch (Exception ignored) { }
        final boolean retailDetail = recognizedDetail || unknownGeneralDetail;
        final String js="(function(){"+
            "var amazon="+amazon+";"+
            "var detail="+retailDetail+";"+
            "var market="+(expectedMarketplace!=null)+";"+
            "if(market){var ids=amazon?['#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen',"+
            "'#corePrice_feature_div .priceToPay .a-offscreen','#price_inside_buybox','#priceblock_ourprice']:"+
            "['#itemPrice','#item-price','.elPriceNumber','#item-price-main','.item-price','.product-detail__price'];"+
            "for(var z=0;z<ids.length;z++){var e=document.querySelector(ids[z]);if(!e)continue;"+
            "if(e.closest('[class*=recommend],[class*=related],[id*=recommend],[id*=related]'))continue;"+
            "var t=(e.getAttribute('content')||e.innerText||e.textContent||'').trim();"+
            "if(t&&t.length<90&& !/(?:送料|参考価格|ポイント|割引)/.test(t))return JSON.stringify({value:t,currency:'JPY'});}"+
            "return JSON.stringify({value:'',currency:''});}"+

            // Same-product price on two independently hosted shops, strict H1
            // plus local tax-inclusive yen text; no click or stock changes.
            "if(!amazon&&detail&&" +
            ("eshop.fumuroya.com".equals(originalHost) || "www.gojochoubei.co.jp".equals(originalHost)
                    || "gojochoubei.co.jp".equals(originalHost)) + "){"+
            "var title=document.querySelector('main h1,h1');"+
            "var expected="+ ("eshop.fumuroya.com".equals(originalHost) ? "'宝の麩'" : "'鰹ごぼう'") + ";"+
            "if(!title||!(title.textContent||'').includes(expected))return JSON.stringify({value:'',currency:''});"+
            "if(title&&(title.textContent||'').includes(expected)){"+
            "var box=title.closest('main,.product-detail,.productDetail,#main,#contents,.item-detail')||document.body;"+
            "var text=(box.innerText||box.textContent||'');var heading=(title.innerText||title.textContent||'').trim();"+
            "var at=heading?text.indexOf(heading):-1;"+
            "if(at>=0){var nearby=text.slice(at+heading.length,at+1200);"+
            "var end=nearby.search(/関連商品|おすすめ商品|この商品を見た|ご購入はこちら|商品説明|配送・送料/);if(end>=0)nearby=nearby.slice(0,end);"+
            "var m=nearby.slice(0,500).match(/[¥￥]\\s*[0-9][0-9,]*(?:\\.[0-9]{1,2})?/);"+
            "if(m&&nearby.slice(m.index,m.index+m[0].length+32).includes('税込')"+
            "&&!/(?:送料|配送料|手数料|割引|ポイント)\\s*[:：]?\\s*$/.test(nearby.slice(Math.max(0,m.index-20),m.index)))"+
            "return JSON.stringify({value:m[0],currency:'JPY'});"+
            "}}}"+
            // A clearly labeled minimum takes precedence over numeric metadata.
            "if(!amazon&&detail){"+
            "var scope=document.querySelector('main,[role=main],#main,#contents,.product-detail,.item-detail')||document.body;"+
            "var txt=(scope.innerText||'').slice(0,8000);"+
            "var stop=txt.search(/関連商品|おすすめ商品|この商品を見た|一緒に購入/);if(stop>=0)txt=txt.slice(0,stop);"+
            "var label=txt.match(/(?:^|\\n|\\s)(?:販売価格|商品価格|税込価格|価格)\\s*[:：]?\\s*([^\\n]{1,50})/);"+
            "if(label&&/[¥￥]|[0-9]\\s*円/.test(label[1])){"+
            "return JSON.stringify({value:label[1],currency:'JPY'});}"+
            "}"+
            "var a=["+
            "'#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen',"+
            "'#corePrice_feature_div .priceToPay .a-offscreen',"+
            "'#apex_desktop .priceToPay .a-offscreen',"+
            "'#price_inside_buybox','#priceblock_dealprice','#priceblock_ourprice',"+
            "'.priceToPay .a-offscreen','[itemprop=price]',"+
            "'.product-detail__price','.productDetail__price',"+
            "'.productDetail .price','.product-detail .price',"+
            "'.product-price','.productPrice','.product_price',"+
            "'.p-product-detail__price','.p-productDetail__price',"+
            "'#product-price','#item-price','.item-price',"+
            "'[data-product-price]'];"+
            "for(var i=0;i<a.length;i++){if(i<7&&!amazon)continue;"+
            "var e=document.querySelector(a[i]);if(!e)continue;"+
            "var s=e.getAttribute('content')||e.textContent||'';"+
            "var cur=document.querySelector('[itemprop=priceCurrency],meta[itemprop=priceCurrency]');"+
            "var cv=cur?(cur.getAttribute('content')||cur.textContent||''):'';"+
            "if(i>=8&&!amazon){if(!detail||s.length>110||/(?:送料|ポイント|割引|値引|クーポン|関連商品|おすすめ)/.test(s))continue;"+
            "var many=s.match(/[¥￥]\\s*[0-9][0-9,]*(?:\\.[0-9]+)?|[0-9][0-9,]*\\s*円/g);"+
            "if(many&&many.length!==1)continue;}"+
            "if(s.trim()&&(amazon||cv.trim()==='JPY'||/¥|￥|円/.test(s)))return JSON.stringify({value:s,currency:amazon?'JPY':cv});}"+
            "var m=document.querySelector('meta[property=\"product:price:amount\"],meta[property=\"og:price:amount\"]');"+
            "var c=document.querySelector('meta[property=\"product:price:currency\"],meta[property=\"og:price:currency\"]');"+
            "if(m&&m.content&&c&&c.content==='JPY')return JSON.stringify({value:m.content,currency:'JPY'});"+
            "var scripts=document.querySelectorAll('script[type=\"application/ld+json\"]');"+
            "function offer(o,d,cur){if(!o||d>8)return null;"+
            "if(Array.isArray(o)){for(var i=0;i<Math.min(30,o.length);i++){var r=offer(o[i],d+1,cur);if(r)return r;}return null;}"+
            "if(typeof o!=='object')return null;var typ=String(o['@type']||'').toLowerCase();"+
            "if(typ.indexOf('aggregateoffer')>=0)return null;"+
            "var cc=o.priceCurrency||cur||'';if(String(cc).toUpperCase()==='JPY'&&(o.price||o.value))return String(o.price||o.value);"+
            "return offer(o.priceSpecification,d+1,cc)||offer(o.offers,d+1,cc);}"+
            "function product(o,d){if(!o||d>8)return null;"+
            "if(Array.isArray(o)){for(var i=0;i<Math.min(40,o.length);i++){var r=product(o[i],d+1);if(r)return r;}return null;}"+
            "if(typeof o!=='object')return null;var typ=String(o['@type']||'').toLowerCase();"+
            "if(typ==='product'||typ.endsWith('/product'))return offer(o.offers,d+1,'');"+
            "return product(o['@graph'],d+1)||product(o.mainEntity,d+1);}"+
            "for(var i=0;i<Math.min(30,scripts.length);i++){try{var v=product(JSON.parse(scripts[i].textContent),0);"+
            "if(v)return JSON.stringify({value:v,currency:'JPY'});}catch(e){}}"+
            // For a genuine product detail page only: read a short visible price
            // phrase near the product heading, never site-wide recommendations.
            "if(!amazon&&detail){"+
            "var root=document.querySelector('main,[role=main],#main,#contents,.product-detail,.item-detail')||document.body;"+
            "var body=(root.innerText||'').slice(0,7000);"+
            "var bound=body.search(/関連商品|おすすめ商品|この商品を見た|一緒に購入/);"+
            "if(bound>=0)body=body.slice(0,bound);"+
            "var tagged=body.match(/(?:販売価格|商品価格|税込価格)\\s*[:：]?\\s*([¥￥]\\s*[0-9][0-9,]*(?:\\s*[～〜~-]\\s*[¥￥]?[0-9,]*)?|[0-9][0-9,]*\\s*円(?:\\s*[～〜~-]\\s*[0-9,]*\\s*円?)?)/);"+
            "if(tagged)return JSON.stringify({value:tagged[1],currency:'JPY'});"+
            "var h=document.querySelector('main h1,h1');"+
            "if(h){var node=h.parentElement;for(var n=0;node&&n<3;n++,node=node.parentElement){"+
            "var text=(node.innerText||'').slice(0,600);"+
            "var slice=text.slice(text.indexOf(h.innerText||'')+(h.innerText||'').length);"+
            "var boundary=slice.search(/商品説明|関連商品|おすすめ商品|よく一緒に|送料/);"+
            "if(boundary>=0)slice=slice.slice(0,boundary);"+
            "var matches=slice.match(/[¥￥]\\s*[0-9][0-9,]*(?:\\.[0-9]+)?|[0-9][0-9,]*\\s*円/g);"+
            "if(matches&&matches.length===1)return JSON.stringify({value:matches[0],currency:'JPY'});"+
            "}}}"+
            "return JSON.stringify({value:'',currency:''});"+
            "})()";
        // Do not run site-wide fallback selectors on Fumuroya: the previous
        // variant returned a 22-yen paper bag as the main product price.
        String strictFumuroyaJs = null;
        if ("eshop.fumuroya.com".equals(originalHost) && originalRetailUrl != null
                && originalRetailUrl.getPath().matches("/product/detail/300840/?")) {
            strictFumuroyaJs = """
(function(){'use strict';
 const empty=()=>JSON.stringify({value:'',currency:''});
 try {
   if(!/^\\/product\\/detail\\/300840\\/?$/.test(location.pathname))return empty();
   const h=document.querySelector('main h1,h1');
   if(!h||!/宝の麩/.test(h.textContent||''))return empty();
   const exclusion=e=>!!e.closest('header,footer,nav,aside,[class*=recommend],[class*=related],'+
     '[class*=option],[class*=accessory],[class*=bag],[class*=giftbag]');
   const root=h.closest('main,[role=main],#main,#contents,.product-detail,.productDetail,.item-detail')||document.body;
   // Accept only a product-specific price element with a single monetary value.
   // Never walk from H1 into body text to select the first incidental price.
   const selectors=['[itemprop=price]','.product-detail__price','.productDetail__price',
     '.product-price','.productPrice','.product_price','.p-product-detail__price',
     '.price-box .price','.sale-price','[data-product-price]'];
   const candidates=[];
   for(const selector of selectors) for(const e of root.querySelectorAll(selector)) {
     if(exclusion(e))continue;
     const t=String(e.getAttribute('content')||e.getAttribute('data-product-price')||e.textContent||'').trim();
     const matches=t.match(/(?:[¥￥]\\s*[0-9][0-9,]*|[0-9][0-9,]*\\s*円)/g)||[];
     if(matches.length!==1)continue;
     const n=Number(matches[0].replace(/[^0-9]/g,''));
     if(!Number.isSafeInteger(n)||n<500||n>30000)continue;
     candidates.push(n);
   }
   // If markup offers multiple conflicting prices, refuse to guess.
   if(candidates.length&&candidates.every(p=>p===candidates[0]))
     return JSON.stringify({value:String(candidates[0]),currency:'JPY'});
   // An explicit main-product price label can stand alone, but not a paper-bag label.
   const container=h.parentElement&&h.parentElement.parentElement;
   if(container&&root.contains(container)) {
     const s=String(container.innerText||container.textContent||'').slice(0,800);
     const m=s.match(/(?:販売価格|商品価格|税込価格)[\\s：:]*[¥￥]\\s*([0-9][0-9,]*)/);
     if(m&&!/(?:手提げ袋|紙袋|送料|ラッピング|オプション)/.test(s.slice(Math.max(0,m.index-26),m.index))) {
       const n=Number(m[1].replace(/,/g,''));
       if(n>=500&&n<=30000)return JSON.stringify({value:String(n),currency:'JPY'});
     }
   }
   return empty();
 }catch(_){return empty();}
})()
""";
        }
        String actualJs=js;
        if (originalRetailUrl != null && WishlistHonmaProductDom.isDetail(originalRetailUrl))
            actualJs=WishlistHonmaProductDom.priceJavascript(originalRetailUrl);
        if (expectedMarketplace == null && originalRetailUrl != null
                && GeneralRetailIdentity.store(originalRetailUrl) != null) {
            actualJs=GeneralRetailPriceDom.javascript(originalHost,
                    GeneralRetailIdentity.itemId(originalRetailUrl));
        }
        if(expectedMarketplace!=null){
            switch(expectedMarketplace.site){
                case AMAZON: actualJs=AmazonDomSelectors.price();break;
                case RAKUTEN: actualJs=RakutenDomSelectors.price();break;
                case YAHOO: actualJs=YahooDomSelectors.price();break;
                default: finish(null,"未対応サイト");return;
            }
        }
        // GENERAL marketplaces: use only exact-item hydrated product data.
        // A missing or ambiguous record stays UNKNOWN/price-null. Never fall back
        // to an unrelated page-wide Product offer or promotional price.
        final boolean guardedHydration = originalRetailUrl != null
                && WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)
                && !retail && expectedMarketplace == null;
        if (guardedHydration) {
            // First try ID-bound hydrated objects, then separately verified
            // Product JSON-LD / canonical-bound rendered metadata on SAME URL.
            // None of this infers inventory or accepts a store-wide price.
            actualJs = "(function(){try{var a=JSON.parse("
                    + WishlistGeneralMarketplaceHydrationDom.javascript(originalRetailUrl)
                    + ");var b=JSON.parse("
                    + WishlistGeneralMarketplaceVerifiedDom.javascript(originalRetailUrl)
                    + ");if(b.reason==='canonical-other-item'||b.reason==='navigation-other-item'||b.reason==='challenge-visible'){"
                    + "a.title='';a.value='';a.currency='';a.reason=b.reason;}"
                    + "else{if(!a.title)a.title=b.title||'';"
                    + "if(!a.value&&b.value){a.value=b.value;a.currency=b.currency;}"
                    + "if(a.reason==='id-unverified'&&(a.title||a.value))a.reason='verified-dom-metadata';}"
                    + "a.verifiedReason=b.reason;a.canonical=b.canonical;"
                    + "a.productNodes=b.productNodes;a.heading=b.heading;"
                    + "return JSON.stringify(a);}catch(_){return JSON.stringify({value:'',reason:'combined-script-error'});}})()";
        }
        else if (unknownGeneralDetail && originalRetailUrl != null)
            actualJs = WishlistGeneralVerifiedUnknownDom.javascript(originalRetailUrl);
        // Never fall through to generic shop-wide recommendations for this SKU.
        if (strictFumuroyaJs != null) actualJs = strictFumuroyaJs;
        if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
            trace("script.select", "hydration="+guardedHydration
                    +" attempts="+inspections+" urlVerified="
                    +(view.getUrl()!=null && allowedDestination(view.getUrl())));
        try {
            view.evaluateJavascript(actualJs, returned -> {
                inspectionRunning=false;
                if(finished)return;
                try {
                    String json=new JSONArray("["+returned+"]").getString(0);
                    JSONObject o=new JSONObject(json);
                    String val=o.optString("value","");
                    String currency=o.optString("currency","");
                    if (independentShop) {
                        trace("dom", "attempt="+inspections+" price="+!val.isEmpty()
                                +" sameItem=true");
                    }
                    if (unknownGeneralDetail) {
                        String reason=o.optString("reason","data-missing");
                        trace("verified-jsonld", "attempt="+inspections+" reason="
                                +(reason.matches("[a-z-]{1,35}")?reason:"invalid")
                                +" images="+(o.optJSONArray("images")==null?0:o.optJSONArray("images").length()));
                    }
                    if (guardedHydration) {
                        String title=o.optString("title", "").replaceAll("\\s+", " ").trim();
                        if (title.length() >= 4 && title.length() <= 240) verifiedMarketplaceTitle=title;
                        if (inspections == 1 || verifiedMarketplaceTitle != null
                                || inspections == GENERAL_PRODUCT_INSPECTIONS) {
                            trace("metadata", "attempt="+inspections+" title="+(verifiedMarketplaceTitle!=null)
                                    +" verifiedReason="+o.optString("verifiedReason","none").replaceAll("[^a-z-]", "")
                                    +" canonical="+o.optString("canonical","unknown").replaceAll("[^a-z-]", "")
                                    +" productNodes="+o.optInt("productNodes",0)
                                    +" heading="+o.optBoolean("heading",false));
                        }
                        String reason=o.optString("reason","data-missing");
                        lastReason=reason.matches("[a-z-]{1,50}") ? reason : "invalid-reason";
                        trace("hydration", "attempt="+inspections+" reason="
                                +(reason.matches("[a-z-]{1,35}")?reason:"invalid")
                                +" source="+o.optString("source","none").replaceAll("[^a-zA-Z-]", "")
                                +" images="+(o.optJSONArray("images")==null?0:o.optJSONArray("images").length())
                                +" ready="+o.optString("ready","unknown").replaceAll("[^a-z]", "")
                                +" blocked="+o.optBoolean("blocked",false)
                                +" chars="+o.optInt("bodyChars",0));
                        String pageKind=o.optString("pageKind", "unknown").replaceAll("[^a-z-]", "");
                        String ready=o.optString("ready", "unknown");
                        int chars=o.optInt("bodyChars",0);
                        int nodes=o.optInt("productNodes",0);
                        String verified=o.optString("verifiedReason", "none");
                        // The live SHEIN failure repeatedly inspected one fully
                        // loaded non-product document without a single item node.
                        // Stop after stability is proven, not after eleven guesses.
                        boolean unbound = "id-unverified".equals(reason)
                                && "unbound-url".equals(pageKind)
                                && !o.optBoolean("heading", false) && nodes == 0
                                && ("unbound-navigation".equals(verified)
                                    || "product-data-unverified".equals(verified));
                        String fingerprint=pageKind+":"+reason+":"+verified+":"+chars+":"+nodes;
                        if ("complete".equals(ready) && unbound && chars > 0) {
                            stableMarketEvidence=fingerprint.equals(lastMarketEvidence)
                                    ? stableMarketEvidence+1 : 1;
                            lastMarketEvidence=fingerprint;
                        } else { stableMarketEvidence=0; lastMarketEvidence=null; }
                        if (inspections==1 || inspections==GENERAL_PRODUCT_INSPECTIONS
                                || stableMarketEvidence>=3)
                            trace("page.audit", "kind="+pageKind+" ready="+ready.replaceAll("[^a-z]", "")
                                    +" productNodes="+nodes+" stable="+stableMarketEvidence
                                    +" boundName="+(verifiedMarketplaceTitle!=null)
                                    +" boundPrice="+!val.isEmpty());
                        if (stableMarketEvidence>=3 && val.isEmpty()) {
                            // SHEIN mobile URLs sometimes resolve to a non-item
                            // storefront. Try the official Japanese SHEIN host
                            // ONCE using the exact saved path and item ID.
                            // Same merchant, same SKU: all existing ID checks
                            // remain in force. Never try a guessed product ID.
                            if (!sheinRegionalRetry && originalRetailUrl != null
                                    && "m.shein.com".equals(originalHost)) {
                                sheinRegionalRetry=true;
                                try {
                                    URL alternate=new URL("https", "jp.shein.com",
                                            originalRetailUrl.getFile());
                                    if (WishlistGeneralMarketplaceIdentity.sameItem(originalRetailUrl, alternate)) {
                                        trace("navigation.retry", "reason=unbound-mobile-page"
                                                +" target=regional-same-item");
                                        inspections=0;
                                        stableMarketEvidence=0;
                                        lastMarketEvidence=null;
                                        view.stopLoading();
                                        view.loadUrl(alternate.toExternalForm());
                                        return;
                                    }
                                } catch (Exception ignored) { }
                            }
                            trace("inspection.stop", "reason=stable-unbound-marketplace-document"
                                    +" attempts="+inspections+" regionalRetry="+sheinRegionalRetry);
                            finish(null, "商品ページの内容を確認できず");
                            return;
                        }
                    }
                    if (retail) {
                        String reason=o.optString("reason","no-price");
                        lastReason=reason.matches("[a-z-]{1,50}")?reason:"invalid-reason";
                        trace("dom", "attempt="+inspections+" price="+!val.isEmpty()
                                +" reason="+lastReason+" mainHTTP="+mainHttpCode);
                        if ("askul.co.jp".equals(originalHost) || "www.askul.co.jp".equals(originalHost)) {
                            if (inspections == 1 || inspections == 5 || !val.isEmpty()
                                    || inspections == RETAIL_INSPECTIONS) {
                                trace("page.evidence", "attempt="+inspections
                                        +" bodyChars="+o.optInt("bodyChars",0)
                                        +" h1="+o.optBoolean("h1",false)
                                        +" skuLabel="+o.optBoolean("skuLabel",false)
                                        +" restrictedHint="+o.optBoolean("blocked",false));
                            }
                        }
                    }
                    WishlistRetailPriceQuote quote = retailDetail && !amazon ?
                            WishlistRetailPriceQuote.fromBareText(val) : null;
                    if (quote != null) { finish(null, quote, null); return; }
                    Long price=WishlistPriceExtractor.parseDomValue(val,currency);
                    if (price != null) {
                        if (isAskul()) inspectAskulStock(view, price);
                        else finish(price, null);
                    }
                    else if (inspections < (retail ? RETAIL_INSPECTIONS
                            : independentShop ? INDEPENDENT_INSPECTIONS
                            : generalProduct ? GENERAL_PRODUCT_INSPECTIONS : MAX_INSPECTIONS))
                        scheduleInspection(view, retail?1400:independentShop?1300:1100);
                    else finish(null, "WebViewにも価格情報なし");
                }catch(Exception ex){
                    // A transient WebView null/malformed callback must not turn
                    // a previously working MUJI price into a permanent failure.
                    // Log the exception class only, never page text or personal data.
                    String category=returned==null?"null-result":returned.isBlank()?"empty-result"
                            :ex.getClass().getSimpleName().replaceAll("[^A-Za-z]", "");
                    trace("dom.error", "attempt="+inspections+" kind="+category
                            +" mainHTTP="+mainHttpCode);
                    if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
                        trace("hydration.error", "attempt="+inspections+" type="+category);
                    if (generalProduct && originalRetailUrl != null
                            && WishlistMode.isMujiProduct(originalRetailUrl)
                            && inspections < GENERAL_PRODUCT_INSPECTIONS) {
                        scheduleInspection(view, 1100);
                    } else finish(null,"WebView価格解析エラー");
                }
            });
        }catch(Exception ex){
            inspectionRunning=false;
            if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
                trace("hydration.error", "type=evaluate-exception");
            finish(null,"WebView解析を開始できず");
        }
    }
    /** Reuse the proven, exact-SKU ASKUL price document for stock inspection.
     * Only the existing strict stockEvidence() can set a verified state.  Stop
     * after a few bounded hydration polls and keep the price even if stock
     * remains UNKNOWN.  This is a read-only DOM operation; no cart is clicked. */
    private void inspectAskulStock(WebView view, Long verifiedPrice) {
        if (finished || view != web || verifiedPrice == null || !isAskul()
                || originalRetailUrl == null || !allowedDestination(view.getUrl())) {
            finish(verifiedPrice, null); return;
        }
        String sku=GeneralRetailIdentity.itemId(originalRetailUrl);
        if (sku==null) { finish(verifiedPrice, null); return; }
        main.removeCallbacks(timeout); // Price is known; bounded stock polls finish below.
        if (askulStockInspections == 0) {
            askulStockDeadline = () -> {
                if (!finished && view == web) {
                    trace("askul.stock.deadline", "status=UNKNOWN");
                    finishAskulWithTitle(view, verifiedPrice);
                }
            };
            main.postDelayed(askulStockDeadline, 7200);
        }
        askulStockInspections++;
        view.evaluateJavascript(AskulProductDom.stockEvidence(sku), raw -> {
            if (finished || view != web) return;
            String status="UNKNOWN", reason="unreadable", flags="";
            try {
                String json=new JSONArray("[" + raw + "]").getString(0);
                JSONObject obj=new JSONObject(json);
                status=obj.optString("status", "UNKNOWN");
                reason=obj.optString("reason", "unknown");
                flags=" skuMatch="+obj.optBoolean("skuLabel",false)
                        +" stockFound="+obj.optBoolean("stockFound",false)
                        +" cartFound="+obj.optInt("cartFound",0)
                        +" cartEnabled="+obj.optInt("cartEnabled",0)
                        +" structured="+obj.optBoolean("structuredProduct",false)
                        +" controls="+obj.optInt("domControls",0)
                        +" cartHint="+obj.optBoolean("cartTextHint",false)
                        +" stockHint="+obj.optBoolean("stockTextHint",false)
                        +" structuredOffer="+obj.optBoolean("structuredOffer",false)
                        +" skuFrame="+obj.optInt("skuFrames",0)
                        +" frameCart="+obj.optInt("frameCart",0)
                        +" frameStock="+obj.optInt("frameStock",0)
                        +" framesReadable="+obj.optInt("accessibleFrames",0)
                        +" scopeCut="+obj.optBoolean("scopeCut",false)
                        +" stockPositive="+obj.optBoolean("localStockPositive",false)
                        +" stockNegative="+obj.optBoolean("localStockNegative",false);
            }catch(Exception ignored) { }
            trace("askul.stock", "attempt="+askulStockInspections+" status="+status
                    +" reason="+reason+flags);
            if ("AVAILABLE".equals(status) || "UNAVAILABLE".equals(status)) {
                askulStockStatus=status;
                finishAskulWithTitle(view, verifiedPrice);
            } else if (askulStockInspections < 5) {
                main.postDelayed(() -> inspectAskulStock(view, verifiedPrice), 1100);
            } else {
                finishAskulWithTitle(view, verifiedPrice);
            }
        });
    }

    /** Capture a title without a second network request, before destroying the
     * successful ASKUL price+stock WebView. Failure never changes price/stock.
     * Both JS result and deadline are bounded; only one callback can complete. */
    private void finishAskulWithTitle(WebView view, Long verifiedPrice) {
        if (finished || askulTitleStarted) return;
        if (view != web || originalRetailUrl == null || !isAskul()
                || !allowedDestination(view.getUrl())
                || !WishlistRetailProductTitleDom.supports(originalRetailUrl)) {
            finish(verifiedPrice, null);return;
        }
        askulTitleStarted=true;
        if (askulStockDeadline != null) main.removeCallbacks(askulStockDeadline);
        askulStockDeadline=null;
        final boolean[] completed={false};
        final Runnable fallback=() -> {
            if (!completed[0] && !finished && view==web) {
                completed[0]=true;
                trace("askul.title", "verified=false reason=callback-timeout");
                finish(verifiedPrice,null);
            }
        };
        main.postDelayed(fallback,1200);
        try {
            view.evaluateJavascript(WishlistRetailProductTitleDom.javascript(originalRetailUrl), raw -> {
                if (completed[0] || finished || view!=web) return;
                completed[0]=true;
                main.removeCallbacks(fallback);
                String reason="unreadable";
                try {
                    Object outer=new org.json.JSONTokener(raw==null?"null":raw).nextValue();
                    if (outer instanceof String) {
                        JSONObject o=new JSONObject((String)outer);
                        reason=o.optString("reason","unreadable");
                        String title=o.optString("title","").trim();
                        if ("verified-rendered-heading".equals(reason)
                                && title.length()>=3 && title.length()<=240)
                            verifiedAskulTitle=title;
                    }
                }catch(Exception ignored) {reason="invalid-result";}
                if (!reason.matches("[a-z0-9-]{1,45}")) reason="unreadable";
                trace("askul.title", "verified="+(verifiedAskulTitle!=null)+" reason="+reason);
                finish(verifiedPrice,null);
            });
        }catch(Exception ex){
            main.removeCallbacks(fallback);completed[0]=true;
            trace("askul.title", "verified=false reason=evaluation-error");
            finish(verifiedPrice,null);
        }
    }

    private void finish(Long price,String error) { finish(price,null,error); }
    private void finish(Long price,WishlistRetailPriceQuote quote,String error) {
        if(finished)return;
        finished=true;
        main.removeCallbacks(timeout);
        if (askulStockDeadline != null) main.removeCallbacks(askulStockDeadline);
        askulStockDeadline=null;
        Callback next=callback;
        callback=null;
        if(web!=null){
            WebView current=web;web=null;
            try{current.stopLoading();current.loadUrl("about:blank");parent.removeView(current);current.destroy();}
            catch(Exception ignored){}
        }
        if(next!=null)next.completed(price,quote,error);
    }
    public void cancel() {callback=null;finish(null,"WebView取得中断");}
}
