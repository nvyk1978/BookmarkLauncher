package com.cmyk.bookmarkslauncher.wishlist;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.view.View;
import android.view.ViewGroup;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.Locale;
import java.util.LinkedHashSet;

/**
 * Foreground, single-product, user-invoked price DOM probe. For only guarded
 * SHEIN/AliExpress GENERAL items, this also publishes read-only same-document
 * title and item-bound image evidence (database writes remain in WishlistPage).
 * No background crawl or cart interaction.
 */
public final class WishlistPriceWebViewProbe {
    public interface Callback { void completed(Long price, WishlistRetailPriceQuote quote, String problem); }
    /** Only non-sensitive progress counters/status; caller associates with a card ID. */
    public interface Trace { void record(String stage, String safeEvidence); }
    private Trace trace;
    public void setTrace(Trace trace) { this.trace = trace; }
    private void trace(String stage, String evidence) { if (trace != null) trace.record(stage, evidence); }
    private final Handler main = new Handler(Looper.getMainLooper());
    private final FrameLayout parent;
    private WebView web;
    private Callback callback;
    private boolean finished;
    private int inspections;
    private static final int MAX_INSPECTIONS = 5;
    private static final int GENERAL_PRODUCT_INSPECTIONS = 11;
    private static final int RETAIL_INSPECTIONS = 13;
    private static final int INDEPENDENT_INSPECTIONS = 13;
    private boolean retail;
    private boolean independentShop;
    private boolean generalProduct;
    private boolean unknownGeneralDetail;
    private boolean inspectionPending;
    private boolean inspectionRunning;
    private String lastReason = "uninspected";
    private String lastMarketEvidence;
    private int stableMarketEvidence;
    private boolean sheinRegionalRetry;
    private boolean marketplaceAlternateRetry;
    private boolean temuReachedExactItem;
    private int temuPreventedRedirects;
    private boolean temuMobileProfileRetry;
    private boolean manualTemuVerificationEnabled;
    private boolean temuVerificationShown;
    private android.app.AlertDialog temuDialog;
    public void setManualTemuVerificationEnabled(boolean enabled) {
        manualTemuVerificationEnabled=enabled;
    }

    private String temuNativeUserAgent;
    private int marketDocumentGeneration;
    // Keep an exact-item price seen in an earlier poll of THIS document.
    // Never carry it across navigation, challenges or contradictory prices.
    private final WishlistMarketplacePriceEvidence retainedMarketPrice = new WishlistMarketplacePriceEvidence();
    // GENERAL SHEIN/AliExpress/Temu: one loaded document provides a bound
    // item-scoped field snapshot to the caller. Never start a second WebView
    // merely to obtain a gallery from an already-inspected page.
    private final LinkedHashSet<String> marketplaceImages = new LinkedHashSet<>();
    private String marketplacePageKind = "uninspected";
    private String marketplaceItemEvidence = "none";
    private String marketplaceStockStatus = "UNKNOWN";
    private String marketplaceStockReason = "not-inspected";
    public String[] marketplaceImages() { return marketplaceImages.toArray(new String[0]); }
    public String marketplacePageKind() { return marketplacePageKind; }
    public String marketplaceItemEvidence() { return marketplaceItemEvidence; }
    public String marketplaceStockStatus() { return marketplaceStockStatus; }
    public String marketplaceStockReason() { return marketplaceStockReason; }

    private int mainHttpCode;
    private String askulStockStatus = "UNKNOWN";
    private String verifiedAskulTitle;
    private String verifiedMarketplaceTitle;
    private String verifiedMarketplaceResolvedUrl;
    private boolean askulTitleStarted;
    private int askulStockInspections;
    private Runnable askulStockDeadline;
    /** The same-identity ASKUL price DOM may also confirm this SKU's purchase state. */
    public String askulStockStatus() { return askulStockStatus; }
    /** An exact saved-SKU product heading captured from this SAME ASKUL WebView. */
    public String verifiedAskulTitle() { return verifiedAskulTitle; }
    public String verifiedMarketplaceTitle() { return verifiedMarketplaceTitle; }
    /** Exact-item provenance for a verified marketplace title. For an AliExpress
     * short link the saved URL has no item ID, so the validated resolved WebView
     * product URL is separately needed by the repository. */
    public String verifiedMarketplaceResolvedItem() {
        return verifiedMarketplaceTitle!=null ? verifiedMarketplaceResolvedUrl : null;
    }
    private boolean isAskul() { return "askul.co.jp".equals(originalHost) || "www.askul.co.jp".equals(originalHost); }
    private String originalHost;
    private URL originalRetailUrl;
    private MarketplaceIdentity expectedMarketplace;
    private final Runnable timeout = () -> {
        trace("timeout", "attempts="+inspections+" mainHTTP="+mainHttpCode+" reason="+lastReason);
        // JS-intensive marketplaces can be loading a second/third resource
        // when their bounded timer fires. Do not discard a previously verified
        // exact-item JPY price solely because a later callback is delayed.
        // No value may be restored after navigation to an unrelated page.
        Long retained = retainedPriceOnCurrentItem();
        if (retained != null) trace("snapshot.price", "reason=preserve-verified-price-on-deadline");
        finish(retained, retained==null ? "WebView読み込みタイムアウト" : null);
    };

    private Long retainedPriceOnCurrentItem() {
        if (web == null || originalRetailUrl == null || retainedMarketPrice.conflicted()) return null;
        try {
            URL current=new URL(web.getUrl());
            if (WishlistGeneralMarketplaceIdentity.sameItem(originalRetailUrl,current)
                    && ("item-url".equals(marketplacePageKind)
                        || "item-bound-jsonld".equals(marketplacePageKind)))
                return retainedMarketPrice.get();
        } catch(Exception ignored) { }
        return null;
    }

    public WishlistPriceWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public void start(String urlText, WishlistMode mode, Callback onDone) {
        cancel();
        callback=onDone;
        finished=false;
        inspections=0;
        inspectionPending=false;
        inspectionRunning=false;
        lastReason="uninspected";
        lastMarketEvidence=null;
        stableMarketEvidence=0;
        sheinRegionalRetry=false;
        marketplaceAlternateRetry=false;
        temuReachedExactItem=false;
        temuPreventedRedirects=0;
        temuMobileProfileRetry=false;
        temuNativeUserAgent=null;
        marketDocumentGeneration=0;
        retainedMarketPrice.clear();
        marketplaceImages.clear();
        marketplacePageKind="uninspected";
        marketplaceItemEvidence="none";
        marketplaceStockStatus="UNKNOWN";
        marketplaceStockReason="not-inspected";
        mainHttpCode=0;
        askulStockStatus="UNKNOWN";
        verifiedAskulTitle=null;
        verifiedMarketplaceTitle=null;
        verifiedMarketplaceResolvedUrl=null;
        askulTitleStarted=false;
        askulStockInspections=0;
        askulStockDeadline=null;
        retail=false;
        independentShop=false;
        generalProduct=false;
        unknownGeneralDetail=false;
        if (Looper.myLooper()!=Looper.getMainLooper()) {
            finish(null,"WebViewはメインスレッド限定");return;
        }
        try {
            URL url=new URL(urlText);
            if (!WishlistCrawler.isAllowedUrl(url) || !"https".equalsIgnoreCase(url.getProtocol())) {
                finish(null,"安全なHTTPS URL以外は対象外");return;
            }
            if (mode == null || mode == WishlistMode.UNRESOLVED
                    || WishlistMode.forDirectUrl(urlText) != mode) {
                finish(null,"商品取得モードが保存済みモードと不一致");return;
            }
            temuVerificationShown=false;
        originalHost=url.getHost().toLowerCase(Locale.ROOT);
            originalRetailUrl=url;
            trace("start", "mode="+mode+" savedMarketItem="
                    +WishlistGeneralMarketplaceIdentity.isDetail(url)
                    +" savedDetail="+WishlistCrawler.isSingleProductPage(url));
            retail=GeneralRetailIdentity.store(url)!=null;
            unknownGeneralDetail=mode==WishlistMode.GENERAL
                    && !WishlistCrawler.isSingleProductPage(url)
                    && WishlistGeneralVerifiedUnknownDom.candidate(url);
            generalProduct=(mode == WishlistMode.GENERAL || mode == WishlistMode.MUJI)
                    && (WishlistCrawler.isSingleProductPage(url) || unknownGeneralDetail);
            independentShop=mode==WishlistMode.GENERAL && (
                    ("eshop.fumuroya.com".equals(originalHost)
                            && url.getPath().matches("/product/detail/[0-9]+/?"))
                    || (("www.gojochoubei.co.jp".equals(originalHost)
                            || "gojochoubei.co.jp".equals(originalHost))
                            && url.getPath().matches("/view/item/[0-9]{12}/?")));
            expectedMarketplace=MarketplaceIdentity.from(url);
            if (MarketplaceIdentity.site(url)!=MarketplaceIdentity.Site.OTHER
                    && expectedMarketplace==null) { finish(null,"商品URLを特定できず");return; }
            trace("route", "generalProduct="+generalProduct+" marketHydration="
                    +(mode==WishlistMode.GENERAL
                       && WishlistGeneralMarketplaceIdentity.isDetail(url))
                    +" retail="+retail+" independent="+independentShop);
            web=BackgroundDomWebView.create(parent.getContext());

            // Interactive storefronts may defer all product hydration while a
            // WebView is DETACHED from a window (even if evaluateJavascript runs).
            // Attach only these three GENERAL merchants behind the opaque Wish
            // page. The engine has a real viewport but no visible/touchable UI.
            // No other merchant's WebView or page layout is modified.
            final boolean mountedMarketplace = mode == WishlistMode.GENERAL
                    && WishlistGeneralMarketplaceIdentity.isDetail(url)
                    && expectedMarketplace == null && !retail;
            // GU's current product page repeatedly timed out with no DOM callback
            // while the separate stock WebView had already rendered its controls.
            // Use a window-attached price renderer for GU ONLY, leaving all
            // successful merchants (Green Beans, Joshin, etc.) unchanged.
            final boolean mountedGu = mode == WishlistMode.GENERAL
                    && WishlistGeneralShopItem.merchant(url)
                        == WishlistGeneralShopItem.Merchant.GU;
            final boolean mountedMercari = mode == WishlistMode.GENERAL
                    && WishlistGeneralShopItem.merchant(url)
                        == WishlistGeneralShopItem.Merchant.MERCARI;
            if (mountedMarketplace && WishlistGeneralMarketplaceIdentity.merchant(url)
                    == WishlistGeneralMarketplaceIdentity.Merchant.TEMU) {
                String nativeAgent=web.getSettings().getUserAgentString();
                temuNativeUserAgent=nativeAgent;
                // Start with the actual device WebView fingerprint, not a
                // Linux desktop UA spoof. The previous forced desktop agent
                // consistently received a verification page in device logs.
                trace("temu.browser", "profile=system-default first=true userAgentVersion=current");
            }
            if (mountedMarketplace || mountedGu || mountedMercari) {
                web.setWillNotDraw(false);
                web.setFocusable(false);
                web.setClickable(false);
                web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
                parent.addView(web, 0, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                trace("engine", "merchant="+(mountedGu ? "GU" : mountedMercari ? "MERCARI"
                        : WishlistGeneralMarketplaceIdentity.merchant(url))
                        +" mountedBehindOpaquePage=true sameItemRequired=true");
            }

            web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setClickable(false);
            web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.setVerticalScrollBarEnabled(false);
            web.setHorizontalScrollBarEnabled(false);

            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request) {
                    if (!request.isForMainFrame()) return false;
                    String target=request.getUrl().toString();
                    // In the explicit, user-visible Temu verification dialog
                    // allow real same-merchant challenge navigation. It is
                    // NEVER allowed to supply price or stock; after the user
                    // confirms we reload the exact saved item route.
                    if (temuDialog!=null && manualTemuSite(target)) {
                        trace("temu.manual", "action=merchant-navigation unverified=true");
                        return false;
                    }
                    if (!allowedDestination(target)) return true;
                    // Exact-item Temu only: distinguish a browser navigation
                    // from an in-page SPA rewrite. Keep only redacted route,
                    // request flags and whether the item data was ever verified.
                    boolean temuItem=originalRetailUrl!=null && temuReachedExactItem
                            && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                               == WishlistGeneralMarketplaceIdentity.Merchant.TEMU;
                    if (temuItem) {
                        String state="invalid";
                        try { state=WishlistGeneralMarketplaceIdentity.relation(originalRetailUrl,
                                new URL(target)).name(); } catch(Exception ignored) { }
                        trace("navigation.temu.request", "relation="+state
                                +" route="+WishlistGeneralMarketplaceIdentity.diagnosticRoute(target)
                                +" redirect="+request.isRedirect()+" gesture="+request.hasGesture()
                                +" attempt="+inspections
                                +" bound="+(verifiedMarketplaceTitle!=null
                                        || retainedMarketPrice.get()!=null));
                    }
                    // TEMU's mobile app often immediately redirects an actual
                    // item document to a generic landing page. Preserve the
                    // already reached exact product (and its pending scripts)
                    // instead of letting that unbound page destroy the DOM.
                    // Never block a verified same-item route or any other shop.
                    if (temuReachedExactItem && originalRetailUrl!=null
                            && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                               == WishlistGeneralMarketplaceIdentity.Merchant.TEMU) {
                        try {
                            if (WishlistGeneralMarketplaceIdentity.relation(originalRetailUrl,
                                    new URL(target))==WishlistGeneralMarketplaceIdentity.ItemRelation.UNKNOWN) {
                                temuPreventedRedirects++;
                                trace("navigation.temu", "reason=prevent-item-to-unbound-redirect"
                                        +" count="+temuPreventedRedirects);
                                return true;
                            }
                        } catch(Exception ignored) { }
                    }
                    return false;
                }
                @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap favicon) {
                    if (finished) return;
                    if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
                        marketDocumentGeneration++;
                    // A marketplace SPA may leave old item DOM/state briefly
                    // available before changing its main-frame navigation.
                    // Never carry a prior document's gallery or name into it.
                    if (inspections > 0 && WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)) {
                        retainedMarketPrice.clear();
                        marketplaceImages.clear();
                        verifiedMarketplaceTitle=null;
        verifiedMarketplaceResolvedUrl=null;
                        marketplacePageKind="uninspected";
                        marketplaceItemEvidence="none";
                        marketplaceStockStatus="UNKNOWN";
                        marketplaceStockReason="navigation-reset";
                        stableMarketEvidence=0;
                        lastMarketEvidence=null;
                        trace("snapshot.navigation", "reset=true reason=main-frame-transition");
                    }
                    if (!allowedDestination(url)) {
                        trace("navigation.reject", "phase=started sameItem=false"); return;
                    }
                    if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)) {
                        String relation="invalid";
                        try { relation=WishlistGeneralMarketplaceIdentity.relation(
                                originalRetailUrl,new URL(url)).name(); } catch(Exception ignored) { }
                        if ("SAME".equals(relation)
                                && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                    == WishlistGeneralMarketplaceIdentity.Merchant.TEMU)
                            temuReachedExactItem=true;
                        trace("page.start", "marketRelation="+relation+" productUrl="
                                +"SAME".equals(relation)+" destination="
                                +WishlistGeneralMarketplaceIdentity.diagnosticRoute(url));
                        if (inspections > 0 && "UNKNOWN".equals(relation)
                                && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                   == WishlistGeneralMarketplaceIdentity.Merchant.TEMU) {
                            trace("navigation.temu", "reason=item-left-to-unbound-page previousAttempts="+inspections);
                            main.postDelayed(() -> {
                                if (finished || web != view || view.getUrl()==null) return;
                                try {
                                    if (WishlistGeneralMarketplaceIdentity.relation(originalRetailUrl,
                                            new URL(view.getUrl())) == WishlistGeneralMarketplaceIdentity.ItemRelation.UNKNOWN
                                            && retainedMarketPrice.get() == null) {
                                        finish(null,"Temu商品ページから別ページに転送されました");
                                    }
                                } catch (Exception ignored) { }
                            }, 2400);
                        }
                    }
                    if (retail || independentShop || generalProduct) {
                        trace("page.start", retail?"sameSku=true":
                                WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)
                                ? "marketNavigationChecked=true" : "sameItem=true");
                        // Some Japanese product sites never finish loading trackers;
                        // inspect the verified document before onPageFinished.
                        scheduleInspection(view, generalProduct && !retail && !independentShop ? 1800 : 1300);
                    }
                }
                @Override public void onPageCommitVisible(WebView view,String url) {
                    if (!finished && originalRetailUrl!=null
                            && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                              == WishlistGeneralMarketplaceIdentity.Merchant.TEMU) {
                        String relation="invalid";
                        try { relation=WishlistGeneralMarketplaceIdentity.relation(
                                originalRetailUrl,new URL(url)).name(); } catch(Exception ignored) { }
                        trace("navigation.temu.commit", "relation="+relation
                                +" route="+WishlistGeneralMarketplaceIdentity.diagnosticRoute(url)
                                +" attempts="+inspections+" denied="+temuPreventedRedirects);
                    }
                }
                @Override public void onPageFinished(WebView view,String url) {
                    if (finished) return;
                    if (!allowedDestination(url)) {
                        trace("navigation.reject", "phase=finished sameItem=false"); return;
                    }
                    if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)) {
                        String relation="invalid";
                        try { relation=WishlistGeneralMarketplaceIdentity.relation(
                                originalRetailUrl,new URL(url)).name(); } catch(Exception ignored) { }
                        trace("page.finished", "marketRelation="+relation+" attempts="+inspections
                                +" destination="+WishlistGeneralMarketplaceIdentity.diagnosticRoute(url));
                    }
                    if (retail || independentShop) trace("page.finished", "sameItem=true attempts="+inspections);
                    scheduleInspection(view,retail?350:independentShop?550:1400);
                }
                private int aliNetworkSamples;
                @Override public android.webkit.WebResourceResponse shouldInterceptRequest(
                        WebView view, WebResourceRequest request) {
                    // Observability only, never override/block/replay requests.
                    // On next device diagnostic, locate item-scoped JSON APIs;
                    // no arbitrary response is a trustworthy JPY amount.
                    if (aliNetworkSamples<8 && originalRetailUrl!=null
                            && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                == WishlistGeneralMarketplaceIdentity.Merchant.ALIEXPRESS
                            && WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)) {
                        String id=WishlistGeneralMarketplaceIdentity.itemId(originalRetailUrl);
                        String target=request.getUrl().toString();
                        String path=request.getUrl().getPath();
                        if (id!=null && ((path!=null && path.contains(id))
                                || (path!=null && path.matches("(?i).*(?:detail|product|sku|price).*")))) {
                            aliNetworkSamples++;
                            boolean itemBound=target.contains(id);
                            // Never output URL/query/body/cookies; only counters.
                            trace("aliexpress.network", "sample="+aliNetworkSamples
                                    +" itemIdInRequest="+itemBound
                                    +" resource=api-or-product noPriceProof=true");
                        }
                    }
                    return null;
                }
                @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError error) {
                    if (req.isForMainFrame()) {
                        trace("network.error", "code="+error.getErrorCode());
                        finish(null,"WebView通信エラー");
                    }
                }
                @Override public void onReceivedHttpError(WebView view, WebResourceRequest req,
                                                           android.webkit.WebResourceResponse response) {
                    if (req.isForMainFrame() && originalRetailUrl != null
                            && (retail || WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))) {
                        mainHttpCode=response.getStatusCode();
                        trace("http", "code="+mainHttpCode);
                        RetailDiagnostics.general(originalRetailUrl, "price.webview.http",
                                "code="+mainHttpCode);
                    }
                }
            });
            main.postDelayed(timeout,retail?23000:independentShop?19000:
                    WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)?27000:
                    generalProduct?18000:14000);
            // AliExpress's product JSON-LD can be an unlinked USD offer even
            // when an item URL is on ja.aliexpress.com (seen repeatedly on
            // the same device). Request the standard Japan/JPY storefront
            // preference BEFORE loading. This is not a currency conversion:
            // only site-supplied JPY price evidence may be committed. Limit
            // the cookie to .aliexpress.com and preserve every other merchant.
            if (guardedAliJapaneseLocale(url)) {
                final WebView target=web;
                final java.util.concurrent.atomic.AtomicBoolean loadOnce =
                        new java.util.concurrent.atomic.AtomicBoolean(false);
                final Runnable continueLoad = () -> {
                    if (loadOnce.compareAndSet(false,true) && !finished && web==target)
                        target.loadUrl(url.toExternalForm());
                };
                try {
                    android.webkit.CookieManager.getInstance().setCookie(
                            "https://www.aliexpress.com",
                            "aep_usuc_f=site=glo&c_tp=JPY&region=JP&b_locale=ja_JP; Domain=.aliexpress.com; Path=/; Secure",
                            success -> {
                                trace("aliexpress.locale", "requested=JP-JPY cookieAccepted="+success);
                                continueLoad.run();
                            });
                    // Preserve start even if the platform never invokes the
                    // asynchronous cookie callback; never navigate twice.
                    main.postDelayed(continueLoad,1200);
                } catch(RuntimeException cookieError) {
                    trace("aliexpress.locale", "reason=cookie-unavailable");
                    continueLoad.run();
                }
            } else web.loadUrl(url.toExternalForm());
        }catch(Exception ex) {finish(null,"WebViewを開始できず");}
    }
    private boolean guardedAliJapaneseLocale(URL saved) {
        return saved != null && generalProduct
                && WishlistGeneralMarketplaceIdentity.isDetail(saved)
                && WishlistGeneralMarketplaceIdentity.merchant(saved)
                   == WishlistGeneralMarketplaceIdentity.Merchant.ALIEXPRESS;
    }
    private boolean allowedDestination(String text) {
        try {
            URL dest=new URL(text);
            if(!"https".equalsIgnoreCase(dest.getProtocol()) || !WishlistCrawler.isAllowedUrl(dest))return false;
            String h=dest.getHost().toLowerCase(Locale.ROOT);
            if (expectedMarketplace!=null && !expectedMarketplace.matches(dest))return false;
            if(originalHost==null)return false;
            // Amazon sign-in / CAPTCHA redirects do not become new crawl targets.
            if(originalHost.equals("amazon.co.jp") || originalHost.endsWith(".amazon.co.jp"))
                return h.equals("amazon.co.jp") || h.endsWith(".amazon.co.jp");
            // The shop redirects category%3A<id> to category:<id> or removes
            // the category trail. Verify the internal product id, not text path.
            if (WishlistHonmaProductDom.isDetail(originalRetailUrl))
                return WishlistHonmaProductDom.sameItem(originalRetailUrl, dest);
            if (generalProduct && originalRetailUrl != null
                    && WishlistMode.isMujiProduct(originalRetailUrl)
                    && !originalRetailUrl.getPath().replaceAll("/+$", "")
                        .equalsIgnoreCase(dest.getPath().replaceAll("/+$", ""))) return false;
            if (originalRetailUrl != null && WishlistGeneralShopItem.isDetail(originalRetailUrl)
                    && !WishlistGeneralShopItem.sameProduct(originalRetailUrl, dest)) return false;
            if (unknownGeneralDetail && originalRetailUrl != null
                    && !WishlistGeneralVerifiedUnknownDom.samePage(originalRetailUrl, dest)) return false;
            if (independentShop && originalRetailUrl != null) {
                String expectedPath=originalRetailUrl.getPath().replaceAll("/+$", "");
                String actualPath=dest.getPath().replaceAll("/+$", "");
                if (!expectedPath.equalsIgnoreCase(actualPath)) return false;
            }
            WishlistGeneralMarketplaceIdentity.ItemRelation marketRelation = originalRetailUrl != null
                    && WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)
                    ? WishlistGeneralMarketplaceIdentity.relation(originalRetailUrl, dest) : null;
            // UNKNOWN URLs are inspected only within the original merchant family.
            // The item-bound JS refuses unbound page-wide names/prices, but a
            // verified same-item JSON state survives harmless URL rewriting.
            boolean guardedFamily = marketRelation != null
                    && marketRelation != WishlistGeneralMarketplaceIdentity.ItemRelation.DIFFERENT;
            return (h.equals(originalHost) || guardedFamily)
                    && (originalRetailUrl == null || GeneralRetailIdentity.store(originalRetailUrl) == null
                        || GeneralRetailIdentity.sameProduct(originalRetailUrl, dest))
                    && (marketRelation == null || guardedFamily);
        }catch(Exception ex){return false;}
    }
    /** Temu-only: start with the native device WebView. On a truly unhydrated
     * generic shell (NOT an explicit verification challenge), retry once with
     * the alternate desktop layout on the unchanged exact product ID. A
     * merchant verification page is never a price proof. */
    private boolean retryTemuNativeProfile(WebView view, String reason) {
        if (finished || view==null || view!=web || temuMobileProfileRetry
                || originalRetailUrl==null || temuNativeUserAgent==null
                || WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                        !=WishlistGeneralMarketplaceIdentity.Merchant.TEMU
                || !WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)) return false;
        // Never re-request a human verification gate using another UA.
        // Caller identifies stable unhydrated storefront shells only.
        java.util.regex.Matcher chrome=java.util.regex.Pattern
                .compile("Chrome/([0-9]+(?:\\.[0-9]+){1,3})")
                .matcher(temuNativeUserAgent);
        if (!chrome.find()) return false;
        temuMobileProfileRetry=true;
        trace("temu.browser.retry", "profile=desktop reason="+reason
                +" sameSavedItem=true");
        inspections=0;
        retainedMarketPrice.clear();
        marketplaceImages.clear();
        verifiedMarketplaceTitle=null;
        verifiedMarketplaceResolvedUrl=null;
        marketplacePageKind="uninspected";
        marketplaceItemEvidence="none";
        marketplaceStockStatus="UNKNOWN";
        marketplaceStockReason="profile-retry";
        stableMarketEvidence=0;
        lastMarketEvidence=null;
        temuReachedExactItem=false;
        view.stopLoading();
        String desktop="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                +"(KHTML, like Gecko) Chrome/"+chrome.group(1)+" Safari/537.36";
        view.getSettings().setUserAgentString(desktop);
        view.getSettings().setUseWideViewPort(true);
        view.getSettings().setLoadWithOverviewMode(true);
        view.loadUrl(originalRetailUrl.toExternalForm());
        return true;
    }
    private boolean manualTemuSite(String raw) {
        if(originalRetailUrl==null || raw==null
                || WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                    !=WishlistGeneralMarketplaceIdentity.Merchant.TEMU)return false;
        try{
            URL url=new URL(raw);
            String host=url.getHost().toLowerCase(Locale.ROOT);
            return "https".equalsIgnoreCase(url.getProtocol())
                    && (host.equals("temu.com")||host.endsWith(".temu.com"));
        }catch(Exception ignored){return false;}
    }

    /** The site can require a human verification step. Only a foreground
     * SINGLE-CARD update may show the real, unmodified merchant page to the
     * user. Never solve a challenge programmatically or accept page title as
     * price proof. A batch refresh cannot open an interaction dialog. */
    private boolean showTemuHumanVerification(WebView view) {
        if(!manualTemuVerificationEnabled || temuVerificationShown || finished
                || view!=web || originalRetailUrl==null
                || WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                      != WishlistGeneralMarketplaceIdentity.Merchant.TEMU
                || !WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)) return false;
        temuVerificationShown=true;
        try {
            main.removeCallbacks(timeout);
            // Only the current price WebView is temporarily made interactive.
            // The same item URL and all snapshot identity checks remain active.
            if(view.getParent() instanceof ViewGroup)
                ((ViewGroup)view.getParent()).removeView(view);
            view.setFocusable(true);
            view.setFocusableInTouchMode(true);
            view.setClickable(true);
            view.setLongClickable(true);
            view.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
            FrameLayout viewer=new FrameLayout(parent.getContext());
            int height=(int)(440*parent.getResources().getDisplayMetrics().density);
            viewer.addView(view,new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,height));
            android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(parent.getContext())
                    .setTitle("Temuの商品確認")
                    .setMessage("Temuの確認画面です。必要な操作を手動で完了後、再解析してください。商品データが表示されなければ価格・在庫は不明のままです。")
                    .setView(viewer)
                    .setPositiveButton("確認後に再解析",(d,which)->{
                        temuDialog=null;
                        if(finished || web!=view)return;
                        if(view.getParent() instanceof ViewGroup)
                            ((ViewGroup)view.getParent()).removeView(view);
                        view.setFocusable(false);view.setFocusableInTouchMode(false);
                        view.setClickable(false);view.setLongClickable(false);
                        view.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
                        parent.addView(view,0,new FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
                        inspections=0;stableMarketEvidence=0;lastMarketEvidence=null;
                        trace("temu.manual", "action=verification-completed reinspection=true");
                        main.postDelayed(timeout,14000L);
                        // Recheck ORIGINAL exact item; the verification page
                        // itself can never be treated as item evidence.
                        view.loadUrl(originalRetailUrl.toExternalForm());
                        scheduleInspection(view,1550);
                    })
                    .setNegativeButton("中断",(d,which)->{
                        temuDialog=null;
                        trace("temu.manual","action=cancelled");
                        finish(null,"Temuの確認画面で商品情報を取得できず");
                    })
                    .setOnCancelListener(d->{
                        temuDialog=null;
                        finish(null,"Temuの確認画面で商品情報を取得できず");
                    }).create();
            temuDialog=dialog;
            trace("temu.manual", "action=show-real-merchant-page itemProof=required");
            dialog.show();
            return true;
        }catch(RuntimeException ex){
            trace("temu.manual", "action=unavailable");
            return false;
        }
    }

    /** Only retry an identical numeric SKU on an alternate official route.
     * Never relax DOM identity checks or cross into promotions/listings. */
    private boolean retryExactMarketAlternate(WebView view, String reason) {
        if (view==null || view!=web || finished || marketplaceAlternateRetry
                || originalRetailUrl==null) return false;
        URL alternate=WishlistGeneralMarketplaceIdentity.fallbackExactItemUrl(originalRetailUrl);
        if (alternate==null || !WishlistGeneralMarketplaceIdentity.sameItem(originalRetailUrl,alternate))
            return false;
        marketplaceAlternateRetry=true;
        trace("navigation.retry", "reason="+reason+" destination="
                +WishlistGeneralMarketplaceIdentity.diagnosticRoute(alternate.toExternalForm()));
        inspections=0;
        retainedMarketPrice.clear();
        marketplaceImages.clear();
        verifiedMarketplaceTitle=null;
        verifiedMarketplaceResolvedUrl=null;
        marketplacePageKind="uninspected";
        marketplaceItemEvidence="none";
        marketplaceStockStatus="UNKNOWN";
        marketplaceStockReason="alternate-retry";
        stableMarketEvidence=0;
        lastMarketEvidence=null;
        view.stopLoading();
        view.loadUrl(alternate.toExternalForm());
        return true;
    }
    private void scheduleInspection(WebView view,long millis) {
        if (finished || inspectionPending || inspectionRunning || web != view) return;
        inspectionPending=true;
        main.postDelayed(() -> {
            inspectionPending=false;
            if (!finished && view == web && !inspectionRunning) inspect(view);
        },millis);
    }

    private void inspect(WebView view) {
        if (finished || view != web || inspectionRunning) return;
        // Do not run page-wide generic selectors on a navigation that lost the
        // saved market item identity, even if the host is still the same.
        if ((retail || WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
                && (view.getUrl()==null || !allowedDestination(view.getUrl()))) {
            trace("dom.skip", "reason=unverified-navigation");
            return;
        }
        inspectionRunning=true;
        inspections++;
        // DOM selectors only; never execute site-provided data as a script.
        final boolean amazon=originalHost!=null && (originalHost.equals("amazon.co.jp") || originalHost.endsWith(".amazon.co.jp"));
        boolean recognizedDetail = false;
        try { recognizedDetail = WishlistCrawler.isSingleProductPage(new URL(view.getUrl())); }
        catch (Exception ignored) { }
        final boolean retailDetail = recognizedDetail || unknownGeneralDetail;
        final String js="(function(){"+
            "var amazon="+amazon+";"+
            "var detail="+retailDetail+";"+
            "var market="+(expectedMarketplace!=null)+";"+
            "if(market){var ids=amazon?['#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen',"+
            "'#corePrice_feature_div .priceToPay .a-offscreen','#price_inside_buybox','#priceblock_ourprice']:"+
            "['#itemPrice','#item-price','.elPriceNumber','#item-price-main','.item-price','.product-detail__price'];"+
            "for(var z=0;z<ids.length;z++){var e=document.querySelector(ids[z]);if(!e)continue;"+
            "if(e.closest('[class*=recommend],[class*=related],[id*=recommend],[id*=related]'))continue;"+
            "var t=(e.getAttribute('content')||e.innerText||e.textContent||'').trim();"+
            "if(t&&t.length<90&& !/(?:送料|参考価格|ポイント|割引)/.test(t))return JSON.stringify({value:t,currency:'JPY'});}"+
            "return JSON.stringify({value:'',currency:''});}"+

            // Same-product price on two independently hosted shops, strict H1
            // plus local tax-inclusive yen text; no click or stock changes.
            "if(!amazon&&detail&&" +
            ("eshop.fumuroya.com".equals(originalHost) || "www.gojochoubei.co.jp".equals(originalHost)
                    || "gojochoubei.co.jp".equals(originalHost)) + "){"+
            "var title=document.querySelector('main h1,h1');"+
            "var expected="+ ("eshop.fumuroya.com".equals(originalHost) ? "'宝の麩'" : "'鰹ごぼう'") + ";"+
            "if(!title||!(title.textContent||'').includes(expected))return JSON.stringify({value:'',currency:''});"+
            "if(title&&(title.textContent||'').includes(expected)){"+
            "var box=title.closest('main,.product-detail,.productDetail,#main,#contents,.item-detail')||document.body;"+
            "var text=(box.innerText||box.textContent||'');var heading=(title.innerText||title.textContent||'').trim();"+
            "var at=heading?text.indexOf(heading):-1;"+
            "if(at>=0){var nearby=text.slice(at+heading.length,at+1200);"+
            "var end=nearby.search(/関連商品|おすすめ商品|この商品を見た|ご購入はこちら|商品説明|配送・送料/);if(end>=0)nearby=nearby.slice(0,end);"+
            "var m=nearby.slice(0,500).match(/[¥￥]\\s*[0-9][0-9,]*(?:\\.[0-9]{1,2})?/);"+
            "if(m&&nearby.slice(m.index,m.index+m[0].length+32).includes('税込')"+
            "&&!/(?:送料|配送料|手数料|割引|ポイント)\\s*[:：]?\\s*$/.test(nearby.slice(Math.max(0,m.index-20),m.index)))"+
            "return JSON.stringify({value:m[0],currency:'JPY'});"+
            "}}}"+
            // A clearly labeled minimum takes precedence over numeric metadata.
            "if(!amazon&&detail){"+
            "var scope=document.querySelector('main,[role=main],#main,#contents,.product-detail,.item-detail')||document.body;"+
            "var txt=(scope.innerText||'').slice(0,8000);"+
            "var stop=txt.search(/関連商品|おすすめ商品|この商品を見た|一緒に購入/);if(stop>=0)txt=txt.slice(0,stop);"+
            "var label=txt.match(/(?:^|\\n|\\s)(?:販売価格|商品価格|税込価格|価格)\\s*[:：]?\\s*([^\\n]{1,50})/);"+
            "if(label&&/[¥￥]|[0-9]\\s*円/.test(label[1])){"+
            "return JSON.stringify({value:label[1],currency:'JPY'});}"+
            "}"+
            "var a=["+
            "'#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen',"+
            "'#corePrice_feature_div .priceToPay .a-offscreen',"+
            "'#apex_desktop .priceToPay .a-offscreen',"+
            "'#price_inside_buybox','#priceblock_dealprice','#priceblock_ourprice',"+
            "'.priceToPay .a-offscreen','[itemprop=price]',"+
            "'.product-detail__price','.productDetail__price',"+
            "'.productDetail .price','.product-detail .price',"+
            "'.product-price','.productPrice','.product_price',"+
            "'.p-product-detail__price','.p-productDetail__price',"+
            "'#product-price','#item-price','.item-price',"+
            "'[data-product-price]'];"+
            "for(var i=0;i<a.length;i++){if(i<7&&!amazon)continue;"+
            "var e=document.querySelector(a[i]);if(!e)continue;"+
            "var s=e.getAttribute('content')||e.textContent||'';"+
            "var cur=document.querySelector('[itemprop=priceCurrency],meta[itemprop=priceCurrency]');"+
            "var cv=cur?(cur.getAttribute('content')||cur.textContent||''):'';"+
            "if(i>=8&&!amazon){if(!detail||s.length>110||/(?:送料|ポイント|割引|値引|クーポン|関連商品|おすすめ)/.test(s))continue;"+
            "var many=s.match(/[¥￥]\\s*[0-9][0-9,]*(?:\\.[0-9]+)?|[0-9][0-9,]*\\s*円/g);"+
            "if(many&&many.length!==1)continue;}"+
            "if(s.trim()&&(amazon||cv.trim()==='JPY'||/¥|￥|円/.test(s)))return JSON.stringify({value:s,currency:amazon?'JPY':cv});}"+
            "var m=document.querySelector('meta[property=\"product:price:amount\"],meta[property=\"og:price:amount\"]');"+
            "var c=document.querySelector('meta[property=\"product:price:currency\"],meta[property=\"og:price:currency\"]');"+
            "if(m&&m.content&&c&&c.content==='JPY')return JSON.stringify({value:m.content,currency:'JPY'});"+
            "var scripts=document.querySelectorAll('script[type=\"application/ld+json\"]');"+
            "function offer(o,d,cur){if(!o||d>8)return null;"+
            "if(Array.isArray(o)){for(var i=0;i<Math.min(30,o.length);i++){var r=offer(o[i],d+1,cur);if(r)return r;}return null;}"+
            "if(typeof o!=='object')return null;var typ=String(o['@type']||'').toLowerCase();"+
            "if(typ.indexOf('aggregateoffer')>=0)return null;"+
            "var cc=o.priceCurrency||cur||'';if(String(cc).toUpperCase()==='JPY'&&(o.price||o.value))return String(o.price||o.value);"+
            "return offer(o.priceSpecification,d+1,cc)||offer(o.offers,d+1,cc);}"+
            "function product(o,d){if(!o||d>8)return null;"+
            "if(Array.isArray(o)){for(var i=0;i<Math.min(40,o.length);i++){var r=product(o[i],d+1);if(r)return r;}return null;}"+
            "if(typeof o!=='object')return null;var typ=String(o['@type']||'').toLowerCase();"+
            "if(typ==='product'||typ.endsWith('/product'))return offer(o.offers,d+1,'');"+
            "return product(o['@graph'],d+1)||product(o.mainEntity,d+1);}"+
            "for(var i=0;i<Math.min(30,scripts.length);i++){try{var v=product(JSON.parse(scripts[i].textContent),0);"+
            "if(v)return JSON.stringify({value:v,currency:'JPY'});}catch(e){}}"+
            // For a genuine product detail page only: read a short visible price
            // phrase near the product heading, never site-wide recommendations.
            "if(!amazon&&detail){"+
            "var root=document.querySelector('main,[role=main],#main,#contents,.product-detail,.item-detail')||document.body;"+
            "var body=(root.innerText||'').slice(0,7000);"+
            "var bound=body.search(/関連商品|おすすめ商品|この商品を見た|一緒に購入/);"+
            "if(bound>=0)body=body.slice(0,bound);"+
            "var tagged=body.match(/(?:販売価格|商品価格|税込価格)\\s*[:：]?\\s*([¥￥]\\s*[0-9][0-9,]*(?:\\s*[～〜~-]\\s*[¥￥]?[0-9,]*)?|[0-9][0-9,]*\\s*円(?:\\s*[～〜~-]\\s*[0-9,]*\\s*円?)?)/);"+
            "if(tagged)return JSON.stringify({value:tagged[1],currency:'JPY'});"+
            "var h=document.querySelector('main h1,h1');"+
            "if(h){var node=h.parentElement;for(var n=0;node&&n<3;n++,node=node.parentElement){"+
            "var text=(node.innerText||'').slice(0,600);"+
            "var slice=text.slice(text.indexOf(h.innerText||'')+(h.innerText||'').length);"+
            "var boundary=slice.search(/商品説明|関連商品|おすすめ商品|よく一緒に|送料/);"+
            "if(boundary>=0)slice=slice.slice(0,boundary);"+
            "var matches=slice.match(/[¥￥]\\s*[0-9][0-9,]*(?:\\.[0-9]+)?|[0-9][0-9,]*\\s*円/g);"+
            "if(matches&&matches.length===1)return JSON.stringify({value:matches[0],currency:'JPY'});"+
            "}}}"+
            "return JSON.stringify({value:'',currency:''});"+
            "})()";
        // Do not run site-wide fallback selectors on Fumuroya: the previous
        // variant returned a 22-yen paper bag as the main product price.
        String strictFumuroyaJs = null;
        if ("eshop.fumuroya.com".equals(originalHost) && originalRetailUrl != null
                && originalRetailUrl.getPath().matches("/product/detail/300840/?")) {
            strictFumuroyaJs = """
(function(){'use strict';
 const empty=()=>JSON.stringify({value:'',currency:''});
 try {
   if(!/^\\/product\\/detail\\/300840\\/?$/.test(location.pathname))return empty();
   const h=document.querySelector('main h1,h1');
   if(!h||!/宝の麩/.test(h.textContent||''))return empty();
   const exclusion=e=>!!e.closest('header,footer,nav,aside,[class*=recommend],[class*=related],'+
     '[class*=option],[class*=accessory],[class*=bag],[class*=giftbag]');
   const root=h.closest('main,[role=main],#main,#contents,.product-detail,.productDetail,.item-detail')||document.body;
   // Accept only a product-specific price element with a single monetary value.
   // Never walk from H1 into body text to select the first incidental price.
   const selectors=['[itemprop=price]','.product-detail__price','.productDetail__price',
     '.product-price','.productPrice','.product_price','.p-product-detail__price',
     '.price-box .price','.sale-price','[data-product-price]'];
   const candidates=[];
   for(const selector of selectors) for(const e of root.querySelectorAll(selector)) {
     if(exclusion(e))continue;
     const t=String(e.getAttribute('content')||e.getAttribute('data-product-price')||e.textContent||'').trim();
     const matches=t.match(/(?:[¥￥]\\s*[0-9][0-9,]*|[0-9][0-9,]*\\s*円)/g)||[];
     if(matches.length!==1)continue;
     const n=Number(matches[0].replace(/[^0-9]/g,''));
     if(!Number.isSafeInteger(n)||n<500||n>30000)continue;
     candidates.push(n);
   }
   // If markup offers multiple conflicting prices, refuse to guess.
   if(candidates.length&&candidates.every(p=>p===candidates[0]))
     return JSON.stringify({value:String(candidates[0]),currency:'JPY'});
   // An explicit main-product price label can stand alone, but not a paper-bag label.
   const container=h.parentElement&&h.parentElement.parentElement;
   if(container&&root.contains(container)) {
     const s=String(container.innerText||container.textContent||'').slice(0,800);
     const m=s.match(/(?:販売価格|商品価格|税込価格)[\\s：:]*[¥￥]\\s*([0-9][0-9,]*)/);
     if(m&&!/(?:手提げ袋|紙袋|送料|ラッピング|オプション)/.test(s.slice(Math.max(0,m.index-26),m.index))) {
       const n=Number(m[1].replace(/,/g,''));
       if(n>=500&&n<=30000)return JSON.stringify({value:String(n),currency:'JPY'});
     }
   }
   return empty();
 }catch(_){return empty();}
})()
""";
        }
        String actualJs=js;
        if (originalRetailUrl != null && WishlistHonmaProductDom.isDetail(originalRetailUrl))
            actualJs=WishlistHonmaProductDom.priceJavascript(originalRetailUrl);
        if (expectedMarketplace == null && originalRetailUrl != null
                && GeneralRetailIdentity.store(originalRetailUrl) != null) {
            actualJs=GeneralRetailPriceDom.javascript(originalHost,
                    GeneralRetailIdentity.itemId(originalRetailUrl));
        }
        if(expectedMarketplace!=null){
            switch(expectedMarketplace.site){
                case AMAZON: actualJs=AmazonDomSelectors.price();break;
                case RAKUTEN: actualJs=RakutenDomSelectors.price();break;
                case YAHOO: actualJs=YahooDomSelectors.price();break;
                default: finish(null,"未対応サイト");return;
            }
        }
        // GENERAL marketplaces: use only exact-item hydrated product data.
        // A missing or ambiguous record stays UNKNOWN/price-null. Never fall back
        // to an unrelated page-wide Product offer or promotional price.
        final boolean guardedHydration = originalRetailUrl != null
                && WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl)
                && !retail && expectedMarketplace == null;
        if (guardedHydration && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                == WishlistGeneralMarketplaceIdentity.Merchant.SHEIN) {
            // SHEIN-only combined hydration. AliExpress and Temu run their
            // own complete item-bound scripts without evaluating this engine.
            // First try ID-bound hydrated objects, then separately verified
            // Product JSON-LD / canonical-bound rendered metadata on SAME URL.
            // None of this infers inventory or accepts a store-wide price.
            actualJs = "(function(){try{var a=JSON.parse("
                    + WishlistGeneralMarketplaceHydrationDom.javascript(originalRetailUrl)
                    + ");var b=JSON.parse("
                    + WishlistGeneralMarketplaceVerifiedDom.javascript(originalRetailUrl)
                    + ");if(b.reason==='canonical-other-item'||b.reason==='navigation-other-item'||b.reason==='challenge-visible'){"
                    + "a.title='';a.value='';a.currency='';a.reason=b.reason;}"
                    + "else{if(!a.title)a.title=b.title||'';"
                    + "if(!a.value&&b.value){a.value=b.value;a.currency=b.currency;}"
                    + "if(a.reason==='id-unverified'&&(a.title||a.value))a.reason='verified-dom-metadata';}"
                    + "var d=JSON.parse(" + WishlistSheinItemDom.javascript(originalRetailUrl) + ");"
                    + "a.priceSource=a.value?'hydrated-or-verified':'none';"
                    + "if(d&&d.identity!=='other-item'&&d.identity!=='canonical-other-item'"
                    + "&&b.reason!=='canonical-other-item'&&b.reason!=='navigation-other-item'"
                    + "&&b.reason!=='challenge-visible'){"
                    + "if(d.value&&!a.value){a.value=d.value;a.currency=d.currency;a.priceSource=d.priceSource;"
                    + "if(a.reason==='id-unverified')a.reason='shein-bound-price';}"
                    + "else if(d.value&&a.value&&d.value!==a.value){a.value='';a.currency='';a.priceSource='conflicting-sources';}"
                    + "a.stockStatus=d.stock||'UNKNOWN';a.stockReason=d.stockReason||'none';}"
                    + "a.sheinAudit=d&&d.identity||'none';a.priceNodes=d&&d.priceNodes||0;"
                    + "a.priceTokens=d&&d.priceTokens||0;a.priceLabel=!!(d&&d.priceLabel);"
                    + "a.cartCount=d&&d.cartCount||0;a.jsonOffers=d&&d.jsonOffers||0;"
                    + "a.verifiedReason=b.reason;a.canonical=b.canonical;"
                    + "a.productNodes=b.productNodes;a.heading=b.heading;a.pageKind=b.pageKind;a.canonicalRoute=b.canonicalRoute;"
                    + "a.itemEvidence=a.idBound===true?'hydrated-id':"
                    + "(b.reason==='verified-product-metadata'?'verified-product':'none');"
                    + "var c=JSON.parse(" + WishlistGeneralMarketplaceImageDom.javascript(originalRetailUrl) + ");"
                    + "if(!Array.isArray(c))c=[];"
                    + "var imgs=(a.idBound===true&&Array.isArray(a.images)?a.images:[]).concat(c);"
                    + "a.imageCandidates=(b.reason==='canonical-other-item'||"
                    + "b.reason==='navigation-other-item'||b.reason==='challenge-visible')"
                    + "?[]:Array.from(new Set(imgs)).slice(0,6);"
                    + "return JSON.stringify(a);}catch(_){return JSON.stringify({value:'',reason:'combined-script-error'});}})()";
        }
        // Independent merchant-specific parsers. SHEIN retains its proven
        // current-price path; Temu has its own isolated product snapshot;
        // AliExpress supplements the existing strict ID-bound hydration.
        if (guardedHydration && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                == WishlistGeneralMarketplaceIdentity.Merchant.TEMU) {
            actualJs=WishlistTemuItemDom.javascript(originalRetailUrl);
        } else if (guardedHydration && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                == WishlistGeneralMarketplaceIdentity.Merchant.ALIEXPRESS) {
            // AliExpress is independent: execute only its own ID-bound parser.
            // The old combined generalized/SHEIN script cannot identify a
            // store banner and adds work without giving item proof.
            actualJs=WishlistAliItemDom.javascript(originalRetailUrl);
        }
        else if (unknownGeneralDetail && originalRetailUrl != null)
            actualJs = WishlistGeneralVerifiedUnknownDom.javascript(originalRetailUrl);
        // Never fall through to generic shop-wide recommendations for this SKU.
        if (strictFumuroyaJs != null) actualJs = strictFumuroyaJs;
        if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
            trace("script.select", "hydration="+guardedHydration
                    +" attempts="+inspections+" urlVerified="
                    +(view.getUrl()!=null && allowedDestination(view.getUrl())));
        try {
            final int evaluatingMarketGeneration=marketDocumentGeneration;
            view.evaluateJavascript(actualJs, returned -> {
                inspectionRunning=false;
                if(finished)return;
                if (guardedHydration && evaluatingMarketGeneration!=marketDocumentGeneration) {
                    trace("snapshot.stale", "reason=main-frame-changed retry=true");
                    scheduleInspection(view,300);
                    return;
                }
                try {
                    String json=new JSONArray("["+returned+"]").getString(0);
                    JSONObject o=new JSONObject(json);
                    String val=o.optString("value","");
                    String currency=o.optString("currency","");
                    if (independentShop) {
                        trace("dom", "attempt="+inspections+" price="+!val.isEmpty()
                                +" sameItem=true");
                    }
                    if (unknownGeneralDetail) {
                        String reason=o.optString("reason","data-missing");
                        trace("verified-jsonld", "attempt="+inspections+" reason="
                                +(reason.matches("[a-z-]{1,35}")?reason:"invalid")
                                +" images="+(o.optJSONArray("images")==null?0:o.optJSONArray("images").length()));
                    }
                    if (guardedHydration) {
                        if (WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                == WishlistGeneralMarketplaceIdentity.Merchant.TEMU
                                && (inspections==1 || inspections==2
                                    || inspections==GENERAL_PRODUCT_INSPECTIONS
                                    || "unbound-url".equals(o.optString("pageKind", "")))) {
                            JSONObject t=o.optJSONObject("temuAudit");
                            if (t!=null) {
                                String nativeRoute=WishlistGeneralMarketplaceIdentity.diagnosticRoute(view.getUrl());
                                trace("temu.document.audit", "attempt="+inspections
                                        +" native="+nativeRoute
                                        +" href="+t.optString("href","missing").replaceAll("[^a-z-]", "")
                                        +" document="+t.optString("docUrl","missing").replaceAll("[^a-z-]", "")
                                        +" urlDiff="+t.optBoolean("docUrlDiff",false)
                                        +" denied="+temuPreventedRedirects
                                        +" ready="+o.optString("ready","unknown").replaceAll("[^a-z]", "")
                                        +" body="+t.optInt("bodyChars",0)
                                        +" children="+t.optInt("bodyChildren",0)
                                        +" scripts="+t.optInt("scripts",0)
                                        +" jsonld="+t.optInt("ldScripts",0)
                                        +" frames="+t.optInt("frames",0)
                                        +" headings="+t.optInt("h1",0)
                                        +" buttons="+t.optInt("buttons",0)
                                        +" appRoot="+t.optBoolean("appRoot",false)
                                        +" nextData="+t.optBoolean("nextData",false)
                                        +" globalState="+t.optBoolean("globalState",false)
                                        +" stateRecords="+t.optInt("stateRecords",0)
                                        +" skeletons="+t.optInt("loadingNodes",0)
                                        +" titleKind="+t.optString("titleKind","unknown").replaceAll("[^a-z-]", "")
                                        +" bodyKind="+t.optString("bodyKind","unknown").replaceAll("[^a-z-]", "")
                                        +" itemText="+t.optBoolean("inlineItemId",false));
                            } else trace("temu.document.audit", "attempt="+inspections+" audit=missing");
                        }
                        if (WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                == WishlistGeneralMarketplaceIdentity.Merchant.ALIEXPRESS
                                && (inspections==1 || inspections==GENERAL_PRODUCT_INSPECTIONS)) {
                            JSONObject audit=o.optJSONObject("aliAudit");
                            if (audit!=null) trace("aliexpress.document.audit", "attempt="+inspections
                                    +" body="+audit.optInt("bodyChars",0)
                                    +" jsonLd="+audit.optInt("jsonLdNodes",0)
                                    +" boundProducts="+audit.optInt("boundProductRecords",0)
                                    +" unlinkedProducts="+audit.optInt("unlinkedProductRecords",0)
                                    +" unlinkedName="+audit.optBoolean("unlinkedHasName",false)
                                    +" unlinkedOffers="+audit.optInt("unlinkedOfferCount",0)
                                    +" unlinkedJpy="+audit.optBoolean("unlinkedSingleJpyPrice",false)
                                    +" metadataOnly="+audit.optBoolean("metadataOnly",false)
                                    +" offerCurrency="+audit.optString("unlinkedCurrency","none").replaceAll("[^A-Z]", "")
                                    +" offerShape="+audit.optString("unlinkedPriceShape","none").replaceAll("[^a-z]", "")
                                    +" headings="+audit.optInt("headings",0)
                                    +" priceNodes="+audit.optInt("productPriceNodes",0)
                                    +" runParams="+audit.optBoolean("hasRunParams",false)
                                    +" idBoundRunParams="+audit.optBoolean("runParamsItem",false)
                                    +" appGate="+audit.optBoolean("appGate",false)
                                    +" verifyGate="+audit.optBoolean("verifyGate",false));
                        }
                        marketplacePageKind=o.optString("pageKind", "unknown").replaceAll("[^a-z-]", "");
                        marketplaceItemEvidence=o.optString("itemEvidence", "none")
                                .replaceAll("[^a-z-]", "");
                        String snapshotReason=o.optString("reason", "none");
                        if ("canonical-other-item".equals(snapshotReason)
                                || "navigation-other-item".equals(snapshotReason)
                                || "challenge-visible".equals(snapshotReason)) {
                            // Evidence in a previous DOM may no longer apply.
                            retainedMarketPrice.clear();
                            marketplaceImages.clear();
                            verifiedMarketplaceTitle=null;
        verifiedMarketplaceResolvedUrl=null;
                            marketplaceItemEvidence="none";
                            marketplaceStockStatus="UNKNOWN";
                            marketplaceStockReason="blocked-or-other-item";
                        }
                        // The SHEIN-only proof is read from this exact loaded product page.
                        // It cannot be inherited across navigation or from a header cart.
                        String marketStock=o.optString("stockStatus", "UNKNOWN");
                        marketplaceStockStatus=("AVAILABLE".equals(marketStock)
                                || "UNAVAILABLE".equals(marketStock)) ? marketStock : "UNKNOWN";
                        marketplaceStockReason=o.optString("stockReason", "none");
                        if (inspections==1 || inspections==GENERAL_PRODUCT_INSPECTIONS
                                || !"UNKNOWN".equals(marketplaceStockStatus) || !val.isEmpty())
                            trace(WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                    ==WishlistGeneralMarketplaceIdentity.Merchant.SHEIN
                                    ? "shein.fields" : "merchant.fields", "attempt="+inspections
                                    +" merchant="+WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                    +" identity="+o.optString("sheinAudit",o.optString("itemEvidence","none")).replaceAll("[^a-z-]", "")
                                    +" price="+(!val.isEmpty())
                                    +" priceSource="+o.optString("priceSource","none").replaceAll("[^a-z-]", "")
                                    +" priceNodes="+o.optInt("priceNodes",0)
                                    +" yenTokens="+o.optInt("priceTokens",0)
                                    +" label="+o.optBoolean("priceLabel",false)
                                    +" offers="+o.optInt("jsonOffers",0)
                                    +" carts="+o.optInt("cartCount",0)
                                    +" stock="+marketplaceStockStatus
                                    +" stockReason="+marketplaceStockReason.replaceAll("[^a-z-]", ""));
                        JSONArray snapshotImages=o.optJSONArray("imageCandidates");
                        if (snapshotImages!=null) for(int i=0;i<Math.min(6,snapshotImages.length());i++) {
                            String candidate=snapshotImages.optString(i, "");
                            // Images are produced exclusively by the existing
                            // item-bound gallery selector; require HTTPS again.
                            try { URL safe=new URL(candidate);
                                if ("https".equalsIgnoreCase(safe.getProtocol())
                                        && marketplaceImages.size()<6) marketplaceImages.add(safe.toExternalForm());
                            }catch(Exception ignored) { }
                        }
                        if (inspections==1 || !marketplaceImages.isEmpty()
                                || inspections==GENERAL_PRODUCT_INSPECTIONS)
                            trace("snapshot", "page="+marketplacePageKind
                                    +" evidence="+marketplaceItemEvidence
                                    +" images="+marketplaceImages.size());
                        String title=o.optString("title", "").replaceAll("\\s+", " ").trim();
                        if (title.length() >= 4 && title.length() <= 240) {
                            verifiedMarketplaceTitle=title;
                            if(originalRetailUrl!=null && view.getUrl()!=null) try{
                                if(WishlistGeneralMarketplaceIdentity.sameItem(originalRetailUrl,
                                        new URL(view.getUrl())))
                                    verifiedMarketplaceResolvedUrl=originalRetailUrl.toExternalForm();
                            }catch(Exception ignored){}
                        }
                        if (inspections == 1 || verifiedMarketplaceTitle != null
                                || inspections == GENERAL_PRODUCT_INSPECTIONS) {
                            trace("metadata", "attempt="+inspections+" title="+(verifiedMarketplaceTitle!=null)
                                    +" verifiedReason="+o.optString("verifiedReason","none").replaceAll("[^a-z-]", "")
                                    +" canonical="+o.optString("canonical","unknown").replaceAll("[^a-z-]", "")
                                    +" canonicalRoute="+o.optString("canonicalRoute","missing").replaceAll("[^a-zA-Z0-9/._%-]", "")
                                    +" productNodes="+o.optInt("productNodes",0)
                                    +" heading="+o.optBoolean("heading",false));
                        }
                        String reason=o.optString("reason","data-missing");
                        lastReason=reason.matches("[a-z-]{1,50}") ? reason : "invalid-reason";
                        trace("hydration", "attempt="+inspections+" reason="
                                +(reason.matches("[a-z-]{1,35}")?reason:"invalid")
                                +" source="+o.optString("source","none").replaceAll("[^a-zA-Z-]", "")
                                +" images="+(o.optJSONArray("images")==null?0:o.optJSONArray("images").length())
                                +" ready="+o.optString("ready","unknown").replaceAll("[^a-z]", "")
                                +" blocked="+o.optBoolean("blocked",false)
                                +" chars="+o.optInt("bodyChars",0));
                        String pageKind=o.optString("pageKind", "unknown").replaceAll("[^a-z-]", "");
                        String ready=o.optString("ready", "unknown");
                        int chars=o.optInt("bodyChars",0);
                        int nodes=o.optInt("productNodes",0);
                        String verified=o.optString("verifiedReason", "none");
                        // The live SHEIN failure repeatedly inspected one fully
                        // loaded non-product document without a single item node.
                        // Stop after stability is proven, not after eleven guesses.
                        // SHEIN has a real merchant challenge document on /challenge.
                        // A saved item URL and HTTP 200 cannot turn that into a
                        // confirmed product. Detect it independently of BODY text:
                        // some challenge variants never print 'captcha' in text.
                        boolean sheinChallenge=false;
                        if (WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                == WishlistGeneralMarketplaceIdentity.Merchant.SHEIN) {
                            sheinChallenge="challenge-visible".equals(verified)
                                    || "challenge-visible".equals(reason)
                                    || o.optBoolean("blocked",false);
                            try {
                                URL current=new URL(view.getUrl());
                                sheinChallenge |= current.getHost().toLowerCase(Locale.ROOT).endsWith(".shein.com")
                                        && current.getPath().matches("(?i).*(?:challenge|captcha|robot|risk).*?");
                            } catch (Exception ignored) { }
                        }
                        boolean blockedMarket = ("challenge-visible".equals(reason)
                                || "challenge-visible".equals(verified))
                                && (WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                        == WishlistGeneralMarketplaceIdentity.Merchant.TEMU
                                    || WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                        == WishlistGeneralMarketplaceIdentity.Merchant.ALIEXPRESS);
                        boolean unbound = ("id-unverified".equals(reason)
                                && "unbound-url".equals(pageKind)
                                && !o.optBoolean("heading", false) && nodes == 0
                                && ("unbound-navigation".equals(verified)
                                    || "product-data-unverified".equals(verified)))
                                || sheinChallenge || blockedMarket;
                        String fingerprint=pageKind+":"+reason+":"+verified+":"+chars+":"+nodes;
                        if ("complete".equals(ready) && unbound && chars > 0) {
                            stableMarketEvidence=fingerprint.equals(lastMarketEvidence)
                                    ? stableMarketEvidence+1 : 1;
                            lastMarketEvidence=fingerprint;
                        } else { stableMarketEvidence=0; lastMarketEvidence=null; }
                        if (inspections==1 || inspections==GENERAL_PRODUCT_INSPECTIONS
                                || stableMarketEvidence>=3)
                            trace("page.audit", "kind="+pageKind+" ready="+ready.replaceAll("[^a-z]", "")
                                    +" productNodes="+nodes+" stable="+stableMarketEvidence
                                    +" boundName="+(verifiedMarketplaceTitle!=null)
                                    +" boundPrice="+!val.isEmpty());
                        if (stableMarketEvidence>=(sheinChallenge?2:3) && val.isEmpty()) {
                            // A verified merchant challenge is NOT an item loading
                            // delay. Replaying it under another UA/URL cannot
                            // manufacture item-bound data; report it as such.
                            if (blockedMarket) {
                                // Only Temu: the saved regional route can be a
                                // merchant verification shell while the public
                                // /goods.html?goods_id= exact-item route works.
                                // Try that OFFICIAL same-ID URL once; never
                                // treat a challenge as product proof, click a
                                // verification widget, or alter other shops.
                                if (WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                        == WishlistGeneralMarketplaceIdentity.Merchant.TEMU
                                        && retryExactMarketAlternate(view,"merchant-challenge-exact-route"))
                                    return;
                                if (WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                        == WishlistGeneralMarketplaceIdentity.Merchant.TEMU
                                        && showTemuHumanVerification(view)) return;
                                trace("inspection.stop", "reason=merchant-challenge-visible"
                                        +" attempts="+inspections+" itemPrice=false"
                                        +" alternateTried="+marketplaceAlternateRetry);
                                finish(null, WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                        == WishlistGeneralMarketplaceIdentity.Merchant.TEMU
                                        ? "Temuの確認画面で商品情報を取得できず"
                                        : "AliExpressの確認画面で商品情報を取得できず");
                                return;
                            }
                            if (sheinChallenge) trace("shein.challenge", "reason=merchant-verification-page"
                                    +" itemPrice=false itemTitle="+(verifiedMarketplaceTitle!=null));
                            // SHEIN mobile URLs sometimes resolve to a non-item
                            // storefront. Try the official Japanese SHEIN host
                            // ONCE using the exact saved path and item ID.
                            // Same merchant, same SKU: all existing ID checks
                            // remain in force. Never try a guessed product ID.
                            if (!sheinRegionalRetry && originalRetailUrl != null
                                    && "m.shein.com".equals(originalHost)) {
                                sheinRegionalRetry=true;
                                try {
                                    URL alternate=WishlistGeneralMarketplaceIdentity.japanDesktopUrl(originalRetailUrl);
                                    if (alternate != null) {
                                        trace("navigation.retry", "reason=unbound-mobile-page"
                                                +" target=regional-same-item destination="
                                                +WishlistGeneralMarketplaceIdentity.diagnosticRoute(alternate.toExternalForm()));
                                        inspections=0;
                                        retainedMarketPrice.clear();
                                        marketplaceImages.clear();
                                        verifiedMarketplaceTitle=null;
        verifiedMarketplaceResolvedUrl=null;
                                        marketplacePageKind="uninspected";
                                        marketplaceItemEvidence="none";
                                        marketplaceStockStatus="UNKNOWN";
                                        marketplaceStockReason="retry-reset";
                                        stableMarketEvidence=0;
                                        lastMarketEvidence=null;
                                        view.stopLoading();
                                        view.loadUrl(alternate.toExternalForm());
                                        return;
                                    }
                                } catch (Exception ignored) { }
                            }
                            if (retryTemuNativeProfile(view,"stable-unbound-or-challenge")) return;
                            if (retryExactMarketAlternate(view,"stable-unbound-document")) return;
                            if (WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                    == WishlistGeneralMarketplaceIdentity.Merchant.TEMU)
                                trace("temu.document.verdict", "reason=stable-unbound-document"
                                        +" blockedNavigations="+temuPreventedRedirects
                                        +" itemPrice="+(retainedMarketPrice.get()!=null)
                                        +" itemTitle="+(verifiedMarketplaceTitle!=null));
                            trace("inspection.stop", "reason=stable-unbound-marketplace-document"
                                    +" attempts="+inspections+" regionalRetry="+sheinRegionalRetry);
                            finish(null, sheinChallenge ? "SHEINの確認画面で商品情報を取得できず"
                                    : "商品ページの内容を確認できず");
                            return;
                        }
                    }
                    if (retail) {
                        String reason=o.optString("reason","no-price");
                        lastReason=reason.matches("[a-z-]{1,50}")?reason:"invalid-reason";
                        trace("dom", "attempt="+inspections+" price="+!val.isEmpty()
                                +" reason="+lastReason+" mainHTTP="+mainHttpCode);
                        if ("askul.co.jp".equals(originalHost) || "www.askul.co.jp".equals(originalHost)) {
                            if (inspections == 1 || inspections == 5 || !val.isEmpty()
                                    || inspections == RETAIL_INSPECTIONS) {
                                trace("page.evidence", "attempt="+inspections
                                        +" bodyChars="+o.optInt("bodyChars",0)
                                        +" h1="+o.optBoolean("h1",false)
                                        +" skuLabel="+o.optBoolean("skuLabel",false)
                                        +" restrictedHint="+o.optBoolean("blocked",false));
                            }
                        }
                    }
                    WishlistRetailPriceQuote quote = retailDetail && !amazon ?
                            WishlistRetailPriceQuote.fromBareText(val) : null;
                    if (quote != null) { finish(null, quote, null); return; }
                    Long price=WishlistPriceExtractor.parseDomValue(val,currency);
                    if (guardedHydration) {
                        boolean itemPage="item-url".equals(marketplacePageKind)
                                || "item-bound-jsonld".equals(marketplacePageKind);
                        boolean denied="canonical-other-item".equals(lastReason)
                                || "navigation-other-item".equals(lastReason)
                                || "challenge-visible".equals(lastReason);
                        if (denied || !itemPage) {
                            retainedMarketPrice.clear();
                            price=null;
                        } else {
                            retainedMarketPrice.offer(price);
                            if (retainedMarketPrice.conflicted()) {
                                trace("snapshot.price", "reason=contradictory-item-prices attempts="+inspections);
                                price=null;
                            } else if (price == null && retainedMarketPrice.get() != null) {
                                price=retainedMarketPrice.get();
                                if (inspections==2 || inspections==4 || inspections==GENERAL_PRODUCT_INSPECTIONS)
                                    trace("snapshot.price", "reason=retained-same-document attempts="+inspections);
                            }
                        }
                    }
                    // Temu can remain at an exact saved item URL while returning
                    // only a generic item shell. A syntactically valid URL is
                    // not product evidence; try native Android profile once,
                    // then the alternate official SAME-ID route when possible.
                    if (guardedHydration && price == null && inspections >= 5
                            && verifiedMarketplaceTitle == null
                            && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                == WishlistGeneralMarketplaceIdentity.Merchant.TEMU
                            && o.optInt("stateRecords",0)==0
                            && o.optInt("jsonOffers",0)==0
                            && o.optInt("priceNodes",0)==0) {
                        if (!"challenge-visible".equals(lastReason)
                                && retryTemuNativeProfile(view,"unhydrated-item-document")) return;
                        if (inspections >= 7
                                && retryExactMarketAlternate(view,"unhydrated-native-item")) return;
                    }
                    // AliExpress may load a syntactically correct /item/ URL
                    // containing only a generic web shell (the observed 8kB DOM).
                    // An alternate same-ID official hostname is worth exactly one
                    // attempt; a matching URL by itself is never a price proof.
                    if (guardedHydration && price == null && inspections >= 5
                            && verifiedMarketplaceTitle == null
                            && WishlistGeneralMarketplaceIdentity.merchant(originalRetailUrl)
                                == WishlistGeneralMarketplaceIdentity.Merchant.ALIEXPRESS
                            && o.optInt("jsonOffers",0)==0
                            && o.optInt("priceNodes",0)==0
                            && retryExactMarketAlternate(view,"unhydrated-item-document")) return;
                    if (price != null) {
                        // A marketplace price can arrive before its title,
                        // gallery or purchase-state data. The previous early
                        // finish lost that later evidence (observed on SHEIN).
                        // Inspect a few more times in the SAME WebView; never
                        // start another browser or substitute unrelated data.
                        if (guardedHydration && inspections < 4
                                && (verifiedMarketplaceTitle == null
                                    || marketplaceImages.isEmpty())) {
                            trace("snapshot.defer", "attempt="+inspections
                                    +" reason=await-same-item-fields"
                                    +" name="+(verifiedMarketplaceTitle!=null)
                                    +" images="+marketplaceImages.size()
                                    +" stock="+marketplaceStockStatus);
                            scheduleInspection(view, 1000);
                        } else if (isAskul()) inspectAskulStock(view, price);
                        else finish(price, null);
                    }
                    else if (inspections < (retail ? RETAIL_INSPECTIONS
                            : independentShop ? INDEPENDENT_INSPECTIONS
                            : generalProduct ? GENERAL_PRODUCT_INSPECTIONS : MAX_INSPECTIONS))
                        scheduleInspection(view, retail?1400:independentShop?1300:1100);
                    else finish(null, "WebViewにも価格情報なし");
                }catch(Exception ex){
                    // A transient WebView null/malformed callback must not turn
                    // a previously working MUJI price into a permanent failure.
                    // Log the exception class only, never page text or personal data.
                    String category=returned==null?"null-result":returned.isBlank()?"empty-result"
                            :ex.getClass().getSimpleName().replaceAll("[^A-Za-z]", "");
                    trace("dom.error", "attempt="+inspections+" kind="+category
                            +" mainHTTP="+mainHttpCode);
                    if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
                        trace("hydration.error", "attempt="+inspections+" type="+category);
                    // GU sometimes fires evaluateJavascript while the SPA has
                    // not yet hydrated. A null/malformed JSON callback on that
                    // first poll is not evidence that the SKU has no price.
                    // Retry ONLY GU (max two extra polls); all existing shop
                    // readers keep their previous error semantics.
                    boolean guTransient = generalProduct && originalRetailUrl != null
                            && WishlistGeneralShopItem.merchant(originalRetailUrl)
                                    == WishlistGeneralShopItem.Merchant.GU
                            && inspections < 3
                            && (returned == null || returned.isBlank()
                                || "null".equals(returned.trim())
                                || ex instanceof org.json.JSONException);
                    if ((generalProduct && originalRetailUrl != null
                            && WishlistMode.isMujiProduct(originalRetailUrl)
                            && inspections < GENERAL_PRODUCT_INSPECTIONS) || guTransient) {
                        if (guTransient) trace("gu.price.retry", "reason=transient-json-callback attempt="+inspections);
                        scheduleInspection(view, 1100);
                    } else finish(null,"WebView価格解析エラー");
                }
            });
        }catch(Exception ex){
            inspectionRunning=false;
            if (WishlistGeneralMarketplaceIdentity.isDetail(originalRetailUrl))
                trace("hydration.error", "type=evaluate-exception");
            finish(null,"WebView解析を開始できず");
        }
    }
    /** Reuse the proven, exact-SKU ASKUL price document for stock inspection.
     * Only the existing strict stockEvidence() can set a verified state.  Stop
     * after a few bounded hydration polls and keep the price even if stock
     * remains UNKNOWN.  This is a read-only DOM operation; no cart is clicked. */
    private void inspectAskulStock(WebView view, Long verifiedPrice) {
        if (finished || view != web || verifiedPrice == null || !isAskul()
                || originalRetailUrl == null || !allowedDestination(view.getUrl())) {
            finish(verifiedPrice, null); return;
        }
        String sku=GeneralRetailIdentity.itemId(originalRetailUrl);
        if (sku==null) { finish(verifiedPrice, null); return; }
        main.removeCallbacks(timeout); // Price is known; bounded stock polls finish below.
        if (askulStockInspections == 0) {
            askulStockDeadline = () -> {
                if (!finished && view == web) {
                    trace("askul.stock.deadline", "status=UNKNOWN");
                    finishAskulWithTitle(view, verifiedPrice);
                }
            };
            main.postDelayed(askulStockDeadline, 7200);
        }
        askulStockInspections++;
        view.evaluateJavascript(AskulProductDom.stockEvidence(sku), raw -> {
            if (finished || view != web) return;
            String status="UNKNOWN", reason="unreadable", flags="";
            try {
                String json=new JSONArray("[" + raw + "]").getString(0);
                JSONObject obj=new JSONObject(json);
                status=obj.optString("status", "UNKNOWN");
                reason=obj.optString("reason", "unknown");
                flags=" skuMatch="+obj.optBoolean("skuLabel",false)
                        +" stockFound="+obj.optBoolean("stockFound",false)
                        +" cartFound="+obj.optInt("cartFound",0)
                        +" cartEnabled="+obj.optInt("cartEnabled",0)
                        +" structured="+obj.optBoolean("structuredProduct",false)
                        +" controls="+obj.optInt("domControls",0)
                        +" cartHint="+obj.optBoolean("cartTextHint",false)
                        +" stockHint="+obj.optBoolean("stockTextHint",false)
                        +" structuredOffer="+obj.optBoolean("structuredOffer",false)
                        +" skuFrame="+obj.optInt("skuFrames",0)
                        +" frameCart="+obj.optInt("frameCart",0)
                        +" frameStock="+obj.optInt("frameStock",0)
                        +" framesReadable="+obj.optInt("accessibleFrames",0)
                        +" scopeCut="+obj.optBoolean("scopeCut",false)
                        +" stockPositive="+obj.optBoolean("localStockPositive",false)
                        +" stockNegative="+obj.optBoolean("localStockNegative",false);
            }catch(Exception ignored) { }
            trace("askul.stock", "attempt="+askulStockInspections+" status="+status
                    +" reason="+reason+flags);
            if ("AVAILABLE".equals(status) || "UNAVAILABLE".equals(status)) {
                askulStockStatus=status;
                finishAskulWithTitle(view, verifiedPrice);
            } else if (askulStockInspections < 5) {
                main.postDelayed(() -> inspectAskulStock(view, verifiedPrice), 1100);
            } else {
                finishAskulWithTitle(view, verifiedPrice);
            }
        });
    }

    /** Capture a title without a second network request, before destroying the
     * successful ASKUL price+stock WebView. Failure never changes price/stock.
     * Both JS result and deadline are bounded; only one callback can complete. */
    private void finishAskulWithTitle(WebView view, Long verifiedPrice) {
        if (finished || askulTitleStarted) return;
        if (view != web || originalRetailUrl == null || !isAskul()
                || !allowedDestination(view.getUrl())
                || !WishlistRetailProductTitleDom.supports(originalRetailUrl)) {
            finish(verifiedPrice, null);return;
        }
        askulTitleStarted=true;
        if (askulStockDeadline != null) main.removeCallbacks(askulStockDeadline);
        askulStockDeadline=null;
        final boolean[] completed={false};
        final Runnable fallback=() -> {
            if (!completed[0] && !finished && view==web) {
                completed[0]=true;
                trace("askul.title", "verified=false reason=callback-timeout");
                finish(verifiedPrice,null);
            }
        };
        main.postDelayed(fallback,1200);
        try {
            view.evaluateJavascript(WishlistRetailProductTitleDom.javascript(originalRetailUrl), raw -> {
                if (completed[0] || finished || view!=web) return;
                completed[0]=true;
                main.removeCallbacks(fallback);
                String reason="unreadable";
                try {
                    Object outer=new org.json.JSONTokener(raw==null?"null":raw).nextValue();
                    if (outer instanceof String) {
                        JSONObject o=new JSONObject((String)outer);
                        reason=o.optString("reason","unreadable");
                        String title=o.optString("title","").trim();
                        if ("verified-rendered-heading".equals(reason)
                                && title.length()>=3 && title.length()<=240)
                            verifiedAskulTitle=title;
                    }
                }catch(Exception ignored) {reason="invalid-result";}
                if (!reason.matches("[a-z0-9-]{1,45}")) reason="unreadable";
                trace("askul.title", "verified="+(verifiedAskulTitle!=null)+" reason="+reason);
                finish(verifiedPrice,null);
            });
        }catch(Exception ex){
            main.removeCallbacks(fallback);completed[0]=true;
            trace("askul.title", "verified=false reason=evaluation-error");
            finish(verifiedPrice,null);
        }
    }

    private void finish(Long price,String error) { finish(price,null,error); }
    private void finish(Long price,WishlistRetailPriceQuote quote,String error) {
        if(finished)return;
        finished=true;
        main.removeCallbacks(timeout);
        if(temuDialog!=null){
            android.app.AlertDialog dialog=temuDialog;
            temuDialog=null;
            try{dialog.dismiss();}catch(RuntimeException ignored){}
        }
        if (askulStockDeadline != null) main.removeCallbacks(askulStockDeadline);
        askulStockDeadline=null;
        Callback next=callback;
        callback=null;
        if(web!=null){
            WebView current=web;web=null;
            try{
                current.stopLoading();current.loadUrl("about:blank");
                if(current.getParent() instanceof ViewGroup)
                    ((ViewGroup)current.getParent()).removeView(current);
                current.destroy();
            }
            catch(Exception ignored){}
        }
        if(next!=null)next.completed(price,quote,error);
    }
    public void cancel() {callback=null;finish(null,"WebView取得中断");}
}
