package com.cmyk.bookmarkslauncher.wishlist;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.view.View;
import android.view.ViewGroup;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.Locale;

/**
 * Foreground, single-product, user-invoked price probe only.
 * Never extracts or edits name/image/status. No background crawl or repeated retry loops.
 */
public final class WishlistPriceWebViewProbe {
    public interface Callback { void completed(Long price, String problem); }
    private final Handler main = new Handler(Looper.getMainLooper());
    private final FrameLayout parent;
    private WebView web;
    private Callback callback;
    private boolean finished;
    private int inspections;
    private static final int MAX_INSPECTIONS = 5;
    private String originalHost;
    private final Runnable timeout = () -> finish(null, "WebView読み込みタイムアウト");

    public WishlistPriceWebViewProbe(FrameLayout parent) { this.parent = parent; }

    public void start(String urlText, Callback onDone) {
        cancel();
        callback=onDone;
        finished=false;
        inspections=0;
        if (Looper.myLooper()!=Looper.getMainLooper()) {
            finish(null,"WebViewはメインスレッド限定");return;
        }
        try {
            URL url=new URL(urlText);
            if (!WishlistCrawler.isAllowedUrl(url) || !"https".equalsIgnoreCase(url.getProtocol())) {
                finish(null,"安全なHTTPS URL以外は対象外");return;
            }
            originalHost=url.getHost().toLowerCase(Locale.ROOT);
            web=new WebView(parent.getContext());
            web.setBackgroundColor(Color.TRANSPARENT);
            // Keep the WebView attached for JS, but never paint it or accept focus.
            // Merely adding it behind a transparent Wishlist is NOT visually hidden.
            web.setAlpha(0f);
            web.setFocusable(false);
            web.setFocusableInTouchMode(false);
            web.setClickable(false);
            web.setLongClickable(false);
            web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            web.setVerticalScrollBarEnabled(false);
            web.setHorizontalScrollBarEnabled(false);
            // Full viewport so lazy DOM/layout has normal dimensions.
            FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
            parent.addView(web,0,p);
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            web.getSettings().setAllowFileAccess(false);
            web.getSettings().setAllowContentAccess(false);
            web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
            web.getSettings().setSupportMultipleWindows(false);
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request) {
                    if (!request.isForMainFrame()) return false;
                    return !allowedDestination(request.getUrl().toString());
                }
                @Override public void onPageFinished(WebView view,String url) {
                    if(finished || !allowedDestination(url)) return;
                    main.postDelayed(() -> { if(!finished && view==web) inspect(view); },1400);
                }
                @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError error) {
                    if (req.isForMainFrame()) finish(null,"WebView通信エラー");
                }
            });
            main.postDelayed(timeout,14000);
            web.loadUrl(url.toString());
        }catch(Exception ex) {finish(null,"WebViewを開始できず");}
    }
    private boolean allowedDestination(String text) {
        try {
            URL dest=new URL(text);
            if(!"https".equalsIgnoreCase(dest.getProtocol()) || !WishlistCrawler.isAllowedUrl(dest))return false;
            String h=dest.getHost().toLowerCase(Locale.ROOT);
            if(originalHost==null)return false;
            // Amazon sign-in / CAPTCHA redirects do not become new crawl targets.
            if(originalHost.equals("amazon.co.jp") || originalHost.endsWith(".amazon.co.jp"))
                return h.equals("amazon.co.jp") || h.endsWith(".amazon.co.jp");
            return h.equals(originalHost);
        }catch(Exception ex){return false;}
    }
    private void inspect(WebView view) {
        inspections++;
        // DOM selectors only; never execute site-provided data as a script.
        final boolean amazon=originalHost!=null && (originalHost.equals("amazon.co.jp") || originalHost.endsWith(".amazon.co.jp"));
        final String js="(function(){"+
            "var amazon="+amazon+";"+
            "var detail=/\\/(?:product\\/detail|products|item\\/detail)\\/[^/]+\\/?$/.test(location.pathname);"+
            "var a=["+
            "'#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen',"+
            "'#corePrice_feature_div .priceToPay .a-offscreen',"+
            "'#apex_desktop .priceToPay .a-offscreen',"+
            "'#price_inside_buybox','#priceblock_dealprice','#priceblock_ourprice',"+
            "'.priceToPay .a-offscreen','[itemprop=price]',"+
            "'.product-detail__price','.productDetail__price',"+
            "'.productDetail .price','.product-detail .price',"+
            "'.product-price','.productPrice','.product_price',"+
            "'.p-product-detail__price','.p-productDetail__price',"+
            "'#product-price','#item-price','.item-price',"+
            "'[data-product-price]'];"+
            "for(var i=0;i<a.length;i++){if(i<7&&!amazon)continue;"+
            "var e=document.querySelector(a[i]);if(!e)continue;"+
            "var s=e.getAttribute('content')||e.textContent||'';"+
            "var cur=document.querySelector('[itemprop=priceCurrency],meta[itemprop=priceCurrency]');"+
            "var cv=cur?(cur.getAttribute('content')||cur.textContent||''):'';"+
            "if(i>=8&&!amazon){if(!detail||s.length>110||/(?:送料|ポイント|割引|値引|クーポン|関連商品|おすすめ)/.test(s))continue;"+
            "var many=s.match(/[¥￥]\\s*[0-9][0-9,]*(?:\\.[0-9]+)?|[0-9][0-9,]*\\s*円/g);"+
            "if(many&&many.length!==1)continue;}"+
            "if(s.trim()&&(amazon||cv.trim()==='JPY'||/¥|￥|円/.test(s)))return JSON.stringify({value:s,currency:amazon?'JPY':cv});}"+
            "var m=document.querySelector('meta[property=\"product:price:amount\"],meta[property=\"og:price:amount\"]');"+
            "var c=document.querySelector('meta[property=\"product:price:currency\"],meta[property=\"og:price:currency\"]');"+
            "if(m&&m.content&&c&&c.content==='JPY')return JSON.stringify({value:m.content,currency:'JPY'});"+
            "var scripts=document.querySelectorAll('script[type=\"application/ld+json\"]');"+
            "function offer(o,d,cur){if(!o||d>8)return null;"+
            "if(Array.isArray(o)){for(var i=0;i<Math.min(30,o.length);i++){var r=offer(o[i],d+1,cur);if(r)return r;}return null;}"+
            "if(typeof o!=='object')return null;var typ=String(o['@type']||'').toLowerCase();"+
            "if(typ.indexOf('aggregateoffer')>=0)return null;"+
            "var cc=o.priceCurrency||cur||'';if(String(cc).toUpperCase()==='JPY'&&(o.price||o.value))return String(o.price||o.value);"+
            "return offer(o.priceSpecification,d+1,cc)||offer(o.offers,d+1,cc);}"+
            "function product(o,d){if(!o||d>8)return null;"+
            "if(Array.isArray(o)){for(var i=0;i<Math.min(40,o.length);i++){var r=product(o[i],d+1);if(r)return r;}return null;}"+
            "if(typeof o!=='object')return null;var typ=String(o['@type']||'').toLowerCase();"+
            "if(typ==='product'||typ.endsWith('/product'))return offer(o.offers,d+1,'');"+
            "return product(o['@graph'],d+1)||product(o.mainEntity,d+1);}"+
            "for(var i=0;i<Math.min(30,scripts.length);i++){try{var v=product(JSON.parse(scripts[i].textContent),0);"+
            "if(v)return JSON.stringify({value:v,currency:'JPY'});}catch(e){}}"+
            // For a genuine product detail page only: read a short visible price
            // phrase near the product heading, never site-wide recommendations.
            "if(!amazon&&/\\/product\\/detail\\//.test(location.pathname)){"+
            "var h=document.querySelector('main h1,h1');"+
            "if(h){var node=h.parentElement;for(var n=0;node&&n<3;n++,node=node.parentElement){"+
            "var text=(node.innerText||'').slice(0,600);"+
            "var slice=text.slice(text.indexOf(h.innerText||'')+(h.innerText||'').length);"+
            "var boundary=slice.search(/商品説明|関連商品|おすすめ商品|よく一緒に|送料/);"+
            "if(boundary>=0)slice=slice.slice(0,boundary);"+
            "var matches=slice.match(/[¥￥]\\s*[0-9][0-9,]*(?:\\.[0-9]+)?|[0-9][0-9,]*\\s*円/g);"+
            "if(matches&&matches.length===1)return JSON.stringify({value:matches[0],currency:'JPY'});"+
            "}}}"+
            "return JSON.stringify({value:'',currency:''});"+
            "})()";
        try {
            view.evaluateJavascript(js, returned -> {
                if(finished)return;
                try {
                    String json=new JSONArray("["+returned+"]").getString(0);
                    JSONObject o=new JSONObject(json);
                    String val=o.optString("value","");
                    String currency=o.optString("currency","");
                    Long price=WishlistPriceExtractor.parseDomValue(val,currency);
                    if (price != null) finish(price, null);
                    else if (inspections < MAX_INSPECTIONS)
                        main.postDelayed(() -> { if (!finished && view == web) inspect(view); }, 1100);
                    else finish(null, "WebViewにも価格情報なし");
                }catch(Exception ex){finish(null,"WebView価格解析エラー");}
            });
        }catch(Exception ex){finish(null,"WebView解析を開始できず");}
    }
    private void finish(Long price,String error) {
        if(finished)return;
        finished=true;
        main.removeCallbacks(timeout);
        Callback next=callback;
        callback=null;
        if(web!=null){
            WebView current=web;web=null;
            try{current.stopLoading();current.loadUrl("about:blank");parent.removeView(current);current.destroy();}
            catch(Exception ignored){}
        }
        if(next!=null)next.completed(price,error);
    }
    public void cancel() {callback=null;finish(null,"WebView取得中断");}
}
