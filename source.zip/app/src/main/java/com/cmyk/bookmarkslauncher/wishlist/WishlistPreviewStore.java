package com.cmyk.bookmarkslauncher.wishlist;

import android.content.Context;
import android.os.Build;
import android.net.http.HttpEngine;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Store a small offline image next to Wishlist data, not in a bookmark-owned file. */
final class WishlistPreviewStore {
    private static final int MAX_IMAGE_BYTES = 5_000_000;
    private WishlistPreviewStore() { }

    static String save(Context context, String itemId, String imageUrl) {
        return save(context, itemId, imageUrl, null);
    }

    /** Image-only download. A page referrer is used only when explicitly supplied by the image probe. */
    static String save(Context context, String itemId, String imageUrl, String pageUrl) {
        return save(context, itemId, imageUrl, pageUrl, WishlistMode.UNRESOLVED);
    }

    /**
     * Product-image bytes are always downloaded and decoded as data; no WebView
     * screenshot or compositor is involved.  On Android 14+ use the platform
     * HTTP engine for BICCAMERA before the legacy URLConnection fallback.
     * This is a distinct transport (not another DOM or pixel retry), and may
     * still fail if the network/CDN refuses the device.
     */
    static String save(Context context, String itemId, String imageUrl, String pageUrl,
                       WishlistMode diagnosticMode) {
        return save(context, itemId, imageUrl, pageUrl, diagnosticMode, null);
    }

    /** Per-candidate failure codes for the initiating card only. Never logs image URLs. */
    static String save(Context context, String itemId, String imageUrl, String pageUrl,
                       WishlistMode diagnosticMode, java.util.function.Consumer<String> failureTrace) {
        if (diagnosticMode == WishlistMode.BICCAMERA && Build.VERSION.SDK_INT >= 34) {
            String saved = saveViaConnection(context,itemId,imageUrl,pageUrl,diagnosticMode,true,failureTrace);
            if (saved != null) return saved;
            RetailDiagnostics.event(diagnosticMode, "image.transportFallback", "from=HttpEngine to=HttpURLConnection");
        }
        return saveViaConnection(context,itemId,imageUrl,pageUrl,diagnosticMode,false,failureTrace);
    }

    private static String saveViaConnection(Context context,String itemId,String imageUrl,
                                            String pageUrl,WishlistMode diagnosticMode,
                                            boolean useHttpEngine,
                                            java.util.function.Consumer<String> failureTrace) {
        RetailDiagnostics.event(diagnosticMode, "image.start", "host="+RetailDiagnostics.host(imageUrl)
                +" referrer="+(pageUrl!=null));
        HttpURLConnection connection = null;
        HttpEngine httpEngine = null;
        File tmp = null;
        try {
            URL url = new URL(imageUrl);
            if (!WishlistCrawler.isAllowedUrl(url) || !"https".equalsIgnoreCase(url.getProtocol())) return imageFailure(diagnosticMode,failureTrace,"url-not-https");
            if (useHttpEngine) {
                httpEngine = new HttpEngine.Builder(context).build();
                connection = (HttpURLConnection) httpEngine.openConnection(url);
            } else {
                connection = (HttpURLConnection) url.openConnection();
            }
            RetailDiagnostics.event(diagnosticMode, "image.transport", "engine="+(useHttpEngine?"HttpEngine":"HttpURLConnection")
                    +" host="+url.getHost());
            connection.setConnectTimeout(diagnosticMode == WishlistMode.BICCAMERA ? 4000 : 10000);
            connection.setReadTimeout(diagnosticMode == WishlistMode.BICCAMERA ? 5500 : 12000);
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36");
            connection.setRequestProperty("Accept", "image/webp,image/png,image/jpeg,image/*;q=0.8,*/*;q=0.2");
            connection.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en;q=0.6");
            if (pageUrl != null) {
                try {
                    URL referer = new URL(pageUrl);
                    if ("https".equalsIgnoreCase(referer.getProtocol()) && WishlistCrawler.isAllowedUrl(referer)) {
                        connection.setRequestProperty("Referer", referer.toString());
                    }
                } catch (Exception ignored) { }
            }
            int imageStatus = connection.getResponseCode();
            RetailDiagnostics.event(diagnosticMode,"image.headers","host="+connection.getURL().getHost()+" code="+imageStatus);
            if (imageStatus != 200 || !WishlistCrawler.isAllowedUrl(connection.getURL())
                    || !"https".equalsIgnoreCase(connection.getURL().getProtocol())) return imageFailure(diagnosticMode,failureTrace,"http-"+imageStatus+"-or-redirect");
            String contentType = connection.getContentType();
            if (contentType != null && !contentType.toLowerCase(java.util.Locale.ROOT).startsWith("image/")) return imageFailure(diagnosticMode,failureTrace,"not-image-content-type");
            if (connection.getContentLengthLong() > MAX_IMAGE_BYTES) return imageFailure(diagnosticMode,failureTrace,"content-too-large");
            byte[] bytes;
            try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream());
                 ByteArrayOutputStream data = new ByteArrayOutputStream()) {
                byte[] block = new byte[8192]; int n;
                while ((n = input.read(block)) != -1) {
                    if (data.size() + n > MAX_IMAGE_BYTES) return imageFailure(diagnosticMode,failureTrace,"body-too-large");
                    data.write(block, 0, n);
                }
                bytes = data.toByteArray();
            }
            if (bytes.length == 0) return imageFailure(diagnosticMode,failureTrace,"empty-body");
            BitmapFactory.Options probe = new BitmapFactory.Options();
            probe.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, probe);
            // Reject Amazon's 1px tracker/placeholder images and tiny icons.
            if (probe.outWidth < 48 || probe.outHeight < 48 || probe.outWidth > 12000 || probe.outHeight > 12000) return imageFailure(diagnosticMode,failureTrace,"invalid-bitmap-bounds-"+probe.outWidth+"x"+probe.outHeight);
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 1;
            while (probe.outWidth / opts.inSampleSize > 640 || probe.outHeight / opts.inSampleSize > 640)
                opts.inSampleSize *= 2;
            Bitmap decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
            if (decoded == null) return imageFailure(diagnosticMode,failureTrace,"bitmap-decode-null");
            int w = decoded.getWidth(), h = decoded.getHeight();
            float scale = Math.min(1f, Math.min(480f / w, 480f / h));
            int targetW = Math.max(1, Math.round(w * scale));
            int targetH = Math.max(1, Math.round(h * scale));
            Bitmap rendered = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(rendered);
            canvas.drawColor(Color.WHITE);
            canvas.drawBitmap(decoded, null, new android.graphics.Rect(0, 0, targetW, targetH), new Paint(Paint.FILTER_BITMAP_FLAG));
            File dir = new File(context.getFilesDir(), "wishlist_previews");
            if (!dir.exists() && !dir.mkdirs()) return imageFailure(diagnosticMode,failureTrace,"mkdir-failed");
            File dest = path(context, itemId);
            tmp = new File(dir, dest.getName() + ".tmp");
            try (FileOutputStream stream = new FileOutputStream(tmp)) {
                if (!rendered.compress(Bitmap.CompressFormat.JPEG, 84, stream)) return imageFailure(diagnosticMode,failureTrace,"jpeg-encode-failed");
                stream.getFD().sync();
            } finally { rendered.recycle(); decoded.recycle(); }
            if (!tmp.renameTo(dest)) {
                if (dest.exists() && !dest.delete()) return imageFailure(diagnosticMode,failureTrace,"old-file-delete-failed");
                if (!tmp.renameTo(dest)) return imageFailure(diagnosticMode,failureTrace,"rename-failed");
            }
            RetailDiagnostics.event(diagnosticMode,"image.saved","host="+url.getHost()+" bytes="+bytes.length+" width="+targetW+" height="+targetH);
            return dest.getAbsolutePath();
        } catch (Exception e) {
            Log.d("WishlistPreviewStore", "Image not available", e);
            return imageFailure(diagnosticMode,failureTrace,"exception-"+RetailDiagnostics.error(e));
        } finally {
            if (connection != null) connection.disconnect();
            if (httpEngine != null) {
                try { httpEngine.shutdown(); }
                catch (Exception ignored) { }
            }
            if (tmp != null && tmp.exists()) tmp.delete();
        }
    }

    private static String imageFailure(WishlistMode mode,
                                       java.util.function.Consumer<String> trace, String reason) {
        RetailDiagnostics.event(mode, "image.failed", "reason="+reason);
        if (trace != null) {
            try { trace.accept(reason); } catch (RuntimeException ignored) { }
        }
        return null;
    }

    /** Copy a user-picked photo to a private offline JPEG. Never write the crawler's file. */
    static String saveSelected(Context context, String itemId, Uri uri) {
        if (context == null || itemId == null || uri == null) return null;
        final int maxBytes = 12_000_000;
        File tmp = null;
        try {
            byte[] bytes;
            try (InputStream input = context.getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                if (input == null) return null;
                byte[] chunk = new byte[8192]; int count;
                while ((count = input.read(chunk)) != -1) {
                    if (buffer.size() + count > maxBytes) return null;
                    buffer.write(chunk, 0, count);
                }
                bytes = buffer.toByteArray();
            }
            if (bytes.length == 0) return null;
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            if (bounds.outWidth < 48 || bounds.outHeight < 48
                    || bounds.outWidth > 20000 || bounds.outHeight > 20000) return null;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 1;
            while (bounds.outWidth / opts.inSampleSize > 960 || bounds.outHeight / opts.inSampleSize > 960)
                opts.inSampleSize *= 2;
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
            if (bitmap == null) return null;
            int width = bitmap.getWidth(), height = bitmap.getHeight();
            float scale = Math.min(1f, Math.min(640f / width, 640f / height));
            int tw = Math.max(1, Math.round(width * scale));
            int th = Math.max(1, Math.round(height * scale));
            Bitmap output = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
            try {
                Canvas canvas = new Canvas(output);
                canvas.drawColor(Color.WHITE);
                canvas.drawBitmap(bitmap, null, new android.graphics.Rect(0, 0, tw, th), new Paint(Paint.FILTER_BITMAP_FLAG));
                File dir = new File(context.getFilesDir(), "wishlist_previews");
                if (!dir.isDirectory() && !dir.mkdirs()) return null;
                File target = manualPath(context, itemId);
                tmp = new File(dir, target.getName() + ".tmp");
                try (FileOutputStream out = new FileOutputStream(tmp)) {
                    if (!output.compress(Bitmap.CompressFormat.JPEG, 88, out)) return null;
                    out.getFD().sync();
                }
                if (!tmp.renameTo(target)) {
                    if (target.exists() && !target.delete()) return null;
                    if (!tmp.renameTo(target)) return null;
                }
                return target.getAbsolutePath();
            } finally { output.recycle(); bitmap.recycle(); }
        } catch (Exception e) {
            Log.d("WishlistPreviewStore", "Selected image not available", e);
            return null;
        } finally { if (tmp != null && tmp.exists()) tmp.delete(); }
    }

    private static File manualPath(Context context, String itemId) {
        String safeId = itemId.replaceAll("[^a-zA-Z0-9_-]", "_");
        return new File(new File(context.getFilesDir(), "wishlist_previews"), safeId + "_manual.jpg");
    }

    static boolean isUsableSavedImage(String path) {
        if (path == null || path.isBlank()) return false;
        File file = new File(path);
        if (!file.isFile()) return false;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            return o.outWidth >= 48 && o.outHeight >= 48;
        } catch (Exception ignored) { return false; }
    }

    private static File path(Context context, String itemId) {
        String safeId = itemId == null ? "invalid" : itemId.replaceAll("[^a-zA-Z0-9_-]", "_");
        return new File(new File(context.getFilesDir(), "wishlist_previews"), safeId + ".jpg");
    }

    static void delete(Context context, String itemId) {
        File f = path(context, itemId);
        if (f.exists()) f.delete();
        File manual = manualPath(context, itemId);
        if (manual.exists()) manual.delete();
    }
}
