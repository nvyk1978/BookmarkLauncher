package com.cmyk.bookmarkslauncher.wishlist;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Store a small offline image next to Wishlist data, not in a bookmark-owned file. */
final class WishlistPreviewStore {
    private static final int MAX_IMAGE_BYTES = 5_000_000;
    private WishlistPreviewStore() { }

    static String save(Context context, String itemId, String imageUrl) {
        return save(context, itemId, imageUrl, null);
    }

    /** Image-only download. A page referrer is used only when explicitly supplied by the image probe. */
    static String save(Context context, String itemId, String imageUrl, String pageUrl) {
        HttpURLConnection connection = null;
        File tmp = null;
        try {
            URL url = new URL(imageUrl);
            if (!WishlistCrawler.isAllowedUrl(url) || !"https".equalsIgnoreCase(url.getProtocol())) return null;
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(12000);
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36");
            connection.setRequestProperty("Accept", "image/webp,image/png,image/jpeg,image/*;q=0.8,*/*;q=0.2");
            connection.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en;q=0.6");
            if (pageUrl != null) {
                try {
                    URL referer = new URL(pageUrl);
                    if ("https".equalsIgnoreCase(referer.getProtocol()) && WishlistCrawler.isAllowedUrl(referer)) {
                        connection.setRequestProperty("Referer", referer.toString());
                    }
                } catch (Exception ignored) { }
            }
            if (connection.getResponseCode() != 200 || !WishlistCrawler.isAllowedUrl(connection.getURL())
                    || !"https".equalsIgnoreCase(connection.getURL().getProtocol())) return null;
            String contentType = connection.getContentType();
            if (contentType != null && !contentType.toLowerCase(java.util.Locale.ROOT).startsWith("image/")) return null;
            if (connection.getContentLengthLong() > MAX_IMAGE_BYTES) return null;
            byte[] bytes;
            try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream());
                 ByteArrayOutputStream data = new ByteArrayOutputStream()) {
                byte[] block = new byte[8192]; int n;
                while ((n = input.read(block)) != -1) {
                    if (data.size() + n > MAX_IMAGE_BYTES) return null;
                    data.write(block, 0, n);
                }
                bytes = data.toByteArray();
            }
            if (bytes.length == 0) return null;
            BitmapFactory.Options probe = new BitmapFactory.Options();
            probe.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, probe);
            if (probe.outWidth <= 0 || probe.outHeight <= 0 || probe.outWidth > 12000 || probe.outHeight > 12000) return null;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = 1;
            while (probe.outWidth / opts.inSampleSize > 640 || probe.outHeight / opts.inSampleSize > 640)
                opts.inSampleSize *= 2;
            Bitmap decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
            if (decoded == null) return null;
            int w = decoded.getWidth(), h = decoded.getHeight();
            float scale = Math.min(1f, Math.min(480f / w, 480f / h));
            int targetW = Math.max(1, Math.round(w * scale));
            int targetH = Math.max(1, Math.round(h * scale));
            Bitmap rendered = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(rendered);
            canvas.drawColor(Color.WHITE);
            canvas.drawBitmap(decoded, null, new android.graphics.Rect(0, 0, targetW, targetH), new Paint(Paint.FILTER_BITMAP_FLAG));
            File dir = new File(context.getFilesDir(), "wishlist_previews");
            if (!dir.exists() && !dir.mkdirs()) return null;
            File dest = path(context, itemId);
            tmp = new File(dir, dest.getName() + ".tmp");
            try (FileOutputStream stream = new FileOutputStream(tmp)) {
                if (!rendered.compress(Bitmap.CompressFormat.JPEG, 84, stream)) return null;
                stream.getFD().sync();
            } finally { rendered.recycle(); decoded.recycle(); }
            if (!tmp.renameTo(dest)) {
                if (dest.exists() && !dest.delete()) return null;
                if (!tmp.renameTo(dest)) return null;
            }
            return dest.getAbsolutePath();
        } catch (Exception e) {
            Log.d("WishlistPreviewStore", "Image not available", e);
            return null;
        } finally {
            if (connection != null) connection.disconnect();
            if (tmp != null && tmp.exists()) tmp.delete();
        }
    }

    private static File path(Context context, String itemId) {
        String safeId = itemId == null ? "invalid" : itemId.replaceAll("[^a-zA-Z0-9_-]", "_");
        return new File(new File(context.getFilesDir(), "wishlist_previews"), safeId + ".jpg");
    }

    static void delete(Context context, String itemId) {
        File f = path(context, itemId);
        if (f.exists()) f.delete();
    }
}
