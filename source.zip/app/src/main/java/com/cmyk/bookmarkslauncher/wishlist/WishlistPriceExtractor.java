package com.cmyk.bookmarkslauncher.wishlist;

import android.text.Html;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Price-only pipeline; consumes HTML independently from titles/images. */
final class WishlistPriceExtractor {
    private static final Pattern META = Pattern.compile("<meta\\b[^>]*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern ATTRIBUTE = Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern JSON_LD = Pattern.compile("<script\\b([^>]*)>(.*?)</script\\s*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern PRICE_TAG = Pattern.compile("<[^>]+>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern PRODUCT_H1 = Pattern.compile("<h([123])\\b[^>]*>(.*?)</h\\1\\s*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern SCRIPT_OR_STYLE = Pattern.compile("<(?:script|style)\\b[^>]*>.*?</(?:script|style)\\s*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern YEN_PRICE = Pattern.compile("(?:[¥￥]\\s*|&yen;\\s*)([0-9][0-9,]*(?:\\.[0-9]{1,2})?)|([0-9][0-9,]*(?:\\.[0-9]{1,2})?)\\s*円", Pattern.CASE_INSENSITIVE);
    /** A rendered DOM price needs an explicit JPY currency or yen-marked text. */
    static Long parseDomValue(String value,String currency){
        if (value==null || value.isBlank())return null;
        if ("JPY".equalsIgnoreCase(currency)) {
            Long result=parsePrice(value);
            if(result!=null)return result;
            java.util.regex.Matcher yen=YEN_PRICE.matcher(value);
            if(yen.find())return parsePrice(coalesce(yen.group(1),yen.group(2)));
        }
        if (!isYenText(value))return null;
        java.util.regex.Matcher match=YEN_PRICE.matcher(value);
        return match.find()?parsePrice(coalesce(match.group(1),match.group(2))):null;
    }

    static Long parse(String html, URL page) {
        // Host+SKU-confirmed gross amount takes priority over a tax-exclusive
        // number or a related product; otherwise use the existing parser.
        if (GeneralRetailIdentity.store(page) != null) {
            // The same product page may contain a tax-exclusive SKU price and
            // gross amounts for unrelated recommendations. Never accept either
            // as this SKU's gross price when its confirmed gross label is absent.
            return GeneralRetailHtmlEvidence.grossPrice(html, page);
        }
        // A few independent shops put their JPY selling price immediately next
        // to the exact product's H1, without a labeled price or JSON-LD offer.
        // Never scan a category/list or borrow prices from recommendations.
        Long bounded = independentShopProductPrice(html, page);
        if (bounded != null) return bounded;
        // Independent from product-name extraction: title is neither an input nor a fallback.
        Long p = productJsonPrice(html,page);
        if (p != null) return p;
        Map<String,String> meta=new HashMap<>();
        Matcher m=META.matcher(html);
        while(m.find()) {
            Map<String,String> a=attributes(m.group());
            String k=coalesce(a.get("property"),a.get("name"),a.get("itemprop"));
            String v=clean(a.get("content"));
            if(k!=null && v!=null) meta.putIfAbsent(k.toLowerCase(Locale.ROOT),v);
        }
        String currency=coalesce(meta.get("product:price:currency"),meta.get("og:price:currency"),meta.get("pricecurrency"),meta.get("product:price:currency_code"));
        String raw=coalesce(meta.get("product:price:amount"),meta.get("og:price:amount"),meta.get("product:sale_price:amount"),meta.get("item:price"),meta.get("twitter:data1"),meta.get("price"));
        if(raw!=null && raw.equals(meta.get("twitter:data1")) && !isYenText(raw))raw=null;
        if("JPY".equalsIgnoreCase(currency) || (currency==null && (isJapanSite(page) || isYenText(raw)))) {
            p=parsePrice(raw);
            if(p!=null)return p;
        }
        p=itempropPrice(html,page);
        if(p!=null)return p;
        if(AmazonPriceExtractor.isAmazon(page)) {
            p=AmazonPriceExtractor.fromHtml(html);
            if(p!=null)return p;
        }
        // Other retailer page text fallback: inspect local price text near a heading,
        // never the title returned by the completely independent metadata parser.
        return priceNearProductHeading(html,page);
    }

    /** Scoped to exact known product pages; allow price values like ¥2,106税込. */
    private static Long independentShopProductPrice(String html, URL page) {
        if (html == null || page == null) return null;
        String host=page.getHost().toLowerCase(Locale.ROOT);
        String path=page.getPath();
        boolean fumuroya=host.equals("eshop.fumuroya.com")
                && path.matches("/product/detail/[0-9]+/?");
        boolean gojo=(host.equals("www.gojochoubei.co.jp") || host.equals("gojochoubei.co.jp"))
                && path.matches("/view/item/[0-9]{12}/?");
        if (!fumuroya && !gojo) return null;
        Matcher heading=PRODUCT_H1.matcher(html);
        while (heading.find()) {
            if (!"1".equals(heading.group(1))) continue;
            String title=clean(heading.group(2));
            if (title==null || title.length()<4) continue;
            // A similar name in an alternate product widget must not be used.
            if (gojo && !title.contains("鰹ごぼう")) continue;
            if (fumuroya && !title.contains("宝の麩")) continue;
            String fragment=html.substring(heading.end(), Math.min(html.length(),heading.end()+4200));
            fragment=SCRIPT_OR_STYLE.matcher(fragment).replaceAll(" ");
            String text=Html.fromHtml(fragment,Html.FROM_HTML_MODE_LEGACY).toString()
                    .replaceAll("[\\s　]+"," ");
            int end=firstMarker(text,"関連商品","おすすめ商品","この商品を見た","ご購入はこちら", "商品説明", "レビューを見る");
            if (end>=0) text=text.substring(0,end);
            text=text.substring(0,Math.min(text.length(),1050));
            Matcher yen=YEN_PRICE.matcher(text);
            while(yen.find()) {
                String prefix=text.substring(Math.max(0,yen.start()-34),yen.start());
                if (prefix.matches("(?s).*(?:送料|配送料|手数料|ポイント|割引|値引|クーポン)\\s*(?:[:：])?\\s*$")) continue;
                // Require the displayed yen price to identify itself as tax-inclusive,
                // or immediately follow the product heading's actual price area.
                String suffix=text.substring(yen.end(),Math.min(text.length(),yen.end()+25));
                if (!suffix.contains("税込") && !prefix.contains("販売価格")
                        && !prefix.contains("商品価格") && !prefix.contains("税込価格")
                        && yen.start()>200) continue;
                Long p=parsePrice(coalesce(yen.group(1),yen.group(2)));
                if (p!=null) return p;
            }
        }
        return null;
    }

    private static Long productJsonPrice(String html,URL page) {
        JSONObject product = WishlistGenericJsonLdProduct.find(html, page);
        if (product == null) return null;
        return offerPrice(product.opt("offers"), 0, isJapanSite(page) ? "JPY" : null, false);
    }

    private static Long searchProduct(Object node,int depth,String defaultCurrency) {
        if(depth>9 || node==null)return null;
        if(node instanceof JSONArray){
            JSONArray a=(JSONArray)node;
            for(int i=0;i<Math.min(60,a.length());i++){
                Long p=searchProduct(a.opt(i),depth+1,defaultCurrency);if(p!=null)return p;
            }
        }else if(node instanceof JSONObject){
            JSONObject o=(JSONObject)node;
            if(typeMatches(o.opt("@type"),"product"))return offerPrice(o.opt("offers"),depth+1,defaultCurrency,false);
            for(String key:new String[]{"@graph","mainEntity","itemListElement","item","about","hasPart"}){
                Long p=searchProduct(o.opt(key),depth+1,defaultCurrency);if(p!=null)return p;
            }
        }
        return null;
    }
    private static Long offerPrice(Object node,int depth,String inheritedCurrency,boolean aggregate) {
        if(depth>9 || node==null)return null;
        if(node instanceof JSONArray){
            JSONArray a=(JSONArray)node;
            for(int i=0;i<Math.min(30,a.length());i++){
                Long p=offerPrice(a.opt(i),depth+1,inheritedCurrency,aggregate);if(p!=null)return p;
            }
        }else if(node instanceof JSONObject){
            JSONObject o=(JSONObject)node;
            String currency=coalesce(o.optString("priceCurrency",null),inheritedCurrency);
            boolean isAggregate=aggregate || typeMatches(o.opt("@type"),"aggregateoffer");
            if(!isAggregate && "JPY".equalsIgnoreCase(currency)) {
                Long p=parsePrice(coalesce(o.optString("price",null),o.optString("value",null)));
                if(p!=null)return p;
            }
            Long p=offerPrice(o.opt("priceSpecification"),depth+1,currency,isAggregate);
            if(p!=null)return p;
            return offerPrice(o.opt("offers"),depth+1,currency,isAggregate);
        }
        return null;
    }

    private static Long priceNearProductHeading(String html, URL page) {
        if (!isJapanSite(page) && !WishlistCrawler.isSingleProductPage(page)) return null;
        // For independent .com/.shop/.net shops, an explicit sales-price label
        // is required; a random yen figure near a heading may be shipping.
        if (!isJapanSite(page)) return explicitLabeledYenPrice(html);
        if (!isJapanSite(page)) return explicitLabeledYenPrice(html);
        // On non-.jp storefronts, only explicit yen-marked text on a
        // confidently identified product page is eligible for fallback.
        Matcher heading = PRODUCT_H1.matcher(html);
        while (heading.find()) {
            String headingText = clean(heading.group(2));
            String normalizedHeading = normalizeHeading(headingText);
            if (normalizedHeading.length() < 6 || (heading.group(1).equals("3"))) continue;
            // Keep a short region adjacent to the product title. Scripts/styles and
            // product recommendations cannot supply a trustworthy main price.
            String fragment = html.substring(heading.end(), Math.min(html.length(), heading.end() + 11000));
            fragment = SCRIPT_OR_STYLE.matcher(fragment).replaceAll(" ");
            String content = Html.fromHtml(fragment, Html.FROM_HTML_MODE_LEGACY).toString()
                    .replaceAll("\\s+", " ");
            content = content.substring(0, Math.min(content.length(), 1250));
            int related = firstMarker(content, "関連商品", "おすすめ商品", "この商品を見た", "よく一緒に購入", "他の商品");
            if (related >= 0) content = content.substring(0, related);
            Matcher yen = YEN_PRICE.matcher(content);
            while (yen.find()) {
                String around = content.substring(Math.max(0, yen.start() - 18), yen.start());
                // Shipping/handling costs are never a product price.
                if (around.matches("(?s).*(?:送料|配送料|手数料|ポイント|値引|割引)\\s*(?:[:：])?\\s*$")) continue;
                Long parsed = parsePrice(coalesce(yen.group(1), yen.group(2)));
                if (parsed != null) return parsed;
            }
        }
        // Some custom stores use a non-H1 product header and a dedicated
        // sales-price label. This fallback stays independent from metadata.
        if (WishlistCrawler.isSingleProductPage(page))
            return explicitLabeledYenPrice(html);
        return null;
    }

    private static Long explicitLabeledYenPrice(String html) {
        if (html == null) return null;
        String text = SCRIPT_OR_STYLE.matcher(html).replaceAll(" ");
        text = Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("[\\s　]+", " ");
        java.util.regex.Pattern labeled = java.util.regex.Pattern.compile(
                "(?:^|[\\s　])(?:販売価格|商品価格|税込価格|価格)\\s*[:：]?\\s*([¥￥]\\s*[0-9][0-9,]*|[0-9][0-9,]*\\s*円)");
        Matcher matches = labeled.matcher(text);
        Long found = null;
        while (matches.find()) {
            // Ranges are separately persisted as ranges, not exact price points.
            if (WishlistRetailPriceQuote.fromBareText(text.substring(matches.start(1),
                    Math.min(text.length(), matches.end(1) + 20))) != null) continue;
            Matcher amount = YEN_PRICE.matcher(matches.group(1));
            if (!amount.find()) continue;
            Long candidate = parsePrice(coalesce(amount.group(1), amount.group(2)));
            if (candidate == null) continue;
            if (found != null && !found.equals(candidate)) return null;
            found = candidate;
        }
        return found;
    }
    private static boolean typeMatches(Object types, String needle) {
        if (types instanceof JSONArray) {
            JSONArray arr = (JSONArray) types;
            for (int i = 0; i < arr.length(); i++) if (typeMatches(arr.opt(i), needle)) return true;
        } else if (types instanceof String) {
            String type = ((String) types).toLowerCase(Locale.ROOT);
            return type.equals(needle) || type.endsWith("/" + needle) || type.endsWith(":" + needle);
        }
        return false;
    }

    private static boolean isYenText(String raw) {
        return raw != null && (raw.contains("¥") || raw.contains("￥") || raw.contains("円")
                || raw.toLowerCase(Locale.ROOT).contains("&yen;"));
    }

    private static Long itempropPrice(String html, URL page) {
        Matcher tags = PRICE_TAG.matcher(html);
        String currency = null;
        String raw = null;
        while (tags.find()) {
            Map<String, String> attrs = attributes(tags.group());
            String field = attrs.get("itemprop");
            if (field == null) continue;
            if (field.equalsIgnoreCase("priceCurrency"))
                currency = clean(coalesce(attrs.get("content"), attrs.get("value")));
            if (field.equalsIgnoreCase("price")) {
                raw = clean(coalesce(attrs.get("content"), attrs.get("value")));
                if (raw == null && !tags.group().startsWith("</")) {
                    String tag = tags.group();
                    if (!tag.endsWith("/>")) {
                        int textEnd = html.indexOf('<', tags.end());
                        if (textEnd > tags.end() && textEnd - tags.end() < 80)
                            raw = clean(html.substring(tags.end(), textEnd));
                    }
                }
            }
            if (currency != null && raw != null) break;
        }
        if (currency != null && !"JPY".equalsIgnoreCase(currency)) return null;
        return currency != null || isJapanSite(page) || isYenText(raw) ? parsePrice(raw) : null;
    }

    private static int firstMarker(String text, String... markers) {
        int first = -1;
        for (String marker : markers) {
            int at = text.indexOf(marker);
            if (at >= 0 && (first < 0 || at < first)) first = at;
        }
        return first;
    }

    private static String normalizeHeading(String text) {
        return text == null ? "" : text.replaceAll("[\\s　\\p{Punct}（）・]+", "").toLowerCase(Locale.ROOT);
    }

    private static Map<String, String> attributes(String tag) {
        Map<String, String> out = new HashMap<>();
        Matcher a = ATTRIBUTE.matcher(tag);
        while (a.find()) {
            String key = a.group(1).toLowerCase(Locale.ROOT);
            out.putIfAbsent(key, coalesce(a.group(2), a.group(3), a.group(4)));
        }
        return out;
    }

    private static boolean isJapanSite(URL u) { String h = u.getHost().toLowerCase(Locale.ROOT); return h.endsWith(".jp"); }

    private static Long parsePrice(String s) {
        if (s == null) return null;
        try {
            String numeric = clean(s);
            if (numeric == null) return null;
            numeric = numeric.replace(",", "").replace("¥", "").replace("￥", "")
                    .replace("円", "").replace("\u00a0", "").replace(" ", "").trim();
            if (!numeric.matches("[0-9]+(?:\\.[0-9]{1,2})?")) return null;
            double d = Double.parseDouble(numeric);
            return d >= 1 && d <= 100_000_000 ? Math.round(d) : null;
        } catch (Exception ignored) { return null; }
    }

    private static String clean(String s) {
        if (s == null) return null;
        String cleaned = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\\s+", " ").trim();
        return cleaned.isBlank() ? null : cleaned;
    }

    private static String coalesce(String... values) { for (String s : values) if (s != null && !s.isBlank()) return s; return null; }
}
