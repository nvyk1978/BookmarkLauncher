package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** HIRAKI size/color stock rows, not the five-item stock SYMBOL LEGEND. GENERAL-only. */
final class HirakiStockEvidence {
    private static final Pattern HEADING = Pattern.compile("(?is)<h1\\b[^>]*>.*?</h1\\s*>");
    private static final Pattern TAGS = Pattern.compile("(?is)<(?:script|style|noscript)\\b[^>]*>.*?</(?:script|style|noscript)\\s*>|<[^>]+>");
    private static final Pattern TABLE = Pattern.compile("(?is)<table\\b[^>]*>(.*?)</table\\s*>");
    private static final Pattern ROW = Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr\\s*>");
    private static final Pattern CELL = Pattern.compile("(?is)<t[dh]\\b[^>]*>(.*?)</t[dh]\\s*>");
    private static final Pattern QTY = Pattern.compile("(?is)<input\\b[^>]*(?:type\\s*=\\s*['\"]?(?:number|text)|(?:name|id)\\s*=\\s*['\"][^'\"]*(?:qty|quantity|count|num))[^>]*>");
    private static final Pattern DISABLED = Pattern.compile("(?i)(?:\\sdisabled(?:\\s|=|>|$)|aria-disabled\\s*=\\s*['\"]true['\"]|\\sreadonly(?:\\s|=|>|$))");
    private static final Pattern CART_BUTTON = Pattern.compile("(?is)<button\\b([^>]*)>(.*?)</button\\s*>|<input\\b([^>]*)>");
    private static final Pattern SOLD = Pattern.compile("(?:×|✕|完売|売り切れ|在庫切れ)");
    private static final Pattern IN_STOCK = Pattern.compile("(?:○|◯|△|在庫あり|在庫わずか|入荷後発送|後日発送)");
    private HirakiStockEvidence() { }

    static boolean isHirakiProduct(URL page) {
        if (page == null) return false;
        String host = page.getHost().toLowerCase(Locale.ROOT);
        return (host.equals("www.hiraki.co.jp") || host.equals("hiraki.co.jp"))
                && page.getPath().matches("(?i)/ec/pro/disp/1/[0-9]+/?");
    }

    static WishlistAvailabilityExtractor.Result inspect(String html, URL page) {
        if (!isHirakiProduct(page) || html == null) return null;
        String sku = page.getPath().replaceAll("/+$", "").replaceAll(".*/", "");
        Matcher h = HEADING.matcher(html);
        if (!h.find()) return unknown("品番と商品見出しの対応を確認できず");
        String vicinity = text(html.substring(Math.max(0, h.start()-1100), h.end()));
        if (!Pattern.compile("品番\\s*[:：]?\\s*"+Pattern.quote(sku)+"(?![0-9])").matcher(vicinity).find())
            return unknown("対象商品品番を確認できず");
        // Only the main item's buy table, preceding the product description.
        String rest = html.substring(h.end(), Math.min(html.length(), h.end()+22000));
        Matcher desc = Pattern.compile("(?i)<h[2-4][^>]*>\\s*商品説明").matcher(rest);
        if (desc.find()) rest = rest.substring(0, desc.start());
        Matcher table = TABLE.matcher(rest);
        int qualifying = 0;
        String resolved = "UNKNOWN";
        while (table.find()) {
            String contents = table.group(1);
            String prefix = text(rest.substring(Math.max(0, table.start()-850), table.start()));
            String heading = text(contents.substring(0,Math.min(contents.length(),1200)));
            if (!(prefix.contains("(99)") || prefix.contains("（99）")
                    || heading.contains("(99)") || heading.contains("（99）"))) continue;
            if (!(heading.contains("在庫") && heading.contains("数量"))) continue;
            Matcher row = ROW.matcher(contents);
            while (row.find()) {
                String r = row.group(1), label = text(r);
                Matcher quantity = QTY.matcher(r);
                // The selected variant has a quantity control, or an explicitly
                // disabled stock row without a control. Ignore the legend, which
                // is outside the size/stock/quantity table.
                if (!quantity.find()) continue;
                Matcher cells = CELL.matcher(r);
                java.util.ArrayList<String> c = new java.util.ArrayList<>();
                while (cells.find()) c.add(text(cells.group(1)));
                if (c.size()<2) continue;
                String stock = c.get(c.size()-2).trim();
                String evidence = "UNKNOWN";
                if (SOLD.matcher(stock).find()) evidence="UNAVAILABLE";
                else if (!DISABLED.matcher(quantity.group()).find() && hasActiveCart(rest)
                        && (IN_STOCK.matcher(stock).find() || stock.isBlank())) evidence="AVAILABLE";
                if (!"UNKNOWN".equals(evidence)) {
                    if (!"UNKNOWN".equals(resolved) && !resolved.equals(evidence))
                        return unknown("同じ商品の在庫欄に矛盾");
                    resolved=evidence; qualifying++;
                }
            }
        }
        RetailDiagnostics.hiraki("html.stock", "skuMatch=true verifiedRows="+qualifying+" status="+resolved);
        return qualifying > 0 ? new WishlistAvailabilityExtractor.Result(resolved,true,"ヒラキ対象色99の在庫行（HTML）")
                : unknown("対象色99の在庫行をHTMLから特定できず（凡例は判定対象外）");
    }

    private static boolean hasActiveCart(String scopedHtml) {
        Matcher buttons = CART_BUTTON.matcher(scopedHtml);
        while (buttons.find()) {
            String attrs = buttons.group(1) != null ? buttons.group(1) : buttons.group(3);
            String label = buttons.group(2) != null ? text(buttons.group(2)) : attrs;
            if (!DISABLED.matcher(attrs).find() && label.contains("カートに入れる")) return true;
        }
        return false;
    }

    private static WishlistAvailabilityExtractor.Result unknown(String reason) {
        RetailDiagnostics.hiraki("html.unknown", reason);
        return new WishlistAvailabilityExtractor.Result("UNKNOWN",false,reason);
    }
    private static String text(String html) {
        return TAGS.matcher(html).replaceAll(" ").replace("&nbsp;"," ").replace("&#215;","×")
                .replace("&times;","×").replaceAll("[\\s　]+"," ");
    }
}
