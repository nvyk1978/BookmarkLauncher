package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/**
 * A read-only fallback for GENERAL product detail pages whose ordinary gallery
 * extractor found no images. It reads advertisement-style Product JSON-LD and
 * its image feed ONLY when the Product belongs to the requested item. It never
 * determines price, stock, identity of other products, or writes saved fields.
 *
 * In particular, it does not replace Joshin's already established image
 * pipeline. Failure to verify a product means zero candidates, not a guess.
 */
public final class WishlistVerifiedProductImageDom {
    private WishlistVerifiedProductImageDom() { }

    public static boolean supports(URL page, WishlistMode mode) {
        return page != null && mode == WishlistMode.GENERAL
                && "https".equalsIgnoreCase(page.getProtocol())
                && WishlistCrawler.isAllowedUrl(page)
                && WishlistCrawler.isSingleProductPage(page)
                && MarketplaceIdentity.site(page) == MarketplaceIdentity.Site.OTHER
                && !WishlistJoshinProductIdentity.isDetail(page);
    }

    public static String javascript(URL page, WishlistMode mode) {
        if (!supports(page, mode)) return "JSON.stringify([])";
        String identity = WishlistGeneralProductIdentity.code(page);
        // Edion item IDs are explicitly in ?p_cd. Never confuse detail.html
        // with a generic product identifier.
        if (identity.isEmpty() || "detail".equalsIgnoreCase(identity))
            return "JSON.stringify([])";
        return SCRIPT.replace("__HOST__", JSONObject.quote(page.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(page.getPath().replaceAll("/+$", "")))
                .replace("__ITEM__", JSONObject.quote(identity))
                .replace("__EDION__", isEdion(page) ? "true" : "false")
                .replace("__ZOZO__", WishlistZozoVariantDom.supports(page) ? "true" : "false");
    }

    private static boolean isEdion(URL url) {
        String h = url.getHost().toLowerCase(Locale.ROOT);
        return (h.equals("edion.com") || h.equals("www.edion.com"))
                && url.getPath().equalsIgnoreCase("/detail.html");
    }

    private static final String SCRIPT = """
(function(){'use strict';
 try{
  const host=__HOST__,path=__PATH__,code=__ITEM__,edion=__EDION__,zozo=__ZOZO__;
  const empty=()=>JSON.stringify([]);
  if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host||
      location.pathname.replace(/\\/+$/,'').toLowerCase()!==path.toLowerCase())return empty();
  if(edion&&new URLSearchParams(location.search).get('p_cd')!==code)return empty();
  const main=document.querySelector('main,[role=main],#main,#contents,#content')||document.body;
  if(!main)return empty();
  const bad='header,nav,footer,aside,[class*=recommend],[class*=related],'+
    '[class*=ranking],[class*=pickup],[id*=recommend],[id*=related]';
  const visible=e=>{if(!e||e.closest(bad))return false;
    const s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden';};
  const headings=[...main.querySelectorAll('h1')].filter(visible);
  if(headings.length!==1)return empty();
  const norm=s=>String(s||'').replace(/[\\s　・\u00a0]/g,'').toLowerCase();
  const title=norm(headings[0].innerText||headings[0].textContent);
  if(title.length<5)return empty();
  const samePage=raw=>{try{const u=new URL(raw,location.href);
    return u.protocol==='https:'&&u.hostname.toLowerCase()===host&&
      u.pathname.replace(/\\/+$/,'').toLowerCase()===path.toLowerCase()&&
      (!edion||u.searchParams.get('p_cd')===code);
    }catch(_){return false;}};
  const canonical=document.querySelector('link[rel=canonical]');
  // A canonical link to a *different* item makes every fallback unsafe.
  if(canonical&&canonical.href&&!samePage(canonical.href))return empty();
  const strongCanonical=!!(canonical&&canonical.href&&samePage(canonical.href));
  const rootText=String(main.innerText||main.textContent||'').slice(0,60000);
  const inquiry=zozo&&(/^\\d{5,15}$/.test(code))&&
      [...rootText.matchAll(/問い合わせ番号\\s*[:：]?\\s*([0-9]{5,15})\\s*[（(]ZOZO[）)]/g)]
      .some(m=>m[1]===code||m[1]===String(Number(code)+1000000));
  const validImage=raw=>{try{
    if(!raw||typeof raw!=='string'||raw.length>2048)return '';
    const u=new URL(raw.replace(/&amp;/g,'&'),location.href);
    if(u.protocol!=='https:'||u.username||u.password)return '';
    if(!(/\\.(?:jpe?g|png|webp|avif)(?:$|[?#])/i.test(u.href)||
          /\\/images?\\//i.test(u.pathname)))return '';
    if(/logo|banner|icon|payment|cart|recommend|related|tracking|spacer|placeholder|noimage|no-image|ranking/i.test(u.pathname))return '';
    return u.href;
   }catch(_){return '';}};
  const selected=new Map();
  const add=(raw,score)=>{const u=validImage(raw);if(u&&(!selected.has(u)||score>selected.get(u)))selected.set(u,score);};
  const photo=v=>{
    if(typeof v==='string'){add(v,230);return;}
    if(Array.isArray(v)){v.slice(0,15).forEach(photo);return;}
    if(v&&typeof v==='object')add(v.contentUrl||v.url,225);
  };
  function visit(v,depth){
    if(depth>4||!v)return;
    if(Array.isArray(v)){v.slice(0,30).forEach(x=>visit(x,depth+1));return;}
    if(typeof v!=='object')return;
    if(v['@graph'])visit(v['@graph'],depth+1);
    const typ=String(v['@type']||'').toLowerCase();
    if(!/(^|[,\\s])product($|[,\\s])/.test(typ) && !Array.isArray(v['@type']))return;
    if(Array.isArray(v['@type'])&&!v['@type'].some(t=>/product/i.test(String(t))))return;
    const name=norm(v.name), matchTitle=name.length>=6&&
      (name===title||(Math.min(name.length,title.length)>=9&&
      (title.includes(name)||name.includes(title))));
    if(!matchTitle)return;
    const sku=[v.sku,v.productID,v.mpn,v.gtin13,v.gtin,v.identifier]
      .some(x=>typeof x==='string'&&x.toLowerCase()===code.toLowerCase());
    const linked=samePage(v.url)||samePage(v['@id']);
    // If an offer declares its own item URL, a mismatch is an explicit
    // contradiction even if this document's canonical link is correct.
    if((v.url||v['@id'])&&!linked)return;
    // Canonical alone does not certify a page-wide Product list: the JSON-LD
    // must also match the unique visible product title.
    if(!(linked||sku||strongCanonical||inquiry))return;
    photo(v.image);
  }
  [...document.querySelectorAll('script[type="application/ld+json"]')]
    .slice(0,20).forEach(s=>{try{visit(JSON.parse(s.textContent),0);}catch(_){}});
  // Only after verifying identity via canonical/ZOZO inquiry, allow the
  // principal gallery and the page's own OGP. Never scan all page images.
  if(strongCanonical||inquiry){
    const selectors=['img[itemprop=image]','#mainImage','#mainImage img',
      '.product-gallery img','.product-detail__image img','.product-image img',
      '.goods-detail__image img','[class*=GoodsDetail] [class*=image] img',
      '[class*=goodsDetail] [class*=image] img','[data-testid*=goods-image] img'];
    for(const sel of selectors){
      for(const el of [...main.querySelectorAll(sel)].slice(0,8)){
        if(!visible(el))continue;
        const img=el.tagName==='IMG'?el:el.querySelector('img');
        if(!img||!visible(img))continue;
        const label=String(img.alt||'')+' '+String(img.className||'');
        if(/recommend|related|banner|logo|icon|placeholder|ranking/i.test(label))continue;
        add(img.getAttribute('data-zoom-image'),150);
        add(img.getAttribute('data-original'),145);
        add(img.getAttribute('data-src'),140);
        add(img.currentSrc||img.src,135);
        const srcset=img.getAttribute('srcset')||img.getAttribute('data-srcset')||'';
        for(const part of srcset.split(',').slice(0,12))add(part.trim().split(/\\s+/)[0],155);
      }
    }
    // OGP is the merchant's intended hero image for search/advertisements.
    const og=document.querySelector('meta[property="og:image:secure_url"],meta[property="og:image"]');
    if(og)add(og.content,110);
  }
  return JSON.stringify([...selected.entries()].sort((a,b)=>b[1]-a[1])
    .slice(0,6).map(p=>p[0]));
 }catch(_){return JSON.stringify([]);}
})()
""";
}
