package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONObject;

/** Non-purchasing UNIQLO variant control only: one explicit target selection per
 * step, no shopping-cart submission, no inferred SKU, no arbitrary page click. */
final class RetailVariantActivator {
    private RetailVariantActivator() { }
    static String script(String query, int step) {
        if(step<0||step>2)return "(function(){return 'ignored';})()";
        return "(function(){'use strict';try{"
                +"const p=new URLSearchParams("+JSONObject.quote(query==null?"":query)+");"
                +"const pairs=[['colorDisplayCode',['data-color-code','data-color-display-code']],"
                +"['sizeDisplayCode',['data-size-code','data-size-display-code']],"
                +"['pldDisplayCode',['data-length-code','data-pld-display-code']]];"
                +"const [key,attrs]=pairs["+step+"];const target=p.get(key);if(!target)return 'no-target';"
                +"if(!/^\\/jp\\/ja\\/products\\/E[0-9]{6}-[0-9]{3}\\/[0-9]{2}\\/?$/.test(location.pathname))return 'wrong-product';"
                +"const actual=new URLSearchParams(location.search);if(actual.has(key)&&actual.get(key)!==target)return 'variant-conflict';"
                +"const scope=document.querySelector('main,[data-testid=product-detail]')||document.body;"
                +"let matches=[];for(const a of attrs){for(const e of scope.querySelectorAll('['+a+']')){"
                +"if(e.getAttribute(a)===target && !matches.includes(e))matches.push(e);}}"
                +"matches=matches.filter(e=>e.getClientRects().length>0);"
                +"if(matches.length!==1)return matches.length?'ambiguous':'not-exposed';"
                +"const e=matches[0];const button=e.closest('button,[role=option],[role=radio]')||e;"
                +"if(button.tagName==='A'||/add.to.cart|購入|注文/i.test(String(button.id||'')+' '+String(button.className||'')))return 'unsafe';"
                +"if(button.disabled||button.getAttribute('aria-disabled')==='true')return 'disabled';"
                +"if(button.getAttribute('aria-selected')==='true'||button.getAttribute('aria-pressed')==='true'||"
                +"button.classList.contains('selected'))return 'already-selected';"
                +"button.click();return 'target-selected';"
                +"}catch(e){return 'activation-error';}})()";
    }
}
