package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Amazon product hero IMAGE ONLY; cannot read or change title, price or history. */
final class AmazonProductImageExtractor {
    private static final Pattern LARGE = Pattern.compile(
            "[\"'](?:hiRes|large|mainUrl)[\"']\\s*:\\s*[\"'](https://[^\"']+)[\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern HIRES_ATTRIBUTE = Pattern.compile(
            "data-(?:old-hires|a-hires)\\s*=\\s*[\"'](https://[^\"']+)[\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern IMAGE_LINK = Pattern.compile(
            "https://(?:[a-zA-Z0-9.-]+\\.)?(?:media-amazon\\.com|ssl-images-amazon\\.com)/images/I/[a-zA-Z0-9._%+\\-]+",
            Pattern.CASE_INSENSITIVE);

    private AmazonProductImageExtractor() { }

    static String find(String html, URL page) {
        if (html == null || page == null) return null;
        String host = page.getHost().toLowerCase(Locale.ROOT);
        if (!(host.equals("amazon.co.jp") || host.endsWith(".amazon.co.jp"))) return null;
        // Amazon product images are embedded as JSON escaped URLs or lazy image
        // attributes, not always as OG tags. Do not match other /images/G/ assets.
        String source = html.replace("&#47;", "/").replace("&quot;", "\"")
                .replace("&#34;", "\"").replace("&amp;", "&");
        // Amazon sometimes double-escapes slashes inside inline image JSON.
        for (int i = 0; i < 3; i++) source = source.replace("\\/", "/");
        for (Pattern pattern : new Pattern[]{LARGE, HIRES_ATTRIBUTE}) {
            Matcher m = pattern.matcher(source);
            while (m.find()) {
                String value = accept(m.group(1));
                if (value != null) return value;
            }
        }
        // When inline high-res keys are absent, a thumbnail in the primary
        // product-image block is a better fallback than a blank card.
        int start = firstBlock(source);
        if (start >= 0) {
            Matcher m = IMAGE_LINK.matcher(source);
            int from = Math.max(0, start - 400);
            int to = Math.min(source.length(), start + 12000);
            m.region(from, to);
            while (m.find()) {
                String value = accept(m.group());
                if (value != null) return value;
            }
        }
        return null;
    }

    private static int firstBlock(String html) {
        for (String token : new String[]{"id=\"landingImage\"", "id='landingImage'",
                "id=\"imgTagWrapperId\"", "id='imgTagWrapperId'",
                "id=\"imageBlock\"", "id='imageBlock'", "colorImages"}) {
            int i = html.indexOf(token);
            if (i >= 0) return i;
        }
        return -1;
    }

    private static String accept(String raw) {
        try {
            URL url = new URL(raw);
            if (!"https".equalsIgnoreCase(url.getProtocol()) || !WishlistCrawler.isAllowedUrl(url)) return null;
            String host = url.getHost().toLowerCase(Locale.ROOT);
            if (!(host.equals("media-amazon.com") || host.endsWith(".media-amazon.com") ||
                    host.equals("ssl-images-amazon.com") || host.endsWith(".ssl-images-amazon.com"))) return null;
            return url.getPath().startsWith("/images/I/") ? url.toString() : null;
        } catch (Exception ignored) { return null; }
    }
}
