package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONObject;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Main Amazon gallery ONLY. HTML-wide hiRes/large scans can select recommendations. */
final class AmazonProductImageExtractor {
    private static final Pattern IMG=Pattern.compile("(?is)<img\\b[^>]*>");
    private static final Pattern ATTR=Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')",Pattern.CASE_INSENSITIVE);
    private static final Pattern PRIMARY_IMAGE=Pattern.compile("(?i)^(?:landingImage|imgBlkFront|ebooksImgBlkFront|main-image)$");
    private static final Pattern BLOCK=Pattern.compile("(?is)<(?:div|span)\\b[^>]*\\bid\\s*=\\s*['\"](?:imgTagWrapperId|main-image-container|imageBlock)['\"][^>]*>");
    private AmazonProductImageExtractor(){}
    static String find(String html,URL page) {
        List<String> candidates=candidates(html,page);
        return candidates.isEmpty()?null:candidates.get(0);
    }
    static List<String> candidates(String html,URL page){
        MarketplaceIdentity key=MarketplaceIdentity.from(page);
        if(key==null||key.site!=MarketplaceIdentity.Site.AMAZON||!key.verified(html,page))return java.util.Collections.emptyList();
        LinkedHashSet<String> urls=new LinkedHashSet<>();
        // First, exact primary-image IDs, never any attribute from related carousel.
        Matcher images=IMG.matcher(html);
        while(images.find()){
            String tag=images.group();
            String id=attr(tag,"id");
            if(id!=null&&PRIMARY_IMAGE.matcher(id).matches())collect(tag,urls);
        }
        // Some layouts omit landingImage but have a dedicated main gallery.
        // Bound the search tightly to its beginning, before thumbnails/recommendations.
        if(urls.isEmpty()){
            Matcher blocks=BLOCK.matcher(html);
            while(blocks.find()){
                String scope=html.substring(blocks.end(),Math.min(html.length(),blocks.end()+4500));
                Matcher im=IMG.matcher(scope);
                if(im.find())collect(im.group(),urls);
                if(!urls.isEmpty())break;
            }
        }
        return new ArrayList<>(urls);
    }
    private static void collect(String tag,LinkedHashSet<String> urls){
        String dynamic=attr(tag,"data-a-dynamic-image");
        if(dynamic!=null){
            try {
                JSONObject obj=new JSONObject(unescape(dynamic));
                String best=null;long area=-1;
                for(java.util.Iterator<String> it=obj.keys();it.hasNext();){
                    String key=it.next();
                    if(accept(key)==null)continue;
                    org.json.JSONArray size=obj.optJSONArray(key);
                    long pixels=size!=null&&size.length()>=2?(long)size.optInt(0)*size.optInt(1):0;
                    if(pixels>area){best=key;area=pixels;}
                }
                if(best!=null)urls.add(accept(best));
            }catch(Exception ignored){}
        }
        for(String field:new String[]{"data-old-hires","data-a-hires","data-src","src"}){
            String link=accept(unescape(attr(tag,field)));
            if(link!=null)urls.add(link);
        }
    }
    private static String attr(String tag,String name){
        Matcher a=ATTR.matcher(tag);
        while(a.find())if(name.equalsIgnoreCase(a.group(1)))return a.group(2)!=null?a.group(2):a.group(3);
        return null;
    }
    private static String unescape(String s){
        if(s==null)return null;
        return s.replace("&quot;","\"").replace("&#34;","\"").replace("&amp;","&")
                .replace("&#47;","/").replace("\\/","/").replace("\\u0026","&");
    }
    private static String accept(String raw){
        if(raw==null)return null;
        try{
            URL url=new URL(raw);
            if(!"https".equalsIgnoreCase(url.getProtocol())||!WishlistCrawler.isAllowedUrl(url))return null;
            String h=url.getHost().toLowerCase(Locale.ROOT);
            if(!(h.equals("media-amazon.com")||h.endsWith(".media-amazon.com")||
                    h.equals("ssl-images-amazon.com")||h.endsWith(".ssl-images-amazon.com")))return null;
            return url.getPath().startsWith("/images/I/")?url.toString():null;
        }catch(Exception ignored){return null;}
    }
}
