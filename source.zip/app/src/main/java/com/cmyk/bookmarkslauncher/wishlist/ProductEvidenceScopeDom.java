package com.cmyk.bookmarkslauncher.wishlist;

/**
 * Shared, read-only product-bound evidence helpers for otherwise independent
 * GENERAL-shop DOM scripts. No clicks, network calls, or global stock guesses.
 * The helpers cannot make a purchase verdict: each store must independently
 * verify its SKU, the selected variant, and negative stock evidence.
 */
final class ProductEvidenceScopeDom {
    private ProductEvidenceScopeDom() { }

    static String javascript() {
        return """
(function(){'use strict';
 const excluded='header,nav,footer,aside,[class*=related],[class*=recommend],[class*=ranking],'+
   '[id*=related],[id*=recommend],[class*=modal],[class*=dialog]';
 const selector='button,input[type=submit],input[type=button],input[type=image],'+
   '[role=button],a[href],[onclick],[data-action],[data-cart],[data-testid]';
 const phrase=/(?:カート|買い物かご|カゴ)\\s*(?:に)?\\s*(?:入れる|追加)|購入する|add\\s*to\\s*(?:cart|basket)/i;
 const action=/(?:add.?to.?cart|add.?cart|cart.?add|cartin|add.?basket|put.?cart|put.?basket|shopping.?cart)/i;
 function text(e){return String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ').replace(/\\s+/g,' ').trim();}
 function enabled(e){
   if(!e||e.disabled||e.readOnly||e.hasAttribute('disabled')||e.getAttribute('aria-disabled')==='true')return false;
   if(/(?:disabled|sold.?out|unavailable)/i.test(String(e.className||'')))return false;
   for(let p=e;p;p=p.parentElement){
     if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return false;
     const st=getComputedStyle(p);
     if(st.display==='none'||st.visibility==='hidden'||st.visibility==='collapse'||Number(st.opacity)===0)return false;
   }return true;
 }
 // A product marker must remain inside the result, even when a recommendation
 // heading appears BEFORE it. Boundaries AFTER the marker limit related cards.
 function around(source,marker,before,after){
   const value=String(source||'');marker.lastIndex=0;
   const match=marker.exec(value);
   if(!match)return {found:false,text:'',markerOffset:-1,cutBefore:false,cutAfter:false,chars:0};
   const start=Math.max(0,match.index-Math.min(before||1200,5000));
   const end=Math.min(value.length,match.index+match[0].length+Math.min(after||3000,8000));
   let prefix=value.slice(start,match.index),suffix=value.slice(match.index,end);
   const boundary=/(?:関連商品|おすすめ商品|この商品を見た|一緒に購入|ランキング|こちらもおすすめ)/g;
   let b,last=-1;while((b=boundary.exec(prefix))!==null)last=b.index+b[0].length;
   const cutBefore=last>=0;if(cutBefore)prefix='';
   boundary.lastIndex=0;b=boundary.exec(suffix.slice(match[0].length));
   const cutAfter=!!b;if(cutAfter)suffix=suffix.slice(0,match[0].length+b.index);
   return {found:true,text:prefix+suffix,markerOffset:prefix.length,
     cutBefore:cutBefore,cutAfter:cutAfter,chars:(prefix+suffix).length};
 }
 function linkDistance(a,b){
   if(!a||!b)return -1;
   let d=0;
   for(let p=a;p&&d<=7;p=p.parentElement,d++){
     let n=0;for(let q=b;q&&n<=7;q=q.parentElement,n++)if(p===q)return d+n;
   }return -1;
 }
 // The closest product input provides an anchor; no mere header cart link or
 // recommendation control can become positive evidence. Keep diagnostics bounded.
 function controls(root,quantity){
   const out={scanned:0,found:0,enabled:0,linked:0,image:0,
     textHints:0,actionHints:0,outside:0,disabled:0,nearest:-1,tag:'none'};
   if(!root||!root.querySelectorAll)return out;
   const doc=root.ownerDocument||document;
   const nodes=[...root.querySelectorAll(selector)];out.scanned=nodes.length;
   for(const c of nodes){
     if(c.closest(excluded))continue;
     if(c.querySelector('button,input,[onclick],[data-action]')&&!c.matches('button,input,a'))continue;
     const img=c.querySelector('img');
     const label=[text(c),c.value,c.getAttribute('aria-label'),c.getAttribute('title'),c.getAttribute('alt'),
       img&&img.getAttribute('alt')].filter(Boolean).join(' ');
     const attrs=[c.name,c.id,c.className,c.getAttribute('onclick'),c.getAttribute('data-action'),
       c.getAttribute('data-cart'),c.getAttribute('data-testid'),c.getAttribute('href'),
       c.getAttribute('src'),img&&img.getAttribute('src')].filter(Boolean).join(' ');
     if(c.matches('input[type=image]')||img)out.image++;
     const t=phrase.test(label),a=action.test(attrs);
     if(t)out.textHints++;if(a)out.actionHints++;
     if(!t&&!a)continue;
     out.found++;
     const live=enabled(c);if(live)out.enabled++;else out.disabled++;
     if(live&&quantity){const distance=linkDistance(c,quantity);
       // Limit evidence to actual product neighbours, not a global menu cart.
       if(distance>=0&&distance<=9){out.linked++;
         if(out.nearest<0||distance<out.nearest)out.nearest=distance;}
     }
     if(out.tag==='none')out.tag=String(c.tagName||'').toLowerCase().slice(0,15);
   }
   if(doc.body&&doc.body!==root){
     for(const c of doc.body.querySelectorAll(selector)){
       if(root.contains(c)||c.closest(excluded))continue;
       const s=[text(c),c.getAttribute('aria-label'),c.getAttribute('onclick'),c.getAttribute('data-action')]
         .filter(Boolean).join(' ');
       if(phrase.test(s)||action.test(s))out.outside++;
     }
   }
   return out;
 }
 // Purchase intent is identified by the *control itself* (including its
 // accessible name). Text such as "カートに入れるボタンを押してください" in a
 // plain paragraph cannot be treated as a live purchase action.
 function liveCart(root,quantity){
   const out={found:0,enabled:0,linked:0,disabled:0,shadow:0,tag:'none'};
   if(!root||!root.querySelectorAll)return out;
   const candidates=[];const seen=new Set();
   const push=n=>{if(n&&!seen.has(n)){seen.add(n);candidates.push(n);}};
   function walk(node,depth){
     if(!node||!node.querySelectorAll||depth>3)return;
     for(const c of node.querySelectorAll(selector+',label,[tabindex]')){
       push(c);
       if(c.shadowRoot){out.shadow++;walk(c.shadowRoot,depth+1);}
     }
   }
   walk(root,0);
   const actions=/(?:カート|買い物かご|カゴ)\\s*(?:に)?\\s*(?:入れる|追加)|(?:購入する|注文する)|add\\s*(?:to)?\\s*(?:cart|basket)/i;
   const codes=/(?:add.?to.?cart|add.?cart|cart.?add|cartin|add.?basket|put.?cart|shopping.?cart)/i;
   for(const c of candidates){
     if(c.closest&&c.closest(excluded))continue;
     const tag=String(c.tagName||'').toLowerCase();
     const actionable=tag==='button'||tag==='input'&&/^(?:submit|button|image)$/i.test(c.type||'')
       ||tag==='a'&&!!c.getAttribute('href')||c.getAttribute('role')==='button'
       ||!!c.getAttribute('onclick')||!!c.getAttribute('data-action')
       ||!!c.getAttribute('data-cart');
     if(!actionable)continue;
     // Don't count an ancestor container and its nested actionable child twice.
     if(c.querySelector&&c.querySelector('button,input[type=submit],input[type=button],[role=button]')
        &&tag!=='button'&&tag!=='input'&&tag!=='a')continue;
     const picture=c.querySelector&&c.querySelector('img');
     const label=[text(c),c.value,c.getAttribute('aria-label'),c.getAttribute('title'),
       c.getAttribute('alt'),picture&&picture.getAttribute('alt')].filter(Boolean).join(' ').slice(0,230);
     const attributes=[c.id,c.name,c.className,c.getAttribute('data-action'),
       c.getAttribute('data-testid'),c.getAttribute('data-cart'),c.getAttribute('onclick'),
       c.getAttribute('src'),picture&&picture.getAttribute('src')].filter(Boolean).join(' ').slice(0,380);
     if(!actions.test(label)&&!codes.test(attributes))continue;
     out.found++;if(out.tag==='none')out.tag=tag;
     if(enabled(c)){
       out.enabled++;
       if(quantity){const distance=linkDistance(c,quantity);
         if(distance>=0&&distance<=12)out.linked++;}
     }else out.disabled++;
   }
   return out;
 }
 return {text:text,enabled:enabled,around:around,controls:controls,liveCart:liveCart,linkDistance:linkDistance};
})()
""";
    }
}
