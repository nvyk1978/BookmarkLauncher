package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Scoped, conservative HTML evidence; GENERAL only, never a seller-specific mode. */
final class GeneralRetailHtmlEvidence {
    private GeneralRetailHtmlEvidence() { }
    private static final Pattern H1 = Pattern.compile("(?is)<h1\\b[^>]*>.*?</h1\\s*>");
    private static final Pattern CODE_LABEL = Pattern.compile("(?i)(?:お申込番号|お申し込み番号|注文コード)");
    private static final Pattern STRIP_SCRIPT = Pattern.compile("(?is)<(?:script|style|noscript)\\b[^>]*>.*?</(?:script|style|noscript)\\s*>");
    private static final Pattern ELEMENT = Pattern.compile("(?is)<(?:button|input|a)\\b([^>]*)(?:>(.{0,200}?)</(?:button|a)\\s*>)?");
    private static final Pattern HIDDEN = Pattern.compile("(?i)(?:\\bdisabled(?:=|\\s|>|$)|\\bhidden(?:=|\\s|>|$)|aria-disabled\\s*=\\s*['\\\"]?true|display\\s*:\\s*none)");
    private static final Pattern ASKUL_BUY = Pattern.compile("カゴに入れる|カートに入れる");
    private static final Pattern MONOTARO_BUY = Pattern.compile("バスケットに入れる|カートに入れる");
    private static final Pattern PRICE_WITH_TAX = Pattern.compile("(?:[￥¥]\\s*([0-9][0-9,]*)\\s*[（(]\\s*税込|税込\\s*[￥¥]\\s*([0-9][0-9,]*)|税込価格\\s*[:：]?\\s*[￥¥]\\s*([0-9][0-9,]*))");

    static WishlistAvailabilityExtractor.Result stock(String html, URL url) {
        String shop = GeneralRetailIdentity.store(url);
        if (shop == null) return null;
        String region = region(html, url);
        if (region == null) return new WishlistAvailabilityExtractor.Result("UNKNOWN",false,"商品コード付き購入領域を特定できず");
        String clean = region.replaceAll("(?is)<[^>]*>", " ").replaceAll("[\\s　]+", " ");
        Matcher el = ELEMENT.matcher(region);
        int enabledButtons = 0;
        while (el.find()) {
            String attrs = el.group(1), body = el.group(2) == null ? "" : el.group(2).replaceAll("<[^>]*>"," ");
            if (HIDDEN.matcher(attrs).find()) continue;
            if (("ASKUL".equals(shop) ? ASKUL_BUY : MONOTARO_BUY).matcher(attrs+" "+body).find()) enabledButtons++;
        }
        if (enabledButtons == 1 && (!"ASKUL".equals(shop)
                || Pattern.compile("在庫\\s*[:：]\\s*あり|アスクル在庫商品").matcher(clean).find()))
            return new WishlistAvailabilityExtractor.Result("AVAILABLE",false,"注文コードと購入操作（HTML）");
        return new WishlistAvailabilityExtractor.Result("UNKNOWN",false,"商品固有の購入操作を確認できず");
    }

    static Long grossPrice(String html, URL url) {
        if (GeneralRetailIdentity.store(url) == null) return null;
        String region = region(html,url);
        if (region == null) return null;
        String visible = region.replaceAll("(?is)<[^>]*>", " ").replaceAll("[\\s　]+", " ");
        Matcher m = PRICE_WITH_TAX.matcher(visible);
        // First explicitly tax-inclusive price after the confirmed main heading.
        // Stop before shipping/delivery tables or recommended items.
        if (m.find()) {
            String raw = m.group(1)!=null ? m.group(1) : m.group(2)!=null ? m.group(2) : m.group(3);
            try { return Long.parseLong(raw.replace(",", "")); }
            catch (NumberFormatException ignored) { }
        }
        return null;
    }

    /** Need the official SKU label in the SAME visible main product section. */
    private static String region(String html, URL url) {
        if (html == null || url == null || html.length() < 100) return null;
        String code = GeneralRetailIdentity.itemId(url);
        if (code == null) return null;
        String doc = STRIP_SCRIPT.matcher(html).replaceAll(" ");
        Matcher h = H1.matcher(doc);
        if (!h.find()) return null;
        String fragment = doc.substring(h.start(), Math.min(doc.length(),h.end()+19000));
        Matcher related = Pattern.compile("(?i)(?:関連商品|おすすめ商品|この商品を見た|人気の商品|こちらもおすすめ)").matcher(fragment);
        if (related.find()) fragment=fragment.substring(0,related.start());
        // Require a literal label and the correct code in the same bounded item block.
        if (!fragment.toUpperCase(Locale.ROOT).contains(code.toUpperCase(Locale.ROOT))
                || !CODE_LABEL.matcher(fragment).find()) return null;
        return fragment;
    }
}
