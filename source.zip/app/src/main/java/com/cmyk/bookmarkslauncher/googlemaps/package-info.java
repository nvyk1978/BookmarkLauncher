/**
 * Isolated Google Maps integration for BookmarkLauncher.
 *
 * Boundary rule:
 * - All Google Maps URL/share parsing, title/address extraction, redirect handling,
 *   Geocoder logic, static-map generation and Maps pin drawing live in this package.
 * - Code outside this package must use only {@link com.cmyk.bookmarkslauncher.googlemaps.GoogleMapsModule}.
 * - Do not change this package as part of ordinary bookmark/UI development unless
 *   the requested change is explicitly about Google Maps behavior.
 */
package com.cmyk.bookmarkslauncher.googlemaps;
