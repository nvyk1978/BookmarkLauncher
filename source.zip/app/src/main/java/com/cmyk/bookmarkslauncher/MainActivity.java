package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;
import com.cmyk.bookmarkslauncher.ui.BookmarkBoardView;

import java.text.DateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final int HOME_COLUMNS = 5;
    private static final int FOLDER_COLUMNS = 4;
    private static final Pattern URL_PATTERN = Pattern.compile("https?://\\S+", Pattern.CASE_INSENSITIVE);

    private BookmarkRepository repo;
    private BookmarkBoardView homeBoard;
    private PopupWindow folderPopup;
    private final ArrayDeque<String> folderStack = new ArrayDeque<>();
    private TextView folderTitle;
    private BookmarkBoardView folderBoard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new BookmarkRepository(this);
        setContentView(buildUi());
        handleIncoming(getIntent());
        refreshHome();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(48,48,48));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18), dp(14), dp(12), dp(8));

        TextView title = new TextView(this);
        title.setText("Bookmarks Launcher");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1f));

        Button add = new Button(this);
        add.setText("＋");
        add.setTextSize(22);
        add.setOnClickListener(v -> showAddDialog(null));
        top.addView(add, new LinearLayout.LayoutParams(dp(56), dp(48)));
        root.addView(top);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        homeBoard = new BookmarkBoardView(this, HOME_COLUMNS);
        homeBoard.setPadding(0,0,0,dp(32));
        bindBoard(homeBoard, null);
        scroll.addView(homeBoard, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private void bindBoard(BookmarkBoardView board, String parentId) {
        board.setListener(new BookmarkBoardView.Listener() {
            @Override public void onOpen(BookmarkNode node, View anchor) {
                if (node.isFolder()) {
                    if (parentId == null) openFolder(node);
                    else enterNestedFolder(node);
                } else openBookmark(node);
            }
            @Override public void onLongPress(BookmarkNode node, View anchor) {
                showNodeMenu(node);
            }
            @Override public void onOrderChanged(List<String> orderedIds) {
                repo.reorder(parentId, orderedIds);
            }
        });
    }

    private void refreshHome() {
        homeBoard.submit(repo.children(null));
    }

    private void openBookmark(BookmarkNode node) {
        if (node.url == null || node.url.isBlank()) return;
        repo.touchAccess(node.id);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(node.url)));
        } catch (Exception e) {
            Toast.makeText(this, "URLを開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private void openFolder(BookmarkNode node) {
        if (folderPopup == null) createFolderPopup();
        folderStack.clear();
        folderStack.push(node.id);
        renderFolder(node.id);
        if (!folderPopup.isShowing()) {
            folderPopup.showAtLocation(homeBoard, Gravity.CENTER, 0, 0);
        }
    }

    private void createFolderPopup() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        panel.setBackgroundColor(Color.rgb(37,32,32));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        Button back = new Button(this);
        back.setText("‹");
        back.setOnClickListener(v -> navigateFolderBack());
        bar.addView(back, new LinearLayout.LayoutParams(dp(52), dp(48)));

        folderTitle = new TextView(this);
        folderTitle.setTextColor(Color.WHITE);
        folderTitle.setTextSize(18);
        folderTitle.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(folderTitle, new LinearLayout.LayoutParams(0, dp(48), 1f));

        Button add = new Button(this);
        add.setText("＋");
        add.setOnClickListener(v -> showAddDialog(folderStack.peek()));
        bar.addView(add, new LinearLayout.LayoutParams(dp(52), dp(48)));
        panel.addView(bar);

        ScrollView sc = new ScrollView(this);
        folderBoard = new BookmarkBoardView(this, FOLDER_COLUMNS);
        sc.addView(folderBoard, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(sc, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        folderPopup = new PopupWindow(panel, dp(350), dp(500), true);
        folderPopup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        folderPopup.setElevation(dp(16));
        folderPopup.setOutsideTouchable(true);
    }

    private void renderFolder(String id) {
        BookmarkNode folder = repo.get(id);
        folderTitle.setText(folder == null ? "フォルダ" : folder.title);
        bindBoard(folderBoard, id);
        folderBoard.submit(repo.children(id));
    }

    private void navigateFolderBack() {
        if (folderStack.size() <= 1) {
            folderPopup.dismiss();
            return;
        }
        folderStack.pop();
        renderFolder(folderStack.peek());
    }

    private void enterNestedFolder(BookmarkNode node) {
        folderStack.push(node.id);
        renderFolder(node.id);
    }

    private void showNodeMenu(BookmarkNode node) {
        String[] actions = node.isFolder()
                ? new String[]{"情報", "1×1", "2×1", "1×2", "2×2", "削除"}
                : new String[]{"情報", "1×1", "2×1", "1×2", "2×2", "削除"};
        new AlertDialog.Builder(this)
                .setTitle(node.title)
                .setItems(actions, (d, which) -> {
                    if (which == 0) showInfo(node);
                    else if (which >= 1 && which <= 4) {
                        int[][] spans = {{1,1},{2,1},{1,2},{2,2}};
                        repo.resize(node.id, spans[which-1][0], spans[which-1][1]);
                        refreshAllVisible();
                    } else if (which == 5) {
                        repo.softDelete(node.id);
                        refreshAllVisible();
                    }
                })
                .show();
    }

    private void showInfo(BookmarkNode node) {
        DateFormat f = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        String created = f.format(new Date(node.createdAt));
        String last = node.lastAccessedAt == null ? "未アクセス" : f.format(new Date(node.lastAccessedAt));
        String offline = node.offlineSavedAt == null ? "未保存" : f.format(new Date(node.offlineSavedAt));
        String body = "URL\n" + (node.url == null ? "—" : node.url) +
                "\n\nブックマーク日\n" + created +
                "\n\n最終アクセス日\n" + last +
                "\n\nオフライン保存\n" + offline +
                "\n\nスクリーンショット\n" + (node.screenshotPath == null ? "未取得" : node.screenshotPath);
        new AlertDialog.Builder(this)
                .setTitle(node.title)
                .setMessage(body)
                .setPositiveButton("閉じる", null)
                .show();
    }

    private void showAddDialog(String parentId) {
        String[] items = {"URLを追加", "フォルダを追加"};
        new AlertDialog.Builder(this)
                .setTitle("追加")
                .setItems(items, (d, which) -> {
                    if (which == 0) showAddBookmark(parentId);
                    else showAddFolder(parentId);
                }).show();
    }

    private void showAddBookmark(String parentId) {
        EditText input = new EditText(this);
        input.setHint("https://example.com");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        new AlertDialog.Builder(this)
                .setTitle("ブックマーク追加")
                .setView(input)
                .setPositiveButton("追加", (d,w) -> {
                    String url = input.getText().toString().trim();
                    if (!url.isEmpty()) {
                        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
                        repo.createBookmark(parentId, url, url);
                        refreshAllVisible();
                    }
                })
                .setNegativeButton("キャンセル", null)
                .show();
    }

    private void showAddFolder(String parentId) {
        EditText input = new EditText(this);
        input.setHint("フォルダ名");
        new AlertDialog.Builder(this)
                .setTitle("フォルダ追加")
                .setView(input)
                .setPositiveButton("追加", (d,w) -> {
                    repo.createFolder(parentId, input.getText().toString().trim());
                    refreshAllVisible();
                })
                .setNegativeButton("キャンセル", null)
                .show();
    }

    private void handleIncoming(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if (text == null) return;
        Matcher m = URL_PATTERN.matcher(text);
        if (m.find()) {
            String url = m.group();
            repo.createBookmark(null, url, url);
            refreshHome();
            Toast.makeText(this, "ブックマークに追加しました", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshAllVisible() {
        refreshHome();
        if (folderPopup != null && folderPopup.isShowing() && !folderStack.isEmpty()) {
            renderFolder(folderStack.peek());
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
