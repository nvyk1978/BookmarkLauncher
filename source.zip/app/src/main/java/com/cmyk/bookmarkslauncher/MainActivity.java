package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;
import com.cmyk.bookmarkslauncher.ui.BookmarkBoardView;
import com.cmyk.bookmarkslauncher.ui.BookmarkTileView;
import com.cmyk.bookmarkslauncher.ui.NDialog;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final int HOME_COLUMNS = 5;
    private static final int HOME_ROWS = 8;
    private static final int FOLDER_COLUMNS = 4;
    private static final int FOLDER_ROWS = 5;
    private static final int FOLDER_TITLE_HEIGHT_DP = 48;
    private static final Pattern URL_PATTERN = Pattern.compile("https?://\\S+", Pattern.CASE_INSENSITIVE);

    private static final int N_BG = 0xFF303030;
    private static final int N_DGRAY = 0xFF252020;
    private static final int N_LBLUE = 0xFF445577;
    private static final int N_ICON = 0xFFA9A999;
    private static final int N_TEXT = 0xFFFFFFFF;

    private BookmarkRepository repo;
    private FrameLayout root;
    private BookmarkBoardView homeBoard;
    private ImageView deleteFab;
    private BookmarkCaptureManager captureManager;
    private final List<FolderPanel> folderPanels = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(N_BG);
        getWindow().setNavigationBarColor(N_BG);
        repo = new BookmarkRepository(this);
        setContentView(buildUi());
        captureManager = new BookmarkCaptureManager(this, root, repo);
        handleIncoming(getIntent());
        refreshHome();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    @Override
    protected void onDestroy() {
        if (captureManager != null) captureManager.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (!folderPanels.isEmpty()) {
            closeTopPanel(false);
            return;
        }
        super.onBackPressed();
    }

    private View buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(N_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(N_BG);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18), dp(64), dp(18), dp(8));

        TextView title = new TextView(this);
        title.setText("BookmarkLauncher");
        title.setTextColor(N_TEXT);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        content.addView(top);

        homeBoard = new BookmarkBoardView(this, HOME_COLUMNS, HOME_ROWS);
        homeBoard.setContainerId(null);
        homeBoard.setPadding(0, 0, 0, dp(96));
        bindBoard(homeBoard, null);
        content.addView(homeBoard, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(content, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        deleteFab = makeDeleteFab();
        deleteFab.setVisibility(View.GONE);
        deleteFab.setOnDragListener(this::handleDeleteDrag);
        FrameLayout.LayoutParams deleteLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        deleteLp.setMargins(0, 0, 0, dp(48));
        root.addView(deleteFab, deleteLp);

        return root;
    }

    private void bindBoard(BookmarkBoardView board, String parentId) {
        board.setContainerId(parentId);
        board.setListener(new BookmarkBoardView.Listener() {
            @Override public void onOpen(BookmarkNode node, View anchor) {
                if (node.isFolder()) openFolderPanel(node, anchor);
                else openBookmark(node);
            }

            @Override public void onLongPress(BookmarkNode node, View anchor) {
                BookmarkNode fresh = repo.get(node.id);
                if (fresh == null || fresh.deletedAt != null) return;
                if (fresh.isFolder()) {
                    NDialog.showFolderDetails(MainActivity.this, fresh, repo.countChildren(fresh.id),
                            newName -> {
                                repo.renameDisplayName(fresh.id, newName);
                                refreshAllVisible();
                            },
                            protectContents -> deleteNode(fresh, protectContents));
                } else {
                    NDialog.showBookmarkDetails(MainActivity.this, fresh,
                            newName -> {
                                repo.renameDisplayName(fresh.id, newName);
                                refreshAllVisible();
                            },
                            callback -> captureBookmark(fresh, callback, true),
                            () -> deleteNode(fresh, true));
                }
            }

            @Override public void onPositionsChanged(List<BookmarkNode> nodes) {
                repo.updatePositions(parentId, nodes);
                refreshAllVisible();
            }

            @Override public void onExternalDrop(BookmarkNode dragged, int cellX, int cellY, List<BookmarkNode> residentNodes) {
                repo.updatePositions(parentId, residentNodes);
                if (!repo.moveToParentAtPosition(dragged.id, parentId, cellX, cellY)) {
                    Toast.makeText(MainActivity.this, "ここには移動できません", Toast.LENGTH_SHORT).show();
                }
                refreshAllVisible();
            }

            @Override public void onCreateFolder(BookmarkNode dragged, BookmarkNode target) {
                repo.createFolderFromNodes(parentId, dragged.id, target.id);
                refreshAllVisible();
            }

            @Override public void onMoveIntoFolder(BookmarkNode dragged, BookmarkNode folder, View folderAnchor) {
                if (!repo.moveToParent(dragged.id, folder.id)) {
                    Toast.makeText(MainActivity.this, "このフォルダには移動できません", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Dropping onto a folder opens that folder from the icon position. Nested folders use
                // the same path, so the interaction can continue level by level.
                openFolderPanel(folder, folderAnchor);
                refreshAllVisible();
            }

            @Override public void onDragExited(BookmarkNode dragged) {
                if (parentId != null) closeFolderForDrag(parentId);
            }

            @Override public void onDragStateChanged(boolean active, BookmarkNode node) {
                setDeleteTargetVisible(active);
            }
        });
    }

    private void refreshHome() {
        repo.ensurePositions(null, HOME_COLUMNS, HOME_ROWS);
        homeBoard.submit(repo.children(null));
    }

    private void openBookmark(BookmarkNode node) {
        if (node.url == null || node.url.isBlank()) return;
        repo.touchAccess(node.id);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(node.url)));
        } catch (Exception e) {
            Toast.makeText(this, "URLを開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private void openFolderPanel(BookmarkNode node, View anchor) {
        BookmarkNode fresh = repo.get(node.id);
        if (fresh == null || fresh.deletedAt != null) return;

        int depth = 0;
        if (fresh.parentId != null) {
            int parentIndex = findPanelIndex(fresh.parentId);
            if (parentIndex >= 0) depth = parentIndex + 1;
        }
        closePanelsFromDepth(depth, true);

        repo.ensurePositions(fresh.id, FOLDER_COLUMNS, FOLDER_ROWS);
        FolderPanel panel = createFolderPanel(fresh, anchor, depth);
        folderPanels.add(panel);
        root.addView(panel.backdrop, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(panel.view, panel.layoutParams);
        panel.view.bringToFront();
        if (deleteFab.getVisibility() == View.VISIBLE) deleteFab.bringToFront();
        updatePanelDimming();
        animateOpen(panel);
    }

    private FolderPanel createFolderPanel(BookmarkNode folder, View anchor, int depth) {
        FrameLayout panelView = new FrameLayout(this);
        panelView.setBackground(roundRect(N_DGRAY, 18));
        panelView.setElevation(0f);
        panelView.setClipChildren(false);

        BookmarkBoardView board = new BookmarkBoardView(this, FOLDER_COLUMNS, FOLDER_ROWS);
        board.setContainerId(folder.id);
        board.setPadding(dp(10), dp(FOLDER_TITLE_HEIGHT_DP + 8), dp(10), dp(10));
        bindBoard(board, folder.id);
        board.submit(repo.children(folder.id));
        panelView.addView(board, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText(folder.title);
        title.setTextColor(N_TEXT);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        FrameLayout.LayoutParams titleLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(FOLDER_TITLE_HEIGHT_DP), Gravity.TOP);
        titleLp.setMargins(dp(14), dp(6), dp(14), 0);
        panelView.addView(title, titleLp);

        int rootWidth = Math.max(root.getWidth(), getResources().getDisplayMetrics().widthPixels);
        int rootHeight = Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels);
        int width = Math.min(dp(360), rootWidth - dp(28));
        int height = Math.min(dp(520), rootHeight - dp(120));
        int left = Math.max(dp(14), (rootWidth - width) / 2);
        int baseTop = Math.max(dp(90), (rootHeight - height) / 2);
        int top = Math.min(rootHeight - height - dp(14), baseTop + depth * dp(FOLDER_TITLE_HEIGHT_DP));
        top = Math.max(dp(14), top);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, height);
        lp.leftMargin = left;
        lp.topMargin = top;

        float[] origin = centerInRoot(anchor);
        View backdrop = new View(this);
        backdrop.setBackgroundColor(Color.TRANSPARENT);
        backdrop.setClickable(true);
        backdrop.setOnClickListener(v -> {
            int index = findPanelIndex(folder.id);
            if (index == folderPanels.size() - 1) closeTopPanel(false);
        });

        FolderPanel panel = new FolderPanel(folder.id, depth, panelView, board, title, backdrop, lp, origin[0], origin[1]);
        configureFolderTitle(panel);
        return panel;
    }

    private void configureFolderTitle(FolderPanel panel) {
        final boolean[] pressed = {false};
        final boolean[] moving = {false};
        final boolean[] moved = {false};
        final float[] downRaw = new float[2];
        final int[] startPosition = new int[2];

        Runnable enterMoveMode = () -> {
            if (!pressed[0] || moved[0]) return;
            moving[0] = true;
            panel.title.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        };

        panel.title.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pressed[0] = true;
                    moving[0] = false;
                    moved[0] = false;
                    downRaw[0] = event.getRawX();
                    downRaw[1] = event.getRawY();
                    startPosition[0] = panel.layoutParams.leftMargin;
                    startPosition[1] = panel.layoutParams.topMargin;
                    v.postDelayed(enterMoveMode, 430L);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downRaw[0];
                    float dy = event.getRawY() - downRaw[1];
                    if (!moving[0] && dx * dx + dy * dy > dp(10) * dp(10)) {
                        moved[0] = true;
                        v.removeCallbacks(enterMoveMode);
                    }
                    if (moving[0]) {
                        moved[0] = true;
                        int rootW = Math.max(root.getWidth(), getResources().getDisplayMetrics().widthPixels);
                        int rootH = Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels);
                        int maxLeft = Math.max(dp(14), rootW - panel.layoutParams.width - dp(14));
                        int maxTop = Math.max(dp(14), rootH - panel.layoutParams.height - dp(14));
                        panel.layoutParams.leftMargin = clamp(startPosition[0] + Math.round(dx), dp(14), maxLeft);
                        panel.layoutParams.topMargin = clamp(startPosition[1] + Math.round(dy), dp(14), maxTop);
                        panel.view.setLayoutParams(panel.layoutParams);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    v.removeCallbacks(enterMoveMode);
                    boolean wasMoving = moving[0];
                    boolean wasMoved = moved[0];
                    pressed[0] = false;
                    moving[0] = false;
                    moved[0] = false;
                    if (!wasMoving && !wasMoved) renameFolder(panel.folderId);
                    return true;

                case MotionEvent.ACTION_CANCEL:
                    v.removeCallbacks(enterMoveMode);
                    pressed[0] = false;
                    moving[0] = false;
                    moved[0] = false;
                    return true;

                default:
                    return true;
            }
        });
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private void renameFolder(String folderId) {
        BookmarkNode folder = repo.get(folderId);
        if (folder == null || folder.deletedAt != null) return;
        NDialog.showInput(this, "フォルダ名", "フォルダ名", folder.title, false, "保存", text -> {
            if (text.isBlank()) return;
            repo.rename(folderId, text);
            refreshAllVisible();
        });
    }

    private void deleteNode(BookmarkNode node, boolean protectFolderContents) {
        BookmarkNode fresh = repo.get(node.id);
        if (fresh == null || fresh.deletedAt != null) return;
        if (fresh.isFolder()) {
            if (protectFolderContents) repo.deletePreservingFolderChildren(fresh.id);
            else repo.deleteRecursive(fresh.id);
            int index = findPanelIndex(fresh.id);
            if (index >= 0) closePanelsFromDepth(index, true);
        } else {
            repo.softDelete(fresh.id);
        }
        refreshAllVisible();
    }

    private boolean handleDeleteDrag(View v, DragEvent e) {
        if (!(e.getLocalState() instanceof BookmarkTileView)) return false;
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return true;
            case DragEvent.ACTION_DRAG_ENTERED:
                deleteFab.setScaleX(1.12f);
                deleteFab.setScaleY(1.12f);
                return true;
            case DragEvent.ACTION_DRAG_EXITED:
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                return true;
            case DragEvent.ACTION_DROP:
                BookmarkNode node = ((BookmarkTileView) e.getLocalState()).getNode();
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                BookmarkNode fresh = repo.get(node.id);
                // Drag-to-delete is deliberately safe: folders use the default protection behavior.
                if (fresh != null) deleteNode(fresh, true);
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                setDeleteTargetVisible(false);
                return true;
            default:
                return true;
        }
    }

    private void setDeleteTargetVisible(boolean visible) {
        deleteFab.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (visible) {
            deleteFab.setAlpha(0f);
            deleteFab.setScaleX(0.85f);
            deleteFab.setScaleY(0.85f);
            deleteFab.bringToFront();
            deleteFab.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(120).start();
        }
    }

    private void closeTopPanel(boolean fromDrag) {
        if (folderPanels.isEmpty()) return;
        FolderPanel top = folderPanels.remove(folderPanels.size() - 1);
        animateClose(top, fromDrag);
        updatePanelDimming();
    }

    private void closeFolderForDrag(String folderId) {
        int index = findPanelIndex(folderId);
        if (index < 0) return;
        for (int i = folderPanels.size() - 1; i >= index; i--) {
            FolderPanel panel = folderPanels.remove(i);
            animateClose(panel, true);
        }
        updatePanelDimming();
    }

    private void closePanelsFromDepth(int depth, boolean animate) {
        for (int i = folderPanels.size() - 1; i >= depth; i--) {
            FolderPanel panel = folderPanels.remove(i);
            if (animate) animateClose(panel, false);
            else {
                root.removeView(panel.view);
                root.removeView(panel.backdrop);
            }
        }
        updatePanelDimming();
    }

    private int findPanelIndex(String folderId) {
        for (int i = 0; i < folderPanels.size(); i++) {
            if (folderPanels.get(i).folderId.equals(folderId)) return i;
        }
        return -1;
    }

    private void updatePanelDimming() {
        int top = folderPanels.size() - 1;
        for (int i = 0; i < folderPanels.size(); i++) {
            FolderPanel panel = folderPanels.get(i);
            panel.view.animate().cancel();
            panel.view.setAlpha(i == top ? 1f : 0.68f);
        }
    }

    private void animateOpen(FolderPanel panel) {
        float targetCenterX = panel.layoutParams.leftMargin + panel.layoutParams.width / 2f;
        float targetCenterY = panel.layoutParams.topMargin + panel.layoutParams.height / 2f;
        panel.view.setPivotX(panel.layoutParams.width / 2f);
        panel.view.setPivotY(panel.layoutParams.height / 2f);
        panel.view.setScaleX(0.16f);
        panel.view.setScaleY(0.16f);
        panel.view.setTranslationX(panel.originX - targetCenterX);
        panel.view.setTranslationY(panel.originY - targetCenterY);
        panel.view.setAlpha(0.72f);
        panel.view.animate()
                .scaleX(1f).scaleY(1f)
                .translationX(0f).translationY(0f)
                .alpha(1f)
                .setInterpolator(new DecelerateInterpolator())
                .setDuration(190)
                .withEndAction(this::updatePanelDimming)
                .start();
    }

    private void animateClose(FolderPanel panel, boolean fromDrag) {
        float targetCenterX = panel.layoutParams.leftMargin + panel.layoutParams.width / 2f;
        float targetCenterY = panel.layoutParams.topMargin + panel.layoutParams.height / 2f;
        panel.view.animate().cancel();
        if (fromDrag) root.removeView(panel.backdrop);
        panel.view.animate()
                .scaleX(0.16f).scaleY(0.16f)
                .translationX(panel.originX - targetCenterX)
                .translationY(panel.originY - targetCenterY)
                .alpha(fromDrag ? 0.45f : 0.6f)
                .setDuration(fromDrag ? 130 : 170)
                .withEndAction(() -> {
                    root.removeView(panel.view);
                    root.removeView(panel.backdrop);
                    updatePanelDimming();
                })
                .start();
    }

    private float[] centerInRoot(View anchor) {
        if (anchor == null) {
            return new float[]{root.getWidth() / 2f, root.getHeight() / 2f};
        }
        int[] anchorLoc = new int[2];
        int[] rootLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);
        root.getLocationOnScreen(rootLoc);
        return new float[]{
                anchorLoc[0] - rootLoc[0] + anchor.getWidth() / 2f,
                anchorLoc[1] - rootLoc[1] + anchor.getHeight() / 2f
        };
    }

    private void showAddDialog(String parentId) {
        String[] items = {"URLを追加", "フォルダを追加"};
        NDialog.showChoices(this, "追加", items, -1, which -> {
            if (which == 0) showAddBookmark(parentId);
            else showAddFolder(parentId);
        });
    }

    private void showAddBookmark(String parentId) {
        NDialog.showInput(this, "ブックマーク追加", "https://example.com", "", true, "追加", text -> {
            String url = text;
            if (url.isEmpty()) return;
            if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
            BookmarkNode created = repo.createBookmark(parentId, url, url);
            refreshAllVisible();
            captureBookmark(created, null, false);
        });
    }

    private void showAddFolder(String parentId) {
        NDialog.showInput(this, "フォルダ追加", "フォルダ名", "", false, "追加", text -> {
            repo.createFolder(parentId, text);
            refreshAllVisible();
        });
    }

    private void handleIncoming(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if (text == null) return;
        Matcher m = URL_PATTERN.matcher(text);
        if (m.find()) {
            String url = m.group();
            BookmarkNode created = repo.createBookmark(null, url, url);
            refreshHome();
            Toast.makeText(this, "ブックマークに追加しました", Toast.LENGTH_SHORT).show();
            captureBookmark(created, null, false);
        }
    }

    private void captureBookmark(BookmarkNode node, NDialog.ThumbnailRefreshCallback callback, boolean showFailureToast) {
        if (captureManager == null || node == null) {
            if (callback != null) callback.onComplete(null, false);
            return;
        }
        captureManager.capture(node, (success, updatedNode, message) -> {
            refreshAllVisible();
            String screenshot = updatedNode == null ? null : updatedNode.screenshotPath;
            if (callback != null) callback.onComplete(screenshot, success);
            if (!success && showFailureToast) {
                Toast.makeText(MainActivity.this, message == null ? "サムネイル取得に失敗しました" : message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void refreshAllVisible() {
        refreshHome();

        for (int i = folderPanels.size() - 1; i >= 0; i--) {
            FolderPanel panel = folderPanels.get(i);
            BookmarkNode folder = repo.get(panel.folderId);
            if (folder == null || folder.deletedAt != null) {
                folderPanels.remove(i);
                root.removeView(panel.view);
                root.removeView(panel.backdrop);
            }
        }

        List<FolderPanel> copy = new ArrayList<>(folderPanels);
        for (FolderPanel panel : copy) {
            BookmarkNode folder = repo.get(panel.folderId);
            if (folder == null || folder.deletedAt != null) continue;
            panel.title.setText(folder.title);
            repo.ensurePositions(panel.folderId, FOLDER_COLUMNS, FOLDER_ROWS);
            panel.board.submit(repo.children(panel.folderId));
        }
        updatePanelDimming();
    }

    private ImageView makeDeleteFab() {
        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.ic_close_vector);
        image.setScaleType(ImageView.ScaleType.CENTER);
        image.setContentDescription("削除");
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(Color.BLACK);
        d.setSize(dp(58), dp(58));
        image.setBackground(d);
        image.setElevation(0f);
        return image;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class FolderPanel {
        final String folderId;
        final int depth;
        final FrameLayout view;
        final BookmarkBoardView board;
        final TextView title;
        final View backdrop;
        final FrameLayout.LayoutParams layoutParams;
        final float originX;
        final float originY;

        FolderPanel(String folderId, int depth, FrameLayout view, BookmarkBoardView board, TextView title,
                    View backdrop, FrameLayout.LayoutParams layoutParams, float originX, float originY) {
            this.folderId = folderId;
            this.depth = depth;
            this.view = view;
            this.board = board;
            this.title = title;
            this.backdrop = backdrop;
            this.layoutParams = layoutParams;
            this.originX = originX;
            this.originY = originY;
        }
    }
}
