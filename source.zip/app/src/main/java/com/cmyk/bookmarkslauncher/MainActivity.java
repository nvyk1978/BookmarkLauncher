package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;
import com.cmyk.bookmarkslauncher.ui.BookmarkBoardView;
import com.cmyk.bookmarkslauncher.ui.BookmarkTileView;
import com.cmyk.bookmarkslauncher.ui.NDialog;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final int HOME_COLUMNS = 5;
    private static final int HOME_ROWS = 8;
    private static final int FOLDER_COLUMNS = 4;
    private static final int FOLDER_ROWS = 5;
    private static final int FOLDER_TITLE_HEIGHT_DP = 48;
    private static final Pattern URL_PATTERN = Pattern.compile("https?://\\S+", Pattern.CASE_INSENSITIVE);

    private static final int N_BG = 0xFF303030;
    private static final int N_DGRAY = 0xFF252020;
    private static final int N_GRAY = 0xFF454040;
    private static final int N_LBLUE = 0xFF445577;
    private static final int N_RED = 0xFF441100;
    private static final int N_ICON = 0xFFA9A999;
    private static final int N_TEXT = 0xFFFFFFFF;

    private BookmarkRepository repo;
    private FrameLayout root;
    private BookmarkBoardView homeBoard;
    private TextView addFab;
    private ImageView deleteFab;
    private final List<FolderPanel> folderPanels = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(N_BG);
        getWindow().setNavigationBarColor(N_BG);
        repo = new BookmarkRepository(this);
        setContentView(buildUi());
        handleIncoming(getIntent());
        refreshHome();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    @Override
    public void onBackPressed() {
        if (!folderPanels.isEmpty()) {
            FolderPanel top = folderPanels.remove(folderPanels.size() - 1);
            animateClose(top, false);
            return;
        }
        super.onBackPressed();
    }

    private View buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(N_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(N_BG);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        // Title block moved 50dp down from the original position.
        top.setPadding(dp(18), dp(64), dp(18), dp(8));

        TextView title = new TextView(this);
        title.setText("BookmarkLauncher");
        title.setTextColor(N_TEXT);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        content.addView(top);

        homeBoard = new BookmarkBoardView(this, HOME_COLUMNS, HOME_ROWS);
        homeBoard.setContainerId(null);
        homeBoard.setPadding(0, 0, 0, dp(96));
        bindBoard(homeBoard, null);
        content.addView(homeBoard, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(content, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        addFab = makeFab("＋");
        addFab.setContentDescription("追加");
        addFab.setOnClickListener(v -> showAddDialog(null));
        FrameLayout.LayoutParams addLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END | Gravity.BOTTOM);
        addLp.setMargins(0, 0, dp(48), dp(48));
        root.addView(addFab, addLp);

        deleteFab = makeDeleteFab();
        deleteFab.setVisibility(View.GONE);
        deleteFab.setOnDragListener(this::handleDeleteDrag);
        FrameLayout.LayoutParams deleteLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.START | Gravity.BOTTOM);
        deleteLp.setMargins(dp(48), 0, 0, dp(48));
        root.addView(deleteFab, deleteLp);

        return root;
    }

    private void bindBoard(BookmarkBoardView board, String parentId) {
        board.setContainerId(parentId);
        board.setListener(new BookmarkBoardView.Listener() {
            @Override public void onOpen(BookmarkNode node, View anchor) {
                if (node.isFolder()) openFolderPanel(node, anchor);
                else openBookmark(node);
            }

            @Override public void onLongPress(BookmarkNode node, View anchor) {
                if (node.isFolder()) showFolderMenu(node);
                else {
                    BookmarkNode fresh = repo.get(node.id);
                    if (fresh != null) NDialog.showBookmarkDetails(MainActivity.this, fresh);
                }
            }

            @Override public void onPositionsChanged(List<BookmarkNode> nodes) {
                repo.updatePositions(parentId, nodes);
                refreshAllVisible();
            }

            @Override public void onExternalDrop(BookmarkNode dragged, int cellX, int cellY, List<BookmarkNode> residentNodes) {
                repo.updatePositions(parentId, residentNodes);
                if (!repo.moveToParentAtPosition(dragged.id, parentId, cellX, cellY)) {
                    Toast.makeText(MainActivity.this, "ここには移動できません", Toast.LENGTH_SHORT).show();
                }
                refreshAllVisible();
            }

            @Override public void onCreateFolder(BookmarkNode dragged, BookmarkNode target) {
                repo.createFolderFromNodes(parentId, dragged.id, target.id);
                refreshAllVisible();
            }

            @Override public void onMoveIntoFolder(BookmarkNode dragged, BookmarkNode folder) {
                if (!repo.moveToParent(dragged.id, folder.id)) {
                    Toast.makeText(MainActivity.this, "このフォルダには移動できません", Toast.LENGTH_SHORT).show();
                }
                refreshAllVisible();
            }

            @Override public void onDragExited(BookmarkNode dragged) {
                if (parentId != null) closeFolderForDrag(parentId);
            }

            @Override public void onDragStateChanged(boolean active, BookmarkNode node) {
                setDeleteTargetVisible(active);
            }
        });
    }

    private void refreshHome() {
        repo.ensurePositions(null, HOME_COLUMNS, HOME_ROWS);
        homeBoard.submit(repo.children(null));
    }

    private void openBookmark(BookmarkNode node) {
        if (node.url == null || node.url.isBlank()) return;
        repo.touchAccess(node.id);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(node.url)));
        } catch (Exception e) {
            Toast.makeText(this, "URLを開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private void openFolderPanel(BookmarkNode node, View anchor) {
        int depth = 0;
        if (node.parentId != null) {
            int parentIndex = findPanelIndex(node.parentId);
            if (parentIndex >= 0) depth = parentIndex + 1;
        }
        closePanelsFromDepth(depth, true);

        repo.ensurePositions(node.id, FOLDER_COLUMNS, FOLDER_ROWS);
        FolderPanel panel = createFolderPanel(node, anchor, depth);
        folderPanels.add(panel);
        root.addView(panel.view, panel.layoutParams);
        panel.view.bringToFront();
        addFab.bringToFront();
        if (deleteFab.getVisibility() == View.VISIBLE) deleteFab.bringToFront();
        animateOpen(panel);
    }

    private FolderPanel createFolderPanel(BookmarkNode folder, View anchor, int depth) {
        FrameLayout panelView = new FrameLayout(this);
        panelView.setBackground(roundRect(N_DGRAY, 18));
        panelView.setElevation(0f);
        panelView.setClipChildren(false);

        BookmarkBoardView board = new BookmarkBoardView(this, FOLDER_COLUMNS, FOLDER_ROWS);
        board.setContainerId(folder.id);
        board.setPadding(dp(10), dp(FOLDER_TITLE_HEIGHT_DP + 8), dp(10), dp(10));
        bindBoard(board, folder.id);
        board.submit(repo.children(folder.id));
        panelView.addView(board, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText(folder.title);
        title.setTextColor(N_TEXT);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        title.setOnClickListener(v -> renameFolder(folder.id));
        FrameLayout.LayoutParams titleLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(FOLDER_TITLE_HEIGHT_DP), Gravity.TOP);
        titleLp.setMargins(dp(14), dp(6), dp(14), 0);
        panelView.addView(title, titleLp);

        int rootWidth = Math.max(root.getWidth(), getResources().getDisplayMetrics().widthPixels);
        int rootHeight = Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels);
        int width = Math.min(dp(360), rootWidth - dp(28));
        int height = Math.min(dp(520), rootHeight - dp(120));
        int left = Math.max(dp(14), (rootWidth - width) / 2);
        int baseTop = Math.max(dp(90), (rootHeight - height) / 2);
        int top = Math.min(rootHeight - height - dp(14), baseTop + depth * dp(FOLDER_TITLE_HEIGHT_DP));
        top = Math.max(dp(14), top);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, height);
        lp.leftMargin = left;
        lp.topMargin = top;

        float[] origin = centerInRoot(anchor);
        return new FolderPanel(folder.id, depth, panelView, board, title, lp, origin[0], origin[1]);
    }

    private void renameFolder(String folderId) {
        BookmarkNode folder = repo.get(folderId);
        if (folder == null) return;
        NDialog.showInput(this, "フォルダ名", "フォルダ名", folder.title, false, "保存", text -> {
            if (text.isBlank()) return;
            repo.rename(folderId, text);
            refreshAllVisible();
        });
    }

    private void showFolderMenu(BookmarkNode node) {
        NDialog.showChoices(this, node.title, new String[]{"削除"}, 0, which -> deleteNode(node));
    }

    private void deleteNode(BookmarkNode node) {
        repo.deletePreservingFolderChildren(node.id);
        if (node.isFolder()) {
            int index = findPanelIndex(node.id);
            if (index >= 0) closePanelsFromDepth(index, true);
        }
        refreshAllVisible();
    }

    private boolean handleDeleteDrag(View v, DragEvent e) {
        if (!(e.getLocalState() instanceof BookmarkTileView)) return false;
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return true;
            case DragEvent.ACTION_DRAG_ENTERED:
                deleteFab.setScaleX(1.12f);
                deleteFab.setScaleY(1.12f);
                return true;
            case DragEvent.ACTION_DRAG_EXITED:
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                return true;
            case DragEvent.ACTION_DROP:
                BookmarkNode node = ((BookmarkTileView) e.getLocalState()).getNode();
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                BookmarkNode fresh = repo.get(node.id);
                if (fresh != null) deleteNode(fresh);
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                setDeleteTargetVisible(false);
                return true;
            default:
                return true;
        }
    }

    private void setDeleteTargetVisible(boolean visible) {
        deleteFab.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (visible) {
            deleteFab.setAlpha(0f);
            deleteFab.setScaleX(0.85f);
            deleteFab.setScaleY(0.85f);
            deleteFab.bringToFront();
            deleteFab.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(120).start();
        }
    }

    private void closeFolderForDrag(String folderId) {
        int index = findPanelIndex(folderId);
        if (index < 0) return;
        for (int i = folderPanels.size() - 1; i >= index; i--) {
            FolderPanel panel = folderPanels.remove(i);
            animateClose(panel, true);
        }
    }

    private void closePanelsFromDepth(int depth, boolean animate) {
        for (int i = folderPanels.size() - 1; i >= depth; i--) {
            FolderPanel panel = folderPanels.remove(i);
            if (animate) animateClose(panel, false);
            else root.removeView(panel.view);
        }
    }

    private int findPanelIndex(String folderId) {
        for (int i = 0; i < folderPanels.size(); i++) {
            if (folderPanels.get(i).folderId.equals(folderId)) return i;
        }
        return -1;
    }

    private void animateOpen(FolderPanel panel) {
        float targetCenterX = panel.layoutParams.leftMargin + panel.layoutParams.width / 2f;
        float targetCenterY = panel.layoutParams.topMargin + panel.layoutParams.height / 2f;
        panel.view.setPivotX(panel.layoutParams.width / 2f);
        panel.view.setPivotY(panel.layoutParams.height / 2f);
        panel.view.setScaleX(0.16f);
        panel.view.setScaleY(0.16f);
        panel.view.setTranslationX(panel.originX - targetCenterX);
        panel.view.setTranslationY(panel.originY - targetCenterY);
        panel.view.setAlpha(0.72f);
        panel.view.animate()
                .scaleX(1f).scaleY(1f)
                .translationX(0f).translationY(0f)
                .alpha(1f)
                .setInterpolator(new DecelerateInterpolator())
                .setDuration(190)
                .start();
    }

    private void animateClose(FolderPanel panel, boolean fromDrag) {
        float targetCenterX = panel.layoutParams.leftMargin + panel.layoutParams.width / 2f;
        float targetCenterY = panel.layoutParams.topMargin + panel.layoutParams.height / 2f;
        panel.view.animate().cancel();
        panel.view.animate()
                .scaleX(0.16f).scaleY(0.16f)
                .translationX(panel.originX - targetCenterX)
                .translationY(panel.originY - targetCenterY)
                .alpha(fromDrag ? 0.45f : 0.6f)
                .setDuration(fromDrag ? 130 : 170)
                .withEndAction(() -> root.removeView(panel.view))
                .start();
    }

    private float[] centerInRoot(View anchor) {
        int[] anchorLoc = new int[2];
        int[] rootLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);
        root.getLocationOnScreen(rootLoc);
        return new float[]{
                anchorLoc[0] - rootLoc[0] + anchor.getWidth() / 2f,
                anchorLoc[1] - rootLoc[1] + anchor.getHeight() / 2f
        };
    }

    private void showAddDialog(String parentId) {
        String[] items = {"URLを追加", "フォルダを追加"};
        NDialog.showChoices(this, "追加", items, -1, which -> {
            if (which == 0) showAddBookmark(parentId);
            else showAddFolder(parentId);
        });
    }

    private void showAddBookmark(String parentId) {
        NDialog.showInput(this, "ブックマーク追加", "https://example.com", "", true, "追加", text -> {
            String url = text;
            if (url.isEmpty()) return;
            if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
            repo.createBookmark(parentId, url, url);
            refreshAllVisible();
        });
    }

    private void showAddFolder(String parentId) {
        NDialog.showInput(this, "フォルダ追加", "フォルダ名", "", false, "追加", text -> {
            repo.createFolder(parentId, text);
            refreshAllVisible();
        });
    }

    private void handleIncoming(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if (text == null) return;
        Matcher m = URL_PATTERN.matcher(text);
        if (m.find()) {
            String url = m.group();
            repo.createBookmark(null, url, url);
            refreshHome();
            Toast.makeText(this, "ブックマークに追加しました", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshAllVisible() {
        refreshHome();
        List<FolderPanel> copy = new ArrayList<>(folderPanels);
        for (FolderPanel panel : copy) {
            BookmarkNode folder = repo.get(panel.folderId);
            if (folder == null || folder.deletedAt != null) continue;
            panel.title.setText(folder.title);
            repo.ensurePositions(panel.folderId, FOLDER_COLUMNS, FOLDER_ROWS);
            panel.board.submit(repo.children(panel.folderId));
        }
    }

    private TextView makeFab(String text) {
        TextView tv = makeRoundIcon(text, N_LBLUE, dp(58));
        tv.setTextSize(28);
        tv.setElevation(0f);
        return tv;
    }

    private ImageView makeDeleteFab() {
        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.ic_close_vector);
        image.setScaleType(ImageView.ScaleType.CENTER);
        image.setContentDescription("削除");
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(Color.BLACK);
        d.setSize(dp(58), dp(58));
        image.setBackground(d);
        image.setElevation(0f);
        return image;
    }

    private TextView makeRoundIcon(String text, int color, int size) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(N_ICON);
        tv.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        d.setSize(size, size);
        tv.setBackground(d);
        return tv;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class FolderPanel {
        final String folderId;
        final int depth;
        final FrameLayout view;
        final BookmarkBoardView board;
        final TextView title;
        final FrameLayout.LayoutParams layoutParams;
        final float originX;
        final float originY;

        FolderPanel(String folderId, int depth, FrameLayout view, BookmarkBoardView board, TextView title,
                    FrameLayout.LayoutParams layoutParams, float originX, float originY) {
            this.folderId = folderId;
            this.depth = depth;
            this.view = view;
            this.board = board;
            this.title = title;
            this.layoutParams = layoutParams;
            this.originX = originX;
            this.originY = originY;
        }
    }
}
