package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;
import com.cmyk.bookmarkslauncher.ui.BookmarkBoardView;
import com.cmyk.bookmarkslauncher.ui.BookmarkTileView;
import com.cmyk.bookmarkslauncher.ui.NDialog;
import com.cmyk.bookmarkslauncher.ui.SearchWidgetView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final int HOME_COLUMNS = 5;
    private static final int HOME_ROWS = 8;
    private static final int FOLDER_COLUMNS = 4;
    private static final int FOLDER_ROWS = 5;
    private static final int FOLDER_TITLE_HEIGHT_DP = 48;
    private static final Pattern URL_PATTERN = Pattern.compile("https?://\\S+", Pattern.CASE_INSENSITIVE);

    private static final int N_BG = 0xFF303030;
    private static final int N_DGRAY = 0xFF252020;
    // Folder surfaces are always opaque. When multiple folder panels are stacked, older
    // panels are darkened with solid colors to imitate alpha stacking without allowing the
    // panels to visually melt into one another.
    private static final int N_FOLDER_BG = 0xFF252020;
    private static final float FOLDER_STACK_DARKEN = 0.18f;

    private static final String PREFS = "bookmarklauncher_ui";
    private static final String KEY_SEARCH_CONFIGURED = "search_configured";
    private static final String KEY_SEARCH_ENABLED = "search_enabled";
    private static final String KEY_SEARCH_CELL_Y = "search_cell_y";
    private static final int N_LBLUE = 0xFF445577;
    private static final int N_ICON = 0xFFA9A999;
    private static final int N_TEXT = 0xFFFFFFFF;

    private BookmarkRepository repo;
    private SharedPreferences prefs;
    private FrameLayout root;
    private BookmarkBoardView homeBoard;
    private ImageView deleteFab;
    private BookmarkCaptureManager captureManager;
    private final List<FolderPanel> folderPanels = new ArrayList<>();
    private final Set<String> dragOpenedPanels = new HashSet<>();
    private final Set<String> dragEnteredPanels = new HashSet<>();
    private BookmarkTileView activeDragTile;
    private BookmarkTileView rootHoverFolderTarget;
    private float lastDragScreenX = Float.NaN;
    private float lastDragScreenY = Float.NaN;
    private final Runnable rootFolderOpenRunnable = () -> {
        BookmarkTileView target = rootHoverFolderTarget;
        if (target == null || activeDragTile == null) return;
        BookmarkNode folder = target.getNode();
        if (folder == null || !folder.isFolder() || folder.id.equals(activeDragTile.getNode().id)) return;
        openFolderPanel(folder, target);
        markDragOpenedPanel(folder.id);
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(N_BG);
        getWindow().setNavigationBarColor(N_BG);
        repo = new BookmarkRepository(this);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.contains(KEY_SEARCH_CONFIGURED)) {
            prefs.edit()
                    .putBoolean(KEY_SEARCH_CONFIGURED, true)
                    .putBoolean(KEY_SEARCH_ENABLED, true)
                    .putInt(KEY_SEARCH_CELL_Y, 0)
                    .apply();
        }
        setContentView(buildUi());
        captureManager = new BookmarkCaptureManager(this, root, repo);
        handleIncoming(getIntent());
        refreshHome();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    @Override
    protected void onDestroy() {
        if (captureManager != null) captureManager.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (!folderPanels.isEmpty()) {
            closeTopPanel(false);
            return;
        }
        super.onBackPressed();
    }

    private View buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(N_BG);
        root.setOnDragListener(this::handleRootDrag);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(N_BG);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18), dp(64), dp(18), dp(8));

        TextView title = new TextView(this);
        title.setText("BookmarkLauncher");
        title.setTextColor(N_TEXT);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        content.addView(top);

        homeBoard = new BookmarkBoardView(this, HOME_COLUMNS, HOME_ROWS);
        homeBoard.setContainerId(null);
        homeBoard.setPadding(0, 0, 0, dp(96));
        bindBoard(homeBoard, null);
        content.addView(homeBoard, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(content, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        deleteFab = makeDeleteFab();
        deleteFab.setVisibility(View.GONE);
        deleteFab.setOnDragListener(this::handleDeleteDrag);
        FrameLayout.LayoutParams deleteLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        deleteLp.setMargins(0, 0, 0, dp(48));
        root.addView(deleteFab, deleteLp);

        return root;
    }

    private void bindBoard(BookmarkBoardView board, String parentId) {
        board.setContainerId(parentId);
        board.setListener(new BookmarkBoardView.Listener() {
            @Override public void onOpen(BookmarkNode node, View anchor) {
                if (node.isFolder()) openFolderPanel(node, anchor);
                else openBookmark(node);
            }

            @Override public void onLongPress(BookmarkNode node, View anchor) {
                BookmarkNode fresh = repo.get(node.id);
                if (fresh == null || fresh.deletedAt != null) return;
                if (fresh.isFolder()) {
                    NDialog.showFolderDetails(MainActivity.this, fresh, repo.countChildren(fresh.id),
                            newName -> {
                                repo.renameDisplayName(fresh.id, newName);
                                refreshAllVisible();
                            },
                            protectContents -> deleteNode(fresh, protectContents));
                } else {
                    NDialog.showBookmarkDetails(MainActivity.this, fresh,
                            newName -> {
                                repo.renameDisplayName(fresh.id, newName);
                                refreshAllVisible();
                            },
                            callback -> captureBookmark(fresh, callback, true),
                            () -> deleteNode(fresh, true));
                }
            }

            @Override public void onPositionsChanged(List<BookmarkNode> nodes) {
                repo.updatePositions(parentId, nodes);
                refreshAllVisible();
            }

            @Override public void onExternalDrop(BookmarkNode dragged, int cellX, int cellY, List<BookmarkNode> residentNodes) {
                repo.updatePositions(parentId, residentNodes);
                if (!repo.moveToParentAtPosition(dragged.id, parentId, cellX, cellY)) {
                    Toast.makeText(MainActivity.this, "ここには移動できません", Toast.LENGTH_SHORT).show();
                }
                refreshAllVisible();
            }

            @Override public void onCreateFolder(BookmarkNode dragged, BookmarkNode target) {
                BookmarkNode freshDragged = repo.get(dragged.id);
                BookmarkNode freshTarget = repo.get(target.id);
                if (freshDragged == null || freshTarget == null) return;
                if (!sameParentId(parentId, freshDragged.parentId) || !sameParentId(parentId, freshTarget.parentId)) return;
                repo.createFolderFromNodes(parentId, dragged.id, target.id);
                refreshAllVisible();
            }

            @Override public void onMoveIntoFolder(BookmarkNode dragged, BookmarkNode folder, View folderAnchor) {
                BookmarkNode freshDragged = repo.get(dragged.id);
                if (freshDragged == null) return;
                if (folder.id.equals(freshDragged.parentId)) {
                    openFolderPanel(folder, folderAnchor);
                    return;
                }
                if (!repo.moveToParent(dragged.id, folder.id)) {
                    Toast.makeText(MainActivity.this, "このフォルダには移動できません", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Dropping onto a folder opens that folder from the icon position. Nested folders use
                // the same path, so the interaction can continue level by level.
                openFolderPanel(folder, folderAnchor);
                refreshAllVisible();
            }

            @Override public void onHoverOpenFolder(BookmarkNode dragged, BookmarkNode folder, View folderAnchor) {
                // Spring-loaded folder opening: hover opens the folder without moving data yet.
                // The actual parent change is committed only on drop.
                if (dragged == null || folder == null || dragged.id.equals(folder.id)) return;
                openFolderPanel(folder, folderAnchor);
                if (activeDragTile != null) markDragOpenedPanel(folder.id);
            }

            @Override public void onDragExited(BookmarkNode dragged) {
                // Folder panel boundary handling is centralized at the root so panels created
                // mid-drag do not get closed just because a new child panel appeared.
            }

            @Override public void onEmptyLongPress(int cellX, int cellY) {
                if (parentId != null) return;
                showHomeEmptyMenu(cellY);
            }

            @Override public void onSearchWidgetMoved(int cellY) {
                if (parentId != null) return;
                prefs.edit().putBoolean(KEY_SEARCH_ENABLED, true).putInt(KEY_SEARCH_CELL_Y, cellY).apply();
                refreshHome();
            }

            @Override public void onSearchQuery(String query) {
                if (parentId == null) showSearchResults(query);
            }

            @Override public void onDragStateChanged(boolean active, BookmarkNode node) {
                setDeleteTargetVisible(active);
            }

            @Override public List<BookmarkNode> onFolderPreview(BookmarkNode folder) {
                List<BookmarkNode> children = repo.children(folder.id);
                if (children.size() <= 4) return children;
                return new ArrayList<>(children.subList(0, 4));
            }
        });
    }

    private static boolean sameParentId(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    private void refreshHome() {
        boolean searchEnabled = isSearchEnabled();
        int searchY = getSearchCellY();
        homeBoard.setSearchWidget(searchEnabled, searchY);
        repo.ensurePositions(null, HOME_COLUMNS, HOME_ROWS, searchEnabled ? searchY : -1);
        homeBoard.submit(repo.children(null));
    }

    private boolean isSearchEnabled() {
        return prefs != null && prefs.getBoolean(KEY_SEARCH_ENABLED, true);
    }

    private int getSearchCellY() {
        return Math.max(0, Math.min(HOME_ROWS - 1, prefs == null ? 0 : prefs.getInt(KEY_SEARCH_CELL_Y, 0)));
    }

    private void showHomeEmptyMenu(int requestedRow) {
        if (isSearchEnabled()) {
            Toast.makeText(this, "検索窓はすでにあります", Toast.LENGTH_SHORT).show();
            return;
        }
        NDialog.showChoices(this, "追加", new String[]{"検索窓を追加"}, -1, which -> {
            if (which != 0) return;
            int row = Math.max(0, Math.min(HOME_ROWS - 1, requestedRow));
            prefs.edit().putBoolean(KEY_SEARCH_ENABLED, true).putInt(KEY_SEARCH_CELL_Y, row).apply();
            refreshHome();
        });
    }

    private void showSearchResults(String query) {
        List<BookmarkNode> results = repo.search(query);
        if (results.isEmpty()) {
            Toast.makeText(this, "見つかりませんでした", Toast.LENGTH_SHORT).show();
            return;
        }
        int count = Math.min(30, results.size());
        String[] labels = new String[count];
        for (int i = 0; i < count; i++) {
            BookmarkNode n = results.get(i);
            labels[i] = n.isFolder() ? "▣ " + n.displayName() : n.displayName();
        }
        NDialog.showChoices(this, "検索結果", labels, -1, which -> {
            if (which < 0 || which >= count) return;
            BookmarkNode n = results.get(which);
            if (n.isFolder()) openFolderPanel(n, null); else openBookmark(n);
        });
    }

    private void openBookmark(BookmarkNode node) {
        if (node.url == null || node.url.isBlank()) return;
        repo.touchAccess(node.id);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(node.url)));
        } catch (Exception e) {
            Toast.makeText(this, "URLを開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private void openFolderPanel(BookmarkNode node, View anchor) {
        BookmarkNode fresh = repo.get(node.id);
        if (fresh == null || fresh.deletedAt != null) return;
        if (findPanelIndex(fresh.id) >= 0) return;

        int depth = 0;
        if (fresh.parentId != null) {
            int parentIndex = findPanelIndex(fresh.parentId);
            if (parentIndex >= 0) depth = parentIndex + 1;
        }
        closePanelsFromDepth(depth, true);

        repo.ensurePositions(fresh.id, FOLDER_COLUMNS, FOLDER_ROWS);
        FolderPanel panel = createFolderPanel(fresh, anchor, depth);
        folderPanels.add(panel);
        root.addView(panel.backdrop, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(panel.view, panel.layoutParams);
        panel.view.bringToFront();
        if (deleteFab.getVisibility() == View.VISIBLE) deleteFab.bringToFront();
        updatePanelDimming();
        animateOpen(panel);
    }

    private FolderPanel createFolderPanel(BookmarkNode folder, View anchor, int depth) {
        FrameLayout panelView = new FrameLayout(this);
        panelView.setBackground(roundRect(N_FOLDER_BG, 18));
        panelView.setElevation(0f);
        panelView.setClipChildren(false);
        // Consume taps inside the folder surface. Only the transparent backdrop is allowed
        // to close the panel, so blank areas inside a folder never collapse it.
        panelView.setClickable(true);
        panelView.setOnClickListener(v -> { });

        BookmarkBoardView board = new BookmarkBoardView(this, FOLDER_COLUMNS, FOLDER_ROWS);
        board.setContainerId(folder.id);
        board.setPadding(dp(10), dp(FOLDER_TITLE_HEIGHT_DP + 8), dp(10), dp(10));
        bindBoard(board, folder.id);
        board.submit(repo.children(folder.id));
        panelView.addView(board, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText(folder.title);
        title.setTextColor(N_TEXT);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        FrameLayout.LayoutParams titleLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(FOLDER_TITLE_HEIGHT_DP), Gravity.TOP);
        titleLp.setMargins(dp(14), dp(6), dp(14), 0);
        panelView.addView(title, titleLp);

        int rootWidth = Math.max(root.getWidth(), getResources().getDisplayMetrics().widthPixels);
        int rootHeight = Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels);

        // Folder contents use the exact same cell metrics as the home workspace.
        // The folder stays 4 columns, but its panel is sized around the home 5-column
        // cell rather than shrinking/enlarging the icon and label component.
        int homeCellW = homeBoard.getCellWidthPx();
        int homeCellH = homeBoard.getCellHeightPx();
        int gap = Math.max(dp(6), homeBoard.getGapPx());
        if (homeCellW <= 0) {
            homeCellW = Math.max(dp(48), (rootWidth - gap * (HOME_COLUMNS + 1)) / HOME_COLUMNS);
        }
        if (homeCellH <= 0) homeCellH = homeCellW;

        int boardHorizontalPadding = dp(20); // 10dp each side
        int boardVerticalPadding = dp(FOLDER_TITLE_HEIGHT_DP + 8) + dp(10);
        int desiredWidth = boardHorizontalPadding + gap * (FOLDER_COLUMNS + 1) + homeCellW * FOLDER_COLUMNS;
        int desiredHeight = boardVerticalPadding + gap * (FOLDER_ROWS + 1) + homeCellH * FOLDER_ROWS;
        int width = Math.min(desiredWidth, rootWidth - dp(28));
        int height = Math.min(desiredHeight, rootHeight - dp(120));
        int left = Math.max(dp(14), (rootWidth - width) / 2);
        int baseTop = Math.max(dp(90), (rootHeight - height) / 2);
        int top = Math.min(rootHeight - height - dp(14), baseTop + depth * dp(FOLDER_TITLE_HEIGHT_DP));
        top = Math.max(dp(14), top);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, height);
        lp.leftMargin = left;
        lp.topMargin = top;

        float[] origin = centerInRoot(anchor);
        View backdrop = new View(this);
        backdrop.setBackgroundColor(Color.TRANSPARENT);
        backdrop.setClickable(true);
        backdrop.setOnClickListener(v -> {
            int index = findPanelIndex(folder.id);
            if (index == folderPanels.size() - 1) closeTopPanel(false);
        });

        FolderPanel panel = new FolderPanel(folder.id, depth, panelView, board, title, backdrop, lp, origin[0], origin[1]);
        configureFolderTitle(panel);
        return panel;
    }

    private void configureFolderTitle(FolderPanel panel) {
        final boolean[] pressed = {false};
        final boolean[] moving = {false};
        final boolean[] moved = {false};
        final float[] downRaw = new float[2];
        final int[] startPosition = new int[2];

        Runnable enterMoveMode = () -> {
            if (!pressed[0] || moved[0]) return;
            moving[0] = true;
            panel.title.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        };

        panel.title.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pressed[0] = true;
                    moving[0] = false;
                    moved[0] = false;
                    downRaw[0] = event.getRawX();
                    downRaw[1] = event.getRawY();
                    startPosition[0] = panel.layoutParams.leftMargin;
                    startPosition[1] = panel.layoutParams.topMargin;
                    v.postDelayed(enterMoveMode, 430L);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downRaw[0];
                    float dy = event.getRawY() - downRaw[1];
                    if (!moving[0] && dx * dx + dy * dy > dp(10) * dp(10)) {
                        moved[0] = true;
                        v.removeCallbacks(enterMoveMode);
                    }
                    if (moving[0]) {
                        moved[0] = true;
                        int rootW = Math.max(root.getWidth(), getResources().getDisplayMetrics().widthPixels);
                        int rootH = Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels);
                        int maxLeft = Math.max(dp(14), rootW - panel.layoutParams.width - dp(14));
                        int maxTop = Math.max(dp(14), rootH - panel.layoutParams.height - dp(14));
                        panel.layoutParams.leftMargin = clamp(startPosition[0] + Math.round(dx), dp(14), maxLeft);
                        panel.layoutParams.topMargin = clamp(startPosition[1] + Math.round(dy), dp(14), maxTop);
                        panel.view.setLayoutParams(panel.layoutParams);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    v.removeCallbacks(enterMoveMode);
                    boolean wasMoving = moving[0];
                    boolean wasMoved = moved[0];
                    pressed[0] = false;
                    moving[0] = false;
                    moved[0] = false;
                    if (!wasMoving && !wasMoved) renameFolder(panel.folderId);
                    return true;

                case MotionEvent.ACTION_CANCEL:
                    v.removeCallbacks(enterMoveMode);
                    pressed[0] = false;
                    moving[0] = false;
                    moved[0] = false;
                    return true;

                default:
                    return true;
            }
        });
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private void renameFolder(String folderId) {
        BookmarkNode folder = repo.get(folderId);
        if (folder == null || folder.deletedAt != null) return;
        NDialog.showInput(this, "フォルダ名", "フォルダ名", folder.title, false, "保存", text -> {
            if (text.isBlank()) return;
            repo.rename(folderId, text);
            refreshAllVisible();
        });
    }

    private void deleteNode(BookmarkNode node, boolean protectFolderContents) {
        BookmarkNode fresh = repo.get(node.id);
        if (fresh == null || fresh.deletedAt != null) return;
        if (fresh.isFolder()) {
            if (protectFolderContents) repo.deletePreservingFolderChildren(fresh.id);
            else repo.deleteRecursive(fresh.id);
            int index = findPanelIndex(fresh.id);
            if (index >= 0) closePanelsFromDepth(index, true);
        } else {
            repo.softDelete(fresh.id);
        }
        refreshAllVisible();
    }

    private boolean handleRootDrag(View v, DragEvent e) {
        Object local = e.getLocalState();
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                cancelRootFolderHover();
                dragOpenedPanels.clear();
                dragEnteredPanels.clear();
                lastDragScreenX = Float.NaN;
                lastDragScreenY = Float.NaN;
                activeDragTile = local instanceof BookmarkTileView ? (BookmarkTileView) local : null;
                return local instanceof BookmarkTileView || local instanceof SearchWidgetView;

            case DragEvent.ACTION_DRAG_LOCATION:
                if (activeDragTile == null) return true;
                float[] screen = rootPointToScreen(e.getX(), e.getY());
                lastDragScreenX = screen[0];
                lastDragScreenY = screen[1];
                handleDragPanelBoundaries(screen[0], screen[1]);
                updateRootFolderHover(screen[0], screen[1]);
                return true;

            case DragEvent.ACTION_DROP:
                cancelRootFolderHover();
                if (activeDragTile == null) return true;
                float[] dropScreen = rootPointToScreen(e.getX(), e.getY());
                if (pointInsideView(deleteFab, dropScreen[0], dropScreen[1])) return true;
                FolderPanel top = topPanelAt(dropScreen[0], dropScreen[1]);
                if (top != null && dragOpenedPanels.contains(top.folderId)) {
                    top.board.coordinatorDrop(activeDragTile, dropScreen[0], dropScreen[1]);
                }
                return true;

            case DragEvent.ACTION_DRAG_ENDED:
                cancelRootFolderHover();
                activeDragTile = null;
                dragOpenedPanels.clear();
                dragEnteredPanels.clear();
                lastDragScreenX = Float.NaN;
                lastDragScreenY = Float.NaN;
                return true;

            default:
                return true;
        }
    }

    private void updateRootFolderHover(float screenX, float screenY) {
        BookmarkTileView target = findTopFolderTarget(screenX, screenY);
        if (target == rootHoverFolderTarget) return;
        cancelRootFolderHover();
        rootHoverFolderTarget = target;
        if (target != null) root.postDelayed(rootFolderOpenRunnable, 650L);
    }

    private void markDragOpenedPanel(String folderId) {
        int index = findPanelIndex(folderId);
        if (index < 0) return;
        dragOpenedPanels.add(folderId);
        // A spring-loaded folder can open while the pointer is almost stationary. Mark it as
        // entered immediately when the pointer is already inside, otherwise the first event we
        // receive may be an outside location and the child would never get its exit-to-close
        // transition. This is what makes child-only collapse reliable.
        if (!Float.isNaN(lastDragScreenX) && !Float.isNaN(lastDragScreenY)) {
            FolderPanel panel = folderPanels.get(index);
            if (pointInsideView(panel.view, lastDragScreenX, lastDragScreenY)) {
                dragEnteredPanels.add(folderId);
            }
        }
    }

    private void cancelRootFolderHover() {
        if (root != null) root.removeCallbacks(rootFolderOpenRunnable);
        rootHoverFolderTarget = null;
    }

    private BookmarkTileView findTopFolderTarget(float screenX, float screenY) {
        for (int i = folderPanels.size() - 1; i >= 0; i--) {
            FolderPanel panel = folderPanels.get(i);
            if (!pointInsideView(panel.view, screenX, screenY)) continue;
            return panel.board.findFolderTargetAtScreen(screenX, screenY, activeDragTile);
        }
        return homeBoard == null ? null : homeBoard.findFolderTargetAtScreen(screenX, screenY, activeDragTile);
    }

    private void handleDragPanelBoundaries(float screenX, float screenY) {
        if (folderPanels.isEmpty()) return;
        FolderPanel top = folderPanels.get(folderPanels.size() - 1);
        boolean inside = pointInsideView(top.view, screenX, screenY);
        if (inside) {
            dragEnteredPanels.add(top.folderId);
            return;
        }
        if (!dragEnteredPanels.contains(top.folderId)) return;

        BookmarkNode closing = repo.get(top.folderId);
        String parentId = closing == null ? null : closing.parentId;
        dragEnteredPanels.remove(top.folderId);
        dragOpenedPanels.remove(top.folderId);
        closeTopPanel(true);
        // After a child closes, the parent must be entered again before it can close.
        if (parentId != null) dragEnteredPanels.remove(parentId);
        cancelRootFolderHover();
    }

    private FolderPanel topPanelAt(float screenX, float screenY) {
        for (int i = folderPanels.size() - 1; i >= 0; i--) {
            FolderPanel panel = folderPanels.get(i);
            if (pointInsideView(panel.view, screenX, screenY)) return panel;
        }
        return null;
    }

    private boolean pointInsideView(View view, float screenX, float screenY) {
        if (view == null || view.getVisibility() != View.VISIBLE) return false;
        int[] loc = new int[2];
        view.getLocationOnScreen(loc);
        return screenX >= loc[0] && screenX <= loc[0] + view.getWidth()
                && screenY >= loc[1] && screenY <= loc[1] + view.getHeight();
    }

    private float[] rootPointToScreen(float rootX, float rootY) {
        int[] loc = new int[2];
        root.getLocationOnScreen(loc);
        return new float[]{loc[0] + rootX, loc[1] + rootY};
    }

    private boolean handleDeleteDrag(View v, DragEvent e) {
        if (!(e.getLocalState() instanceof BookmarkTileView) && !(e.getLocalState() instanceof SearchWidgetView)) return false;
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return true;
            case DragEvent.ACTION_DRAG_ENTERED:
                deleteFab.setScaleX(1.12f);
                deleteFab.setScaleY(1.12f);
                return true;
            case DragEvent.ACTION_DRAG_EXITED:
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                return true;
            case DragEvent.ACTION_DROP:
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                if (e.getLocalState() instanceof SearchWidgetView) {
                    prefs.edit().putBoolean(KEY_SEARCH_ENABLED, false).apply();
                    homeBoard.setSearchWidget(false, getSearchCellY());
                    refreshHome();
                    return true;
                }
                BookmarkNode node = ((BookmarkTileView) e.getLocalState()).getNode();
                BookmarkNode fresh = repo.get(node.id);
                // Drag-to-delete is deliberately safe: folders use the default protection behavior.
                if (fresh != null) deleteNode(fresh, true);
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                setDeleteTargetVisible(false);
                return true;
            default:
                return true;
        }
    }

    private void setDeleteTargetVisible(boolean visible) {
        deleteFab.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (visible) {
            deleteFab.setAlpha(0f);
            deleteFab.setScaleX(0.85f);
            deleteFab.setScaleY(0.85f);
            deleteFab.bringToFront();
            deleteFab.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(120).start();
        }
    }

    private boolean hasOpenChildPanel(String folderId) {
        if (folderId == null) return false;
        int index = findPanelIndex(folderId);
        if (index < 0 || index + 1 >= folderPanels.size()) return false;
        BookmarkNode child = repo.get(folderPanels.get(index + 1).folderId);
        return child != null && folderId.equals(child.parentId);
    }

    private void closeTopPanel(boolean fromDrag) {
        if (folderPanels.isEmpty()) return;
        FolderPanel top = folderPanels.remove(folderPanels.size() - 1);
        dragOpenedPanels.remove(top.folderId);
        dragEnteredPanels.remove(top.folderId);
        animateClose(top, fromDrag);
        updatePanelDimming();
    }

    private void closeFolderForDrag(String folderId) {
        int index = findPanelIndex(folderId);
        if (index < 0) return;
        for (int i = folderPanels.size() - 1; i >= index; i--) {
            FolderPanel panel = folderPanels.remove(i);
            dragOpenedPanels.remove(panel.folderId);
            dragEnteredPanels.remove(panel.folderId);
            animateClose(panel, true);
        }
        updatePanelDimming();
    }

    private void closePanelsFromDepth(int depth, boolean animate) {
        for (int i = folderPanels.size() - 1; i >= depth; i--) {
            FolderPanel panel = folderPanels.remove(i);
            dragOpenedPanels.remove(panel.folderId);
            dragEnteredPanels.remove(panel.folderId);
            if (animate) animateClose(panel, false);
            else {
                root.removeView(panel.view);
                root.removeView(panel.backdrop);
            }
        }
        updatePanelDimming();
    }

    private int findPanelIndex(String folderId) {
        for (int i = 0; i < folderPanels.size(); i++) {
            if (folderPanels.get(i).folderId.equals(folderId)) return i;
        }
        return -1;
    }

    private void updatePanelDimming() {
        // Keep every folder panel fully opaque. Older panels are rendered as progressively darker
        // *solid* N-dark colors while they have panels above them. This gives the visual impression
        // of alpha layers piling up, but no lower panel or home icon can bleed through. Contents
        // (favicon, folder glyphs, labels) stay at full opacity because only the background changes.
        int top = folderPanels.size() - 1;
        for (int i = 0; i < folderPanels.size(); i++) {
            FolderPanel panel = folderPanels.get(i);
            int layersAbove = Math.max(0, top - i);
            panel.view.setAlpha(1f);
            panel.view.setBackground(roundRect(folderBackgroundForLayers(layersAbove), 18));
        }
    }

    private int folderBackgroundForLayers(int layersAbove) {
        if (layersAbove <= 0) return N_FOLDER_BG;
        double factor = Math.pow(1.0 - FOLDER_STACK_DARKEN, layersAbove);
        int r = Math.max(0, Math.min(255, (int) Math.round(Color.red(N_FOLDER_BG) * factor)));
        int g = Math.max(0, Math.min(255, (int) Math.round(Color.green(N_FOLDER_BG) * factor)));
        int b = Math.max(0, Math.min(255, (int) Math.round(Color.blue(N_FOLDER_BG) * factor)));
        return Color.rgb(r, g, b);
    }

    private void animateOpen(FolderPanel panel) {
        float targetCenterX = panel.layoutParams.leftMargin + panel.layoutParams.width / 2f;
        float targetCenterY = panel.layoutParams.topMargin + panel.layoutParams.height / 2f;
        panel.openingOrClosing = true;
        panel.view.setPivotX(panel.layoutParams.width / 2f);
        panel.view.setPivotY(panel.layoutParams.height / 2f);
        panel.view.setScaleX(0.16f);
        panel.view.setScaleY(0.16f);
        panel.view.setTranslationX(panel.originX - targetCenterX);
        panel.view.setTranslationY(panel.originY - targetCenterY);
        panel.view.setAlpha(1f);
        panel.view.animate()
                .scaleX(1f).scaleY(1f)
                .translationX(0f).translationY(0f)
                .setInterpolator(new DecelerateInterpolator())
                .setDuration(190)
                .withEndAction(() -> {
                    panel.openingOrClosing = false;
                    panel.view.setAlpha(1f);
                    updatePanelDimming();
                })
                .start();
    }

    private void animateClose(FolderPanel panel, boolean fromDrag) {
        float targetCenterX = panel.layoutParams.leftMargin + panel.layoutParams.width / 2f;
        float targetCenterY = panel.layoutParams.topMargin + panel.layoutParams.height / 2f;
        panel.openingOrClosing = true;
        panel.view.animate().cancel();
        if (fromDrag) root.removeView(panel.backdrop);
        panel.view.animate()
                .scaleX(0.16f).scaleY(0.16f)
                .translationX(panel.originX - targetCenterX)
                .translationY(panel.originY - targetCenterY)
                .setDuration(fromDrag ? 130 : 170)
                .withEndAction(() -> {
                    panel.openingOrClosing = false;
                    root.removeView(panel.view);
                    root.removeView(panel.backdrop);
                    updatePanelDimming();
                })
                .start();
    }

    private float[] centerInRoot(View anchor) {
        if (anchor == null) {
            return new float[]{root.getWidth() / 2f, root.getHeight() / 2f};
        }
        int[] anchorLoc = new int[2];
        int[] rootLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);
        root.getLocationOnScreen(rootLoc);
        return new float[]{
                anchorLoc[0] - rootLoc[0] + anchor.getWidth() / 2f,
                anchorLoc[1] - rootLoc[1] + anchor.getHeight() / 2f
        };
    }

    private void showAddDialog(String parentId) {
        String[] items = {"URLを追加", "フォルダを追加"};
        NDialog.showChoices(this, "追加", items, -1, which -> {
            if (which == 0) showAddBookmark(parentId);
            else showAddFolder(parentId);
        });
    }

    private void showAddBookmark(String parentId) {
        NDialog.showInput(this, "ブックマーク追加", "https://example.com", "", true, "追加", text -> {
            String url = text;
            if (url.isEmpty()) return;
            if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
            BookmarkNode created = repo.createBookmark(parentId, url, url);
            refreshAllVisible();
            captureBookmark(created, null, false);
        });
    }

    private void showAddFolder(String parentId) {
        NDialog.showInput(this, "フォルダ追加", "フォルダ名", "", false, "追加", text -> {
            repo.createFolder(parentId, text);
            refreshAllVisible();
        });
    }

    private void handleIncoming(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if (text == null) return;
        Matcher m = URL_PATTERN.matcher(text);
        if (m.find()) {
            String url = m.group();
            BookmarkNode created = repo.createBookmark(null, url, url);
            refreshHome();
            Toast.makeText(this, "ブックマークに追加しました", Toast.LENGTH_SHORT).show();
            captureBookmark(created, null, false);
        }
    }

    private void captureBookmark(BookmarkNode node, NDialog.ThumbnailRefreshCallback callback, boolean showFailureToast) {
        if (captureManager == null || node == null) {
            if (callback != null) callback.onComplete(null, false);
            return;
        }
        captureManager.capture(node, (success, updatedNode, message) -> {
            refreshAllVisible();
            String screenshot = updatedNode == null ? null : updatedNode.screenshotPath;
            if (callback != null) callback.onComplete(screenshot, success);
            if (!success && showFailureToast) {
                Toast.makeText(MainActivity.this, message == null ? "サムネイル取得に失敗しました" : message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void refreshAllVisible() {
        refreshHome();

        for (int i = folderPanels.size() - 1; i >= 0; i--) {
            FolderPanel panel = folderPanels.get(i);
            BookmarkNode folder = repo.get(panel.folderId);
            if (folder == null || folder.deletedAt != null) {
                folderPanels.remove(i);
                dragOpenedPanels.remove(panel.folderId);
                dragEnteredPanels.remove(panel.folderId);
                root.removeView(panel.view);
                root.removeView(panel.backdrop);
            }
        }

        List<FolderPanel> copy = new ArrayList<>(folderPanels);
        for (FolderPanel panel : copy) {
            BookmarkNode folder = repo.get(panel.folderId);
            if (folder == null || folder.deletedAt != null) continue;
            panel.title.setText(folder.title);
            repo.ensurePositions(panel.folderId, FOLDER_COLUMNS, FOLDER_ROWS);
            panel.board.submit(repo.children(panel.folderId));
        }
        updatePanelDimming();
    }

    private ImageView makeDeleteFab() {
        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.ic_close_vector);
        image.setScaleType(ImageView.ScaleType.CENTER);
        image.setContentDescription("削除");
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(Color.BLACK);
        d.setSize(dp(58), dp(58));
        image.setBackground(d);
        image.setElevation(0f);
        return image;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class FolderPanel {
        final String folderId;
        final int depth;
        final FrameLayout view;
        final BookmarkBoardView board;
        final TextView title;
        final View backdrop;
        final FrameLayout.LayoutParams layoutParams;
        final float originX;
        final float originY;
        boolean openingOrClosing;

        FolderPanel(String folderId, int depth, FrameLayout view, BookmarkBoardView board, TextView title,
                    View backdrop, FrameLayout.LayoutParams layoutParams, float originX, float originY) {
            this.folderId = folderId;
            this.depth = depth;
            this.view = view;
            this.board = board;
            this.title = title;
            this.backdrop = backdrop;
            this.layoutParams = layoutParams;
            this.originX = originX;
            this.originY = originY;
        }
    }
}
