package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;
import com.cmyk.bookmarkslauncher.ui.BookmarkBoardView;
import com.cmyk.bookmarkslauncher.ui.NDialog;

import java.text.DateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final int HOME_COLUMNS = 5;
    private static final int FOLDER_COLUMNS = 4;
    private static final Pattern URL_PATTERN = Pattern.compile("https?://\\S+", Pattern.CASE_INSENSITIVE);

    private static final int N_BG = 0xFF303030;
    private static final int N_DGRAY = 0xFF252020;
    private static final int N_GRAY = 0xFF454040;
    private static final int N_LGRAY = 0xFF656060;
    private static final int N_LBLUE = 0xFF445577;
    private static final int N_ICON = 0xFFA9A999;
    private static final int N_TEXT = 0xFFFFFFFF;

    private BookmarkRepository repo;
    private BookmarkBoardView homeBoard;
    private PopupWindow folderPopup;
    private final ArrayDeque<String> folderStack = new ArrayDeque<>();
    private TextView folderTitle;
    private BookmarkBoardView folderBoard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(N_BG);
        getWindow().setNavigationBarColor(N_BG);
        repo = new BookmarkRepository(this);
        setContentView(buildUi());
        handleIncoming(getIntent());
        refreshHome();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(N_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(N_BG);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        // Previous top padding was 14dp. Move the title block 50dp lower.
        top.setPadding(dp(18), dp(64), dp(18), dp(8));

        TextView title = new TextView(this);
        title.setText("BookmarkLauncher");
        title.setTextColor(N_TEXT);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        content.addView(top);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        homeBoard = new BookmarkBoardView(this, HOME_COLUMNS);
        homeBoard.setPadding(0, 0, 0, dp(96));
        bindBoard(homeBoard, null);
        scroll.addView(homeBoard, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(content, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView add = makeFab("＋");
        add.setContentDescription("追加");
        add.setOnClickListener(v -> showAddDialog(null));
        FrameLayout.LayoutParams addLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END | Gravity.BOTTOM);
        addLp.setMargins(0, 0, dp(18), dp(18));
        root.addView(add, addLp);
        return root;
    }

    private void bindBoard(BookmarkBoardView board, String parentId) {
        board.setListener(new BookmarkBoardView.Listener() {
            @Override public void onOpen(BookmarkNode node, View anchor) {
                if (node.isFolder()) {
                    if (parentId == null) openFolder(node);
                    else enterNestedFolder(node);
                } else {
                    openBookmark(node);
                }
            }

            @Override public void onLongPress(BookmarkNode node, View anchor) {
                showNodeMenu(node);
            }

            @Override public void onOrderChanged(List<String> orderedIds) {
                repo.reorder(parentId, orderedIds);
                refreshAllVisible();
            }

            @Override public void onCreateFolder(BookmarkNode dragged, BookmarkNode target) {
                repo.createFolderFromNodes(parentId, dragged.id, target.id);
                refreshAllVisible();
            }

            @Override public void onMoveIntoFolder(BookmarkNode dragged, BookmarkNode folder) {
                if (!repo.moveToParent(dragged.id, folder.id)) {
                    Toast.makeText(MainActivity.this, "このフォルダには移動できません", Toast.LENGTH_SHORT).show();
                }
                refreshAllVisible();
            }
        });
    }

    private void refreshHome() {
        homeBoard.submit(repo.children(null));
    }

    private void openBookmark(BookmarkNode node) {
        if (node.url == null || node.url.isBlank()) return;
        repo.touchAccess(node.id);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(node.url)));
        } catch (Exception e) {
            Toast.makeText(this, "URLを開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private void openFolder(BookmarkNode node) {
        if (folderPopup == null) createFolderPopup();
        folderStack.clear();
        folderStack.push(node.id);
        renderFolder(node.id);
        if (!folderPopup.isShowing()) {
            folderPopup.showAtLocation(homeBoard, Gravity.CENTER, 0, dp(28));
        }
    }

    private void createFolderPopup() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        panel.setBackground(roundRect(N_DGRAY, 18));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = makeRoundIcon("‹", N_GRAY, dp(44));
        back.setTextSize(28);
        back.setOnClickListener(v -> navigateFolderBack());
        bar.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));

        folderTitle = new TextView(this);
        folderTitle.setTextColor(N_TEXT);
        folderTitle.setTextSize(18);
        folderTitle.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        titleLp.setMargins(dp(12), 0, dp(8), 0);
        bar.addView(folderTitle, titleLp);
        panel.addView(bar);

        FrameLayout body = new FrameLayout(this);
        ScrollView sc = new ScrollView(this);
        sc.setClipToPadding(false);
        folderBoard = new BookmarkBoardView(this, FOLDER_COLUMNS);
        folderBoard.setPadding(0, 0, 0, dp(76));
        sc.addView(folderBoard, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        body.addView(sc, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView add = makeFab("＋");
        add.setOnClickListener(v -> showAddDialog(folderStack.peek()));
        FrameLayout.LayoutParams addLp = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.END | Gravity.BOTTOM);
        addLp.setMargins(0, 0, dp(8), dp(8));
        body.addView(add, addLp);

        panel.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        int width = Math.min(dp(360), getResources().getDisplayMetrics().widthPixels - dp(28));
        int height = Math.min(dp(520), getResources().getDisplayMetrics().heightPixels - dp(120));
        folderPopup = new PopupWindow(panel, width, height, true);
        folderPopup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        folderPopup.setElevation(dp(16));
        folderPopup.setOutsideTouchable(true);
    }

    private void renderFolder(String id) {
        BookmarkNode folder = repo.get(id);
        folderTitle.setText(folder == null ? "フォルダ" : folder.title);
        bindBoard(folderBoard, id);
        folderBoard.submit(repo.children(id));
    }

    private void navigateFolderBack() {
        if (folderStack.size() <= 1) {
            folderPopup.dismiss();
            return;
        }
        folderStack.pop();
        renderFolder(folderStack.peek());
    }

    private void enterNestedFolder(BookmarkNode node) {
        folderStack.push(node.id);
        renderFolder(node.id);
    }

    private void showNodeMenu(BookmarkNode node) {
        String[] actions = {"情報", "1×1", "2×1", "1×2", "2×2", "削除"};
        NDialog.showChoices(this, node.title, actions, 5, which -> {
            if (which == 0) {
                showInfo(node);
            } else if (which >= 1 && which <= 4) {
                int[][] spans = {{1,1}, {2,1}, {1,2}, {2,2}};
                repo.resize(node.id, spans[which - 1][0], spans[which - 1][1]);
                refreshAllVisible();
            } else if (which == 5) {
                repo.softDelete(node.id);
                refreshAllVisible();
            }
        });
    }

    private void showInfo(BookmarkNode node) {
        DateFormat f = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        String created = f.format(new Date(node.createdAt));
        String last = node.lastAccessedAt == null ? "未アクセス" : f.format(new Date(node.lastAccessedAt));
        String offline = node.offlineSavedAt == null ? "未保存" : f.format(new Date(node.offlineSavedAt));
        String body = "URL\n" + (node.url == null ? "—" : node.url) +
                "\n\nブックマーク日\n" + created +
                "\n\n最終アクセス日\n" + last +
                "\n\nオフライン保存\n" + offline +
                "\n\nスクリーンショット\n" + (node.screenshotPath == null ? "未取得" : node.screenshotPath);
        NDialog.showMessage(this, node.title, body);
    }

    private void showAddDialog(String parentId) {
        String[] items = {"URLを追加", "フォルダを追加"};
        NDialog.showChoices(this, "追加", items, -1, which -> {
            if (which == 0) showAddBookmark(parentId);
            else showAddFolder(parentId);
        });
    }

    private void showAddBookmark(String parentId) {
        NDialog.showInput(this, "ブックマーク追加", "https://example.com", "", true, "追加", text -> {
            String url = text;
            if (url.isEmpty()) return;
            if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
            repo.createBookmark(parentId, url, url);
            refreshAllVisible();
        });
    }

    private void showAddFolder(String parentId) {
        NDialog.showInput(this, "フォルダ追加", "フォルダ名", "", false, "追加", text -> {
            repo.createFolder(parentId, text);
            refreshAllVisible();
        });
    }

    private void handleIncoming(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if (text == null) return;
        Matcher m = URL_PATTERN.matcher(text);
        if (m.find()) {
            String url = m.group();
            repo.createBookmark(null, url, url);
            refreshHome();
            Toast.makeText(this, "ブックマークに追加しました", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshAllVisible() {
        refreshHome();
        if (folderPopup != null && folderPopup.isShowing() && !folderStack.isEmpty()) {
            renderFolder(folderStack.peek());
        }
    }

    private TextView makeFab(String text) {
        TextView tv = makeRoundIcon(text, N_LBLUE, dp(58));
        tv.setTextSize(28);
        tv.setElevation(dp(8));
        return tv;
    }

    private TextView makeRoundIcon(String text, int color, int size) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(N_ICON);
        tv.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        d.setSize(size, size);
        tv.setBackground(d);
        return tv;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
