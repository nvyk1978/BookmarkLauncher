package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;
import com.cmyk.bookmarkslauncher.googlemaps.GoogleMapsModule;
import com.cmyk.bookmarkslauncher.offline.OfflineStorage;
import com.cmyk.bookmarkslauncher.offline.OfflineWebActivity;
import com.cmyk.bookmarkslauncher.ui.BookmarkBoardView;
import com.cmyk.bookmarkslauncher.ui.BookmarkTileView;
import com.cmyk.bookmarkslauncher.ui.NDialog;
import com.cmyk.bookmarkslauncher.ui.SearchWidgetView;
import com.cmyk.bookmarkslauncher.ui.UrlAddWidgetView;
import com.cmyk.bookmarkslauncher.wishlist.WishlistCrawler;
import com.cmyk.bookmarkslauncher.wishlist.WishlistItem;
import com.cmyk.bookmarkslauncher.wishlist.WishlistRepository;
import com.cmyk.bookmarkslauncher.wishlist.WishlistScheduler;

import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final int HOME_COLUMNS = 5;
    private static final int HOME_ROWS = 8;
    private static final int FOLDER_COLUMNS = 4;
    private static final int FOLDER_ROWS = 5;
    private static final int FOLDER_TITLE_HEIGHT_DP = 48;
    private static final Pattern URL_PATTERN = Pattern.compile("https?://\\S+", Pattern.CASE_INSENSITIVE);
    private static final int REQ_OFFLINE_WEB = 7042;
    private static final int REQ_QR_IMAGE = 7043;

    private static final int N_BG = 0xFF303030;
    private static final int N_DGRAY = 0xFF252020;
    // Folder surfaces are always opaque. When multiple folder panels are stacked, older
    // panels are darkened with solid colors to imitate alpha stacking without allowing the
    // panels to visually melt into one another.
    private static final int N_FOLDER_BG = 0xFF454040;
    private static final int FOLDER_OVERLAP_SHADE = 0x36000000;
    private static final int FOLDER_ARM_INSET_DP = 6;
    private static final int FOLDER_EXIT_HYSTERESIS_DP = 10;
    private static final long PARENT_REARM_COOLDOWN_MS = 1000L;

    private static final String PREFS = "bookmarklauncher_ui";
    private static final String KEY_SEARCH_CONFIGURED = "search_configured";
    private static final String KEY_SEARCH_ENABLED = "search_enabled";
    private static final String KEY_SEARCH_CELL_X = "search_cell_x";
    private static final String KEY_SEARCH_CELL_Y = "search_cell_y";
    private static final String KEY_PLUS_CONFIGURED = "plus_configured";
    private static final String KEY_PLUS_ENABLED = "plus_enabled";
    private static final String KEY_PLUS_CELL_X = "plus_cell_x";
    private static final String KEY_PLUS_CELL_Y = "plus_cell_y";
    private static final int N_LBLUE = 0xFF445577;
    private static final int N_ICON = 0xFFA9A999;
    private static final int N_TEXT = 0xFFFFFFFF;

    private BookmarkRepository repo;
    private SharedPreferences prefs;
    private FrameLayout root;
    private BookmarkBoardView homeBoard;
    private ImageView deleteFab;
    private BookmarkCaptureManager captureManager;
    private final List<FolderPanel> folderPanels = new ArrayList<>();
    private final Set<String> dragOpenedPanels = new HashSet<>();
    private BookmarkTileView activeDragTile;
    private View searchResultsBackdrop;
    private FrameLayout searchResultsPanel;
    private String activeDragItemId;
    private BookmarkTileView rootHoverFolderTarget;
    private NDialog.BookmarkDetailsHandle activeBookmarkDetails;
    private String activeBookmarkDetailsId;
    private NDialog.QrScanCallback pendingQrImageCallback;
    // Home and Wishlist are real sibling pages in one window, never two activity snapshots.
    private FrameLayout swipeContainer;
    private WishlistPage wishlistPage;
    private View wishlistView;
    private boolean wishlistActive;
    private boolean wishlistSwipeCandidate;
    private boolean wishlistSwipeTracking;
    private boolean wishlistSwipeAnimating;
    private float wishlistSwipeDownX;
    private float wishlistSwipeDownY;
    private long wishlistSwipeDownTime;
    private int wishlistSwipeDirection;
    private float lastDragScreenX = Float.NaN;
    private float lastDragScreenY = Float.NaN;
    private final Runnable rootFolderOpenRunnable = () -> {
        BookmarkTileView target = rootHoverFolderTarget;
        if (target == null || activeDragTile == null) return;
        BookmarkNode folder = target.getNode();
        if (folder == null || !folder.isFolder() || folder.id.equals(activeDragTile.getNode().id)) return;
        openFolderPanel(folder, target);
        markDragOpenedPanel(folder.id);
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DiagLog.installCrashHandler(this);
        DiagLog.write(this, "APP_START");
        getWindow().setStatusBarColor(0x80000000);
        getWindow().setNavigationBarColor(N_BG);
        repo = new BookmarkRepository(this);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        WishlistScheduler.ensureScheduled(this);
        if (!prefs.contains(KEY_SEARCH_CONFIGURED)) {
            prefs.edit()
                    .putBoolean(KEY_SEARCH_CONFIGURED, true)
                    .putBoolean(KEY_SEARCH_ENABLED, true)
                    .putInt(KEY_SEARCH_CELL_X, 0)
                    .putInt(KEY_SEARCH_CELL_Y, 0)
                    .apply();
        } else if (!prefs.contains(KEY_SEARCH_CELL_X)) {
            prefs.edit().putInt(KEY_SEARCH_CELL_X, 0).apply();
        }
        if (!prefs.contains(KEY_PLUS_CONFIGURED)) {
            int sx = Math.max(0, Math.min(1, prefs.getInt(KEY_SEARCH_CELL_X, 0)));
            int sy = Math.max(0, Math.min(HOME_ROWS - 1, prefs.getInt(KEY_SEARCH_CELL_Y, 0)));
            prefs.edit()
                    .putBoolean(KEY_PLUS_CONFIGURED, true)
                    .putBoolean(KEY_PLUS_ENABLED, true)
                    .putInt(KEY_PLUS_CELL_X, sx == 0 ? 4 : 0)
                    .putInt(KEY_PLUS_CELL_Y, sy)
                    .apply();
        }
        View home = buildUi();
        swipeContainer = new FrameLayout(this);
        swipeContainer.setBackgroundColor(N_BG);
        swipeContainer.setClipChildren(true);
        swipeContainer.addView(home, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(swipeContainer);
        SystemBarScrim.apply(this, swipeContainer);
        installImeTracking();
        captureManager = new BookmarkCaptureManager(this, root, repo);
        handleIncoming(getIntent());
        refreshHome();
        openWishlistFromIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
        openWishlistFromIntent(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == WishlistPage.REQUEST_IMAGE_PICK) {
            if (wishlistPage != null) wishlistPage.onImagePicked(resultCode, data);
            return;
        }
        if (requestCode == REQ_OFFLINE_WEB) {
            // Offline save/delete state is persisted by OfflineWebActivity. Re-read the board
            // so the saved badge appears/disappears as soon as the viewer returns.
            refreshAllVisible();
            refreshActiveBookmarkOfflineState();
            return;
        }
        if (requestCode == REQ_QR_IMAGE) {
            NDialog.QrScanCallback callback = pendingQrImageCallback;
            pendingQrImageCallback = null;
            if (callback == null) return;
            if (resultCode != RESULT_OK || data == null) {
                callback.onError(null);
                return;
            }
            String uriText = data.getStringExtra(NExplorerActivity.RESULT_FILE_URI);
            if (uriText == null || uriText.isBlank()) {
                callback.onError("画像を読み込めませんでした");
                return;
            }
            final Uri imageUri = Uri.parse(uriText);
            final ExecutorService executor = Executors.newSingleThreadExecutor();
            executor.execute(() -> {
                try {
                    String value = QrUtils.decode(this, imageUri);
                    runOnUiThread(() -> {
                        if (value == null || value.isBlank()) callback.onError("画像からQRコードを検出できませんでした");
                        else {
                            DiagLog.write(this, "QR_IMAGE_SUCCESS length=" + value.length());
                            callback.onScanned(value);
                        }
                    });
                } catch (Throwable t) {
                    DiagLog.write(this, "QR_IMAGE_ERROR " + DiagLog.stackTrace(t));
                    runOnUiThread(() -> callback.onError("画像からQRコードを読み取れませんでした"));
                } finally {
                    executor.shutdown();
                }
            });
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Leaving BookmarkLauncher always returns to a clean Home state. Expanded folders
        // are intentionally transient and are never restored after app/background switches.
        cancelRootFolderHover();
        if (root != null && !folderPanels.isEmpty()) closePanelsFromDepth(0, false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (wishlistPage != null) wishlistPage.onHostResume();
    }

    @Override
    protected void onDestroy() {
        if (captureManager != null) captureManager.destroy();
        if (wishlistPage != null) wishlistPage.destroy();
        super.onDestroy();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        // Once a horizontal gesture starts, children receive CANCEL. Both live pages
        // track the finger; ordinary taps, icon drags and vertical scrolling do not.
        final int action = ev.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN && !wishlistSwipeAnimating) {
            wishlistSwipeDownX = ev.getRawX();
            wishlistSwipeDownY = ev.getRawY();
            wishlistSwipeDownTime = android.os.SystemClock.uptimeMillis();
            wishlistSwipeTracking = false;
            // Ignore gestures beginning inside an editable field, not a search box
            // that happens to retain focus while the user swipes elsewhere.
            boolean inInput = false;
            View focused = getCurrentFocus();
            if (focused instanceof EditText && focused.isShown()) {
                int[] position = new int[2];
                focused.getLocationOnScreen(position);
                inInput = ev.getRawX() >= position[0]
                        && ev.getRawX() <= position[0] + focused.getWidth()
                        && ev.getRawY() >= position[1]
                        && ev.getRawY() <= position[1] + focused.getHeight();
            }
            wishlistSwipeCandidate = folderPanels.isEmpty()
                    && activeDragTile == null && searchResultsPanel == null && !inInput;
        } else if (action == MotionEvent.ACTION_MOVE && wishlistSwipeCandidate) {
            float dx = ev.getRawX() - wishlistSwipeDownX;
            float dy = ev.getRawY() - wishlistSwipeDownY;
            if (!wishlistSwipeTracking) {
                if (Math.abs(dy) > dp(14) && Math.abs(dy) >= Math.abs(dx)) {
                    wishlistSwipeCandidate = false;
                } else if (dx > dp(20) && dx > Math.abs(dy) * 1.35f) {
                    wishlistSwipeTracking = true;
                    wishlistSwipeDirection = 1;
                    beginWishlistSwipe();
                    MotionEvent cancel = MotionEvent.obtain(ev);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(cancel);
                    cancel.recycle();
                } else if (dx < -dp(20)) {
                    // Left swipe only navigates back from Wishlist (natural reverse).
                    if (wishlistActive && -dx > Math.abs(dy) * 1.35f) {
                        wishlistSwipeTracking = true;
                        wishlistSwipeDirection = -1;
                        beginWishlistSwipe();
                        MotionEvent cancel = MotionEvent.obtain(ev);
                        cancel.setAction(MotionEvent.ACTION_CANCEL);
                        super.dispatchTouchEvent(cancel);
                        cancel.recycle();
                    } else if (!wishlistActive) {
                        wishlistSwipeCandidate = false;
                    }
                }
            }
            if (wishlistSwipeTracking) {
                trackWishlistSwipe(dx);
                return true;
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            if (wishlistSwipeTracking) {
                float distance = ev.getRawX() - wishlistSwipeDownX;
                long duration = android.os.SystemClock.uptimeMillis() - wishlistSwipeDownTime;
                finishWishlistSwipe(action == MotionEvent.ACTION_UP &&
                        ((wishlistSwipeDirection * distance > swipeWidth() * .29f) ||
                         (wishlistSwipeDirection * distance > dp(90) && duration < 300L)));
                wishlistSwipeTracking = false;
                wishlistSwipeCandidate = false;
                return true;
            }
            wishlistSwipeCandidate = false;
        } else if (action == MotionEvent.ACTION_POINTER_DOWN) {
            if (wishlistSwipeTracking) {
                finishWishlistSwipe(false);
                wishlistSwipeTracking = false;
                wishlistSwipeCandidate = false;
                return true;
            }
            wishlistSwipeCandidate = false;
        }
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
            View focus = getCurrentFocus();
            if (focus != null && focus.getParent() instanceof SearchWidgetView) {
                View search = (View) focus.getParent();
                int[] loc = new int[2];
                search.getLocationOnScreen(loc);
                float x = ev.getRawX();
                float y = ev.getRawY();
                boolean inside = x >= loc[0] && x <= loc[0] + search.getWidth()
                        && y >= loc[1] && y <= loc[1] + search.getHeight();
                if (!inside) {
                    focus.clearFocus();
                    if (homeBoard != null) homeBoard.setSearchImeTranslation(0f);
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
                }
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    private int swipeWidth() {
        int w = swipeContainer == null ? 0 : swipeContainer.getWidth();
        return w > 0 ? w : getResources().getDisplayMetrics().widthPixels;
    }

    private void ensureWishlistPage() {
        if (wishlistPage != null) return;
        wishlistPage = new WishlistPage(this, () -> animateWishlistToHome(), null);
        wishlistView = wishlistPage.getView();
        wishlistView.setVisibility(View.INVISIBLE);
        swipeContainer.addView(wishlistView, 1, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void openWishlistFromIntent(Intent intent) {
        if (intent == null || !intent.hasExtra("wishlist_item_id")) return;
        String id = intent.getStringExtra("wishlist_item_id");
        intent.removeExtra("wishlist_item_id"); // do not unexpectedly reopen on recreation
        ensureWishlistPage();
        wishlistPage.openItem(id);
        wishlistActive = true;
        wishlistView.setTranslationX(0f);
        root.setTranslationX(0f);
        wishlistView.setVisibility(View.VISIBLE);
        root.setVisibility(View.INVISIBLE);
    }

    private void beginWishlistSwipe() {
        ensureWishlistPage();
        if (!wishlistActive) wishlistPage.refresh();
        root.animate().cancel();
        wishlistView.animate().cancel();
        wishlistView.setVisibility(View.VISIBLE);
        root.setVisibility(View.VISIBLE);
        trackWishlistSwipe(0f);
    }

    private void trackWishlistSwipe(float distance) {
        final int w = swipeWidth();
        float d = Math.max(0f, Math.min(w, wishlistSwipeDirection * distance));
        float offset = wishlistSwipeDirection * d;
        View outgoing = wishlistActive ? wishlistView : root;
        View incoming = wishlistActive ? root : wishlistView;
        outgoing.setTranslationX(offset);
        incoming.setTranslationX(offset - wishlistSwipeDirection * w);
    }

    private void finishWishlistSwipe(boolean complete) {
        final int w = swipeWidth();
        final View outgoing = wishlistActive ? wishlistView : root;
        final View incoming = wishlistActive ? root : wishlistView;
        final float end = wishlistSwipeDirection * w;
        wishlistSwipeAnimating = true;
        float progress = Math.abs(outgoing.getTranslationX()) / Math.max(1, w);
        long duration = Math.max(110L, Math.round(260f * (complete ? 1f - progress : progress)));
        android.view.animation.Interpolator ease = new DecelerateInterpolator(1.6f);
        outgoing.animate().translationX(complete ? end : 0f).setDuration(duration).setInterpolator(ease).start();
        incoming.animate().translationX(complete ? 0f : -end).setDuration(duration)
                .setInterpolator(ease).withEndAction(() -> {
                    wishlistActive = complete ? !wishlistActive : wishlistActive;
                    if (wishlistActive) {
                        wishlistView.setVisibility(View.VISIBLE);
                        root.setVisibility(View.INVISIBLE);
                    } else {
                        root.setVisibility(View.VISIBLE);
                        wishlistView.setVisibility(View.INVISIBLE);
                    }
                    root.setTranslationX(0f);
                    wishlistView.setTranslationX(0f);
                    wishlistSwipeAnimating = false;
                }).start();
    }

    private void animateWishlistToHome() {
        if (!wishlistActive || wishlistSwipeTracking || wishlistSwipeAnimating) return;
        wishlistSwipeDirection = 1; // preserve right-swipe-to-home behavior
        beginWishlistSwipe();
        finishWishlistSwipe(true);
    }

    private void installImeTracking() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                boolean imeVisible = insets.isVisible(WindowInsets.Type.ime());
                int imeBottom = imeVisible ? insets.getInsets(WindowInsets.Type.ime()).bottom : 0;
                updateSearchForIme(imeBottom);
                return insets;
            });
            root.post(root::requestApplyInsets);
        } else {
            root.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
                if (root.getHeight() <= 0) return;
                Rect visible = new Rect();
                root.getWindowVisibleDisplayFrame(visible);
                int[] rootLoc = new int[2];
                root.getLocationOnScreen(rootLoc);
                int obstruction = Math.max(0, rootLoc[1] + root.getHeight() - visible.bottom);
                updateSearchForIme(obstruction > dp(120) ? obstruction : 0);
            });
        }
    }

    private void updateSearchForIme(int imeBottomPx) {
        if (homeBoard == null) return;
        SearchWidgetView search = homeBoard.getSearchView();
        if (search == null) return;

        if (imeBottomPx <= 0 || !search.getInput().hasFocus()) {
            homeBoard.setSearchImeTranslation(0f);
            return;
        }

        int[] searchLoc = new int[2];
        int[] rootLoc = new int[2];
        search.getLocationOnScreen(searchLoc);
        root.getLocationOnScreen(rootLoc);

        // getLocationOnScreen includes translationY. Remove the current temporary IME offset
        // so the grid position itself never changes while calculating the new offset.
        float baseTop = searchLoc[1] - rootLoc[1] - search.getTranslationY();
        float baseBottom = baseTop + search.getHeight();
        float keyboardTop = root.getHeight() - imeBottomPx;
        float targetBottom = keyboardTop - dp(10);
        float offset = Math.min(0f, targetBottom - baseBottom);
        homeBoard.setSearchImeTranslation(offset);
    }

    @Override
    public void onBackPressed() {
        if (wishlistActive) {
            if (wishlistPage != null && wishlistPage.handleBack()) return;
            animateWishlistToHome();
            return;
        }
        if (!folderPanels.isEmpty()) {
            closeTopPanel(false);
            return;
        }
        super.onBackPressed();
    }

    private View buildUi() {
        root = new DragCoordinatorLayout(this);
        root.setBackgroundColor(N_BG);
        root.setOnDragListener(this::handleRootDrag);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(N_BG);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(18), dp(64), dp(18), dp(8));

        TextView title = new TextView(this);
        title.setText("BookmarkLauncher");
        title.setTextColor(N_ICON);
        title.setTextSize(25);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        TextView version = new TextView(this);
        version.setText(BuildConfig.VERSION_NAME);
        version.setTextColor(N_ICON);
        version.setTextSize(12);
        version.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(version, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(top);

        homeBoard = new BookmarkBoardView(this, HOME_COLUMNS, HOME_ROWS);
        homeBoard.setContainerId(null);
        homeBoard.setPadding(0, 0, 0, dp(18));
        bindBoard(homeBoard, null);
        content.addView(homeBoard, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(content, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        deleteFab = makeDeleteFab();
        deleteFab.setVisibility(View.GONE);
        deleteFab.setOnDragListener(this::handleDeleteDrag);
        FrameLayout.LayoutParams deleteLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER_HORIZONTAL | Gravity.TOP);
        deleteLp.setMargins(0, dp(58), 0, 0);
        root.addView(deleteFab, deleteLp);

        return root;
    }

    private void setActiveDragItemId(String itemId) {
        activeDragItemId = itemId;
        if (homeBoard != null) homeBoard.setActiveDragItemId(itemId);
        for (FolderPanel panel : folderPanels) panel.board.setActiveDragItemId(itemId);
    }

    private void bindBoard(BookmarkBoardView board, String parentId) {
        board.setContainerId(parentId);
        board.setListener(new BookmarkBoardView.Listener() {
            @Override public void onOpen(BookmarkNode node, View anchor) {
                if (node.isFolder()) openFolderPanel(node, anchor);
                else if (node.isApp()) openApp(node);
                else if (node.isQr()) showQrPreview(node);
                else openBookmark(node);
            }

            @Override public void onLongPress(BookmarkNode node, View anchor) {
                BookmarkNode fresh = repo.get(node.id);
                if (fresh == null || fresh.deletedAt != null) return;
                if (fresh.isFolder()) showFolderProperties(fresh);
                else if (fresh.isApp()) showAppProperties(fresh);
                else if (fresh.isQr()) showQrProperties(fresh);
                else showBookmarkProperties(fresh);
            }

            @Override public void onPositionsChanged(List<BookmarkNode> nodes) {
                repo.updatePositions(parentId, nodes);
                refreshAllVisible();
            }

            @Override public void onExternalDrop(BookmarkNode dragged, int cellX, int cellY, List<BookmarkNode> residentNodes) {
                repo.updatePositions(parentId, residentNodes);
                if (!repo.moveToParentAtPosition(dragged.id, parentId, cellX, cellY)) {
                    Toast.makeText(MainActivity.this, "ここには移動できません", Toast.LENGTH_SHORT).show();
                }
                refreshAllVisible();
            }

            @Override public void onCreateFolder(BookmarkNode dragged, BookmarkNode target) {
                BookmarkNode freshDragged = repo.get(dragged.id);
                BookmarkNode freshTarget = repo.get(target.id);
                if (freshDragged == null || freshTarget == null) return;
                if (!sameParentId(parentId, freshDragged.parentId) || !sameParentId(parentId, freshTarget.parentId)) return;
                repo.createFolderFromNodes(parentId, dragged.id, target.id);
                refreshAllVisible();
            }

            @Override public void onMoveIntoFolder(BookmarkNode dragged, BookmarkNode folder, View folderAnchor) {
                BookmarkNode freshDragged = repo.get(dragged.id);
                if (freshDragged == null) return;
                // A drop commits the move only. Folder expansion is spring-loaded and happens
                // exclusively after the drag hovers over the folder for the configured dwell time.
                if (folder.id.equals(freshDragged.parentId)) return;
                if (!repo.moveToParent(dragged.id, folder.id)) {
                    Toast.makeText(MainActivity.this, "このフォルダには移動できません", Toast.LENGTH_SHORT).show();
                    return;
                }
                refreshAllVisible();
            }

            @Override public void onHoverOpenFolder(BookmarkNode dragged, BookmarkNode folder, View folderAnchor) {
                // Spring-loaded folder opening: hover opens the folder without moving data yet.
                // The actual parent change is committed only on drop.
                if (dragged == null || folder == null || dragged.id.equals(folder.id)) return;
                openFolderPanel(folder, folderAnchor);
                if (activeDragTile != null) markDragOpenedPanel(folder.id);
            }

            @Override public void onDragExited(BookmarkNode dragged) {
                // Boundary state is tracked by DragCoordinatorLayout.dispatchDragEvent(), which
                // receives the drag before it is routed to whichever board is currently under it.
            }

            @Override public void onEmptyLongPress(int cellX, int cellY) {
                if (parentId != null) return;
                showHomeEmptyMenu(cellX, cellY);
            }

            @Override public void onEmptySwipeDown() {
                if (parentId != null) return;
                openNotificationShade();
            }

            @Override public void onSearchWidgetMoved(int cellX, int cellY) {
                if (parentId != null) return;
                prefs.edit().putBoolean(KEY_SEARCH_ENABLED, true)
                        .putInt(KEY_SEARCH_CELL_X, cellX)
                        .putInt(KEY_SEARCH_CELL_Y, cellY).apply();
                refreshHome();
            }

            @Override public void onPlusWidgetMoved(int cellX, int cellY) {
                if (parentId != null) return;
                prefs.edit().putBoolean(KEY_PLUS_ENABLED, true)
                        .putInt(KEY_PLUS_CELL_X, cellX)
                        .putInt(KEY_PLUS_CELL_Y, cellY).apply();
                refreshHome();
            }

            @Override public void onUrlAddRequested() {
                if (parentId == null) showPrimaryAddMenu();
            }

            @Override public void onSearchQuery(String query) {
                if (parentId == null) showSearchResults(query);
            }

            @Override public void onDragStateChanged(boolean active, BookmarkNode node) {
                if (node != null) setActiveDragItemId(active ? node.id : null);
                setDeleteTargetVisible(active);
            }

            @Override public List<BookmarkNode> onFolderPreview(BookmarkNode folder) {
                List<BookmarkNode> children = repo.children(folder.id);
                if (children.size() <= 4) return children;
                return new ArrayList<>(children.subList(0, 4));
            }
        });
    }

    private void openNotificationShade() {
        if (NotificationShadeAccessibilityService.openNotifications()) {
            DiagLog.write(this, "GESTURE_NOTIFICATION_SHADE_OPEN");
            return;
        }

        DiagLog.write(this, "GESTURE_NOTIFICATION_SHADE_ACCESSIBILITY_REQUIRED");
        Toast.makeText(this, "通知バー操作を使うには BookmarkLauncher のユーザー補助をONにしてください", Toast.LENGTH_LONG).show();
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "ユーザー補助設定を開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private static boolean sameParentId(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    private void refreshHome() {
        boolean searchEnabled = isSearchEnabled();
        boolean plusEnabled = isPlusEnabled();
        int searchX = getSearchCellX();
        int searchY = getSearchCellY();
        int plusX = getPlusCellX();
        int plusY = getPlusCellY();
        homeBoard.setHomeWidgets(searchEnabled, searchX, searchY, plusEnabled, plusX, plusY);
        repo.ensurePositions(null, HOME_COLUMNS, HOME_ROWS,
                searchEnabled, searchX, searchY, plusEnabled, plusX, plusY);
        homeBoard.submit(repo.children(null));
    }

    private boolean isSearchEnabled() {
        return prefs != null && prefs.getBoolean(KEY_SEARCH_ENABLED, true);
    }

    private int getSearchCellX() {
        return Math.max(0, Math.min(1, prefs == null ? 0 : prefs.getInt(KEY_SEARCH_CELL_X, 0)));
    }

    private int getSearchCellY() {
        return Math.max(0, Math.min(HOME_ROWS - 1, prefs == null ? 0 : prefs.getInt(KEY_SEARCH_CELL_Y, 0)));
    }

    private boolean isPlusEnabled() {
        return prefs != null && prefs.getBoolean(KEY_PLUS_ENABLED, true);
    }

    private int getPlusCellX() {
        return Math.max(0, Math.min(HOME_COLUMNS - 1, prefs == null ? 4 : prefs.getInt(KEY_PLUS_CELL_X, 4)));
    }

    private int getPlusCellY() {
        return Math.max(0, Math.min(HOME_ROWS - 1, prefs == null ? 0 : prefs.getInt(KEY_PLUS_CELL_Y, 0)));
    }

    private void showHomeEmptyMenu(int requestedX, int requestedY) {
        List<String> options = new ArrayList<>();
        if (!isSearchEnabled()) options.add("検索窓を追加");
        if (!isPlusEnabled()) options.add("(＋追加)を追加");
        options.add("アプリを追加");
        options.add("エクスプローラ");
        options.add("診断ログ");

        String[] labels = options.toArray(new String[0]);
        NDialog.showPlainMenu(this, "追加", labels, which -> {
            if (which < 0 || which >= labels.length) return;
            String selected = labels[which];
            if ("エクスプローラ".equals(selected)) {
                showExplorer(null);
                return;
            }
            if ("診断ログ".equals(selected)) {
                NDiagnosticLog.show(this);
                return;
            }
            if ("アプリを追加".equals(selected)) {
                showAppPicker();
                return;
            }

            int row = Math.max(0, Math.min(HOME_ROWS - 1, requestedY));
            if ("検索窓を追加".equals(selected)) {
                int[] pos = findSearchPlacement(Math.max(0, Math.min(1, requestedX)), row);
                prefs.edit().putBoolean(KEY_SEARCH_ENABLED, true)
                        .putInt(KEY_SEARCH_CELL_X, pos[0]).putInt(KEY_SEARCH_CELL_Y, pos[1]).apply();
            } else if ("(＋追加)を追加".equals(selected)) {
                int[] pos = findPlusPlacement(Math.max(0, Math.min(HOME_COLUMNS - 1, requestedX)), row);
                prefs.edit().putBoolean(KEY_PLUS_ENABLED, true)
                        .putInt(KEY_PLUS_CELL_X, pos[0]).putInt(KEY_PLUS_CELL_Y, pos[1]).apply();
            }
            refreshHome();
        });
    }

    private int[] findSearchPlacement(int preferredX, int preferredY) {
        for (int pass = 0; pass < HOME_ROWS; pass++) {
            int y = (preferredY + pass) % HOME_ROWS;
            for (int k = 0; k < 2; k++) {
                int x = k == 0 ? preferredX : 1 - preferredX;
                if (!isPlusEnabled() || getPlusCellY() != y || getPlusCellX() < x || getPlusCellX() >= x + 4) {
                    return new int[]{x, y};
                }
            }
        }
        return new int[]{0, preferredY};
    }

    private int[] findPlusPlacement(int preferredX, int preferredY) {
        for (int pass = 0; pass < HOME_ROWS; pass++) {
            int y = (preferredY + pass) % HOME_ROWS;
            for (int offset = 0; offset < HOME_COLUMNS; offset++) {
                int x = (preferredX + offset) % HOME_COLUMNS;
                if (!isSearchEnabled() || getSearchCellY() != y || x < getSearchCellX() || x >= getSearchCellX() + 4) {
                    return new int[]{x, y};
                }
            }
        }
        return new int[]{4, preferredY};
    }

    private void showSearchResults(String query) {
        List<BookmarkNode> results = repo.search(query);
        if (results.isEmpty()) {
            Toast.makeText(this, "見つかりませんでした", Toast.LENGTH_SHORT).show();
            return;
        }

        closeSearchResultsPanel();
        closePanelsFromDepth(0, true);

        int count = Math.min(FOLDER_COLUMNS * FOLDER_ROWS, results.size());
        List<BookmarkNode> visible = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            BookmarkNode n = results.get(i);
            // Search results are a presentation grid only. Do not write these coordinates back.
            n.cellX = i % FOLDER_COLUMNS;
            n.cellY = i / FOLDER_COLUMNS;
            n.spanX = 1;
            n.spanY = 1;
            visible.add(n);
        }

        FrameLayout panelView = new FrameLayout(this);
        panelView.setBackgroundColor(Color.TRANSPARENT);
        panelView.setElevation(0f);
        panelView.setClipChildren(false);
        panelView.setClickable(true);
        panelView.setOnClickListener(v -> { });

        FolderBackgroundView background = new FolderBackgroundView(this);
        panelView.addView(background, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        BookmarkBoardView board = new BookmarkBoardView(this, FOLDER_COLUMNS, FOLDER_ROWS);
        board.setContainerId(null);
        board.setDragEnabled(false);
        board.setPadding(dp(10), dp(FOLDER_TITLE_HEIGHT_DP + 8), dp(10), dp(10));
        board.setListener(new BookmarkBoardView.Listener() {
            @Override public void onOpen(BookmarkNode node, View anchor) {
                closeSearchResultsPanel();
                BookmarkNode fresh = repo.get(node.id);
                if (fresh == null || fresh.deletedAt != null) return;
                if (fresh.isFolder()) openFolderPanel(fresh, null);
                else if (fresh.isApp()) openApp(fresh);
                else if (fresh.isQr()) showQrPreview(fresh);
                else openBookmark(fresh);
            }
            @Override public void onLongPress(BookmarkNode node, View anchor) {
                BookmarkNode fresh = repo.get(node.id);
                if (fresh == null || fresh.deletedAt != null) return;
                if (fresh.isFolder()) showFolderProperties(fresh);
                else if (fresh.isApp()) showAppProperties(fresh);
                else if (fresh.isQr()) showQrProperties(fresh);
                else showBookmarkProperties(fresh);
            }
            @Override public void onPositionsChanged(List<BookmarkNode> nodes) { }
            @Override public void onExternalDrop(BookmarkNode dragged, int cellX, int cellY, List<BookmarkNode> residentNodes) { }
            @Override public void onCreateFolder(BookmarkNode dragged, BookmarkNode target) { }
            @Override public void onMoveIntoFolder(BookmarkNode dragged, BookmarkNode folder, View folderAnchor) { }
            @Override public void onHoverOpenFolder(BookmarkNode dragged, BookmarkNode folder, View folderAnchor) { }
            @Override public void onDragExited(BookmarkNode dragged) { }
            @Override public void onDragStateChanged(boolean active, BookmarkNode node) { }
            @Override public void onEmptyLongPress(int cellX, int cellY) { }
            @Override public void onEmptySwipeDown() { }
            @Override public void onSearchWidgetMoved(int cellX, int cellY) { }
            @Override public void onPlusWidgetMoved(int cellX, int cellY) { }
            @Override public void onUrlAddRequested() { }
            @Override public void onSearchQuery(String query) { }
            @Override public List<BookmarkNode> onFolderPreview(BookmarkNode folder) {
                List<BookmarkNode> children = repo.children(folder.id);
                if (children.size() <= 4) return children;
                return new ArrayList<>(children.subList(0, 4));
            }
        });
        board.submit(visible);
        panelView.addView(board, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText("検索結果");
        title.setTextColor(N_TEXT);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        FrameLayout.LayoutParams titleLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(FOLDER_TITLE_HEIGHT_DP), Gravity.TOP);
        titleLp.setMargins(dp(14), dp(6), dp(14), 0);
        panelView.addView(title, titleLp);

        int rootWidth = Math.max(root.getWidth(), getResources().getDisplayMetrics().widthPixels);
        int rootHeight = Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels);
        int homeCellW = homeBoard.getCellWidthPx();
        int homeCellH = homeBoard.getCellHeightPx();
        int gap = Math.max(dp(6), homeBoard.getGapPx());
        if (homeCellW <= 0) homeCellW = Math.max(dp(48), (rootWidth - gap * (HOME_COLUMNS + 1)) / HOME_COLUMNS);
        if (homeCellH <= 0) homeCellH = homeCellW;
        int desiredWidth = dp(20) + gap * (FOLDER_COLUMNS + 1) + homeCellW * FOLDER_COLUMNS;
        int desiredHeight = dp(FOLDER_TITLE_HEIGHT_DP + 18) + gap * (FOLDER_ROWS + 1) + homeCellH * FOLDER_ROWS;
        int width = Math.min(desiredWidth, rootWidth - dp(28));
        int height = Math.min(desiredHeight, rootHeight - dp(120));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, height);
        lp.leftMargin = Math.max(dp(14), (rootWidth - width) / 2);
        lp.topMargin = Math.max(dp(14), (rootHeight - height) / 2);

        View backdrop = new View(this);
        backdrop.setBackgroundColor(Color.TRANSPARENT);
        backdrop.setClickable(true);
        backdrop.setOnClickListener(v -> closeSearchResultsPanel());
        searchResultsBackdrop = backdrop;
        searchResultsPanel = panelView;
        root.addView(backdrop, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(panelView, lp);
        panelView.setScaleX(0.94f);
        panelView.setScaleY(0.94f);
        panelView.setAlpha(0f);
        panelView.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L).setInterpolator(new DecelerateInterpolator()).start();
    }

    private void closeSearchResultsPanel() {
        if (searchResultsPanel != null) {
            searchResultsPanel.animate().cancel();
            root.removeView(searchResultsPanel);
            searchResultsPanel = null;
        }
        if (searchResultsBackdrop != null) {
            root.removeView(searchResultsBackdrop);
            searchResultsBackdrop = null;
        }
    }

    private void showExplorer(String parentId) {
        Intent intent = new Intent(this, NExplorerActivity.class);
        if (parentId != null) intent.putExtra(NExplorerActivity.EXTRA_START_FOLDER_ID, parentId);
        startActivity(intent);
    }

    private void openBookmark(BookmarkNode node) {
        if (node == null || node.isQr() || node.url == null || node.url.isBlank()) return;
        repo.touchAccess(node.id);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(node.url)));
        } catch (Exception e) {
            Toast.makeText(this, "URLを開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private void openApp(BookmarkNode node) {
        if (node == null || node.url == null || node.url.isBlank()) return;
        Intent launch = getPackageManager().getLaunchIntentForPackage(node.url);
        if (launch == null) {
            Toast.makeText(this, "アプリを開けません", Toast.LENGTH_SHORT).show();
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            repo.touchAccess(node.id);
            startActivity(launch);
        } catch (Exception e) {
            Toast.makeText(this, "アプリを開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private void openFolderPanel(BookmarkNode node, View anchor) {
        BookmarkNode fresh = repo.get(node.id);
        if (fresh == null || fresh.deletedAt != null) return;
        if (findPanelIndex(fresh.id) >= 0) return;

        int depth = 0;
        if (fresh.parentId != null) {
            int parentIndex = findPanelIndex(fresh.parentId);
            if (parentIndex >= 0) depth = parentIndex + 1;
        }
        closePanelsFromDepth(depth, true);

        FolderPanel panel = createFolderPanel(fresh, anchor, depth);
        folderPanels.add(panel);
        root.addView(panel.backdrop, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(panel.view, panel.layoutParams);
        panel.view.bringToFront();
        if (deleteFab.getVisibility() == View.VISIBLE) deleteFab.bringToFront();
        updatePanelDimming();
        animateOpen(panel);
    }

    private FolderPanel createFolderPanel(BookmarkNode folder, View anchor, int depth) {
        FrameLayout panelView = new FrameLayout(this);
        panelView.setBackgroundColor(Color.TRANSPARENT);
        panelView.setElevation(0f);
        panelView.setClipChildren(false);
        // Consume taps inside the folder surface. Only the transparent backdrop is allowed
        // to close the panel, so blank areas inside a folder never collapse it.
        panelView.setClickable(true);
        panelView.setOnClickListener(v -> { });

        FolderBackgroundView background = new FolderBackgroundView(this);
        panelView.addView(background, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        List<BookmarkNode> folderChildren = repo.children(folder.id);
        int folderRows = folderRowsFor(folderChildren);
        repo.ensurePositions(folder.id, FOLDER_COLUMNS, folderRows);
        folderChildren = repo.children(folder.id);
        folderRows = folderRowsFor(folderChildren);

        BookmarkBoardView board = new BookmarkBoardView(this, FOLDER_COLUMNS, folderRows);
        board.setContainerId(folder.id);
        board.setActiveDragItemId(activeDragItemId);
        // The title remains fixed above the scroll viewport. Only the icon grid scrolls.
        board.setPadding(dp(10), dp(8), dp(10), dp(10));
        bindBoard(board, folder.id);
        board.submit(folderChildren);

        ScrollView folderScroll = new ScrollView(this);
        folderScroll.setFillViewport(false);
        // Five rows fit without scrolling. A sixth row enables scrolling and is
        // deliberately previewed by half a tile at the bottom of the panel.
        boolean folderScrollable = folderRows > FOLDER_ROWS;
        folderScroll.setVerticalScrollBarEnabled(folderScrollable);
        folderScroll.setScrollbarFadingEnabled(true);
        folderScroll.setOverScrollMode(folderScrollable
                ? View.OVER_SCROLL_IF_CONTENT_SCROLLS
                : View.OVER_SCROLL_NEVER);
        folderScroll.addView(board, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        FrameLayout.LayoutParams scrollLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollLp.topMargin = dp(FOLDER_TITLE_HEIGHT_DP);
        panelView.addView(folderScroll, scrollLp);

        TextView title = new TextView(this);
        title.setText(folder.title);
        title.setTextColor(N_TEXT);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        FrameLayout.LayoutParams titleLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(FOLDER_TITLE_HEIGHT_DP), Gravity.TOP);
        titleLp.setMargins(dp(14), dp(6), dp(14), 0);
        panelView.addView(title, titleLp);

        int rootWidth = Math.max(root.getWidth(), getResources().getDisplayMetrics().widthPixels);
        int rootHeight = Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels);

        // Folder contents use the exact same cell metrics as the home workspace.
        // The folder stays 4 columns, but its panel is sized around the home 5-column
        // cell rather than shrinking/enlarging the icon and label component.
        int homeCellW = homeBoard.getCellWidthPx();
        int homeCellH = homeBoard.getCellHeightPx();
        int gap = Math.max(dp(6), homeBoard.getGapPx());
        if (homeCellW <= 0) {
            homeCellW = Math.max(dp(48), (rootWidth - gap * (HOME_COLUMNS + 1)) / HOME_COLUMNS);
        }
        if (homeCellH <= 0) homeCellH = homeCellW;
        board.setFixedCellHeightPx(homeCellH);

        int boardHorizontalPadding = dp(20); // 10dp each side
        int boardTopPadding = board.getPaddingTop();
        int boardBottomPadding = board.getPaddingBottom();
        int desiredWidth = boardHorizontalPadding + gap * (FOLDER_COLUMNS + 1) + homeCellW * FOLDER_COLUMNS;

        // Rows 1..5 use the original compact dialog height and never scroll. Only after
        // row 6 really exists do we extend the panel just enough to show half of row 6.
        int normalViewportHeight = boardTopPadding
                + boardBottomPadding
                + gap * (FOLDER_ROWS + 1)
                + homeCellH * FOLDER_ROWS;
        int expandedViewportHeight = boardTopPadding
                + gap * (FOLDER_ROWS + 1)
                + homeCellH * FOLDER_ROWS
                + homeCellH / 2;
        expandedViewportHeight = Math.max(normalViewportHeight, expandedViewportHeight);

        int width = Math.min(desiredWidth, rootWidth - dp(28));
        int maxPanelHeight = rootHeight - dp(120);
        int normalHeight = Math.min(dp(FOLDER_TITLE_HEIGHT_DP) + normalViewportHeight, maxPanelHeight);
        int expandedHeight = Math.min(dp(FOLDER_TITLE_HEIGHT_DP) + expandedViewportHeight, maxPanelHeight);
        int height = folderScrollable ? expandedHeight : normalHeight;
        int left = Math.max(dp(14), (rootWidth - width) / 2);
        int baseTop = Math.max(dp(90), (rootHeight - height) / 2);
        int top = Math.min(rootHeight - height - dp(14), baseTop + depth * dp(FOLDER_TITLE_HEIGHT_DP));
        top = Math.max(dp(14), top);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, height);
        lp.leftMargin = left;
        lp.topMargin = top;

        float[] origin = centerInRoot(anchor);
        View backdrop = new View(this);
        backdrop.setBackgroundColor(Color.TRANSPARENT);
        backdrop.setClickable(true);
        backdrop.setOnClickListener(v -> {
            int index = findPanelIndex(folder.id);
            if (index == folderPanels.size() - 1) closeTopPanel(false);
        });

        FolderPanel panel = new FolderPanel(folder.id, depth, panelView, background, board, folderScroll, title, backdrop,
                lp, normalHeight, expandedHeight, origin[0], origin[1]);
        configureFolderTitle(panel);
        return panel;
    }

    private void configureFolderTitle(FolderPanel panel) {
        final boolean[] pressed = {false};
        final boolean[] moving = {false};
        final boolean[] moved = {false};
        final float[] downRaw = new float[2];
        final int[] startPosition = new int[2];

        Runnable enterMoveMode = () -> {
            if (!pressed[0] || moved[0]) return;
            moving[0] = true;
            panel.title.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        };

        panel.title.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pressed[0] = true;
                    moving[0] = false;
                    moved[0] = false;
                    downRaw[0] = event.getRawX();
                    downRaw[1] = event.getRawY();
                    startPosition[0] = panel.layoutParams.leftMargin;
                    startPosition[1] = panel.layoutParams.topMargin;
                    v.postDelayed(enterMoveMode, 430L);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downRaw[0];
                    float dy = event.getRawY() - downRaw[1];
                    if (!moving[0] && dx * dx + dy * dy > dp(10) * dp(10)) {
                        moved[0] = true;
                        v.removeCallbacks(enterMoveMode);
                    }
                    if (moving[0]) {
                        moved[0] = true;
                        int rootW = Math.max(root.getWidth(), getResources().getDisplayMetrics().widthPixels);
                        int rootH = Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels);
                        int maxLeft = Math.max(dp(14), rootW - panel.layoutParams.width - dp(14));
                        int maxTop = Math.max(dp(14), rootH - panel.layoutParams.height - dp(14));
                        panel.layoutParams.leftMargin = clamp(startPosition[0] + Math.round(dx), dp(14), maxLeft);
                        panel.layoutParams.topMargin = clamp(startPosition[1] + Math.round(dy), dp(14), maxTop);
                        panel.view.setLayoutParams(panel.layoutParams);
                        root.post(MainActivity.this::updatePanelDimming);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    v.removeCallbacks(enterMoveMode);
                    boolean wasMoving = moving[0];
                    boolean wasMoved = moved[0];
                    pressed[0] = false;
                    moving[0] = false;
                    moved[0] = false;
                    if (!wasMoving && !wasMoved) renameFolder(panel.folderId);
                    return true;

                case MotionEvent.ACTION_CANCEL:
                    v.removeCallbacks(enterMoveMode);
                    pressed[0] = false;
                    moving[0] = false;
                    moved[0] = false;
                    return true;

                default:
                    return true;
            }
        });
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private int folderRowsFor(List<BookmarkNode> items) {
        if (items == null || items.isEmpty()) return FOLDER_ROWS;
        int usedSlots = 0;
        int maxBottom = 0;
        for (BookmarkNode item : items) {
            if (item == null || item.deletedAt != null) continue;
            int spanX = Math.max(1, Math.min(FOLDER_COLUMNS, item.spanX));
            int spanY = Math.max(1, item.spanY);
            usedSlots += spanX * spanY;
            if (item.cellY >= 0) maxBottom = Math.max(maxBottom, item.cellY + spanY);
        }
        // Do not reserve a sixth row while the first five rows still contain every item.
        // This also compacts stale row-6 positions left by older versions back into rows 1..5.
        int rowsByArea = (usedSlots + FOLDER_COLUMNS - 1) / FOLDER_COLUMNS;
        if (rowsByArea <= FOLDER_ROWS) return FOLDER_ROWS;
        return Math.max(rowsByArea, maxBottom);
    }

    private void renameFolder(String folderId) {
        BookmarkNode folder = repo.get(folderId);
        if (folder == null || folder.deletedAt != null) return;
        NDialog.showInput(this, "フォルダ名", "フォルダ名", folder.title, false, "保存", text -> {
            if (text.isBlank()) return;
            repo.rename(folderId, text);
            refreshAllVisible();
        });
    }

    private void showBookmarkProperties(BookmarkNode fresh) {
        if (fresh == null || fresh.deletedAt != null || fresh.isFolder() || fresh.isApp() || fresh.isQr()) return;
        final String detailId = fresh.id;
        activeBookmarkDetailsId = detailId;
        activeBookmarkDetails = NDialog.showBookmarkDetails(MainActivity.this, fresh,
                newName -> {
                    repo.renameDisplayName(detailId, newName);
                    refreshAllVisible();
                },
                callback -> {
                    BookmarkNode latest = repo.get(detailId);
                    if (latest == null) {
                        callback.onComplete(null, false);
                        return;
                    }
                    captureBookmark(latest, callback, true);
                },
                () -> {
                    BookmarkNode latest = repo.get(detailId);
                    if (latest != null) deleteNode(latest, true);
                },
                () -> {
                    BookmarkNode latest = repo.get(detailId);
                    if (latest == null || latest.url == null || latest.url.isBlank()) return;
                    showQrCreate(latest.displayName(), latest.url);
                },
                () -> {
                    BookmarkNode copy = repo.duplicateBookmarkToHome(detailId);
                    if (copy != null) {
                        refreshHome();
                        Toast.makeText(MainActivity.this, "ホームに複製しました", Toast.LENGTH_SHORT).show();
                    }
                },
                () -> addBookmarkToWishlist(detailId),
                new NDialog.OfflineActionsListener() {
                    @Override
                    public void onOpen() {
                        launchOfflineWeb(detailId, false);
                    }

                    @Override
                    public void onSaveOrUpdate() {
                        launchOfflineWeb(detailId, true);
                    }

                    @Override
                    public void onDelete() {
                        // Keep the bookmark property sheet visible behind this confirmation.
                        NDialog.showDeleteConfirmation(MainActivity.this, "オフライン保存を削除しますか？", () -> {
                            BookmarkNode latest = repo.get(detailId);
                            if (latest == null) return;
                            if (!OfflineStorage.deleteBookmarkSet(MainActivity.this, latest)) {
                                Toast.makeText(MainActivity.this, "オフライン保存の削除に失敗しました", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            repo.updateOfflineState(latest.id, null, null);
                            refreshAllVisible();
                            refreshActiveBookmarkOfflineState();
                            Toast.makeText(MainActivity.this, "オフライン保存を削除しました", Toast.LENGTH_SHORT).show();
                        });
                    }
                });
    }

    private void addBookmarkToWishlist(String nodeId) {
        BookmarkNode latest = repo.get(nodeId);
        if (latest == null || latest.url == null || latest.url.isBlank()) return;
        WishlistRepository wishRepo = new WishlistRepository(this);
        WishlistItem item = wishRepo.addFromBookmark(latest);
        if (item == null) {
            Toast.makeText(this, "Wishlistに追加できませんでした", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "Wishlistに追加しました", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            WishlistCrawler.Result result = WishlistCrawler.fetch(item.url);
            wishRepo.updateCrawl(item.id, result);
        }, "wishlist-first-crawl").start();
    }

    private void launchOfflineWeb(String nodeId, boolean autoSaveRoot) {
        Intent intent = new Intent(this, OfflineWebActivity.class);
        intent.putExtra(OfflineWebActivity.EXTRA_NODE_ID, nodeId);
        intent.putExtra(OfflineWebActivity.EXTRA_AUTO_SAVE_ROOT, autoSaveRoot);
        startActivityForResult(intent, REQ_OFFLINE_WEB);
    }

    private void refreshActiveBookmarkOfflineState() {
        if (activeBookmarkDetails == null || !activeBookmarkDetails.isShowing()) return;
        if (activeBookmarkDetailsId == null) return;
        BookmarkNode latest = repo.get(activeBookmarkDetailsId);
        boolean saved = latest != null && latest.offlineSavedAt != null;
        activeBookmarkDetails.setOfflineSaved(saved);
    }

    private void showAppProperties(BookmarkNode fresh) {
        if (fresh == null || fresh.deletedAt != null || !fresh.isApp()) return;
        NDialog.showAppDetails(MainActivity.this, fresh,
                newName -> {
                    repo.renameDisplayName(fresh.id, newName);
                    refreshAllVisible();
                },
                () -> deleteNode(fresh, true));
    }

    private void showFolderProperties(BookmarkNode fresh) {
        if (fresh == null || fresh.deletedAt != null || !fresh.isFolder()) return;
        NDialog.showFolderDetails(MainActivity.this, fresh, repo.countChildren(fresh.id),
                newName -> {
                    repo.renameDisplayName(fresh.id, newName);
                    refreshAllVisible();
                },
                protectContents -> deleteNode(fresh, protectContents));
    }

    private void deleteNode(BookmarkNode node, boolean protectFolderContents) {
        BookmarkNode fresh = repo.get(node.id);
        if (fresh == null || fresh.deletedAt != null) return;

        String confirmMessage = fresh.isFolder() && !protectFolderContents
                ? "フォルダと中身を削除しますか？"
                : "削除しますか？";
        final String nodeId = fresh.id;
        NDialog.showDeleteConfirmation(this, confirmMessage,
                () -> performDeleteNode(nodeId, protectFolderContents));
    }

    private void performDeleteNode(String nodeId, boolean protectFolderContents) {
        BookmarkNode fresh = repo.get(nodeId);
        if (fresh == null || fresh.deletedAt != null) return;
        if (fresh.isFolder()) {
            if (protectFolderContents) repo.deletePreservingFolderChildren(fresh.id);
            else repo.deleteRecursive(fresh.id);
            int index = findPanelIndex(fresh.id);
            if (index >= 0) closePanelsFromDepth(index, true);
        } else {
            repo.softDelete(fresh.id);
        }
        refreshAllVisible();
    }

    private boolean handleRootDrag(View v, DragEvent e) {
        Object local = e.getLocalState();
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return local instanceof BookmarkTileView || local instanceof SearchWidgetView || local instanceof UrlAddWidgetView;

            case DragEvent.ACTION_DRAG_LOCATION:
                // Coordinates are tracked centrally by DragCoordinatorLayout before child dispatch.
                return true;

            case DragEvent.ACTION_DROP:
                cancelRootFolderHover();
                if (activeDragTile == null) return true;
                float[] dropScreen = rootPointToScreen(e.getX(), e.getY());
                if (pointInsideView(deleteFab, dropScreen[0], dropScreen[1])) return true;
                FolderPanel top = topPanelAt(dropScreen[0], dropScreen[1]);
                if (top != null && dragOpenedPanels.contains(top.folderId)) {
                    top.board.coordinatorDrop(activeDragTile, dropScreen[0], dropScreen[1]);
                }
                return true;

            case DragEvent.ACTION_DRAG_ENDED:
                return true;

            default:
                return true;
        }
    }

    private void handleGlobalDragEvent(DragEvent e) {
        Object local = e.getLocalState();
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                cancelRootFolderHover();
                dragOpenedPanels.clear();
                lastDragScreenX = Float.NaN;
                lastDragScreenY = Float.NaN;
                activeDragTile = local instanceof BookmarkTileView ? (BookmarkTileView) local : null;
                setActiveDragItemId(activeDragTile == null ? null : activeDragTile.getNode().id);
                for (FolderPanel panel : folderPanels) panel.dragExitArmed = false;
                // If a drag begins inside an already-open folder, arm that topmost folder from
                // the source icon's real screen position so a direct outward drag cannot be lost.
                if (activeDragTile != null) {
                    int[] loc = new int[2];
                    activeDragTile.getLocationOnScreen(loc);
                    lastDragScreenX = loc[0] + activeDragTile.getWidth() / 2f;
                    lastDragScreenY = loc[1] + activeDragTile.getHeight() / 2f;
                    handleDragPanelBoundaries(lastDragScreenX, lastDragScreenY);
                }
                break;

            case DragEvent.ACTION_DRAG_LOCATION:
                if (activeDragTile == null) break;
                float[] screen = rootPointToScreen(e.getX(), e.getY());
                lastDragScreenX = screen[0];
                lastDragScreenY = screen[1];
                handleDragPanelBoundaries(screen[0], screen[1]);
                updateRootFolderHover(screen[0], screen[1]);
                break;

            case DragEvent.ACTION_DROP:
                if (activeDragTile != null) {
                    float[] drop = rootPointToScreen(e.getX(), e.getY());
                    lastDragScreenX = drop[0];
                    lastDragScreenY = drop[1];
                }
                break;

            case DragEvent.ACTION_DRAG_ENDED:
                cancelRootFolderHover();
                activeDragTile = null;
                setActiveDragItemId(null);
                dragOpenedPanels.clear();
                lastDragScreenX = Float.NaN;
                lastDragScreenY = Float.NaN;
                for (FolderPanel panel : folderPanels) panel.dragExitArmed = false;
                break;
        }
    }

    private void updateRootFolderHover(float screenX, float screenY) {
        BookmarkTileView target = findTopFolderTarget(screenX, screenY);
        if (target == rootHoverFolderTarget) return;
        cancelRootFolderHover();
        rootHoverFolderTarget = target;
        if (target != null) root.postDelayed(rootFolderOpenRunnable, 650L);
    }

    private void markDragOpenedPanel(String folderId) {
        int index = findPanelIndex(folderId);
        if (index < 0) return;
        dragOpenedPanels.add(folderId);
        // Do not arm EXIT while the panel is animating. animateOpen() re-checks the last
        // screen coordinate against the settled bounds so a stationary hover is handled too.
        folderPanels.get(index).dragExitArmed = false;
    }

    private void cancelRootFolderHover() {
        if (root != null) root.removeCallbacks(rootFolderOpenRunnable);
        rootHoverFolderTarget = null;
    }

    private BookmarkTileView findTopFolderTarget(float screenX, float screenY) {
        for (int i = folderPanels.size() - 1; i >= 0; i--) {
            FolderPanel panel = folderPanels.get(i);
            if (!pointInsideView(panel.view, screenX, screenY)) continue;
            return panel.board.findFolderTargetAtScreen(screenX, screenY, activeDragTile);
        }
        return homeBoard == null ? null : homeBoard.findFolderTargetAtScreen(screenX, screenY, activeDragTile);
    }

    private void handleDragPanelBoundaries(float screenX, float screenY) {
        if (folderPanels.isEmpty() || activeDragTile == null) return;

        // Only the topmost panel participates. A parent can never close while a child is open.
        FolderPanel top = folderPanels.get(folderPanels.size() - 1);
        if (top.openingOrClosing || top.view.getWidth() <= 0 || top.view.getHeight() <= 0) return;

        RectF bounds = boundsOnScreen(top.view);
        RectF armBounds = new RectF(bounds);
        float armInset = dp(FOLDER_ARM_INSET_DP);
        if (armBounds.width() > armInset * 2f && armBounds.height() > armInset * 2f) {
            armBounds.inset(armInset, armInset);
        }

        RectF exitBounds = new RectF(bounds);
        float hysteresis = dp(FOLDER_EXIT_HYSTERESIS_DP);
        exitBounds.inset(-hysteresis, -hysteresis);

        // After a child panel closes, never reinterpret that same drag coordinate as a fresh
        // "entered parent" event. The parent is quarantined for one second and must observe
        // a genuine outside -> inside -> outside sequence before it may close.
        if (top.requireOutsideBeforeRearm) {
            boolean outside = !exitBounds.contains(screenX, screenY);
            if (outside) top.sawOutsideAfterChildClose = true;

            if (SystemClock.uptimeMillis() < top.rearmNotBeforeUptime) return;
            if (!top.sawOutsideAfterChildClose) return;

            if (!top.dragExitArmed) {
                if (armBounds.contains(screenX, screenY)) {
                    top.dragExitArmed = true;
                    top.requireOutsideBeforeRearm = false;
                }
                return;
            }
        }

        if (!top.dragExitArmed) {
            if (armBounds.contains(screenX, screenY)) top.dragExitArmed = true;
            return;
        }

        if (exitBounds.contains(screenX, screenY)) return;

        closeTopPanel(true);
        cancelRootFolderHover();
    }

    private RectF boundsOnScreen(View view) {
        int[] loc = new int[2];
        view.getLocationOnScreen(loc);
        return new RectF(loc[0], loc[1], loc[0] + view.getWidth(), loc[1] + view.getHeight());
    }

    private FolderPanel topPanelAt(float screenX, float screenY) {
        for (int i = folderPanels.size() - 1; i >= 0; i--) {
            FolderPanel panel = folderPanels.get(i);
            if (pointInsideView(panel.view, screenX, screenY)) return panel;
        }
        return null;
    }

    private boolean pointInsideView(View view, float screenX, float screenY) {
        if (view == null || view.getVisibility() != View.VISIBLE) return false;
        int[] loc = new int[2];
        view.getLocationOnScreen(loc);
        return screenX >= loc[0] && screenX <= loc[0] + view.getWidth()
                && screenY >= loc[1] && screenY <= loc[1] + view.getHeight();
    }

    private float[] rootPointToScreen(float rootX, float rootY) {
        int[] loc = new int[2];
        root.getLocationOnScreen(loc);
        return new float[]{loc[0] + rootX, loc[1] + rootY};
    }

    private boolean handleDeleteDrag(View v, DragEvent e) {
        if (!(e.getLocalState() instanceof BookmarkTileView)
                && !(e.getLocalState() instanceof SearchWidgetView)
                && !(e.getLocalState() instanceof UrlAddWidgetView)) return false;
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return true;
            case DragEvent.ACTION_DRAG_ENTERED:
                deleteFab.setScaleX(1.12f);
                deleteFab.setScaleY(1.12f);
                return true;
            case DragEvent.ACTION_DRAG_EXITED:
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                return true;
            case DragEvent.ACTION_DROP:
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                if (e.getLocalState() instanceof SearchWidgetView) {
                    prefs.edit().putBoolean(KEY_SEARCH_ENABLED, false).apply();
                    refreshHome();
                    return true;
                }
                if (e.getLocalState() instanceof UrlAddWidgetView) {
                    prefs.edit().putBoolean(KEY_PLUS_ENABLED, false).apply();
                    refreshHome();
                    return true;
                }
                BookmarkNode node = ((BookmarkTileView) e.getLocalState()).getNode();
                BookmarkNode fresh = repo.get(node.id);
                // Drag-to-delete is deliberately safe: folders use the default protection behavior.
                if (fresh != null) deleteNode(fresh, true);
                return true;
            case DragEvent.ACTION_DRAG_ENDED:
                deleteFab.setScaleX(1f);
                deleteFab.setScaleY(1f);
                setDeleteTargetVisible(false);
                return true;
            default:
                return true;
        }
    }

    private void setDeleteTargetVisible(boolean visible) {
        deleteFab.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (visible) {
            deleteFab.setAlpha(0f);
            deleteFab.setScaleX(0.85f);
            deleteFab.setScaleY(0.85f);
            deleteFab.bringToFront();
            deleteFab.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(120).start();
        }
    }

    private boolean hasOpenChildPanel(String folderId) {
        if (folderId == null) return false;
        int index = findPanelIndex(folderId);
        if (index < 0 || index + 1 >= folderPanels.size()) return false;
        BookmarkNode child = repo.get(folderPanels.get(index + 1).folderId);
        return child != null && folderId.equals(child.parentId);
    }

    private void closeTopPanel(boolean fromDrag) {
        if (folderPanels.isEmpty()) return;
        FolderPanel top = folderPanels.remove(folderPanels.size() - 1);
        dragOpenedPanels.remove(top.folderId);
        animateClose(top, fromDrag);

        if (fromDrag && !folderPanels.isEmpty()) {
            FolderPanel parent = folderPanels.get(folderPanels.size() - 1);
            parent.dragExitArmed = false;
            parent.requireOutsideBeforeRearm = true;
            parent.sawOutsideAfterChildClose = false;
            parent.rearmNotBeforeUptime = SystemClock.uptimeMillis() + PARENT_REARM_COOLDOWN_MS;
        }
        updatePanelDimming();
    }

    private void closeFolderForDrag(String folderId) {
        int index = findPanelIndex(folderId);
        if (index < 0) return;
        for (int i = folderPanels.size() - 1; i >= index; i--) {
            FolderPanel panel = folderPanels.remove(i);
            dragOpenedPanels.remove(panel.folderId);
            animateClose(panel, true);
        }
        updatePanelDimming();
    }

    private void closePanelsFromDepth(int depth, boolean animate) {
        for (int i = folderPanels.size() - 1; i >= depth; i--) {
            FolderPanel panel = folderPanels.remove(i);
            dragOpenedPanels.remove(panel.folderId);
            if (animate) animateClose(panel, false);
            else {
                root.removeView(panel.view);
                root.removeView(panel.backdrop);
            }
        }
        updatePanelDimming();
    }

    private int findPanelIndex(String folderId) {
        for (int i = 0; i < folderPanels.size(); i++) {
            if (folderPanels.get(i).folderId.equals(folderId)) return i;
        }
        return -1;
    }

    private void updatePanelDimming() {
        // Every folder surface itself stays fully opaque. Only geometric overlap regions receive
        // dark overlays, producing an alpha-stacking look without exposing the home screen or
        // reducing icon/text opacity. Multiple underlying panels mean repeated paint and deeper black.
        for (int i = 0; i < folderPanels.size(); i++) {
            FolderPanel current = folderPanels.get(i);
            List<RectF> localOverlaps = new ArrayList<>();
            if (current.view.getWidth() > 0 && current.view.getHeight() > 0) {
                RectF currentScreen = boundsOnScreen(current.view);
                // Store each lower panel's FULL rounded-rect bounds in current-local coordinates.
                // FolderBackgroundView clips the shade by both rounded outlines, so overlap corners
                // never turn into square rectangles even when several panels are stacked.
                for (int j = 0; j < i; j++) {
                    FolderPanel below = folderPanels.get(j);
                    if (below.view.getWidth() <= 0 || below.view.getHeight() <= 0) continue;
                    RectF belowScreen = boundsOnScreen(below.view);
                    RectF intersection = new RectF(currentScreen);
                    if (!intersection.intersect(belowScreen)) continue;
                    RectF localBelow = new RectF(belowScreen);
                    localBelow.offset(-currentScreen.left, -currentScreen.top);
                    localOverlaps.add(localBelow);
                }
            }
            current.background.setOverlapRects(localOverlaps);
            current.view.setAlpha(1f);
        }
    }

    private void animateOpen(FolderPanel panel) {
        float targetCenterX = panel.layoutParams.leftMargin + panel.layoutParams.width / 2f;
        float targetCenterY = panel.layoutParams.topMargin + panel.layoutParams.height / 2f;
        panel.openingOrClosing = true;
        panel.view.setPivotX(panel.layoutParams.width / 2f);
        panel.view.setPivotY(panel.layoutParams.height / 2f);
        panel.view.setScaleX(0.16f);
        panel.view.setScaleY(0.16f);
        panel.view.setTranslationX(panel.originX - targetCenterX);
        panel.view.setTranslationY(panel.originY - targetCenterY);
        panel.view.setAlpha(1f);
        panel.view.animate()
                .scaleX(1f).scaleY(1f)
                .translationX(0f).translationY(0f)
                .setInterpolator(new DecelerateInterpolator())
                .setDuration(190)
                .withEndAction(() -> {
                    panel.openingOrClosing = false;
                    panel.view.setAlpha(1f);
                    updatePanelDimming();
                    if (activeDragTile != null && !Float.isNaN(lastDragScreenX) && !Float.isNaN(lastDragScreenY)) {
                        handleDragPanelBoundaries(lastDragScreenX, lastDragScreenY);
                    }
                })
                .start();
    }

    private void animateClose(FolderPanel panel, boolean fromDrag) {
        float targetCenterX = panel.layoutParams.leftMargin + panel.layoutParams.width / 2f;
        float targetCenterY = panel.layoutParams.topMargin + panel.layoutParams.height / 2f;
        panel.openingOrClosing = true;
        panel.view.animate().cancel();
        if (fromDrag) root.removeView(panel.backdrop);
        panel.view.animate()
                .scaleX(0.16f).scaleY(0.16f)
                .translationX(panel.originX - targetCenterX)
                .translationY(panel.originY - targetCenterY)
                .setDuration(fromDrag ? 130 : 170)
                .withEndAction(() -> {
                    panel.openingOrClosing = false;
                    root.removeView(panel.view);
                    root.removeView(panel.backdrop);
                    updatePanelDimming();
                })
                .start();
    }

    private float[] centerInRoot(View anchor) {
        if (anchor == null) {
            return new float[]{root.getWidth() / 2f, root.getHeight() / 2f};
        }
        int[] anchorLoc = new int[2];
        int[] rootLoc = new int[2];
        anchor.getLocationOnScreen(anchorLoc);
        root.getLocationOnScreen(rootLoc);
        return new float[]{
                anchorLoc[0] - rootLoc[0] + anchor.getWidth() / 2f,
                anchorLoc[1] - rootLoc[1] + anchor.getHeight() / 2f
        };
    }

    private void showAppPicker() {
        DiagLog.write(this, "APP_PICKER_OPEN");

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(16), dp(18), dp(16));
        box.setBackground(roundRect(N_FOLDER_BG, 18));

        TextView title = new TextView(this);
        title.setText("アプリを追加");
        title.setTextColor(N_TEXT);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER_VERTICAL);
        box.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("アプリ検索");
        search.setTextColor(N_TEXT);
        search.setHintTextColor(N_ICON);
        search.setTextSize(15);
        search.setPadding(dp(14), 0, dp(14), 0);
        search.setBackground(roundRect(N_DGRAY, 12));
        search.setEnabled(false);
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        searchLp.bottomMargin = dp(8);
        box.addView(search, searchLp);

        FrameLayout listFrame = new FrameLayout(this);
        ListView list = new ListView(this);
        list.setDividerHeight(0);
        list.setVerticalScrollBarEnabled(true);
        list.setCacheColorHint(Color.TRANSPARENT);
        listFrame.addView(list, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView empty = new TextView(this);
        empty.setText("読み込み中…");
        empty.setTextColor(N_ICON);
        empty.setTextSize(14);
        empty.setGravity(Gravity.CENTER);
        listFrame.addView(empty, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        list.setEmptyView(empty);

        int maxListHeight = Math.min(dp(520), Math.max(dp(260), getResources().getDisplayMetrics().heightPixels - dp(320)));
        box.addView(listFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, maxListHeight));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        TextView count = new TextView(this);
        count.setTextColor(N_TEXT);
        count.setTextSize(14);
        count.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        actions.addView(count, new LinearLayout.LayoutParams(0, dp(48), 1f));

        TextView cancel = pickerAction("キャンセル");
        TextView add = pickerAction("追加");
        TextView close = pickerAction("閉じる");
        cancel.setVisibility(View.GONE);
        add.setVisibility(View.GONE);
        actions.addView(cancel, new LinearLayout.LayoutParams(dp(96), dp(44)));
        actions.addView(add, new LinearLayout.LayoutParams(dp(84), dp(44)));
        actions.addView(close, new LinearLayout.LayoutParams(dp(84), dp(44)));
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        actionsLp.topMargin = dp(10);
        box.addView(actions, actionsLp);

        AppPickerAdapter adapter = new AppPickerAdapter(getPackageManager());
        list.setAdapter(adapter);

        Runnable refreshSelectionUi = () -> {
            int selected = adapter.selectedCount();
            boolean selecting = adapter.isSelectionMode();
            count.setText(selecting ? selected + "件選択" : "");
            cancel.setVisibility(selecting ? View.VISIBLE : View.GONE);
            add.setVisibility(selecting ? View.VISIBLE : View.GONE);
            close.setVisibility(selecting ? View.GONE : View.VISIBLE);
            add.setEnabled(selected > 0);
            add.setAlpha(selected > 0 ? 1f : 0.45f);
        };

        adapter.setListener(new AppPickerAdapter.Listener() {
            @Override public void onSingleAdd(AppEntry app) {
                try {
                    repo.createAppShortcut(null, app.label, app.component.getPackageName());
                    refreshHome();
                    DiagLog.write(MainActivity.this, "APP_PICKER_ADD_SINGLE package=" + app.component.getPackageName());
                    dialog.dismiss();
                    Toast.makeText(MainActivity.this, "ホームに追加しました", Toast.LENGTH_SHORT).show();
                } catch (Throwable t) {
                    DiagLog.write(MainActivity.this, "APP_PICKER_ADD_SINGLE_ERROR " + DiagLog.stackTrace(t));
                    Toast.makeText(MainActivity.this, "アプリ追加に失敗しました", Toast.LENGTH_SHORT).show();
                }
            }

            @Override public void onSelectionChanged() { refreshSelectionUi.run(); }
        });

        cancel.setOnClickListener(v -> {
            adapter.clearSelection();
            refreshSelectionUi.run();
        });
        add.setOnClickListener(v -> {
            List<AppEntry> selected = adapter.getSelectedEntries();
            if (selected.isEmpty()) return;
            int free = homeFreeCellCount();
            if (free <= 0) {
                Toast.makeText(this, "ホームに空きがありません", Toast.LENGTH_SHORT).show();
                return;
            }
            int added = 0;
            try {
                for (AppEntry app : selected) {
                    if (added >= free) break;
                    repo.createAppShortcut(null, app.label, app.component.getPackageName());
                    added++;
                }
                refreshHome();
                DiagLog.write(this, "APP_PICKER_ADD_MULTI selected=" + selected.size() + " added=" + added + " freeBefore=" + free);
                dialog.dismiss();
                if (added < selected.size()) {
                    Toast.makeText(this, added + "件追加しました（ホームの空きまで）", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, added + "件追加しました", Toast.LENGTH_SHORT).show();
                }
            } catch (Throwable t) {
                DiagLog.write(this, "APP_PICKER_ADD_MULTI_ERROR " + DiagLog.stackTrace(t));
                Toast.makeText(this, "アプリ追加に失敗しました", Toast.LENGTH_SHORT).show();
            }
        });
        close.setOnClickListener(v -> dialog.dismiss());

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int countValue) {
                adapter.filter(s == null ? "" : s.toString());
                empty.setText(adapter.getCount() == 0 ? "見つかりません" : "");
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        dialog.setOnDismissListener(d -> {
            adapter.release();
            DiagLog.write(MainActivity.this, "APP_PICKER_DISMISS");
        });

        dialog.setContentView(box);
        dialog.show();
        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            android.view.WindowManager.LayoutParams lp = new android.view.WindowManager.LayoutParams();
            lp.copyFrom(w.getAttributes());
            lp.width = getResources().getDisplayMetrics().widthPixels - dp(30);
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            w.setAttributes(lp);
        }
        DiagLog.write(this, "APP_PICKER_DIALOG_SHOWN");

        ExecutorService loader = Executors.newSingleThreadExecutor();
        adapter.setLoader(loader);
        loader.execute(() -> {
            PackageManager pm = getPackageManager();
            try {
                DiagLog.write(MainActivity.this, "APP_PICKER_QUERY_START");
                Intent query = new Intent(Intent.ACTION_MAIN);
                query.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> resolved = pm.queryIntentActivities(query, PackageManager.MATCH_ALL);
                DiagLog.write(MainActivity.this, "APP_PICKER_QUERY_RESULT count=" + resolved.size());

                Map<String, AppEntry> byPackage = new LinkedHashMap<>();
                for (ResolveInfo info : resolved) {
                    if (Thread.currentThread().isInterrupted()) return;
                    if (info.activityInfo == null || info.activityInfo.packageName == null || info.activityInfo.name == null) continue;
                    String packageName = info.activityInfo.packageName;
                    if (getPackageName().equals(packageName)) continue;
                    CharSequence rawLabel;
                    try { rawLabel = info.loadLabel(pm); }
                    catch (Throwable labelError) {
                        DiagLog.write(MainActivity.this, "APP_PICKER_LABEL_ERROR package=" + packageName + " " + labelError.getClass().getSimpleName());
                        rawLabel = packageName;
                    }
                    String label = rawLabel == null || rawLabel.toString().isBlank() ? packageName : rawLabel.toString();
                    ComponentName component = new ComponentName(packageName, info.activityInfo.name);
                    if (!byPackage.containsKey(packageName)) byPackage.put(packageName, new AppEntry(label, component, info));
                }
                List<AppEntry> apps = new ArrayList<>(byPackage.values());
                apps.sort((a, b) -> a.label.compareToIgnoreCase(b.label));
                DiagLog.write(MainActivity.this, "APP_PICKER_READY count=" + apps.size());
                runOnUiThread(() -> {
                    if (!dialog.isShowing()) return;
                    adapter.setApps(apps);
                    search.setEnabled(true);
                    empty.setText(apps.isEmpty() ? "追加できるアプリがありません" : "");
                    if (apps.isEmpty()) Toast.makeText(MainActivity.this, "追加できるアプリがありません", Toast.LENGTH_SHORT).show();
                });
            } catch (Throwable t) {
                DiagLog.write(MainActivity.this, "APP_PICKER_QUERY_ERROR " + DiagLog.stackTrace(t));
                runOnUiThread(() -> {
                    if (!dialog.isShowing()) return;
                    empty.setText("アプリ一覧の取得に失敗しました");
                    Toast.makeText(MainActivity.this, "アプリ一覧の取得に失敗しました", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private TextView pickerAction(String label) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextColor(N_TEXT);
        view.setTextSize(15);
        view.setGravity(Gravity.CENTER);
        view.setBackground(roundRect(N_LBLUE, 999));
        return view;
    }

    private int homeFreeCellCount() {
        int capacity = HOME_COLUMNS * HOME_ROWS;
        if (isSearchEnabled()) capacity -= 4;
        if (isPlusEnabled()) capacity -= 1;
        return Math.max(0, capacity - repo.children(null).size());
    }

    private Bitmap loadScaledAppIcon(AppEntry app, PackageManager pm) {
        int size = dp(42);
        try {
            Drawable drawable = app.resolveInfo.loadIcon(pm);
            if (drawable == null) return null;
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, size, size);
            drawable.draw(canvas);
            return bitmap;
        } catch (OutOfMemoryError oom) {
            DiagLog.write(this, "APP_PICKER_ICON_OOM package=" + app.component.getPackageName());
            return null;
        } catch (Throwable t) {
            DiagLog.write(this, "APP_PICKER_ICON_ERROR package=" + app.component.getPackageName() + " " + t.getClass().getSimpleName());
            return null;
        }
    }

    private void showPrimaryAddMenu() {
        String[] items = {"ブックマーク", "アプリを追加", "QR作成"};
        NDialog.showPlainMenu(this, null, items, which -> {
            if (which == 0) showAddBookmark(null);
            else if (which == 1) showAppPicker();
            else if (which == 2) showQrCreate();
        });
    }

    private void showQrCreate() {
        showQrCreate(null, null);
    }

    private void showQrCreate(String initialName, String initialValue) {
        NDialog.showQrCreate(this, this::scanQrCode, this::openQrImageExplorer,
                initialName, initialValue, (name, value) -> {
            if (value == null || value.isBlank()) return;
            BookmarkNode created = repo.createQr(null, name, value);
            refreshHome();
            DiagLog.write(this, "QR_CREATE id=" + created.id + " length=" + value.length());
        });
    }

    private void openQrImageExplorer(NDialog.QrScanCallback callback) {
        pendingQrImageCallback = callback;
        Intent intent = new Intent(this, NExplorerActivity.class);
        intent.putExtra(NExplorerActivity.EXTRA_MODE, NExplorerActivity.MODE_IMAGE_PICK);
        startActivityForResult(intent, REQ_QR_IMAGE);
    }

    private void scanQrCode(NDialog.QrScanCallback callback) {
        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .enableAutoZoom()
                .build();
        GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
        scanner.startScan()
                .addOnSuccessListener(barcode -> {
                    String raw = barcode.getRawValue();
                    if (raw == null || raw.isBlank()) {
                        if (callback != null) callback.onError("QRの内容を取得できませんでした");
                        return;
                    }
                    DiagLog.write(this, "QR_SCAN_SUCCESS length=" + raw.length());
                    if (callback != null) callback.onScanned(raw);
                })
                .addOnCanceledListener(() -> {
                    DiagLog.write(this, "QR_SCAN_CANCEL");
                    if (callback != null) callback.onError(null);
                })
                .addOnFailureListener(e -> {
                    DiagLog.write(this, "QR_SCAN_ERROR " + e.getClass().getSimpleName() + ": " + e.getMessage());
                    if (callback != null) callback.onError("QR撮影を開始できませんでした");
                });
    }

    private void showQrPreview(BookmarkNode node) {
        if (node == null || !node.isQr()) return;
        NDialog.showQrPreview(this, node, () -> saveQrPng(node));
    }

    private void showQrProperties(BookmarkNode fresh) {
        if (fresh == null || fresh.deletedAt != null || !fresh.isQr()) return;
        final String nodeId = fresh.id;
        NDialog.showQrDetails(this, fresh,
                newName -> {
                    repo.renameDisplayName(nodeId, newName);
                    refreshAllVisible();
                },
                () -> copyQrPayload(fresh.url),
                () -> saveQrPng(repo.get(nodeId)),
                () -> {
                    BookmarkNode latest = repo.get(nodeId);
                    if (latest != null) deleteNode(latest, true);
                });
    }

    private void copyQrPayload(String value) {
        if (value == null) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null) return;
        clipboard.setPrimaryClip(ClipData.newPlainText("QR", value));
        Toast.makeText(this, "QR内容をコピーしました", Toast.LENGTH_SHORT).show();
    }

    private void saveQrPng(BookmarkNode node) {
        if (node == null || !node.isQr() || node.url == null || node.url.isBlank()) return;
        try {
            QrUtils.savePng(this, node.displayName(), node.url);
            Toast.makeText(this, "Pictures/BookmarkLauncher にPNG保存しました", Toast.LENGTH_SHORT).show();
            DiagLog.write(this, "QR_PNG_SAVE id=" + node.id);
        } catch (Exception e) {
            DiagLog.write(this, "QR_PNG_SAVE_ERROR " + DiagLog.stackTrace(e));
            Toast.makeText(this, "PNG保存に失敗しました", Toast.LENGTH_SHORT).show();
        }
    }

    private void showAddDialog(String parentId) {
        String[] items = {"URLを追加", "フォルダを追加", "アプリを追加"};
        NDialog.showChoices(this, "追加", items, -1, which -> {
            if (which == 0) showAddBookmark(parentId);
            else if (which == 1) showAddFolder(parentId);
            else showAppPicker();
        });
    }

    private void showAddBookmark(String parentId) {
        NDialog.showInput(this, "ブックマーク追加", "https://example.com", "", true, "追加", text -> {
            String url = text;
            if (url.isEmpty()) return;
            if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
            BookmarkNode created = repo.createBookmark(parentId, url, url);
            refreshAllVisible();
            captureBookmark(created, null, false);
        });
    }

    private void showAddFolder(String parentId) {
        NDialog.showInput(this, "フォルダ追加", "フォルダ名", "", false, "追加", text -> {
            repo.createFolder(parentId, text);
            refreshAllVisible();
        });
    }

    private void handleIncoming(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if (text == null) return;
        CharSequence subject = intent.getCharSequenceExtra(Intent.EXTRA_SUBJECT);
        Matcher m = URL_PATTERN.matcher(text);
        if (m.find()) {
            String url = m.group();
            String mapsTitle = GoogleMapsModule.resolveSharedTitle(text, subject, url);
            String initialTitle;
            if (mapsTitle != null) {
                initialTitle = mapsTitle;
            } else if (subject != null && !subject.toString().isBlank()) {
                initialTitle = subject.toString().trim();
            } else {
                initialTitle = url;
            }
            BookmarkNode created = repo.createBookmark(null, initialTitle, url);
            refreshHome();
            Toast.makeText(this, "ブックマークに追加しました", Toast.LENGTH_SHORT).show();
            captureBookmark(created, null, false);
        }
    }

    private void captureBookmark(BookmarkNode node, NDialog.ThumbnailRefreshCallback callback, boolean showFailureToast) {
        if (captureManager == null || node == null || node.isQr() || node.isApp() || node.isFolder()) {
            if (callback != null) callback.onComplete(null, false);
            return;
        }
        captureManager.capture(node, (success, updatedNode, message) -> {
            refreshAllVisible();
            if (callback != null) callback.onComplete(updatedNode, success);
            if (!success && showFailureToast) {
                Toast.makeText(MainActivity.this, message == null ? "サムネイル取得に失敗しました" : message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void applyFolderPanelScrollState(FolderPanel panel, boolean scrollable) {
        panel.scroll.setVerticalScrollBarEnabled(scrollable);
        panel.scroll.setOverScrollMode(scrollable
                ? View.OVER_SCROLL_IF_CONTENT_SCROLLS
                : View.OVER_SCROLL_NEVER);
        if (!scrollable && panel.scroll.getScrollY() != 0) panel.scroll.scrollTo(0, 0);

        int targetHeight = scrollable ? panel.expandedHeight : panel.normalHeight;
        if (panel.layoutParams.height == targetHeight) return;

        // Grow/shrink around the current visual center so the panel does not jump when the
        // 21st item creates row 6. Clamp back inside the usable screen area if necessary.
        float centerY = panel.layoutParams.topMargin + panel.layoutParams.height / 2f;
        panel.layoutParams.height = targetHeight;
        int rootHeight = Math.max(root.getHeight(), getResources().getDisplayMetrics().heightPixels);
        int minTop = dp(14);
        int maxTop = Math.max(minTop, rootHeight - targetHeight - dp(14));
        panel.layoutParams.topMargin = clamp(Math.round(centerY - targetHeight / 2f), minTop, maxTop);
        panel.view.setLayoutParams(panel.layoutParams);
        panel.view.requestLayout();
    }

    private void refreshAllVisible() {
        refreshHome();

        for (int i = folderPanels.size() - 1; i >= 0; i--) {
            FolderPanel panel = folderPanels.get(i);
            BookmarkNode folder = repo.get(panel.folderId);
            if (folder == null || folder.deletedAt != null) {
                folderPanels.remove(i);
                dragOpenedPanels.remove(panel.folderId);
                    root.removeView(panel.view);
                root.removeView(panel.backdrop);
            }
        }

        List<FolderPanel> copy = new ArrayList<>(folderPanels);
        for (FolderPanel panel : copy) {
            BookmarkNode folder = repo.get(panel.folderId);
            if (folder == null || folder.deletedAt != null) continue;
            panel.title.setText(folder.title);
            List<BookmarkNode> children = repo.children(panel.folderId);
            int rows = folderRowsFor(children);
            repo.ensurePositions(panel.folderId, FOLDER_COLUMNS, rows);
            children = repo.children(panel.folderId);
            rows = folderRowsFor(children);
            panel.board.setRows(rows);
            boolean scrollable = rows > FOLDER_ROWS;
            applyFolderPanelScrollState(panel, scrollable);
            panel.board.submit(children);
        }
        updatePanelDimming();
    }

    private ImageView makeDeleteFab() {
        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.ic_close_vector);
        image.setScaleType(ImageView.ScaleType.CENTER);
        image.setContentDescription("削除");
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(Color.BLACK);
        d.setSize(dp(58), dp(58));
        image.setBackground(d);
        image.setElevation(0f);
        return image;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private final class AppPickerAdapter extends BaseAdapter {
        interface Listener {
            void onSingleAdd(AppEntry app);
            void onSelectionChanged();
        }

        private final PackageManager pm;
        private final List<AppEntry> allApps = new ArrayList<>();
        private final List<AppEntry> visibleApps = new ArrayList<>();
        private final Set<String> selectedPackages = new HashSet<>();
        private final Set<String> loadingIcons = java.util.Collections.synchronizedSet(new HashSet<>());
        private final LruCache<String, Bitmap> iconCache = new LruCache<String, Bitmap>(4096) {
            @Override protected int sizeOf(String key, Bitmap value) {
                return Math.max(1, value.getByteCount() / 1024);
            }
        };
        private Listener listener;
        private ExecutorService loader;
        private String query = "";
        private boolean selectionMode;
        private boolean released;

        AppPickerAdapter(PackageManager pm) { this.pm = pm; }

        void setListener(Listener listener) { this.listener = listener; }
        void setLoader(ExecutorService loader) { this.loader = loader; }

        void setApps(List<AppEntry> apps) {
            allApps.clear();
            if (apps != null) allApps.addAll(apps);
            filter(query);
        }

        void filter(String value) {
            query = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
            visibleApps.clear();
            for (AppEntry app : allApps) {
                if (query.isEmpty() || app.label.toLowerCase(Locale.ROOT).contains(query)) visibleApps.add(app);
            }
            notifyDataSetChanged();
        }

        int selectedCount() { return selectedPackages.size(); }
        boolean isSelectionMode() { return selectionMode; }

        void clearSelection() {
            selectionMode = false;
            selectedPackages.clear();
            notifyDataSetChanged();
            if (listener != null) listener.onSelectionChanged();
        }

        List<AppEntry> getSelectedEntries() {
            ArrayList<AppEntry> out = new ArrayList<>();
            for (AppEntry app : allApps) {
                if (selectedPackages.contains(app.component.getPackageName())) out.add(app);
            }
            return out;
        }

        void release() {
            released = true;
            if (loader != null) loader.shutdownNow();
            loadingIcons.clear();
            iconCache.evictAll();
        }

        private void toggle(AppEntry app) {
            String pkg = app.component.getPackageName();
            if (!selectedPackages.add(pkg)) selectedPackages.remove(pkg);
            selectionMode = !selectedPackages.isEmpty();
            notifyDataSetChanged();
            if (listener != null) listener.onSelectionChanged();
        }

        @Override public int getCount() { return visibleApps.size(); }
        @Override public AppEntry getItem(int position) { return visibleApps.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            final RowHolder holder;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(8), dp(5), dp(8), dp(5));
                row.setBackgroundColor(Color.TRANSPARENT);

                FrameLayout iconBox = new FrameLayout(MainActivity.this);
                ImageView icon = new ImageView(MainActivity.this);
                icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iconBox.addView(icon, new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER));

                TextView check = new TextView(MainActivity.this);
                check.setText("✓");
                check.setTextColor(Color.WHITE);
                check.setTextSize(15);
                check.setGravity(Gravity.CENTER);
                check.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
                check.setBackground(roundRect(0xFF227733, 999));
                FrameLayout.LayoutParams checkLp = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.END | Gravity.TOP);
                iconBox.addView(check, checkLp);
                row.addView(iconBox, new LinearLayout.LayoutParams(dp(50), dp(48)));

                TextView label = new TextView(MainActivity.this);
                label.setTextColor(N_TEXT);
                label.setTextSize(16);
                label.setSingleLine(true);
                label.setPadding(dp(10), 0, dp(8), 0);
                row.addView(label, new LinearLayout.LayoutParams(0, dp(52), 1f));

                holder = new RowHolder(row, icon, check, label);
                row.setTag(holder);
                convertView = row;
            } else {
                holder = (RowHolder) convertView.getTag();
            }

            AppEntry app = getItem(position);
            String pkg = app.component.getPackageName();
            holder.label.setText(app.label);
            holder.check.setVisibility(selectedPackages.contains(pkg) ? View.VISIBLE : View.GONE);
            holder.icon.setTag(pkg);
            Bitmap cached = iconCache.get(pkg);
            if (cached != null && !cached.isRecycled()) {
                holder.icon.setImageBitmap(cached);
            } else {
                holder.icon.setImageDrawable(null);
                ExecutorService ex = loader;
                if (ex != null && !ex.isShutdown() && loadingIcons.add(pkg)) {
                    ex.execute(() -> {
                        Bitmap bmp = null;
                        try {
                            if (!released) bmp = loadScaledAppIcon(app, pm);
                            if (bmp != null && !released) iconCache.put(pkg, bmp);
                            final Bitmap ready = bmp;
                            if (ready != null && !released) runOnUiThread(() -> {
                                if (released) return;
                                Object tag = holder.icon.getTag();
                                if (pkg.equals(tag)) holder.icon.setImageBitmap(ready);
                            });
                        } finally {
                            loadingIcons.remove(pkg);
                        }
                    });
                }
            }

            holder.row.setOnClickListener(v -> {
                if (selectionMode) toggle(app);
                else if (listener != null) listener.onSingleAdd(app);
            });
            holder.row.setOnLongClickListener(v -> {
                selectionMode = true;
                toggle(app);
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                return true;
            });
            return convertView;
        }

        private final class RowHolder {
            final LinearLayout row;
            final ImageView icon;
            final TextView check;
            final TextView label;
            RowHolder(LinearLayout row, ImageView icon, TextView check, TextView label) {
                this.row = row; this.icon = icon; this.check = check; this.label = label;
            }
        }
    }

    private static final class AppEntry {
        final String label;
        final ComponentName component;
        final ResolveInfo resolveInfo;

        AppEntry(String label, ComponentName component, ResolveInfo resolveInfo) {
            this.label = label;
            this.component = component;
            this.resolveInfo = resolveInfo;
        }
    }

    private static final class FolderPanel {
        final String folderId;
        final int depth;
        final FrameLayout view;
        final FolderBackgroundView background;
        final BookmarkBoardView board;
        final ScrollView scroll;
        final TextView title;
        final View backdrop;
        final FrameLayout.LayoutParams layoutParams;
        final int normalHeight;
        final int expandedHeight;
        final float originX;
        final float originY;
        boolean openingOrClosing;
        boolean dragExitArmed;
        boolean requireOutsideBeforeRearm;
        boolean sawOutsideAfterChildClose;
        long rearmNotBeforeUptime;

        FolderPanel(String folderId, int depth, FrameLayout view, FolderBackgroundView background,
                    BookmarkBoardView board, ScrollView scroll, TextView title, View backdrop,
                    FrameLayout.LayoutParams layoutParams, int normalHeight, int expandedHeight,
                    float originX, float originY) {
            this.folderId = folderId;
            this.depth = depth;
            this.view = view;
            this.background = background;
            this.board = board;
            this.scroll = scroll;
            this.title = title;
            this.backdrop = backdrop;
            this.layoutParams = layoutParams;
            this.normalHeight = normalHeight;
            this.expandedHeight = expandedHeight;
            this.originX = originX;
            this.originY = originY;
        }
    }

    private final class DragCoordinatorLayout extends FrameLayout {
        DragCoordinatorLayout(Context context) {
            super(context);
        }

        @Override
        public boolean dispatchDragEvent(DragEvent event) {
            if (event.getAction() != DragEvent.ACTION_DRAG_ENDED) handleGlobalDragEvent(event);
            boolean handled = super.dispatchDragEvent(event);
            if (event.getAction() == DragEvent.ACTION_DRAG_ENDED) handleGlobalDragEvent(event);
            return handled;
        }
    }

    private static final class FolderBackgroundView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path clip = new Path();
        private final List<RectF> overlaps = new ArrayList<>();
        private final float radius;

        FolderBackgroundView(Context context) {
            super(context);
            radius = 18f * context.getResources().getDisplayMetrics().density;
            setWillNotDraw(false);
        }

        void setOverlapRects(List<RectF> rects) {
            overlaps.clear();
            for (RectF rect : rects) overlaps.add(new RectF(rect));
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            RectF whole = new RectF(0, 0, getWidth(), getHeight());
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(N_FOLDER_BG);
            canvas.drawRoundRect(whole, radius, radius, paint);
            if (overlaps.isEmpty()) return;

            paint.setColor(FOLDER_OVERLAP_SHADE);
            for (RectF overlap : overlaps) {
                canvas.save();
                // Clip by this panel's round rect AND the overlapping panel's round rect.
                // This produces an opaque "alpha-like" darkening while preserving both panels'
                // corner radii instead of painting a square intersection rectangle.
                clip.reset();
                clip.addRoundRect(whole, radius, radius, Path.Direction.CW);
                canvas.clipPath(clip);
                Path other = new Path();
                other.addRoundRect(overlap, radius, radius, Path.Direction.CW);
                canvas.clipPath(other);
                canvas.drawRect(whole, paint);
                canvas.restore();
            }
        }
    }
}
