package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;

/** Read-only item-bound image selection for exact SHEIN and AliExpress URLs.
 * This never falls back to page-wide OG banners or unrelated recommendation tiles. */
final class WishlistGeneralMarketplaceImageDom {
    private WishlistGeneralMarketplaceImageDom() { }

    static String javascript(URL itemUrl) {
        String id = WishlistGeneralMarketplaceIdentity.itemId(itemUrl);
        if (id == null) return "'[]'";
        final String script = """
(function(){'use strict';try{
 const expected='__EXPECTED__';
 const originalHost='__HOST__';
 const shein=originalHost.endsWith('shein.com');
 const itemId=p=>{
  const m=shein?String(p).match(/(?:^|[-/])p-([0-9]{5,15})(?:-cat-[0-9]{1,12})?\\.html$/i):String(p).match(/^\\/(?:item|i)\\/([0-9]{9,19})\\.html$/i);
  return m?m[1]:'';
 };
 const host=location.hostname.toLowerCase();
 if(!(shein?(host==='shein.com'||host.endsWith('.shein.com')):(host==='aliexpress.com'||host.endsWith('.aliexpress.com'))))return '[]';
 const navigationId=itemId(location.pathname);
 const canonicalLink=document.querySelector('link[rel="canonical"]');
 if(canonicalLink){try{const canonical=new URL(canonicalLink.href||canonicalLink.getAttribute('href'),location.href);
  const domain=canonical.hostname.toLowerCase();
  const permitted=shein?(domain==='shein.com'||domain.endsWith('.shein.com')):
    (domain==='aliexpress.com'||domain.endsWith('.aliexpress.com'));
  if(permitted){const found=itemId(canonical.pathname);if(found&&found!==expected)return '[]';}
 }catch(_){}}
 if(navigationId&&navigationId!==expected)return '[]';
 const urlBound=navigationId===expected;
 const titleNode=document.querySelector('h1,[itemprop="name"],[data-testid="product-title"],[class*="product-title"],[class*="goods-title"]');
 const title=String(titleNode&&(titleNode.innerText||titleNode.textContent)||'').replace(/\\s+/g,' ').trim();
 const normalize=s=>String(s||'').toLowerCase().replace(/[^\\p{L}\\p{N}]/gu,'');
 const normTitle=normalize(title);
 const safe=(raw)=>{try{
  if(!raw||/^(?:data:|blob:)/i.test(raw))return '';
  const u=new URL(raw,location.href);
  if(u.protocol!=='https:')return '';
  if(/(?:logo|banner|sprite|icon|avatar|campaign|promot|placeholder|spacer|noimage|tracking|payment|favicon)/i.test(u.pathname))return '';
  if(/\\.(?:svg|gif)(?:$|[?#])/i.test(u.pathname))return '';
  return u.href;
 }catch(_){return '';}};
 const seen=new Set(),out=[];
 const add=raw=>{const u=safe(raw);if(u&&!seen.has(u)&&out.length<8){seen.add(u);out.push(u);}};
 // Product hydration is bound to the SAME saved numeric item ID. Images on
 // an item's authenticated detail record may have opaque CDN filenames.
 // Never demand the numeric ID inside the image filename itself.
 try {
   const hydrated=JSON.parse(__HYDRATED__);
   if(hydrated && hydrated.blocked)return '[]';
   if(hydrated && !hydrated.blocked && hydrated.idBound === true
       && Array.isArray(hydrated.images)){
     for(const url of hydrated.images)add(url);
   }
 }catch(_){ }
 if(out.length)return JSON.stringify(out.slice(0,6));
 // An unbound landing URL may still carry a JSON-LD Product whose own
 // URL explicitly names the saved item. Nothing else (gallery/header/OG)
 // may be borrowed from such a page. Unlike the old early return, this
 // makes verified product metadata usable in ONE shared snapshot.
 if(!urlBound){
  const products=[];
  const walk=(o,d)=>{if(!o||d>7)return;
   if(Array.isArray(o)){o.forEach(x=>walk(x,d+1));return;}
   if(typeof o!=='object')return;
   const type=Array.isArray(o['@type'])?o['@type'].join(' '):String(o['@type']||'');
   if(/(?:^|[\\s/:])Product(?:$|[\\s/:])/i.test(type))products.push(o);
   for(const key of ['@graph','mainEntity'])if(o[key])walk(o[key],d+1);
  };
  for(const tag of document.querySelectorAll('script[type="application/ld+json"]')){
   try{walk(JSON.parse(tag.textContent||''),0);}catch(_){ }
  }
  const bound=p=>[p.url,p['@id'],p.mainEntityOfPage].some(value=>{
   try{const v=typeof value==='string'?value:(value&&value['@id']);
    const u=new URL(v,location.href);
    return ((h)=>h=== (shein?'shein.com':'aliexpress.com')||h.endsWith('.'+(shein?'shein.com':'aliexpress.com')))(u.hostname.toLowerCase())&&itemId(u.pathname)===expected;
   }catch(_){return false;}
  });
  const found=products.filter(bound);
  if(found.length===1){const images=found[0].image;const v=Array.isArray(images)?images:[images];
   for(const i of v){const raw=typeof i==='string'?i:(i&&(i.url||i.contentUrl));add(raw);}
  }
  return JSON.stringify(out.slice(0,6));
 }
 const attrs=e=>{
  for(const key of ['data-zoom-image','data-original','data-large-image','data-src','data-lazy-src','data-image','src'])add(e.getAttribute(key));
  for(const key of ['data-srcset','srcset']){
   const raw=e.getAttribute(key)||'';
   for(const part of raw.split(',')) add(part.trim().split(/\\s+/)[0]);
  }
  if(e.currentSrc)add(e.currentSrc);
 };
 // Only components representing the primary product gallery are eligible.
 const selectors=shein?[
  '[data-testid*="product-image"] img','[class*="goods-detail"] [class*="gallery"] img',
  '[class*="product-intro"] [class*="image"] img','[class*="goods-detail"] [class*="image"] img',
  '[class*="product-gallery"] img','img[itemprop="image"]'
 ]:[
  '#magnifier img','[class*="magnifier"] img','[class*="images-view"] img',
  '[class*="product-image"] img','[class*="product-gallery"] img',
  '[data-testid*="product-image"] img','img[itemprop="image"]'
 ];
 for(const selector of selectors){
  for(const e of document.querySelectorAll(selector)){
   if(e.closest('header,footer,nav,aside,[class*="recommend"],[class*="related"],[class*="banner"],[class*="advert"]'))continue;
   attrs(e);
  }
  if(out.length)break;
 }
 // Unusual themes omit gallery classes. An image with an alt matching the
 // unique item's heading is still acceptable; never select the first <img>.
 if(!out.length&&normTitle.length>=14&&!/^(?:aliexpress|shein|online shopping)$/i.test(title)){
  for(const e of document.querySelectorAll('img[alt]')){
   if(e.closest('header,footer,nav,aside,[class*="recommend"],[class*="related"],[class*="banner"]'))continue;
   const alt=normalize(e.alt);
   if(alt.length>=8&&(normTitle.includes(alt)||alt.includes(normTitle)))attrs(e);
   if(out.length>=6)break;
  }
 }
 // An explicitly matching Product JSON-LD with its own image may be used,
 // but NEVER a site-wide social preview or an unmatched related Product.
 if(!out.length){
  const products=[];
  const walk=(o,d)=>{if(!o||d>7)return;
   if(Array.isArray(o)){o.forEach(x=>walk(x,d+1));return;}
   if(typeof o!=='object')return;
   const type=Array.isArray(o['@type'])?o['@type'].join(' '):String(o['@type']||'');
   if(/(?:^|[\\s/:])Product(?:$|[\\s/:])/i.test(type))products.push(o);
   for(const key of ['@graph','mainEntity'])if(o[key])walk(o[key],d+1);
  };
  for(const tag of document.querySelectorAll('script[type="application/ld+json"]')){try{walk(JSON.parse(tag.textContent||''),0);}catch(_){}}
  const bound=p=>[p.url,p['@id'],p.mainEntityOfPage].some(value=>{
    try{const v=typeof value==='string'?value:(value&&value['@id']);
     const u=new URL(v,location.href);
     return ((h)=>h=== (shein?'shein.com':'aliexpress.com')||h.endsWith('.'+(shein?'shein.com':'aliexpress.com')))(u.hostname.toLowerCase())&&itemId(u.pathname)===expected;
    }catch(_){return false;}});
  const found=products.filter(bound);
  if(found.length===1){const images=found[0].image;const v=Array.isArray(images)?images:[images];
   for(const i of v){const raw=typeof i==='string'?i:(i&&(i.url||i.contentUrl));add(raw);}
  }
 }
 return JSON.stringify(out.slice(0,6));
}catch(_){return '[]';}})()
""";
        // Both tokens come from validated URL components, never arbitrary HTML.
        return script.replace("__EXPECTED__", id).replace("__HOST__",
                itemUrl.getHost().toLowerCase(java.util.Locale.ROOT))
                .replace("__HYDRATED__", WishlistGeneralMarketplaceHydrationDom.javascript(itemUrl));
    }
}
