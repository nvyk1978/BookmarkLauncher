package com.cmyk.bookmarkslauncher.wishlist;

import android.text.Html;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Finds ONE heading-specific product block; never guesses among ambiguous headings. */
final class WishlistNoteSection {
    private static final Pattern HEADING = Pattern.compile("<h([1-6])\\b[^>]*>(.*?)</h\\1\\s*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    final String name, after, before;
    private WishlistNoteSection(String name, String after, String before) { this.name=name; this.after=after; this.before=before; }
    static WishlistNoteSection find(String html, String note) {
        if (html==null || note==null || note.trim().isEmpty() || note.length()>200) return null;
        String term=normalize(note);
        if(term.length()<2) return null;
        Matcher headings=HEADING.matcher(html);
        java.util.ArrayList<Integer> starts=new java.util.ArrayList<>();
        java.util.ArrayList<Integer> ends=new java.util.ArrayList<>();
        java.util.ArrayList<String> names=new java.util.ArrayList<>();
        while(headings.find() && starts.size()<100) {
            starts.add(headings.start()); ends.add(headings.end());
            names.add(Html.fromHtml(headings.group(2), Html.FROM_HTML_MODE_LEGACY).toString().trim());
        }
        int matched=-1;
        for(int i=0;i<names.size();i++) if(normalize(names.get(i)).contains(term)) {
            if(matched>=0 && !normalize(names.get(matched)).equals(normalize(names.get(i)))) return null;
            if(matched<0)matched=i;
        }
        if(matched<0) return null;
        int start=ends.get(matched);
        int end=matched+1<starts.size()?starts.get(matched+1):html.length();
        // Content can be large on CMS pages. Never cross another product heading.
        String after=html.substring(start, Math.min(end,start+10000));
        int beforeFrom=matched==0?0:ends.get(matched-1);
        String before=html.substring(Math.max(beforeFrom, starts.get(matched)-16000),starts.get(matched));
        return new WishlistNoteSection(names.get(matched),after,before);
    }
    private static String normalize(String s){return s.replaceAll("[\\s　・･（）()\\p{Punct}]", "").toLowerCase(Locale.ROOT);}
}
