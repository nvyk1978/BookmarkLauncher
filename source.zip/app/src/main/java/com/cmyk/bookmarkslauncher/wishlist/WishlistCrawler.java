package com.cmyk.bookmarkslauncher.wishlist;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Transport/orchestrator only. Name and price never call each other's parsers. */
public final class WishlistCrawler {
    private static final String TAG="WishlistCrawler";
    private static final int MAX_HTML_BYTES=2_000_000;
    private static final Pattern CHARSET=Pattern.compile("charset\\s*=\\s*['\"]?([a-zA-Z0-9_\\-]+)",Pattern.CASE_INSENSITIVE);
    private WishlistCrawler(){}
    public static Result fetch(String urlText) {
        Result out = new Result();
        if (urlText == null || urlText.isBlank()) { out.failureReason = "URLなし"; return out; }
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlText.trim());
            if (!isAllowedUrl(url)) { out.failureReason = "URL対象外"; return out; }
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(15000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36");
            conn.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en;q=0.6");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.5");
            out.httpCode = conn.getResponseCode();
            if (!isAllowedUrl(conn.getURL())) { out.failureReason = "転送先URL対象外"; return out; }
            out.resolvedUrl = conn.getURL().toString();
            if (out.httpCode < 200 || out.httpCode >= 300) { out.failureReason = "HTTP " + out.httpCode; return out; }
            String type = conn.getContentType();
            if (type != null && !type.toLowerCase(Locale.ROOT).contains("html")) { out.failureReason = "HTML以外"; return out; }
            byte[] bytes;
            try (BufferedInputStream input = new BufferedInputStream(conn.getInputStream());
                 ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                byte[] block = new byte[8192];
                int n;
                while ((n = input.read(block)) != -1 && buffer.size() < MAX_HTML_BYTES) {
                    buffer.write(block, 0, Math.min(n, MAX_HTML_BYTES - buffer.size()));
                }
                bytes = buffer.toByteArray();
            }
            Charset charset = charset(type, bytes);
            String html = new String(bytes, charset);
            parseHtml(html, conn.getURL(), out);
            out.sourceName = host(conn.getURL().toString());
            out.success = true;
            if (out.price == null) out.failureReason = "価格情報を特定できず";
        } catch (SocketTimeoutException error) {
            out.failureReason = "通信タイムアウト";
            Log.d(TAG, "Preview timeout", error);
        } catch (Exception error) {
            out.failureReason = "通信・解析エラー";
            Log.d(TAG, "Preview not available for URL", error);
        } finally {
            if (conn != null) conn.disconnect();
        }
        return out;
    }


    private static Charset charset(String contentType, byte[] data) {
        String guess = contentType == null ? "" : contentType;
        Matcher c = CHARSET.matcher(guess);
        String name = c.find() ? c.group(1) : null;
        if (name == null) {
            // Some Japanese shops declare Shift_JIS only in their HTML head.
            String head = new String(data, 0, Math.min(data.length, 8192), StandardCharsets.ISO_8859_1);
            c = CHARSET.matcher(head);
            if (c.find()) name = c.group(1);
        }
        try { return name == null ? StandardCharsets.UTF_8 : Charset.forName(name); }
        catch (Exception ignored) { return StandardCharsets.UTF_8; }
    }
    static void parseHtml(String html,URL page,Result out) {
        // One download, two independent analyses, no name-to-price information flow.
        try {
            WishlistMetadataExtractor.Result metadata=WishlistMetadataExtractor.parse(html,page);
            out.title=metadata.title;
            out.imageUrl=metadata.imageUrl;
            out.status=metadata.status;
        }catch(RuntimeException error){Log.w(TAG,"Metadata parser failed independently",error);}
        try {
            out.price=WishlistPriceExtractor.parse(html,page);
        }catch(RuntimeException error){Log.w(TAG,"Price parser failed independently",error);}
    }

    static boolean isAllowedUrl(URL url) {
        String protocol = url.getProtocol();
        if (!"http".equalsIgnoreCase(protocol) && !"https".equalsIgnoreCase(protocol)) return false;
        String host = url.getHost();
        if (host == null || host.isBlank()) return false;
        String h = host.toLowerCase(Locale.ROOT);
        if (h.equals("localhost") || h.endsWith(".local") || h.endsWith(".internal") || h.equals("0.0.0.0") || h.equals("::1") || h.equals("[::1]")) return false;
        if (h.matches("(?:127|10|0)\\.\\d+\\.\\d+\\.\\d+")) return false;
        if (h.matches("192\\.168\\.\\d+\\.\\d+")) return false;
        if (h.matches("172\\.(?:1[6-9]|2\\d|3[01])\\.\\d+\\.\\d+")) return false;
        if (h.matches("169\\.254\\.\\d+\\.\\d+")) return false;
        return !h.contains(":"); // IPv6 literals (including local addresses) are not previewed.
    }
    private static String host(String url) {
        try { String h = new URI(url).getHost(); return h == null ? null : (h.startsWith("www.") ? h.substring(4) : h); }
        catch (Exception ignored) { return null; }
    }
    public static final class Result {
        public boolean success;
        public int httpCode;
        public String resolvedUrl;
        public String title;
        public String imageUrl;
        public String sourceName;
        public Long price;
        public String failureReason;
        public String status="UNKNOWN";
    }
}
