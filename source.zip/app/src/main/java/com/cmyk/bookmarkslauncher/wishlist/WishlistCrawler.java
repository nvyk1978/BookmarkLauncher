package com.cmyk.bookmarkslauncher.wishlist;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Transport/orchestrator only. Name and price never call each other's parsers. */
public final class WishlistCrawler {
    private static final String TAG="WishlistCrawler";
    private static final int MAX_HTML_BYTES=2_000_000;
    private static final Pattern CHARSET=Pattern.compile("charset\\s*=\\s*['\"]?([a-zA-Z0-9_\\-]+)",Pattern.CASE_INSENSITIVE);
    private WishlistCrawler(){}
    /** All Wishlist card update paths MUST use this stored-mode overload. */
    public static Result fetch(WishlistItem item) {
        if (item == null) return new Result();
        return fetch(item.url, item.note, item.acquisitionMode);
    }
    private static Result fetch(String urlText, String note, WishlistMode savedMode) {
        Result out = new Result();
        final WishlistMode expected = savedMode == null ? WishlistMode.UNRESOLVED : savedMode;
        if (urlText == null || urlText.isBlank()) { out.failureReason = "URLなし"; return out; }
        HttpURLConnection conn = null;
        final long requestStarted=android.os.SystemClock.elapsedRealtime();
        boolean headersReceived=false;
        try {
            URL url = new URL(urlText.trim());
            if (!isAllowedUrl(url)) { out.failureReason = "URL対象外"; return out; }
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            boolean largeRetail = expected == WishlistMode.UNIQLO
                    || expected == WishlistMode.YODOBASHI || expected == WishlistMode.BICCAMERA;
            // The dedicated rendered probe follows on user-initiated updates;
            // never spend 27 seconds on HTTP before launching that probe.
            // Heavy camera/electronics stores need time to connect and send response headers.
            // UNIQLO (proven image+price) and the other crawlers are untouched.
            final boolean electronics = expected == WishlistMode.YODOBASHI
                    || expected == WishlistMode.BICCAMERA;
            conn.setConnectTimeout(electronics ? 11000 : (largeRetail ? 5500 : 12000));
            conn.setReadTimeout(electronics ? 14000 : (largeRetail ? 7500 : 15000));
            long httpStarted=android.os.SystemClock.elapsedRealtime();
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36");
            conn.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en;q=0.6");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.5");
            Log.i(TAG,"HTTP begin mode="+expected+" host="+url.getHost());
            RetailDiagnostics.event(expected,"http.start","host="+url.getHost()+" connectMs="+conn.getConnectTimeout()+" readMs="+conn.getReadTimeout());
            out.httpCode = conn.getResponseCode();
            headersReceived=true;
            RetailDiagnostics.event(expected,"http.headers","code="+out.httpCode+" host="+conn.getURL().getHost()+" elapsedMs="+(android.os.SystemClock.elapsedRealtime()-httpStarted));
            if(largeRetail)Log.i(TAG,"Retail HTTP headers mode="+expected+" code="+out.httpCode
                    +" elapsedMs="+(android.os.SystemClock.elapsedRealtime()-httpStarted));
            if (!isAllowedUrl(conn.getURL())) { out.failureReason = "転送先URL対象外"; return out; }
            out.resolvedUrl = conn.getURL().toString();
            WishlistMode resolved = WishlistMode.forResolvedUrl(conn.getURL());
            if (resolved == WishlistMode.UNRESOLVED ||
                    (expected != WishlistMode.UNRESOLVED && expected != resolved)) {
                out.failureReason = "取得モードと転送先が不一致: saved="+expected+" destination="+resolved;
                Log.w(TAG, out.failureReason + " url=" + conn.getURL());
                return out;
            }
            if (expected == WishlistMode.MUJI &&
                    !url.getPath().replaceAll("/+$", "")
                        .equalsIgnoreCase(conn.getURL().getPath().replaceAll("/+$", ""))) {
                out.failureReason = "MUJI商品URLが別商品へ遷移";
                return out;
            }
            if (GeneralRetailIdentity.store(url) != null
                    && !GeneralRetailIdentity.sameProduct(url, conn.getURL())) {
                out.failureReason = "商品IDが異なる転送先";
                return out;
            }
            MarketplaceIdentity requested = MarketplaceIdentity.from(url);
            if (requested != null && !requested.matches(conn.getURL())) {
                out.failureReason = "商品の転送先IDが一致せず";
                return out;
            }
            if (out.httpCode < 200 || out.httpCode >= 300) {
                String response = "";
                if (out.httpCode == 503) {
                    try (java.io.InputStream error = conn.getErrorStream()) {
                        if (error != null) response = new String(error.readNBytes(65536), StandardCharsets.UTF_8);
                    } catch (Exception ignored) { }
                }
                out.siteState = WishlistSiteState.classify(out.httpCode, response);
                out.failureReason = "HTTP " + out.httpCode;
                RetailDiagnostics.event(expected,"http.rejected","code="+out.httpCode+" state="+out.siteState);
                RetailDiagnostics.general(conn.getURL(), "http.rejected", "code="+out.httpCode+" state="+out.siteState);
                return out;
            }
            String type = conn.getContentType();
            if (type != null && !type.toLowerCase(Locale.ROOT).contains("html")) { out.failureReason = "HTML以外"; return out; }
            byte[] bytes;
            try (BufferedInputStream input = new BufferedInputStream(conn.getInputStream());
                 ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                byte[] block = new byte[8192];
                int n;
                while ((n = input.read(block)) != -1 && buffer.size() < MAX_HTML_BYTES) {
                    buffer.write(block, 0, Math.min(n, MAX_HTML_BYTES - buffer.size()));
                }
                bytes = buffer.toByteArray();
                RetailDiagnostics.event(expected,"http.body","bytes="+bytes.length+" elapsedMs="+(android.os.SystemClock.elapsedRealtime()-httpStarted));
            }
            Charset charset = charset(type, bytes);
            String html = new String(bytes, charset);
            out.siteState = WishlistSiteState.classify(out.httpCode, html);
            if (!WishlistSiteState.OK.equals(out.siteState)) {
                out.failureReason = WishlistSiteState.label(out.siteState);
                return out; // Maintenance page is NOT a product page.
            }
            // Reject a marketplace page with a contradictory canonical identity;
            // do not overwrite any previously correct item data.
            if (MarketplaceIdentity.site(conn.getURL()) != MarketplaceIdentity.Site.OTHER) {
                MarketplaceIdentity id = MarketplaceIdentity.from(conn.getURL());
                if (id == null || !id.verified(html, conn.getURL())) {
                    out.failureReason = "対象商品の同一性を検証できず";
                    return out;
                }
            }
            out.acquisitionMode = resolved;
            if (resolved == WishlistMode.GENERAL && GeneralRetailIdentity.store(conn.getURL()) != null)
                RetailDiagnostics.general(conn.getURL(), "http.product", "code="+out.httpCode+" bytes="+bytes.length);
            parseHtml(html, conn.getURL(), out, resolved);
            if (resolved == WishlistMode.GENERAL && GeneralRetailIdentity.store(conn.getURL()) != null)
                RetailDiagnostics.general(conn.getURL(), "price.gross", "skuVerified=true found="+(out.price!=null));
            if (resolved == WishlistMode.GENERAL && GeneralRetailIdentity.store(conn.getURL()) != null)
                RetailDiagnostics.general(conn.getURL(), "http.parsed", "title="+(out.title!=null)
                        +" image="+(out.imageUrl!=null)+" price="+(out.price!=null)
                        +" stock="+out.status+" reason="+out.availabilityReason);
            // Independent image candidates are already resolved for the three
            // marketplaces. Keep the established independent-shop extractor intact.
            if (resolved == WishlistMode.GENERAL
                    && isSingleProductPage(conn.getURL())) {
                out.retailImageCandidates = WishlistRetailImageCandidates.fromHtml(html, conn.getURL());
            }
            // A visible minimum/range is not a confirmed purchasable price.
            // Read it only on one-product URLs, never from a category page.
            if (resolved == WishlistMode.GENERAL
                    && isSingleProductPage(conn.getURL())
                    && GeneralRetailIdentity.store(conn.getURL()) == null) {
                WishlistRetailPriceQuote quote = WishlistRetailPriceQuote.fromHtml(html);
                if (quote != null) {
                    out.priceQuote = quote;
                    out.price = null;
                    // Never treat a listing's incidental "sold out" as proof that a
                    // size-selectable (FROM/RANGE) item cannot be purchased.
                    if (!out.availabilityExplicit && "UNAVAILABLE".equals(out.status)) out.status = "UNKNOWN";
                }
            }
            // Notes are optional product selectors on multi-product pages. The
            // standard Amazon/single-product code above is never modified.
            // A product-detail URL already identifies one product. Never let an
            // optional note override that product with a coincidental text match;
            // keeping noteTargetMatched=false also allows WebView price recovery.
            if (resolved == WishlistMode.GENERAL && note != null && !note.isBlank() && !isSingleProductPage(conn.getURL())) {
                WishlistNoteSection section = WishlistNoteSection.find(html, note);
                if (section != null) {
                    out.noteTargetMatched = true;
                    WishlistAvailabilityExtractor.Result noteStock =
                            WishlistAvailabilityExtractor.parseNoteSection(section);
                    out.status = noteStock.status; // Never inherit page-wide stock status.
                    out.availabilityExplicit = noteStock.explicit;
                    // Image and price remain separate analyses and separate DB writes.
                    String image = WishlistNoteMetadataExtractor.image(section.before, conn.getURL());
                    Long selectedPrice = WishlistNotePriceExtractor.price(section.after);
                    out.title = section.name;
                    out.imageUrl = image; // Never use the page-wide image for a selected product.
                    out.price = selectedPrice; // Never mix another product's price.
                    if (selectedPrice == null) out.failureReason = "備考欄の商品価格を一意に特定できず";
                }
            }
            out.sourceName = host(conn.getURL().toString());
            out.success = true;
            // Diagnostic-only metadata. No availability state is inferred from
            // transport success, and no unrelated crawler pipeline is changed.
            Log.i(TAG, "Stock outcome: mode="+out.acquisitionMode+" host=" + conn.getURL().getHost()
                    + " path=" + conn.getURL().getPath() + " HTTP=" + out.httpCode
                    + " status=" + out.status + " reason=" + out.availabilityReason
                    + " modeVerified=" + (expected == WishlistMode.UNRESOLVED ? "new" : "persisted"));
            if (out.price == null && out.priceQuote == null && out.failureReason == null) out.failureReason = "価格情報を特定できず";
            RetailDiagnostics.event(expected,"http.parse","title="+(out.title!=null)+" image="+(out.imageUrl!=null)+" price="+(out.price!=null)+" stock="+out.status);
        } catch (SocketTimeoutException error) {
            out.siteState = WishlistSiteState.TIMEOUT;
            out.failureReason = "通信タイムアウト";
            if(expected==WishlistMode.UNIQLO||expected==WishlistMode.YODOBASHI||expected==WishlistMode.BICCAMERA)
                Log.w(TAG, "Retail HTTP timeout mode="+expected+" host="+host(urlText)
                        +" stage="+(headersReceived?"body-read":"connect-or-headers")
                        +" elapsedMs="+(android.os.SystemClock.elapsedRealtime()-requestStarted),error);
            else Log.d(TAG, "Preview timeout", error);
            RetailDiagnostics.event(expected,"http.timeout","stage="+(headersReceived?"body-read":"connect-or-headers")+" elapsedMs="+(android.os.SystemClock.elapsedRealtime()-requestStarted)+" exception="+RetailDiagnostics.error(error));
            try { RetailDiagnostics.general(new URL(urlText), "http.timeout", "stage="+(headersReceived?"body":"connect")+" type="+RetailDiagnostics.error(error)); }
            catch (Exception ignored) { }
        } catch (Exception error) {
            out.siteState = WishlistSiteState.CONNECT_FAILED;
            out.failureReason = "通信・解析エラー";
            Log.d(TAG, "Preview not available for URL", error);
            RetailDiagnostics.event(expected,"http.error","stage="+(headersReceived?"after-headers":"before-headers")+" type="+RetailDiagnostics.error(error));
            try { RetailDiagnostics.general(new URL(urlText), "http.error", "type="+RetailDiagnostics.error(error)); }
            catch (Exception ignored) { }
        } finally {
            RetailDiagnostics.event(expected,"http.end","success="+out.success+" code="+out.httpCode+" site="+out.siteState+" title="+(out.title!=null)+" image="+(out.imageUrl!=null)+" price="+(out.price!=null)+" elapsedMs="+(android.os.SystemClock.elapsedRealtime()-requestStarted));
            if (conn != null) conn.disconnect();
        }
        return out;
    }


    private static Charset charset(String contentType, byte[] data) {
        String guess = contentType == null ? "" : contentType;
        Matcher c = CHARSET.matcher(guess);
        String name = c.find() ? c.group(1) : null;
        if (name == null) {
            // Some Japanese shops declare Shift_JIS only in their HTML head.
            String head = new String(data, 0, Math.min(data.length, 8192), StandardCharsets.ISO_8859_1);
            c = CHARSET.matcher(head);
            if (c.find()) name = c.group(1);
        }
        try { return name == null ? StandardCharsets.UTF_8 : Charset.forName(name); }
        catch (Exception ignored) { return StandardCharsets.UTF_8; }
    }
    static void parseHtml(String html,URL page,Result out,WishlistMode mode) {
        // Parser selection is exclusively the stored mode (or a newly verified
        // mode for an UNRESOLVED card), never an independent URL-based fallback.
        if (mode == WishlistMode.AMAZON || mode == WishlistMode.RAKUTEN || mode == WishlistMode.YAHOO) {
            MarketplaceIdentity identity = MarketplaceIdentity.from(page);
            if (identity == null || WishlistMode.forSite(identity.site) != mode
                    || !identity.verified(html, page)) {
                out.status = "UNKNOWN";
                out.availabilityReason = "対象の商品IDまたはcanonicalが一致しません";
                return;
            }
            if (mode == WishlistMode.AMAZON) {
                try { out.title = AmazonNameExtractor.find(html,page); }
                catch (RuntimeException e) { Log.w(TAG, "Amazon title",e); }
                try { out.retailImageCandidates = AmazonProductImageExtractor.candidates(html,page);
                    if (!out.retailImageCandidates.isEmpty())out.imageUrl=out.retailImageCandidates.get(0);
                } catch (RuntimeException e) { Log.w(TAG,"Amazon image",e); }
                try { out.price=AmazonOfferPriceExtractor.parse(html,page);
                    if(out.price==null)out.priceQuote=AmazonOfferPriceExtractor.quote(html,page);
                } catch (RuntimeException e) { Log.w(TAG,"Amazon price",e); }
                try { WishlistAvailabilityExtractor.Result stock=AmazonAvailabilityExtractor.parse(html,page);
                    out.status=stock.status;out.availabilityExplicit=stock.explicit;out.availabilityReason=stock.reason;
                } catch (RuntimeException e) { Log.w(TAG,"Amazon stock",e); }
            }
            if (mode == WishlistMode.RAKUTEN) {
                try { out.title = RakutenNameExtractor.find(html,page); }
                catch (RuntimeException e) { Log.w(TAG, "Rakuten title",e); }
                try { out.retailImageCandidates = RakutenImageExtractor.candidates(html,page);
                    if (!out.retailImageCandidates.isEmpty())out.imageUrl=out.retailImageCandidates.get(0);
                } catch (RuntimeException e) { Log.w(TAG,"Rakuten image",e); }
                try { out.price=RakutenPriceExtractor.parse(html,page);
                    if(out.price==null)out.priceQuote=RakutenPriceExtractor.quote(html,page);
                } catch (RuntimeException e) { Log.w(TAG,"Rakuten price",e); }
                try { WishlistAvailabilityExtractor.Result stock=RakutenAvailabilityExtractor.parse(html,page);
                    out.status=stock.status;out.availabilityExplicit=stock.explicit;out.availabilityReason=stock.reason;
                } catch (RuntimeException e) { Log.w(TAG,"Rakuten stock",e); }
            }
            if (mode == WishlistMode.YAHOO) {
                try { out.title = YahooNameExtractor.find(html,page); }
                catch (RuntimeException e) { Log.w(TAG, "Yahoo title",e); }
                try { out.retailImageCandidates = YahooImageExtractor.candidates(html,page);
                    if (!out.retailImageCandidates.isEmpty())out.imageUrl=out.retailImageCandidates.get(0);
                } catch (RuntimeException e) { Log.w(TAG,"Yahoo image",e); }
                try { out.price=YahooPriceExtractor.parse(html,page);
                    if(out.price==null)out.priceQuote=YahooPriceExtractor.quote(html,page);
                } catch (RuntimeException e) { Log.w(TAG,"Yahoo price",e); }
                try { WishlistAvailabilityExtractor.Result stock=YahooAvailabilityExtractor.parse(html,page);
                    out.status=stock.status;out.availabilityExplicit=stock.explicit;out.availabilityReason=stock.reason;
                } catch (RuntimeException e) { Log.w(TAG,"Yahoo stock",e); }
            }
            return;
        }
        // Strictly isolated high-volume retailers. No GENERAL fallback and no
        // marketplace parsers are allowed to run on these cards.
        if (mode == WishlistMode.UNIQLO) { UniqloProductExtractor.parse(html,page,out); return; }
        if (mode == WishlistMode.YODOBASHI) { YodobashiProductExtractor.parse(html,page,out); return; }
        if (mode == WishlistMode.BICCAMERA) { BicCameraProductExtractor.parse(html,page,out); return; }
        // Independent shops retain their previously successful parsers.
        // Never fall back to the general extractor for a marketplace mode.
        if (mode != WishlistMode.GENERAL && mode != WishlistMode.MUJI) return;
        try {
            WishlistMetadataExtractor.Result metadata=WishlistMetadataExtractor.parse(html,page);
            out.title=metadata.title;
            out.imageUrl=metadata.imageUrl;
            out.status=metadata.status;
            out.availabilityExplicit=metadata.availabilityExplicit;
            out.availabilityReason=metadata.availabilityReason;
        }catch(RuntimeException error){Log.w(TAG,"Metadata parser failed independently",error);}
        try {
            out.price=WishlistPriceExtractor.parse(html,page);
        }catch(RuntimeException error){Log.w(TAG,"Price parser failed independently",error);}
    }

    /**
     * Shared, evidence-based retail detail URL detection for GENERAL mode only.
     * The supported shapes occur on multiple independent shops; no domain is
     * implicitly assigned a new mode. Category/listing pages remain excluded.
     */
    public static boolean isSingleProductPage(URL url) {
        if (url == null) return false;
        if (MarketplaceIdentity.from(url) != null) return true;
        if (HirakiStockEvidence.isHirakiProduct(url) || GeneralRetailIdentity.store(url) != null) return true;
        String path = url.getPath().toLowerCase(Locale.ROOT);
        // Official MUJI JP product URLs carry one 13-digit JAN identifier.
        // Only the exact product route can trigger read-only timeout recovery.
        String hostname = url.getHost().toLowerCase(Locale.ROOT);
        if ("https".equalsIgnoreCase(url.getProtocol())
                && ("muji.com".equals(hostname) || "www.muji.com".equals(hostname))
                && path.matches("^/jp/ja/store/cmdty/detail/[0-9]{13}/?$")) return true;
        // Verified single-item path shapes used by independent GENERAL shops.
        // URL recognition does not assert stock and leaves all persisted modes intact.
        if ("https".equalsIgnoreCase(url.getProtocol())
                && (((hostname.equals("cainz.com") || hostname.equals("www.cainz.com"))
                    && path.matches("^/g/[0-9]{8,15}\\.html$"))
                    || ((hostname.equals("nitori-net.jp") || hostname.equals("www.nitori-net.jp"))
                    && path.matches("^/ec/product/[a-z0-9]{8,22}/?$")))) return true;
        if (path.matches(".*/products/detail/[0-9]+/?") // EC-CUBE
                || path.matches(".*/product/detail/[^/]+/?")
                || path.matches(".*/products/[^/]+/?")
                || path.matches(".*/item/detail/[^/]+/?")
                || path.matches(".*/product/[0-9]+/?")
                || path.matches(".*/item-detail/[0-9]+/?")
                || path.matches(".*/item_detail_[0-9]+\\.html")
                || path.matches(".*/view/item/[a-z0-9_-]*[0-9][a-z0-9_-]*/?") // makeshop
                || path.matches(".*/shop/g/g[a-z0-9_-]*[0-9][a-z0-9_-]*/?") // SKU detail
                || path.matches(".*/shop/[a-z0-9_-]*[0-9][a-z0-9_-]*\\.html") // shopserve
                || path.matches(".*/i/[a-z0-9_-]*[0-9][a-z0-9_-]*/?")) // item code
            return true;
        String query = url.getQuery();
        if (query == null) return false;
        boolean root = path.equals("/") || path.isEmpty() || path.equals("/index.php");
        if (root && hasQueryId(query, "pid", "[0-9]+")) return true; // Color Me
        if (root && hasQueryId(query, "eci_product", "[a-z0-9_-]*[0-9][a-z0-9_-]*"))
            return true; // Product identified separately from page_id
        return path.endsWith("/index.php")
                && hasQueryId(query, "dispatch", "products\\.view")
                && hasQueryId(query, "product_id", "[0-9]+"); // CS-Cart
    }

    /** Whole query parameter match; avoids category parameters and accidental substrings. */
    private static boolean hasQueryId(String query, String key, String valuePattern) {
        return Pattern.compile("(?i)(?:^|&)" + Pattern.quote(key) + "="
                + valuePattern + "(?:&|$)").matcher(query).find();
    }

    static boolean isAllowedUrl(URL url) {
        String protocol = url.getProtocol();
        if (!"http".equalsIgnoreCase(protocol) && !"https".equalsIgnoreCase(protocol)) return false;
        String host = url.getHost();
        if (host == null || host.isBlank()) return false;
        String h = host.toLowerCase(Locale.ROOT);
        if (h.equals("localhost") || h.endsWith(".local") || h.endsWith(".internal") || h.equals("0.0.0.0") || h.equals("::1") || h.equals("[::1]")) return false;
        if (h.matches("(?:127|10|0)\\.\\d+\\.\\d+\\.\\d+")) return false;
        if (h.matches("192\\.168\\.\\d+\\.\\d+")) return false;
        if (h.matches("172\\.(?:1[6-9]|2\\d|3[01])\\.\\d+\\.\\d+")) return false;
        if (h.matches("169\\.254\\.\\d+\\.\\d+")) return false;
        return !h.contains(":"); // IPv6 literals (including local addresses) are not previewed.
    }
    private static String host(String url) {
        try { String h = new URI(url).getHost(); return h == null ? null : (h.startsWith("www.") ? h.substring(4) : h); }
        catch (Exception ignored) { return null; }
    }
    public static final class Result {
        public boolean noteTargetMatched;
        public boolean availabilityExplicit;
        public String availabilityReason;
        public String siteState = WishlistSiteState.OK;
        public boolean success;
        public int httpCode;
        public String resolvedUrl;
        public WishlistMode acquisitionMode = WishlistMode.UNRESOLVED;
        public String title;
        public String imageUrl;
        public java.util.List<String> retailImageCandidates = java.util.Collections.emptyList();
        /** Verified image bytes rendered by the BICCAMERA WebView (memory only). */
        public String sourceName;
        public Long price;
        public WishlistRetailPriceQuote priceQuote;
        public String failureReason;
        public String status="UNKNOWN";
    }
}
