package com.cmyk.bookmarkslauncher.wishlist;

import android.text.Html;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WishlistCrawler {
    private WishlistCrawler() {}

    private static final Pattern META_TITLE = Pattern.compile("<meta[^>]+(?:property|name)=[\\\"'](?:og:title|twitter:title)[\\\"'][^>]+content=[\\\"']([^\\\"']+)[\\\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern TITLE = Pattern.compile("<title[^>]*>(.*?)</title>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern PRICE_META = Pattern.compile("<meta[^>]+(?:property|name|itemprop)=[\\\"'](?:product:price:amount|price|og:price:amount)[\\\"'][^>]+content=[\\\"']([0-9][0-9,]*(?:\\.[0-9]+)?)[\\\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern PRICE_ITEMPROP = Pattern.compile("itemprop=[\\\"']price[\\\"'][^>]+(?:content|value)=[\\\"']([0-9][0-9,]*(?:\\.[0-9]+)?)[\\\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern PRICE_JSON = Pattern.compile("\\\"price\\\"\\s*:\\s*[\\\"']?([0-9][0-9,]*(?:\\.[0-9]+)?)[\\\"']?", Pattern.CASE_INSENSITIVE);
    private static final Pattern PRICE_YEN = Pattern.compile("(?:[¥￥]\\s*|)([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{3,7})\\s*円");

    public static Result fetch(String urlText) {
        Result out = new Result();
        if (urlText == null || urlText.isBlank()) return out;
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlText);
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(15000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36");
            conn.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en;q=0.6");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.8,*/*;q=0.5");
            int code = conn.getResponseCode();
            out.httpCode = code;
            if (code < 200 || code >= 400) return out;
            try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
                 ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
                byte[] block = new byte[8192];
                int total = 0;
                int n;
                while ((n = in.read(block)) > 0 && total < 2_000_000) {
                    int keep = Math.min(n, 2_000_000 - total);
                    buf.write(block, 0, keep);
                    total += keep;
                }
                String html = new String(buf.toByteArray(), StandardCharsets.UTF_8);
                out.title = clean(first(html, META_TITLE));
                if (out.title == null) out.title = clean(first(html, TITLE));
                out.sourceName = host(urlText);
                out.price = price(html);
                out.status = status(html);
                out.success = true;
            }
        } catch (Throwable ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return out;
    }

    private static Long price(String html) {
        String[] candidates = {first(html, PRICE_META), first(html, PRICE_ITEMPROP), first(html, PRICE_JSON), first(html, PRICE_YEN)};
        for (String s : candidates) {
            if (s == null) continue;
            try {
                double d = Double.parseDouble(s.replace(",", ""));
                if (d >= 1 && d <= 100_000_000) return Math.round(d);
            } catch (Exception ignored) { }
        }
        return null;
    }

    private static String status(String html) {
        String t = html.toLowerCase(Locale.ROOT);
        if (containsAny(t, "coming soon", "近日公開", "開始前", "公開予定", "販売開始前", "支援開始前")) return "COMING_SOON";
        if (containsAny(t, "sold out", "out of stock", "在庫切れ", "売り切れ", "完売", "受付停止", "一時停止", "支援受付終了")) return "UNAVAILABLE";
        if (containsAny(t, "in stock", "支援する", "購入する", "予約する", "カートに入れる", "今すぐ購入", "受付中")) return "AVAILABLE";
        return "UNKNOWN";
    }

    private static boolean containsAny(String text, String... values) {
        for (String v : values) if (text.contains(v.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private static String first(String text, Pattern p) {
        Matcher m = p.matcher(text);
        return m.find() ? m.group(1) : null;
    }

    private static String clean(String s) {
        if (s == null) return null;
        String v = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\\s+", " ").trim();
        return v.isBlank() ? null : v;
    }

    private static String host(String u) {
        try {
            String h = new URI(u).getHost();
            if (h == null) return null;
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) { return null; }
    }

    public static final class Result {
        public boolean success;
        public int httpCode;
        public String title;
        public String sourceName;
        public Long price;
        public String status = "UNKNOWN";
    }
}
