package com.cmyk.bookmarkslauncher.wishlist;

import android.text.Html;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Link preview parser. Only public HTTP(S) page metadata is used; no login or site API. */
public final class WishlistCrawler {
    private static final String TAG = "WishlistCrawler";
    private static final int MAX_HTML_BYTES = 2_000_000;
    private static final Pattern META = Pattern.compile("<meta\\b[^>]*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern ATTRIBUTE = Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern TITLE = Pattern.compile("<title\\b[^>]*>(.*?)</title\\s*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern LINK = Pattern.compile("<link\\b[^>]*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern IMAGE = Pattern.compile("<img\\b[^>]*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern JSON_LD = Pattern.compile("<script\\b([^>]*)>(.*?)</script\\s*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    // Prices are extracted only from product-scoped data, not arbitrary body text.
    private static final Pattern PRICE_TAG = Pattern.compile("<[^>]+>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern OFFSCREEN_PRICE = Pattern.compile(
            "<span\\b[^>]*class\\s*=\\s*[\"'][^\"']*\\ba-offscreen\\b[^\"']*[\"'][^>]*>(.*?)</span\\s*>",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern CHARSET = Pattern.compile("charset\\s*=\\s*[\"']?([a-zA-Z0-9_\\-]+)", Pattern.CASE_INSENSITIVE);

    private WishlistCrawler() { }

    public static Result fetch(String urlText) {
        Result out = new Result();
        if (urlText == null || urlText.isBlank()) return out;
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlText.trim());
            if (!isAllowedUrl(url)) return out;
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(15000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36");
            conn.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en;q=0.6");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.5");
            out.httpCode = conn.getResponseCode();
            if (out.httpCode < 200 || out.httpCode >= 300) return out;
            if (!isAllowedUrl(conn.getURL())) return out;
            String type = conn.getContentType();
            if (type != null && !type.toLowerCase(Locale.ROOT).contains("html")) return out;
            byte[] bytes;
            try (BufferedInputStream input = new BufferedInputStream(conn.getInputStream());
                 ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                byte[] block = new byte[8192];
                int n;
                while ((n = input.read(block)) != -1 && buffer.size() < MAX_HTML_BYTES) {
                    buffer.write(block, 0, Math.min(n, MAX_HTML_BYTES - buffer.size()));
                }
                bytes = buffer.toByteArray();
            }
            Charset charset = charset(type, bytes);
            String html = new String(bytes, charset);
            parseHtml(html, conn.getURL(), out);
            out.sourceName = host(conn.getURL().toString());
            out.success = true;
        } catch (Exception error) {
            Log.d(TAG, "Preview not available for URL", error);
        } finally {
            if (conn != null) conn.disconnect();
        }
        return out;
    }

    private static Charset charset(String contentType, byte[] data) {
        String guess = contentType == null ? "" : contentType;
        Matcher c = CHARSET.matcher(guess);
        String name = c.find() ? c.group(1) : null;
        if (name == null) {
            // Some Japanese shops declare Shift_JIS only in their HTML head.
            String head = new String(data, 0, Math.min(data.length, 8192), StandardCharsets.ISO_8859_1);
            c = CHARSET.matcher(head);
            if (c.find()) name = c.group(1);
        }
        try { return name == null ? StandardCharsets.UTF_8 : Charset.forName(name); }
        catch (Exception ignored) { return StandardCharsets.UTF_8; }
    }

    static void parseHtml(String html, URL page, Result out) {
        Map<String, String> meta = new HashMap<>();
        Matcher m = META.matcher(html);
        while (m.find()) {
            Map<String, String> attrs = attributes(m.group());
            String key = coalesce(attrs.get("property"), attrs.get("name"), attrs.get("itemprop"));
            String value = clean(attrs.get("content"));
            if (key != null && value != null) meta.putIfAbsent(key.toLowerCase(Locale.ROOT), value);
        }
        out.title = coalesce(meta.get("og:title"), meta.get("twitter:title"), clean(first(html, TITLE)));
        out.imageUrl = absoluteImage(page, coalesce(meta.get("og:image:secure_url"), meta.get("og:image"),
                meta.get("twitter:image"), meta.get("twitter:image:src")));
        // Product JSON-LD is often more precise than the site's social sharing title.
        Product product = findProduct(html, page);
        if (product.name != null) out.title = product.name;
        if (product.image != null) {
            String resolved = absoluteImage(page, product.image);
            if (resolved != null) out.imageUrl = resolved;
        }
        if (out.imageUrl == null) out.imageUrl = fallbackImage(html, page);
        out.price = product.price;
        if (out.price == null) {
            String currency = coalesce(meta.get("product:price:currency"), meta.get("og:price:currency"),
                    meta.get("pricecurrency"), meta.get("product:price:currency_code"));
            String raw = coalesce(meta.get("product:price:amount"), meta.get("og:price:amount"),
                    meta.get("twitter:data1"), meta.get("price"));
            // twitter:data1 can be promotional text; it is accepted only with a ¥ marker.
            if (raw != null && raw.equals(meta.get("twitter:data1")) && !isYenText(raw)) raw = null;
            if ("JPY".equalsIgnoreCase(currency) || (currency == null && (isJapanSite(page) || isYenText(raw))))
                out.price = parsePrice(raw);
        }
        if (out.price == null) out.price = itempropPrice(html, page);
        if (out.price == null) out.price = shopPrice(html, page);
        // Do not guess prices from arbitrary body text: recommendation ads and
        // crossed-out prices otherwise get mistaken for the product price.
        String availability = coalesce(product.availability, meta.get("product:availability"));
        out.status = availability == null ? status(html) : statusFromAvailability(availability);
    }

    private static Product findProduct(String html, URL page) {
        Product output = new Product();
        Matcher scripts = JSON_LD.matcher(html);
        while (scripts.find()) {
            Map<String, String> attrs = attributes(scripts.group(1));
            String mime = attrs.get("type");
            if (mime == null || !mime.toLowerCase(Locale.ROOT).startsWith("application/ld+json")) continue;
            try {
                String json = scripts.group(2).trim().replaceAll("(?s)^<!--|-->$", "");
                Object node = json.startsWith("[") ? new JSONArray(json) : new JSONObject(json);
                if (searchProduct(node, output, 0, isJapanSite(page) ? "JPY" : null)) break;
            } catch (Exception ignored) { /* Keep OGP fallback on malformed JSON-LD. */ }
        }
        return output;
    }

    private static boolean searchProduct(Object node, Product out, int depth, String defaultCurrency) {
        if (depth > 9) return false;
        if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < Math.min(a.length(), 60); i++) if (searchProduct(a.opt(i), out, depth + 1, defaultCurrency)) return true;
        } else if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            if (isProductType(obj.opt("@type"))) {
                out.name = clean(obj.optString("name", null));
                out.image = imageValue(obj.opt("image"));
                offer(obj.opt("offers"), out, depth + 1, defaultCurrency, false);
                return true;
            }
            // Products are commonly nested under @graph, mainEntity or itemListElement.
            String[] fields = {"@graph", "mainEntity", "itemListElement", "item", "about", "hasPart"};
            for (String key : fields) if (searchProduct(obj.opt(key), out, depth + 1, defaultCurrency)) return true;
        }
        return false;
    }

    private static boolean isProductType(Object types) {
        if (types instanceof JSONArray) {
            JSONArray a = (JSONArray) types;
            for (int i = 0; i < a.length(); i++) if (isProductType(a.opt(i))) return true;
        }
        if (types instanceof String) {
            String s = ((String) types).toLowerCase(Locale.ROOT);
            return s.equals("product") || s.endsWith("/product") || s.endsWith(":product");
        }
        return false;
    }

    /** Traverse Offer / priceSpecification, inheriting currency from the parent. */
    private static void offer(Object node, Product out, int depth, String inheritedCurrency,
                              boolean inheritedAggregate) {
        if (depth > 9 || node == null) return;
        if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < Math.min(a.length(), 30); i++)
                offer(a.opt(i), out, depth + 1, inheritedCurrency, inheritedAggregate);
        } else if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            String currency = coalesce(o.optString("priceCurrency", null), inheritedCurrency);
            boolean aggregate = inheritedAggregate || typeMatches(o.opt("@type"), "aggregateoffer");
            if (out.availability == null) out.availability = clean(o.optString("availability", null));
            // An AggregateOffer lowPrice is only a range floor, not the purchasable price.
            if (out.price == null && !aggregate && "JPY".equalsIgnoreCase(currency))
                out.price = parsePrice(o.optString("price", null));
            if (out.price == null && !aggregate && "JPY".equalsIgnoreCase(currency))
                out.price = parsePrice(o.optString("value", null));
            offer(o.opt("priceSpecification"), out, depth + 1, currency, aggregate);
            offer(o.opt("offers"), out, depth + 1, currency, aggregate);
        }
    }

    private static boolean typeMatches(Object types, String needle) {
        if (types instanceof JSONArray) {
            JSONArray arr = (JSONArray) types;
            for (int i = 0; i < arr.length(); i++) if (typeMatches(arr.opt(i), needle)) return true;
        } else if (types instanceof String) {
            String type = ((String) types).toLowerCase(Locale.ROOT);
            return type.equals(needle) || type.endsWith("/" + needle) || type.endsWith(":" + needle);
        }
        return false;
    }

    private static boolean isYenText(String raw) {
        return raw != null && (raw.contains("¥") || raw.contains("￥") || raw.contains("円")
                || raw.toLowerCase(Locale.ROOT).contains("&yen;"));
    }

    /** Itemprop content from Product price meta/span; currency must be JPY or page must be Japanese. */
    private static Long itempropPrice(String html, URL page) {
        Matcher tags = PRICE_TAG.matcher(html);
        String currency = null;
        String raw = null;
        while (tags.find()) {
            Map<String, String> attrs = attributes(tags.group());
            String field = attrs.get("itemprop");
            if (field == null) continue;
            if (field.equalsIgnoreCase("priceCurrency"))
                currency = clean(coalesce(attrs.get("content"), attrs.get("value")));
            if (field.equalsIgnoreCase("price"))
                raw = clean(coalesce(attrs.get("content"), attrs.get("value")));
            if (currency != null && raw != null) break;
        }
        if (currency != null && !"JPY".equalsIgnoreCase(currency)) return null;
        return currency != null || isJapanSite(page) || isYenText(raw) ? parsePrice(raw) : null;
    }

    /** Amazon's current-price containers and other explicitly named product price elements. */
    private static Long shopPrice(String html, URL page) {
        if (!isJapanSite(page)) return null;
        Matcher tags = PRICE_TAG.matcher(html);
        while (tags.find()) {
            Map<String, String> attrs = attributes(tags.group());
            String id = attrs.get("id");
            String classes = attrs.get("class");
            if (id != null && (id.equals("priceblock_ourprice") || id.equals("priceblock_dealprice")
                    || id.equals("priceblock_saleprice") || id.equals("price_inside_buybox")
                    || id.equals("newBuyBoxPrice"))) {
                int finish = Math.min(html.length(), tags.end() + 300);
                String snippet = html.substring(tags.end(), finish);
                Long p = yenPriceFirst(snippet);
                if (p != null) return p;
            }
            // Current Amazon price is normally inside a priceToPay element, with a
            // visually hidden, accessibility-friendly single price (a-offscreen).
            boolean toPay = (id != null && id.equals("priceToPay"))
                    || (classes != null && java.util.Arrays.asList(classes.split("\\s+")).contains("priceToPay"));
            if (toPay) {
                String snippet = html.substring(tags.end(), Math.min(html.length(), tags.end() + 1400));
                Matcher hidden = OFFSCREEN_PRICE.matcher(snippet);
                if (hidden.find()) {
                    Long p = parsePrice(clean(hidden.group(1)));
                    if (p != null) return p;
                }
            }
        }
        return null;
    }

    private static Long yenPriceFirst(String html) {
        Matcher m = Pattern.compile("(?:[¥￥]\\s*|&yen;\\s*)([0-9][0-9,]*(?:\\.[0-9]{1,2})?)",
                Pattern.CASE_INSENSITIVE).matcher(html);
        return m.find() ? parsePrice(m.group(1)) : null;
    }

    /** Some commerce pages (notably Amazon) expose the product hero image on the img element. */
    private static String fallbackImage(String html, URL page) {
        Matcher links = LINK.matcher(html);
        while (links.find()) {
            Map<String, String> attrs = attributes(links.group());
            String rel = attrs.get("rel");
            if (rel != null && rel.toLowerCase(Locale.ROOT).contains("image_src")) {
                String candidate = absoluteImage(page, clean(attrs.get("href")));
                if (candidate != null) return candidate;
            }
        }
        Matcher images = IMAGE.matcher(html);
        while (images.find()) {
            Map<String, String> attrs = attributes(images.group());
            String id = attrs.get("id");
            boolean productImage = "landingImage".equalsIgnoreCase(id) || "imgBlkFront".equalsIgnoreCase(id)
                    || attrs.containsKey("data-a-dynamic-image");
            if (!productImage) continue;
            String candidate = absoluteImage(page, clean(coalesce(attrs.get("data-old-hires"), attrs.get("data-src"), attrs.get("src"))));
            if (candidate != null) return candidate;
            String dynamic = clean(attrs.get("data-a-dynamic-image"));
            if (dynamic == null) continue;
            try {
                JSONObject urls = new JSONObject(dynamic);
                java.util.Iterator<String> keys = urls.keys();
                while (keys.hasNext()) {
                    candidate = absoluteImage(page, keys.next());
                    if (candidate != null) return candidate;
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    private static String imageValue(Object obj) {
        if (obj instanceof String) return clean((String) obj);
        if (obj instanceof JSONArray) {
            JSONArray a = (JSONArray) obj;
            for (int i = 0; i < a.length(); i++) {
                String s = imageValue(a.opt(i));
                if (s != null) return s;
            }
        }
        if (obj instanceof JSONObject) {
            JSONObject o = (JSONObject) obj;
            return coalesce(o.optString("url", null), o.optString("contentUrl", null));
        }
        return null;
    }

    private static Map<String, String> attributes(String tag) {
        Map<String, String> out = new HashMap<>();
        Matcher a = ATTRIBUTE.matcher(tag);
        while (a.find()) {
            String key = a.group(1).toLowerCase(Locale.ROOT);
            out.putIfAbsent(key, coalesce(a.group(2), a.group(3), a.group(4)));
        }
        return out;
    }

    private static String absoluteImage(URL page, String raw) {
        if (raw == null) return null;
        try {
            URL image = new URL(page, raw.trim());
            return isAllowedUrl(image) && "https".equalsIgnoreCase(image.getProtocol()) ? image.toString() : null;
        } catch (Exception ignored) { return null; }
    }

    static boolean isAllowedUrl(URL url) {
        String protocol = url.getProtocol();
        if (!"http".equalsIgnoreCase(protocol) && !"https".equalsIgnoreCase(protocol)) return false;
        String host = url.getHost();
        if (host == null || host.isBlank()) return false;
        String h = host.toLowerCase(Locale.ROOT);
        if (h.equals("localhost") || h.endsWith(".local") || h.endsWith(".internal") || h.equals("0.0.0.0") || h.equals("::1") || h.equals("[::1]")) return false;
        if (h.matches("(?:127|10|0)\\.\\d+\\.\\d+\\.\\d+")) return false;
        if (h.matches("192\\.168\\.\\d+\\.\\d+")) return false;
        if (h.matches("172\\.(?:1[6-9]|2\\d|3[01])\\.\\d+\\.\\d+")) return false;
        if (h.matches("169\\.254\\.\\d+\\.\\d+")) return false;
        return !h.contains(":"); // IPv6 literals (including local addresses) are not previewed.
    }

    private static boolean isJapanSite(URL u) { String h = u.getHost().toLowerCase(Locale.ROOT); return h.endsWith(".jp"); }

    private static Long parsePrice(String s) {
        if (s == null) return null;
        try {
            String numeric = clean(s);
            if (numeric == null) return null;
            numeric = numeric.replace(",", "").replace("¥", "").replace("￥", "")
                    .replace("円", "").replace("\u00a0", "").replace(" ", "").trim();
            if (!numeric.matches("[0-9]+(?:\\.[0-9]{1,2})?")) return null;
            double d = Double.parseDouble(numeric);
            return d >= 1 && d <= 100_000_000 ? Math.round(d) : null;
        } catch (Exception ignored) { return null; }
    }

    private static String statusFromAvailability(String status) {
        String a = status.toLowerCase(Locale.ROOT);
        if (a.endsWith("instock") || a.endsWith("preorder") || a.endsWith("presale")) return "AVAILABLE";
        if (a.endsWith("outofstock") || a.endsWith("soldout") || a.endsWith("discontinued")) return "UNAVAILABLE";
        if (a.endsWith("prelaunch")) return "COMING_SOON";
        return "UNKNOWN";
    }

    private static String status(String html) {
        // Use the original conservative text-based fallback when a page has no product availability metadata.
        String t = html.toLowerCase(Locale.ROOT);
        if (containsAny(t, "coming soon", "近日公開", "販売開始前")) return "COMING_SOON";
        if (containsAny(t, "sold out", "out of stock", "在庫切れ", "売り切れ", "完売")) return "UNAVAILABLE";
        if (containsAny(t, "in stock", "カートに入れる", "今すぐ購入")) return "AVAILABLE";
        return "UNKNOWN";
    }
    private static boolean containsAny(String text, String... keys) { for (String key : keys) if (text.contains(key)) return true; return false; }
    private static String first(String text, Pattern p) { Matcher m = p.matcher(text); return m.find() ? m.group(1) : null; }
    private static String clean(String s) {
        if (s == null) return null;
        String cleaned = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\\s+", " ").trim();
        return cleaned.isBlank() ? null : cleaned;
    }
    private static String coalesce(String... values) { for (String s : values) if (s != null && !s.isBlank()) return s; return null; }
    private static String host(String url) {
        try { String h = new URI(url).getHost(); return h == null ? null : (h.startsWith("www.") ? h.substring(4) : h); }
        catch (Exception ignored) { return null; }
    }
    private static final class Product { String name, image, availability; Long price; }
    public static final class Result {
        public boolean success;
        public int httpCode;
        public String title;
        public String imageUrl;
        public String sourceName;
        public Long price;
        public String status = "UNKNOWN";
    }
}
