package com.cmyk.bookmarkslauncher.wishlist;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Transport/orchestrator only. Name and price never call each other's parsers. */
public final class WishlistCrawler {
    private static final String TAG="WishlistCrawler";
    private static final int MAX_HTML_BYTES=2_000_000;
    private static final Pattern CHARSET=Pattern.compile("charset\\s*=\\s*['\"]?([a-zA-Z0-9_\\-]+)",Pattern.CASE_INSENSITIVE);
    private WishlistCrawler(){}
    public static Result fetch(String urlText) { return fetch(urlText, ""); }
    public static Result fetch(String urlText, String note) {
        Result out = new Result();
        if (urlText == null || urlText.isBlank()) { out.failureReason = "URLなし"; return out; }
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlText.trim());
            if (!isAllowedUrl(url)) { out.failureReason = "URL対象外"; return out; }
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(15000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36");
            conn.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en;q=0.6");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.5");
            out.httpCode = conn.getResponseCode();
            if (!isAllowedUrl(conn.getURL())) { out.failureReason = "転送先URL対象外"; return out; }
            out.resolvedUrl = conn.getURL().toString();
            MarketplaceIdentity requested = MarketplaceIdentity.from(url);
            if (requested != null && !requested.matches(conn.getURL())) {
                out.failureReason = "商品の転送先IDが一致せず";
                return out;
            }
            if (out.httpCode < 200 || out.httpCode >= 300) {
                String response = "";
                if (out.httpCode == 503) {
                    try (java.io.InputStream error = conn.getErrorStream()) {
                        if (error != null) response = new String(error.readNBytes(65536), StandardCharsets.UTF_8);
                    } catch (Exception ignored) { }
                }
                out.siteState = WishlistSiteState.classify(out.httpCode, response);
                out.failureReason = "HTTP " + out.httpCode;
                return out;
            }
            String type = conn.getContentType();
            if (type != null && !type.toLowerCase(Locale.ROOT).contains("html")) { out.failureReason = "HTML以外"; return out; }
            byte[] bytes;
            try (BufferedInputStream input = new BufferedInputStream(conn.getInputStream());
                 ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                byte[] block = new byte[8192];
                int n;
                while ((n = input.read(block)) != -1 && buffer.size() < MAX_HTML_BYTES) {
                    buffer.write(block, 0, Math.min(n, MAX_HTML_BYTES - buffer.size()));
                }
                bytes = buffer.toByteArray();
            }
            Charset charset = charset(type, bytes);
            String html = new String(bytes, charset);
            out.siteState = WishlistSiteState.classify(out.httpCode, html);
            if (!WishlistSiteState.OK.equals(out.siteState)) {
                out.failureReason = WishlistSiteState.label(out.siteState);
                return out; // Maintenance page is NOT a product page.
            }
            // Reject a marketplace page with a contradictory canonical identity;
            // do not overwrite any previously correct item data.
            if (MarketplaceIdentity.site(conn.getURL()) != MarketplaceIdentity.Site.OTHER) {
                MarketplaceIdentity id = MarketplaceIdentity.from(conn.getURL());
                if (id == null || !id.verified(html, conn.getURL())) {
                    out.failureReason = "対象商品の同一性を検証できず";
                    return out;
                }
            }
            parseHtml(html, conn.getURL(), out);
            // Independent image candidates are already resolved for the three
            // marketplaces. Keep the established independent-shop extractor intact.
            if (MarketplaceIdentity.site(conn.getURL()) == MarketplaceIdentity.Site.OTHER
                    && isSingleProductPage(conn.getURL())) {
                out.retailImageCandidates = WishlistRetailImageCandidates.fromHtml(html, conn.getURL());
            }
            // A visible minimum/range is not a confirmed purchasable price.
            // Read it only on one-product URLs, never from a category page.
            if (MarketplaceIdentity.site(conn.getURL()) == MarketplaceIdentity.Site.OTHER
                    && isSingleProductPage(conn.getURL())) {
                WishlistRetailPriceQuote quote = WishlistRetailPriceQuote.fromHtml(html);
                if (quote != null) {
                    out.priceQuote = quote;
                    out.price = null;
                    // Never treat a listing's incidental "sold out" as proof that a
                    // size-selectable (FROM/RANGE) item cannot be purchased.
                    if (!out.availabilityExplicit && "UNAVAILABLE".equals(out.status)) out.status = "UNKNOWN";
                }
            }
            // Notes are optional product selectors on multi-product pages. The
            // standard Amazon/single-product code above is never modified.
            // A product-detail URL already identifies one product. Never let an
            // optional note override that product with a coincidental text match;
            // keeping noteTargetMatched=false also allows WebView price recovery.
            if (note != null && !note.isBlank() && !isSingleProductPage(conn.getURL())) {
                WishlistNoteSection section = WishlistNoteSection.find(html, note);
                if (section != null) {
                    out.noteTargetMatched = true;
                    WishlistAvailabilityExtractor.Result noteStock =
                            WishlistAvailabilityExtractor.parseNoteSection(section);
                    out.status = noteStock.status; // Never inherit page-wide stock status.
                    out.availabilityExplicit = noteStock.explicit;
                    // Image and price remain separate analyses and separate DB writes.
                    String image = WishlistNoteMetadataExtractor.image(section.before, conn.getURL());
                    Long selectedPrice = WishlistNotePriceExtractor.price(section.after);
                    out.title = section.name;
                    out.imageUrl = image; // Never use the page-wide image for a selected product.
                    out.price = selectedPrice; // Never mix another product's price.
                    if (selectedPrice == null) out.failureReason = "備考欄の商品価格を一意に特定できず";
                }
            }
            out.sourceName = host(conn.getURL().toString());
            out.success = true;
            if (out.price == null && out.priceQuote == null && out.failureReason == null) out.failureReason = "価格情報を特定できず";
        } catch (SocketTimeoutException error) {
            out.siteState = WishlistSiteState.TIMEOUT;
            out.failureReason = "通信タイムアウト";
            Log.d(TAG, "Preview timeout", error);
        } catch (Exception error) {
            out.siteState = WishlistSiteState.CONNECT_FAILED;
            out.failureReason = "通信・解析エラー";
            Log.d(TAG, "Preview not available for URL", error);
        } finally {
            if (conn != null) conn.disconnect();
        }
        return out;
    }


    private static Charset charset(String contentType, byte[] data) {
        String guess = contentType == null ? "" : contentType;
        Matcher c = CHARSET.matcher(guess);
        String name = c.find() ? c.group(1) : null;
        if (name == null) {
            // Some Japanese shops declare Shift_JIS only in their HTML head.
            String head = new String(data, 0, Math.min(data.length, 8192), StandardCharsets.ISO_8859_1);
            c = CHARSET.matcher(head);
            if (c.find()) name = c.group(1);
        }
        try { return name == null ? StandardCharsets.UTF_8 : Charset.forName(name); }
        catch (Exception ignored) { return StandardCharsets.UTF_8; }
    }
    static void parseHtml(String html,URL page,Result out) {
        // The three largest marketplaces have their own strictly scoped pipelines.
        // A page without a product ID is never allowed to return related products.
        if (MarketplaceIdentity.site(page) != MarketplaceIdentity.Site.OTHER) {
            MarketplaceIdentity identity = MarketplaceIdentity.from(page);
            if (identity == null || !identity.verified(html, page)) {
                out.status = "UNKNOWN";
                out.availabilityReason = "対象の商品IDまたはcanonicalが一致しません";
                return;
            }
            try { out.title = MarketplaceNameExtractor.find(html, page); }
            catch (RuntimeException e) { Log.w(TAG, "Marketplace name", e); }
            try {
                out.retailImageCandidates = identity.site == MarketplaceIdentity.Site.AMAZON
                        ? AmazonProductImageExtractor.candidates(html, page)
                        : MarketplaceImageExtractor.candidates(html, page);
                if (!out.retailImageCandidates.isEmpty()) out.imageUrl = out.retailImageCandidates.get(0);
            } catch (RuntimeException e) { Log.w(TAG, "Marketplace images", e); }
            try {
                out.price = MarketplacePriceExtractor.parse(html, page);
                if (out.price == null) out.priceQuote = MarketplacePriceExtractor.quote(html, page);
            } catch (RuntimeException e) { Log.w(TAG, "Marketplace price", e); }
            try {
                WishlistAvailabilityExtractor.Result stock = MarketplaceAvailabilityExtractor.parse(html, page);
                out.status = stock.status;
                out.availabilityExplicit = stock.explicit;
                out.availabilityReason = stock.reason;
                Log.d(TAG, "Marketplace stock " + identity.site + ": " + stock.reason);
            } catch (RuntimeException e) { Log.w(TAG, "Marketplace stock", e); }
            return;
        }
        // Independent shops retain their previously successful parsers.
        try {
            WishlistMetadataExtractor.Result metadata=WishlistMetadataExtractor.parse(html,page);
            out.title=metadata.title;
            out.imageUrl=metadata.imageUrl;
            out.status=metadata.status;
            out.availabilityExplicit=metadata.availabilityExplicit;
        }catch(RuntimeException error){Log.w(TAG,"Metadata parser failed independently",error);}
        try {
            out.price=WishlistPriceExtractor.parse(html,page);
        }catch(RuntimeException error){Log.w(TAG,"Price parser failed independently",error);}
    }

    /** Conservative detail URL recognition; never assume a category listing is one product. */
    public static boolean isSingleProductPage(URL url) {
        if (url == null) return false;
        if (MarketplaceIdentity.from(url) != null) return true;
        String path = url.getPath().toLowerCase(Locale.ROOT);
        // Product pages on independent Japanese shop platforms (not category lists).
        if (path.matches(".*/product/detail/[^/]+/?")
                || path.matches(".*/products/[^/]+/?")
                || path.matches(".*/item/detail/[^/]+/?")
                || path.matches(".*/product/[0-9]+/?")              // ocnk
                || path.matches(".*/item-detail/[0-9]+/?")          // shop platform
                || path.matches(".*/item_detail_[0-9]+\\.html"))   // standalone shop
            return true;
        if (path.endsWith("/index.php")) {
            String query = url.getQuery();
            if (query != null && query.matches("(?is)(?=.*(?:^|&)dispatch=products\\.view(?:&|$))(?=.*(?:^|&)product_id=[0-9]+(?:&|$)).*"))
                return true; // CS-Cart; requires BOTH identifiers
        }
        return false;
    }

    static boolean isAllowedUrl(URL url) {
        String protocol = url.getProtocol();
        if (!"http".equalsIgnoreCase(protocol) && !"https".equalsIgnoreCase(protocol)) return false;
        String host = url.getHost();
        if (host == null || host.isBlank()) return false;
        String h = host.toLowerCase(Locale.ROOT);
        if (h.equals("localhost") || h.endsWith(".local") || h.endsWith(".internal") || h.equals("0.0.0.0") || h.equals("::1") || h.equals("[::1]")) return false;
        if (h.matches("(?:127|10|0)\\.\\d+\\.\\d+\\.\\d+")) return false;
        if (h.matches("192\\.168\\.\\d+\\.\\d+")) return false;
        if (h.matches("172\\.(?:1[6-9]|2\\d|3[01])\\.\\d+\\.\\d+")) return false;
        if (h.matches("169\\.254\\.\\d+\\.\\d+")) return false;
        return !h.contains(":"); // IPv6 literals (including local addresses) are not previewed.
    }
    private static String host(String url) {
        try { String h = new URI(url).getHost(); return h == null ? null : (h.startsWith("www.") ? h.substring(4) : h); }
        catch (Exception ignored) { return null; }
    }
    public static final class Result {
        public boolean noteTargetMatched;
        public boolean availabilityExplicit;
        public String availabilityReason;
        public String siteState = WishlistSiteState.OK;
        public boolean success;
        public int httpCode;
        public String resolvedUrl;
        public String title;
        public String imageUrl;
        public java.util.List<String> retailImageCandidates = java.util.Collections.emptyList();
        public String sourceName;
        public Long price;
        public WishlistRetailPriceQuote priceQuote;
        public String failureReason;
        public String status="UNKNOWN";
    }
}
