package com.cmyk.bookmarkslauncher.wishlist;

/**
 * Reusable *techniques*, not cloned site modes: each policy consumes the
 * same product-bound evidence (r, hit, panelText, localPositive, jsonState,
 * live, root, bad). Merchant-specific routing and WebView lifetime are NOT
 * part of these policies. Dedicated site engines remain unchanged.
 *
 * Unverified evidence must leave status UNKNOWN; never infer stock from a
 * bare enabled cart button. Techniques run serially, sharing the same DOM.
 */
public final class WishlistGeneralEvidenceTechniques {
    private WishlistGeneralEvidenceTechniques() { }

    public static String label(char technique) {
        return switch (technique) {
            case 'B' -> "sku-stock-quantity";
            case 'C' -> "local-buybox-stock";
            case 'D' -> "structured-product-offer";
            case 'E' -> "selected-variant-evidence";
            case 'F' -> "dynamic-product-stock";
            case 'G' -> "variant-local-stock";
            case 'H' -> "exact-listing-state";
            default -> "unknown";
        };
    }

    public static String script(char technique) {
        return switch (technique) {
            case 'B' -> """
    // SKU/quantity technique (origin: ASKUL): SKU-bound product, quantity, explicit visible stock and cart.
    if((r.sku||hit.attrBound)&&r.positive&&hit.nearQty&&localPositive){
      r.status='AVAILABLE';r.reason='sku-stock-quantity-cart';
    }else r.reason='sku-stock-or-quantity-missing';
""";
            case 'C' -> """
    // Local buybox technique (origin: Yodobashi): lone product buybox and positive local selling-stock label.
    if(r.positive&&localPositive&&(hit.panel.matches('form')||hit.nearQty||r.sku||hit.attrBound)){
      r.status='AVAILABLE';r.reason='local-buybox-stock-cart';
    }else r.reason='local-buybox-unverified';
""";
            case 'D' -> """
    // Structured-offer technique (origin: Bic Camera): URL-bound Product offer with InStock and live product cart.
    if(r.jsonBound&&jsonState==='AVAILABLE'&&(r.positive||localPositive)){
      r.status='AVAILABLE';r.reason='structured-same-product-cart';
    }else r.reason='structured-offer-or-stock-unverified';
""";
            case 'E' -> """
    // Selected-variant technique (origin: UNIQLO): selection-dependent; NEVER infer a color/size from page defaults.
    const variants=[...root.querySelectorAll('select[required],[aria-required=true],[data-variant-selected]')]
      .filter(e=>live(e)&&!e.closest(bad));
    const allSelected=variants.length>0&&variants.every(e=>
      e.tagName==='SELECT'?!!e.value&&e.selectedIndex>=0:
      e.getAttribute('data-variant-selected')==='true'||e.getAttribute('aria-checked')==='true');
    if(allSelected&&hit.nearQty&&(r.positive||jsonState==='AVAILABLE')){
      r.status='AVAILABLE';r.reason='selected-variant-stock-cart';
    }else r.reason='variant-not-proven';
""";
            case 'F' -> """
    // Port the positive JSON-LD binding proven by MUJI's dedicated engine:
    // an exact-SKU/URL-bound InStock offer and a single real product CTA can
    // verify availability without a numeric quantity field.  Site-independent
    // F uses the same read-only evidence standard, never the MUJI hostname.
    // Stock-proof technique (origin: MUJI): the cart button may remain enabled after stock is gone. Need a
    // product-bound explicit stock signal in addition to the live cart.
    // MUJI may leave the button live when the online item is out of stock.
    // Require either verified stock text in this product's own buybox or an
    // exact-URL/SKU-linked Product offer claiming InStock. Neither a cart
    // button nor a store-availability popup alone can establish availability.
    if((hit.nearQty&&r.positive&&localPositive)||
       (r.jsonBound&&jsonState==='AVAILABLE'&&
        (r.sku||hit.attrBound||knownUrl||!location.search))){
      r.stockSource=r.jsonBound&&jsonState==='AVAILABLE'?'same-product-offer':'visible-buybox';
      r.status='AVAILABLE';r.reason='dynamic-product-positive-stock-cart';
    }else r.reason=hit.nearQty?'stock-unverified':'quantity-unverified';
""";
            default -> "r.reason='unknown-technique';";
        };
    }
}
