package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** BicCamera mode ONLY. Variant/used prices may not overwrite the main item. */
final class BicCameraProductExtractor {
    private static final Pattern H1=Pattern.compile("(?is)<h1\\b[^>]*>(.*?)</h1>");
    private BicCameraProductExtractor(){}
    static void parse(String html,URL page,WishlistCrawler.Result out){
        if(WishlistMode.forLargeRetailUrl(page)!=WishlistMode.BICCAMERA||!LargeRetailHtml.validCanonical(html,page)){
            out.availabilityReason="ビックカメラの商品同一性が確認できません";return;
        }
        Matcher m=H1.matcher(html);
        out.title=LargeRetailHtml.cleanTitle(m.find()?m.group(1).replaceAll("<[^>]+>","")
                :LargeRetailHtml.ogTitle(html),"BICCAMERA");
        out.imageUrl=LargeRetailHtml.mainImage(html,"BICCAMERA");
        // Official main-product image filename is keyed by the Bic goods number.
        // Candidate bytes must pass the normal HTTP/image verification before saving.
        String item = page.getPath().replaceFirst("^/bc/item/([0-9]{5,15})/?$", "$1");
        if (item.matches("[0-9]{5,15}")) {
            String candidate = "https://image.biccamera.com/img/"
                    + String.format(java.util.Locale.ROOT,"%014d",Long.parseLong(item)) + "_A01.jpg";
            if (out.imageUrl == null) out.imageUrl = candidate;
            out.retailImageCandidates = java.util.List.of(candidate);
        }
        if (out.imageUrl == null) {
            for (String key : new String[]{"twitter:image", "twitter:image:src"}) {
                String raw = LargeRetailHtml.meta(html, key);
                if (raw == null || raw.isBlank()) continue;
                try {
                    URL candidate = new URL(page, raw);
                    String host = candidate.getHost().toLowerCase(java.util.Locale.ROOT);
                    if ("https".equalsIgnoreCase(candidate.getProtocol())
                            && (host.equals("biccamera.com") || host.endsWith(".biccamera.com"))) {
                        out.imageUrl = candidate.toString();
                        break;
                    }
                } catch (Exception ignored) { }
            }
        }
        out.price=LargeRetailHtml.metaYenPrice(html);
        out.status="UNKNOWN";
        out.availabilityReason="ビックカメラの通常商品と限定版・中古品を区別しDOM検証待ち";
    }
    static String domScript(){return LargeRetailDomScripts.biccamera();}
}
