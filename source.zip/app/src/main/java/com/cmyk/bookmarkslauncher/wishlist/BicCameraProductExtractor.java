package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** BicCamera mode ONLY. Variant/used prices may not overwrite the main item. */
final class BicCameraProductExtractor {
    private static final Pattern H1=Pattern.compile("(?is)<h1\\b[^>]*>(.*?)</h1>");
    private BicCameraProductExtractor(){}
    static void parse(String html,URL page,WishlistCrawler.Result out){
        if(WishlistMode.forLargeRetailUrl(page)!=WishlistMode.BICCAMERA||!LargeRetailHtml.validCanonical(html,page)){
            out.availabilityReason="ビックカメラの商品同一性が確認できません";return;
        }
        Matcher m=H1.matcher(html);
        out.title=LargeRetailHtml.cleanTitle(m.find()?m.group(1).replaceAll("<[^>]+>","")
                :LargeRetailHtml.ogTitle(html),"BICCAMERA");
        // This is the same SEO image information that Google can index, read
        // directly from the merchant page without scraping Google search results.
        // Try published main-product image links BEFORE a speculative CDN path.
        java.util.LinkedHashSet<String> images=new java.util.LinkedHashSet<>();
        String item=page.getPath().replaceFirst("^/bc/item/([0-9]{5,15})/?$", "$1");
        if(item.matches("[0-9]{5,15}")){
            for(String key:new String[]{"og:image", "twitter:image", "twitter:image:src", "image"}){
                String raw=LargeRetailHtml.meta(html,key);
                String valid=verifiedImageUrl(raw,page,item);
                if(valid!=null) images.add(valid);
            }
            // Embedded catalog assets sometimes appear only in main-product
            // HTML, not in OG metadata. Require an exact item-code file name.
            Pattern imagePattern=Pattern.compile("https?://[^\\\"'\\\\\\s<>]{8,350}\\.(?:jpg|jpeg|webp|png)(?:\\?[^\\\"'<>\\\\\\s]{0,80})?",Pattern.CASE_INSENSITIVE);
            Matcher imagesInHtml=imagePattern.matcher(html);
            while(imagesInHtml.find()&&images.size()<8){
                String candidate=verifiedImageUrl(imagesInHtml.group(),page,item);
                if(candidate!=null && imageContainsProductCode(candidate,item))images.add(candidate);
            }
            // Last resort is a candidate, never assumed to be a real image;
            // BitmapFactory and the network response must validate its bytes.
            String last="https://image.biccamera.com/img/"
                    +String.format(java.util.Locale.ROOT,"%014d",Long.parseLong(item))+"_A01.jpg";
            images.add(last);
        }
        out.retailImageCandidates=new java.util.ArrayList<>(images);
        if(!images.isEmpty())out.imageUrl=images.iterator().next();
        out.price=LargeRetailHtml.metaYenPrice(html);
        out.status="UNKNOWN";
        out.availabilityReason="ビックカメラの通常商品と限定版・中古品を区別しDOM検証待ち";
    }

    /** Never read unrelated product/used-item thumbnails as the hero image. */
    private static String verifiedImageUrl(String raw,URL page,String id){
        if(raw==null||raw.isBlank())return null;
        try {
            URL candidate=new URL(page,LargeRetailHtml.unescape(raw));
            String host=candidate.getHost().toLowerCase(java.util.Locale.ROOT);
            if(!"https".equalsIgnoreCase(candidate.getProtocol())
                    ||!(host.equals("biccamera.com")||host.endsWith(".biccamera.com")))return null;
            String path=candidate.getPath().toLowerCase(java.util.Locale.ROOT);
            if(!(path.endsWith(".jpg")||path.endsWith(".jpeg")||path.endsWith(".png")||path.endsWith(".webp")))return null;
            if(path.contains("placeholder")||path.contains("noimage")||path.contains("loading"))return null;
            java.util.regex.Matcher m=Pattern.compile("/([0-9]{8,15})_[A-Za-z][0-9]{2}\\.(?:jpg|jpeg|png|webp)$",Pattern.CASE_INSENSITIVE).matcher(path);
            if(m.find()&&!stripZeros(m.group(1)).equals(stripZeros(id)))return null;
            return candidate.toString();
        }catch(Exception ignored){return null;}
    }
    private static String stripZeros(String s){return s.replaceFirst("^0+(?!$)","");}
    private static boolean imageContainsProductCode(String raw,String id){
        try {
            String path=new URL(raw).getPath();
            String padded=String.format(java.util.Locale.ROOT,"%014d",Long.parseLong(id));
            return path.contains(id)||path.contains(padded);
        }catch(Exception ignored){return false;}
    }
    static String domScript(){return LargeRetailDomScripts.biccamera();}
}
