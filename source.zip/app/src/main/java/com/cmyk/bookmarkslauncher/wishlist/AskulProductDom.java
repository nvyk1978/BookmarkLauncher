package com.cmyk.bookmarkslauncher.wishlist;

/**
 * ASKUL-only official product DOM. Uses the requested /p/ code plus the
 * on-page お申込番号 label, never only a URL or a generic shopping-site price.
 * No clicks, login bypass, caches of stale quoted prices, or fixed yen amounts.
 */
final class AskulProductDom {
    private AskulProductDom() { }

    private static boolean valid(String sku) {
        return sku != null && sku.matches("[A-Za-z0-9_-]{5,20}");
    }

    private static String preamble(String sku) {
        return "var sku='" + sku + "';" +
                "var path=(location.pathname||'').replace(/\\/+$/,'').toLowerCase();" +
                "if(path!=='/p/'+sku.toLowerCase())return empty('url-mismatch');" +
                "var body=document.body;if(!body)return empty('body-missing');" +
                "var main=document.querySelector('main,[role=main],#main,#contents,#productDetail,#product-detail')||body;" +
                "function plain(n){return ((n&&(n.innerText||n.textContent))||'').replace(/\\u00a0/g,' ').replace(/　/g,' ');}" +
                "var text=plain(main),whole=plain(body);" +
                "var marker=new RegExp('お申込番号\\\\s*[:：]?\\\\s*'+sku+'(?![A-Za-z0-9_-])','i');" +
                "var m=marker.exec(text);if(!m&&main!==body){text=whole;m=marker.exec(text);}" +
                "var heading=!!document.querySelector('h1');" +
                "var blocked=/(?:Access\\s*Denied|Forbidden|Request\\s*Blocked|アクセス制限|アクセスが集中|ご利用を制限|bot\\s*check|captcha)/i.test(whole);";
    }

    /** Returns JSON.stringify({value,currency,reason,...}) for the shared price probe. */
    static String price(String sku) {
        if (!valid(sku)) return "JSON.stringify({value:'',currency:'',reason:'invalid-sku'})";
        return "(function(){try{" +
                "function empty(r){return JSON.stringify({value:'',currency:'',reason:r,bodyChars:Math.min(99999,whole.length||0),h1:heading||false,skuLabel:!!m,blocked:blocked||false});}" +
                // Declare diagnostic fields before any potential early return.
                "var whole='',heading=false,m=null,blocked=false;" +
                preamble(sku) +
                "if(!m)return empty(blocked?'restricted-page':'sku-marker-missing');" +
                // Look *after the correctly labeled SKU*, where the official
                // product data grid has its own explicit 価格 ￥xxx（税込）.
                "var after=text.slice(m.index+m[0].length,Math.min(text.length,m.index+m[0].length+1600));" +
                "var boundary=after.search(/(?:商品詳細|関連商品|おすすめ商品|この商品を見た|配送オプション|お客様レビュー)/);" +
                "if(boundary>=0)after=after.slice(0,boundary);" +
                "var priceLabel=/(?:^|\\s)(?:価格|税込価格|販売価格)\\s*[:：]?\\s*[￥¥]\\s*([0-9][0-9,]*)\\s*(?:円\\s*)?[（(]\\s*税込\\s*[）)]/g;" +
                "var values=[],match;while((match=priceLabel.exec(after))!==null){values.push(match[1].replace(/,/g,''));if(values.length>=8)break;}" +
                // If the code's own price table is absent, consider only the
                // heading-side product offer *before* the shipping section.
                // Delivery options may also display tax-inclusive amounts.
                "if(!values.length){var before=text.slice(Math.max(0,m.index-2200),m.index);" +
                "var lastProduct=before.lastIndexOf('販売単位');" +
                "if(lastProduct>=0){var section=before.slice(Math.max(0,lastProduct-900));" +
                "var ship=section.search(/(?:配送オプション|配送料|送料|時間帯指定)/);" +
                "if(ship>=0)section=section.slice(0,ship);" +
                "var gross=/[￥¥]\\s*([0-9][0-9,]*)\\s*(?:円\\s*)?[（(]\\s*税込\\s*[）)]/g;" +
                "while((match=gross.exec(section))!==null){values.push(match[1].replace(/,/g,''));if(values.length>=8)break;}}}" +
                "if(!values.length)return empty('gross-label-missing');" +
                "var n=Number(values[0]);" +
                "if(!Number.isSafeInteger(n)||n<1||n>100000000)return empty('gross-invalid');" +
                "for(var i=1;i<values.length;i++)if(Number(values[i])!==n)return empty('gross-ambiguous');" +
                "return JSON.stringify({value:'¥'+n,currency:'JPY',reason:'verified-gross',bodyChars:Math.min(99999,whole.length),h1:heading,skuLabel:true,blocked:false});" +
                "}catch(e){return JSON.stringify({value:'',currency:'',reason:'script-error'});}})()";
    }

    /** ASKUL product-only purchase evidence. Both DOM and structured offers must
     * match the requested order code. Generic home-page carts and recommendation
     * products never prove the registered item's availability. */
    static String stockEvidence(String sku) {
        if (!valid(sku)) return "(function(){return JSON.stringify({status:'UNKNOWN',reason:'invalid-sku'});})()";
        return """
(function(){'use strict';
 const out={status:'UNKNOWN',reason:'no-evidence',skuLabel:false,stockFound:false,
    cartFound:0,cartEnabled:0,cartDisabled:0,restricted:false,
    productArea:false,structuredProduct:false,structuredOffer:false,bodyChars:0,
    domControls:0,cartTextHint:false,stockTextHint:false,iframes:0,
    accessibleFrames:0,skuFrames:0,frameCart:0,frameStock:0,
    localStockPositive:false,localStockNegative:false,scopeCut:false,scopeBefore:false,scopeAfter:false,scopeChars:0,
    productCartText:false,stockPosition:'none',sharedControls:0,sharedCarts:0,sharedEnabled:0,sharedOutside:0,liveCarts:0,liveEnabled:0,liveDisabled:0,modalCartCandidates:0,modalCartEnabled:0,modalPurchaseNamed:0,modalProductLinked:0,modalCartIntent:0,modalExcluded:0,modalTargetStock:0,modalTargetCart:0,modalTargetOther:0,
    productStockLabel:false,productStockConflict:false,productPurchaseText:false,productQuantity:false,productStockDistance:-1,productStockSource:'none',modalProductReady:0,productTextWindowChars:0,productWindowStock:false,productWindowNegative:false,productWindowPurchase:false,productWindowQuantity:false,productWindowQuantityControls:0,productHeadingChars:0,productMarkerPos:-1,productWindowReason:'not-scanned',productNextSkuCut:false};
 const done=()=>JSON.stringify(out);
 try{
 const scopeTools=__SHARED_SCOPE__;
 const code='__SKU__';
 if((location.pathname||'').replace(/\\/+$/,'').toLowerCase()!=='/p/'+code.toLowerCase()){
   out.reason='path-mismatch';return done();
 }
 const body=document.body;if(!body){out.reason='body-missing';return done();}
 const txt=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ');
 const all=txt(body);out.bodyChars=Math.min(all.length,99999);
 out.domControls=body.querySelectorAll('button,input[type=submit],input[type=button],input[type=image],[role=button]').length;
 out.cartTextHint=/(?:カート|ショッピングカート|買い物かご|お買い物かご|カゴ|かご|バスケット|バッグ)\\s*(?:に|へ)?\\s*(?:入れる|追加)|(?:カゴ|かご|買い物かご|お買い物かご)\\s*へ(?=\\s|$)|商品を\\s*(?:かご|カゴ|カート|バスケット)\\s*に追加|(?:今すぐ購入|購入する|注文する)|add[\\s_-]*to[\\s_-]*(?:cart|bag|basket|trolley)|buy\\s*(?:it\\s*)?now/i.test(all);
 out.stockTextHint=/在庫\s*[:：]?\s*(?:あり|有り|有)/.test(all);
 out.iframes=body.querySelectorAll('iframe').length;
 out.restricted=/(?:Access\\s*Denied|Forbidden|Request\\s*Blocked|アクセス制限|captcha)/i.test(all);
 if(out.restricted){out.reason='restricted-page';return done();}
 const marker=new RegExp('お申込番号\\\\s*[:：]?\\\\s*'+code+'(?![A-Za-z0-9_-])','i');
 let main=document.querySelector('main,[role=main],#main,#contents,#productDetail,#product-detail')||body;
 let scoped=txt(main),m=marker.exec(scoped);
 if(!m&&main!==body){scoped=all;main=body;m=marker.exec(scoped);}
 out.skuLabel=!!m;
 if(!m){out.reason='sku-marker-missing';return done();}
 // SKU-labelled product text. Never use header, delivery postcode popup,
 // stock legends, related items, or recommendation product cards.
 const bound=scopeTools.around(scoped,marker,2200,3900);
 if(!bound.found){out.reason='product-scope-missing';return done();}
 const local=bound.text;
 out.scopeBefore=bound.cutBefore;out.scopeAfter=bound.cutAfter;
 out.scopeCut=bound.cutBefore||bound.cutAfter;out.scopeChars=bound.chars;
 const purchase=scopeTools.controls(main,null);
 const live=scopeTools.liveCart(main,null);
 out.liveCarts=live.found;out.liveEnabled=live.enabled;out.liveDisabled=live.disabled;
 out.sharedControls=purchase.scanned;out.sharedCarts=purchase.found;
 out.sharedEnabled=purchase.enabled;out.sharedOutside=purchase.outside;
 out.productArea=local.length>60;
 const stockPositive=/在庫\\s*[:：]?\\s*(?:あり|有り|有)(?![料効])|アスクル在庫商品/.test(local);
 const stockNegative=/在庫\\s*[:：]?\\s*(?:なし|無し|切れ)|売り切れ|売切れ|販売終了|在庫切れ/.test(local);
 out.localStockPositive=stockPositive;out.localStockNegative=stockNegative;
 out.stockFound=stockPositive&&!stockNegative;
 out.stockPosition=stockPositive?'sku-neighborhood':(out.stockTextHint?'elsewhere-or-cut':'none');
 const visibleEnabled=e=>{
   if(!e||e.disabled||e.readOnly||e.getAttribute('disabled')!==null||e.getAttribute('aria-disabled')==='true')return false;
   if(/(?:disabled|soldout|sold-out|unavailable)/i.test(String(e.className||'')))return false;
   for(let n=e;n;n=n.parentElement){
     if(n.hidden||n.getAttribute('aria-hidden')==='true'||n.hasAttribute('inert'))return false;
     let style=getComputedStyle(n);
     if(style.display==='none'||style.visibility==='hidden'||style.visibility==='collapse'||Number(style.opacity)===0)return false;
   }
   return true;
 };
 // ASKUL may place the actual SKU's stock/quantity/cart panel AFTER a
 // recommendation block. 'around()' intentionally cuts such blocks and can
 // truncate this panel to ~701 characters. Independently inspect *visible*
 // short stock labels in the SKU's main product area, using its document order
 // and a bounded proximity to the exact item marker. Do not infer availability
 // from generic help text, related-item cards, catalog pages or stock legends.
 // This branch is not a substitute for the exact SKU URL and on-page marker.
 const productText=txt(main);
 const productMarker=marker.exec(productText);
 const markerPos=productMarker?productMarker.index:-1;
 const mainHeading=main.querySelector&&main.querySelector('h1');
 const headingText=mainHeading?txt(mainHeading).trim():'';
 const stockNodes=main.querySelectorAll?main.querySelectorAll('div,span,p,li,dt,dd,strong,b,label'):[];
 const stockPositiveLabel=/^在庫\\s*(?:[:：]\\s*|\\s+)(?:あり|有り)(?:\\s*[（(][^)）]*[)）])?\\s*$/;
 const stockNegativeLabel=/^在庫\\s*[:：]\\s*(?:なし|無し|切れ|切れです|なしです|完売|在庫切れ)\\s*$/;
 // A label after another SKU does not belong to the requested product.
 const nextOrderInMain=/お申込番号\\s*[:：]?\\s*[A-Za-z0-9_-]{5,20}/g;
 nextOrderInMain.lastIndex=markerPos>=0?markerPos+productMarker[0].length:0;
 const nextProduct=markerPos>=0?nextOrderInMain.exec(productText):null;
 let nearestStock=-1,stockPos=0,stockNeg=0;
 if(markerPos>=0){
   for(const node of Array.from(stockNodes).slice(0,2600)){
     const val=txt(node).trim().replace(/\\s+/g,' ');
     if(val.length>70||val.length<4)continue;
     const yes=stockPositiveLabel.test(val),no=stockNegativeLabel.test(val);
     if(!yes&&!no)continue;
     if(node.closest('header,nav,footer,aside,[class*=related],[class*=recommend],[class*=ranking],[id*=related],[id*=recommend],[class*=modal],[class*=dialog]'))continue;
     if(!visibleEnabled(node))continue;
     // Match this exact text within the same product main region, rather than
     // accepting e.g. a legend or catalog-wide unrelated stock badge.
     const at=productText.indexOf(val,Math.max(0,markerPos-2600));
     if(at<0||at<markerPos-1800||at>markerPos+7600)continue;
     if(nextProduct&&at>=nextProduct.index)continue;
     if(nearestStock<0||Math.abs(at-markerPos)<Math.abs(nearestStock-markerPos))nearestStock=at;
     if(yes)stockPos++;if(no)stockNeg++;
   }
 }
 // The exact SKU marker (rather than the h1 length) anchors this region.
 // ASKUL can render a blank/short h1 while keeping the SKU and purchase box.
 // Skip the next order number to exclude later related-product inventory.
 let boundedProduct='';
 out.productHeadingChars=headingText.length;
 out.productMarkerPos=markerPos;
 if(markerPos>=0){
   const headingAt=headingText.length>=5&&headingText.length<=240
     ?productText.indexOf(headingText):-1;
   const start=headingAt>=0&&headingAt<=markerPos&&markerPos-headingAt<=3500
     ?headingAt:Math.max(0,markerPos-1800);
   let end=Math.min(productText.length,markerPos+7900);
   const tail=productText.slice(markerPos+productMarker[0].length,end);
   const nextOrder=/お申込番号\\s*[:：]?\\s*[A-Za-z0-9_-]{5,20}/.exec(tail);
   if(nextOrder){
     end=Math.min(end,markerPos+productMarker[0].length+nextOrder.index);
     out.productNextSkuCut=true;
   }
   if(end>start&&end-start<=10500){
     boundedProduct=productText.slice(start,end);
     out.productWindowReason=headingAt>=0&&headingAt<=markerPos?'heading-or-sku':'sku-anchor';
   }else out.productWindowReason='invalid-range';
 }else out.productWindowReason='sku-marker-not-in-main';
 out.productTextWindowChars=boundedProduct.length;
 // The SKU must be visible for positive product-local stock evidence.
 if(!boundedProduct){stockPos=0;stockNeg=0;nearestStock=-1;}
 const positive=/(?:^|\\s)在庫\\s*[:：]\\s*(?:あり|有り)(?=\\s|$)|アスクル在庫商品/.test(boundedProduct);
 const negative=/(?:^|\\s)在庫\\s*[:：]\\s*(?:なし|無し|切れ)|(?:売り切れ|売切れ|販売終了|在庫切れ)/.test(boundedProduct);
 out.productWindowStock=positive;out.productWindowNegative=negative;
 const purchasePhrase=/(?:カート|ショッピングカート|買い物かご|お買い物かご|カゴ|かご)\\s*(?:に|へ)?\\s*(?:入れる|追加)|(?:カゴ|かご|買い物かご|お買い物かご)\\s*へ(?=\\s|$)/i;
 out.productWindowPurchase=purchasePhrase.test(boundedProduct);
 out.productWindowQuantity=/数量/.test(boundedProduct);
 out.productWindowQuantityControls=Array.from(main.querySelectorAll('input[type=number],select,[role=spinbutton]'))
   .filter(e=>visibleEnabled(e)&&!e.closest('header,nav,footer,aside,[class*=related],[class*=recommend],[class*=ranking]')).length;
 if(positive&&!negative&&out.productWindowPurchase&&out.productWindowQuantity&&out.productWindowQuantityControls>0){
   if(nearestStock<0){const match=/在庫\\s*[:：]\\s*(?:あり|有り)/.exec(boundedProduct);
     nearestStock=match?productText.indexOf(boundedProduct)+match.index:markerPos;}
   stockPos=Math.max(1,stockPos);
 }
 if(negative)stockNeg=Math.max(1,stockNeg);
 out.productStockDistance=nearestStock<0?-1:nearestStock-markerPos;
 out.productStockConflict=stockPos>0&&stockNeg>0;
 out.productStockLabel=stockPos>0&&stockNeg===0;
 // Do not preserve a generic 701-character stock hit if it belonged to a
 // later product whose order number lies outside this SKU's bounded window.
 if(!out.productStockLabel&&!positive)out.stockFound=false;
 out.productStockSource=out.productStockLabel?(out.productWindowStock?'sku-main-bounded-text':'sku-main-visible-label'):(stockNeg?'negative-or-conflicting':'none');
 // The genuine product stock box contains the quantity selector and an
 // explicit 'カゴに入れる' caption. Do not count a bare cart link or instructions.
 // Require caption and quantity within the same bounded product-text window.
 if(out.productStockLabel&&nearestStock>=0){
   const vicinity=productText.slice(Math.max(0,nearestStock-170),Math.min(productText.length,nearestStock+1750));
   out.productPurchaseText=purchasePhrase.test(vicinity)||out.productWindowPurchase;
   out.productQuantity=(/数量/.test(vicinity)||out.productWindowQuantity)&&
      (out.productWindowQuantityControls>0 || !!main.querySelector('input[type=number],input[name*=quantity],input[name*=qty],select[name*=quantity],select[name*=qty]'));
 }
 const selector='button,input[type=submit],input[type=button],input[type=image],[role=button],a[href],[data-action*=cart],[data-action*=Cart]';
 let nodes=Array.from(main.querySelectorAll(selector));
 if(main!==body)nodes=nodes.concat(Array.from(body.querySelectorAll(selector)).filter(x=>!main.contains(x)));
 const seen=new Set();
 for(const c of nodes){
   if(seen.has(c))continue;seen.add(c);
   if(c.closest('nav,header,footer,aside,[class*=related],[class*=recommend],[id*=related],[id*=recommend],[class*=ranking]'))continue;
   const img=c.querySelector('img[alt]');
   const label=[txt(c),c.value,c.getAttribute('aria-label'),c.getAttribute('title'),c.getAttribute('alt'),
     c.getAttribute('data-action'),img&&img.getAttribute('alt')].filter(Boolean).join(' ');
   if(!/(?:カート|ショッピングカート|買い物かご|お買い物かご|カゴ|かご|バスケット|バッグ)\\s*(?:に|へ)?\\s*(?:入れる|追加)|(?:カゴ|かご|買い物かご|お買い物かご)\\s*へ(?=\\s|$)|商品を\\s*(?:かご|カゴ|カート|バスケット)\\s*に追加|(?:今すぐ購入|購入する|注文する)|add[\\s_-]*to[\\s_-]*(?:cart|bag|basket|trolley)|buy\\s*(?:it\\s*)?now/i.test(label))continue;
   const panel=c.closest('form,[class*=purchase],[class*=buy],[class*=cart],[id*=purchase],[id*=buy]')||c.parentElement;
   if(!panel||!body.contains(panel)||/(?:関連商品|こちらもおすすめ|別の商品を購入)/.test(txt(panel).slice(0,750)))continue;
   // Require the main product's purchase panel, not navigation or the
   // side-panel shopping-basket link.
   const ptext=txt(panel);
   if(panel!==main&&panel!==body&&ptext.length>2600&&!marker.test(ptext))continue;
   out.cartFound++;
   if(visibleEnabled(c))out.cartEnabled++;else out.cartDisabled++;
 }
 // The ASKUL live DOM audit proves a visible, cart-labelled modal opener
 // beside the product quantity control. The stock classifier previously
 // counted *all* modal_01 clones and lost the one product-bound opener.
 // Bind the button by SKU URL, on-page SKU, product container, nearby qty,
 // cart-specific accessible text, and its live state. No DOM clicks.
 const qtySelector='input[type=number],input[name*=quantity],input[name*=qty],select[name*=quantity],select[name*=qty]';
 const productSelector='main,#main,#contents,[role=main],#productDetail,#product-detail,[class*=product],[class*=item-detail]';
 const modalControls=[...body.querySelectorAll('button#modal_01.js-modal1803')];
 out.modalCartCandidates=modalControls.length;
 for(const c of modalControls){
   if(visibleEnabled(c))out.modalCartEnabled++;
   const label=[txt(c),c.getAttribute('aria-label'),c.getAttribute('title'),
      c.getAttribute('alt'),c.querySelector('img')&&c.querySelector('img').getAttribute('alt')]
      .filter(Boolean).join(' ').replace(/\s+/g,' ');
   const named=/(?:カート|ショッピングカート|買い物かご|お買い物かご|カゴ|かご|バスケット|バッグ)\\s*(?:に|へ)?\\s*(?:入れる|追加)|(?:カゴ|かご|買い物かご|お買い物かご)\\s*へ(?=\\s|$)|商品を\\s*(?:かご|カゴ|カート|バスケット)\\s*に追加|(?:今すぐ購入|購入する|注文する)|add[\\s_-]*to[\\s_-]*(?:cart|bag|basket|trolley)|buy\\s*(?:it\\s*)?now/i.test(label)&&
       !/(?:カート|買い物かご|お買い物かご|カゴ|かご|バスケット|バッグ)\\s*(?:を)?\\s*(?:見る|確認)|(?:レジへ|レジに進む|購入手続きへ|ご購入手続きへ|注文画面へ進む|ご注文手続きへ)|(?:view|go\\s*to|open)\\s*(?:the\\s*)?(?:cart|bag|basket|trolley)|(?:proceed\\s*to\\s*)?checkout/i.test(label)&&
       !/(?:ヘルプ|使い方|ご利用案内)/.test(label);
   if(named)out.modalCartIntent++;
   // Inspect the modal's target without opening it. A quantity/stock-check
   // dialog is not automatically an add-to-cart action.
   let opensStockOnly=false;
   const targetId=String(c.getAttribute('data-modal1803-opn')||'').replace(/^#/, '');
   const target=targetId&&/^[A-Za-z][A-Za-z0-9_-]{0,70}$/.test(targetId)?(document.getElementById?document.getElementById(targetId):null):null;
   if(target){
     const words=txt(target).slice(0,2500);
     const stockDialog=/(?:希望の数量で在庫確認|在庫状況を反映する|在庫を確認)/.test(words);
     const cartDialog=/(?:商品がカゴに入りました|商品がカートに入りました|カゴに追加|カートに追加)/.test(words);
     if(stockDialog){out.modalTargetStock++;opensStockOnly=true;}
     else if(cartDialog)out.modalTargetCart++;
     else out.modalTargetOther++;
   }
   if(/(?:カート|ショッピングカート|買い物かご|お買い物かご|カゴ|かご|バスケット|バッグ)\\s*(?:に|へ)?\\s*(?:入れる|追加)|(?:カゴ|かご|買い物かご|お買い物かご)\\s*へ(?=\\s|$)|商品を\\s*(?:かご|カゴ|カート|バスケット)\\s*に追加|(?:今すぐ購入|購入する|注文する)|add[\\s_-]*to[\\s_-]*(?:cart|bag|basket|trolley)|buy\\s*(?:it\\s*)?now/i.test(label))out.modalPurchaseNamed++;
   // The quantity association is local to a product panel, not another
   // SKU's recommendation or the header mini-cart.
   let qtyBound=false;
   for(let p=c,k=0;p&&k<4;p=p.parentElement,k++){
     if(p.querySelector&&p.querySelector(qtySelector)){qtyBound=true;break;}
   }
   // IMPORTANT: this button itself is class="js-modal1803". An exclusion
   // using c.closest('[class*=modal]') matches the button ITSELF, so previous
   // releases rejected even the correct product-local opener every time.
   // Exclude modal *ancestors* only, never the opener's own class.
   const badAncestor=c.parentElement&&c.parentElement.closest(
      'header,nav,footer,aside,[class*=related],[class*=recommend],[class*=ranking],[class*=modal],[class*=dialog]');
   const region=!!c.closest(productSelector)&&!badAncestor;
   const ready=named&&qtyBound&&region&&visibleEnabled(c)&&!opensStockOnly&&
       c.hasAttribute('data-modal1803-opn')&&
       (c.hasAttribute('onclick')||c.getAttribute('type')==='button');
   if(ready){out.modalProductLinked++;out.modalProductReady++;}
   else out.modalExcluded++;
 }
 // Inspect only same-origin frame documents. Third-party frames are neither
 // read nor trusted. A frame must carry the exact order number itself before
 // its own stock or purchase control can count as product evidence.
 for(const f of body.querySelectorAll('iframe')){
   try{
     const d=f.contentDocument;
     if(!d||!d.body)continue;
     out.accessibleFrames++;
     const frameText=txt(d.body);
     if(!marker.test(frameText))continue;
     out.skuFrames++;
     const framePositive=/在庫\s*[:：]?\s*(?:あり|有り)|アスクル在庫商品/.test(frameText);
     const frameNegative=/在庫\s*[:：]?\s*(?:なし|無し|切れ)|売り切れ|販売終了/.test(frameText);
     if(framePositive&&!frameNegative)out.frameStock++;
     for(const b of d.body.querySelectorAll('button,input[type=submit],input[type=button],[role=button]')){
       const name=[txt(b),b.value,b.getAttribute('aria-label'),b.getAttribute('title')].filter(Boolean).join(' ');
       if(/(?:カート|ショッピングカート|買い物かご|お買い物かご|カゴ|かご|バスケット|バッグ)\\s*(?:に|へ)?\\s*(?:入れる|追加)|(?:カゴ|かご|買い物かご|お買い物かご)\\s*へ(?=\\s|$)|商品を\\s*(?:かご|カゴ|カート|バスケット)\\s*に追加|(?:今すぐ購入|購入する|注文する)|add[\\s_-]*to[\\s_-]*(?:cart|bag|basket|trolley)|buy\\s*(?:it\\s*)?now/i.test(name)&&visibleEnabled(b))out.frameCart++;
     }
   }catch(_){/* Cross-origin frame: inaccessible by design. */}
 }
 if(out.skuFrames===1&&out.frameStock===1&&out.frameCart===1&&!stockNegative){
   out.status='AVAILABLE';out.reason='same-sku-frame-stock-cart';return done();
 }
 // Some ASKUL product pages render price and SKU before the purchase panel
 // is hydrated. Check only authoritative per-SKU structured Product offers,
 // not arbitrary script text or catalogue inventory snippets.
 const inspectObject=(node)=>{
   if(!node||typeof node!=='object')return;
   if(Array.isArray(node)){node.forEach(inspectObject);return;}
   const types=String(node['@type']||'').toLowerCase();
   if(types==='product'||types.split(',').includes('product')){
     const ident=String(node.sku||node.productID||node.productId||'');
     const offerUrl=String(node.url||'');
     if(ident.toLowerCase()===code.toLowerCase()&&(!offerUrl||offerUrl.includes('/p/'+code+'/'))){
       out.structuredProduct=true;
       const offers=Array.isArray(node.offers)?node.offers:[node.offers];
       for(const offer of offers){if(!offer||typeof offer!=='object')continue;
         const state=String(offer.availability||'');
         const currency=String(offer.priceCurrency||'JPY');
         const amount=Number(offer.price);
         if(/(?:InStock|LimitedAvailability)$/i.test(state)&&currency==='JPY'&&Number.isFinite(amount)&&amount>0)
           out.structuredOffer=true;
       }
     }
   }
   if(node['@graph']&&Array.isArray(node['@graph']))node['@graph'].forEach(inspectObject);
 };
 for(const el of document.querySelectorAll('script[type="application/ld+json"]')){
   try{inspectObject(JSON.parse(el.textContent||'null'));}catch(_){ }
 }
 if(stockNegative){out.reason='negative-stock';return done();}
 // The primary product panel can explicitly say '在庫：あり' even when
 // the generic 701-character crop ends before that panel. Accept only when
 // the visible stock label, cart caption and quantity belong to this exact
 // SKU's main product section and no stock conflict is present. A generic
 // header cart or unrelated modal alone cannot make this verdict.
 // The unique visible SKU-bound modal candidate already requires a real
 // purchase caption and nearby quantity control, independently of innerText.
 const skuBoundPurchase=out.modalProductReady===1&&out.modalCartIntent>=1&&
    out.productWindowQuantityControls>0;
 if(out.productArea&&out.productStockLabel&&!out.productStockConflict&&
    out.modalProductReady===1&&
    ((out.productPurchaseText&&out.productQuantity)||skuBoundPurchase)&&
    out.productStockDistance>=-1800&&
    out.productStockDistance<=7600){
   out.status='AVAILABLE';out.stockFound=true;
   out.stockPosition='sku-main-visible-label';
   out.reason='same-sku-visible-stock-quantity-cart';return done();
 }
 // The enabled purchase action of this exact-SKU product is itself evidence
 // that the item can be put in the cart. A separate stock badge is optional.
 if(out.productStockLabel&&!out.productStockConflict&&out.modalProductReady===1&&out.cartFound===1&&out.cartEnabled===1&&out.cartDisabled===0){
   out.status='AVAILABLE';out.reason='same-sku-live-cart';return done();
 }
 // An opener is purchase evidence only if the exact product-bound button
 // explicitly names a cart insertion AND its target confirms cart insertion.
 // Stock-check and generic modal openers must remain UNKNOWN.
 if(out.cartFound===0&&out.modalProductReady===1&&out.modalPurchaseNamed>=1&&
    out.modalTargetCart>=1&&out.modalTargetStock===0&&out.modalCartEnabled>=1){
   out.status='AVAILABLE';out.reason='same-sku-confirmed-cart-modal';return done();
 }
 // Modal openers alone are never availability evidence: even a linked
 // opener can display stock guidance rather than insert an item into a cart.
 if(out.productStockLabel&&!out.productStockConflict&&out.modalProductReady===1&&out.cartFound===0&&live.found===1&&live.enabled===1&&live.disabled===0){
   out.status='AVAILABLE';out.reason='same-sku-live-control';return done();
 }
 if(out.productStockLabel&&!out.productStockConflict&&out.modalProductReady===1&&out.cartEnabled>=1&&out.cartDisabled===0&&out.cartEnabled<=3){
   out.status='AVAILABLE';out.reason='same-sku-stock-cart';return done();
 }
 if(out.structuredProduct&&out.structuredOffer){
   out.status='AVAILABLE';out.reason='same-sku-structured-offer';return done();
 }
 if(!out.stockFound){out.reason='stock-missing';return done();}
 if(out.cartEnabled<1){out.reason='enabled-cart-missing';return done();}
 out.reason='cart-conflict';return done();
 }catch(_){out.reason='dom-error';return done();}
})()
""".replace("__SKU__", sku).replace("__SHARED_SCOPE__", ProductEvidenceScopeDom.javascript());
    }

    /** Legacy status-only contract for HTML/DOM adapters. */
    static String stock(String sku) {
        return "(function(){try{return JSON.parse(" + stockEvidence(sku)
                + ").status;}catch(_){return 'UNKNOWN';}})()";
    }
}
