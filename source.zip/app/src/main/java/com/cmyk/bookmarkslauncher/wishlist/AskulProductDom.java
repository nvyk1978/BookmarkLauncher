package com.cmyk.bookmarkslauncher.wishlist;

/**
 * ASKUL-only official product DOM. Uses the requested /p/ code plus the
 * on-page お申込番号 label, never only a URL or a generic shopping-site price.
 * No clicks, login bypass, caches of stale quoted prices, or fixed yen amounts.
 */
final class AskulProductDom {
    private AskulProductDom() { }

    private static boolean valid(String sku) {
        return sku != null && sku.matches("[A-Za-z0-9_-]{5,20}");
    }

    private static String preamble(String sku) {
        return "var sku='" + sku + "';" +
                "var path=(location.pathname||'').replace(/\\/+$/,'').toLowerCase();" +
                "if(path!=='/p/'+sku.toLowerCase())return empty('url-mismatch');" +
                "var body=document.body;if(!body)return empty('body-missing');" +
                "var main=document.querySelector('main,[role=main],#main,#contents,#productDetail,#product-detail')||body;" +
                "function plain(n){return ((n&&(n.innerText||n.textContent))||'').replace(/\\u00a0/g,' ').replace(/　/g,' ');}" +
                "var text=plain(main),whole=plain(body);" +
                "var marker=new RegExp('お申込番号\\\\s*[:：]?\\\\s*'+sku+'(?![A-Za-z0-9_-])','i');" +
                "var m=marker.exec(text);if(!m&&main!==body){text=whole;m=marker.exec(text);}" +
                "var heading=!!document.querySelector('h1');" +
                "var blocked=/(?:Access\\s*Denied|Forbidden|Request\\s*Blocked|アクセス制限|アクセスが集中|ご利用を制限|bot\\s*check|captcha)/i.test(whole);";
    }

    /** Returns JSON.stringify({value,currency,reason,...}) for the shared price probe. */
    static String price(String sku) {
        if (!valid(sku)) return "JSON.stringify({value:'',currency:'',reason:'invalid-sku'})";
        return "(function(){try{" +
                "function empty(r){return JSON.stringify({value:'',currency:'',reason:r,bodyChars:Math.min(99999,whole.length||0),h1:heading||false,skuLabel:!!m,blocked:blocked||false});}" +
                // Declare diagnostic fields before any potential early return.
                "var whole='',heading=false,m=null,blocked=false;" +
                preamble(sku) +
                "if(!m)return empty(blocked?'restricted-page':'sku-marker-missing');" +
                // Look *after the correctly labeled SKU*, where the official
                // product data grid has its own explicit 価格 ￥xxx（税込）.
                "var after=text.slice(m.index+m[0].length,Math.min(text.length,m.index+m[0].length+1600));" +
                "var boundary=after.search(/(?:商品詳細|関連商品|おすすめ商品|この商品を見た|配送オプション|お客様レビュー)/);" +
                "if(boundary>=0)after=after.slice(0,boundary);" +
                "var priceLabel=/(?:^|\\s)(?:価格|税込価格|販売価格)\\s*[:：]?\\s*[￥¥]\\s*([0-9][0-9,]*)\\s*(?:円\\s*)?[（(]\\s*税込\\s*[）)]/g;" +
                "var values=[],match;while((match=priceLabel.exec(after))!==null){values.push(match[1].replace(/,/g,''));if(values.length>=8)break;}" +
                // If the code's own price table is absent, consider only the
                // heading-side product offer *before* the shipping section.
                // Delivery options may also display tax-inclusive amounts.
                "if(!values.length){var before=text.slice(Math.max(0,m.index-2200),m.index);" +
                "var lastProduct=before.lastIndexOf('販売単位');" +
                "if(lastProduct>=0){var section=before.slice(Math.max(0,lastProduct-900));" +
                "var ship=section.search(/(?:配送オプション|配送料|送料|時間帯指定)/);" +
                "if(ship>=0)section=section.slice(0,ship);" +
                "var gross=/[￥¥]\\s*([0-9][0-9,]*)\\s*(?:円\\s*)?[（(]\\s*税込\\s*[）)]/g;" +
                "while((match=gross.exec(section))!==null){values.push(match[1].replace(/,/g,''));if(values.length>=8)break;}}}" +
                "if(!values.length)return empty('gross-label-missing');" +
                "var n=Number(values[0]);" +
                "if(!Number.isSafeInteger(n)||n<1||n>100000000)return empty('gross-invalid');" +
                "for(var i=1;i<values.length;i++)if(Number(values[i])!==n)return empty('gross-ambiguous');" +
                "return JSON.stringify({value:'¥'+n,currency:'JPY',reason:'verified-gross',bodyChars:Math.min(99999,whole.length),h1:heading,skuLabel:true,blocked:false});" +
                "}catch(e){return JSON.stringify({value:'',currency:'',reason:'script-error'});}})()";
    }

    /** Conservative purchase proof bound to exactly this SKU's rendered page. */
    static String stock(String sku) {
        if (!valid(sku)) return "'UNKNOWN'";
        return "(function(){try{" +
                "function empty(r){return 'UNKNOWN';}" +
                preamble(sku) +
                "if(!m||blocked)return 'UNKNOWN';" +
                // A checked stock label and a single enabled, visible purchase
                // control are both mandatory; do not infer from shipping dates.
                "if(!/在庫\\s*[:：]\\s*あり/.test(text)&&!/アスクル在庫商品/.test(text))return 'UNKNOWN';" +
                "function visible(e){if(!e||e.disabled||e.getAttribute('aria-disabled')==='true'||!e.getClientRects().length)return false;" +
                "for(var n=e;n;n=n.parentElement){if(n.hidden||n.getAttribute('aria-hidden')==='true')return false;" +
                "var v=getComputedStyle(n);if(v.display==='none'||v.visibility==='hidden'||Number(v.opacity)===0)return false;}return true;}" +
                "var controls=main.querySelectorAll('button,input[type=submit],input[type=button],[role=button],a[href]');" +
                "var found=0;for(var i=0;i<controls.length&&i<350;i++){var c=controls[i];" +
                "if(!visible(c)||c.closest('nav,header,footer,aside,[class*=related],[class*=recommend],[id*=related],[id*=recommend]'))continue;" +
                "var label=(c.innerText||c.textContent||'')+' '+(c.value||'')+' '+(c.getAttribute('aria-label')||'');" +
                "if(!/(?:カゴに入れる|カートに入れる)/.test(label))continue;" +
                "var panel=c.closest('form,[class*=purchase],[class*=buy],[class*=cart],[id*=purchase],[id*=buy]')||c.parentElement;" +
                "if(!panel||!main.contains(panel))continue;" +
                "var options=panel.querySelectorAll('select[required]'),missing=false;" +
                "for(var j=0;j<options.length;j++)if(visible(options[j])&&!options[j].value)missing=true;" +
                "if(missing)continue;found++;if(found>1)return 'UNKNOWN';}" +
                "return found===1?'AVAILABLE':'UNKNOWN';" +
                "}catch(e){return 'UNKNOWN';}})()";
    }
}
