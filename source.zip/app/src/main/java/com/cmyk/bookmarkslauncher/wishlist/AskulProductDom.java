package com.cmyk.bookmarkslauncher.wishlist;

/**
 * ASKUL-only official product DOM. Uses the requested /p/ code plus the
 * on-page お申込番号 label, never only a URL or a generic shopping-site price.
 * No clicks, login bypass, caches of stale quoted prices, or fixed yen amounts.
 */
final class AskulProductDom {
    private AskulProductDom() { }

    private static boolean valid(String sku) {
        return sku != null && sku.matches("[A-Za-z0-9_-]{5,20}");
    }

    private static String preamble(String sku) {
        return "var sku='" + sku + "';" +
                "var path=(location.pathname||'').replace(/\\/+$/,'').toLowerCase();" +
                "if(path!=='/p/'+sku.toLowerCase())return empty('url-mismatch');" +
                "var body=document.body;if(!body)return empty('body-missing');" +
                "var main=document.querySelector('main,[role=main],#main,#contents,#productDetail,#product-detail')||body;" +
                "function plain(n){return ((n&&(n.innerText||n.textContent))||'').replace(/\\u00a0/g,' ').replace(/　/g,' ');}" +
                "var text=plain(main),whole=plain(body);" +
                "var marker=new RegExp('お申込番号\\\\s*[:：]?\\\\s*'+sku+'(?![A-Za-z0-9_-])','i');" +
                "var m=marker.exec(text);if(!m&&main!==body){text=whole;m=marker.exec(text);}" +
                "var heading=!!document.querySelector('h1');" +
                "var blocked=/(?:Access\\s*Denied|Forbidden|Request\\s*Blocked|アクセス制限|アクセスが集中|ご利用を制限|bot\\s*check|captcha)/i.test(whole);";
    }

    /** Returns JSON.stringify({value,currency,reason,...}) for the shared price probe. */
    static String price(String sku) {
        if (!valid(sku)) return "JSON.stringify({value:'',currency:'',reason:'invalid-sku'})";
        return "(function(){try{" +
                "function empty(r){return JSON.stringify({value:'',currency:'',reason:r,bodyChars:Math.min(99999,whole.length||0),h1:heading||false,skuLabel:!!m,blocked:blocked||false});}" +
                // Declare diagnostic fields before any potential early return.
                "var whole='',heading=false,m=null,blocked=false;" +
                preamble(sku) +
                "if(!m)return empty(blocked?'restricted-page':'sku-marker-missing');" +
                // Look *after the correctly labeled SKU*, where the official
                // product data grid has its own explicit 価格 ￥xxx（税込）.
                "var after=text.slice(m.index+m[0].length,Math.min(text.length,m.index+m[0].length+1600));" +
                "var boundary=after.search(/(?:商品詳細|関連商品|おすすめ商品|この商品を見た|配送オプション|お客様レビュー)/);" +
                "if(boundary>=0)after=after.slice(0,boundary);" +
                "var priceLabel=/(?:^|\\s)(?:価格|税込価格|販売価格)\\s*[:：]?\\s*[￥¥]\\s*([0-9][0-9,]*)\\s*(?:円\\s*)?[（(]\\s*税込\\s*[）)]/g;" +
                "var values=[],match;while((match=priceLabel.exec(after))!==null){values.push(match[1].replace(/,/g,''));if(values.length>=8)break;}" +
                // If the code's own price table is absent, consider only the
                // heading-side product offer *before* the shipping section.
                // Delivery options may also display tax-inclusive amounts.
                "if(!values.length){var before=text.slice(Math.max(0,m.index-2200),m.index);" +
                "var lastProduct=before.lastIndexOf('販売単位');" +
                "if(lastProduct>=0){var section=before.slice(Math.max(0,lastProduct-900));" +
                "var ship=section.search(/(?:配送オプション|配送料|送料|時間帯指定)/);" +
                "if(ship>=0)section=section.slice(0,ship);" +
                "var gross=/[￥¥]\\s*([0-9][0-9,]*)\\s*(?:円\\s*)?[（(]\\s*税込\\s*[）)]/g;" +
                "while((match=gross.exec(section))!==null){values.push(match[1].replace(/,/g,''));if(values.length>=8)break;}}}" +
                "if(!values.length)return empty('gross-label-missing');" +
                "var n=Number(values[0]);" +
                "if(!Number.isSafeInteger(n)||n<1||n>100000000)return empty('gross-invalid');" +
                "for(var i=1;i<values.length;i++)if(Number(values[i])!==n)return empty('gross-ambiguous');" +
                "return JSON.stringify({value:'¥'+n,currency:'JPY',reason:'verified-gross',bodyChars:Math.min(99999,whole.length),h1:heading,skuLabel:true,blocked:false});" +
                "}catch(e){return JSON.stringify({value:'',currency:'',reason:'script-error'});}})()";
    }

    /** Semantically visible controls in a hidden WebView may have zero client rects.
     * Require an on-page labeled SKU, an item-local stock label and an enabled
     * purchase control. Return bounded evidence for card-specific diagnostics. */
    static String stockEvidence(String sku) {
        if (!valid(sku)) return "(function(){return JSON.stringify({status:'UNKNOWN',reason:'invalid-sku'});})()";
        return """
(function(){'use strict';
 const out={status:'UNKNOWN',reason:'no-evidence',skuLabel:false,stockFound:false,
            cartFound:0,cartEnabled:0,cartDisabled:0,restricted:false};
 const done=()=>JSON.stringify(out);
 try{
 const code='__SKU__';
 if((location.pathname||'').replace(/\\/+$/,'').toLowerCase()!=='/p/'+code.toLowerCase()){
   out.reason='path-mismatch';return done();
 }
 const body=document.body;if(!body){out.reason='body-missing';return done();}
 const main=document.querySelector('main,[role=main],#main,#contents,#productDetail,#product-detail')||body;
 const t=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ');
 let text=t(main);const whole=t(body);
 const marker=new RegExp('お申込番号\\\\s*[:：]?\\\\s*'+code+'(?![A-Za-z0-9_-])','i');
 let m=marker.exec(text);
 if(!m&&main!==body){text=whole;m=marker.exec(text);}
 out.skuLabel=!!m;
 out.restricted=/(?:Access\\s*Denied|Forbidden|Request\\s*Blocked|アクセス制限|captcha)/i.test(whole);
 if(out.restricted){out.reason='restricted-page';return done();}
 if(!m){out.reason='sku-marker-missing';return done();}
 // Limit to the registered item's purchase region, not an unrelated recommendation.
 const local=text.slice(Math.max(0,m.index-1800), Math.min(text.length,m.index+3300))
     .split(/(?:関連商品|おすすめ商品|この商品を見た|一緒に購入|ランキング)/)[0];
 // Only consider the bound product's section, never the entire listing page.
 const stockSection=local.split(/(?:関連商品|おすすめ商品|この商品を見た)/)[0];
 const hasPositive=/在庫\\s*[:：]?\\s*(?:あり|有り|有)|アスクル在庫商品/.test(stockSection);
 const hasNegative=/在庫\\s*[:：]?\\s*(?:なし|無し|切れ)|売り切れ|売切れ|販売終了|在庫切れ/.test(stockSection);
 out.stockFound=hasPositive&&!hasNegative;
 const usable=e=>{
   if(!e||e.disabled||e.getAttribute('disabled')!==null||e.getAttribute('aria-disabled')==='true')return false;
   if(/(?:disabled|soldout|sold-out|unavailable)/i.test(String(e.className||'')))return false;
   for(let n=e;n;n=n.parentElement){
     if(n.hidden||n.getAttribute('aria-hidden')==='true'||n.hasAttribute('inert'))return false;
     const cs=getComputedStyle(n);
     if(cs.display==='none'||cs.visibility==='hidden'||cs.visibility==='collapse'||Number(cs.opacity)===0)return false;
   }
   return true;
 };
 // Some ASKUL purchase controls live beside <main>, or use icon labels
 // instead of direct text. The registered SKU is already verified above.
 const selector='button,input[type=submit],input[type=button],[role=button],a[href]';
 let controls=Array.from(main.querySelectorAll(selector));
 if(!controls.some(c=>/カゴに入れる|カートに入れる|カゴに追加|カートに追加/.test(
         (c.innerText||c.textContent||'')+' '+(c.getAttribute('aria-label')||''))) && main!==body)
   controls=Array.from(body.querySelectorAll(selector));
 const candidates=[];
 for(const c of controls){
   if(candidates.length>=10)break;
   if(c.closest('nav,header,footer,aside,[class*=related],[class*=recommend],[id*=related],[id*=recommend],[class*=ranking]'))continue;
   const img=c.querySelector('img[alt]');
   const label=(c.innerText||c.textContent||'')+' '+(c.value||'')+' '+(c.getAttribute('aria-label')||'')
        +' '+(c.getAttribute('title')||'')+' '+(img?img.getAttribute('alt'):'');
   if(!/(?:カゴ|カート|買い物かご)(?:に)?(?:入れる|追加)/.test(label))continue;
   // A main-item form or a main product purchase panel; not a page-wide cart link.
   const panel=c.closest('form,[class*=purchase],[class*=buy],[class*=cart],[id*=purchase],[id*=buy]')||c.parentElement;
   if(!panel||!body.contains(panel))continue;
   // Ignore cart links in navigation and unrelated product/recommendation panels.
   const parentText=t(panel).slice(0,800);
   if(/(?:別の商品を購入|関連商品|こちらもおすすめ)/.test(parentText))continue;
   candidates.push(c);
   if(usable(c)){
     const required=panel.querySelectorAll('select[required]');
     let missing=false;for(const option of required)if(usable(option)&&!option.value)missing=true;
     if(!missing)out.cartEnabled++;
     else out.cartDisabled++;
   }else out.cartDisabled++;
 }
 out.cartFound=candidates.length;
 if(!out.stockFound){out.reason=hasNegative?'conflicting-stock':'stock-missing';return done();}
 if(out.cartEnabled<1){out.reason='enabled-cart-missing';return done();}
 if(out.cartEnabled>3||out.cartDisabled>0){out.reason='cart-conflict';return done();}
 // Multiple sticky copies of the same item control are permitted, but never
 // a separate product's purchase panel or a conflicting sell-out indication.
 out.status='AVAILABLE';out.reason='same-sku-stock-cart';return done();
 }catch(_){out.reason='dom-error';return done();}
})()
""".replace("__SKU__", sku);
    }

    /** Legacy status-only contract for HTML/DOM adapters. */
    static String stock(String sku) {
        return "(function(){try{return JSON.parse(" + stockEvidence(sku)
                + ").status;}catch(_){return 'UNKNOWN';}})()";
    }
}
