package com.cmyk.bookmarkslauncher;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewConfiguration;
import android.view.HapticFeedbackConstants;
import android.view.ViewTreeObserver;
import android.view.animation.DecelerateInterpolator;
import android.transition.ChangeBounds;
import android.transition.Fade;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.wishlist.WishlistCrawler;
import com.cmyk.bookmarkslauncher.wishlist.WishlistPriceWebViewProbe;
import com.cmyk.bookmarkslauncher.wishlist.WishlistImageWebViewProbe;
import com.cmyk.bookmarkslauncher.wishlist.WishlistItem;
import com.cmyk.bookmarkslauncher.wishlist.WishlistRepository;
import com.cmyk.bookmarkslauncher.wishlist.WishlistScheduler;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class WishlistPage {
    private static final int BG = 0xFF303030;
    private static final int DGRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int LGRAY = 0xFF656060;
    private static final int BLUE = 0xFF223355;
    private static final int LBLUE = 0xFF445577;
    private static final int RED = 0xFF441100;
    private static final int LRED = 0xFF662211;
    private static final int ORANGE = 0xFF775500;
    private static final int WHITE = 0xFFA9A999;
    private static final int GREEN = 0xFF227733;
    private static final int TEXT = 0xFFFFFFFF;
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;

    private WishlistRepository repo;
    private FrameLayout root;
    private LinearLayout listBox;
    private ScrollView listScroll;
    private TextView empty;
    // Cards are independent: expanding one never collapses another.
    private final Set<String> expandedIds = new HashSet<>();
    private String query = "";
    private final Set<Long> filterTags = new HashSet<>();
    private Long minPrice;
    private Long maxPrice;
    // Applied search criteria are independent from the editable draft controls.
    private LinearLayout filterPanel;
    // Floating entry points appear only outside search; the pinned filter panel replaces them.
    private View tagFab, searchFab, addFab;
    private EditText inlineQuery, inlineMin, inlineMax;
    private Flow inlineTags;
    private final Set<Long> draftFilterTags = new HashSet<>();
    private int beforeSearchScrollY;
    private Set<String> beforeSearchExpandedIds = new HashSet<>();
    private String pendingImageItemId;
    public static final int REQUEST_IMAGE_PICK = 7942;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private WishlistPriceWebViewProbe priceProbe;
    private WishlistImageWebViewProbe imageProbe;

    private final Activity host;
    private final Runnable onBack;

    public WishlistPage(Activity host, Runnable onBack, String initialItemId) {
        this.host = host;
        this.onBack = onBack;
        repo = new WishlistRepository(host);
        WishlistScheduler.ensureScheduled(host);
        if (initialItemId != null) expandedIds.add(initialItemId);
        buildUi();
        refreshList();
        maybeRefreshStale();
    }

    public FrameLayout getView() { return root; }
    public void openItem(String id) { if (id != null) expandedIds.add(id); refreshList(); }
    public void refresh() { refreshList(); }
    /** Android Back first clears active search, otherwise MainActivity navigates home. */
    public boolean handleBack() {
        if (!hasFilters()) return false;
        clearSearchFilters();
        return true;
    }
    public void destroy() {
        if (priceProbe != null) priceProbe.cancel();
        if (imageProbe != null) imageProbe.cancel();
        io.shutdownNow();
    }
    private void returnToBookmarks() { if (onBack != null) onBack.run(); }
    public void onHostResume() { /* No purchase prompts or purchase tracking UI. */ }

    private View buildUi() {
        root = new FrameLayout(host);
        root.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(host);
        // An opaque page also hides the attached background-only WebView probes.
        page.setBackgroundColor(BG);
        page.setOrientation(LinearLayout.VERTICAL);
        // Match the Home title: 18dp horizontal inset, 64dp top inset,
        // 25sp bold text centered vertically in a 44dp title row.
        page.setPadding(dp(18), dp(64), dp(18), dp(18));

        TextView title = text("Wishlist", 25, WHITE, true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setContentDescription("Wishlist：タップですべて格納");
        title.setOnClickListener(v -> collapseAllCards());
        page.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        ScrollView scroll = new ScrollView(host);
        listScroll = scroll;
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, dp(4), 0, dp(5));
        listBox = new LinearLayout(host);
        listBox.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listBox, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        // Search criteria live BELOW the independently scrolling card list.
        filterPanel = buildFilterPanel();
        page.addView(filterPanel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        filterPanel.setVisibility(View.GONE);
        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        empty = text("Wishlistは空です", 15, LGRAY, false);
        empty.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams emptyLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64), Gravity.CENTER);
        emptyLp.leftMargin = dp(28); emptyLp.rightMargin = dp(28);
        root.addView(empty, emptyLp);

        // PriceRec v0.1.81 TagManageIconView is copied without altering its silhouette.
        tagFab = new TagManageIconView(host);
        tagFab.setBackground(circle(GRAY));
        tagFab.setElevation(dp(8));
        tagFab.setContentDescription("タグ管理");
        tagFab.setOnClickListener(v -> showTagManager());
        FrameLayout.LayoutParams tagLp = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START | Gravity.BOTTOM);
        tagLp.setMargins(dp(18), 0, 0, dp(24));
        root.addView(tagFab, tagLp);

        // Original floating + and magnifier return, with PriceRec's tag icon on the left.
        // During a search ALL THREE are hidden; only the pinned criteria card remains.
        FrameLayout searchButton = new FrameLayout(host);
        searchButton.setBackground(circle(DGRAY));
        searchButton.setElevation(dp(8));
        searchButton.addView(new SearchIcon(host), new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        searchButton.setContentDescription("Wishlist検索");
        searchButton.setOnClickListener(v -> showSearchDialog());
        FrameLayout.LayoutParams searchLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END | Gravity.BOTTOM);
        searchLp.setMargins(0, 0, dp(18), dp(24));
        root.addView(searchButton, searchLp);
        searchFab = searchButton;

        FrameLayout addButton = new FrameLayout(host);
        addButton.setElevation(dp(8));
        addButton.addView(new RoundPlusIcon(host, DGRAY, TEXT),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        addButton.setContentDescription("URLから商品を追加");
        addButton.setOnClickListener(v -> showUrlDialog());
        FrameLayout.LayoutParams addLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END | Gravity.BOTTOM);
        addLp.setMargins(0, 0, dp(84), dp(24));
        root.addView(addButton, addLp);
        addFab = addButton;
        return root;
    }

    private void refreshList() {
        List<WishlistItem> all = repo.listAll();
        List<WishlistItem> visible = new ArrayList<>();
        for (WishlistItem item : all) if (matches(item)) visible.add(item);
        listBox.removeAllViews();
        for (WishlistItem item : visible) listBox.addView(itemRow(item));
        empty.setVisibility(visible.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private boolean matches(WishlistItem item) {
        if (item == null) return false;
        if (query != null && !query.isBlank()) {
            String hay = ((item.title == null ? "" : item.title) + " " + (item.url == null ? "" : item.url) + " " + (item.sourceName == null ? "" : item.sourceName)).toLowerCase(Locale.ROOT);
            if (!hay.contains(query.trim().toLowerCase(Locale.ROOT))) return false;
        }
        if (!filterTags.isEmpty()) {
            Set<Long> assigned = repo.tagsForItem(item.id);
            if (!assigned.containsAll(filterTags)) return false;
        }
        if (minPrice != null || maxPrice != null) {
            // Price filtering is only allowed to use a price confirmed by the latest crawl.
            // A failed refresh keeps the previous value for history/display, but never treats it as current.
            if (!item.priceFetchOk || item.currentPrice == null) return false;
            if (minPrice != null && item.currentPrice < minPrice) return false;
            if (maxPrice != null && item.currentPrice > maxPrice) return false;
        }
        return true;
    }

    /** Keep the header/thumbnail views alive when toggling, so their bounds animate. */
    private static final class CardHeader {
        final LinearLayout line;
        final View thumb;
        final TextView grip;
        final TextView name;
        final TextView url;
        final LinearLayout editors;
        final TextView price;
        final WishlistItem item;
        CardHeader(LinearLayout line, View thumb, TextView grip, TextView name,
                   TextView url, LinearLayout editors, TextView price, WishlistItem item) {
            this.line = line; this.thumb = thumb; this.grip = grip;
            this.name = name; this.url = url; this.editors = editors;
            this.price = price; this.item = item;
        }
    }

    private View itemRow(WishlistItem item) {
        boolean expanded = expandedIds.contains(item.id);
        LinearLayout card = new LinearLayout(host);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setTag(item.id);
        card.setBackground(roundRect(DGRAY, 12));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(0, 0, 0, dp(6));
        card.setLayoutParams(cardLp);

        LinearLayout line = new LinearLayout(host);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.TOP);
        line.setPadding(dp(4), dp(8), dp(8), dp(8));
        TextView grip = text("≡", 24, WHITE, true);
        grip.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        grip.setContentDescription("開閉（長押しで並べ替え）");
        grip.setOnClickListener(v -> toggleExpanded(item));
        line.addView(grip, new LinearLayout.LayoutParams(dp(34), dp(48)));
        attachGrip(grip, item.id, card);

        int imageSize = dp(expanded ? 140 : 80);
        View thumb = thumbnail(item);
        thumb.setContentDescription("商品画像：タップで開閉");
        thumb.setOnClickListener(v -> toggleExpanded(item));
        line.addView(thumb, new LinearLayout.LayoutParams(imageSize, imageSize));

        LinearLayout nameBox = new LinearLayout(host);
        nameBox.setOrientation(LinearLayout.VERTICAL);
        nameBox.setGravity(Gravity.TOP);

        TextView name = text(item.title == null || item.title.isBlank() ? "商品" : item.title,
                14, TEXT, true);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setOnClickListener(v -> toggleExpanded(item));
        name.setOnLongClickListener(v -> { showRenameDialog(item); return true; });
        nameBox.addView(name, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout footer = new LinearLayout(host);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView sub = text(collapsedSub(item), 11, statusColor(item.status), false);
        sub.setSingleLine(true);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sub.setOnClickListener(v -> toggleExpanded(item));
        footer.addView(sub, new LinearLayout.LayoutParams(0, dp(22), 1f));
        TextView priceLabel = null;
        if (item.currentPrice != null) {
            priceLabel = text(price(item.currentPrice), 11, TEXT, true);
            priceLabel.setSingleLine(true);
            priceLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            priceLabel.setVisibility(expanded ? View.GONE : View.VISIBLE);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(22));
            pp.leftMargin = dp(5);
            footer.addView(priceLabel, pp);
        }
        nameBox.addView(footer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(22)));

        TextView url = text(item.url == null ? "" : item.url, 11, LGRAY, false);
        url.setMaxLines(2);
        url.setEllipsize(android.text.TextUtils.TruncateAt.END);
        url.setVisibility(expanded ? View.VISIBLE : View.GONE);
        url.setOnClickListener(v -> toggleExpanded(item));
        LinearLayout.LayoutParams urlLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        urlLp.topMargin = dp(7);
        nameBox.addView(url, urlLp);

        LinearLayout editors = new LinearLayout(host);
        editors.setGravity(Gravity.CENTER_VERTICAL);
        TextView rename = capsule("商品名編集", GRAY, 11);
        rename.setOnClickListener(v -> showRenameDialog(item));
        TextView editImage = capsule("画像編集", GRAY, 11);
        editImage.setOnClickListener(v -> chooseImage(item));
        LinearLayout.LayoutParams renameButtonLp = new LinearLayout.LayoutParams(0, dp(34), 1f);
        renameButtonLp.rightMargin = dp(5);
        editors.addView(rename, renameButtonLp);
        editors.addView(editImage, new LinearLayout.LayoutParams(0, dp(34), 1f));
        editors.setVisibility(expanded ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams editorsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
        editorsLp.topMargin = dp(7);
        nameBox.addView(editors, editorsLp);

        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        nameLp.leftMargin = dp(8);
        line.addView(nameBox, nameLp);
        line.setTag(new CardHeader(line, thumb, grip, name, url, editors, priceLabel, item));
        line.setOnClickListener(v -> toggleExpanded(item));
        card.addView(line, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (expanded) card.addView(expandedView(item), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    private void beginCardTransition() {
        TransitionSet transition = new TransitionSet();
        transition.setOrdering(TransitionSet.ORDERING_TOGETHER);
        transition.addTransition(new ChangeBounds());
        transition.addTransition(new Fade());
        transition.setDuration(250);
        transition.setInterpolator(new DecelerateInterpolator());
        TransitionManager.beginDelayedTransition(listBox, transition);
    }

    /** Toggle only the tapped card. All other expanded cards stay open. */
    private void toggleExpanded(WishlistItem item) {
        View card = findCard(item.id);
        if (!(card instanceof LinearLayout)) return;
        boolean expand = !expandedIds.contains(item.id);
        beginCardTransition();
        setCardExpanded((LinearLayout) card, item, expand);
        if (expand) expandedIds.add(item.id);
        else expandedIds.remove(item.id);
    }

    private View findCard(String id) {
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View v = listBox.getChildAt(i);
            if (id.equals(v.getTag())) return v;
        }
        return null;
    }

    private void setCardExpanded(LinearLayout card, WishlistItem item, boolean expand) {
        View headerView = card.getChildAt(0);
        if (!(headerView.getTag() instanceof CardHeader)) return;
        CardHeader header = (CardHeader) headerView.getTag();
        int side = dp(expand ? 140 : 80);
        ViewGroup.LayoutParams thumbLp = header.thumb.getLayoutParams();
        thumbLp.width = side;
        thumbLp.height = side;
        header.thumb.setLayoutParams(thumbLp);
        header.url.setVisibility(expand ? View.VISIBLE : View.GONE);
        header.editors.setVisibility(expand ? View.VISIBLE : View.GONE);
        if (header.price != null) header.price.setVisibility(expand ? View.GONE : View.VISIBLE);
        if (expand && card.getChildCount() == 1) {
            card.addView(expandedView(item), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else if (!expand && card.getChildCount() > 1) {
            card.removeViewAt(1);
        }
    }

    /** Collapse all at once, while animating image sizes and card heights together. */
    private void collapseAllCards() {
        if (expandedIds.isEmpty()) return;
        beginCardTransition();
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View child = listBox.getChildAt(i);
            if (!(child instanceof LinearLayout) || !(child.getTag() instanceof String)) continue;
            String id = (String) child.getTag();
            if (!expandedIds.contains(id)) continue;
            View head = ((LinearLayout) child).getChildAt(0);
            if (head.getTag() instanceof CardHeader) {
                CardHeader parts = (CardHeader) head.getTag();
                setCardExpanded((LinearLayout) child, parts.item, false);
            }
        }
        expandedIds.clear();
    }

    private View expandedView(WishlistItem item) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        // Prices, tags and actions now run beneath the large image at full card width.
        box.setPadding(dp(12), dp(4), dp(10), dp(12));

        LinearLayout prices = new LinearLayout(host);
        prices.setGravity(Gravity.CENTER_VERTICAL);
        prices.addView(field("登録時", price(item.registeredPrice)), new LinearLayout.LayoutParams(0, dp(44), 1f));
        prices.addView(field("現在", price(item.currentPrice)), new LinearLayout.LayoutParams(0, dp(44), 1f));
        box.addView(prices);

        List<WishlistRepository.PricePoint> history = repo.priceHistory(item.id, 2);
        String change = "価格変動：—";
        if (history.size() >= 2) {
            long d = history.get(0).price - history.get(1).price;
            change = "価格変動：" + shortDate(history.get(1).checkedAt) + "から " + (d > 0 ? "+" : "") + "¥" + String.format(Locale.JAPAN, "%,d", d);
        }
        TextView priceChange = text(change, 12, ORANGE, false);
        box.addView(priceChange, lp(dp(2), dp(3)));
        String registeredDiff = "登録時比：—";
        if (item.registeredPrice != null && item.currentPrice != null) {
            long d = item.currentPrice - item.registeredPrice;
            registeredDiff = "登録時比：" + (d > 0 ? "+" : "") + "¥" + String.format(Locale.JAPAN, "%,d", d);
        }
        box.addView(text(registeredDiff, 12, WHITE, false), lp(0, dp(6)));

        String priceCheck = item.lastPriceCheckedAt == null ? "未取得"
                : dateTime(item.lastPriceCheckedAt) + (item.priceFetchOk ? ""
                : "  " + (item.lastPriceError == null ? "価格取得失敗" : item.lastPriceError));
        TextView checked = text("最終確認：" + priceCheck, 11, LGRAY, false);
        box.addView(checked, lp(0, dp(8)));

        Flow tags = new Flow(host);
        List<WishlistRepository.Tag> assigned = repo.tagsForItemResolved(item.id);
        for (WishlistRepository.Tag t : assigned) tags.addView(tagChip(t.name, false));
        RoundPlusIcon addTag = new RoundPlusIcon(host, ORANGE, TEXT);
        addTag.setContentDescription("タグ追加");
        addTag.setOnClickListener(v -> showTagDialog(item.id));
        tags.addView(addTag, new ViewGroup.LayoutParams(dp(30), dp(30)));
        box.addView(tags, lp(0, dp(8)));

        TextView monitor = capsule(item.monitorResume ? "再開監視 ON" : "再開監視 OFF", item.monitorResume ? ORANGE : GRAY, 12);
        monitor.setOnClickListener(v -> {
            boolean next = !item.monitorResume;
            repo.setMonitor(item.id, next);
            if (next) requestNotificationPermission();
            WishlistScheduler.ensureScheduled(host);
            refreshList();
        });
        box.addView(monitor, new LinearLayout.LayoutParams(dp(116), dp(34)));

        LinearLayout actions = new LinearLayout(host);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView open = capsule("商品ページ", LBLUE, 12);
        open.setOnClickListener(v -> openProduct(item));
        TextView update = capsule("今すぐ更新", ORANGE, 12);
        update.setOnClickListener(v -> refreshOne(item.id));
        TextView delete = capsule("削除", LRED, 12);
        delete.setOnClickListener(v -> showDeleteDialog(item));
        addAction(actions, open); addAction(actions, update); addAction(actions, delete);
        box.addView(actions, lp(dp(8), 0));
        return box;
    }

    private void addAction(LinearLayout row, TextView v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(36), 1f);
        p.rightMargin = dp(5);
        row.addView(v, p);
    }

    /** PriceRec-style card reorder: long hold, finger tracking and FLIP sibling motion. */
    private void attachGrip(TextView grip, String id, View row) {
        final float[] downY = {0f};
        final float[] downX = {0f};
        final float[] pointerOffset = {0f};
        final float[] currentY = {0f};
        final boolean[] dragging = {false};
        final int[] originalIndex = {-1};
        final Runnable[] holdAction = new Runnable[1];
        final int slop = ViewConfiguration.get(host).getScaledTouchSlop();
        grip.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (hasFilters()) return false;
                    downY[0] = e.getRawY();
                    downX[0] = e.getRawX();
                    currentY[0] = downY[0];
                    int[] loc = new int[2];
                    row.getLocationOnScreen(loc);
                    pointerOffset[0] = downY[0] - loc[1];
                    dragging[0] = false;
                    originalIndex[0] = listBox.indexOfChild(row);
                    holdAction[0] = () -> {
                        if (row.getParent() != listBox) return;
                        dragging[0] = true;
                        v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                        row.animate().cancel();
                        row.setElevation(dp(14));
                        row.animate().scaleX(1.015f).scaleY(1.015f).setDuration(120).start();
                        listBox.setClipChildren(false);
                        listBox.setClipToPadding(false);
                        ViewGroup parent = (ViewGroup) listBox.getParent();
                        if (parent != null) parent.requestDisallowInterceptTouchEvent(true);
                    };
                    v.postDelayed(holdAction[0], 300L);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    currentY[0] = e.getRawY();
                    if (!dragging[0]) {
                        if ((Math.abs(currentY[0] - downY[0]) > slop
                                || Math.abs(e.getRawX() - downX[0]) > slop)
                                && holdAction[0] != null) {
                            v.removeCallbacks(holdAction[0]);
                            holdAction[0] = null;
                            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                        }
                        return true;
                    }
                    trackDraggedRow(row, currentY[0], pointerOffset[0]);
                    reorderToward(row, currentY[0], pointerOffset[0]);
                    edgeScroll(currentY[0]);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (holdAction[0] != null) v.removeCallbacks(holdAction[0]);
                    holdAction[0] = null;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    if (!dragging[0] && e.getActionMasked() == MotionEvent.ACTION_UP
                            && Math.abs(e.getRawX() - downX[0]) <= slop
                            && Math.abs(e.getRawY() - downY[0]) <= slop) {
                        // ACTION_DOWN was consumed to monitor a possible drag;
                        // dispatch accessibility-aware click only for a true tap.
                        v.performClick();
                    }
                    if (dragging[0]) {
                        if (e.getActionMasked() == MotionEvent.ACTION_CANCEL
                                && originalIndex[0] >= 0 && row.getParent() == listBox) {
                            moveCardWithAnimation(row, originalIndex[0], null);
                        } else if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                            // Only commit the new order on the actual drop.
                            persistCurrentOrder();
                        }
                        row.animate().cancel();
                        row.animate().translationY(0f).scaleX(1f).scaleY(1f)
                                .setDuration(200).setInterpolator(new DecelerateInterpolator())
                                .withEndAction(() -> row.setElevation(0f)).start();
                    }
                    dragging[0] = false;
                    return true;
            }
            return true;
        });
    }

    private boolean hasFilters() {
        return (query != null && !query.isBlank()) || !filterTags.isEmpty()
                || minPrice != null || maxPrice != null;
    }

    private void trackDraggedRow(View row, float rawY, float pointerOffset) {
        if (row.getParent() != listBox) return;
        int[] loc = new int[2];
        listBox.getLocationOnScreen(loc);
        row.setTranslationY(rawY - pointerOffset - loc[1] - row.getTop());
    }

    private void edgeScroll(float rawY) {
        if (listScroll == null) return;
        int[] loc = new int[2];
        listScroll.getLocationOnScreen(loc);
        if (rawY < loc[1] + dp(40)) listScroll.scrollBy(0, -dp(12));
        else if (rawY > loc[1] + listScroll.getHeight() - dp(40)) listScroll.scrollBy(0, dp(12));
    }

    private void reorderToward(View moving, float rawY, float pointerOffset) {
        int from = listBox.indexOfChild(moving);
        if (from < 0) return;
        int[] loc = new int[2];
        listBox.getLocationOnScreen(loc);
        float pointerCenter = rawY - pointerOffset + moving.getHeight() / 2f - loc[1];
        int to = from;
        if (from + 1 < listBox.getChildCount()) {
            for (int i = from + 1; i < listBox.getChildCount(); i++) {
                View other = listBox.getChildAt(i);
                float midpoint = other.getTop() + other.getHeight() / 2f;
                if (pointerCenter > midpoint) to = i; else break;
            }
        }
        if (from > 0) {
            for (int i = from - 1; i >= 0; i--) {
                View other = listBox.getChildAt(i);
                float midpoint = other.getTop() + other.getHeight() / 2f;
                if (pointerCenter < midpoint) to = i; else break;
            }
        }
        if (to == from) return;
        moveCardWithAnimation(moving, to, () -> trackDraggedRow(moving, rawY, pointerOffset));
    }

    /** Capture old visual positions and animate all displaced rows into their new slots. */
    private void moveCardWithAnimation(View moving, int destination, Runnable keepDraggedPosition) {
        int from = listBox.indexOfChild(moving);
        if (from < 0 || from == destination) return;
        Map<View, Float> oldPositions = new IdentityHashMap<>();
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View row = listBox.getChildAt(i);
            oldPositions.put(row, row.getTop() + row.getTranslationY());
            if (row != moving) row.animate().cancel();
        }
        listBox.removeViewAt(from);
        listBox.addView(moving, Math.max(0, Math.min(destination, listBox.getChildCount())));
        listBox.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override public boolean onPreDraw() {
                ViewTreeObserver observer = listBox.getViewTreeObserver();
                if (observer.isAlive()) observer.removeOnPreDrawListener(this);
                for (Map.Entry<View, Float> entry : oldPositions.entrySet()) {
                    View child = entry.getKey();
                    if (child.getParent() != listBox) continue;
                    if (child == moving) {
                        if (keepDraggedPosition != null) keepDraggedPosition.run();
                        continue;
                    }
                    child.setTranslationY(entry.getValue() - child.getTop());
                    child.animate().translationY(0f).setDuration(220)
                            .setInterpolator(new DecelerateInterpolator()).start();
                }
                return true;
            }
        });
    }

    private void persistCurrentOrder() {
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < listBox.getChildCount(); i++) {
            Object tag = listBox.getChildAt(i).getTag();
            if (tag instanceof String) ids.add((String) tag);
        }
        if (!ids.isEmpty()) repo.updateOrder(ids);
    }

    private View thumbnail(WishlistItem item) {
        FrameLayout f=new FrameLayout(host); f.setBackground(roundRect(GRAY, 9)); f.setClipToOutline(true);
        String path=item.previewPath!=null && new java.io.File(item.previewPath).isFile()
                ? item.previewPath : (item.thumbnailPath!=null?item.thumbnailPath:item.faviconPath);
        if(path!=null) {
            try { Bitmap b=BitmapFactory.decodeFile(path); if(b!=null){ ImageView i=new ImageView(host); i.setScaleType(ImageView.ScaleType.CENTER_CROP); i.setImageBitmap(b); f.addView(i,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)); } } catch(Throwable ignored){}
        }
        return f;
    }

    /** Editable search summary pinned to the screen bottom, outside Wishlist's ScrollView. */
    private LinearLayout buildFilterPanel() {
        LinearLayout panel = new LinearLayout(host);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(12));
        panel.setBackground(roundRect(GRAY, 12));
        panel.setFocusableInTouchMode(true);
        panel.addView(text("検索条件", 14, TEXT, true), lp(0, dp(7)));
        inlineQuery = input("検索語句（商品名・URL）");
        panel.addView(inlineQuery, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        LinearLayout prices = new LinearLayout(host);
        prices.setGravity(Gravity.CENTER_VERTICAL);
        inlineMin = input("最低価格");
        inlineMax = input("最高価格");
        inlineMin.setInputType(InputType.TYPE_CLASS_NUMBER);
        inlineMax.setInputType(InputType.TYPE_CLASS_NUMBER);
        prices.addView(inlineMin, new LinearLayout.LayoutParams(0, dp(42), 1f));
        Space separator = new Space(host);
        prices.addView(separator, new LinearLayout.LayoutParams(dp(8), 1));
        prices.addView(inlineMax, new LinearLayout.LayoutParams(0, dp(42), 1f));
        panel.addView(prices, lp(dp(8), 0));
        panel.addView(text("タグ", 12, WHITE, false), lp(dp(9), dp(5)));
        inlineTags = new Flow(host);
        // Bound the tag-chip area on small screens so the card list still has room.
        ScrollView tagChipScroll = new ScrollView(host);
        tagChipScroll.setFillViewport(false);
        tagChipScroll.addView(inlineTags, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(tagChipScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));
        LinearLayout buttons = new LinearLayout(host);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        // Reserve left-bottom space for the PriceRec tag circle without overlapping actions.
        buttons.addView(new Space(host), new LinearLayout.LayoutParams(dp(58), dp(36)));
        TextView clear = capsule("クリア", LRED, 13);
        TextView search = capsule("再検索", LBLUE, 13);
        addAction(buttons, clear);
        addAction(buttons, search);
        clear.setOnClickListener(v -> clearSearchFilters());
        search.setOnClickListener(v -> applySearch(inlineQuery.getText().toString(),
                number(inlineMin.getText().toString()), number(inlineMax.getText().toString()),
                new HashSet<>(draftFilterTags)));
        panel.addView(buttons, lp(dp(10), 0));
        return panel;
    }

    private void updateDraftTags() {
        if (inlineTags == null) return;
        inlineTags.removeAllViews();
        for (WishlistRepository.Tag t : repo.listTags()) {
            if (!draftFilterTags.contains(t.id)) continue;
            TextView chip = tagChip(t.name + "  ×", false);
            chip.setContentDescription(t.name + "の検索条件を解除");
            chip.setOnClickListener(v -> { draftFilterTags.remove(t.id); updateDraftTags(); });
            inlineTags.addView(chip);
        }
        TextView add = tagChip("＋ タグ", true);
        add.setContentDescription("検索タグを選択");
        add.setOnClickListener(v -> chooseSearchTags());
        inlineTags.addView(add);
    }

    private void chooseSearchTags() {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(14));
        body.setBackground(roundRect(LGRAY, 14));
        body.addView(text("検索するタグ", 18, TEXT, true), lp(0, dp(8)));
        Set<Long> candidate = new HashSet<>(draftFilterTags);
        ScrollView scroll = new ScrollView(host);
        LinearLayout choices = new LinearLayout(host);
        choices.setOrientation(LinearLayout.VERTICAL);
        for (WishlistRepository.Tag tag : repo.listTags()) choices.addView(checkRow(tag, candidate));
        scroll.addView(choices);
        body.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)));
        LinearLayout actions = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 12);
        TextView apply = capsule("適用", LBLUE, 12);
        addAction(actions, cancel); addAction(actions, apply);
        body.addView(actions, lp(dp(10), 0));
        cancel.setOnClickListener(v -> d.dismiss());
        apply.setOnClickListener(v -> {
            draftFilterTags.clear(); draftFilterTags.addAll(candidate);
            updateDraftTags(); d.dismiss();
        });
        d.setContentView(body);
        showDialog(d);
    }

    private void syncFilterPanel() {
        if (filterPanel == null) return;
        boolean active = hasFilters();
        filterPanel.setVisibility(active ? View.VISIBLE : View.GONE);
        int fabVisibility = active ? View.GONE : View.VISIBLE;
        if (tagFab != null) tagFab.setVisibility(fabVisibility);
        if (searchFab != null) searchFab.setVisibility(fabVisibility);
        if (addFab != null) addFab.setVisibility(fabVisibility);
        if (!active) return;
        // Keep focus off EditTexts until a user explicitly chooses a field.
        filterPanel.requestFocus();
        inlineQuery.setText(query);
        inlineMin.setText(minPrice == null ? "" : String.valueOf(minPrice));
        inlineMax.setText(maxPrice == null ? "" : String.valueOf(maxPrice));
        draftFilterTags.clear(); draftFilterTags.addAll(filterTags);
        updateDraftTags();
    }

    private void applySearch(String q, Long min, Long max, Set<Long> tags) {
        String text = q == null ? "" : q.trim();
        boolean any = !text.isEmpty() || min != null || max != null || !tags.isEmpty();
        if (!any) { clearSearchFilters(); return; }
        if (min != null && max != null && min > max) {
            Toast.makeText(host, "最低価格が最高価格を超えています", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!hasFilters()) {
            beforeSearchScrollY = listScroll.getScrollY();
            beforeSearchExpandedIds = new HashSet<>(expandedIds);
        }
        query = text;
        minPrice = min; maxPrice = max;
        filterTags.clear(); filterTags.addAll(tags);
        syncFilterPanel();
        refreshList();
        listScroll.post(() -> listScroll.scrollTo(0, 0));
        // The search is local. Never force a bulk network crawl merely to filter results.
        // Price values available from the latest successful scan are used as they are.
    }

    private void clearSearchFilters() {
        if (!hasFilters()) return;
        query = ""; minPrice = null; maxPrice = null; filterTags.clear();
        restoreBeforeSearch();
    }

    private void restoreBeforeSearch() {
        expandedIds.clear(); expandedIds.addAll(beforeSearchExpandedIds);
        syncFilterPanel();
        refreshList();
        final int restoreY = beforeSearchScrollY;
        listScroll.post(() -> listScroll.scrollTo(0, restoreY));
    }

    private void showSearchDialog() {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box=new LinearLayout(host); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(14),dp(16),dp(14)); box.setBackground(roundRect(LGRAY,14));
        TextView title=text("検索",18,TEXT,true); box.addView(title,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(38)));
        EditText q=input("商品名・URL"); q.setText(query); box.addView(q,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(46)));
        LinearLayout prices=new LinearLayout(host); prices.setGravity(Gravity.CENTER_VERTICAL);
        EditText min=input("最低価格"); min.setInputType(InputType.TYPE_CLASS_NUMBER); if(minPrice!=null)min.setText(String.valueOf(minPrice));
        EditText max=input("最高価格"); max.setInputType(InputType.TYPE_CLASS_NUMBER); if(maxPrice!=null)max.setText(String.valueOf(maxPrice));
        prices.addView(min,new LinearLayout.LayoutParams(0,dp(44),1f)); Space sp=new Space(host); prices.addView(sp,new LinearLayout.LayoutParams(dp(8),1)); prices.addView(max,new LinearLayout.LayoutParams(0,dp(44),1f)); box.addView(prices,lp(dp(8),0));
        TextView tagTitle=text("タグ",13,TEXT,true); box.addView(tagTitle,lp(dp(10),dp(4)));
        ScrollView tagScroll=new ScrollView(host); LinearLayout tagList=new LinearLayout(host); tagList.setOrientation(LinearLayout.VERTICAL); tagScroll.addView(tagList);
        Set<Long> selected=new HashSet<>(filterTags);
        for(WishlistRepository.Tag t:repo.listTags()) tagList.addView(checkRow(t,selected));
        box.addView(tagScroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(220)));
        LinearLayout buttons=new LinearLayout(host); buttons.setGravity(Gravity.CENTER_VERTICAL);
        TextView close=capsule("閉じる",GRAY,12); TextView clear=capsule("クリア",GRAY,12); TextView apply=capsule("検索",LBLUE,12);
        addAction(buttons,close); addAction(buttons,clear); addAction(buttons,apply); box.addView(buttons,lp(dp(10),0));
        clear.setOnClickListener(v -> { d.dismiss(); clearSearchFilters(); });
        apply.setOnClickListener(v -> {
            String word = q.getText().toString();
            Long lower = number(min.getText().toString());
            Long upper = number(max.getText().toString());
            if (lower != null && upper != null && lower > upper) {
                Toast.makeText(host, "最低価格が最高価格を超えています", Toast.LENGTH_SHORT).show();
                return;
            }
            d.dismiss();
            applySearch(word, lower, upper, selected);
        });
        close.setOnClickListener(v -> d.dismiss());
        d.setContentView(box); showDialog(d);
    }

    private View checkRow(WishlistRepository.Tag t, Set<Long> selected) {
        LinearLayout row=new LinearLayout(host); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4),dp(3),dp(4),dp(3));
        TextView check=text(selected.contains(t.id)?"✓":"",15,TEXT,true); check.setGravity(Gravity.CENTER); check.setBackground(circle(selected.contains(t.id)?GREEN:GRAY)); row.addView(check,new LinearLayout.LayoutParams(dp(28),dp(28)));
        TextView name=text(t.name,14,TEXT,false); LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(0,dp(38),1f); nlp.leftMargin=dp(10); row.addView(name,nlp);
        row.setOnClickListener(v -> { if(!selected.add(t.id))selected.remove(t.id); check.setText(selected.contains(t.id)?"✓":""); check.setBackground(circle(selected.contains(t.id)?GREEN:GRAY)); });
        return row;
    }

    /** PriceRec v0.1.81 tag-manager interaction pattern: select, bulk delete,
     * handle drag preview + drop save, long-press rename, in-place updates. */
    private void showTagManager() {
        Dialog dialog = new Dialog(host);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(14));
        body.setBackground(roundRect(LGRAY, 14));
        body.setFocusableInTouchMode(true);
        body.requestFocus();
        body.addView(text("タグ管理", 18, TEXT, true), lp(0, dp(10)));

        ScrollView scroll = new ScrollView(host);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout rows = new LinearLayout(host);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        int maxRowsHeight = Math.max(dp(120), host.getResources().getDisplayMetrics().heightPixels - dp(300));
        body.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.min(dp(280), maxRowsHeight)));

        LinearLayout create = new LinearLayout(host);
        create.setGravity(Gravity.CENTER_VERTICAL);
        EditText input = input("新しいタグ");
        create.addView(input, new LinearLayout.LayoutParams(0, dp(48), 1f));
        FrameLayout plusSlot = new FrameLayout(host);
        LinearLayout.LayoutParams slotParams = new LinearLayout.LayoutParams(dp(56), dp(48));
        slotParams.leftMargin = dp(8);
        create.addView(plusSlot, slotParams);
        RoundPlusIcon add = new RoundPlusIcon(host, ORANGE, TEXT);
        add.setContentDescription("タグ追加");
        FrameLayout.LayoutParams plusParams = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END | Gravity.CENTER_VERTICAL);
        plusParams.rightMargin = dp(4);
        plusSlot.addView(add, plusParams);
        body.addView(create, lp(dp(10), 0));

        LinearLayout footer = new LinearLayout(host);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView delete = capsule("削除", DGRAY, 13);
        TextView right = capsule("OK", LBLUE, 13);
        footer.addView(delete, new LinearLayout.LayoutParams(dp(118), dp(38)));
        footer.addView(new Space(host), new LinearLayout.LayoutParams(0, dp(38), 1f));
        footer.addView(right, new LinearLayout.LayoutParams(dp(118), dp(38)));
        body.addView(footer, lp(dp(12), 0));

        Set<Long> selectedIds = new HashSet<>();
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            if (!dialog.isShowing()) return;
            int y = scroll.getScrollY();
            rows.removeAllViews();
            List<WishlistRepository.Tag> tags = repo.listTags();
            for (WishlistRepository.Tag tag : tags) {
                boolean selected = selectedIds.contains(tag.id);
                LinearLayout row = new LinearLayout(host);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setTag(tag.id);
                row.setBackground(roundRect(selected ? BLUE : DGRAY, 7));
                row.setElevation(dp(2));
                TextView grip = text("☰", 22, WHITE, false);
                grip.setGravity(Gravity.CENTER);
                grip.setContentDescription(tag.name + "を並べ替え");
                row.addView(grip, new LinearLayout.LayoutParams(dp(40), dp(38)));
                TextView label = text(tag.name, 13, TEXT, selected);
                label.setGravity(Gravity.CENTER_VERTICAL);
                label.setIncludeFontPadding(false);
                row.addView(label, new LinearLayout.LayoutParams(0, dp(38), 1f));
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rowLp.bottomMargin = dp(4);
                rows.addView(row, rowLp);
                row.setOnClickListener(v -> {
                    if (!selectedIds.add(tag.id)) selectedIds.remove(tag.id);
                    render[0].run();
                });
                row.setOnLongClickListener(v -> {
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    showTagRenameDialog(tag, render[0]); // manager remains mounted behind editor
                    return true;
                });
                attachTagReorderGesture(grip, row, rows, tag.id, render[0]);
            }
            ViewGroup.LayoutParams scrollParams = scroll.getLayoutParams();
            if (scrollParams != null) {
                scrollParams.height = Math.min(maxRowsHeight, Math.max(dp(50), dp(42) * tags.size()));
                scroll.setLayoutParams(scrollParams);
            }
            if (tags.isEmpty()) {
                TextView placeholder = text("タグがありません", 13, TEXT, false);
                placeholder.setGravity(Gravity.CENTER);
                rows.addView(placeholder, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
            }
            boolean selecting = !selectedIds.isEmpty();
            delete.setEnabled(selecting);
            delete.setAlpha(selecting ? 1f : 0.55f);
            delete.setBackground(roundRect(selecting ? RED : DGRAY, 999));
            right.setText(selecting ? "キャンセル" : "OK");
            right.setBackground(roundRect(selecting ? DGRAY : LBLUE, 999));
            scroll.post(() -> scroll.scrollTo(0, Math.min(y, Math.max(0, rows.getHeight() - scroll.getHeight()))));
        };
        add.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
            if (tagNameExists(name, -1)) { input.setError("同じ名前のタグがあります"); return; }
            if (repo.createTag(name) == null) { input.setError("追加できませんでした"); return; }
            input.setText("");
            render[0].run();
            refreshList();
        });
        delete.setOnClickListener(v -> {
            if (selectedIds.isEmpty()) return;
            AlertDialog confirmation = new AlertDialog.Builder(host)
                    .setTitle("タグ削除")
                    .setMessage("選択した" + selectedIds.size() + "件のタグを削除します。商品自体は削除されません。")
                    .setNegativeButton("キャンセル", null)
                    .setPositiveButton("削除", (d, which) -> {
                        List<Long> ids = new ArrayList<>(selectedIds);
                        for (Long id : ids) if (id != null) repo.deleteTag(id);
                        selectedIds.clear();
                        render[0].run();
                        onTagsChanged();
                    }).create();
            confirmation.setOnShowListener(d -> {
                Window w = confirmation.getWindow();
                if (w != null) w.setBackgroundDrawable(roundRect(LGRAY, 14));
            });
            confirmation.show();
        });
        right.setOnClickListener(v -> {
            if (selectedIds.isEmpty()) dialog.dismiss();
            else { selectedIds.clear(); render[0].run(); }
        });
        dialog.setOnDismissListener(v -> onTagsChanged());
        dialog.setContentView(body);
        showDialog(dialog);
        render[0].run();
    }

    private boolean tagNameExists(String name, long excludingId) {
        for (WishlistRepository.Tag tag : repo.listTags())
            if (tag.id != excludingId && tag.name.equalsIgnoreCase(name.trim())) return true;
        return false;
    }

    private void onTagsChanged() {
        // Deleted tags cannot remain active in the applied or draft search.
        boolean wasSearching = hasFilters();
        Set<Long> existing = new HashSet<>();
        for (WishlistRepository.Tag t : repo.listTags()) existing.add(t.id);
        filterTags.retainAll(existing);
        draftFilterTags.retainAll(existing);
        if (wasSearching && !hasFilters()) restoreBeforeSearch();
        else { syncFilterPanel(); refreshList(); }
    }

    /** Child editor dismisses independently. The parent manager never closes. */
    private void showTagRenameDialog(WishlistRepository.Tag tag, Runnable afterEdit) {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(14));
        body.setBackground(roundRect(LGRAY, 14));
        body.setFocusableInTouchMode(true);
        body.requestFocus();
        body.addView(text("タグ名編集", 18, TEXT, true), lp(0, dp(8)));
        EditText name = input("タグ名");
        name.setText(tag.name);
        body.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        LinearLayout footer = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 13);
        TextView save = capsule("保存", LBLUE, 13);
        addAction(footer, cancel);
        addAction(footer, save);
        body.addView(footer, lp(dp(12), 0));
        cancel.setOnClickListener(v -> d.dismiss());
        save.setOnClickListener(v -> {
            String value = name.getText().toString().trim();
            if (value.isEmpty()) { name.setError("タグ名を入力"); return; }
            if (tagNameExists(value, tag.id)) { name.setError("同じ名前のタグがあります"); return; }
            repo.renameTag(tag.id, value);
            d.dismiss();
            if (afterEdit != null) afterEdit.run();
            onTagsChanged();
        });
        d.setContentView(body);
        showDialog(d);
    }

    /** PriceRec-style long-press grip gesture: preview peers, commit only on drop. */
    private void attachTagReorderGesture(TextView handle, View dragged, LinearLayout rows,
                                         long tagId, Runnable refresh) {
        final boolean[] armed = {false};
        final boolean[] moving = {false};
        final float[] downY = {0};
        final int[] from = {-1};
        final int[] target = {-1};
        handle.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downY[0] = event.getRawY();
                    from[0] = rows.indexOfChild(dragged);
                    target[0] = from[0];
                    armed[0] = false;
                    moving[0] = false;
                    return false; // Android handles the long-press on the grip
                case MotionEvent.ACTION_MOVE:
                    if (!armed[0]) return false;
                    float dy = event.getRawY() - downY[0];
                    if (!moving[0] && Math.abs(dy) < dp(6)) return true;
                    moving[0] = true;
                    dragged.setTranslationY(dy);
                    int next = nearestTagIndex(rows, event.getRawY());
                    if (next >= 0 && next != target[0]) {
                        target[0] = next;
                        animateTagReorderPreview(rows, dragged, from[0], next);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!armed[0]) return false;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    boolean commit = event.getActionMasked() == MotionEvent.ACTION_UP;
                    int destination = target[0];
                    boolean changed = moving[0] && destination >= 0 && destination != from[0];
                    resetTagReorderPreview(rows, dragged);
                    dragged.animate().translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                            .setDuration(145).setInterpolator(new DecelerateInterpolator()).start();
                    dragged.setElevation(dp(2));
                    if (commit && changed) {
                        List<Long> ids = new ArrayList<>();
                        for (WishlistRepository.Tag tag : repo.listTags()) ids.add(tag.id);
                        int old = ids.indexOf(tagId);
                        if (old >= 0) {
                            ids.remove(old);
                            ids.add(Math.max(0, Math.min(destination, ids.size())), tagId);
                            repo.setTagOrder(ids);
                            rows.postDelayed(() -> { if (refresh != null) refresh.run(); }, 155);
                        }
                    }
                    armed[0] = false;
                    moving[0] = false;
                    return true;
                default:
                    return armed[0];
            }
        });
        handle.setOnLongClickListener(v -> {
            armed[0] = true;
            moving[0] = false;
            from[0] = rows.indexOfChild(dragged);
            target[0] = from[0];
            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            dragged.setElevation(dp(12));
            dragged.animate().scaleX(1.025f).scaleY(1.025f).alpha(0.84f).setDuration(85).start();
            return true;
        });
    }

    private int nearestTagIndex(LinearLayout container, float rawY) {
        int[] loc = new int[2];
        container.getLocationOnScreen(loc);
        float y = rawY - loc[1];
        int index = -1;
        float distance = Float.MAX_VALUE;
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            float dy = Math.abs(y - (child.getTop() + child.getHeight() / 2f));
            if (dy < distance) { distance = dy; index = i; }
        }
        return index;
    }

    private void animateTagReorderPreview(LinearLayout container, View dragged, int from, int to) {
        if (from < 0 || to < 0) return;
        int shift = dragged.getHeight() + dp(4);
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child == dragged) continue;
            int offset = 0;
            if (to > from && i > from && i <= to) offset = -shift;
            else if (to < from && i >= to && i < from) offset = shift;
            child.animate().translationY(offset).setDuration(145)
                    .setInterpolator(new DecelerateInterpolator(1.55f)).start();
        }
    }

    private void resetTagReorderPreview(LinearLayout container, View dragged) {
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child != dragged) child.animate().translationY(0f).setDuration(125)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private void showTagDialog(String itemId) {
        Dialog dialog = new Dialog(host);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(14));
        body.setBackground(roundRect(LGRAY, 14));
        body.setFocusableInTouchMode(true);
        body.requestFocus();
        body.addView(text("タグ選択", 18, TEXT, true), lp(0, dp(10)));
        Set<Long> selected = new HashSet<>(repo.tagsForItem(itemId));
        ScrollView scroll = new ScrollView(host);
        LinearLayout rows = new LinearLayout(host);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows);
        body.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)));
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            int y = scroll.getScrollY();
            rows.removeAllViews();
            for (WishlistRepository.Tag tag : repo.listTags()) {
                // Same PriceRec grip/selection/rename actions as the global manager.
                LinearLayout row = new LinearLayout(host);
                row.setTag(tag.id);
                row.setGravity(Gravity.CENTER_VERTICAL);
                boolean active = selected.contains(tag.id);
                row.setBackground(roundRect(active ? BLUE : DGRAY, 7));
                row.setElevation(dp(2));
                TextView grip = text("☰", 22, WHITE, false);
                grip.setGravity(Gravity.CENTER);
                grip.setContentDescription(tag.name + "を並べ替え");
                row.addView(grip, new LinearLayout.LayoutParams(dp(40), dp(38)));
                TextView name = text(tag.name, 13, TEXT, active);
                name.setGravity(Gravity.CENTER_VERTICAL);
                row.addView(name, new LinearLayout.LayoutParams(0, dp(38), 1f));
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
                rowLp.bottomMargin = dp(4);
                rows.addView(row, rowLp);
                row.setOnClickListener(v -> {
                    if (!selected.add(tag.id)) selected.remove(tag.id);
                    render[0].run();
                });
                row.setOnLongClickListener(v -> {
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    showTagRenameDialog(tag, render[0]);
                    return true;
                });
                attachTagReorderGesture(grip, row, rows, tag.id, render[0]);
            }
            scroll.post(() -> scroll.scrollTo(0, Math.min(y, Math.max(0, rows.getHeight() - scroll.getHeight()))));
        };
        LinearLayout create = new LinearLayout(host);
        create.setGravity(Gravity.CENTER_VERTICAL);
        EditText input = input("新しいタグ");
        create.addView(input, new LinearLayout.LayoutParams(0, dp(44), 1f));
        FrameLayout slot = new FrameLayout(host);
        LinearLayout.LayoutParams slotLp = new LinearLayout.LayoutParams(dp(52), dp(44));
        slotLp.leftMargin = dp(8);
        create.addView(slot, slotLp);
        RoundPlusIcon add = new RoundPlusIcon(host, ORANGE, TEXT);
        add.setContentDescription("タグ追加");
        slot.addView(add, new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER));
        body.addView(create, lp(dp(8), 0));
        add.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
            if (tagNameExists(name, -1)) { input.setError("同じ名前のタグがあります"); return; }
            WishlistRepository.Tag tag = repo.createTag(name);
            if (tag == null) { input.setError("追加できませんでした"); return; }
            selected.add(tag.id);
            input.setText("");
            render[0].run();
        });
        LinearLayout footer = new LinearLayout(host);
        TextView apply = capsule("適用", LBLUE, 13);
        TextView close = capsule("閉じる", GRAY, 13);
        addAction(footer, apply);
        addAction(footer, close);
        body.addView(footer, lp(dp(10), 0));
        apply.setOnClickListener(v -> { repo.setTagsForItem(itemId, selected); dialog.dismiss(); });
        close.setOnClickListener(v -> { repo.setTagsForItem(itemId, selected); dialog.dismiss(); });
        dialog.setOnDismissListener(v -> { repo.setTagsForItem(itemId, selected); onTagsChanged(); });
        dialog.setContentView(body);
        showDialog(dialog);
        render[0].run();
    }

    private void openProduct(WishlistItem item) {
        if (item.url == null || item.url.isBlank()) return;
        try {
            host.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(item.url)));
        } catch (Exception e) {
            Toast.makeText(host, "商品ページを開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private void showUrlDialog() {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(roundRect(LGRAY, 14));
        box.setFocusableInTouchMode(true);
        box.requestFocus();
        TextView title = text("商品URLを追加", 18, TEXT, true);
        box.addView(title, lp(0, dp(12)));
        EditText url = input("https://www.amazon.co.jp/...");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        box.addView(url, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        TextView hint = text("商品名・画像・価格を取得できる範囲で自動入力します", 11, TEXT, false);
        box.addView(hint, lp(dp(10), dp(12)));
        LinearLayout buttons = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 12);
        TextView add = capsule("追加", LBLUE, 12);
        addAction(buttons, cancel);
        addAction(buttons, add);
        box.addView(buttons, lp(0, 0));
        cancel.setOnClickListener(v -> d.dismiss());
        add.setOnClickListener(v -> {
            String value = url.getText().toString().trim();
            if (!value.contains("://")) value = "https://" + value;
            Uri parsed = Uri.parse(value);
            if (!("https".equalsIgnoreCase(parsed.getScheme()) || "http".equalsIgnoreCase(parsed.getScheme()))
                    || parsed.getHost() == null || parsed.getHost().isBlank()) {
                url.setError("有効な商品URLを入力してください");
                return;
            }
            WishlistItem item = repo.addUrl(null, value);
            if (item == null) {
                Toast.makeText(host, "追加できませんでした", Toast.LENGTH_SHORT).show();
                return;
            }
            d.dismiss();
            expandedIds.add(item.id);
            refreshList();
            refreshOne(item.id);
        });
        d.setContentView(box);
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        showDialog(d);
    }

    private void chooseImage(WishlistItem item) {
        pendingImageItemId = item.id;
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.setType("image/*");
        try {
            host.startActivityForResult(picker, REQUEST_IMAGE_PICK);
        } catch (android.content.ActivityNotFoundException e) {
            pendingImageItemId = null;
            Toast.makeText(host, "画像を選ぶアプリがありません", Toast.LENGTH_SHORT).show();
        }
    }

    /** The selected image is saved into Wishlist's private storage; no URI permission needs to persist. */
    public void onImagePicked(int resultCode, Intent data) {
        final String id = pendingImageItemId;
        pendingImageItemId = null;
        if (id == null || resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return;
        final Uri image = data.getData();
        Toast.makeText(host, "商品画像を保存中…", Toast.LENGTH_SHORT).show();
        io.execute(() -> {
            boolean ok = repo.setManualImage(id, image);
            host.runOnUiThread(() -> {
                if (host.isFinishing() || host.isDestroyed()) return;
                refreshList();
                Toast.makeText(host, ok ? "商品画像を変更しました" : "画像を保存できませんでした",
                        Toast.LENGTH_SHORT).show();
            });
        });
    }

    private void showRenameDialog(WishlistItem item) {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(roundRect(LGRAY, 14));
        box.setFocusableInTouchMode(true);
        box.requestFocus();
        box.addView(text("商品名編集", 18, TEXT, true), lp(0, dp(12)));
        EditText name = input("商品名");
        name.setText(item.title);
        box.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        LinearLayout buttons = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 12);
        TextView save = capsule("保存", LBLUE, 12);
        addAction(buttons, cancel); addAction(buttons, save);
        box.addView(buttons, lp(dp(12), 0));
        cancel.setOnClickListener(v -> d.dismiss());
        save.setOnClickListener(v -> {
            String value = name.getText().toString().trim();
            if (value.isBlank()) { name.setError("商品名を入力してください"); return; }
            repo.rename(item.id, value); // Marks the name as manual: refresh will not overwrite it.
            d.dismiss();
            refreshList();
        });
        d.setContentView(box);
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        showDialog(d);
    }

    private void refreshOne(String id) {
        Toast.makeText(host, "更新中…", Toast.LENGTH_SHORT).show();
        // HTML is downloaded once, then image and price are persisted through isolated paths.
        // The proven price WebView behavior runs unchanged when needed, independently of images.
        io.execute(() -> {
            WishlistItem before = repo.get(id);
            if (before == null) return;
            WishlistCrawler.Result r = WishlistCrawler.fetch(before.url);
            repo.updateCrawl(id, r);
            final String pageUrl = r.resolvedUrl == null ? before.url : r.resolvedUrl;
            host.runOnUiThread(() -> {
                if (host.isFinishing() || host.isDestroyed()) return;
                refreshList();
                if (r.price != null) {
                    recoverMissingAmazonImage(id, pageUrl);
                    return;
                }
                if (priceProbe != null) priceProbe.cancel();
                priceProbe = new WishlistPriceWebViewProbe(root);
                Toast.makeText(host, "WebViewで価格を補完中…", Toast.LENGTH_SHORT).show();
                priceProbe.start(pageUrl, (price, failure) -> {
                    if (host.isFinishing() || host.isDestroyed()) return;
                    io.execute(() -> {
                        repo.updatePriceFromWebView(id, price, failure);
                        host.runOnUiThread(() -> {
                            if (host.isFinishing() || host.isDestroyed()) return;
                            refreshList();
                            Toast.makeText(host, price == null ?
                                    (failure == null ? "価格は取得できませんでした" : failure) :
                                    "価格を取得しました", Toast.LENGTH_SHORT).show();
                            recoverMissingAmazonImage(id, pageUrl);
                        });
                    });
                });
            });
        });
    }

    /** Manual Amazon image repair only. Image errors can never alter confirmed prices. */
    private void recoverMissingAmazonImage(String id, String pageUrl) {
        if (!WishlistImageWebViewProbe.isAmazonUrl(pageUrl)) return;
        WishlistItem now = repo.get(id);
        if (now == null || repo.hasUsablePreview(id)) return;
        if (imageProbe != null) imageProbe.cancel();
        imageProbe = new WishlistImageWebViewProbe(root);
        imageProbe.start(pageUrl, imageUrl -> {
            if (host.isFinishing() || host.isDestroyed()) return;
            if (imageUrl == null) {
                Toast.makeText(host, "Amazon画像は取得できませんでした", Toast.LENGTH_SHORT).show();
                return;
            }
            io.execute(() -> {
                boolean saved = repo.updateImageFromWebView(id, imageUrl, pageUrl);
                host.runOnUiThread(() -> {
                    if (host.isFinishing() || host.isDestroyed()) return;
                    refreshList();
                    if (!saved) Toast.makeText(host, "Amazon画像の保存に失敗しました", Toast.LENGTH_SHORT).show();
                });
            });
        });
    }

    private void refreshAllNow(Runnable done) {
        Toast.makeText(host,"Wishlistを更新中…",Toast.LENGTH_SHORT).show(); io.execute(()->{for(WishlistItem i:repo.listAll()){if(Thread.currentThread().isInterrupted())break; WishlistCrawler.Result r=WishlistCrawler.fetch(i.url);repo.updateCrawl(i.id,r);try{Thread.sleep(350);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}}host.runOnUiThread(()->{refreshList();if(done!=null)done.run();});});
    }

    private void maybeRefreshStale() {
        long now=System.currentTimeMillis(); boolean stale=false; for(WishlistItem i:repo.listAll())if(i.lastPriceCheckedAt==null||now-i.lastPriceCheckedAt>DAY_MS){stale=true;break;} if(!stale)return; io.execute(()->{for(WishlistItem i:repo.listAll()){if(i.lastPriceCheckedAt!=null&&now-i.lastPriceCheckedAt<=DAY_MS)continue;WishlistCrawler.Result r=WishlistCrawler.fetch(i.url);repo.updateCrawl(i.id,r);try{Thread.sleep(350);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}}host.runOnUiThread(this::refreshList);});
    }

    private void showDeleteDialog(WishlistItem item) {
        android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(host).setMessage("Wishlistから削除しますか？").setNegativeButton("キャンセル",null).setPositiveButton("削除",(d,w)->{repo.delete(item.id);expandedIds.remove(item.id);refreshList();}).create();dialog.setOnShowListener(x->{if(dialog.getWindow()!=null)dialog.getWindow().setBackgroundDrawable(roundRect(LGRAY,14));});dialog.show();
    }

    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&host.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)host.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},811);}

    private String collapsedSub(WishlistItem i){String s=statusLabel(i.status); if(i.monitorResume)s+="  • 再開監視";return s;}
    private int statusColor(String s){if("AVAILABLE".equals(s))return WHITE;if("UNAVAILABLE".equals(s))return LRED;if("COMING_SOON".equals(s))return ORANGE;return LGRAY;}
    private String statusLabel(String s){if("AVAILABLE".equals(s))return "購入可能";if("UNAVAILABLE".equals(s))return "現在購入不可";if("COMING_SOON".equals(s))return "未開始";return "状態未確認";}
    private static String price(Long p){return p==null?"—":"¥"+String.format(Locale.JAPAN,"%,d",p);}
    private String dateTime(long t){return DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(t));}
    private String shortDate(long t){return new java.text.SimpleDateFormat("M/d",Locale.JAPAN).format(new Date(t));}
    private Long number(String s){try{String v=s==null?"":s.replace(",","").trim();return v.isBlank()?null:Long.parseLong(v);}catch(Exception e){return null;}}

    private TextView field(String label,String value){LinearLayout b=new LinearLayout(host);return text(label+"  "+value,12,TEXT,false);}
    private EditText input(String hint){EditText e=new EditText(host);e.setSingleLine(true);e.setTextColor(DGRAY);e.setHintTextColor(GRAY);e.setTextSize(14);e.setHint(hint);e.setPadding(dp(12),0,dp(12),0);e.setBackground(roundRect(WHITE,999));return e;}
    private TextView text(String s,float size,int color,boolean bold){TextView t=new TextView(host);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setIncludeFontPadding(false);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private TextView capsule(String s,int color,float size){TextView t=text(s,size,TEXT,true);t.setGravity(Gravity.CENTER);t.setBackground(roundRect(color,999));t.setPadding(dp(8),0,dp(8),0);return t;}
    private TextView tagChip(String s,boolean add){TextView t=capsule(s,add?ORANGE:GRAY,12);t.setPadding(dp(10),0,dp(10),0);t.setMinHeight(dp(30));return t;}
    private GradientDrawable roundRect(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable circle(int color){GradientDrawable d=new GradientDrawable();d.setShape(GradientDrawable.OVAL);d.setColor(color);return d;}
    private LinearLayout.LayoutParams lp(int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,top,0,bottom);return p;}
    private int dp(int v){return Math.round(v*host.getResources().getDisplayMetrics().density);}
    private void showDialog(Dialog d) {
        Window w = d.getWindow();
        int width = host.getResources().getDisplayMetrics().widthPixels - dp(32);
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            WindowManager.LayoutParams params = w.getAttributes();
            params.width = width;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.gravity = Gravity.CENTER;
            params.windowAnimations = 0; // no side-sliding before the first layout
            w.setAttributes(params);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                    | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        d.show();
        if (w != null) w.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private static final class TagManageIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint holePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        TagManageIconView(Activity context) {
            super(context);
            paint.setColor(WHITE);
            paint.setStyle(Paint.Style.FILL);
            holePaint.setColor(GRAY);
            holePaint.setStyle(Paint.Style.FILL);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w * 0.50f;
            float cy = h * 0.50f;

            // Keep the 48dp circular button unchanged; shrink only the glyph inside it.
            canvas.save();
            canvas.scale(0.88f, 0.88f, cx, cy);

            // Flat 2D tag silhouette. Build it face-on with parallel sides, then rotate as one rigid shape.
            // This keeps the requested mirrored direction without perspective/skew distortion.
            canvas.save();
            canvas.rotate(45f, cx, cy);

            android.graphics.Path path = new android.graphics.Path();
            float left = w * 0.34f;
            float right = w * 0.66f;
            float top = h * 0.20f;
            float bottom = h * 0.80f;
            float r = Math.min(w, h) * 0.12f;

            path.moveTo(left + r, top);
            path.lineTo(right - r, top);
            path.quadTo(right, top, right, top + r);
            path.lineTo(right, bottom - r * 0.55f);
            path.quadTo(right, bottom, right - r * 0.55f, bottom);
            path.lineTo(left + r * 0.55f, bottom);
            path.quadTo(left, bottom, left, bottom - r * 0.55f);
            path.lineTo(left, top + r);
            path.quadTo(left, top, left + r, top);
            path.close();

            canvas.drawPath(path, paint);
            canvas.drawCircle(cx, h * 0.31f, Math.min(w, h) * 0.072f, holePaint);
            canvas.restore();
            canvas.restore();
        }
    }

    private static final class RoundPlusIcon extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fg = new Paint(Paint.ANTI_ALIAS_FLAG);
        RoundPlusIcon(Activity c, int background, int iconColor) {
            super(c);
            bg.setColor(background);
            bg.setStyle(Paint.Style.FILL);
            fg.setColor(iconColor);
            fg.setStyle(Paint.Style.STROKE);
            fg.setStrokeCap(Paint.Cap.ROUND);
            fg.setStrokeWidth(c.getResources().getDisplayMetrics().density * 2.4f);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight(), cx=w/2f, cy=h/2f;
            float r=Math.min(w,h)*.48f;
            c.drawCircle(cx,cy,r,bg);
            float arm=r*.43f;
            c.drawLine(cx-arm,cy,cx+arm,cy,fg);
            c.drawLine(cx,cy-arm,cx,cy+arm,fg);
        }
    }

    private static final class SearchIcon extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        SearchIcon(Activity c){super(c);p.setColor(WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(c.getResources().getDisplayMetrics().density*2.8f);p.setStrokeCap(Paint.Cap.ROUND);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();float r=Math.min(w,h)*.27f;float cx=w*.43f,cy=h*.43f;c.drawCircle(cx,cy,r,p);c.drawLine(cx+r*.72f,cy+r*.72f,w*.78f,h*.78f,p);}
    }

    private static final class Flow extends ViewGroup {
        private final int gap;
        Flow(Activity c){super(c);gap=Math.round(6*c.getResources().getDisplayMetrics().density);}
        @Override protected LayoutParams generateDefaultLayoutParams(){return new MarginLayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);}
        @Override public LayoutParams generateLayoutParams(android.util.AttributeSet attrs){return new MarginLayoutParams(getContext(),attrs);}
        @Override protected LayoutParams generateLayoutParams(LayoutParams p){return new MarginLayoutParams(p);}
        @Override protected boolean checkLayoutParams(LayoutParams p){return p instanceof MarginLayoutParams;}
        @Override protected void onMeasure(int ws,int hs){int w=MeasureSpec.getSize(ws),x=getPaddingLeft(),y=getPaddingTop(),line=0;for(int i=0;i<getChildCount();i++){View v=getChildAt(i);measureChild(v,ws,hs);if(x+v.getMeasuredWidth()+getPaddingRight()>w&&x>getPaddingLeft()){x=getPaddingLeft();y+=line+gap;line=0;}x+=v.getMeasuredWidth()+gap;line=Math.max(line,v.getMeasuredHeight());}setMeasuredDimension(w,y+line+getPaddingBottom());}
        @Override protected void onLayout(boolean ch,int l,int t,int r,int b){int x=getPaddingLeft(),y=getPaddingTop(),line=0,w=r-l;for(int i=0;i<getChildCount();i++){View v=getChildAt(i);if(x+v.getMeasuredWidth()+getPaddingRight()>w&&x>getPaddingLeft()){x=getPaddingLeft();y+=line+gap;line=0;}v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());x+=v.getMeasuredWidth()+gap;line=Math.max(line,v.getMeasuredHeight());}}
    }
}
