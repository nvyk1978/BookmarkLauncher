package com.cmyk.bookmarkslauncher;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewConfiguration;
import android.view.HapticFeedbackConstants;
import android.view.ViewTreeObserver;
import android.view.animation.DecelerateInterpolator;
import android.transition.ChangeBounds;
import android.transition.Fade;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.MotionEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.wishlist.WishlistCrawler;
import com.cmyk.bookmarkslauncher.wishlist.LargeRetailWebViewProbe;
import com.cmyk.bookmarkslauncher.wishlist.AmazonNameWebViewProbe;
import com.cmyk.bookmarkslauncher.wishlist.WishlistPriceWebViewProbe;
import com.cmyk.bookmarkslauncher.wishlist.WishlistAvailabilityWebViewProbe;
import com.cmyk.bookmarkslauncher.wishlist.WishlistImageWebViewProbe;
import com.cmyk.bookmarkslauncher.wishlist.WishlistRetailImageWebViewProbe;
import com.cmyk.bookmarkslauncher.wishlist.WishlistItem;
import com.cmyk.bookmarkslauncher.wishlist.WishlistMode;
import com.cmyk.bookmarkslauncher.wishlist.WishlistSiteBadge;
import com.cmyk.bookmarkslauncher.wishlist.WishlistSiteState;
import com.cmyk.bookmarkslauncher.wishlist.RetailDiagnostics;
import com.cmyk.bookmarkslauncher.wishlist.WishlistRepository;
import com.cmyk.bookmarkslauncher.wishlist.WishlistScheduler;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class WishlistPage {
    private static final int BG = 0xFF303030;
    private static final int DGRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int LGRAY = 0xFF656060;
    private static final int BLUE = 0xFF223355;
    private static final int LBLUE = 0xFF445577;
    private static final int RED = 0xFF441100;
    private static final int LRED = 0xFF662211;
    private static final int ORANGE = 0xFF775500;
    private static final int WHITE = 0xFFA9A999;
    private static final int GREEN = 0xFF227733;
    private static final int TEXT = 0xFFFFFFFF;
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;
    private static final String SORT_PREFS = "wishlist_display_sort";
    private static final String SORT_CHOICE = "sort_choice";
    private static final int SORT_DATE_NEW = 0;
    private static final int SORT_DATE_OLD = 1;
    private static final int SORT_PRICE_HIGH = 2;
    private static final int SORT_PRICE_LOW = 3;
    private int sortChoice = SORT_DATE_NEW;
    // Dragging a card remains possible; an explicit sort choice takes precedence
    // again when changed. Store manual order independently of registration date.
    private boolean manualOrderActive;
    private long manualOrderSince;

    private LargeRetailWebViewProbe largeRetailProbe;
    private WishlistRepository repo;
    private FrameLayout root;
    private LinearLayout listBox;
    private View scrollEndSpace;
    private ScrollView listScroll;
    private GripScrollFrame gripScroll;
    private LinearLayout pullRefreshHeader;
    private TextView pullRefreshLabel;
    private boolean batchRefreshing;
    // UI-thread-owned state; each card has its own independent progress indicator.
    private final Set<String> updatingItems = new HashSet<>();
    private final Map<String, ProgressBar> imageSpinners = new java.util.HashMap<>();
    private final Map<String, Integer> updateTasks = new java.util.HashMap<>();
    // Transient, UI-thread-only label: the CURRENT execution route, never the
    // persistent acquisitionMode. Cleared as soon as all card update tasks end.
    private final Map<String, String> runningModes = new java.util.HashMap<>();
    // Only one user-initiated refresh pipeline per card. A batch chains the SAME
    // card pipeline and awaits all rendered price, stock and image tasks.
    private final Map<String, Runnable> refreshCompletion = new java.util.HashMap<>();
    // A PRAGMA data_version token tracks changes made by the Home page or scheduler
    // through a separate SQLite connection; ordinary swipes reuse live card views.
    private long renderedExternalDbVersion = -1L;
    private TextView empty;
    // Cards are independent: expanding one never collapses another.
    private final Set<String> expandedIds = new HashSet<>();
    private String query = "";
    private final Set<Long> filterTags = new HashSet<>();
    private Long minPrice;
    private Long maxPrice;
    // Applied search criteria are independent from the editable draft controls.
    private LinearLayout filterPanel;
    private LinearLayout pageLayout;
    private int appliedImeLiftPx;
    // Floating entry points appear only outside search; the pinned filter panel replaces them.
    private View tagFab, searchFab, addFab;
    private EditText inlineQuery, inlineMin, inlineMax;
    private Flow inlineTags;
    private final Set<Long> draftFilterTags = new HashSet<>();
    // A tag created inside a Wish card is also revealed when tag management opens next.
    private long pendingTagManagerRevealId = -1L;
    private int beforeSearchScrollY;
    private Set<String> beforeSearchExpandedIds = new HashSet<>();
    private String pendingImageItemId;
    public static final int REQUEST_IMAGE_PICK = 7942;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private WishlistPriceWebViewProbe priceProbe;
    private WishlistAvailabilityWebViewProbe availabilityProbe;
    private WishlistImageWebViewProbe imageProbe;
    private WishlistRetailImageWebViewProbe retailImageProbe;

    private final Activity host;
    private final Runnable onBack;

    public WishlistPage(Activity host, Runnable onBack, String initialItemId) {
        this.host = host;
        this.onBack = onBack;
        repo = new WishlistRepository(host);
        SharedPreferences sortPrefs = host.getSharedPreferences(SORT_PREFS, Context.MODE_PRIVATE);
        int savedSort = sortPrefs.getInt(SORT_CHOICE, SORT_DATE_NEW);
        sortChoice = savedSort >= SORT_DATE_NEW && savedSort <= SORT_PRICE_LOW
                ? savedSort : SORT_DATE_NEW;
        manualOrderActive = sortPrefs.getBoolean("manual_order_active", false);
        manualOrderSince = sortPrefs.getLong("manual_order_since", 0L);
        WishlistScheduler.ensureScheduled(host);
        if (initialItemId != null) expandedIds.add(initialItemId);
        buildUi();
        refreshList();
        maybeRefreshStale();
    }

    public FrameLayout getView() { return root; }
    public void openItem(String id) { if (id != null) expandedIds.add(id); refreshList(); }
    public void refresh() { refreshList(); }
    /** Cheap revision check: never recreate every card at the start of a finger drag. */
    public void refreshIfExternalChanges() {
        long now = repo.externalDataVersion();
        if (now >= 0L && now != renderedExternalDbVersion) refreshList();
    }
    /** Android Back first clears active search, otherwise MainActivity navigates home. */
    public boolean handleBack() {
        if (!hasFilters()) return false;
        clearSearchFilters();
        return true;
    }
    public void destroy() {
        if (priceProbe != null) priceProbe.cancel();
        if (availabilityProbe != null) availabilityProbe.cancel();
        if (imageProbe != null) imageProbe.cancel();
        if (retailImageProbe != null) retailImageProbe.cancel();
        if (largeRetailProbe != null) largeRetailProbe.cancel();
        io.shutdownNow();
    }
    private void returnToBookmarks() { if (onBack != null) onBack.run(); }
    public void onHostResume() { /* No purchase prompts or purchase tracking UI. */ }

    private View buildUi() {
        root = new FrameLayout(host);
        root.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(host);
        // An opaque page also hides the attached background-only WebView probes.
        page.setBackgroundColor(BG);
        page.setOrientation(LinearLayout.VERTICAL);
        pageLayout = page;
        // Match the Home title: 18dp horizontal inset, 64dp top inset,
        // 25sp bold text centered vertically in a 44dp title row.
        page.setPadding(dp(18), dp(64), dp(18), dp(18));

        TextView title = text("Wishlist", 25, WHITE, true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setContentDescription("Wishlist：タップですべて格納");
        title.setOnClickListener(v -> collapseAllCards());
        page.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        PullRefreshScrollView scroll = new PullRefreshScrollView(host);
        listScroll = scroll;
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, dp(4), 0, dp(5));
        listBox = new LinearLayout(host);
        listBox.setOrientation(LinearLayout.VERTICAL);
        // The end spacer is scrollable content, not a fixed overlay: the last
        // card's actions can move above the floating tag/add/search circles.
        LinearLayout scrollContent = new LinearLayout(host);
        scrollContent.setOrientation(LinearLayout.VERTICAL);
        scrollContent.addView(listBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        scrollEndSpace = new Space(host);
        scrollContent.addView(scrollEndSpace, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(112)));
        scroll.addView(scrollContent, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // The card list alone gets a draggable fast-scroll thumb. Keep it outside
        // the ScrollView's children so ACTION_UP card reordering is unaffected.
        gripScroll = new GripScrollFrame(host, scroll);
        pullRefreshHeader = new LinearLayout(host);
        pullRefreshHeader.setPadding(dp(10), dp(8), dp(10), dp(8));
        pullRefreshHeader.setGravity(Gravity.CENTER);
        pullRefreshHeader.setBackground(roundRect(GRAY, 14));
        ProgressBar pullWheel = new ProgressBar(host);
        if (pullWheel.getIndeterminateDrawable() != null)
            pullWheel.getIndeterminateDrawable().mutate().setTint(WHITE);
        pullRefreshHeader.addView(pullWheel, new LinearLayout.LayoutParams(dp(26), dp(26)));
        pullRefreshLabel = text("下へ引いて全件更新", 12, WHITE, true);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        labelLp.leftMargin = dp(8);
        pullRefreshHeader.addView(pullRefreshLabel, labelLp);
        pullRefreshHeader.setVisibility(View.GONE);
        FrameLayout.LayoutParams pullLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(46), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        pullLp.topMargin = dp(8);
        gripScroll.addView(pullRefreshHeader, pullLp);
        scroll.setVerticalScrollBarEnabled(false); // prevent a duplicate native indicator
        scroll.setOnScrollChangeListener((v, x, y, oldX, oldY) -> gripScroll.onContentScrolled());
        page.addView(gripScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        // Search criteria live BELOW the independently scrolling card list.
        filterPanel = buildFilterPanel();
        page.addView(filterPanel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        filterPanel.setVisibility(View.GONE);
        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        empty = text("Wishlistは空です", 15, LGRAY, false);
        empty.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams emptyLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64), Gravity.CENTER);
        emptyLp.leftMargin = dp(28); emptyLp.rightMargin = dp(28);
        root.addView(empty, emptyLp);

        // PriceRec v0.1.81 TagManageIconView is copied without altering its silhouette.
        tagFab = new TagManageIconView(host);
        tagFab.setBackground(circle(GRAY));
        tagFab.setElevation(dp(8));
        tagFab.setContentDescription("タグ管理");
        tagFab.setOnClickListener(v -> showTagManager());
        FrameLayout.LayoutParams tagLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.START | Gravity.BOTTOM);
        tagLp.setMargins(dp(18), 0, 0, dp(24));
        root.addView(tagFab, tagLp);

        // Original floating + and magnifier return, with PriceRec's tag icon on the left.
        // During a search ALL THREE are hidden; only the pinned criteria card remains.
        FrameLayout searchButton = new FrameLayout(host);
        searchButton.setBackground(circle(LBLUE));
        searchButton.setElevation(dp(8));
        searchButton.addView(new SearchIcon(host), new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        searchButton.setContentDescription("Wishlist検索");
        searchButton.setOnClickListener(v -> showSearchDialog());
        FrameLayout.LayoutParams searchLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END | Gravity.BOTTOM);
        searchLp.setMargins(0, 0, dp(18), dp(24));
        root.addView(searchButton, searchLp);
        searchFab = searchButton;

        FrameLayout addButton = new FrameLayout(host);
        addButton.setElevation(dp(8));
        addButton.addView(new RoundPlusIcon(host, LBLUE, WHITE),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        addButton.setContentDescription("URLから商品を追加");
        addButton.setOnClickListener(v -> showUrlDialog());
        FrameLayout.LayoutParams addLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END | Gravity.BOTTOM);
        addLp.setMargins(0, 0, dp(84), dp(24));
        root.addView(addButton, addLp);
        addFab = addButton;
        return root;
    }

    private void refreshList() {
        imageSpinners.clear();
        List<WishlistItem> all = repo.listAll();
        List<WishlistItem> visible = new ArrayList<>();
        for (WishlistItem item : all) if (matches(item)) visible.add(item);
        sortVisibleItems(visible);
        listBox.removeAllViews();
        for (WishlistItem item : visible) listBox.addView(itemRow(item));
        empty.setVisibility(visible.isEmpty() ? View.VISIBLE : View.GONE);
        renderedExternalDbVersion = repo.externalDataVersion();
    }

    /** Sort the display without modifying stored timestamps, prices or existing records. */
    private void sortVisibleItems(List<WishlistItem> items) {
        if (manualOrderActive) {
            items.sort((a, b) -> {
                // Cards added after a manual drag still enter at the very top.
                boolean aNew = a.createdAt > manualOrderSince;
                boolean bNew = b.createdAt > manualOrderSince;
                if (aNew != bNew) return aNew ? -1 : 1;
                if (aNew) {
                    int newer = Long.compare(b.createdAt, a.createdAt);
                    if (newer != 0) return newer;
                }
                int byGrip = Integer.compare(a.sortIndex, b.sortIndex);
                return byGrip != 0 ? byGrip : stableItemOrder(a, b);
            });
            return;
        }
        items.sort((a, b) -> {
            if (sortChoice == SORT_PRICE_HIGH || sortChoice == SORT_PRICE_LOW) {
                // A stale/unknown price is not a trustworthy current-price sort key.
                Long ap = a.priceFetchOk ? a.currentPrice : null;
                Long bp = b.priceFetchOk ? b.currentPrice : null;
                if (ap == null && bp != null) return 1;
                if (bp == null && ap != null) return -1;
                if (ap != null && bp != null) {
                    int comparison = Long.compare(ap, bp);
                    if (comparison != 0) return sortChoice == SORT_PRICE_HIGH
                            ? -comparison : comparison;
                }
            }
            // Unknown/legacy timestamps belong at the bottom in either date direction.
            if (a.createdAt <= 0L && b.createdAt > 0L) return 1;
            if (b.createdAt <= 0L && a.createdAt > 0L) return -1;
            int byDate = Long.compare(a.createdAt, b.createdAt);
            if (byDate != 0) return sortChoice == SORT_DATE_OLD ? byDate : -byDate;
            return stableItemOrder(a, b);
        });
    }

    private static int stableItemOrder(WishlistItem a, WishlistItem b) {
        // If two registrations share the same millisecond, the newer insertion
        // has the larger append index and must appear first.
        int bySavedOrder = Integer.compare(b.sortIndex, a.sortIndex);
        if (bySavedOrder != 0) return bySavedOrder;
        return String.valueOf(a.id).compareTo(String.valueOf(b.id));
    }

    private void selectSort(int choice) {
        if (choice < SORT_DATE_NEW || choice > SORT_PRICE_LOW) return;
        sortChoice = choice;
        // An explicit radio selection always restores the selected sorting rule.
        manualOrderActive = false;
        manualOrderSince = 0L;
        host.getSharedPreferences(SORT_PREFS, Context.MODE_PRIVATE).edit()
                .putInt(SORT_CHOICE, choice)
                .putBoolean("manual_order_active", false)
                .remove("manual_order_since").apply();
        // Caller refreshes after applying search criteria; never reset the
        // pre-search scroll snapshot before applySearch has captured it.
    }

    private boolean matches(WishlistItem item) {
        if (item == null) return false;
        if (query != null && !query.isBlank()) {
            String hay = ((item.title == null ? "" : item.title) + " " + (item.url == null ? "" : item.url) + " " + (item.sourceName == null ? "" : item.sourceName)).toLowerCase(Locale.ROOT);
            String note = item.note == null ? "" : item.note.toLowerCase(Locale.ROOT);
            if (!hay.contains(query.trim().toLowerCase(Locale.ROOT))
                    && !note.contains(query.trim().toLowerCase(Locale.ROOT))) return false;
        }
        if (!filterTags.isEmpty()) {
            Set<Long> assigned = repo.tagsForItem(item.id);
            if (!assigned.containsAll(filterTags)) return false;
        }
        if (minPrice != null || maxPrice != null) {
            // Price filtering is only allowed to use a price confirmed by the latest crawl.
            // A failed refresh keeps the previous value for history/display, but never treats it as current.
            // A minimum/range is not an exact price; do not claim an exact match.
            if (!item.priceFetchOk || item.currentPrice == null) return false;
            if (minPrice != null && item.currentPrice < minPrice) return false;
            if (maxPrice != null && item.currentPrice > maxPrice) return false;
        }
        return true;
    }

    /** Keep the header/thumbnail views alive when toggling, so their bounds animate. */
    private static final class CardHeader {
        final LinearLayout line;
        final View thumb;
        final TextView grip;
        final TextView name;
        final TextView url;
        final TextView collapsedMode;
        final TextView updateModeCollapsed;
        final TextView updateModeExpanded;
        final LinearLayout footer;
        final LinearLayout editors;
        final EditText note;
        final TextView price;
        final WishlistItem item;
        CardHeader(LinearLayout line, View thumb, TextView grip, TextView name,
                   TextView url, TextView collapsedMode, TextView updateModeCollapsed,
                   TextView updateModeExpanded, LinearLayout footer, LinearLayout editors,
                   EditText note, TextView price, WishlistItem item) {
            this.line = line; this.thumb = thumb; this.grip = grip;
            this.name = name; this.url = url; this.collapsedMode = collapsedMode;
            this.updateModeCollapsed = updateModeCollapsed;
            this.updateModeExpanded = updateModeExpanded;
            this.footer = footer;
            this.editors = editors;
            this.note = note; this.price = price; this.item = item;
        }
    }

    private View itemRow(WishlistItem item) {
        boolean expanded = expandedIds.contains(item.id);
        LinearLayout card = new LinearLayout(host);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setTag(item.id);
        card.setBackground(roundRect(DGRAY, 12));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(0, 0, 0, dp(6));
        card.setLayoutParams(cardLp);

        LinearLayout line = new LinearLayout(host);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.TOP);
        line.setPadding(dp(2), dp(10), dp(12), dp(10));
        TextView grip = text("≡", 24, WHITE, true);
        // Center within its own hit target; reduce left outer inset.
        grip.setGravity(Gravity.CENTER);
        grip.setContentDescription("開閉（長押しで並べ替え）");
        grip.setOnClickListener(v -> toggleExpanded(item));
        line.addView(grip, new LinearLayout.LayoutParams(dp(32), dp(48)));
        attachGrip(grip, item.id, card);

        int imageSize = dp(expanded ? 140 : 80);
        View thumb = thumbnail(item);
        thumb.setContentDescription("商品画像：タップで開閉");
        thumb.setOnClickListener(v -> toggleExpanded(item));
        line.addView(thumb, new LinearLayout.LayoutParams(imageSize, imageSize));

        LinearLayout nameBox = new LinearLayout(host);
        nameBox.setOrientation(LinearLayout.VERTICAL);
        // The complete right-hand stack shares the thumbnail's height.
        // Expanded: title and URL at the top; editors and note at the bottom.
        nameBox.setGravity(Gravity.TOP);

        TextView name = text(item.title == null || item.title.isBlank() ? "商品" : item.title,
                14, TEXT, true);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setOnClickListener(v -> toggleExpanded(item));
        name.setOnLongClickListener(v -> { showRenameDialog(item); return true; });
        nameBox.addView(name, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Keep a fixed-size mode line beneath the name even when idle.
        // Invisible (not GONE) prevents any card movement on mode changes.
        TextView updateModeCollapsed = liveModeChip();
        nameBox.addView(updateModeCollapsed, liveModeChipParams());

        WishlistMode mode = item.acquisitionMode == null ? WishlistMode.UNRESOLVED : item.acquisitionMode;
        // A website label is visual only: URLs from GENERAL are never rerouted.
        String storeLabel = WishlistSiteBadge.forCard(item.url, mode);
        // Collapsed single row, left to right: price / present availability / [store].
        // Give stock the flexible middle region and pin the store label to the right.
        LinearLayout footer = new LinearLayout(host);
        footer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout stockRow = new LinearLayout(host);
        stockRow.setOrientation(LinearLayout.HORIZONTAL);
        stockRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView priceLabel = null;
        if (item.currentPrice != null || item.priceMinimum != null) {
            priceLabel = text(currentPriceText(item), 13, TEXT, true);
            priceLabel.setSingleLine(true);
            priceLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
            priceLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            priceLabel.setMaxWidth(dp(120));
            priceLabel.setVisibility(expanded ? View.GONE : View.VISIBLE);
            LinearLayout.LayoutParams priceLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(24));
            priceLp.rightMargin = dp(9);
            stockRow.addView(priceLabel, priceLp);
        }
        TextView sub = text(collapsedSub(item), 11,
                WishlistSiteState.label(item.siteState) != null ? ORANGE : statusColor(item.status), false);
        sub.setSingleLine(true);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sub.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        sub.setOnClickListener(v -> toggleExpanded(item));
        stockRow.addView(sub, new LinearLayout.LayoutParams(0, dp(24), 1f));
        TextView collapsedMode = modeChip(storeLabel);
        collapsedMode.setVisibility(!expanded && !storeLabel.isEmpty() ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams collapsedModeLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(15));
        collapsedModeLp.leftMargin = dp(8);
        stockRow.addView(collapsedMode, collapsedModeLp);
        footer.addView(stockRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));
        footer.setVisibility(expanded ? View.GONE : View.VISIBLE);

        TextView url = storeLabel.isEmpty() ? text(item.url == null ? "" : item.url, 11, LGRAY, false)
                : modeChip(storeLabel);
        url.setSingleLine(true);
        url.setEllipsize(android.text.TextUtils.TruncateAt.END);
        url.setVisibility(expanded ? View.VISIBLE : View.GONE);
        url.setOnClickListener(v -> toggleExpanded(item));
        LinearLayout.LayoutParams urlLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        urlLp.width = storeLabel.isEmpty() ? ViewGroup.LayoutParams.MATCH_PARENT
                : ViewGroup.LayoutParams.WRAP_CONTENT;
        urlLp.height = dp(15);
        urlLp.topMargin = dp(4);
        nameBox.addView(url, urlLp);
        // The expanded mode line occupies a fixed slot beneath the URL row.
        TextView updateModeExpanded = liveModeChip();
        nameBox.addView(updateModeExpanded, liveModeChipParams());
        // The spacer keeps the collapsed site/status/price row against the
        // thumbnail bottom; expanded editor controls still sit at the bottom.
        Space flexSpace = new Space(host);
        nameBox.addView(flexSpace, new LinearLayout.LayoutParams(1, 0, 1f));
        nameBox.addView(footer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        LinearLayout editors = new LinearLayout(host);
        editors.setGravity(Gravity.CENTER_VERTICAL);
        TextView rename = capsule("商品名編集", GRAY, 11);
        rename.setOnClickListener(v -> showRenameDialog(item));
        TextView editImage = capsule("画像編集", GRAY, 11);
        editImage.setOnClickListener(v -> chooseImage(item));
        LinearLayout.LayoutParams renameButtonLp = new LinearLayout.LayoutParams(0, dp(30), 1f);
        renameButtonLp.rightMargin = dp(6);
        editors.addView(rename, renameButtonLp);
        editors.addView(editImage, new LinearLayout.LayoutParams(0, dp(30), 1f));
        editors.setVisibility(expanded ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams editorsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(30));
        editorsLp.topMargin = 0;
        nameBox.addView(editors, editorsLp);

        // Editable note stays within the same 140dp vertical column as the image.
        EditText note = input("備考欄");
        note.setText(item.note == null ? "" : item.note);
        note.setTextSize(11);
        note.setSingleLine(true);
        note.setSelectAllOnFocus(false);
        note.setContentDescription("備考欄：商品検索の語句も入力できます");
        note.setVisibility(expanded ? View.VISIBLE : View.GONE);
        note.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(android.text.Editable s) {
                // Do not rebuild the card while typing, or dismiss the keyboard.
                repo.setNote(item.id, s.toString());
            }
        });
        // The flexible gap above the editors absorbs title-height differences;
        // note's bottom edge aligns with the thumbnail's bottom edge.
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(30));
        noteLp.topMargin = dp(6);
        nameBox.addView(note, noteLp);

        String runningMode = updatingItems.contains(item.id) ? runningModes.get(item.id) : null;
        showLiveModeChip(updateModeCollapsed, runningMode, !expanded);
        showLiveModeChip(updateModeExpanded, runningMode, expanded);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0,
                liveModeColumnHeight(expanded), 1f);
        nameLp.leftMargin = dp(12);
        line.addView(nameBox, nameLp);
        line.setTag(new CardHeader(line, thumb, grip, name, url, collapsedMode,
                updateModeCollapsed, updateModeExpanded, footer, editors, note, priceLabel, item));
        line.setOnClickListener(v -> toggleExpanded(item));
        card.addView(line, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (expanded) card.addView(expandedView(item), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    private void beginCardTransition() {
        TransitionSet transition = new TransitionSet();
        transition.setOrdering(TransitionSet.ORDERING_TOGETHER);
        transition.addTransition(new ChangeBounds());
        transition.addTransition(new Fade());
        transition.setDuration(250);
        transition.setInterpolator(new DecelerateInterpolator());
        TransitionManager.beginDelayedTransition(listBox, transition);
    }

    /** Toggle only the tapped card. All other expanded cards stay open. */
    private void toggleExpanded(WishlistItem item) {
        View card = findCard(item.id);
        if (!(card instanceof LinearLayout)) return;
        boolean expand = !expandedIds.contains(item.id);
        beginCardTransition();
        setCardExpanded((LinearLayout) card, item, expand);
        if (expand) expandedIds.add(item.id);
        else expandedIds.remove(item.id);
    }

    private View findCard(String id) {
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View v = listBox.getChildAt(i);
            if (id.equals(v.getTag())) return v;
        }
        return null;
    }

    private void setCardExpanded(LinearLayout card, WishlistItem item, boolean expand) {
        View headerView = card.getChildAt(0);
        if (!(headerView.getTag() instanceof CardHeader)) return;
        CardHeader header = (CardHeader) headerView.getTag();
        int side = dp(expand ? 140 : 80);
        ViewGroup.LayoutParams thumbLp = header.thumb.getLayoutParams();
        thumbLp.width = side;
        thumbLp.height = side;
        header.thumb.setLayoutParams(thumbLp);
        header.url.setVisibility(expand ? View.VISIBLE : View.GONE);
        String storeLabel = WishlistSiteBadge.forCard(item.url, item.acquisitionMode);
        header.collapsedMode.setVisibility(!expand && !storeLabel.isEmpty() ? View.VISIBLE : View.GONE);
        String runningMode = updatingItems.contains(item.id) ? runningModes.get(item.id) : null;
        showLiveModeChip(header.updateModeCollapsed, runningMode, !expand);
        showLiveModeChip(header.updateModeExpanded, runningMode, expand);
        header.editors.setVisibility(expand ? View.VISIBLE : View.GONE);
        header.note.setVisibility(expand ? View.VISIBLE : View.GONE);
        // Animate the complete right-hand column with the image size.
        ViewGroup rightColumn = (ViewGroup) header.note.getParent();
        ViewGroup.LayoutParams rightLp = rightColumn.getLayoutParams();
        rightLp.height = liveModeColumnHeight(expand);
        rightColumn.setLayoutParams(rightLp);
        // Keep a direct reference: the extra GONE progress labels are not
        // allowed to alter which row is collapsed during expand/collapse.
        View statusRow = header.footer;
        statusRow.setVisibility(expand ? View.GONE : View.VISIBLE);
        ViewGroup.LayoutParams statusLp = statusRow.getLayoutParams();
        statusLp.height = dp(24);
        statusRow.setLayoutParams(statusLp);
        if (header.price != null) header.price.setVisibility(expand ? View.GONE : View.VISIBLE);
        if (expand && card.getChildCount() == 1) {
            card.addView(expandedView(item), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else if (!expand && card.getChildCount() > 1) {
            card.removeViewAt(1);
        }
    }

    /** Collapse all at once, while animating image sizes and card heights together. */
    private void collapseAllCards() {
        if (expandedIds.isEmpty()) return;
        beginCardTransition();
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View child = listBox.getChildAt(i);
            if (!(child instanceof LinearLayout) || !(child.getTag() instanceof String)) continue;
            String id = (String) child.getTag();
            if (!expandedIds.contains(id)) continue;
            View head = ((LinearLayout) child).getChildAt(0);
            if (head.getTag() instanceof CardHeader) {
                CardHeader parts = (CardHeader) head.getTag();
                setCardExpanded((LinearLayout) child, parts.item, false);
            }
        }
        expandedIds.clear();
    }

    private View expandedView(WishlistItem item) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        // Prices, tags and actions now run beneath the large image at full card width.
        // Match the image's leading edge: header's 2dp inset + 32dp grip.
        // The red guide in the reference screenshot is NOT drawn in the UI.
        box.setPadding(dp(34), dp(4), dp(12), dp(12));

        LinearLayout prices = new LinearLayout(host);
        prices.setGravity(Gravity.TOP);
        prices.setMinimumHeight(dp(48));
        TextView registered = field("登録時", price(item.registeredPrice));
        TextView current = field("現在", currentPriceText(item));
        registered.setMinHeight(dp(48));
        current.setMinHeight(dp(48));
        registered.setGravity(Gravity.CENTER_VERTICAL);
        current.setGravity(Gravity.CENTER_VERTICAL);
        // Purchase evidence is independent of price and page reachability.
        // An older verified result must never be labelled "currently" buyable when
        // this check could not determine the product/variant's present stock.
        String stockDescription = availabilityDescription(item);
        String siteAnnotation = WishlistSiteState.label(item.siteState);
        String value = current.getText().toString()
                + (siteAnnotation != null && (item.currentPrice != null || item.priceMinimum != null)
                    ? "  (前回取得)" : "")
                + "  " + stockDescription;
        if (siteAnnotation != null) {
            value += "・" + siteAnnotation;
            android.text.SpannableString marked = new android.text.SpannableString(value);
            marked.setSpan(new android.text.style.ForegroundColorSpan(0xFFFFB366),
                    value.length() - siteAnnotation.length(), value.length(),
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            current.setText(marked);
        } else {
            current.setText(value);
        }
        current.setMaxLines(4);
        current.setEllipsize(android.text.TextUtils.TruncateAt.END);
        // 48dp minimum instead of the old 72dp fixed height.  Longer availability
        // explanations may wrap without being clipped or falsely truncated.
        prices.addView(registered, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        prices.addView(current, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(prices);

        List<WishlistRepository.PricePoint> history = repo.priceHistory(item.id, 2);
        String change = "価格変動：—";
        if (history.size() >= 2) {
            long d = history.get(0).price - history.get(1).price;
            change = "価格変動：" + shortDate(history.get(1).checkedAt) + "から " + signedYen(d);
        }
        // Price status stays on the left; monitor and share live in the previously
        // unused right-hand area (instead of below the tag row).
        LinearLayout statusRow = new LinearLayout(host);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout priceDetails = new LinearLayout(host);
        priceDetails.setOrientation(LinearLayout.VERTICAL);
        TextView priceChange = text(change, 12, ORANGE, false);
        priceChange.setMaxLines(2);
        priceChange.setEllipsize(android.text.TextUtils.TruncateAt.END);
        priceDetails.addView(priceChange, lp(dp(2), dp(3)));
        String registeredDiff = "登録時比：—";
        if (item.registeredPrice != null && item.currentPrice != null) {
            long d = item.currentPrice - item.registeredPrice;
            registeredDiff = "登録時比：" + signedYen(d);
        }
        TextView diffLabel = text(registeredDiff, 12, WHITE, false);
        diffLabel.setMaxLines(2);
        diffLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
        priceDetails.addView(diffLabel, lp(0, dp(6)));

        String priceCheck = item.lastPriceCheckedAt == null ? "未取得"
                : dateTime(item.lastPriceCheckedAt) + (item.priceFetchOk ? ""
                : "  " + (item.lastPriceError == null ? "価格取得失敗" : item.lastPriceError));
        TextView checked = text("最終確認：" + priceCheck, 11, LGRAY, false);
        checked.setMaxLines(3);
        checked.setEllipsize(android.text.TextUtils.TruncateAt.END);
        priceDetails.addView(checked, lp(0, dp(8)));
        statusRow.addView(priceDetails, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout quickActions = new LinearLayout(host);
        quickActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        TextView monitor = capsule(item.monitorResume ? "再開監視 ON" : "再開監視 OFF",
                item.monitorResume ? ORANGE : GRAY, 12);
        monitor.setContentDescription(item.monitorResume ? "再開監視を停止" : "再開監視を開始");
        monitor.setOnClickListener(v -> {
            boolean next = !item.monitorResume;
            repo.setMonitor(item.id, next);
            if (next) requestNotificationPermission();
            WishlistScheduler.ensureScheduled(host);
            refreshList();
        });
        quickActions.addView(monitor, new LinearLayout.LayoutParams(dp(116), dp(34)));

        // Canonical N Standard 0.1.28 share icon (42dp, D.GRAY fill, white geometric glyph).
        View share = new NShareIconView(host);
        share.setContentDescription("商品を共有");
        share.setOnClickListener(v -> shareProduct(item));
        LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(dp(NShareIconView.SIZE_DP), dp(NShareIconView.SIZE_DP));
        shareLp.leftMargin = dp(5);
        quickActions.addView(share, shareLp);
        LinearLayout.LayoutParams quickLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        quickLp.leftMargin = dp(5);
        statusRow.addView(quickActions, quickLp);
        box.addView(statusRow, lp(dp(2), dp(4)));

        Flow tags = new Flow(host);
        List<WishlistRepository.Tag> assigned = repo.tagsForItemResolved(item.id);
        // Add-tag stays at the leading (leftmost) slot even as chips wrap.
        RoundPlusIcon addTag = new RoundPlusIcon(host, ORANGE, TEXT);
        addTag.setContentDescription("タグ追加");
        addTag.setOnClickListener(v -> showTagDialog(item.id));
        tags.addView(addTag, new ViewGroup.LayoutParams(dp(30), dp(30)));
        for (WishlistRepository.Tag t : assigned) tags.addView(tagChip(t.name, false));
        box.addView(tags, lp(0, dp(8)));

        LinearLayout actions = new LinearLayout(host);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView open = capsule("商品ページ", LBLUE, 12);
        open.setOnClickListener(v -> openProduct(item));
        TextView update = capsule("情報更新", ORANGE, 12);
        update.setOnClickListener(v -> refreshOne(item.id));
        TextView delete = capsule("削除", LRED, 12);
        delete.setOnClickListener(v -> showDeleteDialog(item));
        // Card-only diagnostics from the canonical ImgStalker vector, followed by
        // the existing three actions. The icon matches the 36dp capsule height.
        ImgStalkerDiagnosticIconView diagnostics = new ImgStalkerDiagnosticIconView(host);
        diagnostics.setContentDescription("このWishカードの診断ログ");
        diagnostics.setOnClickListener(v -> NDiagnosticLog.showForWishlist(host, item.id));
        LinearLayout.LayoutParams diagnosticLp = new LinearLayout.LayoutParams(dp(36), dp(36));
        diagnosticLp.rightMargin = dp(8);
        actions.addView(diagnostics, diagnosticLp);
        // Keep the text buttons in their original order and equally weighted.
        addCardAction(actions, delete, false);
        addCardAction(actions, update, false);
        addCardAction(actions, open, true);
        box.addView(actions, lp(dp(12), 0));
        return box;
    }

    /** Android share sheet: share the product title and original URL, not its local image. */
    private void shareProduct(WishlistItem item) {
        if (item.url == null || item.url.isBlank()) {
            Toast.makeText(host, "共有できるURLがありません", Toast.LENGTH_SHORT).show();
            return;
        }
        String title = item.title == null ? "" : item.title.trim();
        // URL-fallback titles are not product names: never send the same URL twice.
        boolean hasName = !title.isEmpty() && !title.equals(item.url.trim())
                && !title.matches("(?i)^https?://\\S+$");
        String shareText = hasName ? title + "\n" + item.url.trim() : item.url.trim();
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, shareText);
        if (hasName) send.putExtra(Intent.EXTRA_SUBJECT, title);
        try {
            host.startActivity(Intent.createChooser(send, "商品を共有"));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(host, "共有できるアプリがありません", Toast.LENGTH_SHORT).show();
        }
    }

    private void addCardAction(LinearLayout row, TextView v, boolean last) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(36), 1f);
        if (!last) p.rightMargin = dp(8);
        row.addView(v, p);
    }

    private void addAction(LinearLayout row, TextView v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(36), 1f);
        p.rightMargin = dp(5);
        row.addView(v, p);
    }

    /**
     * PriceRec-style grip: preview positions while the pointer is held, and
     * commit the actual view order + repository order ONLY on ACTION_UP.
     *
     * Important: never remove/reinsert the touched row during MOVE. Detaching
     * a grip from the hierarchy cancels its touch stream and causes premature drops.
     */
    private void attachGrip(TextView grip, String id, View row) {
        final float[] downY = {0f};
        final float[] downX = {0f};
        final float[] pointerOffset = {0f};
        final float[] currentY = {0f};
        final boolean[] dragging = {false};
        final boolean[] touching = {false};
        final int[] from = {-1};
        final int[] target = {-1};
        final Runnable[] startHold = new Runnable[1];
        final Runnable[] edgeRun = new Runnable[1];
        final int slop = ViewConfiguration.get(host).getScaledTouchSlop();

        edgeRun[0] = () -> {
            if (!dragging[0] || !touching[0] || row.getParent() != listBox) return;
            if (scrollNearEdge(currentY[0])) {
                positionDraggedRow(row, currentY[0], pointerOffset[0]);
                int next = gripTargetIndex(row, from[0], currentY[0], pointerOffset[0]);
                if (next != target[0]) {
                    target[0] = next;
                    previewGripOrder(row, from[0], target[0]);
                }
                grip.postDelayed(edgeRun[0], 16L);
            }
        };

        grip.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (hasFilters()) return false;
                    if (row.getParent() != listBox) return false;
                    touching[0] = true;
                    dragging[0] = false;
                    downY[0] = currentY[0] = event.getRawY();
                    downX[0] = event.getRawX();
                    int[] loc = new int[2];
                    row.getLocationOnScreen(loc);
                    pointerOffset[0] = downY[0] - loc[1];
                    from[0] = target[0] = listBox.indexOfChild(row);
                    // Do not allow ScrollView / horizontal paging to steal and
                    // CANCEL an active grip gesture before finger-up.
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
                    startHold[0] = () -> {
                        if (!touching[0] || row.getParent() != listBox) return;
                        dragging[0] = true;
                        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                        row.animate().cancel();
                        row.setElevation(dp(14));
                        row.animate().scaleX(1.015f).scaleY(1.015f).setDuration(100).start();
                        listBox.setClipChildren(false);
                        listBox.setClipToPadding(false);
                        positionDraggedRow(row, currentY[0], pointerOffset[0]);
                        grip.removeCallbacks(edgeRun[0]);
                        grip.post(edgeRun[0]);
                    };
                    v.postDelayed(startHold[0], 300L);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!touching[0]) return true;
                    currentY[0] = event.getRawY();
                    if (!dragging[0]) {
                        if ((Math.abs(currentY[0] - downY[0]) > slop
                                || Math.abs(event.getRawX() - downX[0]) > slop)
                                && startHold[0] != null) {
                            v.removeCallbacks(startHold[0]);
                            startHold[0] = null;
                        }
                        return true;
                    }
                    positionDraggedRow(row, currentY[0], pointerOffset[0]);
                    int next = gripTargetIndex(row, from[0], currentY[0], pointerOffset[0]);
                    if (next != target[0]) {
                        target[0] = next;
                        previewGripOrder(row, from[0], target[0]);
                    }
                    // Start/restart edge auto-scroll when the pointer enters the
                    // edge zone after the initial long press.
                    v.removeCallbacks(edgeRun[0]);
                    v.post(edgeRun[0]);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (startHold[0] != null) v.removeCallbacks(startHold[0]);
                    startHold[0] = null;
                    v.removeCallbacks(edgeRun[0]);
                    touching[0] = false;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    boolean commit = event.getActionMasked() == MotionEvent.ACTION_UP;
                    if (dragging[0]) {
                        if (commit && from[0] >= 0 && target[0] >= 0 && target[0] != from[0]
                                && row.getParent() == listBox) {
                            // Physical rearrangement is AFTER finger-up, never during a drag.
                            moveCardWithAnimation(row, target[0], null);
                            persistCurrentOrder();
                        } else {
                            resetGripPreview(row);
                            row.animate().translationY(0f).setDuration(160)
                                    .setInterpolator(new DecelerateInterpolator()).start();
                        }
                        row.animate().scaleX(1f).scaleY(1f).setDuration(160)
                                .withEndAction(() -> row.setElevation(0f)).start();
                    } else if (commit && Math.abs(event.getRawX() - downX[0]) <= slop
                            && Math.abs(event.getRawY() - downY[0]) <= slop) {
                        v.performClick();
                    }
                    dragging[0] = false;
                    from[0] = target[0] = -1;
                    return true;
                default:
                    return touching[0];
            }
        });
    }

    private boolean scrollNearEdge(float rawY) {
        if (listScroll == null) return false;
        int[] loc = new int[2];
        listScroll.getLocationOnScreen(loc);
        final int top = loc[1], bottom = top + listScroll.getHeight();
        if (rawY < top || rawY > bottom) return false;
        int before = listScroll.getScrollY();
        if (rawY < top + dp(48)) listScroll.scrollBy(0, -dp(10));
        else if (rawY > bottom - dp(48)) listScroll.scrollBy(0, dp(10));
        return before != listScroll.getScrollY();
    }

    private void positionDraggedRow(View row, float rawY, float pointerOffset) {
        if (row.getParent() != listBox) return;
        int[] loc = new int[2];
        listBox.getLocationOnScreen(loc);
        row.setTranslationY(rawY - pointerOffset - loc[1] - row.getTop());
    }

    private int gripTargetIndex(View moving, int from, float rawY, float pointerOffset) {
        if (from < 0 || moving.getParent() != listBox) return from;
        int[] loc = new int[2];
        listBox.getLocationOnScreen(loc);
        float center = rawY - pointerOffset + moving.getHeight() / 2f - loc[1];
        int result = from;
        if (center > moving.getTop() + moving.getHeight() / 2f) {
            for (int i = from + 1; i < listBox.getChildCount(); i++) {
                View other = listBox.getChildAt(i);
                if (center > other.getTop() + other.getHeight() / 2f) result = i;
                else break;
            }
        } else {
            for (int i = from - 1; i >= 0; i--) {
                View other = listBox.getChildAt(i);
                if (center < other.getTop() + other.getHeight() / 2f) result = i;
                else break;
            }
        }
        return result;
    }

    private void previewGripOrder(View dragged, int from, int to) {
        if (from < 0 || to < 0) return;
        int shift = dragged.getHeight();
        ViewGroup.LayoutParams layout = dragged.getLayoutParams();
        if (layout instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams margins = (ViewGroup.MarginLayoutParams) layout;
            shift += margins.topMargin + margins.bottomMargin;
        }
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View other = listBox.getChildAt(i);
            if (other == dragged) continue;
            float dy = 0f;
            if (to > from && i > from && i <= to) dy = -shift;
            else if (to < from && i >= to && i < from) dy = shift;
            other.animate().translationY(dy).setDuration(145)
                    .setInterpolator(new DecelerateInterpolator(1.55f)).start();
        }
    }

    private void resetGripPreview(View dragged) {
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View other = listBox.getChildAt(i);
            if (other != dragged) other.animate().translationY(0f).setDuration(145)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private boolean listBoxHasNoCards() { return listBox == null || listBox.getChildCount() == 0; }

    private boolean hasFilters() {
        return (query != null && !query.isBlank()) || !filterTags.isEmpty()
                || minPrice != null || maxPrice != null;
    }

    /** Capture old visual positions and animate all displaced rows into their new slots. */
    private void moveCardWithAnimation(View moving, int destination, Runnable keepDraggedPosition) {
        int from = listBox.indexOfChild(moving);
        if (from < 0 || from == destination) return;
        Map<View, Float> oldPositions = new IdentityHashMap<>();
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View row = listBox.getChildAt(i);
            oldPositions.put(row, row.getTop() + row.getTranslationY());
            if (row != moving) row.animate().cancel();
        }
        listBox.removeViewAt(from);
        listBox.addView(moving, Math.max(0, Math.min(destination, listBox.getChildCount())));
        listBox.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override public boolean onPreDraw() {
                ViewTreeObserver observer = listBox.getViewTreeObserver();
                if (observer.isAlive()) observer.removeOnPreDrawListener(this);
                for (Map.Entry<View, Float> entry : oldPositions.entrySet()) {
                    View child = entry.getKey();
                    if (child.getParent() != listBox) continue;
                    if (child == moving && keepDraggedPosition != null) {
                        keepDraggedPosition.run();
                        continue;
                    }
                    child.setTranslationY(entry.getValue() - child.getTop());
                    child.animate().translationY(0f).setDuration(220)
                            .setInterpolator(new DecelerateInterpolator()).start();
                }
                return true;
            }
        });
    }

    private void persistCurrentOrder() {
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < listBox.getChildCount(); i++) {
            Object tag = listBox.getChildAt(i).getTag();
            if (tag instanceof String) ids.add((String) tag);
        }
        if (!ids.isEmpty()) {
            repo.updateOrder(ids);
            // Respect existing card-grip manual reordering without falsifying
            // createdAt. The next explicit radio selection returns to date/price sort.
            manualOrderActive = true;
            manualOrderSince = System.currentTimeMillis();
            host.getSharedPreferences(SORT_PREFS, Context.MODE_PRIVATE).edit()
                    .putBoolean("manual_order_active", true)
                    .putLong("manual_order_since", manualOrderSince).apply();
        }
    }

    private View thumbnail(WishlistItem item) {
        FrameLayout f=new FrameLayout(host); f.setBackground(roundRect(GRAY, 9)); f.setClipToOutline(true);
        String path=item.previewPath!=null && new java.io.File(item.previewPath).isFile()
                ? item.previewPath : (item.thumbnailPath!=null?item.thumbnailPath:item.faviconPath);
        if(path!=null) {
            try { Bitmap b=BitmapFactory.decodeFile(path); if(b!=null){ ImageView i=new ImageView(host); i.setScaleType(ImageView.ScaleType.CENTER_CROP); i.setImageBitmap(b); f.addView(i,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)); } } catch(Throwable ignored){}
        }
        // Overlay only: never replace a saved or user-selected product image.
        ProgressBar wheel = new ProgressBar(host);
        if (wheel.getIndeterminateDrawable() != null)
            wheel.getIndeterminateDrawable().mutate().setTint(WHITE);
        wheel.setVisibility(updatingItems.contains(item.id) ? View.VISIBLE : View.GONE);
        wheel.setContentDescription("商品情報を更新中");
        f.addView(wheel, new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        imageSpinners.put(item.id, wheel);
        return f;
    }

    /** Editable search summary pinned to the screen bottom, outside Wishlist's ScrollView. */
    private LinearLayout buildFilterPanel() {
        LinearLayout panel = new LinearLayout(host);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(12));
        panel.setBackground(roundRect(GRAY, 12));
        panel.setFocusableInTouchMode(true);
        panel.addView(text("検索条件", 14, TEXT, true), lp(0, dp(7)));
        inlineQuery = input("検索語句（商品名・URL）");
        panel.addView(inlineQuery, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        LinearLayout prices = new LinearLayout(host);
        prices.setGravity(Gravity.CENTER_VERTICAL);
        inlineMin = input("最低価格");
        inlineMax = input("最高価格");
        configurePriceInput(inlineMin);
        configurePriceInput(inlineMax);
        prices.addView(inlineMin, new LinearLayout.LayoutParams(0, dp(42), 1f));
        Space separator = new Space(host);
        prices.addView(separator, new LinearLayout.LayoutParams(dp(8), 1));
        prices.addView(inlineMax, new LinearLayout.LayoutParams(0, dp(42), 1f));
        panel.addView(prices, lp(dp(8), 0));
        panel.addView(text("タグ", 12, WHITE, false), lp(dp(9), dp(5)));
        inlineTags = new Flow(host);
        // Bound the tag-chip area on small screens so the card list still has room.
        ScrollView tagChipScroll = new ScrollView(host);
        tagChipScroll.setFillViewport(false);
        tagChipScroll.addView(inlineTags, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(tagChipScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));
        LinearLayout buttons = new LinearLayout(host);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        TextView close = capsule("閉じる", GRAY, 13);
        TextView clear = capsule("クリア", LRED, 13);
        TextView search = capsule("再検索", LBLUE, 13);
        addCardAction(buttons, close, false);
        addCardAction(buttons, clear, false);
        addCardAction(buttons, search, true);
        close.setOnClickListener(v -> {
            hideInlineIme();
            clearSearchFilters(); // Leave search, restore prior scroll/expanded cards.
        });
        clear.setOnClickListener(v -> {
            // Clear ONLY editable criteria; keep search mode and existing results
            // until the user explicitly chooses 再検索 or 閉じる.
            inlineQuery.setText("");
            inlineMin.setText("");
            inlineMax.setText("");
            draftFilterTags.clear();
            updateDraftTags();
        });
        search.setOnClickListener(v -> applySearch(inlineQuery.getText().toString(),
                number(inlineMin.getText().toString()), number(inlineMax.getText().toString()),
                new HashSet<>(draftFilterTags)));
        panel.addView(buttons, lp(dp(10), 0));
        return panel;
    }

    private void updateDraftTags() {
        if (inlineTags == null) return;
        inlineTags.removeAllViews();
        for (WishlistRepository.Tag t : repo.listTags()) {
            if (!draftFilterTags.contains(t.id)) continue;
            TextView chip = tagChip(t.name + "  ×", false);
            chip.setBackground(roundRect(LBLUE, 999));
            chip.setContentDescription(t.name + "の検索条件を解除");
            chip.setOnClickListener(v -> { draftFilterTags.remove(t.id); updateDraftTags(); });
            inlineTags.addView(chip);
        }
        TextView add = tagChip("＋ タグ", true);
        add.setContentDescription("検索タグを選択");
        add.setOnClickListener(v -> chooseSearchTags());
        inlineTags.addView(add);
    }

    private void chooseSearchTags() {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(14));
        body.setBackground(roundRect(LGRAY, 14));
        body.addView(text("検索するタグ", 18, TEXT, true), lp(0, dp(8)));
        Set<Long> candidate = new HashSet<>(draftFilterTags);
        MaxHeightScrollView scroll = new MaxHeightScrollView(host, dp(230));
        Flow choices = new Flow(host);
        choices.setPadding(dp(2), dp(2), dp(2), dp(2));
        for (WishlistRepository.Tag tag : repo.listTags())
            choices.addView(searchTagChip(tag, candidate));
        scroll.addView(choices);
        body.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout actions = new LinearLayout(host);
        TextView apply = capsule("適用", LBLUE, 12);
        TextView cancel = capsule("キャンセル", GRAY, 12);
        // Search tag selection: cancel left, apply right.
        addAction(actions, cancel); addAction(actions, apply);
        body.addView(actions, lp(dp(10), 0));
        cancel.setOnClickListener(v -> d.dismiss());
        apply.setOnClickListener(v -> {
            draftFilterTags.clear(); draftFilterTags.addAll(candidate);
            updateDraftTags(); d.dismiss();
        });
        d.setContentView(body);
        showDialog(d);
    }

    private void syncFilterPanel() {
        if (filterPanel == null) return;
        boolean active = hasFilters();
        filterPanel.setVisibility(active ? View.VISIBLE : View.GONE);
        int fabVisibility = active ? View.GONE : View.VISIBLE;
        if (scrollEndSpace != null) {
            ViewGroup.LayoutParams spacerLp = scrollEndSpace.getLayoutParams();
            spacerLp.height = dp(active ? 16 : 112);
            scrollEndSpace.setLayoutParams(spacerLp);
        }
        if (!active) updateImeObstruction(0);
        if (tagFab != null) tagFab.setVisibility(fabVisibility);
        if (searchFab != null) searchFab.setVisibility(fabVisibility);
        if (addFab != null) addFab.setVisibility(fabVisibility);
        if (!active) return;
        // Keep focus off EditTexts until a user explicitly chooses a field.
        filterPanel.requestFocus();
        inlineQuery.setText(query);
        inlineMin.setText(minPrice == null ? "" : String.valueOf(minPrice));
        inlineMax.setText(maxPrice == null ? "" : String.valueOf(maxPrice));
        draftFilterTags.clear(); draftFilterTags.addAll(filterTags);
        updateDraftTags();
    }

    private void applySearch(String q, Long min, Long max, Set<Long> tags) {
        String text = q == null ? "" : q.trim();
        boolean any = !text.isEmpty() || min != null || max != null || !tags.isEmpty();
        if (!any) { clearSearchFilters(); return; }
        if (min != null && max != null && min > max) {
            Toast.makeText(host, "最低価格が最高価格を超えています", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!hasFilters()) {
            beforeSearchScrollY = listScroll.getScrollY();
            beforeSearchExpandedIds = new HashSet<>(expandedIds);
        }
        query = text;
        minPrice = min; maxPrice = max;
        filterTags.clear(); filterTags.addAll(tags);
        syncFilterPanel();
        refreshList();
        listScroll.post(() -> listScroll.scrollTo(0, 0));
        // The search is local. Never force a bulk network crawl merely to filter results.
        // Price values available from the latest successful scan are used as they are.
    }

    private void hideInlineIme() {
        View focused = host.getCurrentFocus();
        if (focused != inlineQuery && focused != inlineMin && focused != inlineMax) return;
        InputMethodManager imm = (InputMethodManager) host.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
        focused.clearFocus();
        filterPanel.requestFocus();
    }

    private void clearSearchFilters() {
        if (!hasFilters()) return;
        query = ""; minPrice = null; maxPrice = null; filterTags.clear();
        restoreBeforeSearch();
    }

    private void restoreBeforeSearch() {
        expandedIds.clear(); expandedIds.addAll(beforeSearchExpandedIds);
        syncFilterPanel();
        refreshList();
        final int restoreY = beforeSearchScrollY;
        listScroll.post(() -> listScroll.scrollTo(0, restoreY));
    }

    private void showSearchDialog() {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box=new LinearLayout(host); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(14),dp(16),dp(14)); box.setBackground(roundRect(LGRAY,14));
        TextView title=text("検索",18,TEXT,true); box.addView(title,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(38)));
        EditText q=input("商品名・URL"); q.setText(query); box.addView(q,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(46)));
        LinearLayout prices=new LinearLayout(host); prices.setGravity(Gravity.CENTER_VERTICAL);
        EditText min=input("最低価格"); configurePriceInput(min); if(minPrice!=null)min.setText(String.valueOf(minPrice));
        EditText max=input("最高価格"); configurePriceInput(max); if(maxPrice!=null)max.setText(String.valueOf(maxPrice));
        prices.addView(min,new LinearLayout.LayoutParams(0,dp(44),1f)); Space sp=new Space(host); prices.addView(sp,new LinearLayout.LayoutParams(dp(8),1)); prices.addView(max,new LinearLayout.LayoutParams(0,dp(44),1f)); box.addView(prices,lp(dp(8),0));
        TextView tagTitle=text("タグ",13,TEXT,true); box.addView(tagTitle,lp(dp(10),dp(4)));
        Set<Long> selected=new HashSet<>(filterTags);
        MaxHeightScrollView tagScroll = new MaxHeightScrollView(host, dp(220));
        Flow tagList = new Flow(host);
        tagList.setPadding(dp(2), dp(2), dp(2), dp(2));
        final List<TextView> draftTagViews = new ArrayList<>();
        for (WishlistRepository.Tag t : repo.listTags()) {
            TextView chip = searchTagChip(t, selected);
            draftTagViews.add(chip);
            tagList.addView(chip);
        }
        tagScroll.addView(tagList);
        box.addView(tagScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(text("ソート", 13, TEXT, true), lp(dp(10), dp(4)));
        // One RadioGroup owns all four choices; the two option columns have
        // fixed, equal weights so their X positions never depend on label length.
        RadioGroup sortOptions = new RadioGroup(host);
        sortOptions.setOrientation(LinearLayout.VERTICAL);
        sortOptions.setPadding(dp(2), 0, dp(2), 0);
        RadioButton[] sortButtons = new RadioButton[4];
        addSortRow(sortOptions, "日付順", "新しい", SORT_DATE_NEW,
                "古い", SORT_DATE_OLD, sortButtons);
        addSortRow(sortOptions, "価格順", "高い", SORT_PRICE_HIGH,
                "安い", SORT_PRICE_LOW, sortButtons);
        sortButtons[sortChoice].setChecked(true);
        // Native RadioGroup does not enforce exclusivity for nested rows.
        // Explicitly manage the four children, keeping them mutually exclusive.
        final int[] draftSort = {sortChoice};
        for (int i = 0; i < sortButtons.length; i++) {
            final int choice = i;
            sortButtons[i].setOnClickListener(v -> {
                draftSort[0] = choice;
                for (int j = 0; j < sortButtons.length; j++)
                    sortButtons[j].setChecked(j == choice);
            });
        }
        box.addView(sortOptions, lp(0, dp(3)));
        LinearLayout buttons=new LinearLayout(host); buttons.setGravity(Gravity.CENTER_VERTICAL);
        TextView close=capsule("閉じる",GRAY,12); TextView clear=capsule("クリア",GRAY,12); TextView apply=capsule("検索",LBLUE,12);
        addAction(buttons,close); addAction(buttons,clear); addAction(buttons,apply); box.addView(buttons,lp(dp(10),0));
        clear.setOnClickListener(v -> {
            // Reset ONLY this dialog's editable draft. Do not dismiss, nor change
            // any search already applied to the pinned criteria panel.
            q.setText("");
            min.setText("");
            max.setText("");
            selected.clear();
            draftSort[0] = SORT_DATE_NEW;
            for (int i = 0; i < sortButtons.length; i++)
                sortButtons[i].setChecked(i == SORT_DATE_NEW);
            for (TextView chip : draftTagViews) {
                chip.setBackground(roundRect(GRAY, 999));
                chip.setContentDescription(chip.getText() + " 未選択");
            }
        });
        apply.setOnClickListener(v -> {
            String word = q.getText().toString();
            Long lower = number(min.getText().toString());
            Long upper = number(max.getText().toString());
            if (lower != null && upper != null && lower > upper) {
                Toast.makeText(host, "最低価格が最高価格を超えています", Toast.LENGTH_SHORT).show();
                return;
            }
            d.dismiss();
            boolean hadFilters = hasFilters();
            selectSort(draftSort[0]);
            applySearch(word, lower, upper, selected);
            if (!hadFilters && word.trim().isEmpty() && lower == null
                    && upper == null && selected.isEmpty()) {
                // applySearch intentionally does not redraw an empty search.
                refreshList();
                listScroll.post(() -> listScroll.scrollTo(0, 0));
            }
        });
        close.setOnClickListener(v -> d.dismiss());
        d.setContentView(box); showDialog(d);
    }

    /** Two vertically aligned choice columns shared by date and price rows. */
    private void addSortRow(RadioGroup group, String title,
            String firstLabel, int firstId, String secondLabel, int secondId,
            RadioButton[] buttons) {
        LinearLayout line = new LinearLayout(host);
        line.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = text(title, 13, TEXT, false);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        line.addView(heading, new LinearLayout.LayoutParams(dp(72), dp(44)));
        RadioButton first = newSortRadio(firstLabel);
        RadioButton second = newSortRadio(secondLabel);
        line.addView(first, new LinearLayout.LayoutParams(0, dp(44), 1f));
        line.addView(second, new LinearLayout.LayoutParams(0, dp(44), 1f));
        group.addView(line, new RadioGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        buttons[firstId] = first;
        buttons[secondId] = second;
    }

    private RadioButton newSortRadio(String label) {
        RadioButton button = new RadioButton(host);
        button.setText(label);
        button.setTextSize(13f);
        button.setTextColor(TEXT);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setIncludeFontPadding(false);
        button.setButtonDrawable(new android.graphics.drawable.InsetDrawable(
                sortRadioDrawable(), 0, 0, dp(10), 0));
        button.setPadding(0, 0, 0, 0);
        return button;
    }

    /** N-style sort choice: grey outer disc; selected-only centered N-white dot. */
    private Drawable sortRadioDrawable() {
        GradientDrawable off = new GradientDrawable();
        off.setShape(GradientDrawable.OVAL);
        off.setColor(GRAY);
        off.setSize(dp(20), dp(20));

        GradientDrawable outer = new GradientDrawable();
        outer.setShape(GradientDrawable.OVAL);
        outer.setColor(GRAY);
        outer.setSize(dp(20), dp(20));
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(WHITE);
        dot.setSize(dp(8), dp(8));
        LayerDrawable checked = new LayerDrawable(new Drawable[]{outer, dot});
        checked.setLayerInset(1, dp(6), dp(6), dp(6), dp(6));
        StateListDrawable selector = new StateListDrawable();
        selector.addState(new int[]{android.R.attr.state_checked}, checked);
        selector.addState(new int[]{}, off);
        return selector;
    }

    /** Don't steal gestures beginning on a list reorder grip or the fast-scroll thumb. */
    public boolean excludesPagingAt(float rawX, float rawY) {
        if (listScroll == null || !listScroll.isShown()) return false;
        int[] location = new int[2];
        listScroll.getLocationOnScreen(location);
        boolean inList = rawY >= location[1] && rawY < location[1] + listScroll.getHeight();
        if (inList && !hasFilters() && rawX >= location[0]
                && rawX < location[0] + dp(36)) return true;
        return gripScroll != null && gripScroll.isThumbTouchAt(rawX, rawY);
    }

    /** Search-only chips: tap the ordinary tag itself to toggle multiple choices. */
    private TextView searchTagChip(WishlistRepository.Tag tag, Set<Long> selected) {
        TextView chip = tagChip(tag.name, false);
        chip.setBackground(roundRect(selected.contains(tag.id) ? LBLUE : GRAY, 999));
        chip.setContentDescription(tag.name + (selected.contains(tag.id) ? " 選択中" : " 未選択"));
        chip.setOnClickListener(v -> {
            if (!selected.add(tag.id)) selected.remove(tag.id);
            chip.setBackground(roundRect(selected.contains(tag.id) ? LBLUE : GRAY, 999));
            chip.setContentDescription(tag.name + (selected.contains(tag.id) ? " 選択中" : " 未選択"));
        });
        return chip;
    }

    /** PriceRec v0.1.81 tag-manager interaction pattern: select, bulk delete,
     * handle drag preview + drop save, long-press rename, in-place updates. */
    private void showTagManager() {
        Dialog dialog = new Dialog(host);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(14));
        body.setBackground(roundRect(LGRAY, 14));
        body.setFocusableInTouchMode(true);
        body.requestFocus();
        body.addView(text("タグ管理", 18, TEXT, true), lp(0, dp(10)));

        ScrollView scroll = new ScrollView(host);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout rows = new LinearLayout(host);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // One tag = a 38dp row + a 4dp bottom margin. Show up to 11.5 tags;
        // the final half row hints that the list can be scrolled.
        int maxRowsHeight = Math.min(dp(42 * 11 + 21),
                Math.max(dp(120), host.getResources().getDisplayMetrics().heightPixels - dp(300)));
        GripScrollFrame tagGripScroll = new GripScrollFrame(host, scroll);
        scroll.setOnScrollChangeListener((v, x, y, oldX, oldY) ->
                tagGripScroll.onContentScrolled());
        body.addView(tagGripScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        LinearLayout create = new LinearLayout(host);
        create.setGravity(Gravity.CENTER_VERTICAL);
        EditText input = input("新しいタグ");
        create.addView(input, new LinearLayout.LayoutParams(0, dp(48), 1f));
        FrameLayout plusSlot = new FrameLayout(host);
        LinearLayout.LayoutParams slotParams = new LinearLayout.LayoutParams(dp(56), dp(48));
        slotParams.leftMargin = dp(8);
        create.addView(plusSlot, slotParams);
        RoundPlusIcon add = new RoundPlusIcon(host, ORANGE, TEXT);
        add.setContentDescription("タグ追加");
        FrameLayout.LayoutParams plusParams = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END | Gravity.CENTER_VERTICAL);
        plusParams.rightMargin = dp(4);
        plusSlot.addView(add, plusParams);
        body.addView(create, lp(dp(10), 0));

        LinearLayout footer = new LinearLayout(host);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView delete = capsule("削除", DGRAY, 13);
        TextView right = capsule("OK", LBLUE, 13);
        footer.addView(delete, new LinearLayout.LayoutParams(dp(118), dp(38)));
        footer.addView(new Space(host), new LinearLayout.LayoutParams(0, dp(38), 1f));
        footer.addView(right, new LinearLayout.LayoutParams(dp(118), dp(38)));
        body.addView(footer, lp(dp(12), 0));

        Set<Long> selectedIds = new HashSet<>();
        final long[] revealTagId = {pendingTagManagerRevealId};
        final int[] renderGeneration = {0};
        pendingTagManagerRevealId = -1L;
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            if (!dialog.isShowing()) return;
            int y = scroll.getScrollY();
            long requestedReveal = revealTagId[0];
            revealTagId[0] = -1L;
            int generation = ++renderGeneration[0];
            rows.removeAllViews();
            List<WishlistRepository.Tag> tags = repo.listTags();
            for (WishlistRepository.Tag tag : tags) {
                boolean selected = selectedIds.contains(tag.id);
                LinearLayout row = new LinearLayout(host);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setTag(tag.id);
                row.setBackground(roundRect(selected ? BLUE : DGRAY, 7));
                row.setElevation(dp(2));
                TextView grip = text("☰", 22, WHITE, false);
                grip.setGravity(Gravity.CENTER);
                grip.setContentDescription(tag.name + "を並べ替え");
                row.addView(grip, new LinearLayout.LayoutParams(dp(40), dp(38)));
                TextView label = text(tag.name, 13, TEXT, selected);
                label.setGravity(Gravity.CENTER_VERTICAL);
                label.setIncludeFontPadding(false);
                row.addView(label, new LinearLayout.LayoutParams(0, dp(38), 1f));
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rowLp.bottomMargin = dp(4);
                rows.addView(row, rowLp);
                row.setOnClickListener(v -> {
                    if (!selectedIds.add(tag.id)) selectedIds.remove(tag.id);
                    render[0].run();
                });
                row.setOnLongClickListener(v -> {
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    showTagRenameDialog(tag, render[0]); // manager remains mounted behind editor
                    return true;
                });
                attachTagReorderGesture(grip, row, rows, tag.id, render[0]);
            }
            ViewGroup.LayoutParams scrollParams = tagGripScroll.getLayoutParams();
            if (scrollParams != null) {
                scrollParams.height = Math.min(maxRowsHeight,
                        Math.max(dp(50), dp(42) * tags.size()));
                tagGripScroll.setLayoutParams(scrollParams);
            }
            if (tags.isEmpty()) {
                TextView placeholder = text("タグがありません", 13, TEXT, false);
                placeholder.setGravity(Gravity.CENTER);
                rows.addView(placeholder, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
            }
            boolean selecting = !selectedIds.isEmpty();
            delete.setEnabled(selecting);
            delete.setAlpha(selecting ? 1f : 0.55f);
            delete.setBackground(roundRect(selecting ? RED : DGRAY, 999));
            right.setText(selecting ? "キャンセル" : "OK");
            right.setBackground(roundRect(selecting ? DGRAY : LBLUE, 999));
            scroll.post(() -> {
                if (generation != renderGeneration[0]) return;
                scroll.scrollTo(0, Math.min(y, Math.max(0, rows.getHeight() - scroll.getHeight())));
                if (requestedReveal > 0L) revealTagRow(scroll, rows, requestedReveal, tagGripScroll);
                else tagGripScroll.onContentScrolled();
            });
        };
        add.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
            if (tagNameExists(name, -1)) { input.setError("同じ名前のタグがあります"); return; }
            WishlistRepository.Tag created = repo.createTag(name);
            if (created == null) { input.setError("追加できませんでした"); return; }
            revealTagId[0] = created.id;
            input.setText("");
            render[0].run();
            refreshList();
        });
        delete.setOnClickListener(v -> {
            if (selectedIds.isEmpty()) return;
            showTagDeleteDialog(selectedIds.size(), () -> {
                List<Long> ids = new ArrayList<>(selectedIds);
                for (Long id : ids) if (id != null) repo.deleteTag(id);
                selectedIds.clear();
                render[0].run();
                onTagsChanged();
            });
        });
        right.setOnClickListener(v -> {
            if (selectedIds.isEmpty()) dialog.dismiss();
            else { selectedIds.clear(); render[0].run(); }
        });
        dialog.setOnDismissListener(v -> onTagsChanged());
        dialog.setContentView(body);
        showDialog(dialog);
        render[0].run();
    }

    /** Identical surface, margins and actions to the Wishlist card delete dialog. */
    /** Scroll only the tag list, after the new row and list bounds are laid out.
     * If the new row is already fully visible, preserve the user's scroll position. */
    private void revealTagRow(ScrollView scroll, LinearLayout rows, long tagId,
                              GripScrollFrame indicator) {
        View row = rows.findViewWithTag(Long.valueOf(tagId));
        if (row == null) return;
        // A post following a rebuild may precede the first layout traversal.
        // Recheck after layout rather than using old child heights.
        if (scroll.getHeight() <= 0 || row.getHeight() <= 0 || rows.isLayoutRequested()) {
            rows.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
                @Override public boolean onPreDraw() {
                    rows.getViewTreeObserver().removeOnPreDrawListener(this);
                    revealTagRow(scroll, rows, tagId, indicator);
                    return true;
                }
            });
            return;
        }
        int visibleTop = scroll.getScrollY();
        int visibleBottom = visibleTop + scroll.getHeight() - scroll.getPaddingBottom();
        int itemTop = rows.getTop() + row.getTop();
        int itemBottom = rows.getTop() + row.getBottom();
        // Include the 4dp row gap so the newly created row isn't clipped.
        if (itemBottom + dp(4) > visibleBottom)
            scroll.scrollTo(0, itemBottom + dp(4) - scroll.getHeight() + scroll.getPaddingBottom());
        else if (itemTop < visibleTop) scroll.scrollTo(0, itemTop);
        if (indicator != null) indicator.onContentScrolled();
    }

    private void showTagDeleteDialog(int count, Runnable onDelete) {
        Dialog dialog = new Dialog(host);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout panel = new LinearLayout(host);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(16), dp(16), dp(16));
        panel.setBackground(roundRect(LGRAY, 14));
        TextView message = text("選択した" + count + "件のタグを削除しますか？\n商品自体は削除されません。",
                15, TEXT, true);
        panel.addView(message, lp(0, dp(16)));
        LinearLayout buttons = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 13);
        TextView delete = capsule("削除", LRED, 13);
        addCardAction(buttons, cancel, false);
        addCardAction(buttons, delete, true);
        panel.addView(buttons, lp(0, 0));
        cancel.setOnClickListener(v -> dialog.dismiss());
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            if (onDelete != null) onDelete.run();
        });
        dialog.setContentView(panel);
        showDialog(dialog);
    }

    private boolean tagNameExists(String name, long excludingId) {
        for (WishlistRepository.Tag tag : repo.listTags())
            if (tag.id != excludingId && tag.name.equalsIgnoreCase(name.trim())) return true;
        return false;
    }

    private void onTagsChanged() {
        // Deleted tags cannot remain active in the applied or draft search.
        boolean wasSearching = hasFilters();
        Set<Long> existing = new HashSet<>();
        for (WishlistRepository.Tag t : repo.listTags()) existing.add(t.id);
        filterTags.retainAll(existing);
        draftFilterTags.retainAll(existing);
        if (wasSearching && !hasFilters()) restoreBeforeSearch();
        else { syncFilterPanel(); refreshList(); }
    }

    /** Child editor dismisses independently. The parent manager never closes. */
    private void showTagRenameDialog(WishlistRepository.Tag tag, Runnable afterEdit) {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(14));
        body.setBackground(roundRect(LGRAY, 14));
        body.setFocusableInTouchMode(true);
        body.requestFocus();
        body.addView(text("タグ名編集", 18, TEXT, true), lp(0, dp(8)));
        EditText name = input("タグ名");
        name.setText(tag.name);
        body.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        LinearLayout footer = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 13);
        TextView save = capsule("保存", LBLUE, 13);
        addAction(footer, cancel);
        addAction(footer, save);
        body.addView(footer, lp(dp(12), 0));
        cancel.setOnClickListener(v -> d.dismiss());
        save.setOnClickListener(v -> {
            String value = name.getText().toString().trim();
            if (value.isEmpty()) { name.setError("タグ名を入力"); return; }
            if (tagNameExists(value, tag.id)) { name.setError("同じ名前のタグがあります"); return; }
            repo.renameTag(tag.id, value);
            d.dismiss();
            if (afterEdit != null) afterEdit.run();
            onTagsChanged();
        });
        d.setContentView(body);
        showDialog(d);
    }

    /** PriceRec-style long-press grip gesture: preview peers, commit only on drop. */
    private void attachTagReorderGesture(TextView handle, View dragged, LinearLayout rows,
                                         long tagId, Runnable refresh) {
        final boolean[] armed = {false};
        final boolean[] moving = {false};
        final float[] downY = {0};
        final int[] from = {-1};
        final int[] target = {-1};
        handle.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downY[0] = event.getRawY();
                    from[0] = rows.indexOfChild(dragged);
                    target[0] = from[0];
                    armed[0] = false;
                    moving[0] = false;
                    return false; // Android handles the long-press on the grip
                case MotionEvent.ACTION_MOVE:
                    if (!armed[0]) return false;
                    float dy = event.getRawY() - downY[0];
                    if (!moving[0] && Math.abs(dy) < dp(6)) return true;
                    moving[0] = true;
                    dragged.setTranslationY(dy);
                    int next = nearestTagIndex(rows, event.getRawY());
                    if (next >= 0 && next != target[0]) {
                        target[0] = next;
                        animateTagReorderPreview(rows, dragged, from[0], next);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (!armed[0]) return false;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    boolean commit = event.getActionMasked() == MotionEvent.ACTION_UP;
                    int destination = target[0];
                    boolean changed = moving[0] && destination >= 0 && destination != from[0];
                    resetTagReorderPreview(rows, dragged);
                    dragged.animate().translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                            .setDuration(145).setInterpolator(new DecelerateInterpolator()).start();
                    dragged.setElevation(dp(2));
                    if (commit && changed) {
                        List<Long> ids = new ArrayList<>();
                        for (WishlistRepository.Tag tag : repo.listTags()) ids.add(tag.id);
                        int old = ids.indexOf(tagId);
                        if (old >= 0) {
                            ids.remove(old);
                            ids.add(Math.max(0, Math.min(destination, ids.size())), tagId);
                            repo.setTagOrder(ids);
                            rows.postDelayed(() -> { if (refresh != null) refresh.run(); }, 155);
                        }
                    }
                    armed[0] = false;
                    moving[0] = false;
                    return true;
                default:
                    return armed[0];
            }
        });
        handle.setOnLongClickListener(v -> {
            armed[0] = true;
            moving[0] = false;
            from[0] = rows.indexOfChild(dragged);
            target[0] = from[0];
            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            dragged.setElevation(dp(12));
            dragged.animate().scaleX(1.025f).scaleY(1.025f).alpha(0.84f).setDuration(85).start();
            return true;
        });
    }

    private int nearestTagIndex(LinearLayout container, float rawY) {
        int[] loc = new int[2];
        container.getLocationOnScreen(loc);
        float y = rawY - loc[1];
        int index = -1;
        float distance = Float.MAX_VALUE;
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            float dy = Math.abs(y - (child.getTop() + child.getHeight() / 2f));
            if (dy < distance) { distance = dy; index = i; }
        }
        return index;
    }

    private void animateTagReorderPreview(LinearLayout container, View dragged, int from, int to) {
        if (from < 0 || to < 0) return;
        int shift = dragged.getHeight() + dp(4);
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child == dragged) continue;
            int offset = 0;
            if (to > from && i > from && i <= to) offset = -shift;
            else if (to < from && i >= to && i < from) offset = shift;
            child.animate().translationY(offset).setDuration(145)
                    .setInterpolator(new DecelerateInterpolator(1.55f)).start();
        }
    }

    private void resetTagReorderPreview(LinearLayout container, View dragged) {
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child != dragged) child.animate().translationY(0f).setDuration(125)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    private void showTagDialog(String itemId) {
        Dialog dialog = new Dialog(host);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(14));
        body.setBackground(roundRect(LGRAY, 14));
        body.setFocusableInTouchMode(true);
        body.requestFocus();
        body.addView(text("タグ選択", 18, TEXT, true), lp(0, dp(10)));
        Set<Long> selected = new HashSet<>(repo.tagsForItem(itemId));
        final long[] revealTagId = {-1L};
        final int[] renderGeneration = {0};
        ScrollView scroll = new ScrollView(host);
        LinearLayout rows = new LinearLayout(host);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows);
        body.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)));
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            int y = scroll.getScrollY();
            long requestedReveal = revealTagId[0];
            revealTagId[0] = -1L;
            int generation = ++renderGeneration[0];
            rows.removeAllViews();
            for (WishlistRepository.Tag tag : repo.listTags()) {
                // Same PriceRec grip/selection/rename actions as the global manager.
                LinearLayout row = new LinearLayout(host);
                row.setTag(tag.id);
                row.setGravity(Gravity.CENTER_VERTICAL);
                boolean active = selected.contains(tag.id);
                row.setBackground(roundRect(active ? BLUE : DGRAY, 7));
                row.setElevation(dp(2));
                TextView grip = text("☰", 22, WHITE, false);
                grip.setGravity(Gravity.CENTER);
                grip.setContentDescription(tag.name + "を並べ替え");
                row.addView(grip, new LinearLayout.LayoutParams(dp(40), dp(38)));
                TextView name = text(tag.name, 13, TEXT, active);
                name.setGravity(Gravity.CENTER_VERTICAL);
                row.addView(name, new LinearLayout.LayoutParams(0, dp(38), 1f));
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
                rowLp.bottomMargin = dp(4);
                rows.addView(row, rowLp);
                row.setOnClickListener(v -> {
                    if (!selected.add(tag.id)) selected.remove(tag.id);
                    render[0].run();
                });
                row.setOnLongClickListener(v -> {
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    showTagRenameDialog(tag, render[0]);
                    return true;
                });
                attachTagReorderGesture(grip, row, rows, tag.id, render[0]);
            }
            scroll.post(() -> {
                if (generation != renderGeneration[0]) return;
                scroll.scrollTo(0, Math.min(y, Math.max(0, rows.getHeight() - scroll.getHeight())));
                if (requestedReveal > 0L) revealTagRow(scroll, rows, requestedReveal, null);
            });
        };
        LinearLayout create = new LinearLayout(host);
        create.setGravity(Gravity.CENTER_VERTICAL);
        EditText input = input("新しいタグ");
        create.addView(input, new LinearLayout.LayoutParams(0, dp(44), 1f));
        FrameLayout slot = new FrameLayout(host);
        LinearLayout.LayoutParams slotLp = new LinearLayout.LayoutParams(dp(52), dp(44));
        slotLp.leftMargin = dp(8);
        create.addView(slot, slotLp);
        RoundPlusIcon add = new RoundPlusIcon(host, ORANGE, TEXT);
        add.setContentDescription("タグ追加");
        slot.addView(add, new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER));
        body.addView(create, lp(dp(8), 0));
        add.setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("タグ名を入力"); return; }
            if (tagNameExists(name, -1)) { input.setError("同じ名前のタグがあります"); return; }
            WishlistRepository.Tag tag = repo.createTag(name);
            if (tag == null) { input.setError("追加できませんでした"); return; }
            selected.add(tag.id);
            revealTagId[0] = tag.id;
            pendingTagManagerRevealId = tag.id;
            input.setText("");
            render[0].run();
        });
        LinearLayout footer = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 13);
        TextView apply = capsule("適用", LBLUE, 13);
        addCardAction(footer, cancel, false);
        addCardAction(footer, apply, true);
        body.addView(footer, lp(dp(12), 0));
        cancel.setOnClickListener(v -> dialog.dismiss());
        apply.setOnClickListener(v -> {
            repo.setTagsForItem(itemId, selected);
            dialog.dismiss();
            onTagsChanged();
        });
        dialog.setContentView(body);
        showDialog(dialog);
        render[0].run();
    }

    private void openProduct(WishlistItem item) {
        if (item.url == null || item.url.isBlank()) return;
        try {
            host.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(item.url)));
        } catch (Exception e) {
            Toast.makeText(host, "商品ページを開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private void showUrlDialog() {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(roundRect(LGRAY, 14));
        box.setFocusableInTouchMode(true);
        box.requestFocus();
        TextView title = text("Wishカード追加", 18, TEXT, true);
        box.addView(title, lp(0, dp(12)));
        EditText url = input("URL");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        final int entryHeight = dp(44);
        box.addView(url, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, entryHeight));
        EditText note = input("備考欄");
        note.setSingleLine(true);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, entryHeight);
        noteParams.topMargin = dp(8);
        box.addView(note, noteParams);
        TextView hint = text("商品名・画像・価格を取得できる範囲で自動入力します", 11, TEXT, false);
        box.addView(hint, lp(dp(8), dp(12)));
        LinearLayout buttons = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 12);
        TextView add = capsule("追加", LBLUE, 12);
        addCardAction(buttons, cancel, false);
        addCardAction(buttons, add, true);
        box.addView(buttons, lp(0, 0));
        cancel.setOnClickListener(v -> d.dismiss());
        add.setOnClickListener(v -> {
            String value = url.getText().toString().trim();
            if (!value.contains("://")) value = "https://" + value;
            Uri parsed = Uri.parse(value);
            if (!("https".equalsIgnoreCase(parsed.getScheme()) || "http".equalsIgnoreCase(parsed.getScheme()))
                    || parsed.getHost() == null || parsed.getHost().isBlank()) {
                url.setError("有効な商品URLを入力してください");
                return;
            }
            WishlistItem item = repo.addUrl(null, value, note.getText().toString().trim());
            if (item == null) {
                Toast.makeText(host, "追加できませんでした", Toast.LENGTH_SHORT).show();
                return;
            }
            d.dismiss();
            expandedIds.add(item.id);
            refreshList();
            refreshOne(item.id);
        });
        d.setContentView(box);
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        showDialog(d);
    }

    private void chooseImage(WishlistItem item) {
        pendingImageItemId = item.id;
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.setType("image/*");
        try {
            host.startActivityForResult(picker, REQUEST_IMAGE_PICK);
        } catch (android.content.ActivityNotFoundException e) {
            pendingImageItemId = null;
            Toast.makeText(host, "画像を選ぶアプリがありません", Toast.LENGTH_SHORT).show();
        }
    }

    /** The selected image is saved into Wishlist's private storage; no URI permission needs to persist. */
    public void onImagePicked(int resultCode, Intent data) {
        final String id = pendingImageItemId;
        pendingImageItemId = null;
        if (id == null || resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return;
        final Uri image = data.getData();
        Toast.makeText(host, "商品画像を保存中…", Toast.LENGTH_SHORT).show();
        io.execute(() -> {
            boolean ok = repo.setManualImage(id, image);
            host.runOnUiThread(() -> {
                if (host.isFinishing() || host.isDestroyed()) return;
                refreshList();
                Toast.makeText(host, ok ? "商品画像を変更しました" : "画像を保存できませんでした",
                        Toast.LENGTH_SHORT).show();
            });
        });
    }

    private void showRenameDialog(WishlistItem item) {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(roundRect(LGRAY, 14));
        box.setFocusableInTouchMode(true);
        box.requestFocus();
        box.addView(text("商品名編集", 18, TEXT, true), lp(0, dp(12)));
        EditText name = input("商品名");
        name.setText(item.title);
        box.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        LinearLayout buttons = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 12);
        TextView save = capsule("保存", LBLUE, 12);
        addAction(buttons, cancel); addAction(buttons, save);
        box.addView(buttons, lp(dp(12), 0));
        cancel.setOnClickListener(v -> d.dismiss());
        save.setOnClickListener(v -> {
            String value = name.getText().toString().trim();
            if (value.isBlank()) { name.setError("商品名を入力してください"); return; }
            repo.rename(item.id, value); // Marks the name as manual: refresh will not overwrite it.
            d.dismiss();
            refreshList();
        });
        d.setContentView(box);
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        showDialog(d);
    }

    /** Label a live update by the route currently being executed (not saved mode). */
    private String liveModeName(WishlistMode mode) {
        if (mode == null) return "未判定モード";
        switch (mode) {
            case AMAZON: return "Amazonモード";
            case RAKUTEN: return "楽天モード";
            case YAHOO: return "Yahoo!モード";
            case UNIQLO: return "UNIQLOモード";
            case YODOBASHI: return "ヨドバシモード";
            case BICCAMERA: return "ビックカメラモード";
            case MUJI: return "無印良品モード";
            case GENERAL: return "GENERALモード";
            default: return "未判定モード";
        }
    }

    private String stockModeName(String url, WishlistMode savedMode) {
        if (savedMode != WishlistMode.GENERAL) return liveModeName(savedMode);
        try {
            com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode dedicated =
                    com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode.forUrl(
                            new java.net.URL(url));
            if (dedicated != com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode.NONE)
                return dedicated.name() + "固有モード";
        } catch (Exception ignored) { }
        return "GENERALモード";
    }

    private TextView liveModeChip() {
        // Only N-white text: no rounded rectangle, fill or decorative padding.
        TextView chip = text("", 11, WHITE, false);
        chip.setBackground(null);
        chip.setPadding(0, 0, 0, 0);
        chip.setIncludeFontPadding(false);
        chip.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        chip.setSingleLine(true);
        chip.setEllipsize(android.text.TextUtils.TruncateAt.END);
        chip.setVisibility(View.GONE);
        return chip;
    }

    private LinearLayout.LayoutParams liveModeChipParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(15));
        lp.topMargin = dp(3);
        return lp;
    }

    private int liveModeColumnHeight(boolean expanded) {
        // Collapsed 80dp and expanded 140dp match the thumbnail exactly,
        // regardless of mode length and whether an update is running.
        return dp(expanded ? 140 : 80);
    }

    private static void showLiveModeChip(TextView chip, String label, boolean locationMatches) {
        if (!locationMatches) {
            // Only the label at the inactive expanded/collapsed position is GONE.
            chip.setVisibility(View.GONE);
            return;
        }
        boolean show = label != null && !label.isEmpty();
        if (show && !label.contentEquals(chip.getText())) chip.setText(label);
        // The active-position label always occupies its 18dp row, even at rest.
        chip.setVisibility(show ? View.VISIBLE : View.INVISIBLE);
    }

    private void applyLiveModeToVisibleCard(String id) {
        View card = findCard(id);
        if (!(card instanceof LinearLayout) || ((LinearLayout) card).getChildCount() == 0) return;
        View head = ((LinearLayout) card).getChildAt(0);
        if (!(head.getTag() instanceof CardHeader)) return;
        CardHeader header = (CardHeader) head.getTag();
        boolean expanded = expandedIds.contains(id);
        String label = updatingItems.contains(id) ? runningModes.get(id) : null;
        showLiveModeChip(header.updateModeCollapsed, label, !expanded);
        showLiveModeChip(header.updateModeExpanded, label, expanded);
        ViewGroup rightColumn = (ViewGroup) header.note.getParent();
        ViewGroup.LayoutParams lp = rightColumn.getLayoutParams();
        int height = liveModeColumnHeight(expanded);
        if (lp.height != height) {
            lp.height = height;
            rightColumn.setLayoutParams(lp);
        }
    }

    /** Must run on the UI thread. Late callbacks cannot resurrect a finished label. */
    private void switchRunningMode(String id, String label) {
        if (!updatingItems.contains(id)) return;
        if (label == null || label.isEmpty()) return;
        if (label.equals(runningModes.get(id))) return;
        runningModes.put(id, label);
        applyLiveModeToVisibleCard(id);
    }

    private void beginUpdate(String id) {
        int count = updateTasks.getOrDefault(id, 0);
        updateTasks.put(id, count + 1);
        updatingItems.add(id);
        ProgressBar wheel = imageSpinners.get(id);
        if (wheel != null) wheel.setVisibility(View.VISIBLE);
    }

    private void finishUpdate(String id) {
        int count = updateTasks.getOrDefault(id, 0);
        if (count > 1) { updateTasks.put(id, count - 1); return; }
        if (count == 0) return; // A canceled/late callback cannot advance a batch twice.
        updateTasks.remove(id);
        updatingItems.remove(id);
        runningModes.remove(id); // Success, failure and timeout ALL remove the label.
        applyLiveModeToVisibleCard(id);
        ProgressBar wheel = imageSpinners.get(id);
        if (wheel != null) wheel.setVisibility(View.GONE);
        // The same async pipeline closes manual and pull-to-refresh alike.
        // Completion is on the UI thread, after ALL its nested probe tasks.
        Runnable completion = refreshCompletion.remove(id);
        if (completion != null) completion.run();
    }

    private void showPullHeader(String title) {
        if (pullRefreshHeader == null) return;
        pullRefreshHeader.setVisibility(View.VISIBLE);
        pullRefreshLabel.setText(title);
        pullRefreshHeader.bringToFront();
    }

    private void hidePullHeaderIfIdle() {
        if (!batchRefreshing && pullRefreshHeader != null) {
            pullRefreshHeader.setVisibility(View.GONE);
            if(listScroll instanceof PullRefreshScrollView)
                ((PullRefreshScrollView)listScroll).animatePullOffset(0);
        }
    }

    /** Real 150dp pull displacement, independent of the horizontal page gesture. */
    private final class PullRefreshScrollView extends ScrollView {
        private float downX, downY;
        private boolean eligible, dragging, childCanceled;
        PullRefreshScrollView(Activity context) { super(context); }
        private void cancelChild(MotionEvent event){
            if(childCanceled)return;
            MotionEvent canceled=MotionEvent.obtain(event);
            canceled.setAction(MotionEvent.ACTION_CANCEL);
            super.dispatchTouchEvent(canceled);
            canceled.recycle();
            childCanceled=true;
        }
        private float displacement(float motion){
            return Math.min(dp(150),Math.max(0f,motion*0.85f));
        }
        @Override public boolean dispatchTouchEvent(MotionEvent event) {
            switch(event.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    downX=event.getRawX();downY=event.getRawY();dragging=false;childCanceled=false;
                    // A searched list can also be pulled; update only its rendered members.
                    eligible=getScrollY()==0&&!batchRefreshing&&!listBoxHasNoCards()
                            &&event.getX()>dp(45)&&event.getX()<getWidth()-dp(34);
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    eligible=false;
                    if(dragging){dragging=false;animatePullOffset(0);hidePullHeaderIfIdle();return true;}
                    break;
                case MotionEvent.ACTION_MOVE:
                    if(eligible){
                        float dy=event.getRawY()-downY,dx=Math.abs(event.getRawX()-downX);
                        if(!dragging&&dy>dp(14)&&dy>dx*1.3f&&getScrollY()==0){
                            dragging=true;cancelChild(event);
                        }
                        if(dragging){
                            float offset=displacement(dy);
                            animate().cancel();setTranslationY(offset);
                            showPullHeader(offset>=dp(125)?(hasFilters()?"離すと検索結果を更新":"離すと全件更新")
                                    :(hasFilters()?"下へ引いて検索結果を更新":"下へ引いて全件更新"));
                            return true;
                        }
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    if(dragging){
                        boolean trigger=eligible&&getScrollY()==0
                                &&displacement(event.getRawY()-downY)>=dp(125);
                        eligible=false;dragging=false;
                        animatePullOffset(trigger?dp(58):0);
                        if(trigger)refreshAllNow(null);
                        else hidePullHeaderIfIdle();
                        return true;
                    }
                    eligible=false;break;
                case MotionEvent.ACTION_CANCEL:
                    if(dragging){dragging=false;eligible=false;animatePullOffset(0);hidePullHeaderIfIdle();return true;}
                    eligible=false;break;
            }
            return super.dispatchTouchEvent(event);
        }
        void animatePullOffset(float y){
            animate().translationY(y).setDuration(260)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator(1.7f)).start();
        }
    }

    private void refreshOne(String id) {
        if (batchRefreshing || !updatingItems.isEmpty()) {
            Toast.makeText(host, "情報更新が完了してから操作してください", Toast.LENGTH_SHORT).show();
            return;
        }
        refreshItem(id, false, null);
    }

    /** Shared EXACT per-card refresh pipeline for manual and pull-to-refresh.
     * A pull batch only selects and serializes IDs, never changes how any
     * product is fetched, saved, or verified. */
    private void refreshItem(String id, boolean batch, Runnable completion) {
        if (host.isFinishing() || host.isDestroyed()) {
            if (completion != null) completion.run();
            return;
        }
        if (completion != null) refreshCompletion.put(id, completion);
        beginUpdate(id);
        WishlistItem initial = repo.get(id);
        switchRunningMode(id, liveModeName(initial == null ? WishlistMode.UNRESOLVED
                : initial.acquisitionMode));
        // Do not erase the prior batch's evidence when a manual retry succeeds.
        // Per-card logs remain bounded by WishlistCardDiagnostics.MAX_BYTES.
        WishlistCardDiagnostics.event(host, id,
                batch ? "refresh.batch.start" : "refresh.manual.start", "user-triggered shared-pipeline");
        if (!batch) Toast.makeText(host, "更新中…", Toast.LENGTH_SHORT).show();
        // HTML is downloaded once, then image and price are persisted through isolated paths.
        // The proven price WebView behavior runs unchanged when needed, independently of images.
        io.execute(() -> {
            WishlistItem before = repo.get(id);
            if (before == null) { host.runOnUiThread(() -> finishUpdate(id)); return; }
            RetailDiagnostics.event(before.acquisitionMode,
                    batch ? "refresh.batch.start" : "refresh.manual.start",
                    "item="+id.substring(0,Math.min(id.length(),8))+" shared=true");
            try { RetailDiagnostics.general(new java.net.URL(before.url),
                    batch ? "refresh.batch.start" : "refresh.manual.start", "mode=GENERAL"); }
            catch (Exception ignored) { }
            if (before.acquisitionMode == WishlistMode.MUJI) {
                host.runOnUiThread(() -> refreshMujiItem(id, before));
                return;
            }
            // Evidence from 0.1.106: direct HTTP timed out before headers on both
            // electronics sites, but WebView loaded their product DOM in 3-6 s.
            // Manual refresh goes directly to identity-checked WebView instead.
            if (before.acquisitionMode==WishlistMode.YODOBASHI
                    || before.acquisitionMode==WishlistMode.BICCAMERA) {
                boolean ready=repo.beginRenderedRetailOnly(id,before.url,before.acquisitionMode);
                host.runOnUiThread(()->{
                    if (host.isFinishing()||host.isDestroyed()||!ready){finishUpdate(id);return;}
                    refreshList();
                    recoverLargeRetail(id,before.url,before.url,before.acquisitionMode,
                            WishlistSiteState.TEMPORARY_ERROR);
                    finishUpdate(id);
                });
                return;
            }
            WishlistCrawler.Result r;
            try {
                r = WishlistCrawler.fetch(before);
                repo.updateCrawl(id, r, isLargeRetailMode(before.acquisitionMode));
            } catch (RuntimeException error) {
                android.util.Log.w("Wishlist", "Manual refresh failed", error);
                RetailDiagnostics.event(before.acquisitionMode,
                        batch ? "refresh.batch.error" : "refresh.manual.error",
                        "type="+RetailDiagnostics.error(error));
                WishlistCardDiagnostics.event(host,id,
                        batch ? "refresh.batch.error" : "refresh.manual.error",
                        "type="+error.getClass().getSimpleName());
                host.runOnUiThread(() -> finishUpdate(id));
                return;
            }
            // GENERAL marketplace cards must keep the SAVED item identity through
            // HTTP -> price -> stock -> image. HTTP 200 on a same-host landing
            // page is NOT evidence that the requested item survived a redirect.
            // Retain the original item URL for independent WebView retries; each
            // probe separately rejects navigation to a different product ID.
            boolean marketplaceSavedItem = false;
            boolean marketplaceResolvedSameItem = false;
            try {
                java.net.URL savedItemUrl = new java.net.URL(before.url);
                marketplaceSavedItem = before.acquisitionMode == WishlistMode.GENERAL
                        && com.cmyk.bookmarkslauncher.wishlist.WishlistGeneralMarketplaceIdentity
                            .isDetail(savedItemUrl);
                marketplaceResolvedSameItem = marketplaceSavedItem && r.resolvedUrl != null
                        && com.cmyk.bookmarkslauncher.wishlist.WishlistGeneralMarketplaceIdentity
                            .sameItem(savedItemUrl, new java.net.URL(r.resolvedUrl));
            } catch (Exception ignored) { }
            final String pageUrl = marketplaceSavedItem
                    ? com.cmyk.bookmarkslauncher.wishlist.WishlistGeneralMarketplaceIdentity
                        .preservedProbeUrl(before.url, r.resolvedUrl)
                    : r.resolvedUrl == null ? before.url : r.resolvedUrl;
            if (marketplaceSavedItem) WishlistCardDiagnostics.event(host, id,
                    "general.market.route", "savedItem=true resolvedSameItem="
                    + marketplaceResolvedSameItem + " probeSavedItem=true http=" + r.httpCode
                    + " result=" + (r.failureReason == null ? "none" : "failed"));
            host.runOnUiThread(() -> {
                if (host.isFinishing() || host.isDestroyed()) { finishUpdate(id); return; }
                refreshList();
                // Giant-EC cards are never sent into the generic WebView/price
                // pipeline, including when HTTP returned 403. The hidden renderer
                // can still try the exact requested item and preserve existing data.
                if (isLargeRetailMode(before.acquisitionMode)) {
                    recoverLargeRetail(id, before.url, pageUrl, before.acquisitionMode, r.siteState);
                    finishUpdate(id);
                    return;
                }
                if (r.success && (r.title==null||r.title.isBlank()) && !before.userTitleEdited
                        && repo.get(id) != null && repo.get(id).acquisitionMode == WishlistMode.AMAZON
                        && WishlistImageWebViewProbe.isAmazonUrl(pageUrl))
                    recoverAmazonName(id, before.url, pageUrl);
                try {
                // Stock is probed independently of price/image ONLY on a manual
                // update. The raw HTML must have succeeded and identified an
                // individual item; don't probe keyword-selected multi-item pages.
                // ASKUL/MonotaRO: HTTP 403 + two detached WebViews running
                // simultaneously starved the exact-SKU price probe on device.
                // If price still needs DOM recovery, run price FIRST and queue
                // this SKU's stock probe afterwards (never in parallel).
                // Price WebView and stock WebView must not compete to render
                // a GENERAL single-product page (MUJI/NITORI/CAINZ included).
                // Keep the two results independent and preserve prior values.
                // Edion often refuses the preliminary HTTP call with 403 and
                // its separate price WebView either times out or receives 503.
                // One rendered item-bound stock WebView now captures BOTH
                // title and exact gross price before it is destroyed. Avoid
                // the redundant first WebView request only on that strict URL.
                boolean isolatedRenderedFirst=false;
                try {
                    com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode route=
                        com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode
                          .forUrl(new java.net.URL(before.url));
                    isolatedRenderedFirst=before.acquisitionMode==WishlistMode.GENERAL
                        && (route==com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode.EDION
                            || route==com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode.ISETAN)
                        && r.price==null && r.priceQuote==null && !r.noteTargetMatched
                        && !WishlistSiteState.PAGE_MISSING.equals(r.siteState)
                        && !WishlistSiteState.MAINTENANCE.equals(r.siteState);
                } catch(Exception ignored) { }
                if (isolatedRenderedFirst) {
                    WishlistCardDiagnostics.event(host,id,"merchant.metadata.route",
                            "single-rendered-item-first=true skip-duplicate-price-webview=true");
                    recoverUnknownAvailability(id,before.url,before.url,()->{
                        recoverMissingProductImage(id,before.url,false);
                        finishUpdate(id);
                    });
                    return;
                }
                final boolean serialGeneralPrice = before.acquisitionMode == WishlistMode.GENERAL
                        && (isVerifiedSingleProductUrl(pageUrl)
                            || isAlphabetCandidate(pageUrl)
                            || isKnownGeneralRetail(before.url)
                            || isIndependentPriceRecoveryUrl(before.url)
                            || isUnknownJsonLdCandidate(before.url))
                        && r.price == null && r.priceQuote == null && !r.noteTargetMatched
                        && !WishlistSiteState.PAGE_MISSING.equals(r.siteState)
                        && !WishlistSiteState.MAINTENANCE.equals(r.siteState);
                // Honma's image and stock share a small hosted storefront.
                // Do not launch competing detached WebViews when HTTP already
                // supplied the exact gross price: stock then image, in order.
                boolean honmaItem = false;
                try { honmaItem = before.acquisitionMode == WishlistMode.GENERAL
                        && com.cmyk.bookmarkslauncher.wishlist.WishlistHonmaProductDom
                           .isDetail(new java.net.URL(before.url)); }
                catch (Exception ignored) { }
                if (!honmaItem && !serialGeneralPrice && ((r.success && "UNKNOWN".equals(r.status))
                        || (before.acquisitionMode == WishlistMode.GENERAL
                        && isKnownGeneralRetail(before.url) && !r.success
                        && !WishlistSiteState.PAGE_MISSING.equals(r.siteState)
                        && !WishlistSiteState.MAINTENANCE.equals(r.siteState)))
                        && !r.noteTargetMatched)
                    recoverUnknownAvailability(id, before.url, pageUrl);
                if (WishlistSiteState.MAINTENANCE.equals(r.siteState)
                        || WishlistSiteState.PAGE_MISSING.equals(r.siteState)) {
                    if (!batch) Toast.makeText(host, WishlistSiteState.label(r.siteState), Toast.LENGTH_SHORT).show();
                    return; // A maintenance/404 page must never replace saved product data.
                }
                if (r.price != null || r.priceQuote != null || r.noteTargetMatched) {
                    // Never let a generic price WebView overwrite a missing
                    // keyword-scoped price with a price from another product.
                    if (r.noteTargetMatched && r.price == null)
                        if (!batch) Toast.makeText(host, "備考欄の商品価格は特定できませんでした", Toast.LENGTH_SHORT).show();
                    if (honmaItem && !r.noteTargetMatched) {
                        recoverUnknownAvailability(id, before.url, pageUrl, () -> {
                            recoverMissingProductImage(id, pageUrl, false);
                            finishUpdate(id);
                        });
                    } else recoverMissingProductImage(id, pageUrl, r.noteTargetMatched);
                    return;
                }
                if (priceProbe != null) priceProbe.cancel();
                final WishlistPriceWebViewProbe thisPriceProbe = new WishlistPriceWebViewProbe(root);
                priceProbe = thisPriceProbe;
                if (serialGeneralPrice) {
                    priceProbe.setTrace((stage, evidence) ->
                            WishlistCardDiagnostics.event(host, id, "price.webview."+stage, evidence));
                    WishlistCardDiagnostics.event(host,id,"price.webview.start",
                            "skuBound=true stockDeferred=true");
                }
                beginUpdate(id);
                switchRunningMode(id, liveModeName(repo.get(id).acquisitionMode));
                if (!batch) Toast.makeText(host, "WebViewで価格を補完中…", Toast.LENGTH_SHORT).show();
                thisPriceProbe.start(pageUrl, repo.get(id).acquisitionMode, (price, quote, failure) -> {
                    if (host.isFinishing() || host.isDestroyed()) { finishUpdate(id); return; }
                    io.execute(() -> {
                        try { RetailDiagnostics.general(new java.net.URL(pageUrl), "price.webview",
                                "price="+(price!=null)+" quote="+(quote!=null)+" error="+(failure!=null)); }
                        catch (Exception ignored) { }
                        WishlistCardDiagnostics.event(host,id,"price.webview.result",
                                "exact="+price+" quote="+(quote!=null)+" error="+(failure==null?"none":failure));
                        if (quote != null) repo.updatePriceQuoteFromWebView(id, quote);
                        else repo.updatePriceFromWebView(id, price, failure);
                        if (quote != null || price != null) repo.recordSiteReachableFromWebView(id);
                        // ASKUL product names used to be reachable only from the
                        // later stock WebView, which is intentionally skipped after
                        // successful price+stock. Save a name from the SAME exact
                        // price WebView before the early finish; repository protects
                        // manually edited names and rechecks URL/acquisition mode.
                        final String marketName=thisPriceProbe.verifiedMarketplaceTitle();
                        if (serialGeneralPrice && marketName!=null) {
                            boolean accepted=repo.updateVerifiedMarketplaceTitle(id,before.url,marketName);
                            WishlistCardDiagnostics.event(host,id,"product.name.commit",
                                    "saved="+accepted+" source=marketplace-price-webview");
                        }
                        final String priceDomName=thisPriceProbe.verifiedAskulTitle();
                        if (serialGeneralPrice && priceDomName!=null) {
                            boolean saved=repo.updateVerifiedRetailTitle(id,before.url,priceDomName);
                            WishlistCardDiagnostics.event(host,id,"product.name.commit",
                                    "saved="+saved+" source=askul-price-webview");
                        }
                        // ASKUL: evaluate the SAME identity-checked DOM that yielded its
                        // verified price before creating another detached WebView.  A
                        // missing control never counts as a positive stock signal.
                        final String priceDomStock = thisPriceProbe.askulStockStatus();
                        if (serialGeneralPrice && ("AVAILABLE".equals(priceDomStock)
                                || "UNAVAILABLE".equals(priceDomStock))) {
                            repo.markVerifiedStockFromWebView(id, before.url, priceDomStock);
                            WishlistCardDiagnostics.event(host,id,"stock.priceWebview.commit",
                                    "status=" + priceDomStock + " sameSku=true");
                        }
                        host.runOnUiThread(() -> {
                            if (host.isFinishing() || host.isDestroyed()) { finishUpdate(id); return; }
                            refreshList();
                            if (!batch) Toast.makeText(host, quote != null ? "最低価格・価格範囲を取得しました" : price == null ?
                                    (failure == null ? "価格は取得できませんでした" : failure) :
                                    "価格を取得しました", Toast.LENGTH_SHORT).show();
                            if (serialGeneralPrice) {
                                // Once the price DOM has supplied verified stock for the
                                // SAME card, do not overwrite it using a second WebView.
                                if ("AVAILABLE".equals(priceDomStock) || "UNAVAILABLE".equals(priceDomStock)) {
                                    recoverMissingProductImage(id, pageUrl, r.noteTargetMatched);
                                    finishUpdate(id);
                                } else {
                                    recoverUnknownAvailability(id, before.url, pageUrl, () -> {
                                        recoverMissingProductImage(id,pageUrl,r.noteTargetMatched);
                                        finishUpdate(id);
                                    });
                                }
                            } else {
                                // HTTP TIMEOUT and 403 are transport outcomes, not
                                // evidence that a product's DOM or stock is absent.
                                // A failed price fetch must not suppress read-only
                                // stock inspection on a VERIFIED product-looking URL.
                                // Listings/search results still cannot enter this path.
                                boolean timeoutStockRecovery = before.acquisitionMode == WishlistMode.GENERAL
                                        && (WishlistSiteState.TIMEOUT.equals(r.siteState)
                                            || WishlistSiteState.ACCESS_RESTRICTED.equals(r.siteState))
                                        && !r.noteTargetMatched
                                        && (isVerifiedSingleProductUrl(pageUrl)
                                            || isAlphabetCandidate(pageUrl));
                                if (timeoutStockRecovery) {
                                    WishlistCardDiagnostics.event(host,id,"transport.webview.recovery",
                                            "httpState="+r.siteState+" price="+(price!=null)
                                            +" stock=independent probe=single-item");
                                    recoverUnknownAvailability(id, before.url, pageUrl, () -> {
                                        recoverMissingProductImage(id, pageUrl, r.noteTargetMatched);
                                        finishUpdate(id);
                                    });
                                } else {
                                    if (WishlistSiteState.TIMEOUT.equals(r.siteState)
                                            || WishlistSiteState.ACCESS_RESTRICTED.equals(r.siteState))
                                        WishlistCardDiagnostics.event(host,id,"transport.webview.recovery",
                                                "httpState="+r.siteState+" price="+(price!=null)
                                                +" productUrl="+isVerifiedSingleProductUrl(pageUrl)
                                                +" candidate="+isAlphabetCandidate(pageUrl)+" stock=skipped");
                                    recoverMissingProductImage(id, pageUrl, r.noteTargetMatched);
                                    finishUpdate(id);
                                }
                            }
                        });
                    });
                });
                } finally { finishUpdate(id); }
            });
        });
    }

    /** Only known individual-product GENERAL shops get extra rendered price probes.
     * Never upgrade GENERAL to a dedicated mode or scrape a search/list page. */
    private static boolean isIndependentPriceRecoveryUrl(String rawUrl) {
        if (rawUrl == null) return false;
        try {
            java.net.URL url = new java.net.URL(rawUrl);
            if (!"https".equalsIgnoreCase(url.getProtocol())) return false;
            String hostName = url.getHost().toLowerCase(java.util.Locale.ROOT);
            String path = url.getPath();
            return ("eshop.fumuroya.com".equals(hostName)
                    && path.matches("/product/detail/[0-9]+/?"))
                    || (("www.gojochoubei.co.jp".equals(hostName)
                    || "gojochoubei.co.jp".equals(hostName))
                    && path.matches("/view/item/[0-9]{12}/?"));
        } catch (Exception ignored) { return false; }
    }

    private static boolean isLargeRetailMode(WishlistMode m) {
        return m==WishlistMode.UNIQLO||m==WishlistMode.YODOBASHI||m==WishlistMode.BICCAMERA;
    }
    /** Dedicated retail DOM extraction, with no GENERAL fallback. */
    private void recoverLargeRetail(String id, String savedUrl, String pageUrl,
                                    WishlistMode mode, String httpState) {
        if (!isLargeRetailMode(mode)) return;
        if (largeRetailProbe != null) largeRetailProbe.cancel();
        final LargeRetailWebViewProbe probe=new LargeRetailWebViewProbe(root);
        probe.setTrace((phase, evidence) -> WishlistCardDiagnostics.event(
                host, id, "retail.webview." + phase, evidence));
        largeRetailProbe=probe;
        beginUpdate(id);
        RetailDiagnostics.event(mode,"refresh.probe.start","host="+RetailDiagnostics.host(savedUrl)+" httpState="+httpState);
        probe.start(mode == WishlistMode.UNIQLO ? savedUrl : pageUrl,mode,result->{
            if(host.isFinishing()||host.isDestroyed()){finishUpdate(id);return;}
            io.execute(()->{
                WishlistItem current=repo.get(id);
                if(current!=null && savedUrl.equals(current.url) && current.acquisitionMode==mode){
                    boolean accepted=result!=null
                            && repo.updateLargeRetailRenderedFields(id,savedUrl,result);
                    String finalHttpState = !accepted && probe.mainFrameFailureState()!=null
                            ? probe.mainFrameFailureState() : httpState;
                    repo.finishLargeRetailProbe(id,savedUrl,mode,finalHttpState,accepted);
                    RetailDiagnostics.event(mode,"refresh.probe.saved","accepted="+accepted+" site="+finalHttpState);
                }
                android.util.Log.i("RetailGiant","Final site state mode="+mode
                        +" rendered="+(result!=null)+" httpState="+httpState);
                host.runOnUiThread(()->{
                    if(!host.isFinishing()&&!host.isDestroyed())refreshList();
                    finishUpdate(id);
                });
            });
        });
    }

    /** Amazon name-only recovery; independent of the image, price and stock probes. */
    private void recoverAmazonName(String id, String expectedUrl, String pageUrl) {
        AmazonNameWebViewProbe probe=new AmazonNameWebViewProbe(root);
        beginUpdate(id);
        probe.start(pageUrl,title->{
            if(title==null||host.isFinishing()||host.isDestroyed()){
                finishUpdate(id);return;
            }
            io.execute(()->{
                repo.updateAmazonTitleFromWebView(id,expectedUrl,title);
                host.runOnUiThread(()->{
                    if(!host.isFinishing()&&!host.isDestroyed())refreshList();
                    finishUpdate(id);
                });
            });
        });
    }

    /** Optional, bounded stock-only DOM recovery after a user-initiated refresh.
     * Never runs on the background scheduler and never edits other metadata. */
    private boolean isKnownGeneralRetail(String url) {
        try { return com.cmyk.bookmarkslauncher.wishlist.GeneralRetailIdentity.store(
                new java.net.URL(url)) != null; }
        catch (Exception ignored) { return false; }
    }

    /** MUJI-only manual/batch path. The HTTP crawler regularly times out while
     * the identity-checked rendered document supplies the price in seconds.
     * Price, stock and image remain independent; no purchase action is clicked.
     * The original GENERAL alphabet pipeline and all successful shops are intact. */
    private void refreshMujiItem(String id, WishlistItem before) {
        if (host.isFinishing() || host.isDestroyed()) { finishUpdate(id); return; }
        if (before == null || before.acquisitionMode != WishlistMode.MUJI
                || WishlistMode.forDirectUrl(before.url) != WishlistMode.MUJI) {
            finishUpdate(id); return;
        }
        if (priceProbe != null) priceProbe.cancel();
        final WishlistPriceWebViewProbe probe = new WishlistPriceWebViewProbe(root);
        priceProbe = probe;
        probe.setTrace((stage, ev) -> WishlistCardDiagnostics.event(host,id,"muji.price."+stage,ev));
        beginUpdate(id);
        WishlistCardDiagnostics.event(host,id,"muji.refresh.start","mode=MUJI path=rendered-price-first");
        probe.start(before.url, WishlistMode.MUJI, (price, quote, failure) -> {
            WishlistCardDiagnostics.event(host,id,"muji.price.result",
                    "exact="+price+" quote="+(quote!=null)+" error="+(failure==null?"none":failure));
            io.execute(() -> {
                WishlistItem current = repo.get(id);
                if (current != null && current.acquisitionMode == WishlistMode.MUJI
                        && before.url.equals(current.url)) {
                    if (quote != null) repo.updatePriceQuoteFromWebView(id, quote);
                    else repo.updatePriceFromWebView(id, price, failure);
                    if (quote != null || price != null) repo.recordSiteReachableFromWebView(id);
                }
                host.runOnUiThread(() -> {
                    finishUpdate(id); // price probe
                    if (host.isFinishing() || host.isDestroyed()) { finishUpdate(id); return; }
                    refreshList();
                    // Never gate stock inspection on a successful price fetch.
                    recoverUnknownAvailability(id, before.url, before.url, () -> {
                        recoverMissingProductImage(id, before.url, false);
                        finishUpdate(id); // original refresh
                    });
                });
            });
        });
    }

    private void recoverUnknownAvailability(String id, String expectedUrl, String pageUrl) {
        recoverUnknownAvailability(id,expectedUrl,pageUrl,null);
    }

    private void recoverUnknownAvailability(String id, String expectedUrl, String pageUrl,
                                            Runnable after) {
        if (pageUrl == null) { if(after!=null)after.run();return; }
        if (availabilityProbe != null) availabilityProbe.cancel();
        availabilityProbe = new WishlistAvailabilityWebViewProbe(root);
        // Card-scoped stock + raw DOM audit for every GENERAL product.
        // The same stock probe also writes bounded summaries to the app-wide log.
        WishlistItem auditItem = repo.get(id);
        if (auditItem != null && (auditItem.acquisitionMode == WishlistMode.GENERAL
                || auditItem.acquisitionMode == WishlistMode.MUJI)) {
            availabilityProbe.setTrace((stage, evidence) ->
                    WishlistCardDiagnostics.event(host,id,"stock.webview."+stage,evidence));
        }
        beginUpdate(id);
        // The stock probe always runs one GENERAL A-G pass first.
        switchRunningMode(id, "GENERAL A");
        String merchantMode="NONE";
        try { merchantMode=com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode
                .forUrl(new java.net.URL(pageUrl)).name(); } catch (Exception ignored) { }
        WishlistCardDiagnostics.event(host,id,"stock.webview.start",
                "probe dedicated="+merchantMode);
        final WishlistAvailabilityWebViewProbe thisStockProbe=availabilityProbe;
        thisStockProbe.setModeProgress(label -> switchRunningMode(id,label));
        thisStockProbe.start(pageUrl, repo.get(id).acquisitionMode, status -> {
            // Metadata fields are independent of stock. One verified, saved-item
            // renderer can repair EDION's 403 price without downgrading any
            // existing Joshin / MUJI / ASKUL successful price and name.
            final String verifiedName=thisStockProbe.verifiedProductTitle();
            final Long verifiedPrice=thisStockProbe.verifiedProductPrice();
            WishlistCardDiagnostics.event(host,id,"stock.webview.result","status="+status
                    +" verifiedName="+(verifiedName!=null)+" verifiedPrice="+(verifiedPrice!=null));
            boolean statusVerified="AVAILABLE".equals(status)||"UNAVAILABLE".equals(status);
            if ((!statusVerified && verifiedName==null && verifiedPrice==null)
                    || host.isFinishing() || host.isDestroyed()) {
                finishUpdate(id);
                if (after != null && !host.isFinishing() && !host.isDestroyed()) after.run();
                return;
            }
            io.execute(() -> {
                WishlistItem latest=repo.get(id);
                boolean sameCard=latest!=null && expectedUrl.equals(latest.url)
                        && (latest.acquisitionMode==WishlistMode.GENERAL
                            || latest.acquisitionMode==WishlistMode.MUJI);
                if (sameCard && verifiedName!=null) {
                    boolean saved=repo.updateVerifiedRetailTitle(id,expectedUrl,verifiedName);
                    WishlistCardDiagnostics.event(host,id,"product.name.commit",
                            "saved="+saved+" source=verified-rendered-item");
                }
                if (sameCard && verifiedPrice!=null && latest.acquisitionMode==WishlistMode.GENERAL) {
                    boolean supported=false;
                    try { supported=com.cmyk.bookmarkslauncher.wishlist.WishlistRetailVerifiedMetadataDom
                        .supports(new java.net.URL(expectedUrl)); }catch(Exception ignored) { }
                    if (supported) {
                        // The original URL and acquisition mode are checked
                        // immediately before committing this field alone.
                        repo.updatePriceFromWebView(id,verifiedPrice,null);
                        repo.recordSiteReachableFromWebView(id);
                        WishlistCardDiagnostics.event(host,id,"price.merchant.commit",
                                "verified=true gross=true price="+verifiedPrice);
                    }
                }
                if (statusVerified && sameCard) {
                    // The *dedicated* site's item-bound purchase evidence may
                    // recover from a transport-only HTTP 403. UNKNOWN never does.
                    try {
                        if ("AVAILABLE".equals(status) && latest.acquisitionMode==WishlistMode.GENERAL
                                && com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode
                                  .forUrl(new java.net.URL(expectedUrl))
                                != com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode.NONE)
                            repo.recordSiteReachableFromWebView(id);
                    }catch(Exception ignored) { }
                    repo.markVerifiedStockFromWebView(id,expectedUrl,status);
                }
                host.runOnUiThread(() -> {
                    if (!host.isFinishing() && !host.isDestroyed()) refreshList();
                    finishUpdate(id);
                    if (after != null && !host.isFinishing() && !host.isDestroyed()) after.run();
                });
            });
        });
    }

    private static boolean isAlphabetCandidate(String raw) {
        try { return com.cmyk.bookmarkslauncher.wishlist.WishlistGeneralAlphabetDom
                .candidateUrl(new java.net.URL(raw)); }
        catch (Exception ignored) { return false; }
    }

    /** URL structure only; never uses page text or a guessed product identity. */
    private static boolean isUnknownJsonLdCandidate(String pageUrl) {
        try { return com.cmyk.bookmarkslauncher.wishlist.WishlistGeneralVerifiedUnknownDom
                .candidate(new java.net.URL(pageUrl)); }
        catch (Exception ignored) { return false; }
    }

    private static boolean isVerifiedSingleProductUrl(String pageUrl) {
        if (pageUrl == null) return false;
        try {
            return WishlistCrawler.isSingleProductPage(new java.net.URL(pageUrl));
        } catch (Exception ignored) { return false; }
    }

    private static boolean isZozoHost(String raw) {
        if (raw == null) return false;
        try {
            String h = new java.net.URL(raw).getHost().toLowerCase(java.util.Locale.ROOT);
            return "zozo.jp".equals(h) || "www.zozo.jp".equals(h);
        } catch (Exception ignored) { return false; }
    }

    /** The ZOZO gallery is eligible only for a saved single-item goods URL. */
    private static boolean isZozoSavedProductDetail(String url) {
        if (url == null) return false;
        try {
            java.net.URL parsed = new java.net.URL(url);
            return com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode.forUrl(parsed)
                    == com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode.ZOZO;
        } catch (Exception ignored) { return false; }
    }

    /** Independent image recovery. Successful price and name data is never touched. */
    private void recoverMissingProductImage(String id, String pageUrl, boolean noteMatched) {
        WishlistItem card = repo.get(id);
        if (card == null) return;
        // A rejected HTTP 403 may resolve to an access-denied destination, not
        // the product that an independent, SKU-bound price WebView identified.
        // For an EXACT ZOZO goods URL, reload the SAVED product directly for
        // read-only image evidence. This does not modify the proven price/stock
        // engines or any non-ZOZO route (Joshin included).
        final boolean zozoSavedItem = card.acquisitionMode == WishlistMode.GENERAL
                && isZozoSavedProductDetail(card.url);
        if (card.acquisitionMode == WishlistMode.GENERAL && isZozoHost(card.url)
                && !zozoSavedItem) WishlistCardDiagnostics.event(host,id,"image.route.skip",
                        "reason=unsupported-saved-zozo-route");
        final String imagePageUrl = zozoSavedItem ? card.url : pageUrl;
        if (imagePageUrl == null || card.acquisitionMode == WishlistMode.UNRESOLVED
                || card.acquisitionMode != WishlistMode.forDirectUrl(imagePageUrl)) {
            if (zozoSavedItem) WishlistCardDiagnostics.event(host,id,"image.route.skip",
                    "reason=mode-or-url-mismatch");
            return;
        }
        if (card.acquisitionMode == WishlistMode.AMAZON) {
            recoverMissingAmazonImage(id, imagePageUrl);
            return;
        }
        // A keyword-selected listing may show many products: never take a
        // page-wide image unless the URL itself identifies one product.
        if (noteMatched) {
            if (zozoSavedItem) WishlistCardDiagnostics.event(host,id,"image.route.skip",
                    "reason=note-selected-listing");
            return;
        }
        boolean productDetail;
        try {
            java.net.URL actualUrl = new java.net.URL(imagePageUrl);
            productDetail = WishlistCrawler.isSingleProductPage(actualUrl)
                    || (card.acquisitionMode == WishlistMode.GENERAL
                        && isUnknownJsonLdCandidate(imagePageUrl))
                    || com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode.forUrl(actualUrl)
                       == com.cmyk.bookmarkslauncher.wishlist.WishlistRetailDedicatedMode.ZOZO;
        } catch (Exception ignored) { productDetail = false; }
        if (zozoSavedItem) WishlistCardDiagnostics.event(host,id,"image.route",
                "source=saved-zozo-product detail="+productDetail
                +" saved="+repo.hasUsablePreview(id)
                +" sameResolved="+imagePageUrl.equals(pageUrl));
        boolean joshinDetail = false;
        try { joshinDetail = com.cmyk.bookmarkslauncher.wishlist.WishlistJoshinProductIdentity
                .isDetail(new java.net.URL(imagePageUrl)); }
        catch (Exception ignored) { }
        if (joshinDetail) WishlistCardDiagnostics.event(host,id,"image.joshin.route",
                "detail="+productDetail+" saved="+repo.hasUsablePreview(id)+" note="+noteMatched);
        // An older GENERAL auto-preview on a guarded marketplace may be a
        // site-wide OG banner. Allow only a strictly item-bound DOM image to
        // replace it; manually selected photos are never overwritten.
        boolean inspectPriorGeneralImage = false;
        try { inspectPriorGeneralImage = card.acquisitionMode == WishlistMode.GENERAL
                && !card.userImageEdited && card.previewImageUrl != null
                && (com.cmyk.bookmarkslauncher.wishlist.WishlistGeneralMarketplaceIdentity
                        .isDetail(new java.net.URL(imagePageUrl))
                    || isUnknownJsonLdCandidate(imagePageUrl)); }
        catch (Exception ignored) { }
        if (!productDetail || (repo.hasUsablePreview(id) && !inspectPriorGeneralImage)) {
            if (zozoSavedItem) WishlistCardDiagnostics.event(host,id,"image.route.skip",
                    "reason="+(!productDetail ? "not-product-detail" : "preview-already-saved"));
            return;
        }
        if (retailImageProbe != null) retailImageProbe.cancel();
        final WishlistRetailImageWebViewProbe thisImageProbe = new WishlistRetailImageWebViewProbe(root);
        retailImageProbe = thisImageProbe;
        boolean honmaSavedItem=false;
        try { honmaSavedItem=card.acquisitionMode == WishlistMode.GENERAL
                && com.cmyk.bookmarkslauncher.wishlist.WishlistHonmaProductDom
                        .isDetail(new java.net.URL(card.url)); }
        catch (Exception ignored) { }
        boolean guardedGeneralDetail=false;
        try { guardedGeneralDetail=card.acquisitionMode == WishlistMode.GENERAL
                && (com.cmyk.bookmarkslauncher.wishlist.WishlistGeneralMarketplaceIdentity
                        .isDetail(new java.net.URL(imagePageUrl))
                    || isUnknownJsonLdCandidate(imagePageUrl)); }
        catch (Exception ignored) { }
        if (zozoSavedItem || honmaSavedItem || guardedGeneralDetail)
            thisImageProbe.setTrace((stage, evidence) ->
                WishlistCardDiagnostics.event(host,id,"image.webview."+stage,evidence));
        beginUpdate(id);
        switchRunningMode(id, stockModeName(imagePageUrl, card.acquisitionMode));
        WishlistCardDiagnostics.event(host,id,"image.webview.start",
                joshinDetail ? "technique=G-gallery adapter=Joshin" : "probe");
        thisImageProbe.start(imagePageUrl, zozoSavedItem ? card.acquisitionMode
                : repo.get(id).acquisitionMode, imageUrls -> {
            WishlistCardDiagnostics.event(host,id,"image.webview.candidates",
                    "count="+(imageUrls==null?0:imageUrls.length));
            final String imageDomName=thisImageProbe.verifiedMarketplaceTitle();
            if (imageDomName!=null) {
                io.execute(() -> {
                    boolean accepted=repo.updateVerifiedMarketplaceTitle(id,card.url,imageDomName);
                    WishlistCardDiagnostics.event(host,id,"product.name.commit",
                            "saved="+accepted+" source=marketplace-image-webview");
                    host.runOnUiThread(() -> {if (!host.isFinishing()&&!host.isDestroyed())refreshList();});
                });
            }
            if (host.isFinishing() || host.isDestroyed()) { finishUpdate(id); return; }
            if (imageUrls == null || imageUrls.length == 0) {
                try { RetailDiagnostics.general(new java.net.URL(imagePageUrl), "image.dom", "candidates=0"); }
                catch (Exception ignored) { }
                Toast.makeText(host, "商品画像候補を特定できませんでした", Toast.LENGTH_SHORT).show();
                finishUpdate(id);
                return;
            }
            try { RetailDiagnostics.general(new java.net.URL(imagePageUrl), "image.dom", "candidates="+imageUrls.length); }
            catch (Exception ignored) { }
            io.execute(() -> {
                // Try gallery candidates sequentially. A failed thumbnail/CDN request
                // must not prevent saving the next product photo.
                boolean saved = false;
                int candidateIndex = 0;
                for (String candidate : imageUrls) {
                    // Joshin's dedicated route uses the reusable G gallery technique.
                    // Bound retries to avoid stalling a 48-card batch on one CDN.
                    boolean joshinImage = false;
                    try { joshinImage = com.cmyk.bookmarkslauncher.wishlist.WishlistJoshinProductIdentity
                            .isDetail(new java.net.URL(imagePageUrl)); }
                    catch (Exception ignored) { }
                    if (joshinImage && candidateIndex >= 3) {
                        WishlistCardDiagnostics.event(host,id,"image.webview.stop",
                                "reason=joshin-retry-budget");
                        break;
                    }
                    // Six MUJI CDN timeouts previously consumed over 70 seconds.
                    // Try at most two distinct candidates with bounded transport.
                    if (repo.get(id) != null && repo.get(id).acquisitionMode == WishlistMode.MUJI
                            && candidateIndex >= 2) {
                        WishlistCardDiagnostics.event(host,id,"image.webview.stop","reason=muji-retry-budget");
                        break;
                    }
                    final int currentIndex = ++candidateIndex;
                    if (repo.updateImageFromWebView(id, candidate, imagePageUrl, reason ->
                            WishlistCardDiagnostics.event(host,id,"image.webview.fetch",
                                    "candidate="+currentIndex+" reason="+reason))) {
                        saved = true;
                        break;
                    }
                }
                final boolean success = saved;
                WishlistCardDiagnostics.event(host,id,"image.webview.save","success="+saved);
                host.runOnUiThread(() -> {
                    if (host.isFinishing() || host.isDestroyed()) { finishUpdate(id); return; }
                    refreshList();
                    if (!success) Toast.makeText(host, "商品画像候補の保存に失敗しました", Toast.LENGTH_SHORT).show();
                    finishUpdate(id);
                });
            });
        });
    }

    /** Manual refresh can replace a previously auto-saved WRONG Amazon image. */
    private void recoverMissingAmazonImage(String id, String pageUrl) {
        if (!WishlistImageWebViewProbe.isAmazonUrl(pageUrl)) return;
        WishlistItem now = repo.get(id);
        if (now == null || now.userImageEdited || now.acquisitionMode != WishlistMode.AMAZON) return;
        if (imageProbe != null) imageProbe.cancel();
        imageProbe = new WishlistImageWebViewProbe(root);
        beginUpdate(id);
        imageProbe.start(pageUrl, imageUrl -> {
            if (host.isFinishing() || host.isDestroyed()) { finishUpdate(id); return; }
            if (imageUrl == null) {
                Toast.makeText(host, "Amazon画像は取得できませんでした", Toast.LENGTH_SHORT).show();
                finishUpdate(id);
                return;
            }
            io.execute(() -> {
                boolean saved = repo.updateImageFromWebView(id, imageUrl, pageUrl);
                host.runOnUiThread(() -> {
                    if (host.isFinishing() || host.isDestroyed()) { finishUpdate(id); return; }
                    refreshList();
                    if (!saved) Toast.makeText(host, "Amazon画像の保存に失敗しました", Toast.LENGTH_SHORT).show();
                    finishUpdate(id);
                });
            });
        });
    }

    /** Pull-to-refresh and a card's 情報更新 run exactly the same fetch pipeline.
     * The ONLY difference is which card IDs are selected. Their URLs, saved
     * modes, HTTP failure recovery, rendered price, stock, and image handling
     * are identical. Process strictly one card at a time: a second WebView
     * cannot cancel or starve a preceding card's probe. */
    private void refreshAllNow(Runnable done) {
        if (batchRefreshing || !updatingItems.isEmpty()) return;
        final boolean filteredBatch = hasFilters();
        final List<WishlistItem> items = new ArrayList<>();
        for (WishlistItem candidate : repo.listAll()) {
            if (matches(candidate)) items.add(candidate);
        }
        sortVisibleItems(items);
        if (items.isEmpty()) {
            hidePullHeaderIfIdle();
            Toast.makeText(host, "更新する商品がありません", Toast.LENGTH_SHORT).show();
            return;
        }
        // Snapshot IDs at the pull gesture. A card becoming unmatched during
        // refresh cannot cause unrelated cards to enter the queue.
        final List<String> ids = new ArrayList<>();
        for (WishlistItem item : items) ids.add(item.id);
        batchRefreshing = true;
        showPullHeader((filteredBatch ? "検索結果を更新中 0/" : "全件更新中 0/") + ids.size());
        Toast.makeText(host, filteredBatch ? "検索結果 " + ids.size() + "件の情報更新を開始"
                : "Wishカード全件の情報更新を開始", Toast.LENGTH_SHORT).show();
        refreshBatchNext(ids, 0, filteredBatch, done);
    }

    /** Advance only after the prior card's final async price/stock/image stage.
     * UI-thread callback is supplied by finishUpdate(), shared with manual. */
    private void refreshBatchNext(List<String> ids, int index, boolean filtered, Runnable done) {
        if (!batchRefreshing) return;
        if (host.isFinishing() || host.isDestroyed() || index >= ids.size()) {
            batchRefreshing = false;
            if (!host.isFinishing() && !host.isDestroyed()) {
                hidePullHeaderIfIdle();
                refreshList();
                Toast.makeText(host, (filtered ? "検索結果の更新 " : "全件更新 ")
                        + index + "/" + ids.size() + "件", Toast.LENGTH_SHORT).show();
                if (done != null) done.run();
            }
            return;
        }
        final String id = ids.get(index);
        final WishlistItem card = repo.get(id);
        if (card == null) {
            refreshBatchNext(ids, index + 1, filtered, done);
            return;
        }
        showPullHeader((filtered ? "検索結果を更新中 " : "全件更新中 ")
                + index + "/" + ids.size());
        // Unlike the old HTTP/price/stock queues, this calls the exact same
        // function as the card button, including ASKUL CONNECT_FAILED/403.
        refreshItem(id, true, () -> {
            WishlistCardDiagnostics.event(host, id, "refresh.batch.finish",
                    "completed=" + (index + 1) + "/" + ids.size()
                            + " shared-pipeline=true");
            if (!host.isFinishing() && !host.isDestroyed()) {
                refreshList();
                showPullHeader((filtered ? "検索結果を更新中 " : "全件更新中 ")
                        + (index + 1) + "/" + ids.size());
            }
            refreshBatchNext(ids, index + 1, filtered, done);
        });
    }

    private void maybeRefreshStale() {
        long now=System.currentTimeMillis(); boolean stale=false; for(WishlistItem i:repo.listAll())if(i.lastPriceCheckedAt==null||now-i.lastPriceCheckedAt>DAY_MS){stale=true;break;} if(!stale)return; io.execute(()->{for(WishlistItem i:repo.listAll()){if(i.lastPriceCheckedAt!=null&&now-i.lastPriceCheckedAt<=DAY_MS)continue;WishlistCrawler.Result r=WishlistCrawler.fetch(i);repo.updateCrawl(i.id,r);try{Thread.sleep(350);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}}host.runOnUiThread(this::refreshList);});
    }

    private void showDeleteDialog(WishlistItem item) {
        Dialog dialog = new Dialog(host);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout panel = new LinearLayout(host);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(16), dp(16), dp(16));
        panel.setBackground(roundRect(LGRAY, 14));
        TextView message = text("Wishlistから削除しますか？", 15, TEXT, true);
        panel.addView(message, lp(0, dp(16)));
        LinearLayout buttons = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 13);
        TextView delete = capsule("削除", LRED, 13);
        addCardAction(buttons, cancel, false);
        addCardAction(buttons, delete, true);
        panel.addView(buttons, lp(0, 0));
        cancel.setOnClickListener(v -> dialog.dismiss());
        delete.setOnClickListener(v -> {
            dialog.dismiss();
            repo.delete(item.id);
            expandedIds.remove(item.id);
            refreshList();
        });
        dialog.setContentView(panel);
        showDialog(dialog);
    }

    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&host.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)host.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},811);}

    private String collapsedSub(WishlistItem i) {
        String description = availabilityDescription(i);
        String site = WishlistSiteState.label(i.siteState);
        String s = site == null ? description : description + "・" + site;
        if (i.monitorResume) s += "  • 再開監視";
        return s;
    }

    private boolean currentStockVerified(WishlistItem i) {
        return WishlistSiteState.label(i.siteState) == null
                && ("AVAILABLE".equals(i.status) || "UNAVAILABLE".equals(i.status));
    }

    private String availabilityDescription(WishlistItem i) {
        if (currentStockVerified(i))
            return "AVAILABLE".equals(i.status) ? "購入可能" : "現在購入不可";
        if ("COMING_SOON".equals(i.status) && WishlistSiteState.label(i.siteState) == null)
            return "未開始";
        if (i.lastConfirmedAt != null && i.lastConfirmedAt > 0L
                && ("AVAILABLE".equals(i.lastConfirmedStatus)
                    || "UNAVAILABLE".equals(i.lastConfirmedStatus))) {
            return "未確認（前回"
                    + ("AVAILABLE".equals(i.lastConfirmedStatus) ? "購入可能" : "完売")
                    + "：" + dateTime(i.lastConfirmedAt) + "）";
        }
        return "未確認";
    }

    private int statusColor(String s) {
        if ("AVAILABLE".equals(s)) return WHITE;
        if ("UNAVAILABLE".equals(s)) return LRED;
        if ("COMING_SOON".equals(s)) return ORANGE;
        return LGRAY;
    }
    private static String currentPriceText(WishlistItem item) {
        if (item.priceMinimum != null && item.priceQuoteKind != null) {
            String min = price(item.priceMinimum);
            if ("FROM".equals(item.priceQuoteKind)) return min + "～";
            if ("RANGE".equals(item.priceQuoteKind) && item.priceMaximum != null)
                return min + "～" + String.format(Locale.JAPAN, "%,d", item.priceMaximum);
        }
        return price(item.currentPrice);
    }
    private static String signedYen(long amount) {
        if (amount == 0L) return "¥0";
        // A sign precedes the currency glyph, including Long.MIN_VALUE.
        java.math.BigInteger magnitude = java.math.BigInteger.valueOf(amount).abs();
        return (amount < 0L ? "-" : "+") + "¥"
                + String.format(Locale.JAPAN, "%,d", magnitude);
    }
    private static String price(Long p){return p==null?"—":"¥"+String.format(Locale.JAPAN,"%,d",p);}
    private String dateTime(long t){return DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(t));}
    private String shortDate(long t){return new java.text.SimpleDateFormat("M/d",Locale.JAPAN).format(new Date(t));}
    private Long number(String s){try{String v=s==null?"":s.replace(",","").trim();return v.isBlank()?null:Long.parseLong(v);}catch(Exception e){return null;}}

    private TextView field(String label,String value){return text(label+"  "+value,12,TEXT,false);}
    /** Price is visible digits, never a phone/contact suggestion target. The
     * numeric-password IME variation inhibits IME learning/suggestion panels,
     * while disabling transformation keeps the entered price readable. */
    private void configurePriceInput(EditText edit) {
        edit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        edit.setTransformationMethod(null);
        edit.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        edit.setAutofillHints((String[]) null);
        edit.setSaveEnabled(false);
        edit.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
    }

    /** Only the pinned Wishlist search form follows the IME. The weighted card
     * list shrinks as the lower padding moves the form above the keyboard. */
    public void updateImeObstruction(int imeBottomPx) {
        if (pageLayout == null) return;
        boolean active = filterPanel != null && filterPanel.getVisibility() == View.VISIBLE;
        // The layout keeps a normal 18dp margin. Keep 8dp more air above IME.
        int lift = active && imeBottomPx > 0 ? Math.max(0, imeBottomPx - dp(10)) : 0;
        if (lift == appliedImeLiftPx) return;
        appliedImeLiftPx = lift;
        pageLayout.setPadding(dp(18), dp(64), dp(18), dp(18) + lift);
    }

    /** The first outside tap while typing closes ONLY the IME; MainActivity
     * consumes its entire pointer stream before cards or swipe navigation see it. */
    public boolean dismissImeOnOutsideTap(float rawX, float rawY, boolean imeVisible) {
        if (!imeVisible || filterPanel == null || filterPanel.getVisibility() != View.VISIBLE)
            return false;
        View focused = host.getCurrentFocus();
        if (focused != inlineQuery && focused != inlineMin && focused != inlineMax) return false;
        if (isInsideInput(inlineQuery, rawX, rawY)
                || isInsideInput(inlineMin, rawX, rawY)
                || isInsideInput(inlineMax, rawX, rawY)) return false;
        InputMethodManager imm = (InputMethodManager) host.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
        focused.clearFocus();
        filterPanel.requestFocus();
        return true;
    }

    private boolean isInsideInput(View edit, float rawX, float rawY) {
        if (edit == null || !edit.isShown()) return false;
        int[] xy = new int[2];
        edit.getLocationOnScreen(xy);
        return rawX >= xy[0] && rawX < xy[0] + edit.getWidth()
                && rawY >= xy[1] && rawY < xy[1] + edit.getHeight();
    }

    private EditText input(String hint){EditText e=new EditText(host);e.setSingleLine(true);e.setTextColor(DGRAY);e.setHintTextColor(GRAY);e.setTextSize(14);e.setHint(hint);e.setPadding(dp(12),0,dp(12),0);e.setBackground(roundRect(WHITE,999));return e;}
    private TextView text(String s,float size,int color,boolean bold){TextView t=new TextView(host);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setIncludeFontPadding(false);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private TextView modeChip(String label) {
        TextView chip = new TextView(host) {
            @Override protected void onDraw(Canvas canvas) {
                String glyph = getText()==null ? "" : getText().toString();
                android.graphics.Rect ink = new android.graphics.Rect();
                getPaint().getTextBounds(glyph, 0, glyph.length(), ink);
                Paint.FontMetrics fm = getPaint().getFontMetrics();
                // Center the glyph's actual drawn bounds, not the font baseline.
                float delta = (fm.ascent + fm.descent - ink.top - ink.bottom) * 0.5f;
                canvas.save();canvas.translate(0,delta);
                super.onDraw(canvas);canvas.restore();
            }
        };
        chip.setText(label);
        chip.setTextSize(9);
        chip.setTextColor(BG);
        chip.setTypeface(null,Typeface.BOLD);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(7), 0, dp(7), 0);
        chip.setBackground(roundRect(WHITE, 4));
        chip.setIncludeFontPadding(false);
        return chip;
    }
    private TextView capsule(String s,int color,float size){TextView t=text(s,size,TEXT,true);t.setGravity(Gravity.CENTER);t.setBackground(roundRect(color,999));t.setPadding(dp(8),0,dp(8),0);return t;}
    private TextView tagChip(String s,boolean add){TextView t=capsule(s,add?ORANGE:GRAY,12);t.setPadding(dp(10),0,dp(10),0);t.setMinHeight(dp(30));return t;}
    private GradientDrawable roundRect(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable circle(int color){GradientDrawable d=new GradientDrawable();d.setShape(GradientDrawable.OVAL);d.setColor(color);return d;}
    private LinearLayout.LayoutParams lp(int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,top,0,bottom);return p;}
    private int dp(int v){return Math.round(v*host.getResources().getDisplayMetrics().density);}
    private void showDialog(Dialog d) {
        Window w = d.getWindow();
        int width = host.getResources().getDisplayMetrics().widthPixels - dp(32);
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            WindowManager.LayoutParams params = w.getAttributes();
            params.width = width;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.gravity = Gravity.CENTER;
            params.windowAnimations = 0; // no side-sliding before the first layout
            w.setAttributes(params);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                    | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        d.show();
        if (w != null) w.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private static final class TagManageIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint holePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        TagManageIconView(Activity context) {
            super(context);
            paint.setColor(WHITE);
            paint.setStyle(Paint.Style.FILL);
            holePaint.setColor(GRAY);
            holePaint.setStyle(Paint.Style.FILL);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w * 0.50f;
            float cy = h * 0.50f;

            // Retain the original visible 48dp glyph size, centered in the 58dp button.
            canvas.save();
            canvas.scale(0.88f * 48f / 58f, 0.88f * 48f / 58f, cx, cy);

            // Flat 2D tag silhouette. Build it face-on with parallel sides, then rotate as one rigid shape.
            // This keeps the requested mirrored direction without perspective/skew distortion.
            canvas.save();
            canvas.rotate(45f, cx, cy);

            android.graphics.Path path = new android.graphics.Path();
            float left = w * 0.34f;
            float right = w * 0.66f;
            float top = h * 0.20f;
            float bottom = h * 0.80f;
            float r = Math.min(w, h) * 0.12f;

            path.moveTo(left + r, top);
            path.lineTo(right - r, top);
            path.quadTo(right, top, right, top + r);
            path.lineTo(right, bottom - r * 0.55f);
            path.quadTo(right, bottom, right - r * 0.55f, bottom);
            path.lineTo(left + r * 0.55f, bottom);
            path.quadTo(left, bottom, left, bottom - r * 0.55f);
            path.lineTo(left, top + r);
            path.quadTo(left, top, left + r, top);
            path.close();

            canvas.drawPath(path, paint);
            canvas.drawCircle(cx, h * 0.31f, Math.min(w, h) * 0.072f, holePaint);
            canvas.restore();
            canvas.restore();
        }
    }

    /** Bound tag chip lists to a comfortable dialog height without blank fixed-height space. */
    private static final class MaxHeightScrollView extends ScrollView {
        private final int maxHeight;
        MaxHeightScrollView(Activity context, int maxHeight) {
            super(context);
            this.maxHeight = maxHeight;
        }
        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            super.onMeasure(widthMeasureSpec,
                    MeasureSpec.makeMeasureSpec(maxHeight, MeasureSpec.AT_MOST));
        }
    }

    /** A thumb users can actually hold and drag on the Wishlist card list only.
     * The parent intercepts DOWN only over the current thumb; everywhere else,
     * cards receive the same touch stream and horizontal paging keeps working. */
    private static final class GripScrollFrame extends FrameLayout {
        private final ScrollView content;
        private final Paint thumb = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float density;
        private boolean gripping;
        private float grabOffset;
        private float indicatorAlpha;
        private ValueAnimator fadeAnimator;
        // Entire fade completes about one second after the last interaction.
        private static final long FADE_DELAY_MS = 740L;
        private final Runnable fadeOut = () -> {
            if (gripping) return;
            if (fadeAnimator != null) fadeAnimator.cancel();
            fadeAnimator = ValueAnimator.ofFloat(indicatorAlpha, 0f);
            fadeAnimator.setDuration(260L);
            fadeAnimator.addUpdateListener(a -> {
                indicatorAlpha = (Float) a.getAnimatedValue();
                invalidate();
            });
            fadeAnimator.start();
        };

        void onContentScrolled() { showIndicator(); }

        private void showIndicator() {
            removeCallbacks(fadeOut);
            if (fadeAnimator != null) fadeAnimator.cancel();
            indicatorAlpha = 1f;
            invalidate();
            if (!gripping) postDelayed(fadeOut, FADE_DELAY_MS);
        }

        @Override protected void onDetachedFromWindow() {
            removeCallbacks(fadeOut);
            if (fadeAnimator != null) fadeAnimator.cancel();
            super.onDetachedFromWindow();
        }

        GripScrollFrame(Activity context, ScrollView scroll) {
            super(context);
            content = scroll;
            density = context.getResources().getDisplayMetrics().density;
            thumb.setColor(WHITE);
            thumb.setAlpha(220);
            addView(scroll, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            setWillNotDraw(false);
        }

        private int px(float dp) { return Math.round(dp * density); }
        private int maxScroll() {
            if (content.getChildCount() == 0) return 0;
            return Math.max(0, content.getChildAt(0).getHeight()
                    + content.getPaddingTop() + content.getPaddingBottom() - content.getHeight());
        }
        private float trackTop() { return px(8); }
        private float trackLength() { return Math.max(0f, getHeight() - px(16)); }
        private float thumbLength(int range) {
            float track = trackLength();
            float visible = content.getHeight();
            return Math.min(track, Math.max(px(46), track * visible / (visible + range)));
        }
        private float thumbTop(int range) {
            float available = trackLength() - thumbLength(range);
            return trackTop() + (range == 0 ? 0 : available *
                    Math.min(1f, Math.max(0f, content.getScrollY() / (float) range)));
        }

        @Override protected void dispatchDraw(Canvas canvas) {
            super.dispatchDraw(canvas);
            int range = maxScroll();
            if (range <= 0 || trackLength() <= 0 || indicatorAlpha <= 0f) return;
            thumb.setAlpha(Math.round(220 * indicatorAlpha));
            float right = getWidth() - px(3);
            float left = right - px(7);
            float top = thumbTop(range);
            canvas.drawRoundRect(left, top, right, top + thumbLength(range),
                    px(4), px(4), thumb);
        }

        boolean isThumbTouchAt(float rawX, float rawY) {
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            float x = rawX - loc[0], y = rawY - loc[1];
            int range = maxScroll();
            return indicatorAlpha > .05f && range > 0 && x >= getWidth() - px(26)
                    && y >= thumbTop(range) - px(12)
                    && y <= thumbTop(range) + thumbLength(range) + px(12);
        }

        @Override public boolean onInterceptTouchEvent(MotionEvent event) {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                int range = maxScroll();
                if (indicatorAlpha > .05f && range > 0 && event.getX() >= getWidth() - px(26)
                        && event.getY() >= thumbTop(range) - px(12)
                        && event.getY() <= thumbTop(range) + thumbLength(range) + px(12)) {
                    gripping = true;
                    showIndicator();
                    grabOffset = Math.max(0f, Math.min(thumbLength(range),
                            event.getY() - thumbTop(range)));
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                }
            }
            return super.onInterceptTouchEvent(event);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (!gripping) return super.onTouchEvent(event);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_MOVE:
                    int range = maxScroll();
                    if (range > 0) {
                        float movable = Math.max(1f, trackLength() - thumbLength(range));
                        float desired = event.getY() - grabOffset - trackTop();
                        float ratio = Math.max(0f, Math.min(1f, desired / movable));
                        content.scrollTo(0, Math.round(ratio * range));
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    gripping = false;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    showIndicator(); // begin fade only after release
                    return true;
                default:
                    return true;
            }
        }
    }

    private static final class RoundPlusIcon extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fg = new Paint(Paint.ANTI_ALIAS_FLAG);
        RoundPlusIcon(Activity c, int background, int iconColor) {
            super(c);
            bg.setColor(background);
            bg.setStyle(Paint.Style.FILL);
            fg.setColor(iconColor);
            fg.setStyle(Paint.Style.STROKE);
            fg.setStrokeCap(Paint.Cap.ROUND);
            fg.setStrokeWidth(c.getResources().getDisplayMetrics().density * 2.4f);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight(), cx=w/2f, cy=h/2f;
            float r=Math.min(w,h)*.48f;
            c.drawCircle(cx,cy,r,bg);
            float arm=r*.43f;
            c.drawLine(cx-arm,cy,cx+arm,cy,fg);
            c.drawLine(cx,cy-arm,cx,cy+arm,fg);
        }
    }

    private static final class SearchIcon extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        SearchIcon(Activity c){super(c);p.setColor(WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(c.getResources().getDisplayMetrics().density*2.8f);p.setStrokeCap(Paint.Cap.ROUND);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();float r=Math.min(w,h)*.27f;float cx=w*.43f,cy=h*.43f;c.drawCircle(cx,cy,r,p);c.drawLine(cx+r*.72f,cy+r*.72f,w*.78f,h*.78f,p);}
    }

    private static final class Flow extends ViewGroup {
        private final int gap;
        Flow(Activity c){super(c);gap=Math.round(6*c.getResources().getDisplayMetrics().density);}
        @Override protected LayoutParams generateDefaultLayoutParams(){return new MarginLayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);}
        @Override public LayoutParams generateLayoutParams(android.util.AttributeSet attrs){return new MarginLayoutParams(getContext(),attrs);}
        @Override protected LayoutParams generateLayoutParams(LayoutParams p){return new MarginLayoutParams(p);}
        @Override protected boolean checkLayoutParams(LayoutParams p){return p instanceof MarginLayoutParams;}
        @Override protected void onMeasure(int ws,int hs){int w=MeasureSpec.getSize(ws),x=getPaddingLeft(),y=getPaddingTop(),line=0;for(int i=0;i<getChildCount();i++){View v=getChildAt(i);measureChild(v,ws,hs);if(x+v.getMeasuredWidth()+getPaddingRight()>w&&x>getPaddingLeft()){x=getPaddingLeft();y+=line+gap;line=0;}x+=v.getMeasuredWidth()+gap;line=Math.max(line,v.getMeasuredHeight());}setMeasuredDimension(w,y+line+getPaddingBottom());}
        @Override protected void onLayout(boolean ch,int l,int t,int r,int b){int x=getPaddingLeft(),y=getPaddingTop(),line=0,w=r-l;for(int i=0;i<getChildCount();i++){View v=getChildAt(i);if(x+v.getMeasuredWidth()+getPaddingRight()>w&&x>getPaddingLeft()){x=getPaddingLeft();y+=line+gap;line=0;}v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());x+=v.getMeasuredWidth()+gap;line=Math.max(line,v.getMeasuredHeight());}}
    }
}
