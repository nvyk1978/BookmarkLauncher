package com.cmyk.bookmarkslauncher;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewConfiguration;
import android.view.ViewTreeObserver;
import android.view.animation.DecelerateInterpolator;
import android.transition.ChangeBounds;
import android.transition.Fade;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import com.cmyk.bookmarkslauncher.wishlist.WishlistCrawler;
import com.cmyk.bookmarkslauncher.wishlist.WishlistItem;
import com.cmyk.bookmarkslauncher.wishlist.WishlistRepository;
import com.cmyk.bookmarkslauncher.wishlist.WishlistScheduler;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class WishlistPage {
    private static final int BG = 0xFF303030;
    private static final int DGRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int LGRAY = 0xFF656060;
    private static final int BLUE = 0xFF223355;
    private static final int LBLUE = 0xFF445577;
    private static final int RED = 0xFF441100;
    private static final int LRED = 0xFF662211;
    private static final int ORANGE = 0xFF775500;
    private static final int WHITE = 0xFFA9A999;
    private static final int GREEN = 0xFF227733;
    private static final int TEXT = 0xFFFFFFFF;
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;

    private WishlistRepository repo;
    private FrameLayout root;
    private LinearLayout listBox;
    private ScrollView listScroll;
    private TextView empty;
    // Cards are independent: expanding one never collapses another.
    private final Set<String> expandedIds = new HashSet<>();
    private String query = "";
    private final Set<Long> filterTags = new HashSet<>();
    private Long minPrice;
    private Long maxPrice;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private final Activity host;
    private final Runnable onBack;

    public WishlistPage(Activity host, Runnable onBack, String initialItemId) {
        this.host = host;
        this.onBack = onBack;
        repo = new WishlistRepository(host);
        WishlistScheduler.ensureScheduled(host);
        if (initialItemId != null) expandedIds.add(initialItemId);
        buildUi();
        refreshList();
        maybeRefreshStale();
    }

    public FrameLayout getView() { return root; }
    public void openItem(String id) { if (id != null) expandedIds.add(id); refreshList(); }
    public void refresh() { refreshList(); }
    public void destroy() { io.shutdownNow(); }
    private void returnToBookmarks() { if (onBack != null) onBack.run(); }
    public void onHostResume() { /* No purchase prompts or purchase tracking UI. */ }

    private View buildUi() {
        root = new FrameLayout(host);
        root.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(host);
        page.setOrientation(LinearLayout.VERTICAL);
        // Match the Home title: 18dp horizontal inset, 64dp top inset,
        // 25sp bold text centered vertically in a 44dp title row.
        page.setPadding(dp(18), dp(64), dp(18), dp(18));

        TextView title = text("Wishlist", 25, WHITE, true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setContentDescription("Wishlist：タップですべて格納");
        title.setOnClickListener(v -> collapseAllCards());
        page.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        ScrollView scroll = new ScrollView(host);
        listScroll = scroll;
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, dp(4), 0, dp(78));
        listBox = new LinearLayout(host);
        listBox.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listBox, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        empty = text("Wishlistは空です", 15, LGRAY, false);
        empty.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams emptyLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64), Gravity.CENTER);
        emptyLp.leftMargin = dp(28); emptyLp.rightMargin = dp(28);
        root.addView(empty, emptyLp);

        FrameLayout searchFab = new FrameLayout(host);
        searchFab.setBackground(circle(DGRAY));
        searchFab.setElevation(dp(8));
        SearchIcon icon = new SearchIcon(host);
        searchFab.addView(icon, new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        searchFab.setContentDescription("Wishlist検索");
        searchFab.setOnClickListener(v -> showSearchDialog());
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END | Gravity.BOTTOM);
        fabLp.setMargins(0, 0, dp(18), dp(24));
        root.addView(searchFab, fabLp);

        // Paste a shop URL directly, just like a messaging-app link preview.
        FrameLayout addFab = new FrameLayout(host);
        addFab.setElevation(dp(8));
        addFab.addView(new RoundPlusIcon(host, DGRAY, TEXT),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        addFab.setContentDescription("URLから商品を追加");
        addFab.setOnClickListener(v -> showUrlDialog());
        FrameLayout.LayoutParams addLp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END | Gravity.BOTTOM);
        addLp.setMargins(0, 0, dp(84), dp(24));
        root.addView(addFab, addLp);
        return root;
    }

    private void refreshList() {
        List<WishlistItem> all = repo.listAll();
        List<WishlistItem> visible = new ArrayList<>();
        for (WishlistItem item : all) if (matches(item)) visible.add(item);
        listBox.removeAllViews();
        for (WishlistItem item : visible) listBox.addView(itemRow(item));
        empty.setVisibility(visible.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private boolean matches(WishlistItem item) {
        if (item == null) return false;
        if (query != null && !query.isBlank()) {
            String hay = ((item.title == null ? "" : item.title) + " " + (item.url == null ? "" : item.url) + " " + (item.sourceName == null ? "" : item.sourceName)).toLowerCase(Locale.ROOT);
            if (!hay.contains(query.trim().toLowerCase(Locale.ROOT))) return false;
        }
        if (!filterTags.isEmpty()) {
            Set<Long> assigned = repo.tagsForItem(item.id);
            if (!assigned.containsAll(filterTags)) return false;
        }
        if (minPrice != null || maxPrice != null) {
            // Price filtering is only allowed to use a price confirmed by the latest crawl.
            // A failed refresh keeps the previous value for history/display, but never treats it as current.
            if (!item.priceFetchOk || item.currentPrice == null) return false;
            if (minPrice != null && item.currentPrice < minPrice) return false;
            if (maxPrice != null && item.currentPrice > maxPrice) return false;
        }
        return true;
    }

    /** Keep the header/thumbnail views alive when toggling, so their bounds animate. */
    private static final class CardHeader {
        final LinearLayout line;
        final View thumb;
        final TextView grip;
        final TextView name;
        final TextView url;
        final TextView rename;
        final TextView price;
        final WishlistItem item;
        CardHeader(LinearLayout line, View thumb, TextView grip, TextView name,
                   TextView url, TextView rename, TextView price, WishlistItem item) {
            this.line = line; this.thumb = thumb; this.grip = grip;
            this.name = name; this.url = url; this.rename = rename;
            this.price = price; this.item = item;
        }
    }

    private View itemRow(WishlistItem item) {
        boolean expanded = expandedIds.contains(item.id);
        LinearLayout card = new LinearLayout(host);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setTag(item.id);
        card.setBackground(roundRect(DGRAY, 12));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(0, 0, 0, dp(6));
        card.setLayoutParams(cardLp);

        LinearLayout line = new LinearLayout(host);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.TOP);
        line.setPadding(dp(4), dp(8), dp(8), dp(8));
        TextView grip = text("≡", 24, WHITE, true);
        grip.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        grip.setContentDescription("開閉（長押しで並べ替え）");
        grip.setOnClickListener(v -> toggleExpanded(item));
        line.addView(grip, new LinearLayout.LayoutParams(dp(34), dp(48)));
        attachGrip(grip, item.id, card);

        int imageSize = dp(expanded ? 140 : 80);
        View thumb = thumbnail(item);
        thumb.setContentDescription("商品画像：タップで開閉");
        thumb.setOnClickListener(v -> toggleExpanded(item));
        line.addView(thumb, new LinearLayout.LayoutParams(imageSize, imageSize));

        LinearLayout nameBox = new LinearLayout(host);
        nameBox.setOrientation(LinearLayout.VERTICAL);
        nameBox.setGravity(Gravity.TOP);

        TextView name = text(item.title == null || item.title.isBlank() ? "商品" : item.title,
                14, TEXT, true);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setOnClickListener(v -> toggleExpanded(item));
        name.setOnLongClickListener(v -> { showRenameDialog(item); return true; });
        nameBox.addView(name, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout footer = new LinearLayout(host);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView sub = text(collapsedSub(item), 11, statusColor(item.status), false);
        sub.setSingleLine(true);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sub.setOnClickListener(v -> toggleExpanded(item));
        footer.addView(sub, new LinearLayout.LayoutParams(0, dp(22), 1f));
        TextView priceLabel = null;
        if (item.currentPrice != null) {
            priceLabel = text(price(item.currentPrice), 11, TEXT, true);
            priceLabel.setSingleLine(true);
            priceLabel.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            priceLabel.setVisibility(expanded ? View.GONE : View.VISIBLE);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(22));
            pp.leftMargin = dp(5);
            footer.addView(priceLabel, pp);
        }
        nameBox.addView(footer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(22)));

        TextView url = text(item.url == null ? "" : item.url, 11, LGRAY, false);
        url.setMaxLines(2);
        url.setEllipsize(android.text.TextUtils.TruncateAt.END);
        url.setVisibility(expanded ? View.VISIBLE : View.GONE);
        url.setOnClickListener(v -> toggleExpanded(item));
        LinearLayout.LayoutParams urlLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        urlLp.topMargin = dp(7);
        nameBox.addView(url, urlLp);

        TextView rename = capsule("商品名を編集", GRAY, 12);
        rename.setOnClickListener(v -> showRenameDialog(item));
        rename.setVisibility(expanded ? View.VISIBLE : View.GONE);
        LinearLayout.LayoutParams renameLp = new LinearLayout.LayoutParams(dp(120), dp(32));
        renameLp.topMargin = dp(7);
        nameBox.addView(rename, renameLp);

        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        nameLp.leftMargin = dp(8);
        line.addView(nameBox, nameLp);
        line.setTag(new CardHeader(line, thumb, grip, name, url, rename, priceLabel, item));
        line.setOnClickListener(v -> toggleExpanded(item));
        card.addView(line, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (expanded) card.addView(expandedView(item), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    private void beginCardTransition() {
        TransitionSet transition = new TransitionSet();
        transition.setOrdering(TransitionSet.ORDERING_TOGETHER);
        transition.addTransition(new ChangeBounds());
        transition.addTransition(new Fade());
        transition.setDuration(250);
        transition.setInterpolator(new DecelerateInterpolator());
        TransitionManager.beginDelayedTransition(listBox, transition);
    }

    /** Toggle only the tapped card. All other expanded cards stay open. */
    private void toggleExpanded(WishlistItem item) {
        View card = findCard(item.id);
        if (!(card instanceof LinearLayout)) return;
        boolean expand = !expandedIds.contains(item.id);
        beginCardTransition();
        setCardExpanded((LinearLayout) card, item, expand);
        if (expand) expandedIds.add(item.id);
        else expandedIds.remove(item.id);
    }

    private View findCard(String id) {
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View v = listBox.getChildAt(i);
            if (id.equals(v.getTag())) return v;
        }
        return null;
    }

    private void setCardExpanded(LinearLayout card, WishlistItem item, boolean expand) {
        View headerView = card.getChildAt(0);
        if (!(headerView.getTag() instanceof CardHeader)) return;
        CardHeader header = (CardHeader) headerView.getTag();
        int side = dp(expand ? 140 : 80);
        ViewGroup.LayoutParams thumbLp = header.thumb.getLayoutParams();
        thumbLp.width = side;
        thumbLp.height = side;
        header.thumb.setLayoutParams(thumbLp);
        header.url.setVisibility(expand ? View.VISIBLE : View.GONE);
        header.rename.setVisibility(expand ? View.VISIBLE : View.GONE);
        if (header.price != null) header.price.setVisibility(expand ? View.GONE : View.VISIBLE);
        if (expand && card.getChildCount() == 1) {
            card.addView(expandedView(item), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else if (!expand && card.getChildCount() > 1) {
            card.removeViewAt(1);
        }
    }

    /** Collapse all at once, while animating image sizes and card heights together. */
    private void collapseAllCards() {
        if (expandedIds.isEmpty()) return;
        beginCardTransition();
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View child = listBox.getChildAt(i);
            if (!(child instanceof LinearLayout) || !(child.getTag() instanceof String)) continue;
            String id = (String) child.getTag();
            if (!expandedIds.contains(id)) continue;
            View head = ((LinearLayout) child).getChildAt(0);
            if (head.getTag() instanceof CardHeader) {
                CardHeader parts = (CardHeader) head.getTag();
                setCardExpanded((LinearLayout) child, parts.item, false);
            }
        }
        expandedIds.clear();
    }

    private View expandedView(WishlistItem item) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        // Prices, tags and actions now run beneath the large image at full card width.
        box.setPadding(dp(12), dp(4), dp(10), dp(12));

        LinearLayout prices = new LinearLayout(host);
        prices.setGravity(Gravity.CENTER_VERTICAL);
        prices.addView(field("登録時", price(item.registeredPrice)), new LinearLayout.LayoutParams(0, dp(44), 1f));
        prices.addView(field("現在", price(item.currentPrice)), new LinearLayout.LayoutParams(0, dp(44), 1f));
        box.addView(prices);

        List<WishlistRepository.PricePoint> history = repo.priceHistory(item.id, 2);
        String change = "価格変動：—";
        if (history.size() >= 2) {
            long d = history.get(0).price - history.get(1).price;
            change = "価格変動：" + shortDate(history.get(1).checkedAt) + "から " + (d > 0 ? "+" : "") + "¥" + String.format(Locale.JAPAN, "%,d", d);
        }
        TextView priceChange = text(change, 12, ORANGE, false);
        box.addView(priceChange, lp(dp(2), dp(3)));
        String registeredDiff = "登録時比：—";
        if (item.registeredPrice != null && item.currentPrice != null) {
            long d = item.currentPrice - item.registeredPrice;
            registeredDiff = "登録時比：" + (d > 0 ? "+" : "") + "¥" + String.format(Locale.JAPAN, "%,d", d);
        }
        box.addView(text(registeredDiff, 12, WHITE, false), lp(0, dp(6)));

        TextView checked = text("最終確認：" + (item.lastPriceCheckedAt == null ? "未取得" : dateTime(item.lastPriceCheckedAt)) + (item.priceFetchOk ? "" : "  取得失敗"), 11, LGRAY, false);
        box.addView(checked, lp(0, dp(8)));

        Flow tags = new Flow(host);
        List<WishlistRepository.Tag> assigned = repo.tagsForItemResolved(item.id);
        for (WishlistRepository.Tag t : assigned) tags.addView(tagChip(t.name, false));
        RoundPlusIcon addTag = new RoundPlusIcon(host, ORANGE, TEXT);
        addTag.setContentDescription("タグ追加");
        addTag.setOnClickListener(v -> showTagDialog(item.id));
        tags.addView(addTag, new ViewGroup.LayoutParams(dp(30), dp(30)));
        box.addView(tags, lp(0, dp(8)));

        TextView monitor = capsule(item.monitorResume ? "再開監視 ON" : "再開監視 OFF", item.monitorResume ? ORANGE : GRAY, 12);
        monitor.setOnClickListener(v -> {
            boolean next = !item.monitorResume;
            repo.setMonitor(item.id, next);
            if (next) requestNotificationPermission();
            WishlistScheduler.ensureScheduled(host);
            refreshList();
        });
        box.addView(monitor, new LinearLayout.LayoutParams(dp(116), dp(34)));

        LinearLayout actions = new LinearLayout(host);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView open = capsule("商品ページ", LBLUE, 12);
        open.setOnClickListener(v -> openProduct(item));
        TextView update = capsule("今すぐ更新", ORANGE, 12);
        update.setOnClickListener(v -> refreshOne(item.id));
        TextView delete = capsule("削除", LRED, 12);
        delete.setOnClickListener(v -> showDeleteDialog(item));
        addAction(actions, open); addAction(actions, update); addAction(actions, delete);
        box.addView(actions, lp(dp(8), 0));
        return box;
    }

    private void addAction(LinearLayout row, TextView v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(36), 1f);
        p.rightMargin = dp(5);
        row.addView(v, p);
    }

    /** PriceRec-style card reorder: long hold, finger tracking and FLIP sibling motion. */
    private void attachGrip(TextView grip, String id, View row) {
        final float[] downY = {0f};
        final float[] downX = {0f};
        final float[] pointerOffset = {0f};
        final float[] currentY = {0f};
        final boolean[] dragging = {false};
        final int[] originalIndex = {-1};
        final Runnable[] holdAction = new Runnable[1];
        final int slop = ViewConfiguration.get(host).getScaledTouchSlop();
        grip.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (hasFilters()) return false;
                    downY[0] = e.getRawY();
                    downX[0] = e.getRawX();
                    currentY[0] = downY[0];
                    int[] loc = new int[2];
                    row.getLocationOnScreen(loc);
                    pointerOffset[0] = downY[0] - loc[1];
                    dragging[0] = false;
                    originalIndex[0] = listBox.indexOfChild(row);
                    holdAction[0] = () -> {
                        if (row.getParent() != listBox) return;
                        dragging[0] = true;
                        v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                        row.animate().cancel();
                        row.setElevation(dp(14));
                        row.animate().scaleX(1.015f).scaleY(1.015f).setDuration(120).start();
                        listBox.setClipChildren(false);
                        listBox.setClipToPadding(false);
                        ViewGroup parent = (ViewGroup) listBox.getParent();
                        if (parent != null) parent.requestDisallowInterceptTouchEvent(true);
                    };
                    v.postDelayed(holdAction[0], 300L);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    currentY[0] = e.getRawY();
                    if (!dragging[0]) {
                        if ((Math.abs(currentY[0] - downY[0]) > slop
                                || Math.abs(e.getRawX() - downX[0]) > slop)
                                && holdAction[0] != null) {
                            v.removeCallbacks(holdAction[0]);
                            holdAction[0] = null;
                            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                        }
                        return true;
                    }
                    trackDraggedRow(row, currentY[0], pointerOffset[0]);
                    reorderToward(row, currentY[0], pointerOffset[0]);
                    edgeScroll(currentY[0]);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (holdAction[0] != null) v.removeCallbacks(holdAction[0]);
                    holdAction[0] = null;
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
                    if (!dragging[0] && e.getActionMasked() == MotionEvent.ACTION_UP
                            && Math.abs(e.getRawX() - downX[0]) <= slop
                            && Math.abs(e.getRawY() - downY[0]) <= slop) {
                        // ACTION_DOWN was consumed to monitor a possible drag;
                        // dispatch accessibility-aware click only for a true tap.
                        v.performClick();
                    }
                    if (dragging[0]) {
                        if (e.getActionMasked() == MotionEvent.ACTION_CANCEL
                                && originalIndex[0] >= 0 && row.getParent() == listBox) {
                            moveCardWithAnimation(row, originalIndex[0], null);
                        } else if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                            // Only commit the new order on the actual drop.
                            persistCurrentOrder();
                        }
                        row.animate().cancel();
                        row.animate().translationY(0f).scaleX(1f).scaleY(1f)
                                .setDuration(200).setInterpolator(new DecelerateInterpolator())
                                .withEndAction(() -> row.setElevation(0f)).start();
                    }
                    dragging[0] = false;
                    return true;
            }
            return true;
        });
    }

    private boolean hasFilters() {
        return (query != null && !query.isBlank()) || !filterTags.isEmpty()
                || minPrice != null || maxPrice != null;
    }

    private void trackDraggedRow(View row, float rawY, float pointerOffset) {
        if (row.getParent() != listBox) return;
        int[] loc = new int[2];
        listBox.getLocationOnScreen(loc);
        row.setTranslationY(rawY - pointerOffset - loc[1] - row.getTop());
    }

    private void edgeScroll(float rawY) {
        if (listScroll == null) return;
        int[] loc = new int[2];
        listScroll.getLocationOnScreen(loc);
        if (rawY < loc[1] + dp(40)) listScroll.scrollBy(0, -dp(12));
        else if (rawY > loc[1] + listScroll.getHeight() - dp(40)) listScroll.scrollBy(0, dp(12));
    }

    private void reorderToward(View moving, float rawY, float pointerOffset) {
        int from = listBox.indexOfChild(moving);
        if (from < 0) return;
        int[] loc = new int[2];
        listBox.getLocationOnScreen(loc);
        float pointerCenter = rawY - pointerOffset + moving.getHeight() / 2f - loc[1];
        int to = from;
        if (from + 1 < listBox.getChildCount()) {
            for (int i = from + 1; i < listBox.getChildCount(); i++) {
                View other = listBox.getChildAt(i);
                float midpoint = other.getTop() + other.getHeight() / 2f;
                if (pointerCenter > midpoint) to = i; else break;
            }
        }
        if (from > 0) {
            for (int i = from - 1; i >= 0; i--) {
                View other = listBox.getChildAt(i);
                float midpoint = other.getTop() + other.getHeight() / 2f;
                if (pointerCenter < midpoint) to = i; else break;
            }
        }
        if (to == from) return;
        moveCardWithAnimation(moving, to, () -> trackDraggedRow(moving, rawY, pointerOffset));
    }

    /** Capture old visual positions and animate all displaced rows into their new slots. */
    private void moveCardWithAnimation(View moving, int destination, Runnable keepDraggedPosition) {
        int from = listBox.indexOfChild(moving);
        if (from < 0 || from == destination) return;
        Map<View, Float> oldPositions = new IdentityHashMap<>();
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View row = listBox.getChildAt(i);
            oldPositions.put(row, row.getTop() + row.getTranslationY());
            if (row != moving) row.animate().cancel();
        }
        listBox.removeViewAt(from);
        listBox.addView(moving, Math.max(0, Math.min(destination, listBox.getChildCount())));
        listBox.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override public boolean onPreDraw() {
                ViewTreeObserver observer = listBox.getViewTreeObserver();
                if (observer.isAlive()) observer.removeOnPreDrawListener(this);
                for (Map.Entry<View, Float> entry : oldPositions.entrySet()) {
                    View child = entry.getKey();
                    if (child.getParent() != listBox) continue;
                    if (child == moving) {
                        if (keepDraggedPosition != null) keepDraggedPosition.run();
                        continue;
                    }
                    child.setTranslationY(entry.getValue() - child.getTop());
                    child.animate().translationY(0f).setDuration(220)
                            .setInterpolator(new DecelerateInterpolator()).start();
                }
                return true;
            }
        });
    }

    private void persistCurrentOrder() {
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < listBox.getChildCount(); i++) {
            Object tag = listBox.getChildAt(i).getTag();
            if (tag instanceof String) ids.add((String) tag);
        }
        if (!ids.isEmpty()) repo.updateOrder(ids);
    }

    private View thumbnail(WishlistItem item) {
        FrameLayout f=new FrameLayout(host); f.setBackground(roundRect(GRAY, 9)); f.setClipToOutline(true);
        String path=item.previewPath!=null && new java.io.File(item.previewPath).isFile()
                ? item.previewPath : (item.thumbnailPath!=null?item.thumbnailPath:item.faviconPath);
        if(path!=null) {
            try { Bitmap b=BitmapFactory.decodeFile(path); if(b!=null){ ImageView i=new ImageView(host); i.setScaleType(ImageView.ScaleType.CENTER_CROP); i.setImageBitmap(b); f.addView(i,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)); } } catch(Throwable ignored){}
        }
        return f;
    }

    private void showSearchDialog() {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box=new LinearLayout(host); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(14),dp(16),dp(14)); box.setBackground(roundRect(LGRAY,14));
        TextView title=text("検索",18,TEXT,true); box.addView(title,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(38)));
        EditText q=input("商品名・URL"); q.setText(query); box.addView(q,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(46)));
        LinearLayout prices=new LinearLayout(host); prices.setGravity(Gravity.CENTER_VERTICAL);
        EditText min=input("最低価格"); min.setInputType(InputType.TYPE_CLASS_NUMBER); if(minPrice!=null)min.setText(String.valueOf(minPrice));
        EditText max=input("最高価格"); max.setInputType(InputType.TYPE_CLASS_NUMBER); if(maxPrice!=null)max.setText(String.valueOf(maxPrice));
        prices.addView(min,new LinearLayout.LayoutParams(0,dp(44),1f)); Space sp=new Space(host); prices.addView(sp,new LinearLayout.LayoutParams(dp(8),1)); prices.addView(max,new LinearLayout.LayoutParams(0,dp(44),1f)); box.addView(prices,lp(dp(8),0));
        TextView tagTitle=text("タグ",13,TEXT,true); box.addView(tagTitle,lp(dp(10),dp(4)));
        ScrollView tagScroll=new ScrollView(host); LinearLayout tagList=new LinearLayout(host); tagList.setOrientation(LinearLayout.VERTICAL); tagScroll.addView(tagList);
        Set<Long> selected=new HashSet<>(filterTags);
        for(WishlistRepository.Tag t:repo.listTags()) tagList.addView(checkRow(t,selected));
        box.addView(tagScroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(220)));
        LinearLayout buttons=new LinearLayout(host); buttons.setGravity(Gravity.CENTER_VERTICAL);
        TextView update=capsule("価格更新",ORANGE,12); TextView clear=capsule("クリア",GRAY,12); TextView apply=capsule("適用",LBLUE,12); TextView close=capsule("閉じる",GRAY,12);
        addAction(buttons,update); addAction(buttons,clear); addAction(buttons,apply); addAction(buttons,close); box.addView(buttons,lp(dp(10),0));
        update.setOnClickListener(v -> refreshAllNow(() -> Toast.makeText(host,"価格を更新しました",Toast.LENGTH_SHORT).show()));
        clear.setOnClickListener(v -> { query=""; filterTags.clear(); minPrice=null; maxPrice=null; d.dismiss(); refreshList(); });
        apply.setOnClickListener(v -> {
            query=q.getText().toString(); filterTags.clear(); filterTags.addAll(selected); minPrice=number(min.getText().toString()); maxPrice=number(max.getText().toString());
            boolean priceSearch=minPrice!=null||maxPrice!=null;
            d.dismiss();
            if(priceSearch) refreshAllNow(this::refreshList); else refreshList();
        });
        close.setOnClickListener(v -> d.dismiss());
        d.setContentView(box); showDialog(d);
    }

    private View checkRow(WishlistRepository.Tag t, Set<Long> selected) {
        LinearLayout row=new LinearLayout(host); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4),dp(3),dp(4),dp(3));
        TextView check=text(selected.contains(t.id)?"✓":"",15,TEXT,true); check.setGravity(Gravity.CENTER); check.setBackground(circle(selected.contains(t.id)?GREEN:GRAY)); row.addView(check,new LinearLayout.LayoutParams(dp(28),dp(28)));
        TextView name=text(t.name,14,TEXT,false); LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(0,dp(38),1f); nlp.leftMargin=dp(10); row.addView(name,nlp);
        row.setOnClickListener(v -> { if(!selected.add(t.id))selected.remove(t.id); check.setText(selected.contains(t.id)?"✓":""); check.setBackground(circle(selected.contains(t.id)?GREEN:GRAY)); });
        return row;
    }

    private View tagManageRow(String itemId, WishlistRepository.Tag t, Set<Long> selected, LinearLayout container) {
        LinearLayout row=new LinearLayout(host);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(2),dp(2),dp(4),dp(2));
        row.setTag(t.id);
        row.setBackground(roundRect(DGRAY,7));

        TextView handle=text("☰",22,LGRAY,false);
        handle.setGravity(Gravity.CENTER);
        handle.setContentDescription(t.name+"を並べ替え");
        row.addView(handle,new LinearLayout.LayoutParams(dp(38),dp(40)));

        TextView check=text(selected.contains(t.id)?"✓":"",15,TEXT,true);
        check.setGravity(Gravity.CENTER);
        check.setBackground(circle(selected.contains(t.id)?GREEN:GRAY));
        row.addView(check,new LinearLayout.LayoutParams(dp(28),dp(28)));

        TextView name=text(t.name,14,TEXT,selected.contains(t.id));
        LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(0,dp(40),1f);
        nlp.leftMargin=dp(10);
        row.addView(name,nlp);

        row.setOnClickListener(v->{
            boolean on;
            if(selected.add(t.id)){
                on=true;
                repo.addTagToItem(itemId,t.id);
            }else{
                selected.remove(t.id);
                on=false;
                repo.removeTagFromItem(itemId,t.id);
            }
            check.setText(on?"✓":"");
            check.setBackground(circle(on?GREEN:GRAY));
            name.setTypeface(null,on?Typeface.BOLD:Typeface.NORMAL);
        });

        final float[] downY={0f};
        final boolean[] moving={false};
        handle.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    downY[0]=e.getRawY(); moving[0]=false;
                    if(v.getParent()!=null)v.getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if(!moving[0]&&Math.abs(e.getRawY()-downY[0])>dp(6)){
                        moving[0]=true;
                        v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                        row.setElevation(dp(8));
                    }
                    if(moving[0])reorderTagToward(row,e.getRawY(),container);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if(v.getParent()!=null)v.getParent().requestDisallowInterceptTouchEvent(false);
                    row.setElevation(dp(2));
                    if(moving[0]&&e.getActionMasked()==MotionEvent.ACTION_UP)persistTagOrder(container);
                    moving[0]=false;
                    return true;
                default:return true;
            }
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(44));
        lp.bottomMargin=dp(4);
        row.setLayoutParams(lp);
        return row;
    }

    private void reorderTagToward(View moving,float rawY,LinearLayout container){
        int from=container.indexOfChild(moving),to=-1;
        if(from<0)return;
        for(int i=0;i<container.getChildCount();i++){
            View child=container.getChildAt(i);
            int[] loc=new int[2]; child.getLocationOnScreen(loc);
            if(rawY>=loc[1]&&rawY<=loc[1]+child.getHeight()){to=i;break;}
        }
        if(to<0||to==from)return;
        container.removeViewAt(from);
        container.addView(moving,to);
    }

    private void persistTagOrder(LinearLayout container){
        List<Long> ids=new ArrayList<>();
        for(int i=0;i<container.getChildCount();i++){
            Object tag=container.getChildAt(i).getTag();
            if(tag instanceof Long)ids.add((Long)tag);
        }
        if(!ids.isEmpty())repo.setTagOrder(ids);
    }

    private void showTagDialog(String itemId) {
        Dialog d=new Dialog(host); d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box=new LinearLayout(host); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(14),dp(16),dp(14)); box.setBackground(roundRect(LGRAY,14));
        box.setFocusableInTouchMode(true);
        box.requestFocus();
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        box.addView(text("タグ選択",18,TEXT,true),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(38)));
        Set<Long> selected=new HashSet<>(repo.tagsForItem(itemId));
        LinearLayout rows=new LinearLayout(host); rows.setOrientation(LinearLayout.VERTICAL);
        Runnable rebuild=()->{
            rows.removeAllViews();
            for(WishlistRepository.Tag t:repo.listTags()) {
                View r=tagManageRow(itemId,t,selected,rows);
                r.setOnLongClickListener(v->{ showTagRenameDelete(t,()->showTagDialog(itemId)); d.dismiss(); return true;});
                rows.addView(r);
            }
        };
        rebuild.run();
        ScrollView scroll=new ScrollView(host); scroll.addView(rows); box.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(230)));
        LinearLayout create=new LinearLayout(host); create.setGravity(Gravity.CENTER_VERTICAL);
        EditText input=input("新しいタグ");
        RoundPlusIcon plus=new RoundPlusIcon(host,ORANGE,TEXT); plus.setContentDescription("タグ追加");
        create.addView(input,new LinearLayout.LayoutParams(0,dp(44),1f));
        FrameLayout plusSlot=new FrameLayout(host); LinearLayout.LayoutParams slotLp=new LinearLayout.LayoutParams(dp(52),dp(44)); slotLp.leftMargin=dp(8); create.addView(plusSlot,slotLp);
        plusSlot.addView(plus,new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.CENTER));
        box.addView(create,lp(dp(8),0));
        plus.setOnClickListener(v->{
            WishlistRepository.Tag t=repo.createTag(input.getText().toString());
            if(t==null){
                Toast.makeText(host,"タグ名を入力してください",Toast.LENGTH_SHORT).show();
                return;
            }
            selected.add(t.id);
            repo.addTagToItem(itemId,t.id);
            input.setText("");
            rebuild.run();
        });
        LinearLayout bottom=new LinearLayout(host); TextView apply=capsule("適用",LBLUE,12); TextView close=capsule("閉じる",GRAY,12); bottom.addView(apply,new LinearLayout.LayoutParams(0,dp(42),1f)); Space gap=new Space(host); bottom.addView(gap,new LinearLayout.LayoutParams(dp(8),1)); bottom.addView(close,new LinearLayout.LayoutParams(0,dp(42),1f)); box.addView(bottom,lp(dp(10),0));
        apply.setOnClickListener(v->{ repo.setTagsForItem(itemId,selected); d.dismiss(); });
        close.setOnClickListener(v->{ repo.setTagsForItem(itemId,selected); d.dismiss(); });
        d.setOnDismissListener(v->refreshList());
        d.setContentView(box); showDialog(d);
    }

    private void showTagRenameDelete(WishlistRepository.Tag tag, Runnable after) {
        Dialog d=new Dialog(host); d.requestWindowFeature(Window.FEATURE_NO_TITLE); LinearLayout b=new LinearLayout(host); b.setOrientation(LinearLayout.VERTICAL); b.setPadding(dp(16),dp(14),dp(16),dp(14)); b.setBackground(roundRect(LGRAY,14)); b.setFocusableInTouchMode(true); b.requestFocus(); d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE); EditText in=input("タグ名"); in.setText(tag.name); b.addView(in,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(46))); LinearLayout row=new LinearLayout(host); TextView del=capsule("削除",LRED,12); TextView save=capsule("保存",LBLUE,12); TextView close=capsule("閉じる",GRAY,12); addAction(row,del);addAction(row,save);addAction(row,close);b.addView(row,lp(dp(10),0)); del.setOnClickListener(v->{repo.deleteTag(tag.id);d.dismiss();after.run();});save.setOnClickListener(v->{repo.renameTag(tag.id,in.getText().toString());d.dismiss();after.run();});close.setOnClickListener(v->d.dismiss());d.setContentView(b);showDialog(d);
    }

    private void openProduct(WishlistItem item) {
        if (item.url == null || item.url.isBlank()) return;
        try {
            host.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(item.url)));
        } catch (Exception e) {
            Toast.makeText(host, "商品ページを開けません", Toast.LENGTH_SHORT).show();
        }
    }

    private void showUrlDialog() {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(roundRect(LGRAY, 14));
        box.setFocusableInTouchMode(true);
        box.requestFocus();
        TextView title = text("商品URLを追加", 18, TEXT, true);
        box.addView(title, lp(0, dp(12)));
        EditText url = input("https://www.amazon.co.jp/...");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        box.addView(url, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        TextView hint = text("商品名・画像・価格を取得できる範囲で自動入力します", 11, TEXT, false);
        box.addView(hint, lp(dp(10), dp(12)));
        LinearLayout buttons = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 12);
        TextView add = capsule("追加", LBLUE, 12);
        addAction(buttons, cancel);
        addAction(buttons, add);
        box.addView(buttons, lp(0, 0));
        cancel.setOnClickListener(v -> d.dismiss());
        add.setOnClickListener(v -> {
            String value = url.getText().toString().trim();
            if (!value.contains("://")) value = "https://" + value;
            Uri parsed = Uri.parse(value);
            if (!("https".equalsIgnoreCase(parsed.getScheme()) || "http".equalsIgnoreCase(parsed.getScheme()))
                    || parsed.getHost() == null || parsed.getHost().isBlank()) {
                url.setError("有効な商品URLを入力してください");
                return;
            }
            WishlistItem item = repo.addUrl(null, value);
            if (item == null) {
                Toast.makeText(host, "追加できませんでした", Toast.LENGTH_SHORT).show();
                return;
            }
            d.dismiss();
            expandedIds.add(item.id);
            refreshList();
            refreshOne(item.id);
        });
        d.setContentView(box);
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        showDialog(d);
    }

    private void showRenameDialog(WishlistItem item) {
        Dialog d = new Dialog(host);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(roundRect(LGRAY, 14));
        box.setFocusableInTouchMode(true);
        box.requestFocus();
        box.addView(text("商品名を編集", 18, TEXT, true), lp(0, dp(12)));
        EditText name = input("商品名");
        name.setText(item.title);
        box.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        LinearLayout buttons = new LinearLayout(host);
        TextView cancel = capsule("キャンセル", GRAY, 12);
        TextView save = capsule("保存", LBLUE, 12);
        addAction(buttons, cancel); addAction(buttons, save);
        box.addView(buttons, lp(dp(12), 0));
        cancel.setOnClickListener(v -> d.dismiss());
        save.setOnClickListener(v -> {
            String value = name.getText().toString().trim();
            if (value.isBlank()) { name.setError("商品名を入力してください"); return; }
            repo.rename(item.id, value); // Marks the name as manual: refresh will not overwrite it.
            d.dismiss();
            refreshList();
        });
        d.setContentView(box);
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        showDialog(d);
    }

    private void refreshOne(String id) {
        Toast.makeText(host,"更新中…",Toast.LENGTH_SHORT).show(); io.execute(()->{WishlistItem before=repo.get(id);if(before!=null){WishlistCrawler.Result r=WishlistCrawler.fetch(before.url);repo.updateCrawl(id,r);}host.runOnUiThread(this::refreshList);});
    }

    private void refreshAllNow(Runnable done) {
        Toast.makeText(host,"Wishlistを更新中…",Toast.LENGTH_SHORT).show(); io.execute(()->{for(WishlistItem i:repo.listAll()){if(Thread.currentThread().isInterrupted())break; WishlistCrawler.Result r=WishlistCrawler.fetch(i.url);repo.updateCrawl(i.id,r);try{Thread.sleep(350);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}}host.runOnUiThread(()->{refreshList();if(done!=null)done.run();});});
    }

    private void maybeRefreshStale() {
        long now=System.currentTimeMillis(); boolean stale=false; for(WishlistItem i:repo.listAll())if(i.lastPriceCheckedAt==null||now-i.lastPriceCheckedAt>DAY_MS){stale=true;break;} if(!stale)return; io.execute(()->{for(WishlistItem i:repo.listAll()){if(i.lastPriceCheckedAt!=null&&now-i.lastPriceCheckedAt<=DAY_MS)continue;WishlistCrawler.Result r=WishlistCrawler.fetch(i.url);repo.updateCrawl(i.id,r);try{Thread.sleep(350);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}}host.runOnUiThread(this::refreshList);});
    }

    private void showDeleteDialog(WishlistItem item) {
        android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(host).setMessage("Wishlistから削除しますか？").setNegativeButton("キャンセル",null).setPositiveButton("削除",(d,w)->{repo.delete(item.id);expandedIds.remove(item.id);refreshList();}).create();dialog.setOnShowListener(x->{if(dialog.getWindow()!=null)dialog.getWindow().setBackgroundDrawable(roundRect(LGRAY,14));});dialog.show();
    }

    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&host.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)host.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},811);}

    private String collapsedSub(WishlistItem i){String s=statusLabel(i.status); if(i.monitorResume)s+="  • 再開監視";return s;}
    private int statusColor(String s){if("AVAILABLE".equals(s))return WHITE;if("UNAVAILABLE".equals(s))return LRED;if("COMING_SOON".equals(s))return ORANGE;return LGRAY;}
    private String statusLabel(String s){if("AVAILABLE".equals(s))return "購入可能";if("UNAVAILABLE".equals(s))return "現在購入不可";if("COMING_SOON".equals(s))return "未開始";return "状態未確認";}
    private static String price(Long p){return p==null?"—":"¥"+String.format(Locale.JAPAN,"%,d",p);}
    private String dateTime(long t){return DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(t));}
    private String shortDate(long t){return new java.text.SimpleDateFormat("M/d",Locale.JAPAN).format(new Date(t));}
    private Long number(String s){try{String v=s==null?"":s.replace(",","").trim();return v.isBlank()?null:Long.parseLong(v);}catch(Exception e){return null;}}

    private TextView field(String label,String value){LinearLayout b=new LinearLayout(host);return text(label+"  "+value,12,TEXT,false);}
    private EditText input(String hint){EditText e=new EditText(host);e.setSingleLine(true);e.setTextColor(DGRAY);e.setHintTextColor(GRAY);e.setTextSize(14);e.setHint(hint);e.setPadding(dp(12),0,dp(12),0);e.setBackground(roundRect(WHITE,999));return e;}
    private TextView text(String s,float size,int color,boolean bold){TextView t=new TextView(host);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setIncludeFontPadding(false);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private TextView capsule(String s,int color,float size){TextView t=text(s,size,TEXT,true);t.setGravity(Gravity.CENTER);t.setBackground(roundRect(color,999));t.setPadding(dp(8),0,dp(8),0);return t;}
    private TextView tagChip(String s,boolean add){TextView t=capsule(s,add?ORANGE:GRAY,12);t.setPadding(dp(10),0,dp(10),0);t.setMinHeight(dp(30));return t;}
    private GradientDrawable roundRect(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable circle(int color){GradientDrawable d=new GradientDrawable();d.setShape(GradientDrawable.OVAL);d.setColor(color);return d;}
    private LinearLayout.LayoutParams lp(int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,top,0,bottom);return p;}
    private int dp(int v){return Math.round(v*host.getResources().getDisplayMetrics().density);}
    private void showDialog(Dialog d) {
        Window w = d.getWindow();
        int width = host.getResources().getDisplayMetrics().widthPixels - dp(32);
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            WindowManager.LayoutParams params = w.getAttributes();
            params.width = width;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.gravity = Gravity.CENTER;
            params.windowAnimations = 0; // no side-sliding before the first layout
            w.setAttributes(params);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                    | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        d.show();
        if (w != null) w.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private static final class RoundPlusIcon extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fg = new Paint(Paint.ANTI_ALIAS_FLAG);
        RoundPlusIcon(Activity c, int background, int iconColor) {
            super(c);
            bg.setColor(background);
            bg.setStyle(Paint.Style.FILL);
            fg.setColor(iconColor);
            fg.setStyle(Paint.Style.STROKE);
            fg.setStrokeCap(Paint.Cap.ROUND);
            fg.setStrokeWidth(c.getResources().getDisplayMetrics().density * 2.4f);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight(), cx=w/2f, cy=h/2f;
            float r=Math.min(w,h)*.48f;
            c.drawCircle(cx,cy,r,bg);
            float arm=r*.43f;
            c.drawLine(cx-arm,cy,cx+arm,cy,fg);
            c.drawLine(cx,cy-arm,cx,cy+arm,fg);
        }
    }

    private static final class SearchIcon extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        SearchIcon(Activity c){super(c);p.setColor(WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(c.getResources().getDisplayMetrics().density*2.8f);p.setStrokeCap(Paint.Cap.ROUND);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();float r=Math.min(w,h)*.27f;float cx=w*.43f,cy=h*.43f;c.drawCircle(cx,cy,r,p);c.drawLine(cx+r*.72f,cy+r*.72f,w*.78f,h*.78f,p);}
    }

    private static final class Flow extends ViewGroup {
        private final int gap;
        Flow(Activity c){super(c);gap=Math.round(6*c.getResources().getDisplayMetrics().density);}
        @Override protected LayoutParams generateDefaultLayoutParams(){return new MarginLayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);}
        @Override public LayoutParams generateLayoutParams(android.util.AttributeSet attrs){return new MarginLayoutParams(getContext(),attrs);}
        @Override protected LayoutParams generateLayoutParams(LayoutParams p){return new MarginLayoutParams(p);}
        @Override protected boolean checkLayoutParams(LayoutParams p){return p instanceof MarginLayoutParams;}
        @Override protected void onMeasure(int ws,int hs){int w=MeasureSpec.getSize(ws),x=getPaddingLeft(),y=getPaddingTop(),line=0;for(int i=0;i<getChildCount();i++){View v=getChildAt(i);measureChild(v,ws,hs);if(x+v.getMeasuredWidth()+getPaddingRight()>w&&x>getPaddingLeft()){x=getPaddingLeft();y+=line+gap;line=0;}x+=v.getMeasuredWidth()+gap;line=Math.max(line,v.getMeasuredHeight());}setMeasuredDimension(w,y+line+getPaddingBottom());}
        @Override protected void onLayout(boolean ch,int l,int t,int r,int b){int x=getPaddingLeft(),y=getPaddingTop(),line=0,w=r-l;for(int i=0;i<getChildCount();i++){View v=getChildAt(i);if(x+v.getMeasuredWidth()+getPaddingRight()>w&&x>getPaddingLeft()){x=getPaddingLeft();y+=line+gap;line=0;}v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());x+=v.getMeasuredWidth()+gap;line=Math.max(line,v.getMeasuredHeight());}}
    }
}
