package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Yodobashi mode ONLY; product-level selectors never fall back to generic retail HTML. */
final class YodobashiProductExtractor {
    private static final Pattern H1=Pattern.compile("(?is)<h1\\b[^>]*>(.*?)</h1>");
    private YodobashiProductExtractor(){}
    static void parse(String html,URL page,WishlistCrawler.Result out){
        if(WishlistMode.forLargeRetailUrl(page)!=WishlistMode.YODOBASHI||!LargeRetailHtml.validCanonical(html,page)){
            out.availabilityReason="ヨドバシの商品同一性が確認できません";return;
        }
        Matcher m=H1.matcher(html);
        out.title=LargeRetailHtml.cleanTitle(m.find()?m.group(1).replaceAll("<[^>]+>","")
                :LargeRetailHtml.ogTitle(html),"YODOBASHI");
        out.imageUrl=LargeRetailHtml.mainImage(html,"YODOBASHI");
        out.price=LargeRetailHtml.metaYenPrice(html);
        if (out.price == null) out.price=publishedMainPrice(html);
        out.status="UNKNOWN";
        out.availabilityReason="ヨドバシの購入ボタンを商品ID単位でDOM検証待ち";
    }
    /** Published page text, not a guessed or cached Google shopping price.
     * Require an explicit stand-alone "価格:" label AFTER the product H1;
     * MSRP (希望小売価格) and points never count as selling prices. */
    static Long publishedMainPrice(String html) {
        if (html == null || html.length() > 2_000_000) return null;
        Matcher h=H1.matcher(html);
        if (!h.find()) return null;
        String section=html.substring(h.end(),Math.min(html.length(),h.end()+18_000));
        section=section.replaceAll("(?is)<script\\b[^>]*>.*?</script>"," ")
                .replaceAll("(?is)<style\\b[^>]*>.*?</style>"," ")
                .replaceAll("(?is)<(?:br|/div|/p|/dd|/dt|/tr|/td|/li)\\b[^>]*>","\n")
                .replaceAll("(?s)<[^>]*>"," ")
                .replace("&yen;","￥").replace("&#165;","￥").replace("&nbsp;"," ");
        section=section.split("(?:関連商品|こちらもおすすめ|一緒に購入|おすすめ商品)",2)[0];
        Pattern label=Pattern.compile("(?m)(?:^|\\n)\\s*価格\\s*[:：]\\s*[|｜]?\\s*[¥￥]?\\s*([0-9,]{3,11})(?:\\s*円)?");
        Matcher m=label.matcher(section);
        if (!m.find()) return null;
        String number=m.group(1).replace(",","");
        try {
            long value=Long.parseLong(number);
            return value>=100 && value<100_000_000 ? value : null;
        } catch (NumberFormatException ignored) {return null;}
    }
    static String domScript(){return LargeRetailDomScripts.yodobashi();}
}
