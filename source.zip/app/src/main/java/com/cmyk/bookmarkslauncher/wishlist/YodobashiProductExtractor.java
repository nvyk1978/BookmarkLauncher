package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Yodobashi mode ONLY; product-level selectors never fall back to generic retail HTML. */
final class YodobashiProductExtractor {
    private static final Pattern H1=Pattern.compile("(?is)<h1\\b[^>]*>(.*?)</h1>");
    private YodobashiProductExtractor(){}
    static void parse(String html,URL page,WishlistCrawler.Result out){
        if(WishlistMode.forLargeRetailUrl(page)!=WishlistMode.YODOBASHI||!LargeRetailHtml.validCanonical(html,page)){
            out.availabilityReason="ヨドバシの商品同一性が確認できません";return;
        }
        Matcher m=H1.matcher(html);
        out.title=LargeRetailHtml.cleanTitle(m.find()?m.group(1).replaceAll("<[^>]+>","")
                :LargeRetailHtml.ogTitle(html),"YODOBASHI");
        out.imageUrl=LargeRetailHtml.mainImage(html,"YODOBASHI");
        out.price=LargeRetailHtml.metaYenPrice(html);
        if (out.price == null) out.price=publishedMainPrice(html);
        out.status="UNKNOWN";
        out.availabilityReason="ヨドバシの購入ボタンを商品ID単位でDOM検証待ち";
    }
    /** Published page text, not a guessed or cached Google shopping price.
     * Require an explicit stand-alone "価格:" label AFTER the product H1;
     * MSRP (希望小売価格) and points never count as selling prices. */
    static Long publishedMainPrice(String html) {
        if (html == null || html.length() > 2_000_000) return null;
        Matcher h=H1.matcher(html);
        if (!h.find()) return null;
        String section=html.substring(h.end(),Math.min(html.length(),h.end()+18_000));
        section=section.replaceAll("(?is)<script\\b[^>]*>.*?</script>"," ")
                .replaceAll("(?is)<style\\b[^>]*>.*?</style>"," ")
                .replaceAll("(?is)<(?:br|/div|/p|/dd|/dt|/tr|/td|/li)\\b[^>]*>","\n")
                .replaceAll("(?s)<[^>]*>"," ")
                .replace("&yen;","￥").replace("&#165;","￥").replace("&nbsp;"," ");
        section=section.split("(?:関連商品|こちらもおすすめ|一緒に購入|おすすめ商品)",2)[0];
        Pattern label=Pattern.compile("(?m)(?:^|\\n)\\s*価格\\s*[:：]\\s*[|｜]?\\s*[¥￥]?\\s*([0-9,]{3,11})(?:\\s*円)?");
        Matcher m=label.matcher(section);
        if (!m.find()) return null;
        String number=m.group(1).replace(",","");
        try {
            long value=Long.parseLong(number);
            return value>=100 && value<100_000_000 ? value : null;
        } catch (NumberFormatException ignored) {return null;}
    }
    static String domScript(){
        String supplemental = """
if(r.price===null){
 const h1=document.querySelector('h1');
 const heading=h1?String(h1.innerText||h1.textContent||'').trim():'';
 const buy=Array.from(document.querySelectorAll('button,a,input')).find(e=>/ショッピングカートに入れる|カートに入れる/.test(String(e.innerText||e.value||e.getAttribute('aria-label')||'')));
 const priceContainers=[];
 const put=e=>{if(e&&!priceContainers.includes(e))priceContainers.push(e);};
 if(buy){for(let e=buy,n=0;e&&n<5;e=e.parentElement,n++)put(e);}
 if(h1){for(let e=h1,n=0;e&&n<6;e=e.parentElement,n++)put(e);}
 const allPrices=[];
 for(const scope of priceContainers){
   const content=String(scope.innerText||scope.textContent||'').slice(0,6500);
   if(!content)continue;
   const sections=content.split(/関連商品|こちらもおすすめ|よく一緒に購入/);
   // Do not use a number next to an MSRP, delivery fee or unrelated item.
   const block=sections[0]||'';
   const found=[...block.matchAll(/(?:価格|販売価格|税込価格)[：:\\s]*[¥￥]?\\s*([\\d,]{3,11})|[¥￥]\\s*([\\d,]{3,11})\\s*(?:[\\d,]{1,9}\\s*(?:ゴールド)?ポイント)?/g)];
   for(const m of found){
     const head=block.slice(0,m.index).split(String.fromCharCode(10)).pop().slice(-35);
     if(/希望小売|メーカー希望|参考価格|中古|買取|送料|ポイント|還元/.test(head))continue;
     const yen=Number((m[1]||m[2]||'').replace(/,/g,''));
     if(yen>=100&&yen<100000000)allPrices.push({yen,scope:scope.tagName});
   }
 }
 const unique=[...new Set(allPrices.map(x=>x.yen))];
 if(unique.length===1)r.price=unique[0];
 // Summary only: never record page text, URL, or user-specific input in logs.
 r.priceEvidence='h1='+!!heading+',cart='+!!buy+',containers='+priceContainers.length+',candidates='+unique.length;
}
""";

        String stockSupplement = """
// Yodobashi-only stock fallback: a hidden read-only WebView may expose no client rects.
// Never accept generic recommendations or a cart elsewhere on the page.
if(r.status==='UNKNOWN' && /^\\/product\\/[0-9]{12,20}\\/?$/.test(location.pathname)){
 const head=document.querySelector('h1');
 const container=document.querySelector('#productDetail,#productDetails,#detailMain,#productMain,main')||document.body;
 const name=head?String(head.textContent||'').trim():'';
 const usable=e=>{
   if(!e||e.disabled||e.getAttribute('disabled')!==null||e.getAttribute('aria-disabled')==='true')return false;
   for(let n=e;n;n=n.parentElement){
     if(n.hidden||n.getAttribute('aria-hidden')==='true'||n.hasAttribute('inert'))return false;
     const v=getComputedStyle(n);if(v.display==='none'||v.visibility==='hidden'||Number(v.opacity)===0)return false;
   }return true;
 };
 const controls=Array.from(container.querySelectorAll('button,input[type=submit],a[href],[role=button]'))
   .filter(e=>!e.closest('nav,header,footer,aside,[class*=recommend],[class*=related],[id*=recommend],[id*=related]'))
   .filter(e=>/ショッピングカートに入れる|カートに入れる/.test(String(e.innerText||e.textContent||e.value||e.getAttribute('aria-label')||'')));
 const active=controls.filter(usable);
 const panel=active.length===1?(active[0].closest('form,[class*=purchase],[class*=Purchase],[class*=buy],[class*=Buy],[class*=cart],[class*=Cart],section')||active[0].parentElement):null;
 const local=panel?String(panel.innerText||panel.textContent||'').slice(0,1400):'';
 const stocks=Array.from(container.querySelectorAll('[class*=stock],[class*=Stock],[id*=stock],[id*=Stock]'))
   .filter(e=>!e.closest('[class*=recommend],[class*=related],[id*=recommend],[id*=related]'))
   .map(e=>String(e.innerText||e.textContent||'').trim().slice(0,150)).filter(Boolean);
 const pos=stocks.filter(t=>/在庫あり|在庫残少|在庫僅少|残りわずか/.test(t)&&!/在庫なし|販売終了/.test(t));
 const neg=stocks.some(t=>/在庫なし|販売終了|売り切れ|取扱終了/.test(t))||/在庫なし|販売終了|売り切れ/.test(local);
 const near=/在庫あり|在庫残少|在庫僅少|残りわずか/.test(local);
 r.purchaseEvidence='name='+!!name+',cart='+controls.length+',enabled='+active.length+',stock='+pos.length+',near='+near+',negative='+neg;
 // A single live cart inside a main-product form plus matching local stock.
 if(name && active.length===1 && controls.length===1 && !neg && (near || (pos.length===1 && panel))) {
   r.status='AVAILABLE';r.reason='ヨドバシ商品本体の購入ボタンと在庫根拠';
 }
}
""";
        String base=LargeRetailDomScripts.yodobashi();
        return base.replace("return JSON.stringify(r);",supplemental + "\n" + stockSupplement + "\nreturn JSON.stringify(r);");
    }
}
