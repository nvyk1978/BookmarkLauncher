package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Yodobashi mode ONLY; product-level selectors never fall back to generic retail HTML. */
final class YodobashiProductExtractor {
    private static final Pattern H1=Pattern.compile("(?is)<h1\\b[^>]*>(.*?)</h1>");
    private YodobashiProductExtractor(){}
    static void parse(String html,URL page,WishlistCrawler.Result out){
        if(WishlistMode.forLargeRetailUrl(page)!=WishlistMode.YODOBASHI||!LargeRetailHtml.validCanonical(html,page)){
            out.availabilityReason="ヨドバシの商品同一性が確認できません";return;
        }
        Matcher m=H1.matcher(html);
        out.title=LargeRetailHtml.cleanTitle(m.find()?m.group(1).replaceAll("<[^>]+>","")
                :LargeRetailHtml.ogTitle(html),"YODOBASHI");
        out.imageUrl=LargeRetailHtml.mainImage(html,"YODOBASHI");
        out.price=LargeRetailHtml.metaYenPrice(html);
        out.status="UNKNOWN";
        out.availabilityReason="ヨドバシの購入ボタンを商品ID単位でDOM検証待ち";
    }
    static String domScript(){return LargeRetailDomScripts.yodobashi();}
}
