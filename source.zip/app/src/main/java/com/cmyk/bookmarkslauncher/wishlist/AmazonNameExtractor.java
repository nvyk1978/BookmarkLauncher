package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONObject;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Requested product name only; independent of images, stock and price. */
final class AmazonNameExtractor {
    private static final Pattern META=Pattern.compile("(?is)<meta\\b[^>]*>");
    private static final Pattern ATTR=Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')",Pattern.CASE_INSENSITIVE);
    private AmazonNameExtractor(){}
    static String find(String html, URL page) {
        MarketplaceIdentity identity=MarketplaceIdentity.from(page);
        if(identity==null||identity.site!=MarketplaceIdentity.Site.AMAZON||!identity.verified(html,page))return null;
        // Only the requested detail page's main title; never recommendations.
        String main=mainProductTitle(html);
        if(main!=null)return main;
        JSONObject product=AmazonProductJsonLd.find(html,page);
        if(product!=null){
            String name=clean(product.optString("name",null));
            if(name!=null)return name;
        }
        Matcher tags=META.matcher(html);
        while(tags.find()){
            String tag=tags.group();
            String prop=attr(tag,"property");
            if("og:title".equalsIgnoreCase(prop)){String t=clean(attr(tag,"content"));if(t!=null&&!looksBlocked(t))return t;}
        }
        // Some Amazon layouts expose only a standard HTML title; accept it only
        // on a verified ASIN detail URL, never on CAPTCHA/sign-in pages.
        Matcher titleTag=Pattern.compile("(?is)<title\\b[^>]*>(.*?)</title\\s*>").matcher(html);
        if(titleTag.find()){
            String title=clean(titleTag.group(1).replaceAll("(?s)<[^>]*>"," "));
            if(title!=null && title.length()>6 && !looksBlocked(title)
                    && !title.matches("(?is)^(?:Amazon(?:\\.co\\.jp)?|Amazon Shopping)$"))
                return title;
        }
        return null;
    }
    private static String mainProductTitle(String html){
        Matcher m=Pattern.compile("(?is)<(?:span|h1|div)\\b([^>]*\\bid\\s*=\\s*['\"](?:productTitle|title)['\"][^>]*)>(.*?)</(?:span|h1|div)\\s*>").matcher(html);
        while(m.find()){
            String raw=m.group(2).replaceAll("(?s)<[^>]*>"," ");
            String clean=clean(raw);
            if(clean!=null && clean.length()>4 && !looksBlocked(clean))return clean;
        }
        return null;
    }
    private static boolean looksBlocked(String value){
        return value.matches("(?is).*(?:captcha|robot check|access denied|ログインしてください|サインイン|アクセスできません).*?");
    }
    private static String attr(String tag,String name){Matcher m=ATTR.matcher(tag);while(m.find())if(name.equalsIgnoreCase(m.group(1)))return m.group(2)!=null?m.group(2):m.group(3);return null;}
    private static String clean(String s){
        if(s==null)return null;
        String x=s.replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replaceAll("\\s+"," ").trim();
        x=x.replace("&lt;","<").replace("&gt;",">").replace("&nbsp;"," ").replace("&#x27;","'").trim();
        return x.isEmpty()?null:x;
    }
}
