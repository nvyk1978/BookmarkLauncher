package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;

/** Persistent routing mode. UI and all crawls consume the same stored value. */
public enum WishlistMode {
    UNRESOLVED(""), GENERAL(""), AMAZON("Amazon"), RAKUTEN("楽天"), YAHOO("Yahoo!");

    /** Legacy label field is kept for source compatibility, never for routing. */
    public final String label;
    WishlistMode(String label) { this.label = label; }
    /** Presentation only. New small/special modes show a generic chip by default. */
    public String cardLabel() {
        switch (this) {
            case AMAZON: return "Amazon";
            case RAKUTEN: return "楽天";
            case YAHOO: return "Yahoo!";
            case GENERAL:
            case UNRESOLVED: return "";
            default: return "専用モード";
        }
    }
    public static WishlistMode read(String value) {
        if (value != null) try { return valueOf(value); } catch (IllegalArgumentException ignored) { }
        return UNRESOLVED;
    }
    public static WishlistMode forDirectUrl(String raw) {
        try {
            URL u = new URL(raw);
            if (!WishlistCrawler.isAllowedUrl(u)) return UNRESOLVED;
            MarketplaceIdentity id = MarketplaceIdentity.from(u);
            if (id != null) return forSite(id.site);
            if (MarketplaceIdentity.site(u) != MarketplaceIdentity.Site.OTHER || shortened(u)) return UNRESOLVED;
            return GENERAL;
        } catch (Exception ignored) { return UNRESOLVED; }
    }
    public static WishlistMode forSite(MarketplaceIdentity.Site site) {
        if (site == MarketplaceIdentity.Site.AMAZON) return AMAZON;
        if (site == MarketplaceIdentity.Site.RAKUTEN) return RAKUTEN;
        if (site == MarketplaceIdentity.Site.YAHOO) return YAHOO;
        return GENERAL;
    }
    static WishlistMode forResolvedUrl(URL url) {
        if (url == null) return UNRESOLVED;
        MarketplaceIdentity.Site site = MarketplaceIdentity.site(url);
        if (site != MarketplaceIdentity.Site.OTHER)
            return MarketplaceIdentity.from(url) == null ? UNRESOLVED : forSite(site);
        return shortened(url) ? UNRESOLVED : GENERAL;
    }
    private static boolean shortened(URL url) {
        String h = url.getHost().toLowerCase(Locale.ROOT);
        return h.equals("amzn.asia") || h.equals("amzn.to") || h.equals("a.r10.to")
                || h.equals("bit.ly") || h.equals("tinyurl.com") || h.equals("t.co")
                || h.equals("x.gd") || h.equals("is.gd") || h.equals("s.id")
                || h.equals("yahoo.jp") || h.equals("store.shopping.yahoo.co.jp") && MarketplaceIdentity.from(url) == null;
    }
}
