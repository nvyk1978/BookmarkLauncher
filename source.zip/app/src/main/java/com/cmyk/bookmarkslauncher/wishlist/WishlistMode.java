package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;

/** Persistent routing mode. UI and all crawls consume the same stored value. */
public enum WishlistMode {
    UNRESOLVED(""), GENERAL(""), AMAZON("Amazon"), RAKUTEN("楽天"), YAHOO("Yahoo!"), UNIQLO("UNIQLO"), YODOBASHI("ヨドバシ"), BICCAMERA("ビックカメラ");

    /** Legacy label field is kept for source compatibility, never for routing. */
    public final String label;
    WishlistMode(String label) { this.label = label; }
    /** Presentation only. New small/special modes show a generic chip by default. */
    public String cardLabel() {
        switch (this) {
            case AMAZON: return "Amazon";
            case RAKUTEN: return "楽天";
            case YAHOO: return "Yahoo!";
            case UNIQLO: return "UNIQLO";
            case YODOBASHI: return "ヨドバシ";
            case BICCAMERA: return "ビックカメラ";
            case GENERAL:
            case UNRESOLVED: return "";
            default: return "専用モード";
        }
    }
    public static WishlistMode read(String value) {
        if (value != null) try { return valueOf(value); } catch (IllegalArgumentException ignored) { }
        return UNRESOLVED;
    }
    public static WishlistMode forDirectUrl(String raw) {
        try {
            URL u = new URL(raw);
            if (!WishlistCrawler.isAllowedUrl(u)) return UNRESOLVED;
            MarketplaceIdentity id = MarketplaceIdentity.from(u);
            if (id != null) return forSite(id.site);
            WishlistMode giant = forLargeRetailUrl(u);
            if (giant != UNRESOLVED) return giant;
            if (MarketplaceIdentity.site(u) != MarketplaceIdentity.Site.OTHER || shortened(u)) return UNRESOLVED;
            return GENERAL;
        } catch (Exception ignored) { return UNRESOLVED; }
    }
    public static WishlistMode forSite(MarketplaceIdentity.Site site) {
        if (site == MarketplaceIdentity.Site.AMAZON) return AMAZON;
        if (site == MarketplaceIdentity.Site.RAKUTEN) return RAKUTEN;
        if (site == MarketplaceIdentity.Site.YAHOO) return YAHOO;
        return GENERAL;
    }
    static WishlistMode forResolvedUrl(URL url) {
        if (url == null) return UNRESOLVED;
        MarketplaceIdentity.Site site = MarketplaceIdentity.site(url);
        if (site != MarketplaceIdentity.Site.OTHER)
            return MarketplaceIdentity.from(url) == null ? UNRESOLVED : forSite(site);
        WishlistMode giant = forLargeRetailUrl(url);
        if (giant != UNRESOLVED) return giant;
        return shortened(url) ? UNRESOLVED : GENERAL;
    }
    /** Host + product-id validation; never match host suffix without a dot boundary. */
    public static WishlistMode forLargeRetailUrl(URL u) {
        if (u == null || !"https".equalsIgnoreCase(u.getProtocol())) return UNRESOLVED;
        String host = u.getHost().toLowerCase(Locale.ROOT);
        String path = u.getPath();
        if ((host.equals("uniqlo.com") || host.endsWith(".uniqlo.com"))
                && path.matches("(?i)^/jp/ja/products/E[0-9]{6}-[0-9]{3}/[0-9]{2}/?$")) return UNIQLO;
        if ((host.equals("yodobashi.com") || host.endsWith(".yodobashi.com"))
                && path.matches("^/product/[0-9]{12,20}/?$")) return YODOBASHI;
        if ((host.equals("biccamera.com") || host.endsWith(".biccamera.com"))
                && path.matches("^/bc/item/[0-9]{5,15}/?$")) return BICCAMERA;
        return UNRESOLVED;
    }
    /** Only the same retail product may be opened by a hidden probe. */
    public static boolean sameLargeRetailProduct(URL first, URL current) {
        if (first == null || current == null) return false;
        WishlistMode mode = forLargeRetailUrl(first);
        return mode != UNRESOLVED && mode == forLargeRetailUrl(current)
                && first.getPath().replaceAll("/$", "").equalsIgnoreCase(current.getPath().replaceAll("/$", ""));
    }
    /** A clothing variant is a distinct purchasable selection even when its product path matches. */
    public static boolean sameLargeRetailVariant(URL requested, URL loaded) {
        if (!sameLargeRetailProduct(requested, loaded)) return false;
        if (forLargeRetailUrl(requested) != UNIQLO) return true;
        for (String key : new String[]{"colorDisplayCode", "sizeDisplayCode", "pldDisplayCode"}) {
            String expected = queryValue(requested, key);
            String actual = queryValue(loaded, key);
            if (expected == null || actual == null || !expected.equals(actual)) return false;
        }
        return true;
    }
    private static String queryValue(URL url, String key) {
        if (url.getQuery() == null) return null;
        for (String pair : url.getQuery().split("&")) {
            String[] parts = pair.split("=", 2);
            if (parts.length == 2 && key.equals(parts[0])) {
                try { return java.net.URLDecoder.decode(parts[1], java.nio.charset.StandardCharsets.UTF_8); }
                catch (Exception ignored) { return null; }
            }
        }
        return null;
    }
    private static boolean shortened(URL url) {
        String h = url.getHost().toLowerCase(Locale.ROOT);
        return h.equals("amzn.asia") || h.equals("amzn.to") || h.equals("a.r10.to")
                || h.equals("bit.ly") || h.equals("tinyurl.com") || h.equals("t.co")
                || h.equals("x.gd") || h.equals("is.gd") || h.equals("s.id")
                || h.equals("yahoo.jp") || h.equals("store.shopping.yahoo.co.jp") && MarketplaceIdentity.from(url) == null;
    }
}
