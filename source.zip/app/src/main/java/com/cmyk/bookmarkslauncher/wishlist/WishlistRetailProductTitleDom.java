package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/**
 * Title-only rendered evidence for three individual-item routes.
 * This never affects prices, availability or previews.  It is used at the end
 * of an already-running foreground stock probe (not a second parallel WebView).
 */
public final class WishlistRetailProductTitleDom {
    private WishlistRetailProductTitleDom() { }

    public static boolean supports(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())
                || !WishlistCrawler.isAllowedUrl(url)) return false;
        String host=url.getHost().toLowerCase(Locale.ROOT);
        if (WishlistRetailVerifiedMetadataDom.supports(url)) return true;
        if (WishlistJoshinProductIdentity.isDetail(url)) return true;
        if (WishlistMode.isMujiProduct(url)) return true;
        return (host.equals("askul.co.jp") || host.equals("www.askul.co.jp"))
                && url.getPath().matches("(?i)^/p/[A-Za-z0-9_-]{5,20}/?$");
    }

    public static String javascript(URL url) {
        if (!supports(url)) return "JSON.stringify({title:'',reason:'unsupported'})";
        // Exact EDION/ISETAN products use a separate merchant-specific parser,
        // never the ASKUL fallback branch below.
        if (WishlistRetailVerifiedMetadataDom.supports(url))
            return WishlistRetailVerifiedMetadataDom.javascript(url);
        String host=url.getHost().toLowerCase(Locale.ROOT);
        String type=WishlistJoshinProductIdentity.isDetail(url) ? "JOSHIN"
                : WishlistMode.isMujiProduct(url) ? "MUJI" : "ASKUL";
        String path=url.getPath().replaceAll("/+$", "");
        String code=type.equals("JOSHIN") ? WishlistJoshinProductIdentity.itemCode(url)
                : path.substring(path.lastIndexOf('/')+1);
        return SCRIPT.replace("__HOST__",JSONObject.quote(host))
                .replace("__PATH__",JSONObject.quote(path.toLowerCase(Locale.ROOT)))
                .replace("__CODE__",JSONObject.quote(code))
                .replace("__TYPE__",JSONObject.quote(type));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const o={title:'',reason:'unverified'}, done=()=>JSON.stringify(o);
 try {
   const type=__TYPE__,host=__HOST__,path=__PATH__,code=__CODE__;
   const cleanPath=x=>String(x||'').replace(/\\/+$/,'').toLowerCase();
   if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host||
      cleanPath(location.pathname)!==path){o.reason='page-mismatch';return done();}
   const body=document.body;if(!body){o.reason='body-pending';return done();}
   const bad='header,nav,footer,aside,[class*=recommend],[class*=related],'+
     '[class*=ranking],[class*=pickup],[class*=search],[id*=recommend],[id*=related]';
   const norm=t=>String(t||'').replace(/\\u00a0|　/g,' ').replace(/\\s+/g,' ').trim();
   const visible=e=>{if(!e||e.closest(bad))return false;
     for(let p=e;p;p=p.parentElement){if(p.hidden||p.getAttribute('aria-hidden')==='true')return false;
       const s=getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||Number(s.opacity)===0)return false;}
     return true;};
   const main=document.querySelector('main,[role=main],#main,#contents,#content,#productDetail,#product-detail')||body;
   // ASKUL can only title the exact order code shown in the rendered product.
   // An unrelated recommendation or a catalog-wide title is never accepted.
   if(type==='ASKUL'){
     const scope=norm(main.innerText||main.textContent);
     const full=main===body?scope:norm(body.innerText||body.textContent);
     const sku=new RegExp('お申込番号\\s*[:：]?\\s*'+code+'(?![A-Za-z0-9_-])','i');
     if(!sku.test(scope)&&!sku.test(full)){o.reason='sku-not-present';return done();}
   }
   // Reject a contradictory canonical product. Some stores omit the canonical
   // or canonicalize Joshin's category number while keeping the same JAN.
   const canonical=document.querySelector('link[rel=canonical]');
   if(canonical&&canonical.href){
     let c;try{c=new URL(canonical.href,location.href);}catch(_){o.reason='bad-canonical';return done();}
     const cp=cleanPath(c.pathname);
     if(c.hostname.toLowerCase().replace(/^www\\./,'')!==host.replace(/^www\\./,'') ||
        (type==='JOSHIN'?!cp.endsWith('/'+code.toLowerCase()+'.html'):
             type==='MUJI'?!cp.endsWith('/'+code.toLowerCase()):cp!=='/p/'+code.toLowerCase())){
       o.reason='other-item-canonical';return done();}
   }
   const badName=s=>!s||s.length<3||s.length>240||
      /^(?:商品|商品詳細|商品情報|検索結果|お探しのページ|アクセスできません|ページが見つかりません|無印良品|ジョーシン|アスクル|ASKUL|Joshin|配送オプション|商品レビュー|ご注意)$/i.test(s)||
      /(?:403 Forbidden|404 Not Found|503 Service Unavailable|Access Denied|エラーページ)/i.test(s);
   // Product pages sometimes use h6 for the actual title (ASKUL), rather
   // than an h1. Correlate its text with product-specific OGP when possible.
   const og=norm(document.querySelector('meta[property="og:title"]')?.getAttribute('content'));
   const heads=[...main.querySelectorAll('h1')].filter(visible)
       .map(e=>norm(e.innerText||e.textContent)).filter(s=>!badName(s));
   let title=[...new Set(heads)].length===1?heads[0]:'';
   if(!title&&type==='ASKUL'){
     const names=[...main.querySelectorAll('h2,h3,h4,h5,h6, [class*=productName], [class*=productTitle]')]
       .filter(visible).map(e=>norm(e.innerText||e.textContent))
       .filter(s=>s.length>=9&&!badName(s));
     const unique=[...new Set(names)];
     // Require the product heading to be contained within the item's OGP
     // title, or be the only substantial product-name candidate.
     const matching=unique.filter(s=>og&&og.includes(s));
     if(matching.length===1)title=matching[0];
     else if(unique.length===1)title=unique[0];
   }
   if(!title&&type==='JOSHIN'){
     const candidates=[...main.querySelectorAll('h2,h3,[itemprop=name], [class*=productName]')]
       .filter(visible).map(e=>norm(e.innerText||e.textContent))
       .filter(s=>s.length>=8&&!badName(s));
     const matching=[...new Set(candidates.filter(s=>og&&og.includes(s)))];
     if(matching.length===1)title=matching[0];
   }
   if(!title && (type==='ASKUL'||type==='JOSHIN') && og&&!badName(og)){
     // OGP is accepted only after exact item URL+canonical and (for ASKUL)
     // the product's on-page order number; never a blind page-wide guess.
     title=og.replace(/\\s*[|｜-]\\s*(?:アスクル|ASKUL|Joshin webショップ|ジョーシン|Joshin).*$/i,'').trim();
   }
   if(badName(title)){o.reason='title-not-bound';return done();}
   if(type==='JOSHIN'&&(!/^[0-9]{8,15}$/.test(code))){o.reason='invalid-item';return done();}
   if(type==='MUJI'&&(!/^[0-9]{13}$/.test(code))){o.reason='invalid-jan';return done();}
   o.title=title;o.reason='verified-rendered-heading';return done();
 }catch(_){o.reason='script-error';return done();}
})()
""";
}
