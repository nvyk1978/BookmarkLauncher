package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/**
 * Title-only rendered evidence for three individual-item routes.
 * This never affects prices, availability or previews.  It is used at the end
 * of an already-running foreground stock probe (not a second parallel WebView).
 */
public final class WishlistRetailProductTitleDom {
    private WishlistRetailProductTitleDom() { }

    public static boolean supports(URL url) {
        if (url == null || !"https".equalsIgnoreCase(url.getProtocol())
                || !WishlistCrawler.isAllowedUrl(url)) return false;
        String host=url.getHost().toLowerCase(Locale.ROOT);
        if (WishlistRetailVerifiedMetadataDom.supports(url)) return true;
        if (WishlistJoshinProductIdentity.isDetail(url)) return true;
        if (WishlistZozoProductTitleDom.supports(url)) return true;
        if (WishlistMode.isMujiProduct(url)) return true;
        return (host.equals("askul.co.jp") || host.equals("www.askul.co.jp"))
                && url.getPath().matches("(?i)^/p/[A-Za-z0-9_-]{5,20}/?$");
    }

    public static String javascript(URL url) {
        if (!supports(url)) return "JSON.stringify({title:'',reason:'unsupported'})";
        // Exact EDION/ISETAN products use a separate merchant-specific parser,
        // never the ASKUL fallback branch below.
        if (WishlistRetailVerifiedMetadataDom.supports(url))
            return WishlistRetailVerifiedMetadataDom.javascript(url);
        if (WishlistZozoProductTitleDom.supports(url))
            return WishlistZozoProductTitleDom.javascript(url);
        String host=url.getHost().toLowerCase(Locale.ROOT);
        String type=WishlistJoshinProductIdentity.isDetail(url) ? "JOSHIN"
                : WishlistMode.isMujiProduct(url) ? "MUJI" : "ASKUL";
        String path=url.getPath().replaceAll("/+$", "");
        String code=type.equals("JOSHIN") ? WishlistJoshinProductIdentity.itemCode(url)
                : path.substring(path.lastIndexOf('/')+1);
        return SCRIPT.replace("__HOST__",JSONObject.quote(host))
                .replace("__PATH__",JSONObject.quote(path.toLowerCase(Locale.ROOT)))
                .replace("__CODE__",JSONObject.quote(code))
                .replace("__TYPE__",JSONObject.quote(type));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const o={title:'',reason:'unverified',canonicalKind:'none'}, done=()=>JSON.stringify(o);
 try {
   const type=__TYPE__,host=__HOST__,path=__PATH__,code=__CODE__;
   const cleanPath=x=>String(x||'').replace(/\\/+$/,'').toLowerCase();
   if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host||
      cleanPath(location.pathname)!==path){o.reason='page-mismatch';return done();}
   const body=document.body;if(!body){o.reason='body-pending';return done();}
   const bad='header,nav,footer,aside,[class*=recommend],[class*=related],'+
     '[class*=ranking],[class*=pickup],[class*=search],[id*=recommend],[id*=related]';
   const norm=t=>String(t||'').replace(/\\u00a0|　/g,' ').replace(/\\s+/g,' ').trim();
   const visible=e=>{if(!e||e.closest(bad))return false;
     for(let p=e;p;p=p.parentElement){if(p.hidden||p.getAttribute('aria-hidden')==='true')return false;
       const s=getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||Number(s.opacity)===0)return false;}
     return true;};
   const main=document.querySelector('main,[role=main],#main,#contents,#content,#productDetail,#product-detail')||body;
   // ASKUL can only title the exact order code shown in the rendered product.
   // An unrelated recommendation or a catalog-wide title is never accepted.
   if(type==='ASKUL'){
     const scope=norm(main.innerText||main.textContent);
     const full=main===body?scope:norm(body.innerText||body.textContent);
     const sku=new RegExp('(?:お申込番号|お申し込み番号|申込番号|商品番号|商品コード)\\\\s*[:：#]?\\\\s*'+code+'(?![A-Za-z0-9_-])','i');
     if(!sku.test(scope)&&!sku.test(full)){o.reason='sku-not-present';return done();}
   }
   // Reject a contradictory canonical product. Some stores omit the canonical
   // or canonicalize Joshin's category number while keeping the same JAN.
   const canonical=document.querySelector('link[rel=canonical]');
   if(canonical&&canonical.href){
     let c;try{c=new URL(canonical.href,location.href);}catch(_){o.reason='bad-canonical';return done();}
     const cp=cleanPath(c.pathname);
     const hostSame=c.hostname.toLowerCase().replace(/^www\\./,'')===host.replace(/^www\\./,'');
     if(!hostSame){o.canonicalKind='different-host';o.reason='other-site-canonical';return done();}
     if(type==='MUJI'){
       const jan=code.toLowerCase();
       const exact=cp.endsWith('/'+jan);
       // An explicit DIFFERENT 13-digit detail number is never an alias.
       const other=cp.match(/(?:^|\\/)([0-9]{13})(?:$|\\/)/);
       if(other&&other[1]!==jan){o.canonicalKind='different-jan';o.reason='other-item-canonical';return done();}
       if(!exact){
         // Only an independently identified Product schema may verify this
         // saved JAN when a site uses a generic canonical (no SKU in path).
         const bodyText=norm((document.querySelector('main,[role=main],#main,#content')||body).innerText||'');
         const short=jan.slice(-8);
         const shortLabel=new RegExp('商品番号\\\\s*[:：]?\\\\s*'+short+'(?![0-9])');
         let sameSku=false,otherSku=false;
         const checkProduct=x=>{
           if(!x||typeof x!=='object')return;
           if(Array.isArray(x)){for(const y of x.slice(0,30))checkProduct(y);return;}
           const typ=String(x['@type']||'').toLowerCase();
           if(typ==='product'||typ.endsWith('/product')){
             const ids=[x.sku,x.productID,x.productId,x.gtin13,x.gtin]
                .filter(v=>v!=null).map(v=>String(v));
             if(ids.includes(jan)||(ids.includes(short)&&shortLabel.test(bodyText)))sameSku=true;
             if(ids.some(v=>/^[0-9]{13}$/.test(v)&&v!==jan))otherSku=true;
           }
           if(x['@graph'])checkProduct(x['@graph']);
           if(x.mainEntity)checkProduct(x.mainEntity);
         };
         for(const sc of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,24)){
           try{checkProduct(JSON.parse(sc.textContent||'null'));}catch(_){}
         }
         if(!sameSku||otherSku){o.canonicalKind=otherSku?'schema-jan-conflict':'alias-unverified';o.reason=sameSku?'muji-canonical-id-conflict':'muji-canonical-sku-unverified';return done();}
         o.canonicalKind='alias-schema-jan';o.canonicalProof='verified-schema-jan';
       }else{o.canonicalKind='matching-jan';o.canonicalProof='matching-jan';}
     }else if(type==='JOSHIN'?!cp.endsWith('/'+code.toLowerCase()+'.html'):
                       cp!=='/p/'+code.toLowerCase()){
       o.reason='other-item-canonical';return done();}
   }
   const badName=s=>!s||s.length<3||s.length>240||
      /^(?:商品|商品詳細|商品情報|検索結果|お探しのページ|アクセスできません|ページが見つかりません|無印良品|ジョーシン|アスクル|ASKUL|Joshin|配送オプション|商品レビュー|ご注意)$/i.test(s)||
      /(?:403 Forbidden|404 Not Found|503 Service Unavailable|Access Denied|エラーページ)/i.test(s);
   // Product pages sometimes use h6 for the actual title (ASKUL), rather
   // than an h1. Correlate its text with product-specific OGP when possible.
   const og=norm(document.querySelector('meta[property="og:title"]')?.getAttribute('content'));
   const heads=[...main.querySelectorAll('h1')].filter(visible)
       .map(e=>norm(e.innerText||e.textContent)).filter(s=>!badName(s));
   let title=[...new Set(heads)].length===1?heads[0]:'';
   if(type==='ASKUL'&&(!title||!og.includes(title))){
     const names=[...main.querySelectorAll('h2,h3,h4,h5,h6,[itemprop=name], [class*=productName], [class*=productTitle], [class*=itemName], [id*=productName]')]
       .filter(visible).map(e=>norm(e.innerText||e.textContent))
       .filter(s=>s.length>=9&&!badName(s));
     const unique=[...new Set(names)];
     // Require the product heading to be contained within the item's OGP
     // title, or be the only substantial product-name candidate.
     const matching=unique.filter(s=>og&&og.includes(s));
     if(matching.length===1)title=matching[0];
     else if(unique.length===1)title=unique[0];
   }
   if(!title&&type==='MUJI'){
     const names=[...main.querySelectorAll('[itemprop=name],[data-testid*=product],'+
       '[class*=productName],[class*=product-name],[class*=itemName],'+
       '[class*=item-name],#productName,#product-name,h2,h3')]
       .filter(visible).map(e=>norm(e.innerText||e.textContent))
       .filter(s=>s.length>=4&&s.length<=240&&!badName(s));
     const unique=[...new Set(names)];
     const matched=unique.filter(s=>og&&(og.includes(s)||s.includes(og)));
     if(matched.length===1)title=matched[0];
     else if(unique.length===1)title=unique[0];
     // JSON-LD/OG is a fallback only when a visible product name and the
     // exact saved JAN detail URL have BOTH been verified.
   }
   if(!title&&type==='JOSHIN'){
     const candidates=[...main.querySelectorAll('h2,h3,[itemprop=name], [class*=productName]')]
       .filter(visible).map(e=>norm(e.innerText||e.textContent))
       .filter(s=>s.length>=8&&!badName(s));
     const matching=[...new Set(candidates.filter(s=>og&&og.includes(s)))];
     if(matching.length===1)title=matching[0];
   }
   if(!title && (type==='ASKUL'||type==='JOSHIN') && og&&!badName(og)){
     // OGP is accepted only after exact item URL+canonical and (for ASKUL)
     // the product's on-page order number; never a blind page-wide guess.
     title=og.replace(/\\s*[|｜-]\\s*(?:アスクル|ASKUL|Joshin webショップ|ジョーシン|Joshin).*$/i,'').trim();
   }
   if(badName(title)){o.reason='title-not-bound';return done();}
   if(type==='JOSHIN'&&(!/^[0-9]{8,15}$/.test(code))){o.reason='invalid-item';return done();}
   if(type==='MUJI'&&(!/^[0-9]{13}$/.test(code))){o.reason='invalid-jan';return done();}
   o.title=title;o.reason='verified-rendered-heading';return done();
 }catch(_){o.reason='script-error';return done();}
})()
""";
}
