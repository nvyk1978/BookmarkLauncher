package com.cmyk.bookmarkslauncher.wishlist;

import android.content.Context;
import android.view.View;
import android.webkit.WebView;

/**
 * A single-use, DOM/JavaScript-only WebView.  This View is never added to the
 * Activity hierarchy, made transparent or captured as pixels.  It is kept alive
 * only until the bounded DOM probe finishes, then destroyed on the UI thread.
 *
 * Android does not promise fully headless WebView execution on every device;
 * callers must use their existing deadlines and report missing evidence, never
 * silently treat a non-rendered document as product availability.
 */
final class BackgroundDomWebView {
    private BackgroundDomWebView() {}

    static WebView create(Context context) {
        WebView web = new WebView(context);
        web.setWillNotDraw(true);    // no View drawing / Canvas capture
        web.setFocusable(false);
        web.setFocusableInTouchMode(false);
        web.setClickable(false);
        web.setLongClickable(false);
        web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        // Give responsive page JavaScript a realistic viewport without attaching
        // this View to a screen or ever drawing any pixels.
        int width = Math.max(360, context.getResources().getDisplayMetrics().widthPixels);
        int height = Math.max(640, context.getResources().getDisplayMetrics().heightPixels);
        web.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
        web.layout(0, 0, width, height);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.getSettings().setSupportMultipleWindows(false);
        return web;
    }
}
