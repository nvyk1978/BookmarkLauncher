package com.cmyk.bookmarkslauncher;

import android.net.Uri;

import java.util.List;
import java.util.Locale;

/** Utilities for recognizing Google Maps links and extracting a place label without an API key. */
public final class GoogleMapsLink {
    private GoogleMapsLink() {}

    public static boolean isGoogleMapsUrl(String value) {
        if (value == null || value.isBlank()) return false;
        try {
            Uri uri = Uri.parse(value.trim());
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.ROOT);
            String path = uri.getPath();
            if (path == null) path = "";

            if (host.equals("maps.app.goo.gl")) return true;
            if ((host.equals("goo.gl") || host.endsWith(".goo.gl")) && path.startsWith("/maps")) return true;
            if (host.equals("maps.google.com") || host.startsWith("maps.google.")) return true;
            if ((host.equals("google.com") || host.startsWith("google.") || host.endsWith(".google.com") || host.startsWith("www.google."))
                    && path.startsWith("/maps")) return true;
        } catch (Throwable ignored) {
        }
        return false;
    }

    /** Extracts the human-readable segment after /place/ when present in an expanded Maps URL. */
    public static String extractPlaceName(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            Uri uri = Uri.parse(value.trim());
            List<String> segments = uri.getPathSegments();
            for (int i = 0; i + 1 < segments.size(); i++) {
                if ("place".equalsIgnoreCase(segments.get(i))) {
                    String candidate = cleanPlaceName(segments.get(i + 1));
                    if (isUsefulPlaceName(candidate)) return candidate;
                }
            }

            String[] queryKeys = {"q", "query", "destination"};
            for (String key : queryKeys) {
                String candidate = cleanPlaceName(uri.getQueryParameter(key));
                if (isUsefulPlaceName(candidate) && !looksLikeCoordinates(candidate)) return candidate;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }


    /** Best-effort place label carried alongside a Maps URL in Android's share text. */
    public static String extractSharedPlaceName(String sharedText, String url) {
        if (!isGoogleMapsUrl(url) || sharedText == null || sharedText.isBlank()) return null;
        String remaining = sharedText.replace(url == null ? "" : url, "\n");
        String[] lines = remaining.split("\r?\n");
        for (String line : lines) {
            String candidate = cleanPlaceName(line);
            if (!isUsefulPlaceName(candidate)) continue;
            String lower = candidate.toLowerCase(Locale.ROOT);
            if (lower.contains("maps.app.goo.gl") || lower.contains("google.com/maps") || lower.contains("goo.gl/maps")) continue;
            return candidate;
        }
        return null;
    }

    public static String cleanPlaceName(String value) {
        if (value == null) return null;
        String out = value.trim();
        if (out.isEmpty()) return null;

        out = out.replace('+', ' ').trim();
        String[] suffixes = {
                " - Google マップ", " – Google マップ", " — Google マップ", " · Google マップ", " | Google マップ",
                " - Google Maps", " – Google Maps", " — Google Maps", " · Google Maps", " | Google Maps"
        };
        for (String suffix : suffixes) {
            if (out.endsWith(suffix)) {
                out = out.substring(0, out.length() - suffix.length()).trim();
                break;
            }
        }
        return isUsefulPlaceName(out) ? out : null;
    }

    public static boolean isUsefulPlaceName(String value) {
        if (value == null) return false;
        String s = value.trim();
        if (s.isEmpty()) return false;
        String lower = s.toLowerCase(Locale.ROOT);
        return !lower.equals("google maps")
                && !s.equals("Google マップ")
                && !lower.equals("maps")
                && !lower.startsWith("http://")
                && !lower.startsWith("https://");
    }

    private static boolean looksLikeCoordinates(String value) {
        if (value == null) return false;
        return value.matches("\\s*-?\\d{1,3}(?:\\.\\d+)?\\s*,\\s*-?\\d{1,3}(?:\\.\\d+)?\\s*");
    }
}
