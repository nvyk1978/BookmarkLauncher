package com.cmyk.bookmarkslauncher;

import android.net.Uri;

import java.util.List;
import java.util.Locale;

/** Utilities for recognizing Google Maps links and extracting a place label without an API key. */
public final class GoogleMapsLink {
    private GoogleMapsLink() {}

    private static final String[] MAP_SUFFIXES = {
            " - Google マップ", " – Google マップ", " — Google マップ", " · Google マップ", " | Google マップ",
            " - Google Maps", " – Google Maps", " — Google Maps", " · Google Maps", " | Google Maps"
    };

    private static final String[] PREFECTURES = {
            "北海道", "青森県", "岩手県", "宮城県", "秋田県", "山形県", "福島県",
            "茨城県", "栃木県", "群馬県", "埼玉県", "千葉県", "東京都", "神奈川県",
            "新潟県", "富山県", "石川県", "福井県", "山梨県", "長野県", "岐阜県",
            "静岡県", "愛知県", "三重県", "滋賀県", "京都府", "大阪府", "兵庫県",
            "奈良県", "和歌山県", "鳥取県", "島根県", "岡山県", "広島県", "山口県",
            "徳島県", "香川県", "愛媛県", "高知県", "福岡県", "佐賀県", "長崎県",
            "熊本県", "大分県", "宮崎県", "鹿児島県", "沖縄県"
    };

    public static boolean isGoogleMapsUrl(String value) {
        if (value == null || value.isBlank()) return false;
        try {
            Uri uri = Uri.parse(value.trim());
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.ROOT);
            String path = uri.getPath();
            if (path == null) path = "";

            if (host.equals("maps.app.goo.gl")) return true;
            if ((host.equals("goo.gl") || host.endsWith(".goo.gl")) && path.startsWith("/maps")) return true;
            if (host.equals("maps.google.com") || host.startsWith("maps.google.")) return true;
            if ((host.equals("google.com") || host.startsWith("google.") || host.endsWith(".google.com") || host.startsWith("www.google."))
                    && path.startsWith("/maps")) return true;
        } catch (Throwable ignored) {
        }
        return false;
    }

    /** Extracts the human-readable segment after /place/ when present in an expanded Maps URL. */
    public static String extractPlaceName(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            Uri uri = Uri.parse(value.trim());
            List<String> segments = uri.getPathSegments();
            for (int i = 0; i + 1 < segments.size(); i++) {
                if ("place".equalsIgnoreCase(segments.get(i))) {
                    String candidate = cleanPlaceName(segments.get(i + 1));
                    if (isUsefulPlaceName(candidate) && !looksLikeAddress(candidate)) return candidate;
                }
            }

            String[] queryKeys = {"q", "query", "destination"};
            for (String key : queryKeys) {
                String candidate = cleanPlaceName(uri.getQueryParameter(key));
                if (isUsefulPlaceName(candidate) && !looksLikeCoordinates(candidate) && !looksLikeAddress(candidate)) return candidate;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Best-effort place label carried alongside a Maps URL in Android's share text. */
    public static String extractSharedPlaceName(String sharedText, String url) {
        if (!isGoogleMapsUrl(url) || sharedText == null || sharedText.isBlank()) return null;
        String remaining = sharedText.replace(url == null ? "" : url, "\n");
        String[] lines = remaining.split("\r?\n");
        for (String line : lines) {
            String candidate = cleanPlaceName(line);
            if (!isUsefulPlaceName(candidate) || looksLikeAddress(candidate)) continue;
            String lower = candidate.toLowerCase(Locale.ROOT);
            if (lower.contains("maps.app.goo.gl") || lower.contains("google.com/maps") || lower.contains("goo.gl/maps")) continue;
            return candidate;
        }
        return null;
    }

    /**
     * Normalizes a Google Maps page/OG title into a shop/facility name.
     * Google often appends a postal address to the visible page title; only the name portion is kept.
     */
    public static String cleanPlaceName(String value) {
        if (value == null) return null;
        String out = value.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
        if (out.isEmpty()) return null;

        for (String suffix : MAP_SUFFIXES) {
            if (out.endsWith(suffix)) {
                out = out.substring(0, out.length() - suffix.length()).trim();
                break;
            }
        }

        out = stripTrailingAddress(out);
        return isUsefulPlaceName(out) && !looksLikeAddress(out) ? out : null;
    }

    public static boolean isUsefulPlaceName(String value) {
        if (value == null) return false;
        String s = value.trim();
        if (s.isEmpty()) return false;
        String lower = s.toLowerCase(Locale.ROOT);
        return !lower.equals("google maps")
                && !s.equals("Google マップ")
                && !lower.equals("maps")
                && !lower.startsWith("http://")
                && !lower.startsWith("https://")
                && !isWebErrorTitle(s);
    }

    public static boolean isWebErrorTitle(String value) {
        if (value == null) return false;
        String s = value.trim().toLowerCase(Locale.ROOT);
        return s.contains("ウェブページへのアクセス不可")
                || s.contains("webページへのアクセス不可")
                || s.contains("このウェブページにアクセスできません")
                || s.contains("ページを表示できません")
                || s.contains("webpage not available")
                || s.contains("this webpage is not available")
                || s.contains("this site can’t be reached")
                || s.contains("this site can't be reached")
                || s.startsWith("err_");
    }

    private static String stripTrailingAddress(String value) {
        String out = value == null ? "" : value.trim();
        if (out.isEmpty()) return out;

        // Postal code is an especially strong boundary even when Maps omitted a separator.
        java.util.regex.Matcher postal = java.util.regex.Pattern
                .compile("(?:\\s*[·|｜,、\\-–—]\\s*)?〒?\\s*\\d{3}-?\\d{4}(?:\\s|$)")
                .matcher(out);
        if (postal.find() && postal.start() > 0) {
            String left = trimTrailingSeparator(out.substring(0, postal.start()));
            if (!left.isBlank()) return left;
        }

        // Prefer explicit title/address separators. Only cut when the right hand side actually
        // looks like an address, so names containing punctuation are preserved.
        String[] separators = {" · ", " | ", "｜", " – ", " — ", " - ", ", ", "、"};
        for (String separator : separators) {
            int from = 0;
            while (true) {
                int index = out.indexOf(separator, from);
                if (index < 0) break;
                String right = out.substring(index + separator.length()).trim();
                if (looksLikeAddress(right)) {
                    String left = trimTrailingSeparator(out.substring(0, index));
                    if (!left.isBlank()) return left;
                }
                from = index + separator.length();
            }
        }

        // Some Maps titles concatenate the place and prefecture with whitespace only.
        int prefectureIndex = firstPrefectureIndex(out);
        if (prefectureIndex > 0) {
            String right = out.substring(prefectureIndex);
            if (looksLikeAddress(right)) {
                String left = trimTrailingSeparator(out.substring(0, prefectureIndex));
                if (!left.isBlank()) return left;
            }
        }
        return out;
    }

    private static String trimTrailingSeparator(String value) {
        if (value == null) return "";
        return value.replaceAll("[\\s·|｜,、\\-–—]+$", "").trim();
    }

    private static int firstPrefectureIndex(String value) {
        int best = -1;
        for (String prefecture : PREFECTURES) {
            int i = value.indexOf(prefecture);
            if (i > 0 && (best < 0 || i < best)) best = i;
        }
        return best;
    }

    private static boolean looksLikeAddress(String value) {
        if (value == null) return false;
        String s = value.replace('\u00A0', ' ').trim();
        if (s.isEmpty()) return false;
        if (s.matches(".*〒?\\s*\\d{3}-?\\d{4}.*")) return true;

        boolean hasPrefecture = false;
        for (String prefecture : PREFECTURES) {
            if (s.contains(prefecture)) {
                hasPrefecture = true;
                break;
            }
        }
        if (hasPrefecture && (s.matches(".*[市区町村郡].*") || s.matches(".*\\d+.*"))) return true;
        if (s.matches(".*\\d+丁目.*") || s.matches(".*\\d+番地.*") || s.matches(".*\\d+番.*\\d*号?.*")) return true;
        return s.matches(".*(?:^|\\s)\\d{1,4}[-−ー]\\d{1,4}(?:[-−ー]\\d{1,4})?(?:\\s|$).*" );
    }

    private static boolean looksLikeCoordinates(String value) {
        if (value == null) return false;
        return value.matches("\\s*-?\\d{1,3}(?:\\.\\d+)?\\s*,\\s*-?\\d{1,3}(?:\\.\\d+)?\\s*");
    }
}
