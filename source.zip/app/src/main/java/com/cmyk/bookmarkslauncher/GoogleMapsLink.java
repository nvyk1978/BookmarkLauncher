package com.cmyk.bookmarkslauncher;

import android.net.Uri;

import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Utilities for recognizing Google Maps links and extracting place metadata without an API key. */
public final class GoogleMapsLink {
    private GoogleMapsLink() {}

    private static final String[] MAP_SUFFIXES = {
            " - Google マップ", " – Google マップ", " — Google マップ", " · Google マップ", " | Google マップ",
            " - Google Maps", " – Google Maps", " — Google Maps", " · Google Maps", " | Google Maps"
    };

    private static final String[] PREFECTURES = {
            "北海道", "青森県", "岩手県", "宮城県", "秋田県", "山形県", "福島県",
            "茨城県", "栃木県", "群馬県", "埼玉県", "千葉県", "東京都", "神奈川県",
            "新潟県", "富山県", "石川県", "福井県", "山梨県", "長野県", "岐阜県",
            "静岡県", "愛知県", "三重県", "滋賀県", "京都府", "大阪府", "兵庫県",
            "奈良県", "和歌山県", "鳥取県", "島根県", "岡山県", "広島県", "山口県",
            "徳島県", "香川県", "愛媛県", "高知県", "福岡県", "佐賀県", "長崎県",
            "熊本県", "大分県", "宮崎県", "鹿児島県", "沖縄県"
    };

    private static final Pattern AT_COORDS = Pattern.compile(
            "@(-?\\d{1,2}(?:\\.\\d+)?),(-?\\d{1,3}(?:\\.\\d+)?)");
    // Google Maps place URLs usually carry the actual POI coordinates in
    // !8m2!3d<lat>!4d<lng>. The @lat,lng segment is commonly only the
    // viewport center, so it must never outrank the POI data.
    private static final Pattern POI_DATA_COORDS = Pattern.compile(
            "!8m2!3d(-?\\d{1,2}(?:\\.\\d+)?)!4d(-?\\d{1,3}(?:\\.\\d+)?)");
    private static final Pattern DATA_COORDS = Pattern.compile(
            "!3d(-?\\d{1,2}(?:\\.\\d+)?)!4d(-?\\d{1,3}(?:\\.\\d+)?)");
    private static final Pattern LAT_LNG_PAIR = Pattern.compile(
            "^\\s*(-?\\d{1,2}(?:\\.\\d+)?)\\s*,\\s*(-?\\d{1,3}(?:\\.\\d+)?)\\s*$");

    public static final class Coordinates {
        public final double latitude;
        public final double longitude;

        public Coordinates(double latitude, double longitude) {
            this.latitude = latitude;
            this.longitude = longitude;
        }

        public boolean isValid() {
            return latitude >= -90d && latitude <= 90d && longitude >= -180d && longitude <= 180d;
        }
    }

    public static boolean isGoogleMapsUrl(String value) {
        if (value == null || value.isBlank()) return false;
        try {
            Uri uri = Uri.parse(value.trim());
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.ROOT);
            String path = uri.getPath();
            if (path == null) path = "";

            if (host.equals("maps.app.goo.gl")) return true;
            if ((host.equals("goo.gl") || host.endsWith(".goo.gl")) && path.startsWith("/maps")) return true;
            if (host.equals("maps.google.com") || host.startsWith("maps.google.")) return true;
            if ((host.equals("google.com") || host.startsWith("google.") || host.endsWith(".google.com") || host.startsWith("www.google."))
                    && path.startsWith("/maps")) return true;
        } catch (Throwable ignored) {
        }
        return false;
    }

    public static boolean isShortGoogleMapsUrl(String value) {
        if (value == null || value.isBlank()) return false;
        try {
            Uri uri = Uri.parse(value.trim());
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.ROOT);
            String path = uri.getPath() == null ? "" : uri.getPath();
            return host.equals("maps.app.goo.gl")
                    || ((host.equals("goo.gl") || host.endsWith(".goo.gl")) && path.startsWith("/maps"));
        } catch (Throwable ignored) {
            return false;
        }
    }

    /** Extracts the human-readable segment after /place/ when present in an expanded Maps URL. */
    public static String extractPlaceName(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            Uri uri = Uri.parse(value.trim());
            List<String> segments = uri.getPathSegments();
            for (int i = 0; i + 1 < segments.size(); i++) {
                if ("place".equalsIgnoreCase(segments.get(i))) {
                    String candidate = cleanPlaceName(segments.get(i + 1));
                    if (isUsefulPlaceName(candidate) && !looksLikeAddress(candidate)) return candidate;
                }
            }

            String[] queryKeys = {"q", "query", "destination"};
            for (String key : queryKeys) {
                String candidate = cleanPlaceName(uri.getQueryParameter(key));
                if (isUsefulPlaceName(candidate) && !looksLikeCoordinates(candidate) && !looksLikeAddress(candidate)) return candidate;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /**
     * Extracts the best available destination coordinate. Kept for callers that
     * want a one-shot result; capture code should prefer extractPreciseCoordinates()
     * first and only use extractViewportCoordinates() after canonical navigation.
     */
    public static Coordinates extractCoordinates(String value) {
        Coordinates precise = extractPreciseCoordinates(value);
        return precise != null ? precise : extractViewportCoordinates(value);
    }

    /**
     * Coordinates that identify a requested place/destination rather than the map camera.
     */
    public static Coordinates extractPreciseCoordinates(String value) {
        if (value == null || value.isBlank()) return null;
        String raw = value.trim();

        // 1) Explicit place/POI coordinate pair.
        Coordinates coordinates = matchLastCoordinates(POI_DATA_COORDS.matcher(raw));
        if (coordinates != null) return coordinates;

        // 2) Other !3d..!4d pairs. Use the last valid pair because canonical
        // place URLs append destination data after viewport/navigation data.
        coordinates = matchLastCoordinates(DATA_COORDS.matcher(raw));
        if (coordinates != null) return coordinates;

        // 3) Explicit destination/search coordinate parameters.
        try {
            Uri uri = Uri.parse(raw);
            String[] keys = {"destination", "q", "query"};
            for (String key : keys) {
                Coordinates fromQuery = parseCoordinatePair(uri.getQueryParameter(key));
                if (fromQuery != null) return fromQuery;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /**
     * Camera/viewport coordinates. These are deliberately a last resort because
     * Google Maps can preserve a completely unrelated map center in @lat,lng.
     */
    public static Coordinates extractViewportCoordinates(String value) {
        if (value == null || value.isBlank()) return null;
        String raw = value.trim();
        try {
            Uri uri = Uri.parse(raw);
            String[] keys = {"ll", "center"};
            for (String key : keys) {
                Coordinates fromQuery = parseCoordinatePair(uri.getQueryParameter(key));
                if (fromQuery != null) return fromQuery;
            }
        } catch (Throwable ignored) {
        }
        return matchLastCoordinates(AT_COORDS.matcher(raw));
    }

    private static Coordinates matchCoordinates(Matcher matcher) {
        if (!matcher.find()) return null;
        return coordinatesFromGroups(matcher);
    }

    private static Coordinates matchLastCoordinates(Matcher matcher) {
        Coordinates last = null;
        while (matcher.find()) {
            Coordinates current = coordinatesFromGroups(matcher);
            if (current != null) last = current;
        }
        return last;
    }

    private static Coordinates coordinatesFromGroups(Matcher matcher) {
        try {
            Coordinates result = new Coordinates(Double.parseDouble(matcher.group(1)), Double.parseDouble(matcher.group(2)));
            return result.isValid() ? result : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static Coordinates parseCoordinatePair(String value) {
        if (value == null) return null;
        Matcher matcher = LAT_LNG_PAIR.matcher(value);
        return matchCoordinates(matcher);
    }

    /** Best-effort place label carried alongside a Maps URL in Android's share text. */
    public static String extractSharedPlaceName(String sharedText, String url) {
        if (!isGoogleMapsUrl(url) || sharedText == null || sharedText.isBlank()) return null;
        String remaining = sharedText.replace(url == null ? "" : url, "\n");
        String[] lines = remaining.split("\r?\n");
        for (String line : lines) {
            String candidate = cleanPlaceName(line);
            if (!isUsefulPlaceName(candidate) || looksLikeAddress(candidate)) continue;
            String lower = candidate.toLowerCase(Locale.ROOT);
            if (lower.contains("maps.app.goo.gl") || lower.contains("google.com/maps") || lower.contains("goo.gl/maps")) continue;
            return candidate;
        }
        return null;
    }

    /**
     * Normalizes a Google Maps page/OG title into a shop/facility name.
     * Google often appends a postal address to the visible page title; only the name portion is kept.
     */
    public static String cleanPlaceName(String value) {
        if (value == null) return null;
        String out = value.replace('\u00A0', ' ').replace('\u3000', ' ').replace('+', ' ').replaceAll("\\s+", " ").trim();
        if (out.isEmpty()) return null;

        for (String suffix : MAP_SUFFIXES) {
            if (out.endsWith(suffix)) {
                out = out.substring(0, out.length() - suffix.length()).trim();
                break;
            }
        }

        // Some Maps titles are emitted as "<postal address> <shop name>".
        // Recover the trailing shop/facility name before the normal trailing-address stripper.
        String afterAddress = extractTrailingNameAfterAddress(out);
        if (afterAddress != null) return afterAddress;

        out = stripTrailingAddress(out);
        return isUsefulPlaceName(out) && !looksLikeAddress(out) ? out : null;
    }

    public static boolean isUsefulPlaceName(String value) {
        if (value == null) return false;
        String s = value.trim();
        if (s.isEmpty()) return false;
        String lower = s.toLowerCase(Locale.ROOT);
        return !lower.equals("google maps")
                && !s.equals("Google マップ")
                && !lower.equals("maps")
                && !lower.startsWith("http://")
                && !lower.startsWith("https://")
                && !isWebErrorTitle(s);
    }

    public static boolean isWebErrorTitle(String value) {
        if (value == null) return false;
        String s = value.trim().toLowerCase(Locale.ROOT);
        return s.contains("ウェブページへのアクセス不可")
                || s.contains("webページへのアクセス不可")
                || s.contains("このウェブページにアクセスできません")
                || s.contains("ページを表示できません")
                || s.contains("webpage not available")
                || s.contains("this webpage is not available")
                || s.contains("this site can’t be reached")
                || s.contains("this site can't be reached")
                || s.startsWith("err_");
    }

    /**
     * Maps occasionally returns titles such as
     * "〒275-0011 千葉県... 2階 串じまん 大久保店".
     * Find the first whitespace boundary where the left side is clearly an
     * address and the right side is clearly not; the right side is the place name.
     */
    private static String extractTrailingNameAfterAddress(String value) {
        if (value == null) return null;
        String s = value.replace('\u3000', ' ').replaceAll("\\s+", " ").trim();
        if (s.isEmpty() || !looksLikeAddress(s)) return null;

        Matcher spaces = Pattern.compile("\\s+").matcher(s);
        while (spaces.find()) {
            String left = s.substring(0, spaces.start()).trim();
            String right = s.substring(spaces.end()).trim();
            if (left.isEmpty() || right.isEmpty()) continue;
            if (!looksLikeAddress(left)) continue;
            if (!isUsefulPlaceName(right) || looksLikeAddress(right) || looksLikeCoordinates(right)) continue;
            return trimTrailingSeparator(right);
        }
        return null;
    }

    private static String stripTrailingAddress(String value) {
        String out = value == null ? "" : value.trim();
        if (out.isEmpty()) return out;

        java.util.regex.Matcher postal = java.util.regex.Pattern
                .compile("(?:\\s*[·|｜,、\\-–—]\\s*)?〒?\\s*\\d{3}-?\\d{4}(?:\\s|$)")
                .matcher(out);
        if (postal.find() && postal.start() > 0) {
            String left = trimTrailingSeparator(out.substring(0, postal.start()));
            if (!left.isBlank()) return left;
        }

        String[] separators = {" · ", " | ", "｜", " – ", " — ", " - ", ", ", "、"};
        for (String separator : separators) {
            int from = 0;
            while (true) {
                int index = out.indexOf(separator, from);
                if (index < 0) break;
                String right = out.substring(index + separator.length()).trim();
                if (looksLikeAddress(right)) {
                    String left = trimTrailingSeparator(out.substring(0, index));
                    if (!left.isBlank()) return left;
                }
                from = index + separator.length();
            }
        }

        int prefectureIndex = firstPrefectureIndex(out);
        if (prefectureIndex > 0) {
            String right = out.substring(prefectureIndex);
            if (looksLikeAddress(right)) {
                String left = trimTrailingSeparator(out.substring(0, prefectureIndex));
                if (!left.isBlank()) return left;
            }
        }
        return out;
    }

    private static String trimTrailingSeparator(String value) {
        if (value == null) return "";
        return value.replaceAll("[\\s·|｜,、\\-–—]+$", "").trim();
    }

    private static int firstPrefectureIndex(String value) {
        int best = -1;
        for (String prefecture : PREFECTURES) {
            int i = value.indexOf(prefecture);
            if (i > 0 && (best < 0 || i < best)) best = i;
        }
        return best;
    }

    private static boolean looksLikeAddress(String value) {
        if (value == null) return false;
        String s = normalizeAddressDigits(value.replace('\u00A0', ' ').replace('\u3000', ' ').trim());
        if (s.isEmpty()) return false;
        if (s.matches(".*〒?\\s*\\d{3}-?\\d{4}.*")) return true;

        boolean hasPrefecture = false;
        for (String prefecture : PREFECTURES) {
            if (s.contains(prefecture)) {
                hasPrefecture = true;
                break;
            }
        }
        if (hasPrefecture && (s.matches(".*[市区町村郡].*") || s.matches(".*\\d+.*"))) return true;
        if (s.matches(".*\\d+丁目.*") || s.matches(".*\\d+番地.*") || s.matches(".*\\d+番.*\\d*号?.*")) return true;
        if (s.matches(".*(?:^|\\s)\\d+\\s*(?:階|F)(?:\\s|$).*")) return true;
        return s.matches(".*(?:^|\\s)\\d{1,4}[-−ー]\\d{1,4}(?:[-−ー]\\d{1,4})?(?:\\s|$).*" );
    }

    private static String normalizeAddressDigits(String value) {
        if (value == null || value.isEmpty()) return value;
        StringBuilder out = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c >= '０' && c <= '９') c = (char) ('0' + (c - '０'));
            else if (c == 'Ｆ' || c == 'ｆ') c = 'F';
            out.append(c);
        }
        return out.toString();
    }

    private static boolean looksLikeCoordinates(String value) {
        if (value == null) return false;
        return LAT_LNG_PAIR.matcher(value).matches();
    }
}
