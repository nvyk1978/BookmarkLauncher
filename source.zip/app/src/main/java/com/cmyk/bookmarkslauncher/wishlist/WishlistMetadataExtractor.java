package com.cmyk.bookmarkslauncher.wishlist;

import android.text.Html;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Product name/image/availability pipeline. Never reads or writes prices. */
final class WishlistMetadataExtractor {
    private static final Pattern META = Pattern.compile("<meta\\b[^>]*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern ATTRIBUTE = Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern TITLE = Pattern.compile("<title\\b[^>]*>(.*?)</title\\s*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern LINK = Pattern.compile("<link\\b[^>]*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern IMAGE = Pattern.compile("<img\\b[^>]*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern JSON_LD = Pattern.compile("<script\\b([^>]*)>(.*?)</script\\s*>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    static Result parse(String html, URL page) {
        Result out = new Result();
        Map<String,String> meta = new HashMap<>();
        Matcher m = META.matcher(html);
        while (m.find()) {
            Map<String,String> attrs = attributes(m.group());
            String key = coalesce(attrs.get("property"),attrs.get("name"),attrs.get("itemprop"));
            String val = clean(attrs.get("content"));
            if (key != null && val != null) meta.putIfAbsent(key.toLowerCase(Locale.ROOT),val);
        }
        out.title = coalesce(meta.get("og:title"),meta.get("twitter:title"),clean(first(html,TITLE)));
        out.imageUrl = absoluteImage(page,coalesce(meta.get("og:image:secure_url"),meta.get("og:image"),meta.get("twitter:image"),meta.get("twitter:image:src")));
        Product product = findProduct(html);
        if (product.name != null) out.title=product.name;
        if (product.image != null) {
            String image=absoluteImage(page,product.image);
            if (image != null) out.imageUrl=image;
        }
        if (out.imageUrl == null) out.imageUrl=fallbackImage(html,page);
        // Completely independent product-stock analysis. Never infer sold-out
        // from arbitrary page/footer/hidden-template text.
        WishlistAvailabilityExtractor.Result stock = WishlistAvailabilityExtractor.parse(
                html, page, product.availability, meta.get("product:availability"));
        out.availabilityExplicit = stock.explicit;
        out.status = stock.status;
        return out;
    }
    static final class Result {String title;String imageUrl;String status="UNKNOWN";boolean availabilityExplicit;}
    private static final class Product {String name,image,availability;}

    private static Product findProduct(String html) {
        Product output = new Product();
        Matcher scripts = JSON_LD.matcher(html);
        while (scripts.find()) {
            Map<String, String> attrs = attributes(scripts.group(1));
            String mime = attrs.get("type");
            if (mime == null || !mime.toLowerCase(Locale.ROOT).startsWith("application/ld+json")) continue;
            try {
                String json = scripts.group(2).trim().replaceAll("(?s)^<!--|-->$", "");
                Object node = json.startsWith("[") ? new JSONArray(json) : new JSONObject(json);
                if (searchProduct(node, output, 0)) break;
            } catch (Exception ignored) { /* Keep OGP fallback on malformed JSON-LD. */ }
        }
        return output;
    }
    private static boolean searchProduct(Object node, Product out, int depth) {
        if (depth > 9) return false;
        if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < Math.min(a.length(), 60); i++) if (searchProduct(a.opt(i), out, depth + 1)) return true;
        } else if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            if (isProductType(obj.opt("@type"))) {
                out.name = clean(obj.optString("name", null));
                out.image = imageValue(obj.opt("image"));
                findAvailability(obj.opt("offers"),out,0);
                return true;
            }
            // Products are commonly nested under @graph, mainEntity or itemListElement.
            String[] fields = {"@graph", "mainEntity", "itemListElement", "item", "about", "hasPart"};
            for (String key : fields) if (searchProduct(obj.opt(key), out, depth + 1)) return true;
        }
        return false;
    }
    private static void findAvailability(Object offers, Product out,int depth) {
        if (depth > 6 || offers == null || out.availability != null) return;
        if (offers instanceof JSONArray) {
            JSONArray arr=(JSONArray)offers;
            for(int i=0;i<Math.min(20,arr.length());i++) findAvailability(arr.opt(i),out,depth+1);
        } else if(offers instanceof JSONObject) {
            JSONObject o=(JSONObject)offers;
            String availability=clean(o.optString("availability",null));
            if (availability != null) out.availability=availability;
            findAvailability(o.opt("offers"),out,depth+1);
        }
    }

    private static boolean isProductType(Object types) {
        if (types instanceof JSONArray) {
            JSONArray a = (JSONArray) types;
            for (int i = 0; i < a.length(); i++) if (isProductType(a.opt(i))) return true;
        }
        if (types instanceof String) {
            String s = ((String) types).toLowerCase(Locale.ROOT);
            return s.equals("product") || s.endsWith("/product") || s.endsWith(":product");
        }
        return false;
    }

    private static String fallbackImage(String html, URL page) {
        Matcher links = LINK.matcher(html);
        while (links.find()) {
            Map<String, String> attrs = attributes(links.group());
            String rel = attrs.get("rel");
            if (rel != null && rel.toLowerCase(Locale.ROOT).contains("image_src")) {
                String candidate = absoluteImage(page, clean(attrs.get("href")));
                if (candidate != null) return candidate;
            }
        }
        Matcher images = IMAGE.matcher(html);
        while (images.find()) {
            Map<String, String> attrs = attributes(images.group());
            String id = attrs.get("id");
            boolean productImage = "landingImage".equalsIgnoreCase(id) || "imgBlkFront".equalsIgnoreCase(id)
                    || attrs.containsKey("data-a-dynamic-image");
            if (!productImage) continue;
            String candidate = absoluteImage(page, clean(coalesce(attrs.get("data-old-hires"), attrs.get("data-src"), attrs.get("src"))));
            if (candidate != null) return candidate;
            String dynamic = clean(attrs.get("data-a-dynamic-image"));
            if (dynamic == null) continue;
            try {
                JSONObject urls = new JSONObject(dynamic);
                java.util.Iterator<String> keys = urls.keys();
                while (keys.hasNext()) {
                    candidate = absoluteImage(page, keys.next());
                    if (candidate != null) return candidate;
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    private static String imageValue(Object obj) {
        if (obj instanceof String) return clean((String) obj);
        if (obj instanceof JSONArray) {
            JSONArray a = (JSONArray) obj;
            for (int i = 0; i < a.length(); i++) {
                String s = imageValue(a.opt(i));
                if (s != null) return s;
            }
        }
        if (obj instanceof JSONObject) {
            JSONObject o = (JSONObject) obj;
            return coalesce(o.optString("url", null), o.optString("contentUrl", null));
        }
        return null;
    }

    private static Map<String, String> attributes(String tag) {
        Map<String, String> out = new HashMap<>();
        Matcher a = ATTRIBUTE.matcher(tag);
        while (a.find()) {
            String key = a.group(1).toLowerCase(Locale.ROOT);
            out.putIfAbsent(key, coalesce(a.group(2), a.group(3), a.group(4)));
        }
        return out;
    }

    private static String absoluteImage(URL page, String raw) {
        if (raw == null) return null;
        try {
            URL image = new URL(page, raw.trim());
            return WishlistCrawler.isAllowedUrl(image) && "https".equalsIgnoreCase(image.getProtocol()) ? image.toString() : null;
        } catch (Exception ignored) { return null; }
    }

    private static String first(String text, Pattern p) { Matcher m = p.matcher(text); return m.find() ? m.group(1) : null; }

    private static String clean(String s) {
        if (s == null) return null;
        String cleaned = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\\s+", " ").trim();
        return cleaned.isBlank() ? null : cleaned;
    }

    private static String coalesce(String... values) { for (String s : values) if (s != null && !s.isBlank()) return s; return null; }
}
