package com.cmyk.bookmarkslauncher.wishlist;

import android.content.Context;
import android.content.SharedPreferences;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Deterministic, stable numbered catalogue for read-only item inspection.
 *  Existing source techniques are TRIAL until a fresh name, image and stock
 *  success qualifies them. Numbers remain reserved across upgrades. Uncompiled
 *  dynamic engines remain UNKNOWN rather than impersonating native scrapers.
 *  Persistent WishlistMode and existing saved-card data remain unchanged. */
public final class WishlistNumberedTechniqueRegistry {
    private WishlistNumberedTechniqueRegistry() { }
    public static final String[] BUILTIN = new String[]{
        "GENERAL-STANDARD",
        "ASKUL-SKU-QUANTITY",
        "YODOBASHI-BUYBOX",
        "BICCAMERA-OFFER",
        "UNIQLO-VARIANT",
        "MUJI-DYNAMIC",
        "ZOZO-VARIANT-ROWS",
        "MERCARI-LISTING",
        "HIRAKI-COLOR-SKU",
        "FUMUROYA-PRODUCT-QUANTITY",
        "JR-CENTRAL-SELECTED-BUNDLE",
        "HONMA-GROSS-PRICE-CART",
        "ASKUL-EXACT-PRODUCT",
        "MONOTARO-ORDER-CODE",
        "YUIKAN-ITEM",
        "NAKASHIMA-ITEM",
        "TORIKAN-ITEM",
        "GREENBEANS-ITEM",
        "LOHACO-ITEM",
        "GU-COLOR-SIZE",
        "EDION-PRODUCT",
        "AU-PRODUCT",
        "ISETAN-PRODUCT",
        "AMAZON-BUYBOX",
        "RAKUTEN-OFFER",
        "YAHOO-PRODUCT",
        "SHEIN-PRODUCT",
        "TEMU-PRODUCT",
        "ALIEXPRESS-PRODUCT",
        "JOSHIN-PRODUCT",
        "NITORI-PRODUCT",
        "CAINZ-PRODUCT",
        "UNIQLO-EXACT-VARIANT",
        "YODOBASHI-EXACT-ITEM",
        "BICCAMERA-EXACT-ITEM",
        "MUJI-EXACT-ITEM",
        "ZOZO-EXACT-DID",
        "MERCARI-EXACT-LISTING",
        "GREENBEANS-EXACT-ITEM",
        "LOHACO-EXACT-ITEM"
    };
    private static final String PREF = "wishlist_numbered_techniques_183";
    private static final String KEY = "extra_modes";
    private static final String VERIFIED_KEY = "verified_three_field_modes";
    public static String number(int index) { return String.format(Locale.ROOT,"%03d",index); }
    public static int builtinCount() { return BUILTIN.length; }
    /** Slots from v0.1.183 that had only stock proof retain their positions
     * but are INACTIVE until three new independently verified fields qualify. */
    private static List<String> rawCatalog(Context context) {
        ArrayList<String> all=new ArrayList<>();
        for(String b:BUILTIN)all.add(b);
        if(context==null)return all;
        String saved=context.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE)
                .getString(KEY,"");
        if(!saved.isEmpty())for(String x:saved.split("\n"))
            if(x.matches("[A-Z0-9_-]{3,80}")&&!all.contains(x))all.add(x);
        return all;
    }
    public static synchronized List<String> catalog(Context context) {
        List<String> all=rawCatalog(context);
        if(context==null)return all;
        String qualified=context.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE)
                .getString(VERIFIED_KEY,"");
        java.util.HashSet<String> active=new java.util.HashSet<>();
        for(String k:qualified.split("\n"))if(!k.isEmpty())active.add(k);
        // Existing numbered merchant slots are trial techniques until the
        // dedicated source succeeds for ALL THREE fields in a fresh update.
        // Trial scripts may run for discovery, but must not be described as a
        // registered/verified three-field engine.
        for(int i=8;i<BUILTIN.length;i++)
            if(!active.contains(all.get(i)))all.set(i,"TRIAL-"+all.get(i));
        for(int i=BUILTIN.length;i<all.size();i++)
            if(!active.contains(all.get(i)))all.set(i,"PENDING-"+all.get(i));
        return all;
    }
    /** Old stock-only auto-registration is FORBIDDEN since v0.1.184. */
    @Deprecated public static synchronized String registerDedicatedSuccess(Context context, String key, String status) {
        return "";
    }
    /** Only three verified, fresh fields from a single card refresh qualify. */
    public static synchronized String registerDedicatedSuccess(Context context, String key,
                                String status, boolean imageVerified, boolean titleVerified,
                                boolean stateVerified) {
        if (!imageVerified || !titleVerified || !stateVerified) return "";
        if (context == null || key == null || !("AVAILABLE".equals(status)||"UNAVAILABLE".equals(status))) return "";
        String normalized=key.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9_-]","-");
        if (!normalized.matches("[A-Z0-9_-]{3,80}")) return "";
        List<String> all=rawCatalog(context);
        int id=all.indexOf(normalized);
        if(id<0 && all.size()>=999)return "";
        SharedPreferences prefs=context.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String qualified=prefs.getString(VERIFIED_KEY,"");
        boolean alreadyVerified=("\n"+qualified).contains("\n"+normalized+"\n");
        if(id>=0 && (id<8||alreadyVerified))return number(id);
        StringBuilder extra=new StringBuilder();
        for(int i=BUILTIN.length;i<all.size();i++)extra.append(all.get(i)).append('\n');
        if(id<0)extra.append(normalized).append('\n');
        // One atomic commit: no stock-only label can run as an active profile.
        // Fixed builtins (008+) gain qualified status only after three proofs.
        boolean committed=prefs.edit().putString(KEY,extra.toString())
                .putString(VERIFIED_KEY,qualified+normalized+'\n').commit();
        return committed?number(id>=0?id:all.size()):"";
    }
    public static String dedicatedKey(URL url, WishlistMode mode) {
        if (url==null || mode==null) return "";
        if (mode!=WishlistMode.GENERAL) {
            switch (mode) {
                case MUJI: return "MUJI-EXACT-ITEM";
                case UNIQLO: return "UNIQLO-EXACT-VARIANT";
                case YODOBASHI: return "YODOBASHI-EXACT-ITEM";
                case BICCAMERA: return "BICCAMERA-EXACT-ITEM";
                case AMAZON: return "AMAZON-BUYBOX";
                case RAKUTEN: return "RAKUTEN-OFFER";
                case YAHOO: return "YAHOO-PRODUCT";
                default: return "DEDICATED-"+mode.name();
            }
        }
        String host=url.getHost().toUpperCase(Locale.ROOT);
        // Preserve builtin numbers even for canonical root hosts. Previous
        // code minted spurious DEDICATED-* slots for exactly these stores.
        if ((host.equals("HONMA-STORE.NET") || host.equals("WWW.HONMA-STORE.NET"))
                && url.getPath().matches("(?i)^/shop/products/view/[1-9][0-9]{0,9}(?:/category(?::|%3a)[0-9]{1,7})?/?$"))
            return "HONMA-GROSS-PRICE-CART";
        if (host.equals("YUICAN-SHOP.COM") || host.equals("WWW.YUICAN-SHOP.COM"))
            return "YUIKAN-ITEM";
        if (host.equals("ZOZO.JP") || host.endsWith(".ZOZO.JP"))
            return "ZOZO-EXACT-DID";
        if (host.equals("MERCARI.COM") || host.endsWith(".MERCARI.COM")) return "MERCARI-EXACT-LISTING";
        if (host.equals("GU-GLOBAL.COM") || host.endsWith(".GU-GLOBAL.COM")) return "GU-COLOR-SIZE";
        if (host.endsWith(".FUMUROYA.COM")) return "FUMUROYA-PRODUCT-QUANTITY";
        if (host.endsWith(".JR-CENTRAL.CO.JP")) return "JR-CENTRAL-SELECTED-BUNDLE";
        if (host.equals("HIRAKI.CO.JP") || host.endsWith(".HIRAKI.CO.JP")) return "HIRAKI-COLOR-SKU";
        if (host.contains("ASKUL.CO.JP")) return "ASKUL-EXACT-PRODUCT";
        if (host.endsWith(".ZOZO.JP")) return "ZOZO-EXACT-DID";
        if (host.endsWith(".EDION.COM")) return "EDION-PRODUCT";
        if (host.contains("AU.COM")||host.contains("WOWMA.JP")) return "AU-PRODUCT";
        if (host.endsWith(".MISTORE.JP")) return "ISETAN-PRODUCT";
        if (host.equals("GREENBEANS.COM") || host.endsWith(".GREENBEANS.COM")) return "GREENBEANS-EXACT-ITEM";
        if (host.equals("LOHACO.YAHOO.CO.JP")) return "LOHACO-EXACT-ITEM";
        host=host.replaceAll("[^A-Z0-9_-]","-");
        return "DEDICATED-"+host;
    }
}
