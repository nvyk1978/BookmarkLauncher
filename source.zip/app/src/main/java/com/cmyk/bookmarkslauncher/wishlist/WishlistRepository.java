package com.cmyk.bookmarkslauncher.wishlist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class WishlistRepository {
    private final Db helper;
    private final Context appContext;

    public WishlistRepository(Context context) {
        appContext = context.getApplicationContext();
        helper = new Db(appContext);
    }

    public WishlistItem addFromBookmark(BookmarkNode node) {
        if (node == null || node.url == null || node.url.isBlank() || node.isFolder() || node.isApp() || node.isQr()) return null;
        WishlistItem existing = findBySourceOrUrl(node.id, node.url);
        if (existing != null) return existing;
        long now = System.currentTimeMillis();
        WishlistItem item = new WishlistItem();
        item.id = UUID.randomUUID().toString();
        item.sourceNodeId = node.id;
        item.title = node.displayName();
        item.url = node.url;
        item.sourceName = node.siteNameOrFallback();
        item.thumbnailPath = node.screenshotPath;
        item.faviconPath = node.faviconPath;
        item.status = "UNKNOWN";
        item.previousStatus = "UNKNOWN";
        item.sortIndex = nextSortIndex();
        item.createdAt = now;
        item.updatedAt = now;
        ContentValues v = values(item);
        helper.getWritableDatabase().insertOrThrow("wish_items", null, v);
        return item;
    }

    public WishlistItem addUrl(String title, String url) {
        return addUrl(title, url, "");
    }

    public WishlistItem addUrl(String title, String url, String note) {
        if (url == null || url.isBlank()) return null;
        WishlistItem existing = findBySourceOrUrl(null, url);
        if (existing != null) {
            if (note != null && !note.isBlank() && (existing.note == null || existing.note.isBlank())) {
                setNote(existing.id, note.trim());
                existing.note = note.trim();
            }
            return existing;
        }
        long now = System.currentTimeMillis();
        WishlistItem item = new WishlistItem();
        item.id = UUID.randomUUID().toString();
        item.title = title == null || title.isBlank() ? url : title.trim();
        item.userTitleEdited = title != null && !title.isBlank();
        item.url = url.trim();
        item.note = note == null ? "" : note.trim();
        item.status = "UNKNOWN";
        item.previousStatus = "UNKNOWN";
        item.sortIndex = nextSortIndex();
        item.createdAt = now;
        item.updatedAt = now;
        helper.getWritableDatabase().insertOrThrow("wish_items", null, values(item));
        return item;
    }

    public WishlistItem get(String id) {
        if (id == null) return null;
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, "id=?", new String[]{id}, null, null, null, "1")) {
            return c.moveToFirst() ? readItem(c) : null;
        }
    }

    public List<WishlistItem> listAll() {
        List<WishlistItem> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, null, null, null, null, "sort_index ASC, created_at ASC")) {
            while (c.moveToNext()) out.add(readItem(c));
        }
        return out;
    }

    public List<WishlistItem> listMonitored() {
        List<WishlistItem> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, "monitor_resume=1", null, null, null, "sort_index ASC")) {
            while (c.moveToNext()) out.add(readItem(c));
        }
        return out;
    }

    public void updateOrder(List<String> ids) {
        if (ids == null) return;
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < ids.size(); i++) {
                ContentValues v = new ContentValues();
                v.put("sort_index", i);
                v.put("updated_at", System.currentTimeMillis());
                db.update("wish_items", v, "id=?", new String[]{ids.get(i)});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    /** Keep the note independent of crawler metadata, title, images and price history. */
    public void setNote(String id, String note) {
        if (id == null) return;
        ContentValues v = new ContentValues();
        v.put("note", note == null ? "" : note);
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
    }

    public void rename(String id, String title) {
        ContentValues v = new ContentValues();
        v.put("title", title == null ? "" : title.trim());
        v.put("user_title_edited", 1);
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
    }

    public void delete(String id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("item_tags", "item_id=?", new String[]{id});
            db.delete("price_history", "item_id=?", new String[]{id});
            db.delete("purchase_history", "item_id=?", new String[]{id});
            db.delete("wish_items", "id=?", new String[]{id});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        WishlistPreviewStore.delete(appContext, id);
    }

    public void setMonitor(String id, boolean enabled) {
        ContentValues v = new ContentValues();
        v.put("monitor_resume", enabled ? 1 : 0);
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
    }

    /** Coordinates two isolated DB paths; price updates never depend on metadata. */
    public void updateCrawl(String id, WishlistCrawler.Result result) {
        if (result == null) return;
        // Price and metadata writes must survive independent failures.
        try {
            if (result.success && result.priceQuote != null)
                updatePriceQuoteOnly(id, result.priceQuote);
            else updatePriceOnly(id, result.success ? result.price : null, result.failureReason, "crawl");
        } catch (RuntimeException ignored) { /* Metadata must still be updated. */ }
        try {
            updateMetadataOnly(id, result);
        } catch (RuntimeException ignored) { /* Price must stay saved. */ }
    }

    public boolean hasUsablePreview(String id) {
        WishlistItem item = get(id);
        return item != null && WishlistPreviewStore.isUsableSavedImage(item.previewPath);
    }

    private void updateMetadataOnly(String id, WishlistCrawler.Result result) {
        if (!result.success) return;
        WishlistItem before=get(id);
        if (before == null) return;
        String preview=null;
        if (!before.userImageEdited && result.imageUrl!=null && !result.imageUrl.isBlank()) {
            if (!result.imageUrl.equals(before.previewImageUrl)
                    || !WishlistPreviewStore.isUsableSavedImage(before.previewPath)) {
                preview=WishlistPreviewStore.save(appContext,id,result.imageUrl);
            }
        }
        ContentValues v=new ContentValues();
        if (!before.userTitleEdited && result.title!=null && !result.title.isBlank())
            v.put("title",result.title.trim());
        if (result.sourceName!=null && !result.sourceName.isBlank())v.put("source_name",result.sourceName.trim());
        if(preview!=null){v.put("preview_image_url",result.imageUrl);v.put("preview_path",preview);}
        if(result.status!=null && !result.status.isBlank()){
            v.put("previous_status",before.status==null?"UNKNOWN":before.status);
            v.put("status",result.status);
        }
        if(v.size()==0)return;
        v.put("updated_at",System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items",v,"id=?",new String[]{id});
    }

    /** Image-only path; a failed image download never edits a name, price or price history. */
    public boolean updateImageFromWebView(String id, String imageUrl, String productPageUrl) {
        if (id == null || imageUrl == null || imageUrl.isBlank()) return false;
        WishlistItem before = get(id);
        if (before == null || before.userImageEdited) return false;
        // Preserve an already downloaded preview (including an eventual user-selected one).
        if (WishlistPreviewStore.isUsableSavedImage(before.previewPath)) return true;
        String saved = WishlistPreviewStore.save(appContext, id, imageUrl, productPageUrl);
        if (saved == null) return false;
        ContentValues v = new ContentValues();
        v.put("preview_image_url", imageUrl);
        v.put("preview_path", saved);
        v.put("updated_at", System.currentTimeMillis());
        return helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id}) > 0;
    }

    /** User photo is independent of crawler metadata and all price writes. */
    public boolean setManualImage(String id, android.net.Uri imageUri) {
        if (id == null || imageUri == null || get(id) == null) return false;
        String saved = WishlistPreviewStore.saveSelected(appContext, id, imageUri);
        if (saved == null) return false;
        ContentValues fields = new ContentValues();
        fields.put("preview_path", saved);
        fields.putNull("preview_image_url");
        fields.put("user_image_edited", 1);
        fields.put("updated_at", System.currentTimeMillis());
        return helper.getWritableDatabase().update("wish_items", fields, "id=?", new String[]{id}) > 0;
    }

    private void updatePriceOnly(String id,Long price,String failure,String origin) {
        if(id==null)return;
        WishlistItem before=get(id);
        if(before==null)return;
        long now=System.currentTimeMillis();
        SQLiteDatabase db=helper.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues v=new ContentValues();
            v.put("last_price_checked_at",now);
            v.put("updated_at",now);
            if(price!=null){
                v.putNull("price_quote_kind");
                v.putNull("price_minimum");
                v.putNull("price_maximum");
                v.put("current_price",price);
                if(before.registeredPrice==null)v.put("registered_price",price);
                v.put("price_fetch_ok",1);
                v.putNull("last_price_error");
                Long lastRecorded=latestRecordedPrice(id);
                if(lastRecorded==null || !lastRecorded.equals(price)){
                    ContentValues point=new ContentValues();
                    point.put("item_id",id);
                    point.put("price",price);
                    point.put("checked_at",now);
                    point.put("source",origin);
                    db.insert("price_history",null,point);
                }
            }else{
                v.put("price_fetch_ok",0);
                v.put("last_price_error",failure==null?"価格情報を特定できず":failure);
            }
            db.update("wish_items",v,"id=?",new String[]{id});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }

    /** A minimum or interval is display-only, NEVER an exact price/history point. */
    private void updatePriceQuoteOnly(String id, WishlistRetailPriceQuote quote) {
        if (id == null || quote == null || get(id) == null) return;
        ContentValues v = new ContentValues();
        v.putNull("current_price"); // Never present an old exact value as today's price.
        v.put("price_quote_kind", quote.kind);
        v.put("price_minimum", quote.minimum);
        if (quote.maximum != null) v.put("price_maximum", quote.maximum);
        else v.putNull("price_maximum");
        v.put("price_fetch_ok", 1);
        v.putNull("last_price_error");
        v.put("last_price_checked_at", System.currentTimeMillis());
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
    }

    /** Foreground WebView also treats minimum prices as ranges, never exact history. */
    public void updatePriceQuoteFromWebView(String id, WishlistRetailPriceQuote quote) {
        updatePriceQuoteOnly(id, quote);
    }

    /** Price-only WebView fallback. It cannot touch names, images, or availability. */
    public void updatePriceFromWebView(String id,Long price,String failure) {
        updatePriceOnly(id,price,failure,"webview");
    }

    private Long latestRecordedPrice(String id) {
        try (Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT price FROM price_history WHERE item_id=? ORDER BY checked_at DESC, id DESC LIMIT 1",
                new String[]{id})) {
            return c.moveToFirst() && !c.isNull(0) ? c.getLong(0) : null;
        }
    }

    public List<PricePoint> priceHistory(String itemId, int limit) {
        List<PricePoint> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("price_history", new String[]{"price","checked_at"},
                "item_id=?", new String[]{itemId}, null, null, "checked_at DESC, id DESC", String.valueOf(Math.max(1, limit)))) {
            while (c.moveToNext()) out.add(new PricePoint(c.getLong(0), c.getLong(1)));
        }
        return out;
    }

    public void addPurchase(String itemId, Long price) {
        ContentValues v = new ContentValues();
        v.put("item_id", itemId);
        if (price != null) v.put("price", price);
        v.put("purchased_at", System.currentTimeMillis());
        helper.getWritableDatabase().insert("purchase_history", null, v);
    }

    public List<Purchase> purchases(String itemId, int limit) {
        List<Purchase> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("purchase_history", new String[]{"id","price","purchased_at"},
                "item_id=?", new String[]{itemId}, null, null, "purchased_at DESC, id DESC", limit <= 0 ? null : String.valueOf(limit))) {
            while (c.moveToNext()) out.add(new Purchase(c.getLong(0), c.isNull(1) ? null : c.getLong(1), c.getLong(2)));
        }
        return out;
    }

    public int purchaseCount(String itemId) {
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM purchase_history WHERE item_id=?", new String[]{itemId})) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public void deletePurchase(long purchaseId) {
        helper.getWritableDatabase().delete("purchase_history", "id=?", new String[]{String.valueOf(purchaseId)});
    }

    public List<Tag> listTags() {
        List<Tag> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("tags", new String[]{"id","name","sort_index"}, null, null, null, null, "sort_index ASC, id ASC")) {
            while (c.moveToNext()) out.add(new Tag(c.getLong(0), c.getString(1), c.getInt(2)));
        }
        return out;
    }

    public Tag createTag(String name) {
        if (name == null || name.trim().isBlank()) return null;
        String clean = name.trim();
        SQLiteDatabase db = helper.getWritableDatabase();
        try (Cursor c = db.query("tags", new String[]{"id","name","sort_index"}, "name=? COLLATE NOCASE", new String[]{clean}, null, null, null, "1")) {
            if (c.moveToFirst()) return new Tag(c.getLong(0), c.getString(1), c.getInt(2));
        }
        int sortIndex = nextTagSortIndex();
        ContentValues v = new ContentValues();
        v.put("name", clean);
        v.put("sort_index", sortIndex);
        long id = db.insert("tags", null, v);
        return id < 0 ? null : new Tag(id, clean, sortIndex);
    }

    public void renameTag(long id, String name) {
        if (name == null || name.trim().isBlank()) return;
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        try {
            helper.getWritableDatabase().update("tags", v, "id=?", new String[]{String.valueOf(id)});
        } catch (android.database.sqlite.SQLiteConstraintException ignored) {
            // Keep the existing tag if the requested name already exists.
        }
    }

    public void deleteTag(long id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("item_tags", "tag_id=?", new String[]{String.valueOf(id)});
            db.delete("tags", "id=?", new String[]{String.valueOf(id)});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public void setTagOrder(List<Long> ids) {
        if (ids == null) return;
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < ids.size(); i++) {
                Long id = ids.get(i);
                if (id == null) continue;
                ContentValues v = new ContentValues();
                v.put("sort_index", i);
                db.update("tags", v, "id=?", new String[]{String.valueOf(id)});
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public Set<Long> tagsForItem(String itemId) {
        Set<Long> out = new HashSet<>();
        try (Cursor c = helper.getReadableDatabase().query("item_tags", new String[]{"tag_id"}, "item_id=?", new String[]{itemId}, null, null, "tag_id ASC")) {
            while (c.moveToNext()) out.add(c.getLong(0));
        }
        return out;
    }

    public void addTagToItem(String itemId, long tagId) {
        if (itemId == null || itemId.isBlank() || tagId <= 0) return;
        ContentValues v = new ContentValues();
        v.put("item_id", itemId);
        v.put("tag_id", tagId);
        helper.getWritableDatabase().insertWithOnConflict(
                "item_tags", null, v, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void removeTagFromItem(String itemId, long tagId) {
        if (itemId == null || itemId.isBlank() || tagId <= 0) return;
        helper.getWritableDatabase().delete(
                "item_tags", "item_id=? AND tag_id=?",
                new String[]{itemId, String.valueOf(tagId)});
    }

    public void setTagsForItem(String itemId, Set<Long> ids) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("item_tags", "item_id=?", new String[]{itemId});
            if (ids != null) for (Long id : ids) {
                if (id == null) continue;
                ContentValues v = new ContentValues();
                v.put("item_id", itemId);
                v.put("tag_id", id);
                db.insertWithOnConflict("item_tags", null, v, SQLiteDatabase.CONFLICT_IGNORE);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public List<Tag> tagsForItemResolved(String itemId) {
        List<Tag> out = new ArrayList<>();
        String sql = "SELECT t.id,t.name,t.sort_index FROM tags t JOIN item_tags it ON it.tag_id=t.id WHERE it.item_id=? ORDER BY t.sort_index ASC,t.id ASC";
        try (Cursor c = helper.getReadableDatabase().rawQuery(sql, new String[]{itemId})) {
            while (c.moveToNext()) out.add(new Tag(c.getLong(0), c.getString(1), c.getInt(2)));
        }
        return out;
    }

    private WishlistItem findBySourceOrUrl(String sourceId, String url) {
        String sel;
        String[] args;
        if (sourceId != null && !sourceId.isBlank()) {
            sel = "source_node_id=? OR url=?";
            args = new String[]{sourceId, url};
        } else {
            sel = "url=?";
            args = new String[]{url};
        }
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, sel, args, null, null, null, "1")) {
            return c.moveToFirst() ? readItem(c) : null;
        }
    }

    private int nextSortIndex() {
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COALESCE(MAX(sort_index),-1)+1 FROM wish_items", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private int nextTagSortIndex() {
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COALESCE(MAX(sort_index),-1)+1 FROM tags", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private ContentValues values(WishlistItem item) {
        ContentValues v = new ContentValues();
        v.put("id", item.id);
        v.put("source_node_id", item.sourceNodeId);
        v.put("title", item.title);
        v.put("url", item.url);
        v.put("source_name", item.sourceName);
        v.put("note", item.note == null ? "" : item.note);
        v.put("thumbnail_path", item.thumbnailPath);
        v.put("favicon_path", item.faviconPath);
        v.put("preview_image_url", item.previewImageUrl);
        v.put("preview_path", item.previewPath);
        v.put("user_title_edited", item.userTitleEdited ? 1 : 0);
        v.put("user_image_edited", item.userImageEdited ? 1 : 0);
        if (item.registeredPrice != null) v.put("registered_price", item.registeredPrice);
        if (item.currentPrice != null) v.put("current_price", item.currentPrice);
        v.put("price_quote_kind", item.priceQuoteKind);
        if (item.priceMinimum != null) v.put("price_minimum", item.priceMinimum);
        if (item.priceMaximum != null) v.put("price_maximum", item.priceMaximum);
        if (item.lastPriceCheckedAt != null) v.put("last_price_checked_at", item.lastPriceCheckedAt);
        v.put("price_fetch_ok", item.priceFetchOk ? 1 : 0);
        v.put("last_price_error", item.lastPriceError);
        v.put("status", item.status == null ? "UNKNOWN" : item.status);
        v.put("previous_status", item.previousStatus == null ? "UNKNOWN" : item.previousStatus);
        v.put("monitor_resume", item.monitorResume ? 1 : 0);
        v.put("sort_index", item.sortIndex);
        v.put("created_at", item.createdAt);
        v.put("updated_at", item.updatedAt);
        return v;
    }

    private WishlistItem readItem(Cursor c) {
        WishlistItem i = new WishlistItem();
        i.id = s(c, "id");
        i.sourceNodeId = s(c, "source_node_id");
        i.title = s(c, "title");
        i.url = s(c, "url");
        i.sourceName = s(c, "source_name");
        i.note = s(c, "note");
        i.thumbnailPath = s(c, "thumbnail_path");
        i.faviconPath = s(c, "favicon_path");
        i.previewImageUrl = s(c, "preview_image_url");
        i.previewPath = s(c, "preview_path");
        i.userTitleEdited = integer(c, "user_title_edited") != 0;
        i.userImageEdited = integer(c, "user_image_edited") != 0;
        i.registeredPrice = lng(c, "registered_price");
        i.currentPrice = lng(c, "current_price");
        i.priceQuoteKind = s(c, "price_quote_kind");
        i.priceMinimum = lng(c, "price_minimum");
        i.priceMaximum = lng(c, "price_maximum");
        i.lastPriceCheckedAt = lng(c, "last_price_checked_at");
        i.priceFetchOk = integer(c, "price_fetch_ok") != 0;
        i.lastPriceError = s(c, "last_price_error");
        i.status = s(c, "status");
        i.previousStatus = s(c, "previous_status");
        i.monitorResume = integer(c, "monitor_resume") != 0;
        i.sortIndex = integer(c, "sort_index");
        Long created = lng(c, "created_at");
        Long updated = lng(c, "updated_at");
        i.createdAt = created == null ? 0 : created;
        i.updatedAt = updated == null ? 0 : updated;
        return i;
    }

    private static String s(Cursor c, String name) { int idx=c.getColumnIndex(name); return idx<0||c.isNull(idx)?null:c.getString(idx); }
    private static int integer(Cursor c, String name) { int idx=c.getColumnIndex(name); return idx<0||c.isNull(idx)?0:c.getInt(idx); }
    private static Long lng(Cursor c, String name) { int idx=c.getColumnIndex(name); return idx<0||c.isNull(idx)?null:c.getLong(idx); }

    public static final class PricePoint {
        public final long price;
        public final long checkedAt;
        PricePoint(long price, long checkedAt) { this.price=price; this.checkedAt=checkedAt; }
    }
    public static final class Purchase {
        public final long id;
        public final Long price;
        public final long purchasedAt;
        Purchase(long id, Long price, long purchasedAt) { this.id=id; this.price=price; this.purchasedAt=purchasedAt; }
    }
    public static final class Tag {
        public final long id;
        public final String name;
        public final int sortIndex;
        Tag(long id, String name, int sortIndex) { this.id=id; this.name=name; this.sortIndex=sortIndex; }
    }

    private static final class Db extends SQLiteOpenHelper {
        Db(Context c) { super(c, "bookmarklauncher_wishlist.db", null, 6); }
        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE wish_items (" +
                    "id TEXT PRIMARY KEY, source_node_id TEXT, title TEXT NOT NULL, url TEXT NOT NULL, source_name TEXT, note TEXT NOT NULL DEFAULT ''," +
                    "thumbnail_path TEXT, favicon_path TEXT, preview_image_url TEXT, preview_path TEXT, user_title_edited INTEGER NOT NULL DEFAULT 0, user_image_edited INTEGER NOT NULL DEFAULT 0," +
                    "registered_price INTEGER, current_price INTEGER, last_price_checked_at INTEGER," +
                    "price_quote_kind TEXT, price_minimum INTEGER, price_maximum INTEGER," +
                    "price_fetch_ok INTEGER NOT NULL DEFAULT 0, last_price_error TEXT, status TEXT NOT NULL DEFAULT 'UNKNOWN', previous_status TEXT NOT NULL DEFAULT 'UNKNOWN'," +
                    "monitor_resume INTEGER NOT NULL DEFAULT 0, sort_index INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)");
            db.execSQL("CREATE INDEX wish_items_sort_idx ON wish_items(sort_index)");
            db.execSQL("CREATE INDEX wish_items_url_idx ON wish_items(url)");
            db.execSQL("CREATE TABLE tags (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE, sort_index INTEGER NOT NULL DEFAULT 0)");
            db.execSQL("CREATE TABLE item_tags (item_id TEXT NOT NULL, tag_id INTEGER NOT NULL, PRIMARY KEY(item_id,tag_id))");
            db.execSQL("CREATE TABLE price_history (id INTEGER PRIMARY KEY AUTOINCREMENT, item_id TEXT NOT NULL, price INTEGER NOT NULL, checked_at INTEGER NOT NULL, source TEXT)");
            db.execSQL("CREATE INDEX price_history_item_idx ON price_history(item_id,checked_at DESC)");
            db.execSQL("CREATE TABLE purchase_history (id INTEGER PRIMARY KEY AUTOINCREMENT, item_id TEXT NOT NULL, price INTEGER, purchased_at INTEGER NOT NULL)");
            db.execSQL("CREATE INDEX purchase_history_item_idx ON purchase_history(item_id,purchased_at DESC)");
        }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            if (oldVersion < 2) {
                // Non-destructive migration: preserve Wish items, tags, history and sorting.
                db.execSQL("ALTER TABLE wish_items ADD COLUMN preview_image_url TEXT");
                db.execSQL("ALTER TABLE wish_items ADD COLUMN preview_path TEXT");
                db.execSQL("ALTER TABLE wish_items ADD COLUMN user_title_edited INTEGER NOT NULL DEFAULT 0");
            }
            if (oldVersion < 3) {
                db.execSQL("ALTER TABLE wish_items ADD COLUMN last_price_error TEXT");
            }
            if (oldVersion < 4) {
                db.execSQL("ALTER TABLE wish_items ADD COLUMN user_image_edited INTEGER NOT NULL DEFAULT 0");
            }
            if (oldVersion < 5) {
                db.execSQL("ALTER TABLE wish_items ADD COLUMN note TEXT NOT NULL DEFAULT ''");
            }
            if (oldVersion < 6) {
                db.execSQL("ALTER TABLE wish_items ADD COLUMN price_quote_kind TEXT");
                db.execSQL("ALTER TABLE wish_items ADD COLUMN price_minimum INTEGER");
                db.execSQL("ALTER TABLE wish_items ADD COLUMN price_maximum INTEGER");
            }
        }
    }
}
