package com.cmyk.bookmarkslauncher.wishlist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class WishlistRepository {
    private final Db helper;

    public WishlistRepository(Context context) {
        helper = new Db(context.getApplicationContext());
    }

    public WishlistItem addFromBookmark(BookmarkNode node) {
        if (node == null || node.url == null || node.url.isBlank() || node.isFolder() || node.isApp() || node.isQr()) return null;
        WishlistItem existing = findBySourceOrUrl(node.id, node.url);
        if (existing != null) return existing;
        long now = System.currentTimeMillis();
        WishlistItem item = new WishlistItem();
        item.id = UUID.randomUUID().toString();
        item.sourceNodeId = node.id;
        item.title = node.displayName();
        item.url = node.url;
        item.sourceName = node.siteNameOrFallback();
        item.thumbnailPath = node.screenshotPath;
        item.faviconPath = node.faviconPath;
        item.status = "UNKNOWN";
        item.previousStatus = "UNKNOWN";
        item.sortIndex = nextSortIndex();
        item.createdAt = now;
        item.updatedAt = now;
        ContentValues v = values(item);
        helper.getWritableDatabase().insertOrThrow("wish_items", null, v);
        return item;
    }

    public WishlistItem addUrl(String title, String url) {
        if (url == null || url.isBlank()) return null;
        WishlistItem existing = findBySourceOrUrl(null, url);
        if (existing != null) return existing;
        long now = System.currentTimeMillis();
        WishlistItem item = new WishlistItem();
        item.id = UUID.randomUUID().toString();
        item.title = title == null || title.isBlank() ? url : title.trim();
        item.url = url.trim();
        item.status = "UNKNOWN";
        item.previousStatus = "UNKNOWN";
        item.sortIndex = nextSortIndex();
        item.createdAt = now;
        item.updatedAt = now;
        helper.getWritableDatabase().insertOrThrow("wish_items", null, values(item));
        return item;
    }

    public WishlistItem get(String id) {
        if (id == null) return null;
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, "id=?", new String[]{id}, null, null, null, "1")) {
            return c.moveToFirst() ? readItem(c) : null;
        }
    }

    public List<WishlistItem> listAll() {
        List<WishlistItem> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, null, null, null, null, "sort_index ASC, created_at ASC")) {
            while (c.moveToNext()) out.add(readItem(c));
        }
        return out;
    }

    public List<WishlistItem> listMonitored() {
        List<WishlistItem> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, "monitor_resume=1", null, null, null, "sort_index ASC")) {
            while (c.moveToNext()) out.add(readItem(c));
        }
        return out;
    }

    public void updateOrder(List<String> ids) {
        if (ids == null) return;
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < ids.size(); i++) {
                ContentValues v = new ContentValues();
                v.put("sort_index", i);
                v.put("updated_at", System.currentTimeMillis());
                db.update("wish_items", v, "id=?", new String[]{ids.get(i)});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public void rename(String id, String title) {
        ContentValues v = new ContentValues();
        v.put("title", title == null ? "" : title.trim());
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
    }

    public void delete(String id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("item_tags", "item_id=?", new String[]{id});
            db.delete("price_history", "item_id=?", new String[]{id});
            db.delete("purchase_history", "item_id=?", new String[]{id});
            db.delete("wish_items", "id=?", new String[]{id});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public void setMonitor(String id, boolean enabled) {
        ContentValues v = new ContentValues();
        v.put("monitor_resume", enabled ? 1 : 0);
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
    }

    public void updateCrawl(String id, WishlistCrawler.Result result) {
        WishlistItem before = get(id);
        if (before == null || result == null) return;
        long now = System.currentTimeMillis();
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            if (before.sourceNodeId == null && result.title != null && !result.title.isBlank()) v.put("title", result.title.trim());
            if (result.sourceName != null && !result.sourceName.isBlank()) v.put("source_name", result.sourceName.trim());
            if (result.price != null) {
                v.put("current_price", result.price);
                if (before.registeredPrice == null) v.put("registered_price", result.price);
                v.put("price_fetch_ok", 1);
                Long lastRecorded = latestRecordedPrice(id);
                if (lastRecorded == null || !lastRecorded.equals(result.price)) {
                    ContentValues h = new ContentValues();
                    h.put("item_id", id);
                    h.put("price", result.price);
                    h.put("checked_at", now);
                    h.put("source", "crawl");
                    db.insert("price_history", null, h);
                }
            } else {
                v.put("price_fetch_ok", 0);
            }
            v.put("last_price_checked_at", now);
            if (result.status != null && !result.status.isBlank()) {
                v.put("previous_status", before.status == null ? "UNKNOWN" : before.status);
                v.put("status", result.status);
            }
            v.put("updated_at", now);
            db.update("wish_items", v, "id=?", new String[]{id});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private Long latestRecordedPrice(String id) {
        try (Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT price FROM price_history WHERE item_id=? ORDER BY checked_at DESC, id DESC LIMIT 1",
                new String[]{id})) {
            return c.moveToFirst() && !c.isNull(0) ? c.getLong(0) : null;
        }
    }

    public List<PricePoint> priceHistory(String itemId, int limit) {
        List<PricePoint> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("price_history", new String[]{"price","checked_at"},
                "item_id=?", new String[]{itemId}, null, null, "checked_at DESC, id DESC", String.valueOf(Math.max(1, limit)))) {
            while (c.moveToNext()) out.add(new PricePoint(c.getLong(0), c.getLong(1)));
        }
        return out;
    }

    public void addPurchase(String itemId, Long price) {
        ContentValues v = new ContentValues();
        v.put("item_id", itemId);
        if (price != null) v.put("price", price);
        v.put("purchased_at", System.currentTimeMillis());
        helper.getWritableDatabase().insert("purchase_history", null, v);
    }

    public List<Purchase> purchases(String itemId, int limit) {
        List<Purchase> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("purchase_history", new String[]{"id","price","purchased_at"},
                "item_id=?", new String[]{itemId}, null, null, "purchased_at DESC, id DESC", limit <= 0 ? null : String.valueOf(limit))) {
            while (c.moveToNext()) out.add(new Purchase(c.getLong(0), c.isNull(1) ? null : c.getLong(1), c.getLong(2)));
        }
        return out;
    }

    public int purchaseCount(String itemId) {
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM purchase_history WHERE item_id=?", new String[]{itemId})) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public void deletePurchase(long purchaseId) {
        helper.getWritableDatabase().delete("purchase_history", "id=?", new String[]{String.valueOf(purchaseId)});
    }

    public List<Tag> listTags() {
        List<Tag> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("tags", new String[]{"id","name","sort_index"}, null, null, null, null, "sort_index ASC, id ASC")) {
            while (c.moveToNext()) out.add(new Tag(c.getLong(0), c.getString(1), c.getInt(2)));
        }
        return out;
    }

    public Tag createTag(String name) {
        if (name == null || name.trim().isBlank()) return null;
        String clean = name.trim();
        SQLiteDatabase db = helper.getWritableDatabase();
        try (Cursor c = db.query("tags", new String[]{"id","name","sort_index"}, "name=? COLLATE NOCASE", new String[]{clean}, null, null, null, "1")) {
            if (c.moveToFirst()) return new Tag(c.getLong(0), c.getString(1), c.getInt(2));
        }
        int sortIndex = nextTagSortIndex();
        ContentValues v = new ContentValues();
        v.put("name", clean);
        v.put("sort_index", sortIndex);
        long id = db.insert("tags", null, v);
        return id < 0 ? null : new Tag(id, clean, sortIndex);
    }

    public void renameTag(long id, String name) {
        if (name == null || name.trim().isBlank()) return;
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        try {
            helper.getWritableDatabase().update("tags", v, "id=?", new String[]{String.valueOf(id)});
        } catch (android.database.sqlite.SQLiteConstraintException ignored) {
            // Keep the existing tag if the requested name already exists.
        }
    }

    public void deleteTag(long id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("item_tags", "tag_id=?", new String[]{String.valueOf(id)});
            db.delete("tags", "id=?", new String[]{String.valueOf(id)});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public void setTagOrder(List<Long> ids) {
        if (ids == null) return;
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < ids.size(); i++) {
                Long id = ids.get(i);
                if (id == null) continue;
                ContentValues v = new ContentValues();
                v.put("sort_index", i);
                db.update("tags", v, "id=?", new String[]{String.valueOf(id)});
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public Set<Long> tagsForItem(String itemId) {
        Set<Long> out = new HashSet<>();
        try (Cursor c = helper.getReadableDatabase().query("item_tags", new String[]{"tag_id"}, "item_id=?", new String[]{itemId}, null, null, "tag_id ASC")) {
            while (c.moveToNext()) out.add(c.getLong(0));
        }
        return out;
    }

    public void setTagsForItem(String itemId, Set<Long> ids) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("item_tags", "item_id=?", new String[]{itemId});
            if (ids != null) for (Long id : ids) {
                if (id == null) continue;
                ContentValues v = new ContentValues();
                v.put("item_id", itemId);
                v.put("tag_id", id);
                db.insert("item_tags", null, v);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public List<Tag> tagsForItemResolved(String itemId) {
        List<Tag> out = new ArrayList<>();
        String sql = "SELECT t.id,t.name,t.sort_index FROM tags t JOIN item_tags it ON it.tag_id=t.id WHERE it.item_id=? ORDER BY t.sort_index ASC,t.id ASC";
        try (Cursor c = helper.getReadableDatabase().rawQuery(sql, new String[]{itemId})) {
            while (c.moveToNext()) out.add(new Tag(c.getLong(0), c.getString(1), c.getInt(2)));
        }
        return out;
    }

    private WishlistItem findBySourceOrUrl(String sourceId, String url) {
        String sel;
        String[] args;
        if (sourceId != null && !sourceId.isBlank()) {
            sel = "source_node_id=? OR url=?";
            args = new String[]{sourceId, url};
        } else {
            sel = "url=?";
            args = new String[]{url};
        }
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, sel, args, null, null, null, "1")) {
            return c.moveToFirst() ? readItem(c) : null;
        }
    }

    private int nextSortIndex() {
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COALESCE(MAX(sort_index),-1)+1 FROM wish_items", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private int nextTagSortIndex() {
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COALESCE(MAX(sort_index),-1)+1 FROM tags", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private ContentValues values(WishlistItem item) {
        ContentValues v = new ContentValues();
        v.put("id", item.id);
        v.put("source_node_id", item.sourceNodeId);
        v.put("title", item.title);
        v.put("url", item.url);
        v.put("source_name", item.sourceName);
        v.put("thumbnail_path", item.thumbnailPath);
        v.put("favicon_path", item.faviconPath);
        if (item.registeredPrice != null) v.put("registered_price", item.registeredPrice);
        if (item.currentPrice != null) v.put("current_price", item.currentPrice);
        if (item.lastPriceCheckedAt != null) v.put("last_price_checked_at", item.lastPriceCheckedAt);
        v.put("price_fetch_ok", item.priceFetchOk ? 1 : 0);
        v.put("status", item.status == null ? "UNKNOWN" : item.status);
        v.put("previous_status", item.previousStatus == null ? "UNKNOWN" : item.previousStatus);
        v.put("monitor_resume", item.monitorResume ? 1 : 0);
        v.put("sort_index", item.sortIndex);
        v.put("created_at", item.createdAt);
        v.put("updated_at", item.updatedAt);
        return v;
    }

    private WishlistItem readItem(Cursor c) {
        WishlistItem i = new WishlistItem();
        i.id = s(c, "id");
        i.sourceNodeId = s(c, "source_node_id");
        i.title = s(c, "title");
        i.url = s(c, "url");
        i.sourceName = s(c, "source_name");
        i.thumbnailPath = s(c, "thumbnail_path");
        i.faviconPath = s(c, "favicon_path");
        i.registeredPrice = lng(c, "registered_price");
        i.currentPrice = lng(c, "current_price");
        i.lastPriceCheckedAt = lng(c, "last_price_checked_at");
        i.priceFetchOk = integer(c, "price_fetch_ok") != 0;
        i.status = s(c, "status");
        i.previousStatus = s(c, "previous_status");
        i.monitorResume = integer(c, "monitor_resume") != 0;
        i.sortIndex = integer(c, "sort_index");
        Long created = lng(c, "created_at");
        Long updated = lng(c, "updated_at");
        i.createdAt = created == null ? 0 : created;
        i.updatedAt = updated == null ? 0 : updated;
        return i;
    }

    private static String s(Cursor c, String name) { int idx=c.getColumnIndex(name); return idx<0||c.isNull(idx)?null:c.getString(idx); }
    private static int integer(Cursor c, String name) { int idx=c.getColumnIndex(name); return idx<0||c.isNull(idx)?0:c.getInt(idx); }
    private static Long lng(Cursor c, String name) { int idx=c.getColumnIndex(name); return idx<0||c.isNull(idx)?null:c.getLong(idx); }

    public static final class PricePoint {
        public final long price;
        public final long checkedAt;
        PricePoint(long price, long checkedAt) { this.price=price; this.checkedAt=checkedAt; }
    }
    public static final class Purchase {
        public final long id;
        public final Long price;
        public final long purchasedAt;
        Purchase(long id, Long price, long purchasedAt) { this.id=id; this.price=price; this.purchasedAt=purchasedAt; }
    }
    public static final class Tag {
        public final long id;
        public final String name;
        public final int sortIndex;
        Tag(long id, String name, int sortIndex) { this.id=id; this.name=name; this.sortIndex=sortIndex; }
    }

    private static final class Db extends SQLiteOpenHelper {
        Db(Context c) { super(c, "bookmarklauncher_wishlist.db", null, 1); }
        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE wish_items (" +
                    "id TEXT PRIMARY KEY, source_node_id TEXT, title TEXT NOT NULL, url TEXT NOT NULL, source_name TEXT," +
                    "thumbnail_path TEXT, favicon_path TEXT, registered_price INTEGER, current_price INTEGER, last_price_checked_at INTEGER," +
                    "price_fetch_ok INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'UNKNOWN', previous_status TEXT NOT NULL DEFAULT 'UNKNOWN'," +
                    "monitor_resume INTEGER NOT NULL DEFAULT 0, sort_index INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)");
            db.execSQL("CREATE INDEX wish_items_sort_idx ON wish_items(sort_index)");
            db.execSQL("CREATE INDEX wish_items_url_idx ON wish_items(url)");
            db.execSQL("CREATE TABLE tags (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE, sort_index INTEGER NOT NULL DEFAULT 0)");
            db.execSQL("CREATE TABLE item_tags (item_id TEXT NOT NULL, tag_id INTEGER NOT NULL, PRIMARY KEY(item_id,tag_id))");
            db.execSQL("CREATE TABLE price_history (id INTEGER PRIMARY KEY AUTOINCREMENT, item_id TEXT NOT NULL, price INTEGER NOT NULL, checked_at INTEGER NOT NULL, source TEXT)");
            db.execSQL("CREATE INDEX price_history_item_idx ON price_history(item_id,checked_at DESC)");
            db.execSQL("CREATE TABLE purchase_history (id INTEGER PRIMARY KEY AUTOINCREMENT, item_id TEXT NOT NULL, price INTEGER, purchased_at INTEGER NOT NULL)");
            db.execSQL("CREATE INDEX purchase_history_item_idx ON purchase_history(item_id,purchased_at DESC)");
        }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    }
}
