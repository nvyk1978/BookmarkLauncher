package com.cmyk.bookmarkslauncher.wishlist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.WishlistCardDiagnostics;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class WishlistRepository {
    private final Db helper;
    private final Context appContext;

    public WishlistRepository(Context context) {
        appContext = context.getApplicationContext();
        RetailDiagnostics.install(appContext);
        helper = new Db(appContext);
        repairFumuroyaBagPriceRegression();
    }

    /** Repair ONLY the documented 0.1.123 false webview price for this exact
     * Fumuroya card. Never touch other products, genuine orders or stock history.
     * Keep the registered amount, discard the bad 22-yen WebView price point and
     * mark the restored display value as unverified until a future good crawl. */
    private void repairFumuroyaBagPriceRegression() {
        final String id = "72ad16b2-564f-4684-bdf5-8e98d9d1b52e";
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        boolean repaired = false;
        try (Cursor c = db.rawQuery(
                "SELECT url,registered_price,current_price FROM wish_items WHERE id=?",new String[]{id})) {
            if (c.moveToFirst() && !c.isNull(1) && !c.isNull(2)
                    && c.getLong(1)==2106L && c.getLong(2)==22L
                    && isFumuroyaProduct(c.getString(0))) {
                db.delete("price_history", "item_id=? AND price=22 AND source='webview'", new String[]{id});
                ContentValues fixed = new ContentValues();
                fixed.put("current_price",2106L);
                fixed.put("price_fetch_ok",0);
                fixed.put("last_price_error","誤った付属品価格を補正（再確認待ち）");
                fixed.putNull("last_price_checked_at");
                fixed.put("updated_at",System.currentTimeMillis());
                db.update("wish_items", fixed, "id=? AND current_price=22", new String[]{id});
                repaired = true;
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        if (repaired) WishlistCardDiagnostics.event(appContext,id,"price.repair",
                "accessory=22 restored=2106 historyPointRemoved=true priceVerified=false");
    }

    private static boolean isFumuroyaProduct(String url) {
        if (url==null) return false;
        try {
            java.net.URL parsed = new java.net.URL(url);
            return "https".equalsIgnoreCase(parsed.getProtocol())
                    && "eshop.fumuroya.com".equalsIgnoreCase(parsed.getHost())
                    && parsed.getPath().matches("/product/detail/300840/?");
        } catch (Exception ignored) { return false; }
    }

    public WishlistItem addFromBookmark(BookmarkNode node) {
        if (node == null || node.url == null || node.url.isBlank() || node.isFolder() || node.isApp() || node.isQr()) return null;
        WishlistItem existing = findBySourceOrUrl(node.id, node.url);
        if (existing != null) return existing;
        long now = System.currentTimeMillis();
        WishlistItem item = new WishlistItem();
        item.id = UUID.randomUUID().toString();
        item.sourceNodeId = node.id;
        item.title = node.displayName();
        item.url = GeneralRetailIdentity.canonical(node.url);
        item.acquisitionMode = WishlistMode.forDirectUrl(item.url);
        item.sourceName = node.siteNameOrFallback();
        item.thumbnailPath = node.screenshotPath;
        item.faviconPath = node.faviconPath;
        item.status = "UNKNOWN";
        item.previousStatus = "UNKNOWN";
        item.sortIndex = nextSortIndex();
        item.createdAt = now;
        item.updatedAt = now;
        ContentValues v = values(item);
        helper.getWritableDatabase().insertOrThrow("wish_items", null, v);
        return item;
    }

    public WishlistItem addUrl(String title, String url) {
        return addUrl(title, url, "");
    }

    public WishlistItem addUrl(String title, String url, String note) {
        if (url == null || url.isBlank()) return null;
        WishlistItem existing = findBySourceOrUrl(null, url);
        if (existing != null) {
            if (note != null && !note.isBlank() && (existing.note == null || existing.note.isBlank())) {
                setNote(existing.id, note.trim());
                existing.note = note.trim();
            }
            return existing;
        }
        long now = System.currentTimeMillis();
        WishlistItem item = new WishlistItem();
        item.id = UUID.randomUUID().toString();
        item.title = title == null || title.isBlank() ? url : title.trim();
        item.userTitleEdited = title != null && !title.isBlank();
        item.url = GeneralRetailIdentity.canonical(url);
        item.acquisitionMode = WishlistMode.forDirectUrl(item.url);
        item.note = note == null ? "" : note.trim();
        item.status = "UNKNOWN";
        item.previousStatus = "UNKNOWN";
        item.sortIndex = nextSortIndex();
        item.createdAt = now;
        item.updatedAt = now;
        helper.getWritableDatabase().insertOrThrow("wish_items", null, values(item));
        return item;
    }

    public WishlistItem get(String id) {
        if (id == null) return null;
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, "id=?", new String[]{id}, null, null, null, "1")) {
            return c.moveToFirst() ? readItem(c) : null;
        }
    }

    /** Inexpensive token that changes for writes made by other SQLite connections.
     * Never increments for this helper's own writes (those explicitly refresh UI). */
    public long externalDataVersion() {
        try (Cursor c = helper.getReadableDatabase().rawQuery("PRAGMA data_version", null)) {
            return c.moveToFirst() ? c.getLong(0) : -1L;
        } catch (RuntimeException ignored) {
            return -1L; // Preserve last good cards when DB is briefly unavailable.
        }
    }

    public List<WishlistItem> listAll() {
        List<WishlistItem> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, null, null, null, null, "sort_index ASC, created_at ASC")) {
            while (c.moveToNext()) out.add(readItem(c));
        }
        return out;
    }

    public List<WishlistItem> listMonitored() {
        List<WishlistItem> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, "monitor_resume=1", null, null, null, "sort_index ASC")) {
            while (c.moveToNext()) out.add(readItem(c));
        }
        return out;
    }

    public void updateOrder(List<String> ids) {
        if (ids == null) return;
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < ids.size(); i++) {
                ContentValues v = new ContentValues();
                v.put("sort_index", i);
                v.put("updated_at", System.currentTimeMillis());
                db.update("wish_items", v, "id=?", new String[]{ids.get(i)});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    /** Keep the note independent of crawler metadata, title, images and price history. */
    public void setNote(String id, String note) {
        if (id == null) return;
        ContentValues v = new ContentValues();
        v.put("note", note == null ? "" : note);
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
    }

    public void rename(String id, String title) {
        ContentValues v = new ContentValues();
        v.put("title", title == null ? "" : title.trim());
        v.put("user_title_edited", 1);
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
    }

    public void delete(String id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("item_tags", "item_id=?", new String[]{id});
            db.delete("price_history", "item_id=?", new String[]{id});
            db.delete("purchase_history", "item_id=?", new String[]{id});
            db.delete("wish_items", "id=?", new String[]{id});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        WishlistPreviewStore.delete(appContext, id);
    }

    public void setMonitor(String id, boolean enabled) {
        ContentValues v = new ContentValues();
        v.put("monitor_resume", enabled ? 1 : 0);
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
    }

    /** Coordinates two isolated DB paths; price updates never depend on metadata. */
    public void updateCrawl(String id, WishlistCrawler.Result result) {
        updateCrawl(id,result,false);
    }

    /** On foreground retail updates, HTTP is only phase one. Do not announce
     * its timeout as the FINAL outcome while the identity-bound WebView runs.
     * Background periodic refreshes use the ordinary finished HTTP result. */
    public void updateCrawl(String id, WishlistCrawler.Result result, boolean retailProbePending) {
        if (result == null) return;
        WishlistCardDiagnostics.event(appContext, id, "crawl.http.result",
                "mode=" + result.acquisitionMode + " success=" + result.success
                + " site=" + result.siteState + " price=" + result.price
                + " quote=" + (result.priceQuote != null) + " image=" + (result.imageUrl != null)
                + " stock=" + result.status + " verified=" + result.availabilityExplicit
                + " failure=" + (result.failureReason == null ? "none" : result.failureReason));
        if (result.success && result.acquisitionMode != WishlistMode.UNRESOLVED) {
            if (!bindAcquisitionMode(id, result.acquisitionMode)) {
                android.util.Log.w("WishlistMode", "Refused cross-mode update: item="+id+" attempted="+result.acquisitionMode);
                return;
            }
        }
        // Site reachability is stored separately, including failures; never mark
        // missing/blocked/maintenance pages as sold-out products.
        try {
            WishlistItem persisted = retailProbePending ? get(id) : null;
            WishlistMode actualMode = persisted == null ? result.acquisitionMode : persisted.acquisitionMode;
            boolean large = actualMode == WishlistMode.YODOBASHI
                    || actualMode == WishlistMode.BICCAMERA
                    || actualMode == WishlistMode.UNIQLO;
            updateSiteStateOnly(id, retailProbePending && large
                    ? WishlistSiteState.CHECKING : result.siteState);
        } catch (RuntimeException error) {
            RetailDiagnostics.event(result.acquisitionMode,"db.site.error","type="+RetailDiagnostics.error(error));
        }
        // Do not turn an already good price into a failed price while its
        // independent foreground renderer has not had a chance to run.
        try {
            if (result.success && result.priceQuote != null)
                updatePriceQuoteOnly(id, result.priceQuote);
            else if (!retailProbePending || result.price != null)
                updatePriceOnly(id, result.success ? result.price : null, result.failureReason, "crawl");
        } catch (RuntimeException error) {
            RetailDiagnostics.event(result.acquisitionMode,"db.price.error","type="+RetailDiagnostics.error(error));
        }
        try {
            updateMetadataOnly(id, result);
        } catch (RuntimeException error) {
            RetailDiagnostics.event(result.acquisitionMode,"db.metadata.error","type="+RetailDiagnostics.error(error));
        }
    }

    /** Manual and user-triggered batch updates: the device log shows ordinary
     * HTTP timed out before headers on these two sites, whereas WebView rendered
     * the intended product in seconds. Do not block the UI on that redundant HTTP. */
    public boolean beginRenderedRetailOnly(String id, String url, WishlistMode mode) {
        if (id==null||url==null||(mode!=WishlistMode.YODOBASHI && mode!=WishlistMode.BICCAMERA))return false;
        WishlistItem item=get(id);
        if(item==null||!url.equals(item.url)||item.acquisitionMode!=mode)return false;
        ContentValues v=new ContentValues();
        v.put("site_state",WishlistSiteState.CHECKING);
        v.put("site_checked_at",System.currentTimeMillis());
        int count=helper.getWritableDatabase().update("wish_items",v,
                "id=? AND acquisition_mode=?",new String[]{id,mode.name()});
        RetailDiagnostics.event(mode,"db.webviewOnly.start","rows="+count);
        WishlistCardDiagnostics.event(appContext,id,"webview.only.start","mode="+mode+" rows="+count);
        return count>0;
    }

    /** Large-retailer DOM recovery: each proven field is independent.
     * An HTTP timeout must not turn an empty DOM price into a failed price check.
     * The product/mode identity must match the persisted card before any write. */
    public boolean updateLargeRetailRenderedFields(String id, String savedUrl, WishlistCrawler.Result result) {
        if (result == null || !result.success || savedUrl == null) return false;
        WishlistCardDiagnostics.event(appContext, id, "webview.result", "mode="+result.acquisitionMode
                +" price="+result.price+" image="+(result.imageUrl!=null)
                +" stock="+result.status+" explicit="+result.availabilityExplicit);
        RetailDiagnostics.event(result.acquisitionMode, "db.webview.begin", "title="+(result.title!=null)+" image="+(result.imageUrl!=null)+" price="+(result.price!=null)+" stock="+result.availabilityExplicit);
        WishlistItem before = get(id);
        if (before == null || !savedUrl.equals(before.url)
                || before.acquisitionMode != result.acquisitionMode) {
            RetailDiagnostics.event(result.acquisitionMode,"db.webview.refused","item-or-mode-changed");
            return false;
        }
        try {
            java.net.URL source = new java.net.URL(savedUrl);
            java.net.URL resolved = new java.net.URL(result.resolvedUrl);
            if (!WishlistMode.sameLargeRetailVariant(source, resolved)) {
                RetailDiagnostics.event(result.acquisitionMode,"db.webview.refused","product-or-variant-mismatch");
                return false;
            }
        } catch (Exception ignored) {
            RetailDiagnostics.event(result.acquisitionMode,"db.webview.refused","invalid-url");
            return false;
        }
        if (result.price != null) {
            try { updatePriceOnly(id, result.price, null, "retail-webview"); }
            catch (RuntimeException error) { android.util.Log.w("RetailGiant", "DOM price", error);
                RetailDiagnostics.event(result.acquisitionMode,"db.price.error","type="+RetailDiagnostics.error(error)); }
        }
        if (result.title != null || result.imageUrl != null || result.availabilityExplicit) {
            // A verified product page with no variant-specific stock evidence
            // means CURRENT availability is UNKNOWN, not the last known buyable
            // state. updateMetadataOnly preserves last_confirmed_* unchanged.
            if (!result.availabilityExplicit) result.status = "UNKNOWN";
            try { updateMetadataOnly(id, result); }
            catch (RuntimeException error) { android.util.Log.w("RetailGiant", "DOM fields", error);
                RetailDiagnostics.event(result.acquisitionMode,"db.metadata.error","type="+RetailDiagnostics.error(error)); }
        }
        // The rendered product content is reachability evidence even if a
        // preceding direct HTTP request was blocked or timed out.
        updateSiteStateOnly(id, WishlistSiteState.OK);
        RetailDiagnostics.event(result.acquisitionMode, "db.webview.end", "site=OK savedPrice="+(result.price!=null)+" candidateImage="+(result.imageUrl!=null));
        return true;
    }

    /** Restore the actual HTTP result only after a rendered probe has exhausted
     * its own deadline. Never leave a persisted pending state indefinitely.
     * The saved URL and fixed acquisition mode guard against stale callbacks. */
    public void finishLargeRetailProbe(String id, String savedUrl,
                                      WishlistMode expectedMode, String httpState,
                                      boolean renderedProductFound) {
        WishlistItem current = get(id);
        if (current == null || savedUrl == null || !savedUrl.equals(current.url)
                || current.acquisitionMode != expectedMode) return;
        updateSiteStateOnly(id, renderedProductFound ? WishlistSiteState.OK : httpState);
        RetailDiagnostics.event(expectedMode, "db.final", "webviewAccepted="+renderedProductFound+" site="+(renderedProductFound ? WishlistSiteState.OK : httpState));
        WishlistCardDiagnostics.event(appContext,id,"webview.finish","mode="+expectedMode
                +" accepted="+renderedProductFound+" site="+(renderedProductFound ? WishlistSiteState.OK : httpState));
    }

    /** Bind a mode once; no crawler may silently change a previously bound mode. */
    private boolean bindAcquisitionMode(String id, WishlistMode verified) {
        if (verified == null || verified == WishlistMode.UNRESOLVED) return false;
        WishlistItem before = get(id);
        if (before == null) return false;
        WishlistMode old = before.acquisitionMode;
        if (old == verified) return true;
        if (old != WishlistMode.UNRESOLVED) return false;
        ContentValues v = new ContentValues();
        v.put("acquisition_mode", verified.name());
        v.put("updated_at", System.currentTimeMillis());
        // Atomic binding avoids races between a background and a manual refresh.
        int changed = helper.getWritableDatabase().update("wish_items", v,
                "id=? AND acquisition_mode='UNRESOLVED'", new String[]{id});
        return changed > 0 || (get(id) != null && get(id).acquisitionMode == verified);
    }

    public boolean hasUsablePreview(String id) {
        WishlistItem item = get(id);
        return item != null && WishlistPreviewStore.isUsableSavedImage(item.previewPath);
    }

    private static boolean isMarketplaceProduct(String url) {
        if (url == null) return false;
        try { return MarketplaceIdentity.from(new java.net.URL(url)) != null; }
        catch (Exception ignored) { return false; }
    }

    /** Site state is independent of name, image, product stock and price/history. */
    private void updateSiteStateOnly(String id, String state) {
        if (id == null) return;
        ContentValues v = new ContentValues();
        v.put("site_state", state == null ? WishlistSiteState.CONNECT_FAILED : state);
        v.put("site_checked_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
        WishlistCardDiagnostics.event(appContext,id,"site.state", "state="+state);
    }

    /** A successful foreground WebView price proves page reachability, not product availability. */
    public void recordSiteReachableFromWebView(String id) {
        WishlistItem before = get(id);
        if (before != null && (WishlistSiteState.ACCESS_RESTRICTED.equals(before.siteState)
                || WishlistSiteState.CONNECT_FAILED.equals(before.siteState)
                || WishlistSiteState.TIMEOUT.equals(before.siteState)
                || WishlistSiteState.TEMPORARY_ERROR.equals(before.siteState))) {
            updateSiteStateOnly(id, WishlistSiteState.OK);
        }
    }

    private void updateMetadataOnly(String id, WishlistCrawler.Result result) {
        if (!result.success) return;
        WishlistItem before=get(id);
        if (before == null) return;
        String preview=null;
        RetailDiagnostics.event(result.acquisitionMode, "db.metadata.start", "title="+(result.title!=null)+" price="+(result.price!=null)+" image="+(result.imageUrl!=null)+" imageEdited="+before.userImageEdited+" savedImage="+WishlistPreviewStore.isUsableSavedImage(before.previewPath)+" candidates="+(result.retailImageCandidates==null?0:result.retailImageCandidates.size()));
        if (preview == null && !before.userImageEdited && result.imageUrl!=null && !result.imageUrl.isBlank()) {
            if (!result.imageUrl.equals(before.previewImageUrl)
                    || !WishlistPreviewStore.isUsableSavedImage(before.previewPath)) {
                preview=WishlistPreviewStore.save(appContext,id,result.imageUrl,
                        result.acquisitionMode == WishlistMode.BICCAMERA ? result.resolvedUrl : null,
                        result.acquisitionMode);
            }
        }
        // Separate image-only recovery for retail product galleries; download each
        // high-confidence candidate in order rather than stopping at one broken thumbnail.
        String chosenImageUrl = result.imageUrl;
        if (preview == null && !before.userImageEdited
                && result.retailImageCandidates != null
                && (!WishlistPreviewStore.isUsableSavedImage(before.previewPath)
                    || (isMarketplaceProduct(result.resolvedUrl) && result.imageUrl != null
                        && !result.imageUrl.equals(before.previewImageUrl))
                    || (result.acquisitionMode == WishlistMode.BICCAMERA
                        && result.imageUrl != null && !result.imageUrl.equals(before.previewImageUrl)))) {
            int retailAttempts=0;
            for (String candidate : result.retailImageCandidates) {
                if (candidate == null || candidate.equals(result.imageUrl)) continue;
                if (result.acquisitionMode == WishlistMode.BICCAMERA && ++retailAttempts > 1) {
                    RetailDiagnostics.event(result.acquisitionMode,"image.stop","skip-redundant-cdn-timeouts");
                    break;
                } // May retry the same URL with the product-page Referer.
                preview = WishlistPreviewStore.save(appContext, id, candidate, result.resolvedUrl,result.acquisitionMode);
                if (preview != null) { chosenImageUrl = candidate; break; }
            }
        }
        WishlistCardDiagnostics.event(appContext, id, "image.result",
                "candidate="+(result.imageUrl!=null)+" downloaded="+(preview!=null)
                +" previousUsable="+WishlistPreviewStore.isUsableSavedImage(before.previewPath)
                +" edited="+before.userImageEdited);
        RetailDiagnostics.event(result.acquisitionMode, "db.image.result", "downloadSaved="+(preview!=null)+" existingUsable="+WishlistPreviewStore.isUsableSavedImage(before.previewPath)+" manuallyEdited="+before.userImageEdited);
        ContentValues v=new ContentValues();
        if (!before.userTitleEdited && result.title!=null && !result.title.isBlank())
            v.put("title",result.title.trim());
        if (result.sourceName!=null && !result.sourceName.isBlank())v.put("source_name",result.sourceName.trim());
        if(preview!=null){v.put("preview_image_url",chosenImageUrl);v.put("preview_path",preview);}
        if(result.status!=null && !result.status.isBlank()){
            v.put("previous_status",before.status==null?"UNKNOWN":before.status);
            v.put("status",result.status);
            // A failed/UNKNOWN observation is not proof of currently being buyable.
            // Keep the previously verified observation with its ORIGINAL timestamp.
            if("AVAILABLE".equals(result.status)||"UNAVAILABLE".equals(result.status)){
                v.put("last_confirmed_status",result.status);
                v.put("last_confirmed_at",System.currentTimeMillis());
            }
        }
        if(v.size()==0) {
            RetailDiagnostics.event(result.acquisitionMode,"db.metadata.skip","no-new-fields");
            return;
        }
        v.put("updated_at",System.currentTimeMillis());
        int updated = helper.getWritableDatabase().update("wish_items",v,"id=?",new String[]{id});
        RetailDiagnostics.event(result.acquisitionMode,"db.metadata.commit","rows="+updated+" imageStored="+(preview!=null)+" title="+(result.title!=null));
        WishlistCardDiagnostics.event(appContext, id, "metadata.commit", "rows="+updated
                +" title="+(result.title!=null)+" imageSaved="+(preview!=null)
                +" stock="+result.status);
    }

    /** Rendered cart control may only resolve a still-UNKNOWN item as buyable.
     * It must not overwrite an explicit stock outcome or any unrelated metadata. */
    public void markAvailableFromWebView(String id, String expectedUrl) {
        if (id == null || expectedUrl == null) return;
        WishlistItem before = get(id);
        if (before == null || !expectedUrl.equals(before.url)
                || !"UNKNOWN".equals(before.status)
                || !WishlistSiteState.OK.equals(before.siteState)) return;
        ContentValues v = new ContentValues();
        v.put("previous_status", "UNKNOWN");
        v.put("status", "AVAILABLE");
        v.put("last_confirmed_status","AVAILABLE");
        v.put("last_confirmed_at",System.currentTimeMillis());
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v,
                "id=? AND status='UNKNOWN' AND site_state=?",
                new String[]{id, WishlistSiteState.OK});
    }

    /** The positive status path is unchanged. Only HIRAKI's verified stock row
     * may additionally record an explicit sold-out result from a foreground DOM. */
    public void markVerifiedStockFromWebView(String id, String expectedUrl, String status) {
        // Only these two identity-bound GENERAL probes can recover site
        // reachability after a refused raw HTTP request. The visible enabled
        // purchase control is for the exact requested product code.
        if ("AVAILABLE".equals(status) && id != null && expectedUrl != null) {
            WishlistItem candidate = get(id);
            boolean knownRetail = false;
            try { knownRetail = GeneralRetailIdentity.store(new java.net.URL(expectedUrl)) != null; }
            catch (Exception ignored) { }
            if (knownRetail && candidate != null
                    && candidate.acquisitionMode == WishlistMode.GENERAL
                    && expectedUrl.equals(candidate.url) && "UNKNOWN".equals(candidate.status)) {
                ContentValues v = new ContentValues();
                v.put("previous_status", "UNKNOWN");
                v.put("status", "AVAILABLE");
                v.put("last_confirmed_status", "AVAILABLE");
                v.put("last_confirmed_at", System.currentTimeMillis());
                v.put("site_state", WishlistSiteState.OK);
                v.put("site_checked_at", System.currentTimeMillis());
                v.put("updated_at", System.currentTimeMillis());
                helper.getWritableDatabase().update("wish_items", v,
                        "id=? AND url=? AND acquisition_mode='GENERAL' AND status='UNKNOWN'",
                        new String[]{id, expectedUrl});
                RetailDiagnostics.general(urlForRetail(expectedUrl), "db.stock.webview", "available=true exactSku=true");
                return;
            }
        }
        if ("AVAILABLE".equals(status)) { markAvailableFromWebView(id, expectedUrl); return; }
        if (!"UNAVAILABLE".equals(status) || id == null || expectedUrl == null) return;
        WishlistItem before = get(id);
        if (before == null || before.acquisitionMode != WishlistMode.GENERAL
                || !expectedUrl.equals(before.url) || !"UNKNOWN".equals(before.status)
                || !WishlistSiteState.OK.equals(before.siteState)) return;
        try { if (!HirakiStockEvidence.isHirakiProduct(new java.net.URL(expectedUrl))) return; }
        catch (Exception ignored) { return; }
        ContentValues v = new ContentValues();
        v.put("previous_status", "UNKNOWN");
        v.put("status", "UNAVAILABLE");
        v.put("last_confirmed_status", "UNAVAILABLE");
        v.put("last_confirmed_at", System.currentTimeMillis());
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v,
                "id=? AND status='UNKNOWN' AND site_state=?",
                new String[]{id, WishlistSiteState.OK});
    }

    private java.net.URL urlForRetail(String text) {
        try { return new java.net.URL(text); }
        catch (Exception ignored) { return null; }
    }

    /** Amazon title-only rendered DOM recovery; never overwrites a manual title. */
    public void updateAmazonTitleFromWebView(String id,String expectedUrl,String newTitle){
        if(id==null||expectedUrl==null||newTitle==null||newTitle.isBlank())return;
        WishlistItem before=get(id);
        if(before==null||before.userTitleEdited||!expectedUrl.equals(before.url)
                || before.acquisitionMode != WishlistMode.AMAZON)return;
        ContentValues v=new ContentValues();
        v.put("title",newTitle.trim());
        v.put("updated_at",System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items",v,"id=? AND user_title_edited=0",new String[]{id});
    }

    /** Image-only path; a failed image download never edits a name, price or price history. */
    public boolean updateImageFromWebView(String id, String imageUrl, String productPageUrl) {
        return updateImageFromWebView(id, imageUrl, productPageUrl, null);
    }

    /** Only the initiating manual-refresh card receives its own image failure reason. */
    public boolean updateImageFromWebView(String id, String imageUrl, String productPageUrl,
                                          java.util.function.Consumer<String> failureTrace) {
        if (id == null || imageUrl == null || imageUrl.isBlank()) return false;
        WishlistItem before = get(id);
        if (before == null || before.userImageEdited
                || before.acquisitionMode == WishlistMode.UNRESOLVED
                || before.acquisitionMode != WishlistMode.forDirectUrl(productPageUrl)) return false;
        // Revalidate a previously auto-downloaded image: older Amazon builds
        // could store recommendations. User-selected images are protected above.
        if (WishlistPreviewStore.isUsableSavedImage(before.previewPath)
                && (!isMarketplaceProduct(productPageUrl)
                    || imageUrl.equals(before.previewImageUrl))) return true;
        String saved = WishlistPreviewStore.save(appContext, id, imageUrl, productPageUrl,
                before.acquisitionMode, failureTrace);
        if (saved == null) return false;
        ContentValues v = new ContentValues();
        v.put("preview_image_url", imageUrl);
        v.put("preview_path", saved);
        v.put("updated_at", System.currentTimeMillis());
        return helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id}) > 0;
    }

    /** User photo is independent of crawler metadata and all price writes. */
    public boolean setManualImage(String id, android.net.Uri imageUri) {
        if (id == null || imageUri == null || get(id) == null) return false;
        String saved = WishlistPreviewStore.saveSelected(appContext, id, imageUri);
        if (saved == null) return false;
        ContentValues fields = new ContentValues();
        fields.put("preview_path", saved);
        fields.putNull("preview_image_url");
        fields.put("user_image_edited", 1);
        fields.put("updated_at", System.currentTimeMillis());
        return helper.getWritableDatabase().update("wish_items", fields, "id=?", new String[]{id}) > 0;
    }

    private void updatePriceOnly(String id,Long price,String failure,String origin) {
        if(id==null)return;
        WishlistItem before=get(id);
        if(before==null)return;
        // Product-bound defense in depth: a 22-yen paper bag must never again
        // be committed as the price of the 2,106-yen Fumuroya gift product.
        if (price != null && isFumuroyaProduct(before.url)
                && before.registeredPrice != null && before.registeredPrice >= 1000L
                && price < 500L) {
            WishlistCardDiagnostics.event(appContext,id,"price.rejected",
                    "reason=accessory-price-risk value="+price);
            price = null;
            failure = "商品本体ではない可能性がある価格を除外";
        }
        long now=System.currentTimeMillis();
        RetailDiagnostics.event(before.acquisitionMode,"db.price.start","present="+(price!=null)+" origin="+origin);
        SQLiteDatabase db=helper.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues v=new ContentValues();
            v.put("last_price_checked_at",now);
            v.put("updated_at",now);
            if(price!=null){
                v.putNull("price_quote_kind");
                v.putNull("price_minimum");
                v.putNull("price_maximum");
                v.put("current_price",price);
                if(before.registeredPrice==null)v.put("registered_price",price);
                v.put("price_fetch_ok",1);
                v.putNull("last_price_error");
                Long lastRecorded=latestRecordedPrice(id);
                if(lastRecorded==null || !lastRecorded.equals(price)){
                    ContentValues point=new ContentValues();
                    point.put("item_id",id);
                    point.put("price",price);
                    point.put("checked_at",now);
                    point.put("source",origin);
                    db.insert("price_history",null,point);
                }
            }else{
                v.put("price_fetch_ok",0);
                v.put("last_price_error",failure==null?"価格情報を特定できず":failure);
            }
            db.update("wish_items",v,"id=?",new String[]{id});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        RetailDiagnostics.event(before.acquisitionMode,"db.price.commit","present="+(price!=null)+" origin="+origin);
        WishlistCardDiagnostics.event(appContext,id,"price.commit","origin="+origin
                +" price="+price+" ok="+(price!=null)
                +" failure="+(failure==null?"none":failure));
    }

    /** A minimum or interval is display-only, NEVER an exact price/history point. */
    private void updatePriceQuoteOnly(String id, WishlistRetailPriceQuote quote) {
        if (id == null || quote == null || get(id) == null) return;
        ContentValues v = new ContentValues();
        v.putNull("current_price"); // Never present an old exact value as today's price.
        v.put("price_quote_kind", quote.kind);
        v.put("price_minimum", quote.minimum);
        if (quote.maximum != null) v.put("price_maximum", quote.maximum);
        else v.putNull("price_maximum");
        v.put("price_fetch_ok", 1);
        v.putNull("last_price_error");
        v.put("last_price_checked_at", System.currentTimeMillis());
        v.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("wish_items", v, "id=?", new String[]{id});
        WishlistCardDiagnostics.event(appContext,id,"price.quote.commit","kind="+quote.kind
                +" minimum="+quote.minimum+" maximum="+quote.maximum);
    }

    /** Foreground WebView also treats minimum prices as ranges, never exact history. */
    public void updatePriceQuoteFromWebView(String id, WishlistRetailPriceQuote quote) {
        updatePriceQuoteOnly(id, quote);
    }

    /** Price-only WebView fallback. It cannot touch names, images, or availability. */
    public void updatePriceFromWebView(String id,Long price,String failure) {
        updatePriceOnly(id,price,failure,"webview");
    }

    private Long latestRecordedPrice(String id) {
        try (Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT price FROM price_history WHERE item_id=? ORDER BY checked_at DESC, id DESC LIMIT 1",
                new String[]{id})) {
            return c.moveToFirst() && !c.isNull(0) ? c.getLong(0) : null;
        }
    }

    public List<PricePoint> priceHistory(String itemId, int limit) {
        List<PricePoint> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("price_history", new String[]{"price","checked_at"},
                "item_id=?", new String[]{itemId}, null, null, "checked_at DESC, id DESC", String.valueOf(Math.max(1, limit)))) {
            while (c.moveToNext()) out.add(new PricePoint(c.getLong(0), c.getLong(1)));
        }
        return out;
    }

    public void addPurchase(String itemId, Long price) {
        ContentValues v = new ContentValues();
        v.put("item_id", itemId);
        if (price != null) v.put("price", price);
        v.put("purchased_at", System.currentTimeMillis());
        helper.getWritableDatabase().insert("purchase_history", null, v);
    }

    public List<Purchase> purchases(String itemId, int limit) {
        List<Purchase> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("purchase_history", new String[]{"id","price","purchased_at"},
                "item_id=?", new String[]{itemId}, null, null, "purchased_at DESC, id DESC", limit <= 0 ? null : String.valueOf(limit))) {
            while (c.moveToNext()) out.add(new Purchase(c.getLong(0), c.isNull(1) ? null : c.getLong(1), c.getLong(2)));
        }
        return out;
    }

    public int purchaseCount(String itemId) {
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM purchase_history WHERE item_id=?", new String[]{itemId})) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public void deletePurchase(long purchaseId) {
        helper.getWritableDatabase().delete("purchase_history", "id=?", new String[]{String.valueOf(purchaseId)});
    }

    public List<Tag> listTags() {
        List<Tag> out = new ArrayList<>();
        try (Cursor c = helper.getReadableDatabase().query("tags", new String[]{"id","name","sort_index"}, null, null, null, null, "sort_index ASC, id ASC")) {
            while (c.moveToNext()) out.add(new Tag(c.getLong(0), c.getString(1), c.getInt(2)));
        }
        return out;
    }

    public Tag createTag(String name) {
        if (name == null || name.trim().isBlank()) return null;
        String clean = name.trim();
        SQLiteDatabase db = helper.getWritableDatabase();
        try (Cursor c = db.query("tags", new String[]{"id","name","sort_index"}, "name=? COLLATE NOCASE", new String[]{clean}, null, null, null, "1")) {
            if (c.moveToFirst()) return new Tag(c.getLong(0), c.getString(1), c.getInt(2));
        }
        int sortIndex = nextTagSortIndex();
        ContentValues v = new ContentValues();
        v.put("name", clean);
        v.put("sort_index", sortIndex);
        long id = db.insert("tags", null, v);
        return id < 0 ? null : new Tag(id, clean, sortIndex);
    }

    public void renameTag(long id, String name) {
        if (name == null || name.trim().isBlank()) return;
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        try {
            helper.getWritableDatabase().update("tags", v, "id=?", new String[]{String.valueOf(id)});
        } catch (android.database.sqlite.SQLiteConstraintException ignored) {
            // Keep the existing tag if the requested name already exists.
        }
    }

    public void deleteTag(long id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("item_tags", "tag_id=?", new String[]{String.valueOf(id)});
            db.delete("tags", "id=?", new String[]{String.valueOf(id)});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public void setTagOrder(List<Long> ids) {
        if (ids == null) return;
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < ids.size(); i++) {
                Long id = ids.get(i);
                if (id == null) continue;
                ContentValues v = new ContentValues();
                v.put("sort_index", i);
                db.update("tags", v, "id=?", new String[]{String.valueOf(id)});
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public Set<Long> tagsForItem(String itemId) {
        Set<Long> out = new HashSet<>();
        try (Cursor c = helper.getReadableDatabase().query("item_tags", new String[]{"tag_id"}, "item_id=?", new String[]{itemId}, null, null, "tag_id ASC")) {
            while (c.moveToNext()) out.add(c.getLong(0));
        }
        return out;
    }

    public void addTagToItem(String itemId, long tagId) {
        if (itemId == null || itemId.isBlank() || tagId <= 0) return;
        ContentValues v = new ContentValues();
        v.put("item_id", itemId);
        v.put("tag_id", tagId);
        helper.getWritableDatabase().insertWithOnConflict(
                "item_tags", null, v, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void removeTagFromItem(String itemId, long tagId) {
        if (itemId == null || itemId.isBlank() || tagId <= 0) return;
        helper.getWritableDatabase().delete(
                "item_tags", "item_id=? AND tag_id=?",
                new String[]{itemId, String.valueOf(tagId)});
    }

    public void setTagsForItem(String itemId, Set<Long> ids) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("item_tags", "item_id=?", new String[]{itemId});
            if (ids != null) for (Long id : ids) {
                if (id == null) continue;
                ContentValues v = new ContentValues();
                v.put("item_id", itemId);
                v.put("tag_id", id);
                db.insertWithOnConflict("item_tags", null, v, SQLiteDatabase.CONFLICT_IGNORE);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public List<Tag> tagsForItemResolved(String itemId) {
        List<Tag> out = new ArrayList<>();
        String sql = "SELECT t.id,t.name,t.sort_index FROM tags t JOIN item_tags it ON it.tag_id=t.id WHERE it.item_id=? ORDER BY t.sort_index ASC,t.id ASC";
        try (Cursor c = helper.getReadableDatabase().rawQuery(sql, new String[]{itemId})) {
            while (c.moveToNext()) out.add(new Tag(c.getLong(0), c.getString(1), c.getInt(2)));
        }
        return out;
    }

    private WishlistItem findBySourceOrUrl(String sourceId, String url) {
        String normalized = GeneralRetailIdentity.canonical(url);
        if (normalized != null && !normalized.equals(url)) {
            WishlistItem match = findBySourceOrUrl(sourceId, normalized);
            if (match != null) return match;
        }
        String sel;
        String[] args;
        if (sourceId != null && !sourceId.isBlank()) {
            sel = "source_node_id=? OR url=?";
            args = new String[]{sourceId, url};
        } else {
            sel = "url=?";
            args = new String[]{url};
        }
        try (Cursor c = helper.getReadableDatabase().query("wish_items", null, sel, args, null, null, null, "1")) {
            if (c.moveToFirst()) return readItem(c);
        }
        if (normalized != null && GeneralRetailIdentity.storeFromText(normalized)) {
            // Old Wish cards may still contain an advertising query. Compare
            // only our two exact product hosts, not unrelated saved websites.
            try (Cursor c = helper.getReadableDatabase().query("wish_items", null,
                    "url LIKE ? OR url LIKE ?", new String[]{"%askul.co.jp/p/%", "%monotaro.com/p/%"},
                    null, null, null)) {
                while (c.moveToNext()) {
                    WishlistItem item = readItem(c);
                    if (normalized.equals(GeneralRetailIdentity.canonical(item.url))) return item;
                }
            }
        }
        return null;
    }

    private int nextSortIndex() {
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COALESCE(MAX(sort_index),-1)+1 FROM wish_items", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private int nextTagSortIndex() {
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT COALESCE(MAX(sort_index),-1)+1 FROM tags", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private ContentValues values(WishlistItem item) {
        ContentValues v = new ContentValues();
        v.put("id", item.id);
        v.put("source_node_id", item.sourceNodeId);
        v.put("title", item.title);
        v.put("url", item.url);
        v.put("source_name", item.sourceName);
        v.put("note", item.note == null ? "" : item.note);
        v.put("thumbnail_path", item.thumbnailPath);
        v.put("favicon_path", item.faviconPath);
        v.put("preview_image_url", item.previewImageUrl);
        v.put("preview_path", item.previewPath);
        v.put("user_title_edited", item.userTitleEdited ? 1 : 0);
        v.put("user_image_edited", item.userImageEdited ? 1 : 0);
        if (item.registeredPrice != null) v.put("registered_price", item.registeredPrice);
        if (item.currentPrice != null) v.put("current_price", item.currentPrice);
        v.put("price_quote_kind", item.priceQuoteKind);
        if (item.priceMinimum != null) v.put("price_minimum", item.priceMinimum);
        if (item.priceMaximum != null) v.put("price_maximum", item.priceMaximum);
        if (item.lastPriceCheckedAt != null) v.put("last_price_checked_at", item.lastPriceCheckedAt);
        v.put("price_fetch_ok", item.priceFetchOk ? 1 : 0);
        v.put("last_price_error", item.lastPriceError);
        v.put("acquisition_mode", item.acquisitionMode == null ? WishlistMode.UNRESOLVED.name() : item.acquisitionMode.name());
        v.put("status", item.status == null ? "UNKNOWN" : item.status);
        v.put("previous_status", item.previousStatus == null ? "UNKNOWN" : item.previousStatus);
        v.put("last_confirmed_status",item.lastConfirmedStatus);
        if(item.lastConfirmedAt!=null)v.put("last_confirmed_at",item.lastConfirmedAt);
        v.put("site_state", item.siteState == null ? WishlistSiteState.OK : item.siteState);
        if (item.siteCheckedAt != null) v.put("site_checked_at", item.siteCheckedAt);
        v.put("monitor_resume", item.monitorResume ? 1 : 0);
        v.put("sort_index", item.sortIndex);
        v.put("created_at", item.createdAt);
        v.put("updated_at", item.updatedAt);
        return v;
    }

    private WishlistItem readItem(Cursor c) {
        WishlistItem i = new WishlistItem();
        i.id = s(c, "id");
        i.sourceNodeId = s(c, "source_node_id");
        i.title = s(c, "title");
        i.url = s(c, "url");
        i.acquisitionMode = WishlistMode.read(s(c, "acquisition_mode"));
        i.sourceName = s(c, "source_name");
        i.note = s(c, "note");
        i.thumbnailPath = s(c, "thumbnail_path");
        i.faviconPath = s(c, "favicon_path");
        i.previewImageUrl = s(c, "preview_image_url");
        i.previewPath = s(c, "preview_path");
        i.userTitleEdited = integer(c, "user_title_edited") != 0;
        i.userImageEdited = integer(c, "user_image_edited") != 0;
        i.registeredPrice = lng(c, "registered_price");
        i.currentPrice = lng(c, "current_price");
        i.priceQuoteKind = s(c, "price_quote_kind");
        i.priceMinimum = lng(c, "price_minimum");
        i.priceMaximum = lng(c, "price_maximum");
        i.lastPriceCheckedAt = lng(c, "last_price_checked_at");
        i.priceFetchOk = integer(c, "price_fetch_ok") != 0;
        i.lastPriceError = s(c, "last_price_error");
        i.status = s(c, "status");
        i.previousStatus = s(c, "previous_status");
        i.lastConfirmedStatus = s(c,"last_confirmed_status");
        i.lastConfirmedAt = lng(c,"last_confirmed_at");
        i.siteState = s(c, "site_state");
        i.siteCheckedAt = lng(c, "site_checked_at");
        i.monitorResume = integer(c, "monitor_resume") != 0;
        i.sortIndex = integer(c, "sort_index");
        Long created = lng(c, "created_at");
        Long updated = lng(c, "updated_at");
        i.createdAt = created == null ? 0 : created;
        i.updatedAt = updated == null ? 0 : updated;
        return i;
    }

    private static String s(Cursor c, String name) { int idx=c.getColumnIndex(name); return idx<0||c.isNull(idx)?null:c.getString(idx); }
    private static int integer(Cursor c, String name) { int idx=c.getColumnIndex(name); return idx<0||c.isNull(idx)?0:c.getInt(idx); }
    private static Long lng(Cursor c, String name) { int idx=c.getColumnIndex(name); return idx<0||c.isNull(idx)?null:c.getLong(idx); }

    public static final class PricePoint {
        public final long price;
        public final long checkedAt;
        PricePoint(long price, long checkedAt) { this.price=price; this.checkedAt=checkedAt; }
    }
    public static final class Purchase {
        public final long id;
        public final Long price;
        public final long purchasedAt;
        Purchase(long id, Long price, long purchasedAt) { this.id=id; this.price=price; this.purchasedAt=purchasedAt; }
    }
    public static final class Tag {
        public final long id;
        public final String name;
        public final int sortIndex;
        Tag(long id, String name, int sortIndex) { this.id=id; this.name=name; this.sortIndex=sortIndex; }
    }

    private static final class Db extends SQLiteOpenHelper {
        Db(Context c) { super(c, "bookmarklauncher_wishlist.db", null, 11); }
        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE wish_items (" +
                    "id TEXT PRIMARY KEY, source_node_id TEXT, title TEXT NOT NULL, url TEXT NOT NULL, acquisition_mode TEXT NOT NULL DEFAULT 'UNRESOLVED', source_name TEXT, note TEXT NOT NULL DEFAULT ''," +
                    "thumbnail_path TEXT, favicon_path TEXT, preview_image_url TEXT, preview_path TEXT, user_title_edited INTEGER NOT NULL DEFAULT 0, user_image_edited INTEGER NOT NULL DEFAULT 0," +
                    "registered_price INTEGER, current_price INTEGER, last_price_checked_at INTEGER," +
                    "price_quote_kind TEXT, price_minimum INTEGER, price_maximum INTEGER," +
                    "price_fetch_ok INTEGER NOT NULL DEFAULT 0, last_price_error TEXT, status TEXT NOT NULL DEFAULT 'UNKNOWN', previous_status TEXT NOT NULL DEFAULT 'UNKNOWN'," +
                    "last_confirmed_status TEXT, last_confirmed_at INTEGER," +
                    "site_state TEXT NOT NULL DEFAULT 'OK', site_checked_at INTEGER," +
                    "monitor_resume INTEGER NOT NULL DEFAULT 0, sort_index INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)");
            db.execSQL("CREATE INDEX wish_items_sort_idx ON wish_items(sort_index)");
            db.execSQL("CREATE INDEX wish_items_url_idx ON wish_items(url)");
            db.execSQL("CREATE TABLE tags (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE, sort_index INTEGER NOT NULL DEFAULT 0)");
            db.execSQL("CREATE TABLE item_tags (item_id TEXT NOT NULL, tag_id INTEGER NOT NULL, PRIMARY KEY(item_id,tag_id))");
            db.execSQL("CREATE TABLE price_history (id INTEGER PRIMARY KEY AUTOINCREMENT, item_id TEXT NOT NULL, price INTEGER NOT NULL, checked_at INTEGER NOT NULL, source TEXT)");
            db.execSQL("CREATE INDEX price_history_item_idx ON price_history(item_id,checked_at DESC)");
            db.execSQL("CREATE TABLE purchase_history (id INTEGER PRIMARY KEY AUTOINCREMENT, item_id TEXT NOT NULL, price INTEGER, purchased_at INTEGER NOT NULL)");
            db.execSQL("CREATE INDEX purchase_history_item_idx ON purchase_history(item_id,purchased_at DESC)");
        }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            if (oldVersion < 2) {
                // Non-destructive migration: preserve Wish items, tags, history and sorting.
                db.execSQL("ALTER TABLE wish_items ADD COLUMN preview_image_url TEXT");
                db.execSQL("ALTER TABLE wish_items ADD COLUMN preview_path TEXT");
                db.execSQL("ALTER TABLE wish_items ADD COLUMN user_title_edited INTEGER NOT NULL DEFAULT 0");
            }
            if (oldVersion < 3) {
                db.execSQL("ALTER TABLE wish_items ADD COLUMN last_price_error TEXT");
            }
            if (oldVersion < 4) {
                db.execSQL("ALTER TABLE wish_items ADD COLUMN user_image_edited INTEGER NOT NULL DEFAULT 0");
            }
            if (oldVersion < 5) {
                db.execSQL("ALTER TABLE wish_items ADD COLUMN note TEXT NOT NULL DEFAULT ''");
            }
            if (oldVersion < 6) {
                db.execSQL("ALTER TABLE wish_items ADD COLUMN price_quote_kind TEXT");
                db.execSQL("ALTER TABLE wish_items ADD COLUMN price_minimum INTEGER");
                db.execSQL("ALTER TABLE wish_items ADD COLUMN price_maximum INTEGER");
            }
            if (oldVersion < 7) {
                db.execSQL("ALTER TABLE wish_items ADD COLUMN site_state TEXT NOT NULL DEFAULT 'OK'");
                db.execSQL("ALTER TABLE wish_items ADD COLUMN site_checked_at INTEGER");
                // Legacy page-wide "sold out" text often belonged to another size/item.
                // Clear uncertain old flags on minimum quotes; the next crawl can restore
                // a genuine product-specific UNAVAILABLE from structured availability.
                db.execSQL("UPDATE wish_items SET status='UNKNOWN' WHERE " +
                        "status='UNAVAILABLE' AND price_quote_kind IS NOT NULL AND price_minimum IS NOT NULL");
            }
            if (oldVersion < 8) {
                // Older versions assigned UNAVAILABLE from any sold-out words in
                // the entire HTML, including another product or hidden template.
                // Provenance was never stored, so conservatively clear ONLY this
                // potentially false stock flag. Do not touch site state, titles,
                // images, prices or price history. A later crawl may reverify.
                db.execSQL("UPDATE wish_items SET status='UNKNOWN', previous_status='UNKNOWN' " +
                        "WHERE status='UNAVAILABLE'");
            }
            if (oldVersion < 9) {
                db.execSQL("ALTER TABLE wish_items ADD COLUMN last_confirmed_status TEXT");
                db.execSQL("ALTER TABLE wish_items ADD COLUMN last_confirmed_at INTEGER");
                // Keep existing known observations, but distinguish them from the latest crawl.
                db.execSQL("UPDATE wish_items SET last_confirmed_status=status,last_confirmed_at=updated_at " +
                        "WHERE status IN ('AVAILABLE','UNAVAILABLE')");
            }
            if (oldVersion < 10) {
                // Keep every row and its history. Direct verified product URLs can be
                // routed immediately; redirects/short links remain UNRESOLVED until
                // the next successful fetch verifies the final product identity.
                db.execSQL("ALTER TABLE wish_items ADD COLUMN acquisition_mode TEXT NOT NULL DEFAULT 'UNRESOLVED'");
                List<String[]> detected = new ArrayList<>();
                try (Cursor rows = db.query("wish_items", new String[]{"id","url"}, null, null, null, null, null)) {
                    while (rows.moveToNext()) {
                        WishlistMode mode = WishlistMode.forDirectUrl(rows.getString(1));
                        if (mode != WishlistMode.UNRESOLVED)
                            detected.add(new String[]{rows.getString(0),mode.name()});
                    }
                }
                for (String[] entry : detected) {
                    ContentValues value = new ContentValues();
                    value.put("acquisition_mode",entry[1]);
                    db.update("wish_items",value,"id=?",new String[]{entry[0]});
                }
            }
            if (oldVersion < 11) {
                // Rebind only previously GENERAL/UNRESOLVED cards whose original
                // URL identifies one of the newly isolated large retailers.
                // Do not change any price/image/name, history or user overrides.
                List<String[]> remap = new ArrayList<>();
                try (Cursor rows = db.query("wish_items", new String[]{"id","url","acquisition_mode"},
                        "acquisition_mode IN ('GENERAL','UNRESOLVED')", null, null, null, null)) {
                    while (rows.moveToNext()) {
                        WishlistMode detected = WishlistMode.forDirectUrl(rows.getString(1));
                        if (detected == WishlistMode.UNIQLO || detected == WishlistMode.YODOBASHI
                                || detected == WishlistMode.BICCAMERA)
                            remap.add(new String[]{rows.getString(0), detected.name()});
                    }
                }
                for (String[] entry : remap) {
                    ContentValues values = new ContentValues();
                    values.put("acquisition_mode", entry[1]);
                    db.update("wish_items", values, "id=?", new String[]{entry[0]});
                }
            }
        }
    }
}
