package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/** Read-only stock evidence adapters; each merchant is isolated from A-G. */
public final class WishlistRetailDedicatedStockDom {
    private WishlistRetailDedicatedStockDom() { }

    public static String javascript(URL url) {
        WishlistRetailDedicatedMode merchant = WishlistRetailDedicatedMode.forUrl(url);
        if (merchant == WishlistRetailDedicatedMode.NONE)
            return "JSON.stringify({status:'UNKNOWN',reason:'unsupported'})";
        if (merchant == WishlistRetailDedicatedMode.ISETAN)
            return WishlistIsetanStockDom.javascript(url);
        String path = url.getPath().replaceAll("/+$", "").toLowerCase(Locale.ROOT);
        String item = merchant == WishlistRetailDedicatedMode.ZOZO
                ? WishlistRetailDedicatedMode.zozoGoodsId(url)
                : merchant == WishlistRetailDedicatedMode.EDION
                  ? WishlistRetailDedicatedMode.query(url, "p_cd")
                  : WishlistGeneralProductIdentity.code(url);
        String did = merchant == WishlistRetailDedicatedMode.ZOZO
                ? WishlistRetailDedicatedMode.query(url, "did") : "";
        String selected = "";
        if (merchant == WishlistRetailDedicatedMode.AU) {
            for (String key : new String[]{"variant_id", "sku_id", "variant"}) {
                selected = WishlistRetailDedicatedMode.query(url, key);
                if (!selected.isEmpty()) break;
            }
        }
        return SCRIPT.replace("__SELECTED__", JSONObject.quote(selected))
                .replace("__MERCHANT__", JSONObject.quote(merchant.name()))
                .replace("__HOST__", JSONObject.quote(url.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(path))
                .replace("__ITEM__", JSONObject.quote(item == null ? "" : item))
                .replace("__DID__", JSONObject.quote(did));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const r={status:'UNKNOWN',reason:'pending',product:false,idBound:false,
   variantBound:false,liveCarts:0,stockPairs:0,didRequired:false};
 const done=()=>JSON.stringify(r);
 try {
   const merchant=__MERCHANT__,host=__HOST__,path=__PATH__,item=__ITEM__,did=__DID__,selected=__SELECTED__;
   r.didRequired=!!did;
   const clean=s=>String(s||'').replace(/\\/+$/,'').toLowerCase();
   if(location.protocol!=='https:'||location.hostname.toLowerCase()!==host||
      clean(location.pathname)!==path){r.reason='document-mismatch';return done();}
   const qp=new URLSearchParams(location.search);
   if(merchant==='EDION'&&qp.get('p_cd')!==item){r.reason='sku-query-mismatch';return done();}
   if(merchant==='ZOZO'&&did&&qp.get('did')!==did){r.reason='variant-url-mismatch';return done();}
   const main=document.querySelector('main,[role=main],#main,#contents,#content')||document.body;
   if(!main){r.reason='document-pending';return done();}
   const bad='header,nav,footer,aside,[class*=recommend],[class*=related],'+
     '[class*=ranking],[class*=pickup],[id*=recommend],[id*=related]';
   const txt=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ').trim();
   const live=e=>{if(!e||e.disabled||e.hasAttribute('disabled')||
       e.getAttribute('aria-disabled')==='true')return false;
     for(let x=e;x;x=x.parentElement){if(x.hidden||x.hasAttribute('inert')||
       x.getAttribute('aria-hidden')==='true')return false;
       const s=getComputedStyle(x);if(s.display==='none'||s.visibility==='hidden'||
         s.visibility==='collapse'||Number(s.opacity)===0)return false;}return true;};
   const heads=[...main.querySelectorAll('h1')].filter(e=>live(e)&&!e.closest(bad));
   if(heads.length!==1||txt(heads[0]).length<3){r.reason='heading-unverified';return done();}
   r.product=true;
   let canonical=document.querySelector('link[rel=canonical]');
   let canonicalMatch=false;
   if(canonical&&canonical.href){
     try{let c=new URL(canonical.href,location.href);
       canonicalMatch=c.hostname.toLowerCase()===host&&clean(c.pathname)===path&&
         (merchant!=='EDION'||c.searchParams.get('p_cd')===item);
       // A canonical for a different product is a hard conflict, not proof.
       if(!canonicalMatch){r.reason='canonical-different-product';return done();}
     }catch(_){r.reason='canonical-invalid';return done();}
   }
   const text=txt(main).slice(0,110000);
   const normal=s=>String(s||'').toLowerCase();
   const identities=[...main.querySelectorAll('[data-product-id],[data-item-id],[data-goods-id],'+
     '[data-sku],[data-product-code],[itemprop=sku],input[name*=product],input[name*=goods]')]
      .filter(e=>!e.closest(bad)).slice(0,100);
   const attrMatch=identities.some(e=>{
     const a=['data-product-id','data-item-id','data-goods-id','data-sku',
       'data-product-code','content','value'].map(k=>e.getAttribute(k)||'');
     return a.some(x=>normal(x)===normal(item));});
   const escaped=item;
   const labelMatch=!!item&&new RegExp('(?:商品コード|商品番号|品番|問い合わせ番号|お問い合わせ番号|SKU|JAN)\\\\s*[:：#]?\\\\s*'+escaped+'(?:\\\\D|$)','i').test(text);
   if(merchant==='EDION'){
     // This item's canonical detail URL + exact p_cd proves its identity
     // even when a dynamic product DOM omits a printed manufacturer SKU.
     r.idBound=!!(canonicalMatch||attrMatch||labelMatch);
     // Edion 403/503 error pages are never positive evidence.
     if(!r.idBound){r.reason='edion-item-unverified';return done();}
   } else if(merchant==='AU') {
     // Next.js storefronts may not print an SKU; a matching canonical and
     // exactly one visible detail heading bind the product URL to its cart.
     r.idBound=canonicalMatch||attrMatch||labelMatch;
     if(!r.idBound){r.reason='au-item-unverified';return done();}
   } else {
     // Inquiry numbers can differ by 1,000,000. Never assume a matching
     // store number. The canonical and a unique H1 safely bind the product
     // page, but never bind a requested ?did variant by themselves.
     r.idBound=canonicalMatch||attrMatch||labelMatch;
     if(!r.idBound){r.reason='zozo-item-unverified';return done();}
     if(did&&!/^[0-9]{5,18}$/.test(did)){r.reason='invalid-variant-id';return done();}
   }
   const adds=[...main.querySelectorAll('button,[role=button],input[type=submit],a[href]')]
      .filter(e=>live(e)&&!e.closest(bad))
      .filter(e=>{
        const t=[txt(e),e.getAttribute('aria-label')||'',e.value||''].join(' ');
        return /カート\\s*に\\s*入れる|かご\\s*に\\s*入れる|バッグ\\s*に\\s*入れる|add\\s*to\\s*(?:cart|bag)/i.test(t)
           || (merchant==='EDION'&&(e.id==='into_cart'||e.id==='skip_cart'))
           || (merchant==='AU'&&e.tagName==='BUTTON'&&/CartButton_cartButton/.test(e.className||''));
       });
   r.liveCarts=adds.length;
   if(!adds.length){r.reason='no-product-cart';return done();}
   const negative=/(在庫\\s*[:：]?\\s*(?:なし|切れ)|売り切れ|完売|入荷待ち|販売終了|out of stock|sold out)/i;
   const positive=/(在庫\\s*[:：]?\\s*(?:あり|有り|有)|在庫数\\s*[1-9][0-9]*|残り\\s*[1-9][0-9]*\\s*(?:個|点)|在庫残少|残りわずか)/i;
   for(const c of adds.slice(0,30)){
     let root=c;
     for(let i=0;i<6&&root.parentElement&&root!==main;i++){
       const p=root.parentElement;
       if(txt(p).length>2500)break;
       if(p.querySelectorAll('h1').length>1)break;
       root=p;
     }
     const t=txt(root).slice(0,2500);
     if(negative.test(t))continue;
     if(merchant==='EDION'){
       if(!positive.test(t))continue;
       r.variantBound=true;r.stockPairs++;
     }else if(merchant==='AU'){
       // Require a genuine product purchase button, not the shop's header
       // shopping-cart link. This is never inferred from the link alone.
       if(c.tagName!=='BUTTON'||!/CartButton_cartButton/.test(c.className||''))continue;
       if(!canonicalMatch&&!attrMatch&&!labelMatch)continue;
       if(selected){
         let matched=false;
         for(let n=c,i=0;n&&i<6;i++,n=n.parentElement){
           const values=[n.getAttribute('data-variant-id'),n.getAttribute('data-sku-id'),
               n.getAttribute('data-selected-id'),n.getAttribute('href')]
                .filter(Boolean).join(' ');
           if(values.includes(selected)){matched=true;break;}
         }
         if(!matched)continue;
       }
       r.variantBound=true;r.stockPairs++;
     }else{
       // ZOZO size/colour variants are NOT interchangeable. An exact ?did
       // requires a matching variant-specific node around the live action.
       if(did){
         let bound=false;for(let n=c,i=0;n&&i<7;i++,n=n.parentElement){
           let attrs=[n.getAttribute('data-did'),n.getAttribute('data-detail-id'),
             n.getAttribute('data-variant-id'),n.getAttribute('href')].filter(Boolean).join(' ');
           if(new RegExp('(?:^|\\\\D)'+did+'(?:$|\\\\D)').test(attrs)){bound=true;break;}
         }
         if(!bound)continue;
       }
       // ZOZO must show local stock, not a floating global Add button.
       if(!positive.test(t))continue;
       r.variantBound=true;r.stockPairs++;
     }
   }
   if(r.stockPairs>0&&r.idBound&&r.variantBound){
     r.status='AVAILABLE';r.reason='merchant-item-cart-verified';
   }else r.reason=merchant==='ZOZO'&&did?'zozo-did-not-bound':'no-local-stock-proof';
   return done();
 }catch(_){r.reason='dom-error';return done();}
})()
""";
}
