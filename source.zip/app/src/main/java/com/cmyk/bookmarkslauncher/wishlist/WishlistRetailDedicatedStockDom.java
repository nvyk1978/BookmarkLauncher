package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import java.util.Locale;
import org.json.JSONObject;

/** Read-only stock evidence adapters; each merchant is isolated from A-G. */
public final class WishlistRetailDedicatedStockDom {
    private WishlistRetailDedicatedStockDom() { }

    public static String javascript(URL url) {
        WishlistRetailDedicatedMode merchant = WishlistRetailDedicatedMode.forUrl(url);
        if (merchant == WishlistRetailDedicatedMode.NONE)
            return "JSON.stringify({status:'UNKNOWN',reason:'unsupported'})";
        if (merchant == WishlistRetailDedicatedMode.ISETAN)
            return WishlistIsetanStockDom.javascript(url);
        String path = url.getPath().replaceAll("/+$", "").toLowerCase(Locale.ROOT);
        String item = merchant == WishlistRetailDedicatedMode.ZOZO
                ? WishlistRetailDedicatedMode.zozoGoodsId(url)
                : merchant == WishlistRetailDedicatedMode.EDION
                  ? WishlistRetailDedicatedMode.query(url, "p_cd")
                  : WishlistGeneralProductIdentity.code(url);
        String did = merchant == WishlistRetailDedicatedMode.ZOZO
                ? WishlistRetailDedicatedMode.query(url, "did") : "";
        String selected = "";
        if (merchant == WishlistRetailDedicatedMode.AU) {
            for (String key : new String[]{"variant_id", "sku_id", "variant"}) {
                selected = WishlistRetailDedicatedMode.query(url, key);
                if (!selected.isEmpty()) break;
            }
        }
        return SCRIPT.replace("__SELECTED__", JSONObject.quote(selected))
                .replace("__MERCHANT__", JSONObject.quote(merchant.name()))
                .replace("__HOST__", JSONObject.quote(url.getHost().toLowerCase(Locale.ROOT)))
                .replace("__PATH__", JSONObject.quote(path))
                .replace("__ITEM__", JSONObject.quote(item == null ? "" : item))
                .replace("__DID__", JSONObject.quote(did));
    }

    private static final String SCRIPT = """
(function(){'use strict';
 const r={status:'UNKNOWN',reason:'pending',product:false,idBound:false,
   variantBound:false,liveCarts:0,stockPairs:0,didRequired:false,
   didNodes:0,didLocalCarts:0,didLocalStock:0,
   didStateRecords:0,didStateStock:0,didStateContradictions:0,didStateExamined:0,
   didStateOwnerMatched:0,didStateNestedStock:0,didStateUnproven:0,
   didStateKeyHints:'none',didStateRecordWithStockKey:0};
 const done=()=>JSON.stringify(r);
 try {
   const merchant=__MERCHANT__,host=__HOST__,path=__PATH__,item=__ITEM__,did=__DID__,selected=__SELECTED__;
   r.didRequired=!!did;
   const clean=s=>String(s||'').replace(/\\/+$/,'').toLowerCase();
   const zozoPath=p=>clean(p).match(new RegExp('^/(?:sp/)?(?:shop/([a-z0-9_-]+)/)?goods(?:-sale)?/([0-9]{5,15})$'));
   const zozoHost=h=>h==='zozo.jp'||h==='www.zozo.jp';
   const savedZozo=merchant==='ZOZO'?zozoPath(path):null;
   const liveZozo=merchant==='ZOZO'?zozoPath(location.pathname):null;
   const zozoSame=merchant==='ZOZO'&&zozoHost(host)&&zozoHost(location.hostname.toLowerCase())&&
      savedZozo&&liveZozo&&savedZozo[2]===item&&liveZozo[2]===item&&
      (!savedZozo[1]||!liveZozo[1]||savedZozo[1]===liveZozo[1]);
   if(location.protocol!=='https:'||!(merchant==='ZOZO'?zozoSame:
      location.hostname.toLowerCase()===host&&clean(location.pathname)===path)){
      r.reason='document-mismatch';return done();}
   const qp=new URLSearchParams(location.search);
   if(merchant==='EDION'&&qp.get('p_cd')!==item){r.reason='sku-query-mismatch';return done();}
   if(merchant==='ZOZO'&&did&&qp.get('did')!==did){r.reason='variant-url-mismatch';return done();}
   const main=document.querySelector('main,[role=main],#main,#contents,#content')||document.body;
   if(!main){r.reason='document-pending';return done();}
   const bad='header,nav,footer,aside,[class*=recommend],[class*=related],'+
     '[class*=ranking],[class*=pickup],[id*=recommend],[id*=related]';
   const txt=e=>String((e&&(e.innerText||e.textContent))||'').replace(/\\u00a0|　/g,' ').trim();
   const live=e=>{if(!e||e.disabled||e.hasAttribute('disabled')||
       e.getAttribute('aria-disabled')==='true')return false;
     for(let x=e;x;x=x.parentElement){if(x.hidden||x.hasAttribute('inert')||
       x.getAttribute('aria-hidden')==='true')return false;
       const s=getComputedStyle(x);if(s.display==='none'||s.visibility==='hidden'||
         s.visibility==='collapse'||Number(s.opacity)===0)return false;}return true;};
   const heads=[...main.querySelectorAll('h1')].filter(e=>live(e)&&!e.closest(bad));
   if(heads.length!==1||txt(heads[0]).length<3){r.reason='heading-unverified';return done();}
   r.product=true;
   let canonical=document.querySelector('link[rel=canonical]');
   let canonicalMatch=false;
   if(canonical&&canonical.href){
     try{let c=new URL(canonical.href,location.href);
       if(merchant==='ZOZO'){
         const saved=zozoPath(path),resolved=zozoPath(c.pathname);
         canonicalMatch=zozoHost(c.hostname.toLowerCase())&&!!saved&&!!resolved&&
           saved[2]===item&&resolved[2]===item&&
           (!saved[1]||!resolved[1]||saved[1]===resolved[1]);
       }else{
         canonicalMatch=c.hostname.toLowerCase()===host&&clean(c.pathname)===path&&
           (merchant!=='EDION'||!c.searchParams.has('p_cd')||c.searchParams.get('p_cd')===item);
       }
       // A canonical for a different product is a hard conflict, not proof.
       if(!canonicalMatch){r.reason='canonical-different-product';return done();}
     }catch(_){r.reason='canonical-invalid';return done();}
   }
   const text=txt(main).slice(0,110000);
   const normal=s=>String(s||'').toLowerCase();
   const identities=[...main.querySelectorAll('[data-product-id],[data-item-id],[data-goods-id],'+
     '[data-sku],[data-product-code],[itemprop=sku],input[name*=product],input[name*=goods]')]
      .filter(e=>!e.closest(bad)).slice(0,100);
   const attrMatch=identities.some(e=>{
     const a=['data-product-id','data-item-id','data-goods-id','data-sku',
       'data-product-code','content','value'].map(k=>e.getAttribute(k)||'');
     return a.some(x=>normal(x)===normal(item));});
   const escaped=item;
   const labelMatch=!!item&&new RegExp('(?:商品コード|商品番号|品番|問い合わせ番号|お問い合わせ番号|SKU|JAN)\\\\s*[:：#]?\\\\s*'+escaped+'(?:\\\\D|$)','i').test(text);
   if(merchant==='EDION'){
     // This item's canonical detail URL + exact p_cd proves its identity
     // even when a dynamic product DOM omits a printed manufacturer SKU.
     r.idBound=!!(canonicalMatch||attrMatch||labelMatch);
     // Edion 403/503 error pages are never positive evidence.
     if(!r.idBound){r.reason='edion-item-unverified';return done();}
   } else if(merchant==='AU') {
     // Next.js storefronts may not print an SKU; a matching canonical and
     // exactly one visible detail heading bind the product URL to its cart.
     r.idBound=canonicalMatch||attrMatch||labelMatch;
     if(!r.idBound){r.reason='au-item-unverified';return done();}
   } else {
     // The ZOZO inquiry number (not a store SKU) may be goods ID + 1,000,000.
     // Only an explicitly ZOZO-labelled inquiry is eligible for that offset.
     const inquiry=[...text.matchAll(/問い合わせ番号\\s*[:：]?\\s*([0-9]{5,15})\\s*[（(]ZOZO[）)]/g)];
     const zozoInquiry=inquiry.some(m=>Number(m[1])===Number(item)||
         Number(m[1])===Number(item)+1000000);
     r.idBound=canonicalMatch||attrMatch||labelMatch||zozoInquiry;
     if(!r.idBound){r.reason='zozo-item-unverified';return done();}
     if(did&&!/^[0-9]{5,18}$/.test(did)){r.reason='invalid-variant-id';return done();}
   }
   const adds=[...main.querySelectorAll('button,[role=button],input[type=submit],a[href]')]
      .filter(e=>live(e)&&!e.closest(bad))
      .filter(e=>{
        const t=[txt(e),e.getAttribute('aria-label')||'',e.value||''].join(' ');
        return /カート\\s*に\\s*入れる|かご\\s*に\\s*入れる|バッグ\\s*に\\s*入れる|add\\s*to\\s*(?:cart|bag)/i.test(t)
           || (merchant==='EDION'&&(e.id==='into_cart'||e.id==='skip_cart'))
           || (merchant==='AU'&&e.tagName==='BUTTON'&&/CartButton_cartButton/.test(e.className||''));
       });
   r.liveCarts=adds.length;
   if(!adds.length){r.reason='no-product-cart';return done();}
   const negative=/(在庫\\s*[:：]?\\s*(?:なし|切れ)|売り切れ|完売|入荷待ち|販売終了|out of stock|sold out)/i;
   const positive=/(在庫\\s*[:：]?\\s*(?:あり|有り|有|わずか|僅か)|在庫数\\s*[1-9][0-9]*|残り\\s*[1-9][0-9]*\\s*(?:個|点)|在庫残少|残りわずか)/i;
   // EDION's actual shipping stock indicator lives in the separate
   // 「配送受取のかた / 在庫状況 ○在庫あり」 block, often outside the small
   // immediate ancestor of #into_cart. A visible item-specific shipping
   // section and the verified product's active cart are BOTH required.
   let edionDeliveryStock=false;
   if(merchant==='EDION'){
     const full=txt(main),name=txt(heads[0]);
     const begin=full.indexOf(name);
     if(begin>=0){
       const detail=full.slice(begin+name.length,begin+16000);
       const cartAt=detail.search(/カート\\s*に\\s*入れる/);
       if(cartAt>=0){
         const before=detail.slice(Math.max(0,cartAt-2200),cartAt);
         const matches=[...before.matchAll(/在庫状況\\s*([○◯△×]\\s*在庫\\s*(?:あり|わずか|なし)|お取り寄せ)/g)];
         edionDeliveryStock=/配送受取/.test(before)&&matches.length===1&&
           /^[○◯△]/.test(matches[0][1])&& !/在庫\\s*なし/.test(matches[0][1]);
       }
     }
   }
   for(const c of adds.slice(0,30)){
     let root=c;
     for(let i=0;i<6&&root.parentElement&&root!==main;i++){
       const p=root.parentElement;
       if(txt(p).length>2500)break;
       if(p.querySelectorAll('h1').length>1)break;
       root=p;
     }
     const t=txt(root).slice(0,2500);
     if(negative.test(t))continue;
     if(merchant==='EDION'){
       // Either a local cart ancestor proves stock, or the ONE exact shipping
       // inventory row preceding this item's purchase operation does.
       if(!positive.test(t)&&!edionDeliveryStock)continue;
       r.variantBound=true;r.stockPairs++;
     }else if(merchant==='AU'){
       // Require a genuine product purchase button, not the shop's header
       // shopping-cart link. This is never inferred from the link alone.
       if(c.tagName!=='BUTTON'||!/CartButton_cartButton/.test(c.className||''))continue;
       if(!canonicalMatch&&!attrMatch&&!labelMatch)continue;
       if(selected){
         let matched=false;
         for(let n=c,i=0;n&&i<6;i++,n=n.parentElement){
           const values=[n.getAttribute('data-variant-id'),n.getAttribute('data-sku-id'),
               n.getAttribute('data-selected-id'),n.getAttribute('href')]
                .filter(Boolean).join(' ');
           if(values.includes(selected)){matched=true;break;}
         }
         if(!matched)continue;
       }
       r.variantBound=true;r.stockPairs++;
     }else{
       // ZOZO size/colour variants are NOT interchangeable. An exact ?did
       // requires a matching variant-specific node around the live action.
       if(did){
         // Match exact variant IDs only in this purchase button's own ancestors.
         const sameDid=e=>{
           for(const k of ['data-did','data-detail-id','data-goods-detail-id',
             'data-variant-id','data-stock-id','data-sku-id','data-selected-id']){
             if(e.getAttribute(k)===did)return true;
           }
           const href=e.getAttribute('href');
           if(href){try{const u=new URL(href,location.href);
             if(u.origin===location.origin&&u.searchParams.get('did')===did)return true;
           }catch(_){}}
           return false;
         };
         let bound=false;for(let n=c,i=0;n&&i<8&&main.contains(n);i++,n=n.parentElement){
           if(sameDid(n)){bound=true;break;}
         }
         if(!bound)continue;
       }
       // ZOZO must show local stock, not a floating global Add button.
       if(!positive.test(t))continue;
       r.variantBound=true;r.stockPairs++;
     }
   }
   if(merchant==='ZOZO'&&did&&r.stockPairs===0&&r.idBound){
     // ZOZO sometimes places ?did on a colour/stock option link, a sibling
     // of the live add button, not on the button itself. Look for a SMALL,
     // unique option subtree containing that exact DID, the local positive
     // stock row, and exactly one live purchase action. Neither page-wide
     // stock text nor the ?did URL alone establishes availability.
     const exactDid=e=>{
       for(const k of ['data-did','data-detail-id','data-goods-detail-id',
         'data-variant-id','data-stock-id','data-sku-id','data-selected-id']){
         if(e.getAttribute(k)===did)return true;
       }
       const href=e.getAttribute('href');
       if(href){try{const u=new URL(href,location.href);
         return u.origin===location.origin&&u.searchParams.get('did')===did;
       }catch(_){}}
       return false;
     };
     const options=[...main.querySelectorAll('[data-did],[data-detail-id],'+
       '[data-goods-detail-id],[data-variant-id],[data-stock-id],'+
       '[data-sku-id],[data-selected-id],a[href*=did]')]
       .filter(e=>!e.closest(bad)&&exactDid(e)).slice(0,40);
     r.didNodes=options.length;
     const optAll='[data-did],[data-detail-id],[data-goods-detail-id],'+
       '[data-variant-id],[data-stock-id],[data-sku-id],[data-selected-id],a[href*=did]';
     let matched=0;
     for(const option of options){
       for(let p=option,depth=0;p&&p!==main&&depth<5;p=p.parentElement,depth++){
         if(!live(p))continue;
         const t=txt(p);
         if(t.length>560||negative.test(t))break;
         if(!positive.test(t))continue;
         // An ancestor containing multiple different DID choices cannot
         // attribute a stock quantity to this selected option.
         const other=[...p.querySelectorAll(optAll)]
            .filter(x=>x!==option&&!x.closest(bad)&&!exactDid(x));
         if(other.length)break;
         const local=adds.filter(a=>p.contains(a));
         if(local.length!==1)continue;
         r.didLocalCarts++;
         r.didLocalStock++;
         matched++;
         break;
       }
     }
     if(matched===1){r.variantBound=true;r.stockPairs=1;}
   }
   if(merchant==='ZOZO'&&did&&r.idBound&&r.stockPairs===0&&adds.length){
     // ZOZO's dynamic product page can have no ?did/stock-id HTML
     // attributes at all. In that case use only SAME-goods, SAME-detail
     // structured stock records carried by this document's product state.
     // A price, header cart, unmatched colour or positive stock elsewhere
     // on the page is never sufficient. No click, fetch or state mutation.
     const sameId=(a,b)=>String(a||'')===String(b);
     const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
     const goodsKeys=['goodsId','goods_id','goodsID','productId','product_id'];
     const didKeys=['did','goodsDetailId','goods_detail_id','goodsDetailID',
       'detailId','detail_id','stockId','stock_id','skuId','sku_id','variantId','variant_id'];
     const qtyKeys=['stockQuantity','stock_quantity','availableQuantity',
       'available_quantity','stockCount','stock_count','inventoryCount',
       'inventory_count','remainingStock','remaining_stock'];
     const buyKeys=['isPurchasable','purchasable','canPurchase','canBuy',
       'isAvailable','available','inStock','isInStock','hasStock'];
     const negKeys=['soldOut','isSoldOut','outOfStock','isOutOfStock',
       'isDisabled','discontinued'];
     const positiveState=/^(?:IN_STOCK|INSTOCK|AVAILABLE|在庫あり|販売中)$/i;
     const negativeState=/^(?:OUT_OF_STOCK|SOLD_OUT|SOLDOUT|UNAVAILABLE|完売|在庫なし|在庫切れ)$/i;
     let examined=0,matches=0,proved=0,contradictions=0,owners=0,nestedProof=0,unproven=0;
     const keyHints=new Set();let recordsWithStockKey=0;
     const visited=new WeakSet();
     const inspect=(root)=>{
       const walk=(o,owner,depth,fromProduct)=>{
         if(!o||typeof o!=='object'||depth>13||examined>=3500||visited.has(o))return;
         visited.add(o);examined++;
         if(Array.isArray(o)){
           for(const x of o.slice(0,400))walk(x,owner,depth+1,fromProduct);
           return;
         }
         let goods=owner;
         for(const k of goodsKeys)if(own(o,k)&&o[k]!=null){
           // Explicitly different goods IDs must NOT inherit parent stock.
           goods=sameId(o[k],item)?item:'DIFFERENT';break;
         }
         if(goods==='DIFFERENT')return;
         const hit=didKeys.some(k=>own(o,k)&&sameId(o[k],did));
         if(hit){
           matches++;
           if(goods===item){
             owners++;
             // Only record short, stock-related FIELD NAMES, never IDs,
             // page contents, field values or personal data. No verdict change.
             const hints=Object.keys(o).slice(0,100).filter(k=>
               /^[A-Za-z][A-Za-z0-9_]{0,35}$/.test(k)&&
               /stock|inventory|avail|quantity|count|remain|purchase|purchas|sell|sale|sold|order|cart|status|detail/i.test(k));
             if(hints.length)recordsWithStockKey++;
             for(const k of hints.slice(0,15))if(keyHints.size<25)keyHints.add(k);
             let pos=false,neg=false;
             for(const k of qtyKeys)if(own(o,k)&&o[k]!=null){
               const n=Number(o[k]);if(Number.isFinite(n)){
                 if(n>0)pos=true;else neg=true;
               }
             }
             for(const k of buyKeys)if(own(o,k)){
               if(o[k]===true)pos=true;
               if(o[k]===false)neg=true;
             }
             for(const k of negKeys)if(own(o,k)&&o[k]===true)neg=true;
             for(const k of ['stockStatus','stock_status','availability','status'])if(own(o,k)){
               const value=String(o[k]||'');
               if(positiveState.test(value))pos=true;
               if(negativeState.test(value))neg=true;
             }
             // Only descend into a SINGLE stock object belonging to this
             // exact DID record. Never borrow a sibling colour/size's stock,
             // a product-wide availability flag or an unrelated array.
             if(!pos&&!neg){
               for(const key of ['stock','stockData','inventory','inventoryData',
                   'stockInfo','inventoryInfo','stockStatusDetail','availabilityInfo']){
                 const v=o[key];
                 if(!v||typeof v!=='object'||Array.isArray(v))continue;
                 if(goodsKeys.some(k=>own(v,k)&&!sameId(v[k],item))||
                   didKeys.some(k=>own(v,k)&&!sameId(v[k],did)))continue;
                 let localPos=false,localNeg=false;
                 for(const k of qtyKeys)if(own(v,k)&&v[k]!=null){
                   const n=Number(v[k]);
                   if(Number.isFinite(n)){if(n>0)localPos=true;else localNeg=true;}
                 }
                 for(const k of buyKeys)if(own(v,k)){
                   if(v[k]===true)localPos=true;
                   if(v[k]===false)localNeg=true;
                 }
                 for(const k of negKeys)if(v[k]===true)localNeg=true;
                 for(const k of ['stockStatus','stock_status','availability','status'])
                   if(own(v,k)){
                     const z=String(v[k]||'');
                     if(positiveState.test(z))localPos=true;
                     if(negativeState.test(z))localNeg=true;
                   }
                 if(localPos||localNeg){
                   if(localPos)nestedProof++;
                   pos=pos||localPos;neg=neg||localNeg;
                 }
               }
             }
             if(pos&&!neg)proved++;
             if(neg)contradictions++;
             if(!pos&&!neg)unproven++;
           }
         }
         // Traverse product/variant/stock records only; other nested app
         // state (account, cart, recommendations) is not inventory proof.
         const keys=Object.keys(o).slice(0,120);
         for(const k of keys){
           if(!/^(?:props|pageProps|initialState|dehydratedState|queries|query|result|state|data|item|goods|product|products|details|detail|sku|skus|stock|stocks|variant|variants|color|colors|size|sizes|inventory|inventories|options|list|items|entities|byId|nodes|edges|children|payload|records|productData|goodsData|stockData|detailData|goodsDetail|goodsDetails|productDetails|sizeStocks|colorStocks)$/i.test(k))continue;
           try{const child=o[k];if(child&&typeof child==='object')
             walk(child,goods,depth+1,fromProduct||/goods|product/i.test(k));
           }catch(_){}
         }
       };
       walk(root,null,0,false);
     };
     // JSON-only hydration scripts, not arbitrary HTML or executable JS.
     for(const script of [...document.querySelectorAll('script[type="application/json"],'+
         'script#__NEXT_DATA__,script#__NUXT_DATA__,script[data-product-state]')].slice(0,15)){
       try{const raw=script.textContent||'';
         if(raw.length<10||raw.length>2500000||!raw.includes(did))continue;
         inspect(JSON.parse(raw));
       }catch(_){}
     }
     // Read-only React props of the *current product action/size widgets*.
     // React often owns the exact goodsDetailId and stock quantity but leaves
     // no data-did/data-stock-id on the rendered HTML nodes.
     const controls=adds.slice(0,8);
     for(const button of controls){
       for(let n=button,d=0;n&&d<5&&main.contains(n);n=n.parentElement,d++){
         try{
           const keys=Object.keys(n).filter(k=>k.startsWith('__reactProps$')||
             k.startsWith('__reactFiber$')||k.startsWith('__reactContainer$')).slice(0,3);
           for(const k of keys){
             const v=n[k];if(!v||typeof v!=='object')continue;
             const candidates=[v,v.memoizedProps,v.pendingProps,v.props,
                 v.memoizedState,v.stateNode&&v.stateNode.props].filter(Boolean);
             for(const state of candidates)inspect(state);
             // A nearby fibre can hold the product option props on its parent.
             if(v.return&&v.return.memoizedProps)inspect(v.return.memoizedProps);
           }
         }catch(_){}
       }
     }
     r.didStateRecords=matches;r.didStateStock=proved;
     r.didStateContradictions=contradictions;r.didStateExamined=examined;
     r.didStateOwnerMatched=owners;r.didStateNestedStock=nestedProof;
     r.didStateUnproven=unproven;
     r.didStateRecordWithStockKey=recordsWithStockKey;
     r.didStateKeyHints=[...keyHints].sort().slice(0,12).join(',').slice(0,190)||'none';
     // Both exact IDs must have been asserted in the SAME state branch.
     // Uninformative duplicate references do not cancel explicit stock proof;
     // any conflicting zero-stock match blocks this fallback entirely.
     if(matches>0&&owners>0&&proved>0&&contradictions===0){
       r.variantBound=true;r.stockPairs=1;r.reason='zozo-structured-did-stock';
     }
   }
   if(r.stockPairs>0&&r.idBound&&r.variantBound){
     r.status='AVAILABLE';
     if(r.reason!=='zozo-structured-did-stock')
       r.reason=merchant==='ZOZO'&&did?'zozo-exact-did-local-cart':'merchant-item-cart-verified';
   }else r.reason=merchant==='ZOZO'&&did?'zozo-did-not-bound':'no-local-stock-proof';
   return done();
 }catch(_){r.reason='dom-error';return done();}
})()
""";
}
