package com.cmyk.bookmarkslauncher.ui;

import android.content.ClipData;
import android.content.Context;
import android.graphics.Rect;
import android.view.DragEvent;
import android.view.View;
import android.view.ViewGroup;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import java.util.ArrayList;
import java.util.List;

public final class BookmarkBoardView extends ViewGroup {
    public interface Listener {
        void onOpen(BookmarkNode node, View anchor);
        void onLongPress(BookmarkNode node, View anchor);
        void onOrderChanged(List<String> orderedIds);
    }

    private final int columns;
    private final int gapPx;
    private final List<BookmarkNode> nodes = new ArrayList<>();
    private Listener listener;
    private int cellSize;
    private BookmarkTileView dragging;
    private boolean dragMoved;

    public BookmarkBoardView(Context context, int columns) {
        super(context);
        this.columns = columns;
        this.gapPx = dp(6);
        setClipChildren(false);
        setOnDragListener(this::handleDrag);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<BookmarkNode> items) {
        nodes.clear();
        nodes.addAll(items);
        rebuild();
    }

    private void rebuild() {
        removeAllViews();
        for (BookmarkNode node : nodes) {
            BookmarkTileView tile = new BookmarkTileView(getContext(), node);
            tile.setOnClickListener(v -> { if (listener != null) listener.onOpen(node, v); });
            tile.setOnLongClickListener(v -> {
                dragging = tile;
                dragMoved = false;
                ClipData data = ClipData.newPlainText("bookmark-id", node.id);
                v.startDragAndDrop(data, new DragShadowBuilder(v), v, 0);
                return true;
            });
            addView(tile);
        }
        requestLayout();
    }

    private boolean handleDrag(View v, DragEvent e) {
        if (dragging == null) return true;
        if (e.getAction() == DragEvent.ACTION_DRAG_LOCATION) {
            int target = indexAt(e.getX(), e.getY());
            int from = indexOfChild(dragging);
            if (target >= 0 && from >= 0 && target != from && target < nodes.size()) {
                BookmarkNode moved = nodes.remove(from);
                if (target > from) target--;
                nodes.add(Math.max(0, Math.min(target, nodes.size())), moved);
                dragMoved = true;
                rebuild();
                dragging = (BookmarkTileView) getChildAt(nodes.indexOf(moved));
            }
        } else if (e.getAction() == DragEvent.ACTION_DRAG_ENDED) {
            BookmarkTileView finished = dragging;
            if (listener != null) {
                if (dragMoved) {
                    List<String> ids = new ArrayList<>();
                    for (BookmarkNode n : nodes) ids.add(n.id);
                    listener.onOrderChanged(ids);
                } else if (finished != null) {
                    listener.onLongPress(finished.getNode(), finished);
                }
            }
            dragging = null;
            dragMoved = false;
        }
        return true;
    }

    private int indexAt(float x, float y) {
        Rect r = new Rect();
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            child.getHitRect(r);
            if (r.contains((int)x, (int)y)) return i;
        }
        return getChildCount() - 1;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        cellSize = Math.max(1, (width - gapPx * (columns + 1)) / columns);

        int[] heights = new int[columns];
        for (int i = 0; i < getChildCount(); i++) {
            BookmarkTileView child = (BookmarkTileView) getChildAt(i);
            BookmarkNode n = child.getNode();
            int w = cellSize * Math.min(columns, n.spanX) + gapPx * (Math.min(columns, n.spanX) - 1);
            int h = cellSize * Math.max(1, n.spanY) + gapPx * (Math.max(1, n.spanY) - 1);
            child.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
            int col = shortestRun(heights, Math.min(columns, n.spanX));
            int base = 0;
            for (int c = col; c < col + Math.min(columns, n.spanX); c++) base = Math.max(base, heights[c]);
            int next = base + h + gapPx;
            for (int c = col; c < col + Math.min(columns, n.spanX); c++) heights[c] = next;
        }
        int max = 0;
        for (int h : heights) max = Math.max(max, h);
        setMeasuredDimension(width, Math.max(dp(120), max + gapPx));
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int[] heights = new int[columns];
        for (int i = 0; i < getChildCount(); i++) {
            BookmarkTileView child = (BookmarkTileView) getChildAt(i);
            BookmarkNode n = child.getNode();
            int span = Math.min(columns, n.spanX);
            int col = shortestRun(heights, span);
            int top = 0;
            for (int c = col; c < col + span; c++) top = Math.max(top, heights[c]);
            int left = gapPx + col * (cellSize + gapPx);
            int childTop = gapPx + top;
            child.layout(left, childTop, left + child.getMeasuredWidth(), childTop + child.getMeasuredHeight());
            int next = top + child.getMeasuredHeight() + gapPx;
            for (int c = col; c < col + span; c++) heights[c] = next;
        }
    }

    private int shortestRun(int[] heights, int span) {
        int bestCol = 0;
        int bestHeight = Integer.MAX_VALUE;
        for (int c = 0; c <= columns - span; c++) {
            int h = 0;
            for (int x = c; x < c + span; x++) h = Math.max(h, heights[x]);
            if (h < bestHeight) {
                bestHeight = h;
                bestCol = c;
            }
        }
        return bestCol;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
