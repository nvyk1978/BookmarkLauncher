package com.cmyk.bookmarkslauncher.ui;

import android.content.ClipData;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class BookmarkBoardView extends ViewGroup {
    public interface Listener {
        void onOpen(BookmarkNode node, View anchor);
        void onLongPress(BookmarkNode node, View anchor);
        void onPositionsChanged(List<BookmarkNode> nodes);
        void onExternalDrop(BookmarkNode dragged, int cellX, int cellY, List<BookmarkNode> residentNodes);
        void onCreateFolder(BookmarkNode dragged, BookmarkNode target);
        void onMoveIntoFolder(BookmarkNode dragged, BookmarkNode folder, View folderAnchor);
        void onHoverOpenFolder(BookmarkNode dragged, BookmarkNode folder, View folderAnchor);
        void onDragExited(BookmarkNode dragged);
        void onDragStateChanged(boolean active, BookmarkNode node);
        void onEmptyLongPress(int cellX, int cellY);
        void onSearchWidgetMoved(int cellY);
        void onSearchQuery(String query);
        List<BookmarkNode> onFolderPreview(BookmarkNode folder);
    }

    // Keep the reorder dwell aligned with current AOSP Launcher3 behavior.
    private static final long REORDER_DELAY_MS = 650L;
    private static final long FOLDER_OPEN_DELAY_MS = 650L;
    private static final long REORDER_ANIMATION_MS = 180L;
    private static final float SEARCH_HEIGHT_FRACTION = 0.50f;
    private static final int SEARCH_HORIZONTAL_INSET_DP = 12;

    private static final int N_GREEN = 0xFF227733;
    private static final int N_ORANGE = 0xFF775500;

    private final int columns;
    private final int rows;
    private final int gapPx;
    private final List<BookmarkNode> nodes = new ArrayList<>();
    private final Map<String, int[]> originalPositions = new HashMap<>();
    private Map<String, float[]> pendingReorderAnimationFrom;
    private final Paint targetPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private Listener listener;
    private String containerId;
    private int cellWidth;
    private int cellHeight;

    private BookmarkTileView dragging;
    private SearchWidgetView draggingSearch;
    private BookmarkTileView folderTarget;
    private BookmarkTileView scheduledFolderTarget;
    private SearchWidgetView searchView;
    private boolean searchEnabled;
    private int searchCellY;
    private int pendingSearchY = -1;
    private int originalSearchY = -1;
    private float blankDownX;
    private float blankDownY;
    private boolean blankDown;
    private int pendingCellX = -1;
    private int pendingCellY = -1;
    private int scheduledCellX = -1;
    private int scheduledCellY = -1;
    private boolean reorderPreview;
    private boolean dropHandled;
    private boolean everMoved;
    private boolean sourceOwnsDrag;
    private boolean exitNotified;
    private boolean hasDragLocation;
    private float dragStartX;
    private float dragStartY;
    private float lastTouchX;
    private float lastTouchY;
    private String activeDragItemId;

    private final Runnable reorderRunnable = () -> {
        if (dragging == null || folderTarget != null) return;
        if (pendingCellX != scheduledCellX || pendingCellY != scheduledCellY) return;
        previewReorderAt(pendingCellX, pendingCellY);
    };

    private final Runnable folderOpenRunnable = () -> {
        if (dragging == null || folderTarget == null || folderTarget != scheduledFolderTarget) return;
        BookmarkNode target = folderTarget.getNode();
        if (!target.isFolder() || listener == null) return;
        listener.onHoverOpenFolder(dragging.getNode(), target, folderTarget);
    };

    public BookmarkBoardView(Context context, int columns, int rows) {
        super(context);
        this.columns = Math.max(1, columns);
        this.rows = Math.max(1, rows);
        this.gapPx = dp(6);
        setWillNotDraw(false);
        setClipChildren(false);
        setClipToPadding(false);
        setOnDragListener(this::handleDrag);
        setLongClickable(true);
        setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                blankDownX = event.getX();
                blankDownY = event.getY();
                blankDown = tileUnder(blankDownX, blankDownY) == null && !pointInsideSearch(blankDownX, blankDownY);
            } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                float dx = event.getX() - blankDownX;
                float dy = event.getY() - blankDownY;
                if (dx * dx + dy * dy > dp(10) * dp(10)) blankDown = false;
            }
            return false;
        });
        setOnLongClickListener(v -> {
            if (!blankDown || listener == null) return false;
            int[] cell = cellForPoint(blankDownX, blankDownY, 1, 1);
            listener.onEmptyLongPress(cell[0], cell[1]);
            blankDown = false;
            return true;
        });
    }

    public int getColumns() { return columns; }
    public int getRows() { return rows; }
    public int getCellWidthPx() { return cellWidth; }
    public int getCellHeightPx() { return cellHeight; }
    public int getGapPx() { return gapPx; }
    public SearchWidgetView getSearchView() { return searchView; }

    public void setActiveDragItemId(String itemId) {
        String previous = activeDragItemId;
        activeDragItemId = itemId;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (!(child instanceof BookmarkTileView)) continue;
            BookmarkTileView tile = (BookmarkTileView) child;
            boolean active = itemId != null && itemId.equals(tile.getNode().id);
            boolean wasActive = previous != null && previous.equals(tile.getNode().id);
            if (active) {
                tile.setAlpha(0.18f);
                tile.setScaleX(1.04f);
                tile.setScaleY(1.04f);
            } else if (itemId == null || wasActive) {
                tile.setAlpha(1f);
                tile.setScaleX(1f);
                tile.setScaleY(1f);
            }
        }
    }

    public void setSearchImeTranslation(float translationY) {
        if (searchView == null) return;
        searchView.animate().cancel();
        searchView.setTranslationY(translationY);
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setSearchWidget(boolean enabled, int cellY) {
        searchEnabled = enabled;
        searchCellY = Math.max(0, Math.min(rows - 1, cellY));
        rebuild();
    }

    public boolean isSearchEnabled() { return searchEnabled; }
    public int getSearchCellY() { return searchCellY; }

    public void submit(List<BookmarkNode> items) {
        cancelReorderTimer();
        clearFolderTarget();
        nodes.clear();
        nodes.addAll(items);
        pendingReorderAnimationFrom = null;
        rebuild();
    }

    private void rebuild() {
        removeAllViews();
        searchView = null;
        if (searchEnabled) {
            searchView = new SearchWidgetView(getContext(), searchCellY);
            searchView.setListener(new SearchWidgetView.Listener() {
                @Override public void onSearch(String query) {
                    if (listener != null) listener.onSearchQuery(query);
                }

                @Override public boolean onLongPress(SearchWidgetView view) {
                    return beginSearchDrag(view);
                }
            });
            addView(searchView);
        }
        for (BookmarkNode node : nodes) {
            List<BookmarkNode> preview = node.isFolder() && listener != null
                    ? listener.onFolderPreview(node)
                    : java.util.Collections.emptyList();
            BookmarkTileView tile = new BookmarkTileView(getContext(), node, preview);
            tile.setElevation(0f);
            if (activeDragItemId != null && activeDragItemId.equals(node.id)) {
                tile.setAlpha(0.18f);
                tile.setScaleX(1.04f);
                tile.setScaleY(1.04f);
            }
            tile.setOnClickListener(v -> {
                if (listener != null) listener.onOpen(node, v);
            });
            tile.setOnTouchListener((v, event) -> {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN || event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    lastTouchX = v.getLeft() + event.getX();
                    lastTouchY = v.getTop() + event.getY();
                }
                return false;
            });
            tile.setOnLongClickListener(v -> beginDrag((BookmarkTileView) v));
            addView(tile);
        }
        requestLayout();
    }

    private boolean beginDrag(BookmarkTileView tile) {
        dragging = tile;
        activeDragItemId = tile.getNode().id;
        sourceOwnsDrag = true;
        pendingCellX = tile.getNode().cellX;
        pendingCellY = tile.getNode().cellY;
        scheduledCellX = -1;
        scheduledCellY = -1;
        reorderPreview = false;
        dropHandled = false;
        everMoved = false;
        exitNotified = false;
        hasDragLocation = false;
        dragStartX = lastTouchX;
        dragStartY = lastTouchY;
        snapshotPositions();
        clearFolderTarget();

        if (listener != null) listener.onDragStateChanged(true, tile.getNode());

        ClipData data = ClipData.newPlainText("bookmark-id", tile.getNode().id);
        boolean started = tile.startDragAndDrop(data, new FlatDragShadowBuilder(tile), tile, 0);
        if (started) {
            tile.setAlpha(0.18f);
            tile.setScaleX(1.04f);
            tile.setScaleY(1.04f);
        } else {
            if (listener != null) listener.onDragStateChanged(false, tile.getNode());
            resetDraggedAppearance();
            dragging = null;
        }
        return started;
    }

    private boolean beginSearchDrag(SearchWidgetView view) {
        draggingSearch = view;
        dragging = null;
        originalSearchY = searchCellY;
        pendingSearchY = searchCellY;
        dropHandled = false;
        everMoved = false;
        if (listener != null) listener.onDragStateChanged(true, null);
        ClipData data = ClipData.newPlainText("search-widget", "search");
        boolean started = view.startDragAndDrop(data, new FlatDragShadowBuilder(view), view, 0);
        if (started) {
            view.setAlpha(0.22f);
            view.setScaleX(1.02f);
            view.setScaleY(1.02f);
        } else {
            view.setAlpha(1f);
            view.setScaleX(1f);
            view.setScaleY(1f);
            draggingSearch = null;
            if (listener != null) listener.onDragStateChanged(false, null);
        }
        return started;
    }

    private boolean handleDrag(View v, DragEvent e) {
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                if (e.getLocalState() instanceof SearchWidgetView) {
                    draggingSearch = (SearchWidgetView) e.getLocalState();
                    dragging = null;
                    originalSearchY = searchCellY;
                    pendingSearchY = searchCellY;
                    dropHandled = false;
                    everMoved = false;
                    return searchEnabled && searchView == draggingSearch;
                }
                if (!(e.getLocalState() instanceof BookmarkTileView)) return false;
                dragging = (BookmarkTileView) e.getLocalState();
                activeDragItemId = dragging.getNode().id;
                draggingSearch = null;
                sourceOwnsDrag = containsNode(dragging.getNode().id);
                snapshotPositions();
                dropHandled = false;
                reorderPreview = false;
                exitNotified = false;
                hasDragLocation = false;
                if (!sourceOwnsDrag) everMoved = true;
                clearFolderTarget();
                return true;

            case DragEvent.ACTION_DRAG_LOCATION:
                if (draggingSearch != null) {
                    int[] cell = cellForPoint(e.getX(), e.getY(), columns, 1);
                    pendingSearchY = cell[1];
                    if (pendingSearchY != originalSearchY) everMoved = true;
                    invalidate();
                    return true;
                }
                if (dragging == null) return true;
                hasDragLocation = true;
                if (sourceOwnsDrag) {
                    float dx = e.getX() - dragStartX;
                    float dy = e.getY() - dragStartY;
                    if (dx * dx + dy * dy > dp(12) * dp(12)) everMoved = true;
                } else {
                    everMoved = true;
                }
                updateDragTarget(e.getX(), e.getY());
                return true;

            case DragEvent.ACTION_DRAG_EXITED:
                if (draggingSearch != null) return true;
                cancelReorderTimer();
                clearFolderTarget();
                pendingCellX = -1;
                pendingCellY = -1;
                invalidate();
                if (hasDragLocation && everMoved && !exitNotified && listener != null) {
                    exitNotified = true;
                    listener.onDragExited(dragging.getNode());
                }
                return true;

            case DragEvent.ACTION_DROP:
                if (draggingSearch != null) {
                    dropHandled = true;
                    searchCellY = Math.max(0, Math.min(rows - 1, pendingSearchY));
                    if (searchView != null) searchView.setCellY(searchCellY);
                    requestLayout();
                    if (listener != null) listener.onSearchWidgetMoved(searchCellY);
                    return true;
                }
                if (dragging == null) return true;
                dropHandled = true;
                performDrop();
                return true;

            case DragEvent.ACTION_DRAG_ENDED:
                if (draggingSearch != null) {
                    if (!dropHandled || !e.getResult()) {
                        searchCellY = originalSearchY;
                        if (searchView != null) searchView.setCellY(searchCellY);
                    }
                    draggingSearch.setAlpha(1f);
                    draggingSearch.setScaleX(1f);
                    draggingSearch.setScaleY(1f);
                    draggingSearch = null;
                    pendingSearchY = -1;
                    originalSearchY = -1;
                    dropHandled = false;
                    everMoved = false;
                    requestLayout();
                    invalidate();
                    if (listener != null) listener.onDragStateChanged(false, null);
                    return true;
                }
                if (!dropHandled || !e.getResult()) restoreOriginalPositions();
                BookmarkNode endedNode = dragging == null ? null : dragging.getNode();
                boolean notifyEnd = sourceOwnsDrag;
                cancelReorderTimer();
                clearFolderTarget();
                resetDraggedAppearance();
                setActiveDragItemId(null);
                dragging = null;
                pendingCellX = -1;
                pendingCellY = -1;
                scheduledCellX = -1;
                scheduledCellY = -1;
                reorderPreview = false;
                dropHandled = false;
                everMoved = false;
                sourceOwnsDrag = false;
                exitNotified = false;
                hasDragLocation = false;
                originalPositions.clear();
                invalidate();
                if (notifyEnd && endedNode != null && listener != null) {
                    listener.onDragStateChanged(false, endedNode);
                }
                return true;

            default:
                return true;
        }
    }

    private void updateDragTarget(float x, float y) {
        BookmarkTileView target = tileUnder(x, y);
        if (target != null && target != dragging && inFolderZone(target, x, y)) {
            cancelReorderTimer();
            if (reorderPreview) restoreOriginalPositions();
            pendingCellX = -1;
            pendingCellY = -1;
            setFolderTarget(target);
            invalidate();
            return;
        }

        clearFolderTarget();
        int[] cell = cellForPoint(x, y, dragging.getNode().spanX, dragging.getNode().spanY);
        int newX = cell[0];
        int newY = cell[1];
        boolean changed = newX != pendingCellX || newY != pendingCellY;
        pendingCellX = newX;
        pendingCellY = newY;

        if (changed && reorderPreview) restoreOriginalPositions();

        if (areaFree(newX, newY, dragging.getNode().spanX, dragging.getNode().spanY, dragging.getNode().id)) {
            cancelReorderTimer();
        } else if (changed || scheduledCellX != newX || scheduledCellY != newY) {
            scheduleReorder(newX, newY);
        }
        invalidate();
    }

    private void performDrop() {
        BookmarkNode draggedNode = dragging.getNode();

        if (folderTarget != null && folderTarget != dragging && listener != null) {
            BookmarkNode target = folderTarget.getNode();
            restoreOriginalPositions();
            everMoved = true;
            if (target.isFolder()) listener.onMoveIntoFolder(draggedNode, target, folderTarget);
            else listener.onCreateFolder(draggedNode, target);
            return;
        }

        if (sourceOwnsDrag && !everMoved) {
            restoreOriginalPositions();
            if (listener != null) listener.onLongPress(draggedNode, dragging);
            return;
        }

        if (pendingCellX < 0 || pendingCellY < 0) {
            restoreOriginalPositions();
            return;
        }

        if (!areaFree(pendingCellX, pendingCellY, draggedNode.spanX, draggedNode.spanY, draggedNode.id)) {
            previewReorderAt(pendingCellX, pendingCellY);
        }

        if (!areaFree(pendingCellX, pendingCellY, draggedNode.spanX, draggedNode.spanY, draggedNode.id)) {
            restoreOriginalPositions();
            return;
        }

        draggedNode.cellX = pendingCellX;
        draggedNode.cellY = pendingCellY;
        reorderPreview = false;
        requestLayout();

        if (listener != null) {
            if (sourceOwnsDrag && Objects.equals(draggedNode.parentId, containerId)) {
                listener.onPositionsChanged(new ArrayList<>(nodes));
            } else {
                listener.onExternalDrop(draggedNode, pendingCellX, pendingCellY, new ArrayList<>(nodes));
            }
        }
    }

    private void scheduleReorder(int cellX, int cellY) {
        cancelReorderTimer();
        scheduledCellX = cellX;
        scheduledCellY = cellY;
        postDelayed(reorderRunnable, REORDER_DELAY_MS);
    }

    private void cancelReorderTimer() {
        removeCallbacks(reorderRunnable);
        scheduledCellX = -1;
        scheduledCellY = -1;
    }

    private void previewReorderAt(int cellX, int cellY) {
        if (dragging == null || cellX < 0 || cellY < 0) return;
        // Capture the currently visible positions before changing cell coordinates. The next
        // layout pass places views at their new cells, then onLayout animates them from these
        // captured screen positions. This keeps the dragged icon under the finger while nearby
        // icons slide out of the way instead of teleporting.
        Map<String, float[]> before = captureTileVisualPositions();
        restoreOriginalPositionValues();

        BookmarkNode draggedNode = dragging.getNode();
        List<BookmarkNode> conflicts = conflictsAt(cellX, cellY, draggedNode.spanX, draggedNode.spanY, draggedNode.id);
        if (conflicts.isEmpty()) return;

        boolean[][] occupied = occupancyExcluding(draggedNode.id, conflicts);
        mark(occupied, cellX, cellY, draggedNode.spanX, draggedNode.spanY, true);

        for (BookmarkNode conflict : conflicts) {
            int[] original = originalPositions.get(conflict.id);
            int originX = original == null ? conflict.cellX : original[0];
            int originY = original == null ? conflict.cellY : original[1];
            int[] free = nearestFree(occupied, originX, originY, conflict.spanX, conflict.spanY);
            if (free == null) {
                restoreOriginalPositions();
                return;
            }
            conflict.cellX = free[0];
            conflict.cellY = free[1];
            mark(occupied, free[0], free[1], conflict.spanX, conflict.spanY, true);
        }

        reorderPreview = true;
        pendingReorderAnimationFrom = before;
        requestLayout();
        invalidate();
    }

    private List<BookmarkNode> conflictsAt(int x, int y, int spanX, int spanY, String excludeId) {
        List<BookmarkNode> out = new ArrayList<>();
        for (BookmarkNode n : nodes) {
            if (n.id.equals(excludeId)) continue;
            if (rectsOverlap(x, y, spanX, spanY, n.cellX, n.cellY, n.spanX, n.spanY)) out.add(n);
        }
        return out;
    }

    private boolean[][] occupancyExcluding(String draggedId, List<BookmarkNode> additionallyExcluded) {
        boolean[][] occupied = new boolean[rows][columns];
        if (searchEnabled && searchCellY >= 0 && searchCellY < rows) {
            for (int x = 0; x < columns; x++) occupied[searchCellY][x] = true;
        }
        for (BookmarkNode n : nodes) {
            if (n.id.equals(draggedId) || additionallyExcluded.contains(n)) continue;
            mark(occupied, n.cellX, n.cellY, n.spanX, n.spanY, true);
        }
        return occupied;
    }

    private int[] nearestFree(boolean[][] occupied, int originX, int originY, int spanX, int spanY) {
        int[] best = null;
        int bestScore = Integer.MAX_VALUE;
        for (int y = 0; y <= rows - spanY; y++) {
            for (int x = 0; x <= columns - spanX; x++) {
                if (!fits(occupied, x, y, spanX, spanY)) continue;
                int distance = Math.abs(x - originX) + Math.abs(y - originY);
                int score = distance * 100 + y * columns + x;
                if (score < bestScore) {
                    bestScore = score;
                    best = new int[]{x, y};
                }
            }
        }
        return best;
    }

    private boolean areaFree(int x, int y, int spanX, int spanY, String excludeId) {
        if (x < 0 || y < 0 || x + spanX > columns || y + spanY > rows) return false;
        if (searchEnabled && y <= searchCellY && y + spanY > searchCellY) return false;
        for (BookmarkNode n : nodes) {
            if (n.id.equals(excludeId)) continue;
            if (rectsOverlap(x, y, spanX, spanY, n.cellX, n.cellY, n.spanX, n.spanY)) return false;
        }
        return true;
    }

    private boolean containsNode(String id) {
        for (BookmarkNode n : nodes) if (n.id.equals(id)) return true;
        return false;
    }

    private static boolean rectsOverlap(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh) {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
    }

    private BookmarkTileView tileUnder(float x, float y) {
        for (int i = getChildCount() - 1; i >= 0; i--) {
            View child = getChildAt(i);
            if (child == dragging || !(child instanceof BookmarkTileView)) continue;
            if (x >= child.getLeft() && x <= child.getRight() && y >= child.getTop() && y <= child.getBottom()) {
                return (BookmarkTileView) child;
            }
        }
        return null;
    }

    private boolean inFolderZone(BookmarkTileView target, float x, float y) {
        // The visible icon sits above the text label, so using the whole tile center made the
        // folder target too low and too small. Delegate to the tile's visual-icon hit test.
        return target.isFolderDropHit(x - target.getLeft(), y - target.getTop());
    }

    /** Find a folder target using screen coordinates. Used by the root drag coordinator so
     * panels opened after ACTION_DRAG_STARTED can still participate in the same drag session. */
    public BookmarkTileView findFolderTargetAtScreen(float screenX, float screenY, BookmarkTileView exclude) {
        for (int i = getChildCount() - 1; i >= 0; i--) {
            View child = getChildAt(i);
            if (!(child instanceof BookmarkTileView) || child == exclude) continue;
            BookmarkTileView tile = (BookmarkTileView) child;
            if (exclude != null && tile.getNode().id.equals(exclude.getNode().id)) continue;
            if (!tile.getNode().isFolder()) continue;
            int[] loc = new int[2];
            tile.getLocationOnScreen(loc);
            float localX = screenX - loc[0];
            float localY = screenY - loc[1];
            if (localX >= 0 && localY >= 0 && localX <= tile.getWidth() && localY <= tile.getHeight()
                    && tile.isFolderDropHit(localX, localY)) return tile;
        }
        return null;
    }

    /** Fallback drop path for a board that was created while a system drag was already active. */
    public boolean coordinatorDrop(BookmarkTileView source, float screenX, float screenY) {
        if (source == null || listener == null) return false;
        int[] boardLoc = new int[2];
        getLocationOnScreen(boardLoc);
        float x = screenX - boardLoc[0];
        float y = screenY - boardLoc[1];
        if (x < 0 || y < 0 || x > getWidth() || y > getHeight()) return false;

        BookmarkTileView target = tileUnder(x, y);
        if (target != null && target != source && inFolderZone(target, x, y)) {
            BookmarkNode draggedNode = source.getNode();
            if (target.getNode().isFolder()) listener.onMoveIntoFolder(draggedNode, target.getNode(), target);
            else listener.onCreateFolder(draggedNode, target.getNode());
            return true;
        }

        BookmarkNode draggedNode = source.getNode();
        int[] cell = cellForPoint(x, y, draggedNode.spanX, draggedNode.spanY);
        snapshotPositions();
        BookmarkTileView previousDragging = dragging;
        boolean previousSourceOwns = sourceOwnsDrag;
        dragging = source;
        sourceOwnsDrag = containsNode(draggedNode.id);
        pendingCellX = cell[0];
        pendingCellY = cell[1];
        if (!areaFree(cell[0], cell[1], draggedNode.spanX, draggedNode.spanY, draggedNode.id)) {
            previewReorderAt(cell[0], cell[1]);
        }
        boolean free = areaFree(cell[0], cell[1], draggedNode.spanX, draggedNode.spanY, draggedNode.id);
        if (!free) {
            restoreOriginalPositions();
            dragging = previousDragging;
            sourceOwnsDrag = previousSourceOwns;
            return false;
        }

        draggedNode.cellX = cell[0];
        draggedNode.cellY = cell[1];
        reorderPreview = false;
        if (sourceOwnsDrag && Objects.equals(draggedNode.parentId, containerId)) {
            listener.onPositionsChanged(new ArrayList<>(nodes));
        } else {
            listener.onExternalDrop(draggedNode, cell[0], cell[1], new ArrayList<>(nodes));
        }
        dragging = previousDragging;
        sourceOwnsDrag = previousSourceOwns;
        return true;
    }

    private boolean pointInsideSearch(float x, float y) {
        return searchView != null && x >= searchView.getLeft() && x <= searchView.getRight()
                && y >= searchView.getTop() && y <= searchView.getBottom();
    }

    private int[] cellForPoint(float x, float y, int spanX, int spanY) {
        int sx = Math.max(1, Math.min(columns, spanX));
        int sy = Math.max(1, Math.min(rows, spanY));
        float strideX = cellWidth + gapPx;
        float strideY = cellHeight + gapPx;
        float itemW = cellWidth * sx + gapPx * (sx - 1);
        float itemH = cellHeight * sy + gapPx * (sy - 1);
        float firstLeft = getPaddingLeft() + gapPx;
        float firstTop = getPaddingTop() + gapPx;
        int cellX = Math.round((x - firstLeft - itemW / 2f) / strideX);
        int cellY = Math.round((y - firstTop - itemH / 2f) / strideY);
        cellX = Math.max(0, Math.min(columns - sx, cellX));
        cellY = Math.max(0, Math.min(rows - sy, cellY));
        return new int[]{cellX, cellY};
    }

    private void setFolderTarget(BookmarkTileView target) {
        if (folderTarget == target) return;
        clearFolderTarget();
        folderTarget = target;
        folderTarget.setDropHighlight(true);
        folderTarget.setScaleX(1.06f);
        folderTarget.setScaleY(1.06f);
        if (target.getNode().isFolder()) {
            scheduledFolderTarget = target;
            postDelayed(folderOpenRunnable, FOLDER_OPEN_DELAY_MS);
        }
    }

    private void clearFolderTarget() {
        removeCallbacks(folderOpenRunnable);
        scheduledFolderTarget = null;
        if (folderTarget != null) {
            folderTarget.setDropHighlight(false);
            folderTarget.setScaleX(1f);
            folderTarget.setScaleY(1f);
        }
        folderTarget = null;
    }

    private void snapshotPositions() {
        originalPositions.clear();
        for (BookmarkNode n : nodes) originalPositions.put(n.id, new int[]{n.cellX, n.cellY});
    }

    private void restoreOriginalPositionValues() {
        if (originalPositions.isEmpty()) return;
        for (BookmarkNode n : nodes) {
            int[] p = originalPositions.get(n.id);
            if (p != null) {
                n.cellX = p[0];
                n.cellY = p[1];
            }
        }
    }

    private Map<String, float[]> captureTileVisualPositions() {
        Map<String, float[]> out = new HashMap<>();
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (!(child instanceof BookmarkTileView)) continue;
            BookmarkTileView tile = (BookmarkTileView) child;
            out.put(tile.getNode().id, new float[]{
                    child.getLeft() + child.getTranslationX(),
                    child.getTop() + child.getTranslationY()
            });
        }
        return out;
    }

    private void restoreOriginalPositions() {
        if (originalPositions.isEmpty()) return;
        Map<String, float[]> before = captureTileVisualPositions();
        restoreOriginalPositionValues();
        reorderPreview = false;
        pendingReorderAnimationFrom = before;
        requestLayout();
        invalidate();
    }

    private void resetDraggedAppearance() {
        if (dragging != null) {
            dragging.setAlpha(1f);
            dragging.setScaleX(1f);
            dragging.setScaleY(1f);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (draggingSearch != null && pendingSearchY >= 0) {
            float left = getPaddingLeft() + gapPx + dp(SEARCH_HORIZONTAL_INSET_DP);
            float rowTop = getPaddingTop() + gapPx + pendingSearchY * (cellHeight + gapPx);
            float searchH = searchVisualHeight();
            float top = rowTop + (cellHeight - searchH) / 2f;
            float right = getWidth() - getPaddingRight() - gapPx - dp(SEARCH_HORIZONTAL_INSET_DP);
            float bottom = top + searchH;
            targetPaint.setStyle(Paint.Style.STROKE);
            targetPaint.setStrokeWidth(dp(2));
            targetPaint.setColor(N_GREEN);
            canvas.drawRoundRect(new RectF(left + dp(2), top + dp(2), right - dp(2), bottom - dp(2)), dp(18), dp(18), targetPaint);
            return;
        }
        if (dragging == null || pendingCellX < 0 || pendingCellY < 0 || folderTarget != null) return;
        int sx = Math.max(1, dragging.getNode().spanX);
        int sy = Math.max(1, dragging.getNode().spanY);
        float left = getPaddingLeft() + gapPx + pendingCellX * (cellWidth + gapPx);
        float top = getPaddingTop() + gapPx + pendingCellY * (cellHeight + gapPx);
        float right = left + cellWidth * sx + gapPx * (sx - 1);
        float bottom = top + cellHeight * sy + gapPx * (sy - 1);
        boolean free = areaFree(pendingCellX, pendingCellY, sx, sy, dragging.getNode().id);
        targetPaint.setStyle(Paint.Style.STROKE);
        targetPaint.setStrokeWidth(dp(2));
        targetPaint.setColor(free ? N_GREEN : N_ORANGE);
        canvas.drawRoundRect(new RectF(left + dp(2), top + dp(2), right - dp(2), bottom - dp(2)), dp(12), dp(12), targetPaint);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int widthAvailable = Math.max(1, width - getPaddingLeft() - getPaddingRight());
        cellWidth = Math.max(1, (widthAvailable - gapPx * (columns + 1)) / columns);

        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        int desiredHeight;
        if (heightMode == MeasureSpec.EXACTLY) {
            int hAvailable = Math.max(1, heightSize - getPaddingTop() - getPaddingBottom());
            cellHeight = Math.max(dp(48), (hAvailable - gapPx * (rows + 1)) / rows);
            desiredHeight = heightSize;
        } else {
            cellHeight = cellWidth;
            desiredHeight = getPaddingTop() + getPaddingBottom() + gapPx * (rows + 1) + cellHeight * rows;
            if (heightMode == MeasureSpec.AT_MOST) desiredHeight = Math.min(desiredHeight, heightSize);
        }

        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child instanceof SearchWidgetView) {
                int w = cellWidth * columns + gapPx * (columns - 1) - dp(SEARCH_HORIZONTAL_INSET_DP * 2);
                int searchH = searchVisualHeight();
                child.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(searchH, MeasureSpec.EXACTLY));
            } else if (child instanceof BookmarkTileView) {
                BookmarkNode n = ((BookmarkTileView) child).getNode();
                int sx = Math.max(1, Math.min(columns, n.spanX));
                int sy = Math.max(1, Math.min(rows, n.spanY));
                int w = cellWidth * sx + gapPx * (sx - 1);
                int h = cellHeight * sy + gapPx * (sy - 1);
                child.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
            }
        }
        setMeasuredDimension(width, desiredHeight);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child instanceof SearchWidgetView) {
                int y = Math.max(0, Math.min(rows - 1, searchCellY));
                int left = getPaddingLeft() + gapPx + dp(SEARCH_HORIZONTAL_INSET_DP);
                int rowTop = getPaddingTop() + gapPx + y * (cellHeight + gapPx);
                int top = rowTop + (cellHeight - child.getMeasuredHeight()) / 2;
                child.layout(left, top, left + child.getMeasuredWidth(), top + child.getMeasuredHeight());
            } else if (child instanceof BookmarkTileView) {
                BookmarkNode n = ((BookmarkTileView) child).getNode();
                int sx = Math.max(1, Math.min(columns, n.spanX));
                int sy = Math.max(1, Math.min(rows, n.spanY));
                int x = Math.max(0, Math.min(columns - sx, n.cellX));
                int y = Math.max(0, Math.min(rows - sy, n.cellY));
                int left = getPaddingLeft() + gapPx + x * (cellWidth + gapPx);
                int top = getPaddingTop() + gapPx + y * (cellHeight + gapPx);
                child.layout(left, top, left + child.getMeasuredWidth(), top + child.getMeasuredHeight());
            }
        }

        if (pendingReorderAnimationFrom != null) {
            Map<String, float[]> from = pendingReorderAnimationFrom;
            pendingReorderAnimationFrom = null;
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                if (!(child instanceof BookmarkTileView) || child == dragging) continue;
                BookmarkTileView tile = (BookmarkTileView) child;
                float[] old = from.get(tile.getNode().id);
                if (old == null) continue;
                float dx = old[0] - child.getLeft();
                float dy = old[1] - child.getTop();
                if (Math.abs(dx) < 0.5f && Math.abs(dy) < 0.5f) continue;
                child.animate().cancel();
                child.setTranslationX(dx);
                child.setTranslationY(dy);
                child.animate()
                        .translationX(0f)
                        .translationY(0f)
                        .setDuration(REORDER_ANIMATION_MS)
                        .start();
            }
        }
    }

    private int searchVisualHeight() {
        return Math.max(dp(30), Math.round(cellHeight * SEARCH_HEIGHT_FRACTION));
    }

    private static boolean fits(boolean[][] occupied, int x, int y, int spanX, int spanY) {
        if (x < 0 || y < 0 || y + spanY > occupied.length || x + spanX > occupied[0].length) return false;
        for (int yy = y; yy < y + spanY; yy++) {
            for (int xx = x; xx < x + spanX; xx++) if (occupied[yy][xx]) return false;
        }
        return true;
    }

    private static void mark(boolean[][] occupied, int x, int y, int spanX, int spanY, boolean value) {
        if (x < 0 || y < 0) return;
        for (int yy = y; yy < y + spanY && yy < occupied.length; yy++) {
            for (int xx = x; xx < x + spanX && xx < occupied[0].length; xx++) occupied[yy][xx] = value;
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static final class FlatDragShadowBuilder extends View.DragShadowBuilder {
        private final View view;

        FlatDragShadowBuilder(View view) {
            super(view);
            this.view = view;
        }

        @Override
        public void onProvideShadowMetrics(Point outShadowSize, Point outShadowTouchPoint) {
            int width = Math.max(1, view.getWidth());
            int height = Math.max(1, view.getHeight());
            outShadowSize.set(width, height);
            outShadowTouchPoint.set(width / 2, height / 2);
        }

        @Override
        public void onDrawShadow(Canvas canvas) {
            view.draw(canvas);
        }
    }
}
