package com.cmyk.bookmarkslauncher.ui;

import android.content.ClipData;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class BookmarkBoardView extends ViewGroup {
    public interface Listener {
        void onOpen(BookmarkNode node, View anchor);
        void onLongPress(BookmarkNode node, View anchor);
        void onPositionsChanged(List<BookmarkNode> nodes);
        void onExternalDrop(BookmarkNode dragged, int cellX, int cellY, List<BookmarkNode> residentNodes);
        void onCreateFolder(BookmarkNode dragged, BookmarkNode target);
        void onMoveIntoFolder(BookmarkNode dragged, BookmarkNode folder, View folderAnchor);
        void onDragExited(BookmarkNode dragged);
        void onDragStateChanged(boolean active, BookmarkNode node);
    }

    // Keep the reorder dwell aligned with current AOSP Launcher3 behavior.
    private static final long REORDER_DELAY_MS = 650L;
    private static final float FOLDER_RADIUS_FACTOR = 0.28f;

    private static final int N_GREEN = 0xFF227733;
    private static final int N_ORANGE = 0xFF775500;

    private final int columns;
    private final int rows;
    private final int gapPx;
    private final List<BookmarkNode> nodes = new ArrayList<>();
    private final Map<String, int[]> originalPositions = new HashMap<>();
    private final Paint targetPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private Listener listener;
    private String containerId;
    private int cellWidth;
    private int cellHeight;

    private BookmarkTileView dragging;
    private BookmarkTileView folderTarget;
    private int pendingCellX = -1;
    private int pendingCellY = -1;
    private int scheduledCellX = -1;
    private int scheduledCellY = -1;
    private boolean reorderPreview;
    private boolean dropHandled;
    private boolean everMoved;
    private boolean sourceOwnsDrag;
    private boolean exitNotified;
    private boolean hasDragLocation;
    private float dragStartX;
    private float dragStartY;
    private float lastTouchX;
    private float lastTouchY;

    private final Runnable reorderRunnable = () -> {
        if (dragging == null || folderTarget != null) return;
        if (pendingCellX != scheduledCellX || pendingCellY != scheduledCellY) return;
        previewReorderAt(pendingCellX, pendingCellY);
    };

    public BookmarkBoardView(Context context, int columns, int rows) {
        super(context);
        this.columns = Math.max(1, columns);
        this.rows = Math.max(1, rows);
        this.gapPx = dp(6);
        setWillNotDraw(false);
        setClipChildren(false);
        setClipToPadding(false);
        setOnDragListener(this::handleDrag);
    }

    public int getColumns() { return columns; }
    public int getRows() { return rows; }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<BookmarkNode> items) {
        cancelReorderTimer();
        clearFolderTarget();
        nodes.clear();
        nodes.addAll(items);
        rebuild();
    }

    private void rebuild() {
        removeAllViews();
        for (BookmarkNode node : nodes) {
            BookmarkTileView tile = new BookmarkTileView(getContext(), node);
            tile.setElevation(0f);
            tile.setOnClickListener(v -> {
                if (listener != null) listener.onOpen(node, v);
            });
            tile.setOnTouchListener((v, event) -> {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN || event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    lastTouchX = v.getLeft() + event.getX();
                    lastTouchY = v.getTop() + event.getY();
                }
                return false;
            });
            tile.setOnLongClickListener(v -> beginDrag((BookmarkTileView) v));
            addView(tile);
        }
        requestLayout();
    }

    private boolean beginDrag(BookmarkTileView tile) {
        dragging = tile;
        sourceOwnsDrag = true;
        pendingCellX = tile.getNode().cellX;
        pendingCellY = tile.getNode().cellY;
        scheduledCellX = -1;
        scheduledCellY = -1;
        reorderPreview = false;
        dropHandled = false;
        everMoved = false;
        exitNotified = false;
        hasDragLocation = false;
        dragStartX = lastTouchX;
        dragStartY = lastTouchY;
        snapshotPositions();
        clearFolderTarget();

        if (listener != null) listener.onDragStateChanged(true, tile.getNode());

        ClipData data = ClipData.newPlainText("bookmark-id", tile.getNode().id);
        boolean started = tile.startDragAndDrop(data, new FlatDragShadowBuilder(tile), tile, 0);
        if (started) {
            tile.setAlpha(0.18f);
            tile.setScaleX(1.04f);
            tile.setScaleY(1.04f);
        } else {
            if (listener != null) listener.onDragStateChanged(false, tile.getNode());
            resetDraggedAppearance();
            dragging = null;
        }
        return started;
    }

    private boolean handleDrag(View v, DragEvent e) {
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                if (!(e.getLocalState() instanceof BookmarkTileView)) return false;
                dragging = (BookmarkTileView) e.getLocalState();
                sourceOwnsDrag = containsNode(dragging.getNode().id);
                snapshotPositions();
                dropHandled = false;
                reorderPreview = false;
                exitNotified = false;
                hasDragLocation = false;
                if (!sourceOwnsDrag) everMoved = true;
                clearFolderTarget();
                return true;

            case DragEvent.ACTION_DRAG_LOCATION:
                if (dragging == null) return true;
                hasDragLocation = true;
                if (sourceOwnsDrag) {
                    float dx = e.getX() - dragStartX;
                    float dy = e.getY() - dragStartY;
                    if (dx * dx + dy * dy > dp(12) * dp(12)) everMoved = true;
                } else {
                    everMoved = true;
                }
                updateDragTarget(e.getX(), e.getY());
                return true;

            case DragEvent.ACTION_DRAG_EXITED:
                cancelReorderTimer();
                clearFolderTarget();
                pendingCellX = -1;
                pendingCellY = -1;
                invalidate();
                if (hasDragLocation && everMoved && !exitNotified && listener != null) {
                    exitNotified = true;
                    listener.onDragExited(dragging.getNode());
                }
                return true;

            case DragEvent.ACTION_DROP:
                if (dragging == null) return true;
                dropHandled = true;
                performDrop();
                return true;

            case DragEvent.ACTION_DRAG_ENDED:
                if (!dropHandled || !e.getResult()) restoreOriginalPositions();
                BookmarkNode endedNode = dragging == null ? null : dragging.getNode();
                boolean notifyEnd = sourceOwnsDrag;
                cancelReorderTimer();
                clearFolderTarget();
                resetDraggedAppearance();
                dragging = null;
                pendingCellX = -1;
                pendingCellY = -1;
                scheduledCellX = -1;
                scheduledCellY = -1;
                reorderPreview = false;
                dropHandled = false;
                everMoved = false;
                sourceOwnsDrag = false;
                exitNotified = false;
                hasDragLocation = false;
                originalPositions.clear();
                invalidate();
                if (notifyEnd && endedNode != null && listener != null) {
                    listener.onDragStateChanged(false, endedNode);
                }
                return true;

            default:
                return true;
        }
    }

    private void updateDragTarget(float x, float y) {
        BookmarkTileView target = tileUnder(x, y);
        if (target != null && target != dragging && inFolderZone(target, x, y)) {
            cancelReorderTimer();
            if (reorderPreview) restoreOriginalPositions();
            pendingCellX = -1;
            pendingCellY = -1;
            setFolderTarget(target);
            invalidate();
            return;
        }

        clearFolderTarget();
        int[] cell = cellForPoint(x, y, dragging.getNode().spanX, dragging.getNode().spanY);
        int newX = cell[0];
        int newY = cell[1];
        boolean changed = newX != pendingCellX || newY != pendingCellY;
        pendingCellX = newX;
        pendingCellY = newY;

        if (changed && reorderPreview) restoreOriginalPositions();

        if (areaFree(newX, newY, dragging.getNode().spanX, dragging.getNode().spanY, dragging.getNode().id)) {
            cancelReorderTimer();
        } else if (changed || scheduledCellX != newX || scheduledCellY != newY) {
            scheduleReorder(newX, newY);
        }
        invalidate();
    }

    private void performDrop() {
        BookmarkNode draggedNode = dragging.getNode();

        if (folderTarget != null && folderTarget != dragging && listener != null) {
            BookmarkNode target = folderTarget.getNode();
            restoreOriginalPositions();
            everMoved = true;
            if (target.isFolder()) listener.onMoveIntoFolder(draggedNode, target, folderTarget);
            else listener.onCreateFolder(draggedNode, target);
            return;
        }

        if (sourceOwnsDrag && !everMoved) {
            restoreOriginalPositions();
            if (listener != null) listener.onLongPress(draggedNode, dragging);
            return;
        }

        if (pendingCellX < 0 || pendingCellY < 0) {
            restoreOriginalPositions();
            return;
        }

        if (!areaFree(pendingCellX, pendingCellY, draggedNode.spanX, draggedNode.spanY, draggedNode.id)) {
            previewReorderAt(pendingCellX, pendingCellY);
        }

        if (!areaFree(pendingCellX, pendingCellY, draggedNode.spanX, draggedNode.spanY, draggedNode.id)) {
            restoreOriginalPositions();
            return;
        }

        draggedNode.cellX = pendingCellX;
        draggedNode.cellY = pendingCellY;
        reorderPreview = false;
        requestLayout();

        if (listener != null) {
            if (sourceOwnsDrag && Objects.equals(draggedNode.parentId, containerId)) {
                listener.onPositionsChanged(new ArrayList<>(nodes));
            } else {
                listener.onExternalDrop(draggedNode, pendingCellX, pendingCellY, new ArrayList<>(nodes));
            }
        }
    }

    private void scheduleReorder(int cellX, int cellY) {
        cancelReorderTimer();
        scheduledCellX = cellX;
        scheduledCellY = cellY;
        postDelayed(reorderRunnable, REORDER_DELAY_MS);
    }

    private void cancelReorderTimer() {
        removeCallbacks(reorderRunnable);
        scheduledCellX = -1;
        scheduledCellY = -1;
    }

    private void previewReorderAt(int cellX, int cellY) {
        if (dragging == null || cellX < 0 || cellY < 0) return;
        restoreOriginalPositions();

        BookmarkNode draggedNode = dragging.getNode();
        List<BookmarkNode> conflicts = conflictsAt(cellX, cellY, draggedNode.spanX, draggedNode.spanY, draggedNode.id);
        if (conflicts.isEmpty()) return;

        boolean[][] occupied = occupancyExcluding(draggedNode.id, conflicts);
        mark(occupied, cellX, cellY, draggedNode.spanX, draggedNode.spanY, true);

        for (BookmarkNode conflict : conflicts) {
            int[] original = originalPositions.get(conflict.id);
            int originX = original == null ? conflict.cellX : original[0];
            int originY = original == null ? conflict.cellY : original[1];
            int[] free = nearestFree(occupied, originX, originY, conflict.spanX, conflict.spanY);
            if (free == null) {
                restoreOriginalPositions();
                return;
            }
            conflict.cellX = free[0];
            conflict.cellY = free[1];
            mark(occupied, free[0], free[1], conflict.spanX, conflict.spanY, true);
        }

        reorderPreview = true;
        requestLayout();
        invalidate();
    }

    private List<BookmarkNode> conflictsAt(int x, int y, int spanX, int spanY, String excludeId) {
        List<BookmarkNode> out = new ArrayList<>();
        for (BookmarkNode n : nodes) {
            if (n.id.equals(excludeId)) continue;
            if (rectsOverlap(x, y, spanX, spanY, n.cellX, n.cellY, n.spanX, n.spanY)) out.add(n);
        }
        return out;
    }

    private boolean[][] occupancyExcluding(String draggedId, List<BookmarkNode> additionallyExcluded) {
        boolean[][] occupied = new boolean[rows][columns];
        for (BookmarkNode n : nodes) {
            if (n.id.equals(draggedId) || additionallyExcluded.contains(n)) continue;
            mark(occupied, n.cellX, n.cellY, n.spanX, n.spanY, true);
        }
        return occupied;
    }

    private int[] nearestFree(boolean[][] occupied, int originX, int originY, int spanX, int spanY) {
        int[] best = null;
        int bestScore = Integer.MAX_VALUE;
        for (int y = 0; y <= rows - spanY; y++) {
            for (int x = 0; x <= columns - spanX; x++) {
                if (!fits(occupied, x, y, spanX, spanY)) continue;
                int distance = Math.abs(x - originX) + Math.abs(y - originY);
                int score = distance * 100 + y * columns + x;
                if (score < bestScore) {
                    bestScore = score;
                    best = new int[]{x, y};
                }
            }
        }
        return best;
    }

    private boolean areaFree(int x, int y, int spanX, int spanY, String excludeId) {
        if (x < 0 || y < 0 || x + spanX > columns || y + spanY > rows) return false;
        for (BookmarkNode n : nodes) {
            if (n.id.equals(excludeId)) continue;
            if (rectsOverlap(x, y, spanX, spanY, n.cellX, n.cellY, n.spanX, n.spanY)) return false;
        }
        return true;
    }

    private boolean containsNode(String id) {
        for (BookmarkNode n : nodes) if (n.id.equals(id)) return true;
        return false;
    }

    private static boolean rectsOverlap(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh) {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
    }

    private BookmarkTileView tileUnder(float x, float y) {
        for (int i = getChildCount() - 1; i >= 0; i--) {
            View child = getChildAt(i);
            if (child == dragging || !(child instanceof BookmarkTileView)) continue;
            if (x >= child.getLeft() && x <= child.getRight() && y >= child.getTop() && y <= child.getBottom()) {
                return (BookmarkTileView) child;
            }
        }
        return null;
    }

    private boolean inFolderZone(BookmarkTileView target, float x, float y) {
        float cx = target.getLeft() + target.getWidth() / 2f;
        float cy = target.getTop() + target.getHeight() / 2f;
        float dx = x - cx;
        float dy = y - cy;
        float radius = Math.min(target.getWidth(), target.getHeight()) * FOLDER_RADIUS_FACTOR;
        return dx * dx + dy * dy <= radius * radius;
    }

    private int[] cellForPoint(float x, float y, int spanX, int spanY) {
        int sx = Math.max(1, Math.min(columns, spanX));
        int sy = Math.max(1, Math.min(rows, spanY));
        float strideX = cellWidth + gapPx;
        float strideY = cellHeight + gapPx;
        float itemW = cellWidth * sx + gapPx * (sx - 1);
        float itemH = cellHeight * sy + gapPx * (sy - 1);
        float firstLeft = getPaddingLeft() + gapPx;
        float firstTop = getPaddingTop() + gapPx;
        int cellX = Math.round((x - firstLeft - itemW / 2f) / strideX);
        int cellY = Math.round((y - firstTop - itemH / 2f) / strideY);
        cellX = Math.max(0, Math.min(columns - sx, cellX));
        cellY = Math.max(0, Math.min(rows - sy, cellY));
        return new int[]{cellX, cellY};
    }

    private void setFolderTarget(BookmarkTileView target) {
        if (folderTarget == target) return;
        clearFolderTarget();
        folderTarget = target;
        folderTarget.setDropHighlight(true);
        folderTarget.setScaleX(1.06f);
        folderTarget.setScaleY(1.06f);
    }

    private void clearFolderTarget() {
        if (folderTarget != null) {
            folderTarget.setDropHighlight(false);
            folderTarget.setScaleX(1f);
            folderTarget.setScaleY(1f);
        }
        folderTarget = null;
    }

    private void snapshotPositions() {
        originalPositions.clear();
        for (BookmarkNode n : nodes) originalPositions.put(n.id, new int[]{n.cellX, n.cellY});
    }

    private void restoreOriginalPositions() {
        if (originalPositions.isEmpty()) return;
        for (BookmarkNode n : nodes) {
            int[] p = originalPositions.get(n.id);
            if (p != null) {
                n.cellX = p[0];
                n.cellY = p[1];
            }
        }
        reorderPreview = false;
        requestLayout();
        invalidate();
    }

    private void resetDraggedAppearance() {
        if (dragging != null) {
            dragging.setAlpha(1f);
            dragging.setScaleX(1f);
            dragging.setScaleY(1f);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (dragging == null || pendingCellX < 0 || pendingCellY < 0 || folderTarget != null) return;
        int sx = Math.max(1, dragging.getNode().spanX);
        int sy = Math.max(1, dragging.getNode().spanY);
        float left = getPaddingLeft() + gapPx + pendingCellX * (cellWidth + gapPx);
        float top = getPaddingTop() + gapPx + pendingCellY * (cellHeight + gapPx);
        float right = left + cellWidth * sx + gapPx * (sx - 1);
        float bottom = top + cellHeight * sy + gapPx * (sy - 1);
        boolean free = areaFree(pendingCellX, pendingCellY, sx, sy, dragging.getNode().id);
        targetPaint.setStyle(Paint.Style.STROKE);
        targetPaint.setStrokeWidth(dp(2));
        targetPaint.setColor(free ? N_GREEN : N_ORANGE);
        canvas.drawRoundRect(new RectF(left + dp(2), top + dp(2), right - dp(2), bottom - dp(2)), dp(12), dp(12), targetPaint);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int widthAvailable = Math.max(1, width - getPaddingLeft() - getPaddingRight());
        cellWidth = Math.max(1, (widthAvailable - gapPx * (columns + 1)) / columns);

        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        int desiredHeight;
        if (heightMode == MeasureSpec.EXACTLY) {
            int hAvailable = Math.max(1, heightSize - getPaddingTop() - getPaddingBottom());
            cellHeight = Math.max(dp(48), (hAvailable - gapPx * (rows + 1)) / rows);
            desiredHeight = heightSize;
        } else {
            cellHeight = cellWidth;
            desiredHeight = getPaddingTop() + getPaddingBottom() + gapPx * (rows + 1) + cellHeight * rows;
            if (heightMode == MeasureSpec.AT_MOST) desiredHeight = Math.min(desiredHeight, heightSize);
        }

        for (int i = 0; i < getChildCount(); i++) {
            BookmarkTileView child = (BookmarkTileView) getChildAt(i);
            BookmarkNode n = child.getNode();
            int sx = Math.max(1, Math.min(columns, n.spanX));
            int sy = Math.max(1, Math.min(rows, n.spanY));
            int w = cellWidth * sx + gapPx * (sx - 1);
            int h = cellHeight * sy + gapPx * (sy - 1);
            child.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
        }
        setMeasuredDimension(width, desiredHeight);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        for (int i = 0; i < getChildCount(); i++) {
            BookmarkTileView child = (BookmarkTileView) getChildAt(i);
            BookmarkNode n = child.getNode();
            int sx = Math.max(1, Math.min(columns, n.spanX));
            int sy = Math.max(1, Math.min(rows, n.spanY));
            int x = Math.max(0, Math.min(columns - sx, n.cellX));
            int y = Math.max(0, Math.min(rows - sy, n.cellY));
            int left = getPaddingLeft() + gapPx + x * (cellWidth + gapPx);
            int top = getPaddingTop() + gapPx + y * (cellHeight + gapPx);
            child.layout(left, top, left + child.getMeasuredWidth(), top + child.getMeasuredHeight());
        }
    }

    private static boolean fits(boolean[][] occupied, int x, int y, int spanX, int spanY) {
        if (x < 0 || y < 0 || y + spanY > occupied.length || x + spanX > occupied[0].length) return false;
        for (int yy = y; yy < y + spanY; yy++) {
            for (int xx = x; xx < x + spanX; xx++) if (occupied[yy][xx]) return false;
        }
        return true;
    }

    private static void mark(boolean[][] occupied, int x, int y, int spanX, int spanY, boolean value) {
        if (x < 0 || y < 0) return;
        for (int yy = y; yy < y + spanY && yy < occupied.length; yy++) {
            for (int xx = x; xx < x + spanX && xx < occupied[0].length; xx++) occupied[yy][xx] = value;
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static final class FlatDragShadowBuilder extends View.DragShadowBuilder {
        private final View view;

        FlatDragShadowBuilder(View view) {
            super(view);
            this.view = view;
        }

        @Override
        public void onProvideShadowMetrics(Point outShadowSize, Point outShadowTouchPoint) {
            int width = Math.max(1, view.getWidth());
            int height = Math.max(1, view.getHeight());
            outShadowSize.set(width, height);
            outShadowTouchPoint.set(width / 2, height / 2);
        }

        @Override
        public void onDrawShadow(Canvas canvas) {
            view.draw(canvas);
        }
    }
}
