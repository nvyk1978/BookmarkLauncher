package com.cmyk.bookmarkslauncher.ui;

import android.content.ClipData;
import android.content.Context;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.DragEvent;
import android.view.View;
import android.view.ViewGroup;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import java.util.ArrayList;
import java.util.List;

public final class BookmarkBoardView extends ViewGroup {
    public interface Listener {
        void onOpen(BookmarkNode node, View anchor);
        void onLongPress(BookmarkNode node, View anchor);
        void onOrderChanged(List<String> orderedIds);
        void onCreateFolder(BookmarkNode dragged, BookmarkNode target);
        void onMoveIntoFolder(BookmarkNode dragged, BookmarkNode folder);
    }

    private static final long FOLDER_HOVER_MS = 460L;
    private static final float CENTER_ZONE = 0.31f;

    private final int columns;
    private final int gapPx;
    private final List<BookmarkNode> nodes = new ArrayList<>();
    private Listener listener;
    private int cellSize;

    private BookmarkTileView dragging;
    private int dragFrom = -1;
    private int pendingInsert = -1;
    private BookmarkTileView hoverTile;
    private long hoverStarted;
    private boolean folderArmed;
    private boolean dragMoved;
    private boolean dropHandled;

    public BookmarkBoardView(Context context, int columns) {
        super(context);
        this.columns = columns;
        this.gapPx = dp(6);
        setClipChildren(false);
        setClipToPadding(false);
        setOnDragListener(this::handleDrag);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<BookmarkNode> items) {
        clearDragState();
        nodes.clear();
        nodes.addAll(items);
        rebuild();
    }

    private void rebuild() {
        removeAllViews();
        for (BookmarkNode node : nodes) {
            BookmarkTileView tile = new BookmarkTileView(getContext(), node);
            tile.setOnClickListener(v -> {
                if (listener != null) listener.onOpen(node, v);
            });
            tile.setOnLongClickListener(v -> {
                if (!(v instanceof BookmarkTileView)) return false;
                dragging = (BookmarkTileView) v;
                dragFrom = indexOfChild(v);
                pendingInsert = dragFrom;
                dragMoved = false;
                dropHandled = false;
                folderArmed = false;
                clearHover();
                dragging.setAlpha(0.38f);
                dragging.setScaleX(1.04f);
                dragging.setScaleY(1.04f);
                ClipData data = ClipData.newPlainText("bookmark-id", node.id);
                boolean started = v.startDragAndDrop(data, new DragShadowBuilder(v), v, 0);
                if (!started) resetDraggedAppearance();
                return started;
            });
            addView(tile);
        }
        requestLayout();
    }

    private boolean handleDrag(View v, DragEvent e) {
        switch (e.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                if (e.getLocalState() instanceof BookmarkTileView) {
                    dragging = (BookmarkTileView) e.getLocalState();
                    dragFrom = indexOfChild(dragging);
                    pendingInsert = dragFrom;
                    return true;
                }
                return false;

            case DragEvent.ACTION_DRAG_LOCATION:
                if (dragging == null) return true;
                updateDragTarget(e.getX(), e.getY());
                return true;

            case DragEvent.ACTION_DRAG_EXITED:
                clearHover();
                return true;

            case DragEvent.ACTION_DROP:
                if (dragging == null) return true;
                dropHandled = true;
                performDrop();
                return true;

            case DragEvent.ACTION_DRAG_ENDED:
                BookmarkTileView finished = dragging;
                boolean showMenu = !dropHandled && !dragMoved;
                resetDraggedAppearance();
                clearHover();
                dragging = null;
                dragFrom = -1;
                pendingInsert = -1;
                folderArmed = false;
                dropHandled = false;
                if (showMenu && finished != null && listener != null) {
                    listener.onLongPress(finished.getNode(), finished);
                }
                return true;

            default:
                return true;
        }
    }

    private void updateDragTarget(float x, float y) {
        int nearest = nearestIndex(x, y);
        if (nearest < 0 || nearest >= getChildCount()) return;
        View raw = getChildAt(nearest);
        if (!(raw instanceof BookmarkTileView)) return;
        BookmarkTileView target = (BookmarkTileView) raw;

        if (target == dragging) {
            clearHover();
            pendingInsert = dragFrom;
            return;
        }
        dragMoved = true;

        Rect r = new Rect(target.getLeft(), target.getTop(), target.getRight(), target.getBottom());
        float dx = Math.abs(x - r.exactCenterX());
        float dy = Math.abs(y - r.exactCenterY());
        boolean inCenter = dx <= r.width() * CENTER_ZONE && dy <= r.height() * CENTER_ZONE;

        if (inCenter) {
            pendingInsert = -1;
            if (hoverTile != target) {
                clearHover();
                hoverTile = target;
                hoverStarted = SystemClock.uptimeMillis();
                hoverTile.setDropHighlight(true);
                final BookmarkTileView armedTarget = target;
                postDelayed(() -> {
                    if (dragging != null && hoverTile == armedTarget) {
                        folderArmed = true;
                        armedTarget.setScaleX(1.06f);
                        armedTarget.setScaleY(1.06f);
                    }
                }, FOLDER_HOVER_MS);
            }
            if (SystemClock.uptimeMillis() - hoverStarted >= FOLDER_HOVER_MS) {
                folderArmed = true;
                hoverTile.setScaleX(1.06f);
                hoverTile.setScaleY(1.06f);
            }
        } else {
            clearHover();
            folderArmed = false;
            pendingInsert = insertionIndexFor(target, x, y);
            if (pendingInsert != dragFrom) dragMoved = true;
        }
    }

    private void performDrop() {
        BookmarkNode draggedNode = dragging.getNode();
        if (folderArmed && hoverTile != null && hoverTile != dragging && listener != null) {
            BookmarkNode target = hoverTile.getNode();
            dragMoved = true;
            if (target.isFolder()) listener.onMoveIntoFolder(draggedNode, target);
            else listener.onCreateFolder(draggedNode, target);
            return;
        }

        if (!folderArmed && !dragMoved && (pendingInsert < 0 || pendingInsert == dragFrom)) {
            if (listener != null) listener.onLongPress(draggedNode, dragging);
            return;
        }

        if (pendingInsert < 0) pendingInsert = dragFrom;
        int from = indexOfNode(draggedNode.id);
        if (from < 0) return;

        int to = Math.max(0, Math.min(pendingInsert, nodes.size()));
        BookmarkNode moved = nodes.remove(from);
        if (to > from) to--;
        to = Math.max(0, Math.min(to, nodes.size()));
        nodes.add(to, moved);
        dragMoved = dragMoved || to != from;

        if (dragMoved && listener != null) {
            List<String> ids = new ArrayList<>();
            for (BookmarkNode n : nodes) ids.add(n.id);
            listener.onOrderChanged(ids);
        }
    }

    private int insertionIndexFor(BookmarkTileView target, float x, float y) {
        int targetIndex = indexOfChild(target);
        if (targetIndex < 0) return dragFrom;
        float centerX = target.getLeft() + target.getWidth() / 2f;
        float centerY = target.getTop() + target.getHeight() / 2f;

        // Launcher-like: grazing the side means sorting, not folder creation.
        if (Math.abs(y - centerY) <= target.getHeight() * 0.55f) {
            return x < centerX ? targetIndex : targetIndex + 1;
        }
        return y < centerY ? targetIndex : targetIndex + 1;
    }

    private int nearestIndex(float x, float y) {
        if (getChildCount() == 0) return -1;
        Rect r = new Rect();
        int best = -1;
        double bestDistance = Double.MAX_VALUE;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child == dragging) continue;
            child.getHitRect(r);
            if (r.contains((int) x, (int) y)) return i;
            double dx = x - r.exactCenterX();
            double dy = y - r.exactCenterY();
            double dist = dx * dx + dy * dy;
            if (dist < bestDistance) {
                bestDistance = dist;
                best = i;
            }
        }
        return best;
    }

    private int indexOfNode(String id) {
        for (int i = 0; i < nodes.size(); i++) {
            if (nodes.get(i).id.equals(id)) return i;
        }
        return -1;
    }

    private void clearHover() {
        if (hoverTile != null) {
            hoverTile.setDropHighlight(false);
            hoverTile.setScaleX(1f);
            hoverTile.setScaleY(1f);
        }
        hoverTile = null;
        hoverStarted = 0L;
        folderArmed = false;
    }

    private void resetDraggedAppearance() {
        if (dragging != null) {
            dragging.setAlpha(1f);
            dragging.setScaleX(1f);
            dragging.setScaleY(1f);
        }
    }

    private void clearDragState() {
        resetDraggedAppearance();
        clearHover();
        dragging = null;
        dragFrom = -1;
        pendingInsert = -1;
        dragMoved = false;
        dropHandled = false;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int contentWidth = Math.max(1, width - getPaddingLeft() - getPaddingRight());
        cellSize = Math.max(1, (contentWidth - gapPx * (columns + 1)) / columns);

        int[] heights = new int[columns];
        for (int i = 0; i < getChildCount(); i++) {
            BookmarkTileView child = (BookmarkTileView) getChildAt(i);
            BookmarkNode n = child.getNode();
            int spanX = Math.max(1, Math.min(columns, n.spanX));
            int spanY = Math.max(1, n.spanY);
            int w = cellSize * spanX + gapPx * (spanX - 1);
            int h = cellSize * spanY + gapPx * (spanY - 1);
            child.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
            int col = shortestRun(heights, spanX);
            int base = 0;
            for (int c = col; c < col + spanX; c++) base = Math.max(base, heights[c]);
            int next = base + h + gapPx;
            for (int c = col; c < col + spanX; c++) heights[c] = next;
        }
        int max = 0;
        for (int h : heights) max = Math.max(max, h);
        setMeasuredDimension(width, Math.max(dp(120), max + gapPx + getPaddingTop() + getPaddingBottom()));
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int[] heights = new int[columns];
        for (int i = 0; i < getChildCount(); i++) {
            BookmarkTileView child = (BookmarkTileView) getChildAt(i);
            BookmarkNode n = child.getNode();
            int span = Math.max(1, Math.min(columns, n.spanX));
            int col = shortestRun(heights, span);
            int top = 0;
            for (int c = col; c < col + span; c++) top = Math.max(top, heights[c]);
            int left = getPaddingLeft() + gapPx + col * (cellSize + gapPx);
            int childTop = getPaddingTop() + gapPx + top;
            child.layout(left, childTop, left + child.getMeasuredWidth(), childTop + child.getMeasuredHeight());
            int next = top + child.getMeasuredHeight() + gapPx;
            for (int c = col; c < col + span; c++) heights[c] = next;
        }
    }

    private int shortestRun(int[] heights, int span) {
        int bestCol = 0;
        int bestHeight = Integer.MAX_VALUE;
        for (int c = 0; c <= columns - span; c++) {
            int h = 0;
            for (int x = c; x < c + span; x++) h = Math.max(h, heights[x]);
            if (h < bestHeight) {
                bestHeight = h;
                bestCol = c;
            }
        }
        return bestCol;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
