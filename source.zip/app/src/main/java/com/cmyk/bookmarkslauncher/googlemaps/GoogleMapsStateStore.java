package com.cmyk.bookmarkslauncher.googlemaps;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Private per-bookmark state for the isolated Google Maps integration.
 * Nothing outside the googlemaps package needs to know about map coordinates or scale.
 */
final class GoogleMapsStateStore {
    private GoogleMapsStateStore() {}

    private static final String PREFS = "google_maps_bookmark_state";
    static final float DEFAULT_SCALE = 1.0f;
    static final float MIN_SCALE = 0.70f;
    static final float MAX_SCALE = 1.60f;

    static final class SavedCoordinates {
        final double latitude;
        final double longitude;

        SavedCoordinates(double latitude, double longitude) {
            this.latitude = latitude;
            this.longitude = longitude;
        }
    }

    static void saveCoordinates(Context context, String nodeId, double latitude, double longitude) {
        if (context == null || nodeId == null || nodeId.isBlank()) return;
        if (latitude < -90d || latitude > 90d || longitude < -180d || longitude > 180d) return;
        prefs(context).edit()
                .putLong(key(nodeId, "lat"), Double.doubleToRawLongBits(latitude))
                .putLong(key(nodeId, "lng"), Double.doubleToRawLongBits(longitude))
                .putBoolean(key(nodeId, "has_coord"), true)
                .apply();
    }

    static SavedCoordinates getCoordinates(Context context, String nodeId) {
        if (context == null || nodeId == null || nodeId.isBlank()) return null;
        SharedPreferences p = prefs(context);
        if (!p.getBoolean(key(nodeId, "has_coord"), false)) return null;
        double lat = Double.longBitsToDouble(p.getLong(key(nodeId, "lat"), Double.doubleToRawLongBits(Double.NaN)));
        double lng = Double.longBitsToDouble(p.getLong(key(nodeId, "lng"), Double.doubleToRawLongBits(Double.NaN)));
        if (Double.isNaN(lat) || Double.isNaN(lng) || lat < -90d || lat > 90d || lng < -180d || lng > 180d) return null;
        return new SavedCoordinates(lat, lng);
    }

    static float getScale(Context context, String nodeId) {
        if (context == null || nodeId == null || nodeId.isBlank()) return DEFAULT_SCALE;
        return clampScale(prefs(context).getFloat(key(nodeId, "scale"), DEFAULT_SCALE));
    }

    static void saveScale(Context context, String nodeId, float scale) {
        if (context == null || nodeId == null || nodeId.isBlank()) return;
        prefs(context).edit().putFloat(key(nodeId, "scale"), clampScale(scale)).apply();
    }

    static float clampScale(float value) {
        if (Float.isNaN(value) || Float.isInfinite(value)) return DEFAULT_SCALE;
        return Math.max(MIN_SCALE, Math.min(MAX_SCALE, value));
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String key(String nodeId, String suffix) {
        return nodeId + "." + suffix;
    }
}
