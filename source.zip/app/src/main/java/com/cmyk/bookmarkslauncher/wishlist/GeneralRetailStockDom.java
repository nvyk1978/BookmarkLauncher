package com.cmyk.bookmarkslauncher.wishlist;

/** Read-only, item-identified checks for the two GENERAL stores. Never clicks. */
final class GeneralRetailStockDom {
    private GeneralRetailStockDom() { }

    static String javascript(String storeHost, String code) {
        // Only the URL-validated alphanumeric product ID reaches this method.
        if (code == null || !code.matches("[A-Za-z0-9_-]{5,20}")) return "'UNKNOWN'";
        if (storeHost.equals("askul.co.jp") || storeHost.equals("www.askul.co.jp"))
            return AskulProductDom.stock(code);
        String item = code.replace("'", "");
        boolean askul = storeHost.equals("askul.co.jp") || storeHost.equals("www.askul.co.jp");
        return "(function(){try{" +
            "var expected='" + item + "';var askul=" + askul + ";" +
            "var path=location.pathname||'';" +
            "if(askul){if(path.toLowerCase().replace(/\\/+$/,'')!=='/p/'+expected.toLowerCase())return 'UNKNOWN';}" +
            "else{if(path.replace(/\\/+$/,'')!=='/p/'+expected.slice(0,4)+'/'+expected.slice(4))return 'UNKNOWN';}" +
            "var main=document.querySelector('main,[role=main],#main,#contents,#productDetail,#product-detail')||document.body;" +
            "var title=main.querySelector('h1');if(!title||!title.textContent.trim())return 'UNKNOWN';" +
            "var bodyText=main.textContent||'';" +
            // On Askul SKU labels appear as お申込番号; MonotaRO uses 注文コード.
            "var marker=askul?'お申込番号':'注文コード';" +
            "var codeAt=bodyText.indexOf(expected);if(codeAt<0)return 'UNKNOWN';" +
            "var segment=bodyText.slice(Math.max(0,codeAt-100),codeAt+expected.length+100);" +
            "if(segment.indexOf(marker)<0)return 'UNKNOWN';" +
            "function visible(e){if(!e||e.disabled||e.getAttribute('aria-disabled')==='true'||!e.getClientRects().length)return false;" +
            "for(var n=e;n;n=n.parentElement){if(n.hidden||n.getAttribute('aria-hidden')==='true')return false;" +
            "var s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0)return false;}return true;}" +
            "var buy=askul?/(?:カゴへ|カゴに入れる|カートに入れる)/:/(?:バスケットに入れる|カートに入れる)/;" +
            "var controls=main.querySelectorAll('button,input[type=submit],input[type=button],[role=button],a[href]');" +
            "var valid=[];for(var i=0;i<controls.length&&i<300;i++){var b=controls[i];" +
            "if(!visible(b)||b.closest('header,footer,nav,aside,[class*=related],[class*=recommend],[class*=ranking],[id*=related],[id*=recommend]'))continue;" +
            "var label=(b.innerText||b.textContent||'')+' '+(b.value||'')+' '+(b.getAttribute('aria-label')||'');" +
            "if(!buy.test(label))continue;" +
            "var p=b.closest('form,[class*=purchase],[class*=buy],[class*=cart],[id*=purchase],[id*=buy]')||b.parentElement;" +
            "if(!p||!main.contains(p))continue;" +
            "var selected=p.querySelectorAll('select[required]');var missing=false;" +
            "for(var k=0;k<selected.length;k++){if(visible(selected[k])&&!selected[k].value){missing=true;break;}}" +
            "if(missing)continue;" +
            "valid.push(b);}" +
            "if(valid.length!==1)return 'UNKNOWN';" +
            // Positive checkout evidence, not a warehouse promise. Do not claim
            // sold-out based on page-wide templates, recommendations, or badges.
            "var focus=valid[0].closest('form,[class*=purchase],[class*=buy],[class*=cart]')||valid[0].parentElement;" +
            "if(focus){var notices=focus.querySelectorAll('[class*=stock],[class*=sold],[id*=stock]');" +
            "for(var j=0;j<notices.length;j++)if(visible(notices[j])&&/(?:売り切れ|売切れ|完売|在庫切れ)/.test(notices[j].textContent||''))return 'UNKNOWN';}" +
            "if(askul){var text=(main.innerText||'');" +
            "if(!/在庫\\s*[:：]\\s*あり/.test(text)&&!/在庫商品/.test(text))return 'UNKNOWN';}" +
            "return 'AVAILABLE';" +
            "}catch(e){return 'UNKNOWN';}})()";
    }
}
