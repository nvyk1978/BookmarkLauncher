package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import org.json.JSONObject;

/** Mercari alone: exact-listing state is stronger than a missing rendered H1.
 * No general/recommendation item, no price inference, no cart clicks. */
public final class WishlistMercariItemStockDom {
    private WishlistMercariItemStockDom() { }
    public static String javascript(URL url) {
        if (WishlistGeneralShopItem.merchant(url)!=WishlistGeneralShopItem.Merchant.MERCARI)
            return "JSON.stringify({status:'UNKNOWN',reason:'not-mercari'})";
        return JS.replace("__ID__",JSONObject.quote(WishlistGeneralShopItem.code(url)));
    }
    private static final String JS="""
(function(){'use strict';
 const out={status:'UNKNOWN',reason:'item-state-missing',bound:false,heading:0,
   heroCarts:0,heroDisabled:0,heroPrice:false,heroSold:false,variants:false};
 const done=()=>JSON.stringify(out),id=__ID__;
 try {
  const u=new URL(location.href);
  if(u.protocol!=='https:'||u.hostname!=='jp.mercari.com'||
      u.pathname.replace(/[/]+$/,'')!=='/item/'+id){out.reason='item-url-mismatch';return done();}
  const canon=document.querySelector('link[rel=canonical]');
  if(canon&&canon.href){const c=new URL(canon.href,location.href);
    if(c.protocol!=='https:'||c.hostname!=='jp.mercari.com'||
        c.pathname.replace(/[/]+$/,'')!=='/item/'+id){out.reason='canonical-mismatch';return done();}}
  const roots=[];
  const w=typeof window==='object'?window:{};
  for(const key of ['__NEXT_DATA__','__INITIAL_STATE__','__PRELOADED_STATE__'])
    if(w[key]&&typeof w[key]==='object')roots.push(w[key]);
  const el=document.querySelector('script#__NEXT_DATA__[type="application/json"]');
  if(el){try{const raw=el.textContent||'';
      if(raw.length<1500000)roots.push(JSON.parse(raw));}catch(_){}}
  const matches=[],stack=roots.map(x=>[x,0]),seen=new Set();let steps=0;
  while(stack.length&&steps++<800&&matches.length<12){
   const [obj,depth]=stack.pop();if(!obj||typeof obj!=='object'||seen.has(obj)||depth>11)continue;
   seen.add(obj);
   if(Array.isArray(obj)){for(const x of obj.slice(0,25))if(x&&typeof x==='object')stack.push([x,depth+1]);continue;}
   const claimed=[obj.id,obj.itemId,obj.item_id].filter(x=>x!=null).map(String);
   if(claimed.includes(id)&&claimed.every(x=>x===id)){
    const name=String(obj.name||obj.itemName||obj.title||'').trim();
    const price=obj.price&&typeof obj.price==='object'?obj.price.amount:obj.price;
    const number=Number(String(price||'').replace(/,/g,''));
    const state=String(obj.status||obj.itemStatus||obj.item_status||'').toLowerCase();
    if(name.length>=4&&name.length<=240&&Number.isSafeInteger(number)&&number>=1&&number<=100000000)
      matches.push(state);
   }
   for(const [k,v] of Object.entries(obj).slice(0,80)){
    if(/recommend|related|suggest|popular|rank|advert|search|history|tracking|category/i.test(k))continue;
    if(v&&typeof v==='object')stack.push([v,depth+1]);
   }
  }
  const states=[...new Set(matches.filter(Boolean))];
  if(!states.length){out.reason='item-state-missing';return done();}
  if(states.length!==1){out.reason='conflicting-item-states';return done();}
  out.bound=true;out.heading=1;out.heroPrice=true;
  const st=states[0];
  if(['sold_out','soldout','sold','closed'].includes(st)){
    out.status='UNAVAILABLE';out.heroSold=true;out.reason='listing-id-sold-state';
  }else if(['on_sale','onsale','for_sale','selling'].includes(st)){
    out.status='AVAILABLE';out.reason='listing-id-on-sale-state';
  }else out.reason='unrecognized-item-state';
  return done();
 }catch(_){out.reason='state-script-error';return done();}
})()
""";
}
