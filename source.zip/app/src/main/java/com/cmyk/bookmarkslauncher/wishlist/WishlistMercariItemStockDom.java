package com.cmyk.bookmarkslauncher.wishlist;

import java.net.URL;
import org.json.JSONObject;

/** Mercari alone: exact-listing state is stronger than a missing rendered H1.
 * No general/recommendation item, no price inference, no cart clicks. */
public final class WishlistMercariItemStockDom {
    private WishlistMercariItemStockDom() { }
    public static String javascript(URL url) {
        if (WishlistGeneralShopItem.merchant(url)!=WishlistGeneralShopItem.Merchant.MERCARI)
            return "JSON.stringify({status:'UNKNOWN',reason:'not-mercari'})";
        return JS.replace("__ID__",JSONObject.quote(WishlistGeneralShopItem.code(url)));
    }
    private static final String JS="""
(function(){'use strict';
 const out={status:'UNKNOWN',reason:'item-state-missing',bound:false,heading:0,
   heroCarts:0,heroDisabled:0,heroPrice:false,heroSold:false,variants:false};
 const done=()=>JSON.stringify(out),id=__ID__;
 try {
  const u=new URL(location.href);
  if(u.protocol!=='https:'||u.hostname!=='jp.mercari.com'||
      u.pathname.replace(/[/]+$/,'')!=='/item/'+id){out.reason='item-url-mismatch';return done();}
  const canon=document.querySelector('link[rel=canonical]');
  if(canon&&canon.href){const c=new URL(canon.href,location.href);
    if(c.protocol!=='https:'||c.hostname!=='jp.mercari.com'||
        c.pathname.replace(/[/]+$/,'')!=='/item/'+id){out.reason='canonical-mismatch';return done();}}
  const roots=[];
  const w=typeof window==='object'?window:{};
  for(const key of ['__NEXT_DATA__','__INITIAL_STATE__','__PRELOADED_STATE__'])
    if(w[key]&&typeof w[key]==='object')roots.push(w[key]);
  const el=document.querySelector('script#__NEXT_DATA__[type="application/json"]');
  if(el){try{const raw=el.textContent||'';
      if(raw.length<1500000)roots.push(JSON.parse(raw));}catch(_){}}
  // Merchant Product JSON-LD may be the only server-rendered source, even
  // when the SPA has no H1. Require an explicit listing URL/identifier AND
  // an item name, numeric price and item-bound offer availability.
  const jsonld=[];
  for(const el of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,15)){
   try {const raw=el.textContent||'';if(raw.length>0&&raw.length<350000)
     jsonld.push(JSON.parse(raw));}catch(_){}
  }
  const ldStack=jsonld.map(x=>[x,0]);let ldSteps=0;
  while(ldStack.length&&ldSteps++<160){
   const [obj,depth]=ldStack.pop();if(!obj||typeof obj!=='object'||depth>6)continue;
   if(Array.isArray(obj)){for(const x of obj.slice(0,20))ldStack.push([x,depth+1]);continue;}
   const type=String(obj['@type']||'').toLowerCase();
   if(type==='product'){
    const ids=[obj.url,obj['@id'],obj.productID,obj.sku].filter(x=>typeof x==='string');
    const bound=ids.some(x=>{try{const a=new URL(x,location.href);
     return a.hostname==='jp.mercari.com'&&a.pathname.replace(/[/]+$/,'')==='/item/'+id;
     }catch(_){return x===id;}});
    const name=String(obj.name||'').trim();const offers=Array.isArray(obj.offers)?obj.offers:[obj.offers];
    if(bound&&name.length>=4&&name.length<=240){
     for(const offer of offers){if(!offer||typeof offer!=='object')continue;
      const number=Number(String(offer.price||'').replace(/,/g,''));
      const state=String(offer.availability||'').toLowerCase().split('/').pop();
      if(Number.isSafeInteger(number)&&number>=1&&number<=100000000){
       if(state==='soldout'||state==='outofstock'||state==='discontinued') roots.push({id,name,price:number,status:'sold_out'});
       if(state==='instock'||state==='limitedavailability') roots.push({id,name,price:number,status:'on_sale'});
      }
     }
    }
   }
   for(const [k,v] of Object.entries(obj).slice(0,35)) if(v&&typeof v==='object')ldStack.push([v,depth+1]);
  }
  const matches=[],stack=roots.map(x=>[x,0]),seen=new Set();let steps=0;
  while(stack.length&&steps++<800&&matches.length<12){
   const [obj,depth]=stack.pop();if(!obj||typeof obj!=='object'||seen.has(obj)||depth>11)continue;
   seen.add(obj);
   if(Array.isArray(obj)){for(const x of obj.slice(0,25))if(x&&typeof x==='object')stack.push([x,depth+1]);continue;}
   const claimed=[obj.id,obj.itemId,obj.item_id].filter(x=>x!=null).map(String);
   if(claimed.includes(id)&&claimed.every(x=>x===id)){
    const name=String(obj.name||obj.itemName||obj.title||'').trim();
    const price=obj.price&&typeof obj.price==='object'?
      (obj.price.amount||obj.price.value):obj.price;
    const number=Number(String(price||'').replace(/,/g,''));
    const state=String(obj.status||obj.itemStatus||obj.item_status||'').toLowerCase()
      .replace(/[\s-]+/g,'_');
    if(name.length>=4&&name.length<=240&&Number.isSafeInteger(number)&&number>=1&&number<=100000000)
      matches.push(state);
   }
   for(const [k,v] of Object.entries(obj).slice(0,80)){
    if(/recommend|related|suggest|popular|rank|advert|search|history|tracking|category/i.test(k))continue;
    if(v&&typeof v==='object')stack.push([v,depth+1]);
   }
  }
  const states=[...new Set(matches.filter(Boolean))];
  if(!states.length){out.reason='item-state-missing';return done();}
  if(states.length!==1){out.reason='conflicting-item-states';return done();}
  out.bound=true;out.heading=1;out.heroPrice=true;
  const st=states[0];
  if(['sold_out','soldout','sold','closed'].includes(st)){
    out.status='UNAVAILABLE';out.heroSold=true;out.reason='listing-id-sold-state';
  }else if(['on_sale','onsale','for_sale','selling','available'].includes(st)){
    out.status='AVAILABLE';out.reason='listing-id-on-sale-state';
  }else out.reason='unrecognized-item-state';
  return done();
 }catch(_){out.reason='state-script-error';return done();}
})()
""";
}
