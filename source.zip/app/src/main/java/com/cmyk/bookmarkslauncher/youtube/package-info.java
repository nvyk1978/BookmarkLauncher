/**
 * Isolated YouTube integration for BookmarkLauncher.
 *
 * Boundary rule:
 * - YouTube URL/video-ID parsing and official thumbnail acquisition live here.
 * - Code outside this package uses only YouTubeModule.
 * - Ordinary bookmark/UI development must not change this package unless the
 *   requested change is explicitly about YouTube behavior.
 */
package com.cmyk.bookmarkslauncher.youtube;
