package com.cmyk.bookmarkslauncher.wishlist;

/** Product-bound read-only DOM diagnostics for two independent GENERAL shops.
 * No web action is performed. Unknown evidence is never promoted to AVAILABLE. */
final class WishlistIndependentStockDom {
    private WishlistIndependentStockDom() { }

    static String javascript(String host) {
        if ("eshop.fumuroya.com".equals(host)) return fumuroya();
        if ("e-mono.jr-central.co.jp".equals(host)) return jrCentral();
        return "JSON.stringify({status:'UNKNOWN',reason:'unsupported'})";
    }

    private static String fumuroya() {
        return """
(function(){'use strict';
 const out={status:'UNKNOWN',reason:'missing-evidence',path:false,title:false,
   qty:0,cart:0,enabled:0,negative:0,controls:0};
 const done=()=>JSON.stringify(out);
 try{
   const path=location.pathname||'';
   out.path=/^\\/product\\/detail\\/[0-9]+\\/?$/.test(path);
   if(!out.path){out.reason='path-mismatch';return done();}
   const h=document.querySelector('main h1,h1');
   out.title=!!h&&/宝の麩/.test(h.textContent||'');
   if(!out.title){out.reason='item-title-missing';return done();}
   const root=h.closest('main,[role=main],#main,.product-detail,.item-detail')||document.body;
   if(!root){out.reason='root-missing';return done();}
   const txt=e=>String(e&&(e.innerText||e.textContent)||'').trim();
   const live=e=>{
     if(!e||e.disabled||e.hasAttribute('disabled')||e.getAttribute('aria-disabled')==='true')return false;
     for(let p=e;p;p=p.parentElement){
       if(p.hidden||p.hasAttribute('inert')||p.getAttribute('aria-hidden')==='true')return false;
       const s=getComputedStyle(p);
       if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0)return false;
     }return true;
   };
   const quantities=[...root.querySelectorAll('input[type=number],input[name*=quantity],input[name*=qty],input[name*=amount],select[name*=quantity]')]
     .filter(e=>live(e)&&!e.closest('header,nav,footer,aside,[class*=related],[class*=recommend]'));
   out.qty=quantities.length;
   for(const b of root.querySelectorAll('button,input[type=submit],input[type=image],input[type=button],a[href],[role=button],[onclick]')){
     if(b.closest('header,nav,footer,aside,[class*=related],[class*=recommend]'))continue;
     out.controls++;
     const label=[txt(b),b.value,b.getAttribute('alt'),b.getAttribute('aria-label'),b.getAttribute('title'),b.getAttribute('onclick')].filter(Boolean).join(' ');
     if(!/(?:カートに入れる|買い物かごに入れる|かごに入れる|add.?to.?cart)/i.test(label))continue;
     if(b.querySelector('button,input,[onclick]')&&!b.matches('button,input,a'))continue;
     out.cart++;
     const group=b.closest('form,.product-detail,.item-detail,.purchase,.cart')||b.parentElement;
     if(!group||!root.contains(group))continue;
     const negatives=group.querySelectorAll('[class*=sold],[class*=out-of-stock],[class*=stock], [id*=sold], [id*=stock]');
     let blocked=false;
     for(const n of negatives){if(live(n)&&/(完売しました|販売終了|在庫切れ|売り切れ)/.test(txt(n))){blocked=true;break;}}
     if(blocked)out.negative++;
     if(live(b)&&!blocked)out.enabled++;
   }
   if(out.negative>0){out.reason='visible-sold-out';return done();}
   if(out.enabled===1&&out.cart===1&&out.qty===1){out.status='AVAILABLE';out.reason='product-quantity-cart';return done();}
   out.reason=out.qty===0?'quantity-missing':out.cart===0?'cart-missing':'cart-conflict';
   return done();
 }catch(e){out.reason='dom-error';return done();}
})()
""";
    }

    private static String jrCentral() {
        return """
(function(){'use strict';
 const out={status:'UNKNOWN',reason:'missing-evidence',sku:false,title:false,
   selected:false,qty:0,forms:0,cart:0,enabled:0,negative:false};
 const done=()=>JSON.stringify(out);
 try{
   const path=location.pathname||'';
   out.sku=/^\\/shop\\/g\\/gSG100130006\\/?$/i.test(path);
   if(!out.sku){out.reason='sku-mismatch';return done();}
   const title=document.querySelector('main h1,h1,h2');
   out.title=!!title&&/極厚鉄板/.test(title.textContent||'')&&/大/.test(title.textContent||'');
   if(!out.title){out.reason='title-mismatch';return done();}
   const root=title.closest('main,[role=main],#main,.item-detail,.product-detail')||document.body;
   const txt=e=>String(e&&(e.innerText||e.textContent)||'').trim();
   const full=txt(root);
   out.selected=/選択されたサイズ[：:]\\s*本体\\s*[＆&+]\\s*蓋\\s*[(（]大[)）]/.test(full);
   if(!out.selected){out.reason='variant-not-selected';return done();}
   const usable=e=>{
     if(!e||e.disabled||e.hasAttribute('disabled')||e.getAttribute('aria-disabled')==='true')return false;
     for(let n=e;n;n=n.parentElement){
       if(n.hidden||n.hasAttribute('inert')||n.getAttribute('aria-hidden')==='true')return false;
       const s=getComputedStyle(n);if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0)return false;
     }return true;
   };
   const selector='button,input[type=submit],input[type=image],input[type=button],[role=button],a[href],[onclick]';
   const forms=[...root.querySelectorAll('form')];out.forms=forms.length;
   const quantities=[...root.querySelectorAll('input[type=number],input[name*=quantity],input[name*=qty],input[name*=amount],select[name*=quantity]')].filter(usable);
   out.qty=quantities.length;
   const candidates=[...root.querySelectorAll(selector)].filter(c=>!c.closest('header,footer,nav,aside,[class*=related],[class*=recommend]'));
   for(const c of candidates){
     const label=[txt(c),c.value,c.getAttribute('alt'),c.getAttribute('title'),c.getAttribute('aria-label')].filter(Boolean).join(' ');
     const action=[c.name,c.id,c.getAttribute('onclick'),c.getAttribute('data-action'),c.getAttribute('src')].filter(Boolean).join(' ');
     if(!/(カートに入れる|買い物かごに入れる|購入する|add.?to.?cart)/i.test(label)
        &&!/(add.?cart|cart.?add|cartin)/i.test(action))continue;
     if(c.querySelector('button,input,[onclick]')&&!c.matches('button,input,a'))continue;
     out.cart++;
     const panel=c.closest('form,.purchase,.cart,.item-detail,.product-detail')||c.parentElement;
     if(!panel||!root.contains(panel))continue;
     const notices=panel.querySelectorAll('[class*=sold],[class*=out-of-stock],[class*=stock],[id*=sold]');
     let negative=false;
     for(const n of notices){if(usable(n)&&/(売り切れ|在庫切れ|販売終了|完売)/.test(txt(n)))negative=true;}
     if(negative){out.negative=true;continue;}
     const required=panel.querySelectorAll('select[required]');let ready=true;
     for(const s of required){if(!s.value||s.selectedIndex<0)ready=false;}
     if(ready&&usable(c))out.enabled++;
   }
   if(out.negative){out.reason='sold-out';return done();}
   if(out.cart===1&&out.enabled===1){out.status='AVAILABLE';out.reason='selected-variant-purchase';return done();}
   out.reason=out.cart===0?'purchase-element-missing':'purchase-unready';return done();
 }catch(e){out.reason='dom-error';return done();}
})()
""";
    }
}
