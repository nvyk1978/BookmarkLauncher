package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceResponse;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;

import org.json.JSONTokener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One-shot hidden WebView used to refresh bookmark metadata, favicon and a 1:1 top-page thumbnail.
 * The WebView is attached off-screen so it still has a real layout/draw pass.
 */
public final class BookmarkCaptureManager {
    public interface Listener {
        void onComplete(boolean success, BookmarkNode updatedNode, String message);
    }

    private final Activity activity;
    private final FrameLayout host;
    private final BookmarkRepository repo;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private WebView webView;
    private Bitmap receivedIcon;
    private String activeNodeId;
    private Runnable pendingFinish;
    private int finishAttempts;
    private boolean mainFrameError;
    private String mainFrameErrorUrl;
    private long captureGeneration;
    private String preparedGoogleMapsUrl;
    private String preparedGoogleMapsThumbnailPath;
    private String preparedGoogleMapsPlaceName;
    private String preparedGoogleMapsAddress;
    private boolean resolvedMapGenerationAttempted;
    private boolean mapCanonicalProbeAttempted;
    private boolean mapPageProbeAttempted;

    public BookmarkCaptureManager(Activity activity, FrameLayout host, BookmarkRepository repo) {
        this.activity = activity;
        this.host = host;
        this.repo = repo;
    }

    public void capture(BookmarkNode node, Listener listener) {
        if (node == null || node.url == null || node.url.isBlank()) {
            if (listener != null) listener.onComplete(false, node, "URLがありません");
            return;
        }
        host.post(() -> beginCapture(node, listener));
    }

    public void destroy() {
        captureGeneration++;
        cancelActive();
        io.shutdownNow();
    }

    private void beginCapture(BookmarkNode node, Listener listener) {
        cancelActive();
        final long generation = ++captureGeneration;
        activeNodeId = node.id;

        if (!GoogleMapsLink.isGoogleMapsUrl(node.url)) {
            startCapture(node.id, node.url, node.url, listener);
            return;
        }

        // Resolve Maps share links before WebView navigation. This avoids the common
        // maps.app.goo.gl -> intent:// handoff that hidden WebViews cannot render.
        io.execute(() -> {
            String expanded = expandGoogleMapsUrl(node.url);
            if (expanded == null || expanded.isBlank()) expanded = node.url;
            String placeName = GoogleMapsLink.extractPlaceName(expanded);
            GoogleMapsLink.Coordinates coordinates = GoogleMapsLink.extractExplicitPoiCoordinates(expanded);
            if (coordinates != null) {
                DiagLog.write(activity, "MAP_COORDINATES_EXPANDED_POI lat=" + coordinates.latitude + " lng=" + coordinates.longitude);
            } else {
                DiagLog.write(activity, "MAP_COORDINATES_EXPANDED_POI none");
            }

            String thumbnailPath = null;
            if (coordinates != null) {
                try {
                    File assets = new File(activity.getFilesDir(), "bookmark_assets");
                    if ((assets.exists() || assets.mkdirs())) {
                        File target = new File(assets, node.id + "_thumb.jpg");
                        if (StaticMapThumbnail.generate(coordinates.latitude, coordinates.longitude, target)) {
                            thumbnailPath = target.getAbsolutePath();
                        }
                    }
                } catch (Throwable ignored) {
                }
            }

            final String finalExpanded = expanded;
            final String finalPlaceName = placeName;
            final String finalThumbnailPath = thumbnailPath;
            final boolean finalMapGenerationAttempted = coordinates != null;
            main.post(() -> {
                if (generation != captureGeneration || !node.id.equals(activeNodeId)) return;
                preparedGoogleMapsUrl = finalExpanded;
                preparedGoogleMapsPlaceName = finalPlaceName;
                preparedGoogleMapsThumbnailPath = finalThumbnailPath;
                resolvedMapGenerationAttempted = finalMapGenerationAttempted;
                startCapture(node.id, node.url, finalExpanded, listener);
            });
        });
    }

    private void startCapture(String nodeId, String originalUrl, String loadUrl, Listener listener) {
        activeNodeId = nodeId;
        receivedIcon = null;
        finishAttempts = 0;
        mainFrameError = false;
        mainFrameErrorUrl = null;

        WebView w = new WebView(activity);
        webView = w;
        // Keep the capture WebView fully off-screen/transparent while still laid out and drawable.
        // Direct webView.draw(canvas) below still captures its contents without flashing its
        // default background behind the N dialog/home UI.
        w.setBackgroundColor(Color.TRANSPARENT);
        w.setAlpha(0f);
        w.setVerticalScrollBarEnabled(false);
        w.setHorizontalScrollBarEnabled(false);
        WebSettings settings = w.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        int screenWidth = Math.max(1, activity.getResources().getDisplayMetrics().widthPixels);
        int renderWidth = Math.min(1080, Math.max(720, screenWidth));
        int renderHeight = Math.max(renderWidth * 2, 1280);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(renderWidth, renderHeight);
        lp.leftMargin = -renderWidth - 64;
        lp.topMargin = 0;
        host.addView(w, lp);

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onReceivedIcon(WebView view, Bitmap icon) {
                if (!nodeId.equals(activeNodeId) || icon == null) return;
                receivedIcon = icon.copy(Bitmap.Config.ARGB_8888, false);
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String startedUrl, Bitmap favicon) {
                if (!nodeId.equals(activeNodeId)) return;
                // A later redirect may recover from an error on an earlier URL. A genuine error
                // on the currently loading main frame will set these again in onReceivedError.
                if (!isInternalErrorUrl(startedUrl)) {
                    mainFrameError = false;
                    mainFrameErrorUrl = null;
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request == null || request.getUrl() == null || !request.isForMainFrame()) return false;
                String next = request.getUrl().toString();
                String scheme = request.getUrl().getScheme();
                if (scheme == null || "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) return false;

                // Google Maps share links can hand browsers an intent:// URL. A hidden WebView
                // cannot launch it as a page and would otherwise render Chrome's error screen.
                if ("intent".equalsIgnoreCase(scheme)) {
                    String webFallback = webFallbackFromIntent(next);
                    if (webFallback != null) {
                        view.loadUrl(webFallback);
                    } else {
                        mainFrameError = true;
                        mainFrameErrorUrl = null;
                        scheduleFinish(nodeId, originalUrl, listener, 250L);
                    }
                    return true;
                }
                // Do not let unsupported schemes become a captured WebView error page.
                mainFrameError = true;
                mainFrameErrorUrl = null;
                scheduleFinish(nodeId, originalUrl, listener, 250L);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String loadedUrl) {
                if (!nodeId.equals(activeNodeId)) return;
                scheduleFinish(nodeId, originalUrl, listener, GoogleMapsLink.isGoogleMapsUrl(originalUrl) ? 1800L : 850L);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame() && nodeId.equals(activeNodeId)) {
                    mainFrameError = true;
                    mainFrameErrorUrl = request.getUrl() == null ? null : request.getUrl().toString();
                    scheduleFinish(nodeId, originalUrl, listener, 700L);
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                if (request != null && request.isForMainFrame() && errorResponse != null
                        && errorResponse.getStatusCode() >= 400 && nodeId.equals(activeNodeId)) {
                    mainFrameError = true;
                    mainFrameErrorUrl = request.getUrl() == null ? null : request.getUrl().toString();
                }
            }
        });

        w.loadUrl(loadUrl == null || loadUrl.isBlank() ? originalUrl : loadUrl);
    }

    private void scheduleFinish(String nodeId, String originalUrl, Listener listener, long delayMs) {
        if (pendingFinish != null) main.removeCallbacks(pendingFinish);
        pendingFinish = () -> finishCapture(nodeId, originalUrl, listener);
        main.postDelayed(pendingFinish, delayMs);
    }

    private void finishCapture(String nodeId, String originalUrl, Listener listener) {
        WebView w = webView;
        if (w == null || !nodeId.equals(activeNodeId)) return;
        if (w.getProgress() < 100 && finishAttempts++ < 3) {
            scheduleFinish(nodeId, originalUrl, listener, 500L);
            return;
        }

        w.scrollTo(0, 0);
        String resolvedUrl = w.getUrl() == null ? originalUrl : w.getUrl();
        boolean googleMaps = GoogleMapsLink.isGoogleMapsUrl(originalUrl) || GoogleMapsLink.isGoogleMapsUrl(resolvedUrl);

        // For Google Maps, first obtain the rendered place name + postal address.
        // The address is forward-geocoded and is the primary source for the map center.
        // Only an explicit !8m2!3d..!4d POI pair is allowed as a fallback; camera/viewport
        // coordinates (@lat,lng / generic !3d..!4d) are never used for static maps.
        if (googleMaps && !mapPageProbeAttempted) {
            mapPageProbeAttempted = true;
            probeGoogleMapsPage(w, nodeId, originalUrl, resolvedUrl, listener);
            return;
        }

        if (shouldRejectScreenshot(w, resolvedUrl)) {
            finishWithoutScreenshot(nodeId, originalUrl, resolvedUrl, googleMaps, listener);
            return;
        }

        resolvePageTitle(w, nodeId, googleMaps, resolvedUrl, resolvedTitle ->
                finishMetadataCapture(w, nodeId, originalUrl, resolvedUrl, googleMaps, resolvedTitle, listener));
    }

    private void probeGoogleMapsPage(WebView w, String nodeId, String originalUrl, String resolvedUrl, Listener listener) {
        String script = "(function(){" +
                "var n=[],a=[],u=[];var ns={},as={},us={};" +
                "function add(arr,seen,v){v=(v||'').trim();if(v&&!seen[v]){seen[v]=1;arr.push(v);}}" +
                "var nsel=['h1.DUwDvf','main h1','[role=\\\"main\\\"] h1','h1','meta[itemprop=\\\"name\\\"]'];" +
                "for(var i=0;i<nsel.length;i++){var e=document.querySelector(nsel[i]);if(e)add(n,ns,e.content||e.textContent||e.getAttribute('aria-label')||'');}" +
                "var og=document.querySelector('meta[property=\\\"og:title\\\"]');if(og)add(n,ns,og.content);" +
                "var tw=document.querySelector('meta[name=\\\"twitter:title\\\"]');if(tw)add(n,ns,tw.content);" +
                "add(n,ns,document.title||'');" +
                "var asel=['button[data-item-id=\\\"address\\\"]','[data-item-id=\\\"address\\\"]','[aria-label^=\\\"住所:\\\"]','[aria-label^=\\\"住所：\\\"]','[aria-label^=\\\"Address:\\\"]','meta[itemprop=\\\"address\\\"]'];" +
                "for(var j=0;j<asel.length;j++){var x=document.querySelector(asel[j]);if(x){add(a,as,x.getAttribute('aria-label')||'');add(a,as,x.content||x.textContent||'');}}" +
                "add(a,as,document.title||'');" +
                "var c=document.querySelector('link[rel=\\\"canonical\\\"]');if(c)add(u,us,c.href);" +
                "var ou=document.querySelector('meta[property=\\\"og:url\\\"]');if(ou)add(u,us,ou.content);" +
                "add(u,us,location.href||'');" +
                "return n.join('<<<BLMAP>>>')+'<<<BLSECTION>>>'+a.join('<<<BLADDR>>>')+'<<<BLSECTION>>>'+u.join('<<<BLURL>>>');})()";
        w.evaluateJavascript(script, value -> {
            if (!nodeId.equals(activeNodeId) || webView == null) return;
            String packed = cleanJs(value);
            String[] sections = packed == null ? new String[0] : packed.split(java.util.regex.Pattern.quote("<<<BLSECTION>>>"), -1);
            String name = sections.length > 0 ? firstUsefulMapsTitle(sections[0]) : null;
            String address = sections.length > 1 ? firstUsefulMapsAddress(sections[1]) : null;
            String urlPack = sections.length > 2 ? sections[2] : null;

            if (name == null) name = GoogleMapsLink.extractPlaceName(resolvedUrl);
            if (name == null) name = GoogleMapsLink.extractPlaceName(preparedGoogleMapsUrl);
            if (address == null) address = GoogleMapsLink.extractAddressCandidate(w.getTitle());

            preparedGoogleMapsPlaceName = name;
            preparedGoogleMapsAddress = address;
            String poiUrl = firstMapsUrlWithExplicitPoi(urlPack);
            if (poiUrl != null) preparedGoogleMapsUrl = poiUrl;

            final String addressForGeocode = address;
            final GoogleMapsLink.Coordinates explicitPoi = firstExplicitPoiCoordinates(urlPack, resolvedUrl, preparedGoogleMapsUrl);
            DiagLog.write(activity, "MAP_PAGE_METADATA name=" + safeLog(name) + " address=" + safeLog(address));

            io.execute(() -> {
                GoogleMapsLink.Coordinates coordinates = null;
                String source = "none";
                if (addressForGeocode != null) {
                    coordinates = geocodeAddress(addressForGeocode);
                    if (coordinates != null) source = "geocoder";
                }
                if (coordinates == null && explicitPoi != null) {
                    coordinates = explicitPoi;
                    source = "explicit_poi";
                }

                String path = null;
                if (coordinates != null) {
                    DiagLog.write(activity, "MAP_COORDINATES_FINAL source=" + source + " lat=" + coordinates.latitude + " lng=" + coordinates.longitude);
                    try {
                        File assets = new File(activity.getFilesDir(), "bookmark_assets");
                        if (assets.exists() || assets.mkdirs()) {
                            File target = new File(assets, nodeId + "_thumb.jpg");
                            if (StaticMapThumbnail.generate(coordinates.latitude, coordinates.longitude, target)) path = target.getAbsolutePath();
                        }
                    } catch (Throwable ignored) {
                    }
                } else {
                    DiagLog.write(activity, "MAP_COORDINATES_FINAL none");
                }

                final String generatedPath = path;
                main.post(() -> {
                    if (!nodeId.equals(activeNodeId) || webView == null) return;
                    if (generatedPath != null) preparedGoogleMapsThumbnailPath = generatedPath;
                    resolvedMapGenerationAttempted = true;
                    finishCapture(nodeId, originalUrl, listener);
                });
            });
        });
    }

    private GoogleMapsLink.Coordinates geocodeAddress(String rawAddress) {
        if (rawAddress == null || rawAddress.isBlank()) return null;
        String query = rawAddress.replaceAll("\\s*[0-9０-９]+\\s*(?:階|[FＦ])\\s*$", "").trim();
        if (query.isBlank() || !Geocoder.isPresent()) return null;
        try {
            Geocoder geocoder = new Geocoder(activity, Locale.JAPAN);
            List<Address> results = geocoder.getFromLocationName(query, 3);
            if (results == null) return null;
            for (Address result : results) {
                if (result == null || !result.hasLatitude() || !result.hasLongitude()) continue;
                GoogleMapsLink.Coordinates coordinates = new GoogleMapsLink.Coordinates(result.getLatitude(), result.getLongitude());
                if (coordinates.isValid()) return coordinates;
            }
        } catch (Throwable t) {
            DiagLog.write(activity, "MAP_GEOCODER_ERROR " + t.getClass().getSimpleName());
        }
        return null;
    }

    private static String firstUsefulMapsAddress(String packedCandidates) {
        if (packedCandidates == null || packedCandidates.isBlank()) return null;
        String[] candidates = packedCandidates.split(java.util.regex.Pattern.quote("<<<BLADDR>>>"));
        for (String candidate : candidates) {
            String address = GoogleMapsLink.extractAddressCandidate(candidate);
            if (address != null) return address;
        }
        return null;
    }

    private static String firstMapsUrlWithExplicitPoi(String packedCandidates) {
        if (packedCandidates == null || packedCandidates.isBlank()) return null;
        String[] candidates = packedCandidates.split(java.util.regex.Pattern.quote("<<<BLURL>>>"));
        for (String candidate : candidates) {
            if (GoogleMapsLink.extractExplicitPoiCoordinates(candidate) != null) return candidate;
        }
        return null;
    }

    private static GoogleMapsLink.Coordinates firstExplicitPoiCoordinates(String packedCandidates, String... fallbacks) {
        if (packedCandidates != null && !packedCandidates.isBlank()) {
            String[] candidates = packedCandidates.split(java.util.regex.Pattern.quote("<<<BLURL>>>"));
            for (String candidate : candidates) {
                GoogleMapsLink.Coordinates c = GoogleMapsLink.extractExplicitPoiCoordinates(candidate);
                if (c != null) return c;
            }
        }
        if (fallbacks != null) {
            for (String candidate : fallbacks) {
                GoogleMapsLink.Coordinates c = GoogleMapsLink.extractExplicitPoiCoordinates(candidate);
                if (c != null) return c;
            }
        }
        return null;
    }

    private static String safeLog(String value) {
        if (value == null) return "<none>";
        String s = value.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() > 120 ? s.substring(0, 120) : s;
    }

    private interface TitleCallback {
        void onResolved(String title);
    }

    private void resolvePageTitle(WebView w, String nodeId, boolean googleMaps, String resolvedUrl, TitleCallback callback) {
        String normalTitle = clean(w.getTitle());
        if (!googleMaps) {
            callback.onResolved(normalTitle);
            return;
        }

        // Expanded Google Maps links normally contain /place/<name>/. This is the most stable
        // source because Maps' DOM class names change frequently.
        String fromPrepared = GoogleMapsLink.cleanPlaceName(preparedGoogleMapsPlaceName);
        String fromUrl = GoogleMapsLink.extractPlaceName(resolvedUrl);
        if (fromUrl == null) fromUrl = GoogleMapsLink.extractPlaceName(preparedGoogleMapsUrl);
        String fromWindowTitle = GoogleMapsLink.cleanPlaceName(normalTitle);
        BookmarkNode existing = repo.get(nodeId);
        String fromSharedTitle = existing == null ? null : GoogleMapsLink.cleanPlaceName(existing.title);
        final String stableUrlTitle = fromPrepared != null ? fromPrepared : fromUrl;
        final String fallback = stableUrlTitle != null ? stableUrlTitle : (fromWindowTitle != null ? fromWindowTitle : fromSharedTitle);

        // Ask the rendered Maps page for several independent name candidates. Do not stop at
        // the first h1: some mobile layouts use an address as h1 while og:title/document.title
        // still contain the shop name. Java validates each candidate and skips address-only text.
        String mapTitleScript = "(function(){" +
                "var a=[];var seen={};" +
                "function add(v){v=(v||'').trim();if(v&&!seen[v]){seen[v]=1;a.push(v);}}" +
                "var s=['h1.DUwDvf','main h1','[role=\"main\"] h1','h1','meta[itemprop=\"name\"]'];" +
                "for(var i=0;i<s.length;i++){var e=document.querySelector(s[i]);if(e)add(e.content||e.textContent||'');}" +
                "var o=document.querySelector('meta[property=\"og:title\"]');if(o)add(o.content);" +
                "var t=document.querySelector('meta[name=\"twitter:title\"]');if(t)add(t.content);" +
                "add(document.title||'');return a.join('<<<BLMAP>>>');})()";
        w.evaluateJavascript(mapTitleScript, value -> {
            if (!nodeId.equals(activeNodeId) || webView == null) return;
            String fromDom = firstUsefulMapsTitle(cleanJs(value));
            callback.onResolved(fromDom != null ? fromDom : (stableUrlTitle != null ? stableUrlTitle : fallback));
        });
    }

    private static String firstUsefulMapsTitle(String packedCandidates) {
        if (packedCandidates == null || packedCandidates.isBlank()) return null;
        String[] candidates = packedCandidates.split(java.util.regex.Pattern.quote("<<<BLMAP>>>"));
        for (String candidate : candidates) {
            String cleaned = GoogleMapsLink.cleanPlaceName(candidate);
            if (cleaned != null) return cleaned;
        }
        return null;
    }

    private static String firstMapsUrlWithPreciseCoordinates(String packedCandidates) {
        if (packedCandidates == null || packedCandidates.isBlank()) return null;
        String[] candidates = packedCandidates.split(java.util.regex.Pattern.quote("<<<BLMAPURL>>>"));
        for (String candidate : candidates) {
            if (GoogleMapsLink.extractPreciseCoordinates(candidate) != null) return candidate;
        }
        return null;
    }

    private void finishMetadataCapture(WebView w, String nodeId, String originalUrl, String resolvedUrl,
                                       boolean googleMaps, String pageTitle, Listener listener) {
        if (!nodeId.equals(activeNodeId) || webView == null) return;

        String siteScript = "(function(){" +
                "var a=['meta[property=\\\"og:site_name\\\"]','meta[name=\\\"application-name\\\"]','meta[name=\\\"apple-mobile-web-app-title\\\"]'];" +
                "for(var i=0;i<a.length;i++){var e=document.querySelector(a[i]);if(e&&e.content)return e.content;}return '';})()";
        String iconScript = "(function(){var e=document.querySelector('link[rel~=\\\"icon\\\"]');return e&&e.href?e.href:'';})()";

        w.evaluateJavascript(siteScript, siteValue -> {
            if (!nodeId.equals(activeNodeId) || webView == null) return;
            String siteName = googleMaps ? "Google Maps" : cleanJs(siteValue);
            if (siteName == null || siteName.isBlank()) siteName = fallbackSiteName(resolvedUrl);
            final String finalSiteName = siteName;

            w.evaluateJavascript(iconScript, iconValue -> {
                if (!nodeId.equals(activeNodeId) || webView == null) return;
                String iconUrl = cleanJs(iconValue);
                try {
                    File assets = new File(activity.getFilesDir(), "bookmark_assets");
                    if (!assets.exists() && !assets.mkdirs()) throw new IllegalStateException("asset directory");

                    String screenshotPath = googleMaps ? validPreparedMapPath(nodeId) : null;
                    if (screenshotPath == null) {
                        if (shouldRejectScreenshot(w, w.getUrl() == null ? resolvedUrl : w.getUrl())) {
                            finishWithoutScreenshot(nodeId, originalUrl, resolvedUrl, googleMaps, listener);
                            return;
                        }
                        File screenshot = new File(assets, nodeId + "_thumb.jpg");
                        saveSquareScreenshot(w, screenshot);
                        screenshotPath = screenshot.getAbsolutePath();
                    }

                    // Google Maps always uses BookmarkLauncher's N-light-red vector pin, never Google's favicon.
                    String faviconPath = null;
                    if (!googleMaps && receivedIcon != null) {
                        File favicon = new File(assets, nodeId + "_favicon.png");
                        saveBitmap(receivedIcon, favicon, Bitmap.CompressFormat.PNG, 100);
                        faviconPath = favicon.getAbsolutePath();
                    }

                    if (googleMaps) repo.updateGoogleMapsMetadata(nodeId, pageTitle, screenshotPath);
                    else repo.updateWebMetadata(nodeId, finalSiteName, pageTitle, faviconPath, screenshotPath);
                    BookmarkNode updated = repo.get(nodeId);
                    if (listener != null) listener.onComplete(true, updated, null);

                    if (!googleMaps && faviconPath == null) {
                        String candidate = iconUrl;
                        if (candidate == null || candidate.isBlank()) candidate = defaultFaviconUrl(resolvedUrl == null ? originalUrl : resolvedUrl);
                        fetchFaviconAsync(nodeId, candidate, assets, listener);
                    }
                } catch (Exception e) {
                    BookmarkNode updated = repo.get(nodeId);
                    if (listener != null) listener.onComplete(false, updated, "サムネイル取得に失敗しました");
                } finally {
                    clearWebView(nodeId);
                }
            });
        });
    }

    private void finishWithoutScreenshot(String nodeId, String originalUrl, String resolvedUrl,
                                         boolean googleMaps, Listener listener) {
        if (!nodeId.equals(activeNodeId)) return;
        BookmarkNode existing = repo.get(nodeId);
        String pageTitle = null;
        if (googleMaps) {
            pageTitle = GoogleMapsLink.cleanPlaceName(preparedGoogleMapsPlaceName);
            if (pageTitle == null) pageTitle = GoogleMapsLink.extractPlaceName(preparedGoogleMapsUrl);
            if (pageTitle == null) pageTitle = GoogleMapsLink.extractPlaceName(resolvedUrl);
            if (pageTitle == null) pageTitle = GoogleMapsLink.extractPlaceName(originalUrl);
            if (pageTitle == null && existing != null) pageTitle = GoogleMapsLink.cleanPlaceName(existing.title);
        }
        String siteName = googleMaps ? "Google Maps" : fallbackSiteName(resolvedUrl == null ? originalUrl : resolvedUrl);
        String staticMapPath = googleMaps ? validPreparedMapPath(nodeId) : null;
        if (googleMaps) repo.updateGoogleMapsMetadata(nodeId, pageTitle, staticMapPath);
        else repo.updateWebMetadata(nodeId, siteName, pageTitle, null, staticMapPath);
        BookmarkNode updated = repo.get(nodeId);
        if (listener != null) {
            if (staticMapPath != null) listener.onComplete(true, updated, null);
            else listener.onComplete(false, updated, "ページを表示できなかったためサムネイルは更新しませんでした");
        }
        clearWebView(nodeId);
    }

    private String validPreparedMapPath(String nodeId) {
        if (nodeId == null || !nodeId.equals(activeNodeId)) return null;
        if (preparedGoogleMapsThumbnailPath == null || preparedGoogleMapsThumbnailPath.isBlank()) return null;
        File file = new File(preparedGoogleMapsThumbnailPath);
        return file.isFile() && file.length() > 0 ? file.getAbsolutePath() : null;
    }

    private boolean shouldRejectScreenshot(WebView view, String resolvedUrl) {
        if (isInternalErrorUrl(resolvedUrl)) return true;
        String title = view == null ? null : clean(view.getTitle());
        if (GoogleMapsLink.isWebErrorTitle(title)) return true;
        if (!mainFrameError) return false;
        if (mainFrameErrorUrl == null || mainFrameErrorUrl.isBlank()) return true;
        return sameUrlIgnoringFragment(mainFrameErrorUrl, resolvedUrl);
    }

    private static boolean isInternalErrorUrl(String value) {
        if (value == null) return false;
        String lower = value.trim().toLowerCase(java.util.Locale.ROOT);
        return lower.startsWith("chrome-error://") || lower.startsWith("about:neterror");
    }

    private static boolean sameUrlIgnoringFragment(String a, String b) {
        if (a == null || b == null) return false;
        int ai = a.indexOf('#');
        int bi = b.indexOf('#');
        String aa = ai >= 0 ? a.substring(0, ai) : a;
        String bb = bi >= 0 ? b.substring(0, bi) : b;
        return aa.equals(bb);
    }

    private static String webFallbackFromIntent(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            Intent intent = Intent.parseUri(value, Intent.URI_INTENT_SCHEME);
            String fallback = intent.getStringExtra("browser_fallback_url");
            if (isHttpUrl(fallback)) return fallback;
            Uri data = intent.getData();
            if (data != null && isHttpUrl(data.toString())) return data.toString();
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static boolean isHttpUrl(String value) {
        if (value == null) return false;
        String lower = value.toLowerCase(java.util.Locale.ROOT);
        return lower.startsWith("https://") || lower.startsWith("http://");
    }

    private static String expandGoogleMapsUrl(String value) {
        if (value == null || value.isBlank()) return value;
        String current = value.trim();
        for (int hop = 0; hop < 10; hop++) {
            if (!isHttpUrl(current)) break;
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(current).openConnection();
                connection.setConnectTimeout(7000);
                connection.setReadTimeout(7000);
                connection.setInstanceFollowRedirects(false);
                connection.setRequestMethod("GET");
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36");
                connection.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en;q=0.7");
                int code = connection.getResponseCode();

                if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    String location = connection.getHeaderField("Location");
                    if (location == null || location.isBlank()) break;
                    if (location.startsWith("intent://")) {
                        String fallback = webFallbackFromIntent(location);
                        if (fallback == null) break;
                        current = fallback;
                    } else {
                        current = new URL(new URL(current), location).toExternalForm();
                    }
                    continue;
                }

                // A few Google redirect pages return HTTP 200 and perform the last handoff in HTML.
                // Read only a small prefix and recover a concrete google.com/maps URL when present.
                if (code >= 200 && code < 300 && GoogleMapsLink.isShortGoogleMapsUrl(current)) {
                    String fromHtml = extractMapsUrlFromHtml(readSmallBody(connection, 160 * 1024));
                    if (fromHtml != null && !fromHtml.equals(current)) {
                        current = fromHtml;
                        continue;
                    }
                }
                return current;
            } catch (Exception ignored) {
                return current;
            } finally {
                if (connection != null) connection.disconnect();
            }
        }
        return current;
    }

    private static String readSmallBody(HttpURLConnection connection, int maxBytes) {
        try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int remaining = maxBytes;
            while (remaining > 0) {
                int read = in.read(buffer, 0, Math.min(buffer.length, remaining));
                if (read < 0) break;
                out.write(buffer, 0, read);
                remaining -= read;
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String extractMapsUrlFromHtml(String html) {
        if (html == null || html.isBlank()) return null;
        String normalized = html
                .replace("&amp;", "&")
                .replace("\\u003d", "=")
                .replace("\\u0026", "&")
                .replace("\\/", "/");
        Pattern pattern = Pattern.compile("https://(?:www\\.)?google\\.[A-Za-z.]+/maps[^\"'<>\\s]+", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(normalized);
        while (matcher.find()) {
            String candidate = matcher.group();
            if (GoogleMapsLink.isGoogleMapsUrl(candidate)) return candidate;
        }
        return null;
    }

    private void fetchFaviconAsync(String nodeId, String iconUrl, File assets, Listener listener) {
        if (iconUrl == null || iconUrl.isBlank()) return;
        io.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(iconUrl).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 Android BookmarkLauncher");
                if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 400) return;
                Bitmap bitmap = android.graphics.BitmapFactory.decodeStream(connection.getInputStream());
                if (bitmap == null) return;
                File favicon = new File(assets, nodeId + "_favicon.png");
                saveBitmap(bitmap, favicon, Bitmap.CompressFormat.PNG, 100);
                repo.updateFaviconPath(nodeId, favicon.getAbsolutePath());
                activity.runOnUiThread(() -> {
                    if (listener != null) listener.onComplete(true, repo.get(nodeId), null);
                });
            } catch (Exception ignored) {
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private static void saveSquareScreenshot(WebView webView, File target) throws Exception {
        int side = Math.max(1, Math.min(webView.getWidth(), webView.getHeight()));
        Bitmap bitmap = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
        webView.draw(canvas);
        saveBitmap(bitmap, target, Bitmap.CompressFormat.JPEG, 90);
        bitmap.recycle();
    }

    private static void saveBitmap(Bitmap bitmap, File file, Bitmap.CompressFormat format, int quality) throws Exception {
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            if (!bitmap.compress(format, quality, out)) throw new IllegalStateException("compress failed");
            out.flush();
        }
    }

    private void cancelActive() {
        if (pendingFinish != null) {
            main.removeCallbacks(pendingFinish);
            pendingFinish = null;
        }
        if (webView != null) {
            try {
                webView.stopLoading();
                host.removeView(webView);
                webView.destroy();
            } catch (Exception ignored) {
            }
            webView = null;
        }
        receivedIcon = null;
        mainFrameError = false;
        mainFrameErrorUrl = null;
        preparedGoogleMapsUrl = null;
        preparedGoogleMapsThumbnailPath = null;
        preparedGoogleMapsPlaceName = null;
        preparedGoogleMapsAddress = null;
        resolvedMapGenerationAttempted = false;
        mapCanonicalProbeAttempted = false;
        mapPageProbeAttempted = false;
        activeNodeId = null;
    }

    private void clearWebView(String nodeId) {
        if (!nodeId.equals(activeNodeId)) return;
        if (webView != null) {
            WebView old = webView;
            webView = null;
            host.removeView(old);
            old.destroy();
        }
        pendingFinish = null;
        receivedIcon = null;
        mainFrameError = false;
        mainFrameErrorUrl = null;
        preparedGoogleMapsUrl = null;
        preparedGoogleMapsThumbnailPath = null;
        preparedGoogleMapsPlaceName = null;
        preparedGoogleMapsAddress = null;
        resolvedMapGenerationAttempted = false;
        mapCanonicalProbeAttempted = false;
        mapPageProbeAttempted = false;
        activeNodeId = null;
    }

    private static String clean(String value) {
        if (value == null) return null;
        String v = value.trim();
        return v.isEmpty() ? null : v;
    }

    private static String cleanJs(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            Object parsed = new JSONTokener(value).nextValue();
            if (parsed == null) return null;
            return clean(String.valueOf(parsed));
        } catch (Exception ignored) {
            return clean(value.replace("\\\"", "\"").replaceAll("^\"|\"$", ""));
        }
    }

    private static String fallbackSiteName(String url) {
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            if (host == null || host.isBlank()) return "ブックマーク";
            if (host.startsWith("www.")) host = host.substring(4);
            String[] parts = host.split("\\.");
            String base = parts.length == 0 ? host : parts[0];
            if (base.isBlank()) return host;
            return Character.toUpperCase(base.charAt(0)) + base.substring(1);
        } catch (Exception ignored) {
            return "ブックマーク";
        }
    }

    private static String defaultFaviconUrl(String url) {
        try {
            Uri uri = Uri.parse(url);
            if (uri.getScheme() == null || uri.getHost() == null) return null;
            return uri.getScheme() + "://" + uri.getHost() + "/favicon.ico";
        } catch (Exception ignored) {
            return null;
        }
    }
}
