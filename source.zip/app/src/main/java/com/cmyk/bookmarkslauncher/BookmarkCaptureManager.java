package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.widget.FrameLayout;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;
import com.cmyk.bookmarkslauncher.googlemaps.GoogleMapsModule;

/**
 * Capture dispatcher.
 *
 * Google Maps is intentionally isolated behind GoogleMapsModule. Normal bookmark
 * capture contains no Maps parsing/geocoding/static-map code, so future changes to
 * ordinary bookmarks cannot accidentally alter the Maps behavior and vice versa.
 */
public final class BookmarkCaptureManager {
    public interface Listener {
        void onComplete(boolean success, BookmarkNode updatedNode, String message);
    }

    private final WebBookmarkCaptureManager webCapture;
    private final GoogleMapsModule.CaptureController mapsCapture;

    public BookmarkCaptureManager(Activity activity, FrameLayout host, BookmarkRepository repo) {
        webCapture = new WebBookmarkCaptureManager(activity, host, repo);
        mapsCapture = GoogleMapsModule.createCaptureController(activity, host, repo);
    }

    public void capture(BookmarkNode node, Listener listener) {
        if (node == null || node.url == null || node.url.isBlank()) {
            if (listener != null) listener.onComplete(false, node, "URLがありません");
            return;
        }

        if (GoogleMapsModule.handles(node.url)) {
            webCapture.cancel();
            mapsCapture.capture(node, listener == null ? null : listener::onComplete);
        } else {
            mapsCapture.cancel();
            webCapture.capture(node, listener == null ? null : listener::onComplete);
        }
    }

    public void destroy() {
        webCapture.destroy();
        mapsCapture.destroy();
    }
}
