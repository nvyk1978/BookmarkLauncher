package com.cmyk.bookmarkslauncher;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;
import com.cmyk.bookmarkslauncher.data.BookmarkRepository;

import org.json.JSONTokener;

import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One-shot hidden WebView used to refresh bookmark metadata, favicon and a 1:1 top-page thumbnail.
 * The WebView is attached off-screen so it still has a real layout/draw pass.
 */
public final class BookmarkCaptureManager {
    public interface Listener {
        void onComplete(boolean success, BookmarkNode updatedNode, String message);
    }

    private final Activity activity;
    private final FrameLayout host;
    private final BookmarkRepository repo;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private WebView webView;
    private Bitmap receivedIcon;
    private String activeNodeId;
    private Runnable pendingFinish;
    private int finishAttempts;

    public BookmarkCaptureManager(Activity activity, FrameLayout host, BookmarkRepository repo) {
        this.activity = activity;
        this.host = host;
        this.repo = repo;
    }

    public void capture(BookmarkNode node, Listener listener) {
        if (node == null || node.url == null || node.url.isBlank()) {
            if (listener != null) listener.onComplete(false, node, "URLがありません");
            return;
        }
        host.post(() -> startCapture(node.id, node.url, listener));
    }

    public void destroy() {
        cancelActive();
        io.shutdownNow();
    }

    private void startCapture(String nodeId, String url, Listener listener) {
        cancelActive();
        activeNodeId = nodeId;
        receivedIcon = null;
        finishAttempts = 0;

        WebView w = new WebView(activity);
        webView = w;
        w.setBackgroundColor(Color.WHITE);
        w.setVerticalScrollBarEnabled(false);
        w.setHorizontalScrollBarEnabled(false);
        WebSettings settings = w.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        int screenWidth = Math.max(1, activity.getResources().getDisplayMetrics().widthPixels);
        int renderWidth = Math.min(1080, Math.max(720, screenWidth));
        int renderHeight = Math.max(renderWidth * 2, 1280);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(renderWidth, renderHeight);
        lp.leftMargin = screenWidth + 64;
        lp.topMargin = 0;
        host.setClipChildren(false);
        host.addView(w, lp);

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onReceivedIcon(WebView view, Bitmap icon) {
                if (!nodeId.equals(activeNodeId) || icon == null) return;
                receivedIcon = icon.copy(Bitmap.Config.ARGB_8888, false);
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String loadedUrl) {
                if (!nodeId.equals(activeNodeId)) return;
                scheduleFinish(nodeId, url, listener, 850L);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame() && nodeId.equals(activeNodeId)) {
                    // Some pages report a transient resource error before a redirect succeeds.
                    scheduleFinish(nodeId, url, listener, 1200L);
                }
            }
        });

        w.loadUrl(url);
    }

    private void scheduleFinish(String nodeId, String originalUrl, Listener listener, long delayMs) {
        if (pendingFinish != null) main.removeCallbacks(pendingFinish);
        pendingFinish = () -> finishCapture(nodeId, originalUrl, listener);
        main.postDelayed(pendingFinish, delayMs);
    }

    private void finishCapture(String nodeId, String originalUrl, Listener listener) {
        WebView w = webView;
        if (w == null || !nodeId.equals(activeNodeId)) return;
        if (w.getProgress() < 100 && finishAttempts++ < 3) {
            scheduleFinish(nodeId, originalUrl, listener, 500L);
            return;
        }

        w.scrollTo(0, 0);
        String pageTitle = clean(w.getTitle());
        String siteScript = "(function(){" +
                "var a=['meta[property=\\\"og:site_name\\\"]','meta[name=\\\"application-name\\\"]','meta[name=\\\"apple-mobile-web-app-title\\\"]'];" +
                "for(var i=0;i<a.length;i++){var e=document.querySelector(a[i]);if(e&&e.content)return e.content;}return '';})()";
        String iconScript = "(function(){var e=document.querySelector('link[rel~=\\\"icon\\\"]');return e&&e.href?e.href:'';})()";

        w.evaluateJavascript(siteScript, siteValue -> {
            if (!nodeId.equals(activeNodeId) || webView == null) return;
            String siteName = cleanJs(siteValue);
            if (siteName == null || siteName.isBlank()) siteName = fallbackSiteName(w.getUrl() == null ? originalUrl : w.getUrl());
            final String finalSiteName = siteName;

            w.evaluateJavascript(iconScript, iconValue -> {
                if (!nodeId.equals(activeNodeId) || webView == null) return;
                String iconUrl = cleanJs(iconValue);
                try {
                    File assets = new File(activity.getFilesDir(), "bookmark_assets");
                    if (!assets.exists() && !assets.mkdirs()) throw new IllegalStateException("asset directory");

                    File screenshot = new File(assets, nodeId + "_thumb.jpg");
                    saveSquareScreenshot(w, screenshot);

                    String faviconPath = null;
                    if (receivedIcon != null) {
                        File favicon = new File(assets, nodeId + "_favicon.png");
                        saveBitmap(receivedIcon, favicon, Bitmap.CompressFormat.PNG, 100);
                        faviconPath = favicon.getAbsolutePath();
                    }

                    repo.updateWebMetadata(nodeId, finalSiteName, pageTitle, faviconPath, screenshot.getAbsolutePath());
                    BookmarkNode updated = repo.get(nodeId);
                    if (listener != null) listener.onComplete(true, updated, null);

                    if (faviconPath == null) {
                        String candidate = iconUrl;
                        if (candidate == null || candidate.isBlank()) candidate = defaultFaviconUrl(w.getUrl() == null ? originalUrl : w.getUrl());
                        fetchFaviconAsync(nodeId, candidate, assets, listener);
                    }
                } catch (Exception e) {
                    BookmarkNode updated = repo.get(nodeId);
                    if (listener != null) listener.onComplete(false, updated, "サムネイル取得に失敗しました");
                } finally {
                    clearWebView(nodeId);
                }
            });
        });
    }

    private void fetchFaviconAsync(String nodeId, String iconUrl, File assets, Listener listener) {
        if (iconUrl == null || iconUrl.isBlank()) return;
        io.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(iconUrl).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 Android BookmarkLauncher");
                if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 400) return;
                Bitmap bitmap = android.graphics.BitmapFactory.decodeStream(connection.getInputStream());
                if (bitmap == null) return;
                File favicon = new File(assets, nodeId + "_favicon.png");
                saveBitmap(bitmap, favicon, Bitmap.CompressFormat.PNG, 100);
                repo.updateFaviconPath(nodeId, favicon.getAbsolutePath());
                activity.runOnUiThread(() -> {
                    if (listener != null) listener.onComplete(true, repo.get(nodeId), null);
                });
            } catch (Exception ignored) {
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private static void saveSquareScreenshot(WebView webView, File target) throws Exception {
        int side = Math.max(1, Math.min(webView.getWidth(), webView.getHeight()));
        Bitmap bitmap = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
        webView.draw(canvas);
        saveBitmap(bitmap, target, Bitmap.CompressFormat.JPEG, 90);
        bitmap.recycle();
    }

    private static void saveBitmap(Bitmap bitmap, File file, Bitmap.CompressFormat format, int quality) throws Exception {
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            if (!bitmap.compress(format, quality, out)) throw new IllegalStateException("compress failed");
            out.flush();
        }
    }

    private void cancelActive() {
        if (pendingFinish != null) {
            main.removeCallbacks(pendingFinish);
            pendingFinish = null;
        }
        if (webView != null) {
            try {
                webView.stopLoading();
                host.removeView(webView);
                webView.destroy();
            } catch (Exception ignored) {
            }
            webView = null;
        }
        receivedIcon = null;
        activeNodeId = null;
    }

    private void clearWebView(String nodeId) {
        if (!nodeId.equals(activeNodeId)) return;
        if (webView != null) {
            WebView old = webView;
            webView = null;
            host.removeView(old);
            old.destroy();
        }
        pendingFinish = null;
        receivedIcon = null;
        activeNodeId = null;
    }

    private static String clean(String value) {
        if (value == null) return null;
        String v = value.trim();
        return v.isEmpty() ? null : v;
    }

    private static String cleanJs(String value) {
        if (value == null || "null".equals(value)) return null;
        try {
            Object parsed = new JSONTokener(value).nextValue();
            if (parsed == null) return null;
            return clean(String.valueOf(parsed));
        } catch (Exception ignored) {
            return clean(value.replace("\\\"", "\"").replaceAll("^\"|\"$", ""));
        }
    }

    private static String fallbackSiteName(String url) {
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            if (host == null || host.isBlank()) return "ブックマーク";
            if (host.startsWith("www.")) host = host.substring(4);
            String[] parts = host.split("\\.");
            String base = parts.length == 0 ? host : parts[0];
            if (base.isBlank()) return host;
            return Character.toUpperCase(base.charAt(0)) + base.substring(1);
        } catch (Exception ignored) {
            return "ブックマーク";
        }
    }

    private static String defaultFaviconUrl(String url) {
        try {
            Uri uri = Uri.parse(url);
            if (uri.getScheme() == null || uri.getHost() == null) return null;
            return uri.getScheme() + "://" + uri.getHost() + "/favicon.ico";
        } catch (Exception ignored) {
            return null;
        }
    }
}
