package com.cmyk.bookmarkslauncher.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class BookmarkTileView extends FrameLayout {
    private static final int FOLDER_DROP_EXPAND_DP = 4;
    private static final int N_DGRAY = 0xFF252020;
    private static final int N_GRAY = 0xFF454040;
    private static final int N_LGRAY = 0xFF656060;
    private static final int N_ICON = 0xFFA9A999;
    private static final int N_ORANGE = 0xFF775500;
    private static final int N_BLUE = 0xFF223355;
    private static final int N_LBLUE = 0xFF445577;
    private static final int N_GREEN = 0xFF227733;

    private final BookmarkNode node;
    private final TextView title;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path bookmarkPath = new Path();
    private final List<PreviewItem> previews = new ArrayList<>();
    private Bitmap favicon;
    private boolean dropHighlight;
    private final boolean nestedFolderStyle;

    public BookmarkTileView(Context context, BookmarkNode node) {
        this(context, node, Collections.emptyList(), false);
    }

    public BookmarkTileView(Context context, BookmarkNode node, List<BookmarkNode> previewNodes) {
        this(context, node, previewNodes, false);
    }

    public BookmarkTileView(Context context, BookmarkNode node, List<BookmarkNode> previewNodes, boolean nestedFolderStyle) {
        super(context);
        this.node = node;
        this.nestedFolderStyle = nestedFolderStyle;
        setWillNotDraw(false);
        setBackgroundColor(0x00000000);
        setClickable(true);
        setFocusable(true);
        setElevation(0f);

        if (node.isApp()) {
            favicon = loadAppIcon(context, node.url);
        } else if (!node.isFolder() && node.faviconPath != null) {
            favicon = decode(node.faviconPath);
        }
        if (node.isFolder() && previewNodes != null) {
            int count = Math.min(4, previewNodes.size());
            for (int i = 0; i < count; i++) previews.add(new PreviewItem(context, previewNodes.get(i)));
        }

        title = new TextView(context);
        title.setText(node.displayName());
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(12);
        title.setMaxLines(2);
        title.setIncludeFontPadding(false);
        title.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        title.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, dp(34), Gravity.BOTTOM);
        lp.setMargins(dp(3), 0, dp(3), 0);
        addView(title, lp);
    }

    public BookmarkNode getNode() { return node; }

    public void setDropHighlight(boolean highlighted) {
        if (dropHighlight == highlighted) return;
        dropHighlight = highlighted;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float availableW = Math.max(1f, getWidth() - dp(6));
        float availableH = Math.max(1f, getHeight() - dp(37));
        float side = Math.min(availableW, availableH);
        float left = (getWidth() - side) / 2f;
        float top = dp(1);
        RectF iconBounds = new RectF(left, top, left + side, top + side);

        if (node.isFolder()) {
            if (nestedFolderStyle) drawNestedFolder(canvas, iconBounds);
            else drawHomeFolder(canvas, iconBounds);
        } else if (node.isApp()) {
            drawAppIcon(canvas, iconBounds);
        } else {
            drawBookmarkCircle(canvas, iconBounds);
        }

        if (dropHighlight) {
            float inset = dp(2);
            RectF ring = new RectF(iconBounds.left + inset, iconBounds.top + inset,
                    iconBounds.right - inset, iconBounds.bottom - inset);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(N_GREEN);
            canvas.drawOval(ring, paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }

    /** Home folder: launcher-style N light-blue circle with up to four child previews. */
    private void drawHomeFolder(Canvas canvas, RectF bounds) {
        float diameter = bounds.width();
        float cx = bounds.centerX();
        float cy = bounds.centerY();
        float radius = diameter / 2f;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_LBLUE);
        canvas.drawCircle(cx, cy, radius, paint);

        if (previews.isEmpty()) {
            RectF emptyBounds = new RectF(cx - radius * 0.56f, cy - radius * 0.56f,
                    cx + radius * 0.56f, cy + radius * 0.56f);
            drawFolderVector(canvas, emptyBounds, N_LBLUE);
            return;
        }

        // Preview items are intentionally oversized. Like Pixel Launcher folders, the outer
        // folder circle acts as the mask; a little clipping at the circumference is preferable
        // to tiny, hard-to-read favicons/folder glyphs.
        float miniRadius = radius * 0.48f;
        float dx = radius * 0.44f;
        float dy = radius * 0.43f;
        float[][] positions;
        switch (previews.size()) {
            case 1:
                positions = new float[][]{{cx, cy - radius * 0.18f}};
                break;
            case 2:
                positions = new float[][]{{cx - dx, cy - dy}, {cx + dx, cy - dy}};
                break;
            case 3:
                positions = new float[][]{{cx - dx, cy - dy}, {cx + dx, cy - dy}, {cx, cy + dy}};
                break;
            default:
                positions = new float[][]{{cx - dx, cy - dy}, {cx + dx, cy - dy}, {cx - dx, cy + dy}, {cx + dx, cy + dy}};
                break;
        }

        int save = canvas.save();
        Path folderMask = new Path();
        folderMask.addCircle(cx, cy, radius, Path.Direction.CW);
        canvas.clipPath(folderMask);
        for (int i = 0; i < previews.size() && i < positions.length; i++) {
            drawPreview(canvas, previews.get(i), positions[i][0], positions[i][1], miniRadius);
        }
        canvas.restoreToCount(save);
    }

    /** Folder tile shown inside another folder: dark-gray circle + N-blue folder vector. */
    private void drawNestedFolder(Canvas canvas, RectF bounds) {
        float radius = bounds.width() / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_DGRAY);
        canvas.drawCircle(bounds.centerX(), bounds.centerY(), radius, paint);

        RectF folderBounds = new RectF(
                bounds.left + bounds.width() * 0.16f,
                bounds.top + bounds.height() * 0.18f,
                bounds.right - bounds.width() * 0.16f,
                bounds.bottom - bounds.height() * 0.18f);
        drawFolderVector(canvas, folderBounds, N_LBLUE);
    }

    /** Shared folder silhouette used at every scale so full-size and miniature folders match. */
    private void drawFolderVector(Canvas canvas, RectF bounds, int color) {
        float side = Math.min(bounds.width(), bounds.height());
        float left = bounds.centerX() - side * 0.50f;
        float right = bounds.centerX() + side * 0.50f;
        float top = bounds.centerY() - side * 0.43f;
        float bottom = bounds.centerY() + side * 0.43f;
        float w = right - left;
        float h = bottom - top;
        float tabH = h * 0.20f;
        float tabW = w * 0.45f;
        float corner = Math.max(1f, side * 0.09f);

        Path folder = new Path();
        folder.moveTo(left + corner, top);
        folder.lineTo(left + tabW - corner * 0.35f, top);
        folder.quadTo(left + tabW, top, left + tabW + corner * 0.25f, top + tabH * 0.45f);
        folder.lineTo(left + tabW + corner * 0.80f, top + tabH);
        folder.lineTo(right - corner, top + tabH);
        folder.quadTo(right, top + tabH, right, top + tabH + corner);
        folder.lineTo(right, bottom - corner);
        folder.quadTo(right, bottom, right - corner, bottom);
        folder.lineTo(left + corner, bottom);
        folder.quadTo(left, bottom, left, bottom - corner);
        folder.lineTo(left, top + corner);
        folder.quadTo(left, top, left + corner, top);
        folder.close();

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        canvas.drawPath(folder, paint);
    }

    private void drawPreview(Canvas canvas, PreviewItem preview, float cx, float cy, float radius) {
        if (preview.folder) {
            RectF miniBounds = new RectF(cx - radius, cy - radius, cx + radius, cy + radius);
            drawNestedFolder(canvas, miniBounds);
            return;
        }
        if (preview.app && preview.bitmap != null) {
            float half = radius * 0.82f;
            RectF dst = new RectF(cx - half, cy - half, cx + half, cy + half);
            float ratio = Math.min(dst.width() / Math.max(1, preview.bitmap.getWidth()),
                    dst.height() / Math.max(1, preview.bitmap.getHeight()));
            float w = preview.bitmap.getWidth() * ratio;
            float h = preview.bitmap.getHeight() * ratio;
            paint.setFilterBitmap(true);
            canvas.drawBitmap(preview.bitmap, null, new RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f), paint);
            return;
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_DGRAY);
        canvas.drawCircle(cx, cy, radius, paint);

        // Keep current favicon sizing; only the folder tile style changes in this build.
        float faviconHalf = radius * 0.512f;
        RectF faviconDst = new RectF(cx - faviconHalf, cy - faviconHalf,
                cx + faviconHalf, cy + faviconHalf);
        float fallbackInset = radius * 0.22f;
        RectF fallbackDst = new RectF(cx - radius + fallbackInset, cy - radius + fallbackInset,
                cx + radius - fallbackInset, cy + radius - fallbackInset);

        if (preview.bitmap != null) {
            paint.setFilterBitmap(true);
            float ratio = Math.min(faviconDst.width() / Math.max(1, preview.bitmap.getWidth()),
                    faviconDst.height() / Math.max(1, preview.bitmap.getHeight()));
            float w = preview.bitmap.getWidth() * ratio;
            float h = preview.bitmap.getHeight() * ratio;
            RectF fitted = new RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);
            canvas.drawBitmap(preview.bitmap, null, fitted, paint);
        } else {
            drawBookmarkGlyph(canvas, fallbackDst);
        }
    }


    /** App shortcut: render the installed app's own icon without the bookmark-circle treatment. */
    private void drawAppIcon(Canvas canvas, RectF bounds) {
        if (favicon == null) {
            drawBookmarkCircle(canvas, bounds);
            return;
        }
        float half = Math.min(bounds.width(), bounds.height()) * 0.41f;
        float cx = bounds.centerX();
        float cy = bounds.centerY();
        RectF max = new RectF(cx - half, cy - half, cx + half, cy + half);
        float ratio = Math.min(max.width() / Math.max(1, favicon.getWidth()),
                max.height() / Math.max(1, favicon.getHeight()));
        float w = favicon.getWidth() * ratio;
        float h = favicon.getHeight() * ratio;
        paint.setFilterBitmap(true);
        canvas.drawBitmap(favicon, null, new RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f), paint);
    }

    /** Bookmark icon: a dark-gray circle with the favicon centered without any circular crop. */
    private void drawBookmarkCircle(Canvas canvas, RectF bounds) {
        float diameter = bounds.width();
        float radius = diameter / 2f;
        float cx = bounds.centerX();
        float cy = bounds.centerY();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_DGRAY);
        canvas.drawCircle(cx, cy, radius, paint);

        // Another step smaller than 0.1.13: keep the circle size unchanged and shrink only favicon.
        RectF faviconBounds = new RectF(cx - radius * 0.512f, cy - radius * 0.512f,
                cx + radius * 0.512f, cy + radius * 0.512f);
        RectF fallbackBounds = new RectF(cx - radius * 0.74f, cy - radius * 0.74f,
                cx + radius * 0.74f, cy + radius * 0.74f);
        if (favicon != null) {
            float ratio = Math.min(faviconBounds.width() / Math.max(1, favicon.getWidth()),
                    faviconBounds.height() / Math.max(1, favicon.getHeight()));
            float w = favicon.getWidth() * ratio;
            float h = favicon.getHeight() * ratio;
            RectF dst = new RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);
            paint.setFilterBitmap(true);
            canvas.drawBitmap(favicon, null, dst, paint);
        } else {
            drawBookmarkGlyph(canvas, fallbackBounds);
        }
    }

    private void drawBookmarkGlyph(Canvas canvas, RectF bounds) {
        float size = bounds.width() * 0.42f;
        float cx = bounds.centerX();
        float top = bounds.centerY() - size * 0.78f;
        float left = cx - size * 0.65f;
        float right = cx + size * 0.65f;
        float bottom = top + size * 1.55f;
        paint.setColor(N_ICON);
        bookmarkPath.reset();
        bookmarkPath.moveTo(left, top);
        bookmarkPath.lineTo(right, top);
        bookmarkPath.lineTo(right, bottom);
        bookmarkPath.lineTo(cx, bottom - size * 0.45f);
        bookmarkPath.lineTo(left, bottom);
        bookmarkPath.close();
        canvas.drawPath(bookmarkPath, paint);
    }


    /**
     * Hit-test the visual icon itself rather than the whole tile (which also includes the label).
     * Existing folders use nearly the full circular icon as their drop target; bookmarks keep a
     * smaller center target so grazing the edge still behaves as reorder instead of folder-create.
     */
    public boolean isFolderDropHit(float localX, float localY) {
        float availableW = Math.max(1f, getWidth() - dp(6));
        float availableH = Math.max(1f, getHeight() - dp(37));
        float side = Math.min(availableW, availableH);
        float left = (getWidth() - side) / 2f;
        float top = dp(1);
        float cx = left + side / 2f;
        float cy = top + side / 2f;
        float expand = dp(FOLDER_DROP_EXPAND_DP);
        if (node.isFolder()) {
            if (!nestedFolderStyle) {
                float radius = side * 0.53f + expand;
                float dx = localX - cx;
                float dy = localY - cy;
                return dx * dx + dy * dy <= radius * radius;
            }
            float padX = side * 0.02f;
            float padTop = side * 0.07f;
            float padBottom = side * 0.05f;
            return localX >= left + padX - expand && localX <= left + side - padX + expand
                    && localY >= top + padTop - expand && localY <= top + side - padBottom + expand;
        }
        float radius = side * 0.53f + expand;
        float dx = localX - cx;
        float dy = localY - cy;
        return dx * dx + dy * dy <= radius * radius;
    }

    private Bitmap decode(String path) {
        if (path == null || path.isBlank()) return null;
        File file = new File(path);
        return file.isFile() ? BitmapFactory.decodeFile(file.getAbsolutePath()) : null;
    }

    private static Bitmap loadAppIcon(Context context, String packageName) {
        if (context == null || packageName == null || packageName.isBlank()) return null;
        try {
            Drawable drawable = context.getPackageManager().getApplicationIcon(packageName);
            if (drawable == null) return null;
            int w = Math.max(1, drawable.getIntrinsicWidth());
            int h = Math.max(1, drawable.getIntrinsicHeight());
            if (w <= 1) w = 96;
            if (h <= 1) h = 96;
            Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, w, h);
            drawable.draw(canvas);
            return bitmap;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static final class PreviewItem {
        final boolean folder;
        final boolean app;
        final Bitmap bitmap;

        PreviewItem(Context context, BookmarkNode node) {
            folder = node != null && node.isFolder();
            app = node != null && node.isApp();
            Bitmap found = null;
            if (!folder && app) {
                found = loadAppIcon(context, node.url);
            } else if (!folder && node != null && node.faviconPath != null) {
                File file = new File(node.faviconPath);
                if (file.isFile()) found = BitmapFactory.decodeFile(file.getAbsolutePath());
            }
            bitmap = found;
        }
    }
}
