package com.cmyk.bookmarkslauncher.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import java.io.File;

public final class BookmarkTileView extends FrameLayout {
    private static final int N_GRAY = 0xFF454040;
    private static final int N_LGRAY = 0xFF656060;
    private static final int N_ICON = 0xFFA9A999;
    private static final int N_ORANGE = 0xFF775500;
    private static final int N_GREEN = 0xFF227733;

    private final BookmarkNode node;
    private final TextView title;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path bookmarkPath = new Path();
    private Bitmap favicon;
    private boolean dropHighlight;

    public BookmarkTileView(Context context, BookmarkNode node) {
        super(context);
        this.node = node;
        setWillNotDraw(false);
        setBackgroundColor(0x00000000);
        setClickable(true);
        setFocusable(true);
        setElevation(0f);

        if (!node.isFolder() && node.faviconPath != null) {
            File f = new File(node.faviconPath);
            if (f.isFile()) favicon = BitmapFactory.decodeFile(f.getAbsolutePath());
        }

        title = new TextView(context);
        title.setText(node.displayName());
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(12);
        title.setMaxLines(2);
        title.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        title.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, dp(34), Gravity.BOTTOM);
        lp.setMargins(dp(4), 0, dp(4), dp(1));
        addView(title, lp);
    }

    public BookmarkNode getNode() { return node; }

    public void setDropHighlight(boolean highlighted) {
        if (dropHighlight == highlighted) return;
        dropHighlight = highlighted;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float availableW = Math.max(1f, getWidth() - dp(12));
        float availableH = Math.max(1f, getHeight() - dp(42));
        float side = Math.min(availableW, availableH);
        float left = (getWidth() - side) / 2f;
        float top = dp(5);
        RectF card = new RectF(left, top, left + side, top + side);
        float radius = Math.max(dp(10), side * 0.16f);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(dropHighlight ? N_LGRAY : N_GRAY);
        canvas.drawRoundRect(card, radius, radius, paint);

        if (node.isFolder()) {
            drawFolder(canvas, card);
        } else if (favicon != null) {
            drawFavicon(canvas, card);
        } else {
            drawBookmarkGlyph(canvas, card);
        }

        if (dropHighlight) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(N_GREEN);
            canvas.drawRoundRect(card, radius, radius, paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }

    private void drawFolder(Canvas canvas, RectF card) {
        float iconSide = card.width() * 0.50f;
        float cx = card.centerX();
        float top = card.top + card.height() * 0.26f;
        paint.setColor(N_ORANGE);
        RectF body = new RectF(cx - iconSide / 2f, top + iconSide * 0.22f,
                cx + iconSide / 2f, top + iconSide * 0.84f);
        canvas.drawRoundRect(body, dp(6), dp(6), paint);
        RectF tab = new RectF(body.left + iconSide * 0.08f, top,
                body.left + iconSide * 0.50f, top + iconSide * 0.36f);
        canvas.drawRoundRect(tab, dp(5), dp(5), paint);
    }

    private void drawFavicon(Canvas canvas, RectF card) {
        float max = card.width() * 0.56f;
        float ratio = Math.min(max / Math.max(1, favicon.getWidth()), max / Math.max(1, favicon.getHeight()));
        float w = favicon.getWidth() * ratio;
        float h = favicon.getHeight() * ratio;
        RectF dst = new RectF(card.centerX() - w / 2f, card.centerY() - h / 2f,
                card.centerX() + w / 2f, card.centerY() + h / 2f);
        paint.setFilterBitmap(true);
        canvas.drawBitmap(favicon, null, dst, paint);
    }

    private void drawBookmarkGlyph(Canvas canvas, RectF card) {
        float size = card.width() * 0.30f;
        float cx = card.centerX();
        float top = card.centerY() - size * 0.78f;
        float left = cx - size * 0.65f;
        float right = cx + size * 0.65f;
        float bottom = top + size * 1.55f;
        paint.setColor(N_ICON);
        bookmarkPath.reset();
        bookmarkPath.moveTo(left, top);
        bookmarkPath.lineTo(right, top);
        bookmarkPath.lineTo(right, bottom);
        bookmarkPath.lineTo(cx, bottom - size * 0.45f);
        bookmarkPath.lineTo(left, bottom);
        bookmarkPath.close();
        canvas.drawPath(bookmarkPath, paint);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
