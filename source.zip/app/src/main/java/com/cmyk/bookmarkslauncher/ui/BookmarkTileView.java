package com.cmyk.bookmarkslauncher.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

public final class BookmarkTileView extends FrameLayout {
    private final BookmarkNode node;
    private final TextView title;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path bookmarkPath = new Path();

    public BookmarkTileView(Context context, BookmarkNode node) {
        super(context);
        this.node = node;
        setWillNotDraw(false);
        setPadding(dp(8), dp(8), dp(8), dp(8));
        setBackgroundColor(0xFF454040);

        title = new TextView(context);
        title.setText(node.title);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(12);
        title.setMaxLines(node.spanY > 1 ? 3 : 2);
        title.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        title.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        addView(title, lp);
    }

    public BookmarkNode getNode() { return node; }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float top = dp(12);
        float size = Math.min(getWidth(), getHeight()) * (node.spanX > 1 || node.spanY > 1 ? 0.26f : 0.34f);
        paint.setColor(node.isFolder() ? 0xFF775500 : 0xFFA9A999);

        if (node.isFolder()) {
            float left = cx - size;
            float right = cx + size;
            float bottom = top + size * 1.35f;
            canvas.drawRoundRect(left, top + size * 0.25f, right, bottom, dp(6), dp(6), paint);
            canvas.drawRoundRect(left + size * 0.12f, top, cx, top + size * 0.45f, dp(5), dp(5), paint);
        } else {
            bookmarkPath.reset();
            float left = cx - size * 0.65f;
            float right = cx + size * 0.65f;
            float bottom = top + size * 1.55f;
            bookmarkPath.moveTo(left, top);
            bookmarkPath.lineTo(right, top);
            bookmarkPath.lineTo(right, bottom);
            bookmarkPath.lineTo(cx, bottom - size * 0.45f);
            bookmarkPath.lineTo(left, bottom);
            bookmarkPath.close();
            canvas.drawPath(bookmarkPath, paint);
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
