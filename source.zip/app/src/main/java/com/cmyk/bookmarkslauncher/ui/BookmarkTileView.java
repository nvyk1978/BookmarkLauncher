package com.cmyk.bookmarkslauncher.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.cmyk.bookmarkslauncher.data.BookmarkNode;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class BookmarkTileView extends FrameLayout {
    private static final int N_DGRAY = 0xFF252020;
    private static final int N_GRAY = 0xFF454040;
    private static final int N_LGRAY = 0xFF656060;
    private static final int N_ICON = 0xFFA9A999;
    private static final int N_ORANGE = 0xFF775500;
    private static final int N_GREEN = 0xFF227733;

    private final BookmarkNode node;
    private final TextView title;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path bookmarkPath = new Path();
    private final List<PreviewItem> previews = new ArrayList<>();
    private Bitmap favicon;
    private boolean dropHighlight;

    public BookmarkTileView(Context context, BookmarkNode node) {
        this(context, node, Collections.emptyList());
    }

    public BookmarkTileView(Context context, BookmarkNode node, List<BookmarkNode> previewNodes) {
        super(context);
        this.node = node;
        setWillNotDraw(false);
        setBackgroundColor(0x00000000);
        setClickable(true);
        setFocusable(true);
        setElevation(0f);

        if (!node.isFolder() && node.faviconPath != null) {
            favicon = decode(node.faviconPath);
        }
        if (node.isFolder() && previewNodes != null) {
            int count = Math.min(4, previewNodes.size());
            for (int i = 0; i < count; i++) previews.add(new PreviewItem(previewNodes.get(i)));
        }

        title = new TextView(context);
        title.setText(node.displayName());
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(12);
        title.setMaxLines(2);
        title.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        title.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, dp(34), Gravity.BOTTOM);
        lp.setMargins(dp(4), 0, dp(4), dp(1));
        addView(title, lp);
    }

    public BookmarkNode getNode() { return node; }

    public void setDropHighlight(boolean highlighted) {
        if (dropHighlight == highlighted) return;
        dropHighlight = highlighted;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float availableW = Math.max(1f, getWidth() - dp(10));
        float availableH = Math.max(1f, getHeight() - dp(40));
        float side = Math.min(availableW, availableH);
        float left = (getWidth() - side) / 2f;
        float top = dp(3);
        RectF iconBounds = new RectF(left, top, left + side, top + side);

        if (node.isFolder()) drawFolder(canvas, iconBounds);
        else if (favicon != null) drawFavicon(canvas, iconBounds);
        else drawBookmarkGlyph(canvas, iconBounds);

        if (dropHighlight) {
            float inset = dp(2);
            RectF ring = new RectF(iconBounds.left + inset, iconBounds.top + inset,
                    iconBounds.right - inset, iconBounds.bottom - inset);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(N_GREEN);
            if (node.isFolder()) canvas.drawOval(ring, paint);
            else canvas.drawRoundRect(ring, dp(12), dp(12), paint);
            paint.setStyle(Paint.Style.FILL);
        }
    }

    /** Pixel-launcher-like folder: one large circle containing small previews. */
    private void drawFolder(Canvas canvas, RectF bounds) {
        float diameter = bounds.width() * 0.90f;
        float cx = bounds.centerX();
        float cy = bounds.centerY();
        float radius = diameter / 2f;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(N_GRAY);
        canvas.drawCircle(cx, cy, radius, paint);

        if (previews.isEmpty()) {
            drawMiniFolderGlyph(canvas, cx, cy, radius * 0.42f, N_ORANGE);
            return;
        }

        float miniRadius = radius * 0.34f;
        float dx = radius * 0.36f;
        float dy = radius * 0.34f;
        float[][] positions;
        switch (previews.size()) {
            case 1:
                positions = new float[][]{{cx, cy - radius * 0.18f}};
                break;
            case 2:
                positions = new float[][]{{cx - dx, cy - dy}, {cx + dx, cy - dy}};
                break;
            case 3:
                positions = new float[][]{{cx - dx, cy - dy}, {cx + dx, cy - dy}, {cx, cy + dy}};
                break;
            default:
                positions = new float[][]{{cx - dx, cy - dy}, {cx + dx, cy - dy}, {cx - dx, cy + dy}, {cx + dx, cy + dy}};
                break;
        }

        for (int i = 0; i < previews.size() && i < positions.length; i++) {
            drawPreview(canvas, previews.get(i), positions[i][0], positions[i][1], miniRadius);
        }
    }

    private void drawPreview(Canvas canvas, PreviewItem preview, float cx, float cy, float radius) {
        paint.setColor(N_DGRAY);
        canvas.drawCircle(cx, cy, radius, paint);
        float inset = radius * 0.14f;
        RectF dst = new RectF(cx - radius + inset, cy - radius + inset,
                cx + radius - inset, cy + radius - inset);

        if (preview.bitmap != null) {
            paint.setFilterBitmap(true);
            canvas.save();
            Path clip = new Path();
            clip.addCircle(cx, cy, radius - inset, Path.Direction.CW);
            canvas.clipPath(clip);
            canvas.drawBitmap(preview.bitmap, null, dst, paint);
            canvas.restore();
        } else if (preview.folder) {
            drawMiniFolderGlyph(canvas, cx, cy, radius * 1.25f, N_ORANGE);
        } else {
            drawBookmarkGlyph(canvas, dst);
        }
    }

    /** Bookmark tiles have no background card; favicon itself is the visual icon. */
    private void drawFavicon(Canvas canvas, RectF bounds) {
        float max = bounds.width() * 0.82f;
        float ratio = Math.min(max / Math.max(1, favicon.getWidth()), max / Math.max(1, favicon.getHeight()));
        float w = favicon.getWidth() * ratio;
        float h = favicon.getHeight() * ratio;
        RectF dst = new RectF(bounds.centerX() - w / 2f, bounds.centerY() - h / 2f,
                bounds.centerX() + w / 2f, bounds.centerY() + h / 2f);
        paint.setFilterBitmap(true);
        canvas.drawBitmap(favicon, null, dst, paint);
    }

    private void drawBookmarkGlyph(Canvas canvas, RectF bounds) {
        float size = bounds.width() * 0.42f;
        float cx = bounds.centerX();
        float top = bounds.centerY() - size * 0.78f;
        float left = cx - size * 0.65f;
        float right = cx + size * 0.65f;
        float bottom = top + size * 1.55f;
        paint.setColor(N_ICON);
        bookmarkPath.reset();
        bookmarkPath.moveTo(left, top);
        bookmarkPath.lineTo(right, top);
        bookmarkPath.lineTo(right, bottom);
        bookmarkPath.lineTo(cx, bottom - size * 0.45f);
        bookmarkPath.lineTo(left, bottom);
        bookmarkPath.close();
        canvas.drawPath(bookmarkPath, paint);
    }

    private void drawMiniFolderGlyph(Canvas canvas, float cx, float cy, float size, int color) {
        paint.setColor(color);
        RectF body = new RectF(cx - size * 0.50f, cy - size * 0.16f,
                cx + size * 0.50f, cy + size * 0.38f);
        canvas.drawRoundRect(body, Math.max(1f, size * 0.12f), Math.max(1f, size * 0.12f), paint);
        RectF tab = new RectF(body.left + size * 0.08f, cy - size * 0.42f,
                body.left + size * 0.48f, cy - size * 0.06f);
        canvas.drawRoundRect(tab, Math.max(1f, size * 0.10f), Math.max(1f, size * 0.10f), paint);
    }


    /**
     * Hit-test the visual icon itself rather than the whole tile (which also includes the label).
     * Existing folders use nearly the full circular icon as their drop target; bookmarks keep a
     * smaller center target so grazing the edge still behaves as reorder instead of folder-create.
     */
    public boolean isFolderDropHit(float localX, float localY) {
        float availableW = Math.max(1f, getWidth() - dp(10));
        float availableH = Math.max(1f, getHeight() - dp(40));
        float side = Math.min(availableW, availableH);
        float left = (getWidth() - side) / 2f;
        float top = dp(3);
        float cx = left + side / 2f;
        float cy = top + side / 2f;
        float radius = side * (node.isFolder() ? 0.48f : 0.30f);
        float dx = localX - cx;
        float dy = localY - cy;
        return dx * dx + dy * dy <= radius * radius;
    }

    private Bitmap decode(String path) {
        if (path == null || path.isBlank()) return null;
        File file = new File(path);
        return file.isFile() ? BitmapFactory.decodeFile(file.getAbsolutePath()) : null;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static final class PreviewItem {
        final boolean folder;
        final Bitmap bitmap;

        PreviewItem(BookmarkNode node) {
            folder = node != null && node.isFolder();
            Bitmap found = null;
            if (!folder && node != null && node.faviconPath != null) {
                File file = new File(node.faviconPath);
                if (file.isFile()) found = BitmapFactory.decodeFile(file.getAbsolutePath());
            }
            bitmap = found;
        }
    }
}
