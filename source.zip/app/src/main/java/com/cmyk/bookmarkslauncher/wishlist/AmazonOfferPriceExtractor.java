package com.cmyk.bookmarkslauncher.wishlist;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Price ONLY: exact JPY offer for requested marketplace item, never minimum/related/shipping. */
final class AmazonOfferPriceExtractor {
    private static final Pattern META=Pattern.compile("(?is)<meta\\b[^>]*>");
    private static final Pattern ATTR=Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')",Pattern.CASE_INSENSITIVE);
    private static final Pattern PRICE_ELEMENT=Pattern.compile("(?is)<(?:span|div|p|strong|em)\\b([^>]*(?:id|class)\\s*=\\s*['\"][^'\"]*(?:priceblock_ourprice|priceblock_dealprice|priceblock_saleprice|price_inside_buybox|priceToPay|elPriceNumber|item-price|itemPrice|product-price|sale-price|selling-price)[^'\"]*['\"][^>]*)>(.{1,300}?)</(?:span|div|p|strong|em)\\s*>");
    private static final Pattern TEXT=Pattern.compile("(?:[¥￥]\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)|([0-9][0-9,]*)\\s*円)");
    private AmazonOfferPriceExtractor(){}
    static Long parse(String html,URL page){
        MarketplaceIdentity id=MarketplaceIdentity.from(page);
        if(id==null||id.site!=MarketplaceIdentity.Site.AMAZON||!id.verified(html,page))return null;
        JSONObject product=AmazonProductJsonLd.find(html,page);
        if(product!=null){
            LinkedHashSet<Long> prices=new LinkedHashSet<>();
            readOffers(product.opt("offers"),prices,"",0);
            if(prices.size()==1)return prices.iterator().next();
            if(prices.size()>1)return null; // Do not turn a variant's minimum into an exact price.
        }
        // Amazon buy-box elements are scoped product-price signals; not related cards.
        if(id.site==MarketplaceIdentity.Site.AMAZON){
            Long amazon=AmazonPriceExtractor.fromHtml(html);
            if(amazon!=null)return amazon;
        }
        // Product-specific OGP price is valid only on a canonical-confirmed detail URL.
        String amount=null,currency=null;
        Matcher metas=META.matcher(html);
        while(metas.find()){
            String tag=metas.group();
            String key=first(attr(tag,"property"),attr(tag,"name"));
            if(key==null)continue;
            key=key.toLowerCase(Locale.ROOT);
            if(key.equals("product:price:amount")||key.equals("og:price:amount")||key.equals("product:sale_price:amount"))amount=first(amount,attr(tag,"content"));
            if(key.equals("product:price:currency")||key.equals("og:price:currency"))currency=first(currency,attr(tag,"content"));
        }
        if(amount!=null&&(currency==null||currency.equalsIgnoreCase("JPY"))){
            Long p=yen(amount);if(p!=null)return p;
        }
        // Site-specific primary-price containers (not arbitrary yen in document).
        Matcher element=PRICE_ELEMENT.matcher(html);
        LinkedHashSet<Long> explicit=new LinkedHashSet<>();
        while(element.find() && explicit.size()<3){
            String scope=element.group(2).replaceAll("(?s)<[^>]+>"," ").replace("&yen;","¥");
            // Price ranges are not a confirmed fixed current price.
            if(scope.matches("(?s).*(?:～|〜|から|より).*"))continue;
            Matcher text=TEXT.matcher(scope);
            if(text.find()){
                Long price=yen(first(text.group(1),text.group(2)));
                if(price!=null)explicit.add(price);
            }
        }
        return explicit.size()==1?explicit.iterator().next():null;
    }
    static WishlistRetailPriceQuote quote(String html,URL page){
        MarketplaceIdentity id=MarketplaceIdentity.from(page);
        if(id==null||id.site!=MarketplaceIdentity.Site.AMAZON||!id.verified(html,page))return null;
        JSONObject product=AmazonProductJsonLd.find(html,page);
        if(product==null)return null;
        Object raw=product.opt("offers");
        if(!(raw instanceof JSONObject))return null;
        JSONObject offer=(JSONObject)raw;
        if(!offer.optString("@type","").toLowerCase(Locale.ROOT).contains("aggregateoffer"))return null;
        if(!"JPY".equalsIgnoreCase(offer.optString("priceCurrency","")))return null;
        Long lo=yen(offer.optString("lowPrice",null));
        Long hi=yen(offer.optString("highPrice",null));
        if(lo==null || (hi!=null&&hi<lo))return null;
        return WishlistRetailPriceQuote.fromBareText("¥"+lo+"～"+(hi==null?"":"¥"+hi));
    }
    private static void readOffers(Object node,LinkedHashSet<Long> results,String inheritedCurrency,int depth){
        if(node==null||depth>9||results.size()>2)return;
        if(node instanceof JSONArray){JSONArray a=(JSONArray)node;for(int i=0;i<Math.min(30,a.length());i++)readOffers(a.opt(i),results,inheritedCurrency,depth+1);}
        else if(node instanceof JSONObject){
            JSONObject o=(JSONObject)node;
            String currency=first(o.optString("priceCurrency",null),inheritedCurrency);
            String type=o.optString("@type","").toLowerCase(Locale.ROOT);
            if(!type.contains("aggregateoffer")&&"JPY".equalsIgnoreCase(currency)){
                Long p=yen(o.optString("price",null));if(p!=null)results.add(p);
                readOffers(o.opt("priceSpecification"),results,currency,depth+1);
            }
            readOffers(o.opt("offers"),results,currency,depth+1);
        }
    }
    private static Long yen(String raw){
        if(raw==null||raw.isBlank())return null;
        try{
            String p=raw.trim().replace(",","").replace("¥","").replace("￥","").replace("円","");
            if(!p.matches("[0-9]+(?:\\.[0-9]{1,2})?"))return null;
            long price=Math.round(Double.parseDouble(p));
            return price>0&&price<=100000000?price:null;
        }catch(Exception ignored){return null;}
    }
    private static String attr(String tag,String name){Matcher m=ATTR.matcher(tag);while(m.find())if(name.equalsIgnoreCase(m.group(1)))return m.group(2)!=null?m.group(2):m.group(3);return null;}
    private static String first(String a,String b){return a!=null&&!a.isBlank()?a:b;}
}
