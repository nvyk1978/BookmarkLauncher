package com.cmyk.bookmarkslauncher.ui;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

/** Normalizes a shared store message immediately after it is pasted into a URL field. */
public final class SharedUrlPaste {
    private SharedUrlPaste() {}

    public static void attach(EditText field) {
        if (field == null) return;
        field.addTextChangedListener(new TextWatcher() {
            private boolean normalizing;

            @Override public void beforeTextChanged(CharSequence text, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence text, int start, int before, int count) {}

            @Override public void afterTextChanged(Editable text) {
                if (normalizing || text == null) return;
                String entered = text.toString();
                String extracted = SharedUrlExtractor.extractOrOriginal(entered);
                if (!extracted.equals(entered) && extracted.contains("://")) {
                    normalizing = true;
                    try {
                        field.setText(extracted);
                        field.setSelection(extracted.length());
                    } finally {
                        normalizing = false;
                    }
                }
            }
        });
    }
}
