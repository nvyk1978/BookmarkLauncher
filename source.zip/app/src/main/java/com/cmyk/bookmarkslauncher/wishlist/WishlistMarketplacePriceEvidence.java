package com.cmyk.bookmarkslauncher.wishlist;

/** Ephemeral, document-scoped item price proof for serial WebView DOM polls.
 * A missing later field does not erase earlier valid proof. A conflict must not
 * silently pick one promotional or variant price. Never persist this object. */
final class WishlistMarketplacePriceEvidence {
    private Long value;
    private boolean conflict;
    void clear() { value = null; conflict = false; }
    void offer(Long candidate) {
        if (candidate == null || conflict) return;
        if (value != null && !value.equals(candidate)) {
            value = null;
            conflict = true;
        } else value = candidate;
    }
    Long get() { return conflict ? null : value; }
    boolean conflicted() { return conflict; }
}
